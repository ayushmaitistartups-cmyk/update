# Backend — Overview, Stack & Architecture

The Lumos backend is an **async FastAPI + uvicorn application** that is the brain of the Smart Tutor Lamp. It terminates one persistent binary WebSocket per ESP32-S3 lamp, accepts a multimodal "turn" (camera JPEG(s) + microphone PCM), runs it through a deterministic pre-router → tiered multimodal LLM (Gemini 3.1 Flash-Lite by default, with Claude/OpenAI/DeepSeek swappable and a Pro tier-3) → code-enforced output validator → reply schema → TTS (Gemini, Piper, or Cartesia) + LaTeX / graph / chemistry / TFT rendering, and streams paced audio + chunked screen frames back to the lamp — all while persisting sessions/turns/memory to Supabase Postgres (+pgvector) and optionally Redis. The same engine also drives a web "brain-bench" simulator, a beta-cohort pilot instrumentation surface, and firmware OTA. This document is the definitive reference for the backend's stack, bootstrapping, configuration, layered architecture, and the complete end-to-end request lifecycle, grounded entirely in the code under [`Smart-Tutor-Lamp-backend/app/`](Smart-Tutor-Lamp-backend/app).

> **Updated 2026-07-05** (backend tip `a5533e5`, 116 commits; last full sync 2026-06-16 `00d20d6`). New since the last sync: the **Cartesia** streaming-TTS engine, the **RDKit** chemistry-structure renderer and the restored matplotlib **graph** renderer, the scrollable-**document** TFT model, the code-enforced **output validator / input guard / math verifier** (doc 11), the **pilot / insights / OTA / offline-tagger** subsystems (doc 12), the current tutor **nudge/verdict guard stack**, and — 2026-07-03/04 — a **memory-leak/OOM hardening pass**: a process-wide `render_graph_gated()` concurrency gate (`GRAPH_RENDER_CONCURRENCY`), closed matplotlib figure / `AsyncGroq` HTTP-client handles, hard per-turn audio/image buffer ceilings, `GRAPH_VIEW` request coalescing, and a backgrounded (parallel, not serial) conversational-memory load. Structural: `legacy/` moved to **`app/legacy/`** (only `validator.py` + `turn_handler.py`), and `temp_server_files/` was **deleted**.

---

## Table of Contents

1. [Purpose & Responsibility](#1-purpose--responsibility)
2. [Technology Stack](#2-technology-stack)
3. [Layered Architecture](#3-layered-architecture)
4. [Application Bootstrapping & Startup](#4-application-bootstrapping--startup)
5. [Configuration & Environment Variables](#5-configuration--environment-variables)
6. [Logging Subsystem](#6-logging-subsystem)
7. [The Wire Protocol](#7-the-wire-protocol)
8. [Session State & Frame Handling](#8-session-state--frame-handling)
9. [The Turn Orchestrator](#9-the-turn-orchestrator)
10. [Provider Abstractions (LLM & TTS)](#10-provider-abstractions-llm--tts)
11. [Storage, Persistence & Memory](#11-storage-persistence--memory)
12. [End-to-End Request Lifecycle](#12-end-to-end-request-lifecycle)
13. [Error Handling, Timeouts, Retries & Fallbacks](#13-error-handling-timeouts-retries--fallbacks)
14. [Integration Points & Cross-References](#14-integration-points--cross-references)
15. [File-by-File / Function-by-Function Breakdown](#15-file-by-file--function-by-function-breakdown)

---

## 1. Purpose & Responsibility

The backend is the **single in-process orchestration server** between the lamp's edge hardware and all cloud AI services. Its non-negotiable design goal, stated at the top of [BACKEND_DESIGN.md:3](Smart-Tutor-Lamp-backend/BACKEND_DESIGN.md#L3), is **sub-2-second perceived latency** from end-of-speech to first audio/first pixels. Every architectural choice — collapsing STT+LLM into one multimodal call, streaming TTS while the LLM still generates, persistent WebSocket, pre-uploading images during speech — serves that latency budget.

Concrete responsibilities:

- **Terminate the lamp WebSocket** (`/lamp/ws`) and the web bench WebSocket (`/api/frontend/ws`), decoding/encoding the binary frame protocol ([protocol.py](Smart-Tutor-Lamp-backend/app/protocol.py)).
- **Authenticate** the device (dev-bypass or Clerk + device_jwt + DB row checks) — gated by `ENABLE_AUTH`.
- **Buffer a turn**: accumulate chunked image JPEGs + mic PCM, gate on duration, and hand off to the orchestrator ([session.py](Smart-Tutor-Lamp-backend/app/session.py)).
- **Run the turn pipeline**: image enhancement, pre-routing, tiered LLM dispatch, escalation, problem-memo grounding, guard re-calls ([orchestrator.py](Smart-Tutor-Lamp-backend/app/services/orchestrator.py)).
- **Dispatch the reply**: parallel TTS audio leg + TFT text/LaTeX leg back to the lamp ([dispatch.py](Smart-Tutor-Lamp-backend/app/services/dispatch.py)).
- **Persist** sessions, turns, memory (L1/L2/L3), blobs, and admin traces to Postgres/Redis/object-storage.
- **Serve firmware OTA** — the lamp polls `GET /lamp/ota/version` (always mounted, unauthenticated) and self-flashes from a Postgres-stored `.bin` (doc 12 §3).
- **Instrument the beta cohort** — the pilot surface (turn feedback, surveys, one-tap problem reports, consent, activation funnel) and the admin-only **insights** learning-analytics + the offline **topic/mistake taggers** (doc 12).
- **Enforce output in code** — a deterministic input guard + output validator + math/chem verifier runs after the LLM parse, before dispatch (doc 11).
- **Fail loud at boot, degrade gracefully at runtime**: startup self-tests refuse to come up on misconfiguration ([startup.py](Smart-Tutor-Lamp-backend/app/startup.py)), but a missing DB/Redis/TTS at runtime degrades to a still-functional path.

---

## 2. Technology Stack

### 2.1 Core framework & runtime

Declared in [pyproject.toml:8-23](Smart-Tutor-Lamp-backend/pyproject.toml#L8) and [requirements.txt:11-16](Smart-Tutor-Lamp-backend/requirements.txt#L11):

| Library | Role |
|---|---|
| **FastAPI** | ASGI web framework — routes, WebSocket endpoints, middleware, exception handlers |
| **uvicorn[standard]** | ASGI server (dev `--reload`; prod `--workers 2` on a single VM per [main.py:9-12](Smart-Tutor-Lamp-backend/app/main.py#L9)) |
| **websockets** | WS transport library used by uvicorn/Starlette |
| **pydantic >= 2.0** | Reply schema (`LlmReply`) uses v2 `ConfigDict` / `model_validate_json` |
| **pydantic-settings >= 2.0** | Env-driven `Settings` object ([config.py:28](Smart-Tutor-Lamp-backend/app/config.py#L28)) |
| **python-dotenv** | Pushes `.env` into `os.environ` before anyone reads it ([config.py:25](Smart-Tutor-Lamp-backend/app/config.py#L25)) |
| **Python >= 3.11** | `requires-python` in pyproject; code uses PEP 604 `str \| None` |

### 2.2 Media / rendering

| Library | Role |
|---|---|
| **matplotlib** | mathtext renders LaTeX equations to TFT pixels ([latex_engine.py](Smart-Tutor-Lamp-backend/app/providers/latex_engine.py)); also drives the **graph renderer** ([graph_renderer.py](Smart-Tutor-Lamp-backend/app/providers/graph_renderer.py)) — plot spec → color JPEG |
| **rdkit** | 2D molecular-structure depiction (SMILES → color JPEG) for the chemistry page ([rdkit_renderer.py](Smart-Tutor-Lamp-backend/app/providers/rdkit_renderer.py)); only used when `CHEM_STRUCTURE_ENABLED`, no-op if absent — [requirements.txt:27-30](Smart-Tutor-Lamp-backend/requirements.txt#L27) |
| **numpy / Pillow** | image buffers + the PIL fallback enhancement pipeline; Pillow also composes the scrollable-document blocks ([document.py](Smart-Tutor-Lamp-backend/app/providers/document.py)) |
| **opencv-python-headless** | full camera rectifier (page detect, perspective warp, paper-mask bleach, CLAHE+unsharp) — [pyproject.toml:19-22](Smart-Tutor-Lamp-backend/pyproject.toml#L19) |
| **httpx** | streaming HTTP for the Cartesia TTS provider (`POST /tts/bytes`) — pinned in [requirements.txt:17-20](Smart-Tutor-Lamp-backend/requirements.txt#L17) |

### 2.3 LLM provider SDKs (optional extras)

From [pyproject.toml:30-34](Smart-Tutor-Lamp-backend/pyproject.toml#L30):

- `gemini` → `google-genai` (the reference, default provider — audio+image+text in one call)
- `openai` → `openai`
- `claude` → `anthropic` + `groq` (Groq Whisper supplies upstream STT for providers that can't take raw audio)
- `deepseek` → `openai` (talks to DeepSeek's OpenAI-compatible API) + `groq`

[requirements.txt:35](Smart-Tutor-Lamp-backend/requirements.txt#L35) pins **`aiohttp>=3.13.5,<4.0`** — google-genai's async client uses aiohttp, and versions `<3.13.5` reject `StreamReader.readline(max_line_length=…)` (googleapis/python-genai#2487), which is what makes Gemini streaming (`GEMINI_TTS_STREAM` / `GEMINI_USE_STREAM`) usable.

### 2.4 Persistence, cache, auth

| Library | Role |
|---|---|
| **sqlalchemy[asyncio] >= 2.0** + **asyncpg >= 0.29** + **greenlet** | Async Postgres engine ([db/session.py](Smart-Tutor-Lamp-backend/app/db/session.py)). Must be SQLAlchemy ≥ 2.0 — the async engine lives in `sqlalchemy.ext.asyncio` |
| **redis[hiredis]** | Optional L1 session-memory + active-session cache + revocation pub/sub |
| **aioboto3** | S3/R2/Supabase-Storage blob backend |
| **clerk-backend-api** | HTTP Clerk session-token verify ([deps/clerk.py](Smart-Tutor-Lamp-backend/app/deps/clerk.py)) |
| **pyjwt[crypto]** | WS-only Clerk token verify via JWKS ([deps/clerk_ws.py](Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py)) |
| **svix** | Clerk webhook signature verification (user.deleted cascade) |
| **python-jose[cryptography]** | device_jwt HS256 sign/verify |
| **argon2-cffi** | device-secret hashing for pairing |
| **slowapi** | FastAPI rate-limit decorators ([main.py:21-22](Smart-Tutor-Lamp-backend/app/main.py#L21)) |
| **nanoid** | 6-char pairing-code generator |
| **python-multipart** | FastAPI Form/File parsing for `POST /api/frontend/simulate` |

### 2.5 TTS engines

| Library | Role |
|---|---|
| **piper-tts >= 1.2.0** | Self-hosted CPU voice — provides both the importable `piper` module (warm `library` mode) AND the `piper` CLI (`subprocess` mode) |
| **audioop-lts >= 0.2.1** (Py≥3.13) | Resample Piper → 24 kHz and IMA/DVI ADPCM wire codec (stdlib `audioop` removed in 3.13) |
| **opuslib >= 3.0.1** | Optional Opus wire codec (also needs a system libopus) |

> Note: `cartesia` is now a **live** TTS provider (Cartesia Sonic, `POST /tts/bytes`, continuous audio — see [06-tts-and-media.md](06-tts-and-media.md) §3.4); only `kokoro_local` remains a reserved/placeholder provider that yields a silent/visual-only turn.

The wire contract is identical for every TTS provider: **24 kHz mono int16 LE PCM, ≤ 4 KB chunks** ([tts_base.py:32-37](Smart-Tutor-Lamp-backend/app/providers/tts_base.py#L32)).

---

## 3. Layered Architecture

The codebase is organized as a strict **routes → services → providers → storage** layering, with the layer numbers from `BACKEND_TODO.md` echoed in nearly every module docstring. The directory layout under [`app/`](Smart-Tutor-Lamp-backend/app):

```
app/
  main.py            # Layer 0 — FastAPI app, middleware, exception handlers, route wiring, lifespan
  startup.py         # Boot self-tests (LLM key present + LaTeX renderer works)
  config.py          # Layer 0 — pydantic-settings, the single source of all env config
  logging.py         # Central logging config (verbose-by-default knobs)
  protocol.py        # Layer 1.1 — frame type enum + encode/decode + wire-size constants
  session.py         # Layer 1.3/1.5 + 2 — per-WS Session state, frame ingest, TX helpers
  routes/            # ENTRYPOINTS (HTTP + WS)
    ws_lamp.py       #   /lamp/ws — the lamp WebSocket (Layer 1.2)
    health.py        #   /healthz (liveness) + /readyz (readiness)
    device_lamp.py, device_user.py, pairing_info.py, clerk_webhook.py,
    frontend_manager.py, admin.py   # auth/pairing/web-bench/admin (ENABLE_AUTH only)
  services/          # ORCHESTRATION LOGIC
    orchestrator.py  #   Layer 8 — the turn pipeline (the heart)
    dispatch.py      #   Layer 5.3 — reply → outbound frames
    escalation_router.py, problem_memo.py, session_memory.py, memory.py,
    image_prep.py, turn_trace.py, model_solver.py, ... (and more)
  providers/         # EXTERNAL SERVICE ADAPTERS (one SDK per file)
    llm_base.py      #   Layer 4 — abstract LlmProvider + factory
    llm_gemini.py, llm_openai.py, llm_claude.py, llm_deepseek.py
    tts_base.py      #   Layer 7 — abstract TtsProvider + factory
    tts_gemini.py, tts_piper.py, tts_cartesia.py
    image_preprocessor.py, latex_engine.py, latex_renderer.py, grounding.py
  schemas/           # PYDANTIC MODELS (llm_response, frontend, auth, admin, model_eval)
  prompts/           # System-prompt assembly (turn1/turn2, classifier, latex rules)
  db/                # SQLAlchemy engine (session.py) + ORM models (models.py)
  storage/           # Durable writers (turns, blobs, events, memory_vec, model_eval, ...)
  deps/              # FastAPI dependencies (clerk, device_auth, rate_limit, admin)
  workers/           # Background jobs (embed, rollup, transcribe)
  formatting/        # tft_formatter, track_router
```

The dependency direction is one-way and enforced by **lazy local imports** at call sites (heavily used so that the no-DB / no-auth / no-TTS paths boot without optional packages installed). Examples:
- [main.py:80](Smart-Tutor-Lamp-backend/app/main.py#L80) imports `app.db.session.init_db` inside a `try` so a missing/old SQLAlchemy degrades gracefully.
- [session.py:362](Smart-Tutor-Lamp-backend/app/session.py#L362) imports `app.services.image_prep` inside `_on_image_terminator` to avoid a module-load cycle.
- [session.py:464](Smart-Tutor-Lamp-backend/app/session.py#L464) imports `app.services.orchestrator.get_orchestrator` inside `_on_audio_end`.

### 3.1 The four tiers, conceptually

```mermaid
flowchart TD
    subgraph EDGE["ESP32-S3 LAMP"]
      MIC[Mic INMP441] --> WS
      CAM[OV5640 cam] --> WS
      TFT[TFT ILI9341 + LED]
      SPK[Speaker MAX98357A]
    end
    WS[Persistent binary WebSocket TLS]

    subgraph ROUTES["ROUTES (entrypoints)"]
      WSLAMP[ws_lamp.lamp_ws]
      HEALTH[health.healthz / readyz]
      FE[frontend_manager / admin / pairing]
    end

    subgraph SVC["SERVICES (orchestration)"]
      SESS[session.Session]
      ORCH[orchestrator.TurnOrchestrator]
      PRE[escalation_router.preroute]
      DISP[dispatch.dispatch_reply]
      MEMO[problem_memo]
      MEM[session_memory]
    end

    subgraph PROV["PROVIDERS (adapters)"]
      LLM[llm_base get_llm_provider]
      TTS[tts_base get_tts_provider]
      IMG[image_preprocessor]
      LATEX[latex_engine.LatexRenderer]
    end

    subgraph STORE["STORAGE"]
      PG[(Supabase Postgres + pgvector)]
      REDIS[(Redis - optional)]
      BLOB[(S3 / R2 / local blobs)]
    end

    WS <--> WSLAMP
    WSLAMP --> SESS --> ORCH
    ORCH --> PRE
    ORCH --> LLM
    ORCH --> MEMO
    ORCH --> MEM
    ORCH --> DISP
    DISP --> TTS
    DISP --> LATEX
    ORCH --> IMG
    ORCH --> STORE
    MEM --> PG
    MEM --> REDIS
    DISP -- AUDIO_OUT / TFT frames --> WS --> SPK
    WS --> TFT
```

---

## 4. Application Bootstrapping & Startup

### 4.1 Import-time

[main.py:33-34](Smart-Tutor-Lamp-backend/app/main.py#L33) calls `configure_logging()` **first**, before any other import-time work, so even import-time logs are captured. The `lumos` logger is bound at module level.

The FastAPI app object is created at [main.py:138](Smart-Tutor-Lamp-backend/app/main.py#L138):

```python
app = FastAPI(title="Lumos Backend", version="0.0.1", lifespan=lifespan)
```

### 4.2 Middleware & exception handlers (registered at import time)

In order:

1. **slowapi limiter** — `app.state.limiter = limiter` and the 429 handler `_rate_limit_exceeded_handler` ([main.py:141-142](Smart-Tutor-Lamp-backend/app/main.py#L141)).
2. **`RequestValidationError` handler** ([main.py:153-156](Smart-Tutor-Lamp-backend/app/main.py#L153)) — logs the exact failing field(s) at WARNING (`[422] …`) and returns the standard 422 body. FastAPI normally logs nothing on a 422, which makes body-shape mismatches hard to diagnose server-side.
3. **Catch-all `Exception` handler** ([main.py:164-171](Smart-Tutor-Lamp-backend/app/main.py#L164)) — fires only for *unhandled* exceptions (HTTPException keeps its own handler). Dumps a full traceback via `log.exception` and returns a clean `{"error": "internal server error", "code": "INTERNAL_ERROR"}` envelope (never a raw stacktrace over the wire).
4. **HTTP tracer middleware** `_trace_requests` ([main.py:179-200](Smart-Tutor-Lamp-backend/app/main.py#L179)) — times every request with `time.perf_counter()`. Log level chosen by status: `>=500` → ERROR, `>=400` → WARNING, else INFO if `LOG_ALL_REQUESTS` else DEBUG. An exception bubbling out of the route is logged here with `[REQ-FAIL] … raised after N ms` before re-raising.
5. **CORS** ([main.py:219-229](Smart-Tutor-Lamp-backend/app/main.py#L219)) — exact-match `allow_origins` from `CORS_ALLOWED_ORIGINS`, plus a regex `^https?://(localhost|127\.0\.0\.1)(:\d+)?$` so any localhost/127.0.0.1 port works in dev (the browser's Origin must match byte-for-byte). `allow_credentials=True`; methods GET/POST/PUT/DELETE/OPTIONS; headers include `Authorization`, `Content-Type`, and the three `svix-*` webhook headers. The lamp is server-to-server and ignores CORS.
6. **GZip** (`GZipMiddleware`, `minimum_size=500`) ([main.py:282](Smart-Tutor-Lamp-backend/app/main.py#L282), added 2026-07-10) — compresses the large, highly-compressible admin/analytics JSON payloads (`list_turns` up to 200 rows, overview / model_stats / the new `/admin/analytics/*` aggregates) that previously shipped uncompressed; bodies under 500 B skip it. Registered **after** CORS so it is the outermost layer (compresses the final body, preserves CORS headers). HTTP-only — WebSocket connections (the lamp's `/lamp/ws`) bypass ASGI HTTP middleware, so the TTS wire-codec audio is never double-compressed.

### 4.3 Route wiring

Always mounted: `health_router` and `ws_router` ([main.py:233-234](Smart-Tutor-Lamp-backend/app/main.py#L233)).

If `STORAGE_BACKEND == "local"` ([main.py:241-253](Smart-Tutor-Lamp-backend/app/main.py#L241)), `/blobs` is mounted as a `StaticFiles` directory (so the admin trace view can play turn audio + compare raw/enhanced images locally without S3). Filenames are UUID-derived (`turn-<uuid>.wav` / `trace-<uuid>-*.jpg`) — unguessable.

If `ENABLE_AUTH` ([main.py:258-272](Smart-Tutor-Lamp-backend/app/main.py#L258)) the auth surface is mounted: `device_lamp`, `device_user`, `pairing_info`, `clerk_webhook`, `frontend_manager`, `admin`. In dev they are left off so accidental calls 404 cleanly instead of 503-ing because Clerk isn't configured.

### 4.4 The `lifespan` async context manager

[main.py:37-135](Smart-Tutor-Lamp-backend/app/main.py#L37). uvicorn enters this once on startup and exits on shutdown. Sequence:

1. Banner log with `ENABLE_AUTH` state.
2. **`await run_all_startup_checks()`** ([startup.py:93-98](Smart-Tutor-Lamp-backend/app/startup.py#L93)) — see §4.5.
3. **If `ENABLE_AUTH`**: fail-loud check that `DEVICE_JWT_SECRET`, `CLERK_SECRET_KEY`, `DATABASE_URL` are all set; raise `RuntimeError` if any is missing ([main.py:52-64](Smart-Tutor-Lamp-backend/app/main.py#L52)). `CLERK_WEBHOOK_SECRET` is deliberately *not* required (the webhook route self-guards with 503; revocation still works via per-connect + heartbeat checks) — only a WARNING is logged.
4. **If `DATABASE_URL`** ([main.py:75-101](Smart-Tutor-Lamp-backend/app/main.py#L75)): lazily import + `await init_db(create_tables=True)`, then best-effort `seed_providers()` for the model-comparison registry. On DB-init failure: if `ENABLE_AUTH` → re-raise (auth can't function without DB); else log and **continue stateless** (no session/turn persistence). With no `DATABASE_URL` at all → stateless mode logged.
5. **If `REDIS_URL`** ([main.py:107-110](Smart-Tutor-Lamp-backend/app/main.py#L107)): `await init_redis()` — powers revocation pub/sub (auth path) + short-term conversation history (Layer 3.2). Unset → both degrade gracefully.
6. **TTS warmup** ([main.py:114-124](Smart-Tutor-Lamp-backend/app/main.py#L114)): fetch the configured TTS provider; if it's available, `await tts.warmup()` so the first turn isn't slowed by a cold model load (~2 s). Best-effort + non-fatal (text/visual still works without audio).
7. `yield` — app serves.
8. **Shutdown** ([main.py:128-135](Smart-Tutor-Lamp-backend/app/main.py#L128)): `dispose_redis()` if Redis was set, `dispose_db()` if auth was on, final log.

### 4.5 Startup self-tests ([startup.py](Smart-Tutor-Lamp-backend/app/startup.py))

`run_all_startup_checks()` runs two checks **in order — LLM first (fast fail on missing keys), then LaTeX (slower matplotlib cold-start)**:

**`verify_llm_provider_configured()`** ([startup.py:41-64](Smart-Tutor-Lamp-backend/app/startup.py#L41)):
- Instantiate the configured provider via `get_llm_provider()`. On any exception → `sys.exit(2)`.
- Map provider name → required env var:
  `gemini→GEMINI_API_KEY`, `openai→OPENAI_API_KEY`, `claude→ANTHROPIC_API_KEY`, `deepseek→DEEPSEEK_API_KEY`.
- If that env var is unset → log error + `sys.exit(2)`.

**`verify_latex_renderer()`** ([startup.py:67-90](Smart-Tutor-Lamp-backend/app/startup.py#L67)):
- Import `LatexRenderer, DisplayConfig, Orientation` from `app.providers.latex_engine`. If not importable → WARNING (latex displays will fail at runtime) but **return** (does not block boot).
- Build a `LatexRenderer(DisplayConfig(orientation=Orientation.LANDSCAPE))` and render each of 6 representative `_LATEX_SAMPLES` ([startup.py:31-38](Smart-Tutor-Lamp-backend/app/startup.py#L31)):
  `e^{i\pi}+1=0`, the quadratic formula, the Gaussian integral, Maxwell's curl-E law, Bayes' theorem, and the time-dependent Schrödinger equation.
- If any render returns 0 bytes or raises → log error (matplotlib mathtext subset may have drifted; check `app/prompts/_latex_rules.py`) and `sys.exit(3)`.

Both checks raise `SystemExit` so uvicorn refuses to come up and CI/Docker healthchecks see the non-zero exit.

---

## 5. Configuration & Environment Variables

All config flows through `Settings` ([config.py:28-753](Smart-Tutor-Lamp-backend/app/config.py#L28)), a `pydantic_settings.BaseSettings` with `model_config = SettingsConfigDict(env_file=".env", extra="ignore")`. Critically, [config.py:25](Smart-Tutor-Lamp-backend/app/config.py#L25) calls `load_dotenv(override=False)` **before** pydantic reads anything — because pydantic-settings does *not* sync into `os.environ`, and several provider modules + the startup self-test use `os.getenv`. `override=False` gives standard 12-factor precedence (a real shell env var beats a `.env` entry). The singleton `settings = Settings()` is at [config.py:753](Smart-Tutor-Lamp-backend/app/config.py#L753); everywhere else does `from app.config import settings`.

### 5.1 LLM selection & timeouts

| Var | Default | Effect |
|---|---|---|
| `LLM_PROVIDER` | `gemini` | One of `gemini\|openai\|claude\|deepseek`. Swap brain with one line |
| `GEMINI_API_KEY` / `GEMINI_MODEL` | `""` / `gemini-3.1-flash-lite` | Default brain |
| `OPENAI_API_KEY` / `OPENAI_MODEL` | `""` / `gpt-4o` | |
| `ANTHROPIC_API_KEY` / `ANTHROPIC_MODEL` | `""` / `claude-sonnet-4-6` | |
| `DEEPSEEK_API_KEY` / `DEEPSEEK_MODEL` / `DEEPSEEK_BASE_URL` | `""` / `deepseek-chat` / `https://api.deepseek.com` | |
| `GROQ_API_KEY` | `""` | Upstream Whisper STT for providers that can't take raw audio + pre-router fast STT |
| `CLAUDE_TIMEOUT_FALLBACK` | `True` | When primary=Gemini and a tier hits a SERVER failure (timeout/429/5xx), re-run the same turn on Claude ([config.py:43-51](Smart-Tutor-Lamp-backend/app/config.py#L43)) |
| `GEMINI_TEMPERATURE` | `1.0` | Lamp Gemini sampling temp (Gemini scale 0.0–2.0); restored to `1.0` to match production (see doc 13) |
| `CLAUDE_TEMPERATURE` | `0.3` | Claude sampling temp (Claude scale 0.0–1.0; tuned low for math) |

Provider-level constants live in [llm_base.py:38-66](Smart-Tutor-Lamp-backend/app/providers/llm_base.py#L38):
- `LLM_HARD_TIMEOUT_S = 20.0` — any call > 20 s falls back (bumped from 12 s after free-tier Gemini Flash hit it on India→US-Central multimodal calls; realistic p95 is 12–15 s).
- `LLM_MAX_OUTPUT_TOKENS = 900` — provider-level default output cap (overridden per-tier for the lamp).

### 5.2 Two-tier (and tier-3) "thinking" dispatch

These constants ARE the escalation algorithm's parameters ([config.py:406-510](Smart-Tutor-Lamp-backend/app/config.py#L406)):

| Var | Default | Effect |
|---|---|---|
| `GEMINI_DYNAMIC_THINKING` | `True` | Enable two-tier flow; off → single-tier with `GEMINI_THINKING_BUDGET` (default `0`) |
| `GEMINI_TIER1_THINKING_BUDGET` | `0` | Fast tier — no thinking |
| `GEMINI_TIER1_MAX_OUTPUT_TOK` | `1200` | Tier-1 output ceiling (raised from 600 after equation-heavy JSON truncated at 590) |
| `GEMINI_TIER2_THINKING_BUDGET` | `1024` | Deep tier — high reasoning (`>=1024` maps to `thinking_level=high`) |
| `GEMINI_TIER2_MAX_OUTPUT_TOK` | `4000` | Tier-2 ceiling (raised after a thinking spike starved a tier-2 reply) |
| `GEMINI_ESCALATE_CONFIDENCE` | `0.45` | Reply confidence below this → escalate |
| `GEMINI_TIER3_ENABLED` | `True` | Build a second Gemini-Pro provider; escalate hard/low-conf turns to it |
| `GEMINI_TIER3_MODEL` | `gemini-3.1-pro-preview` | The Pro model |
| `GEMINI_TIER3_THINKING_BUDGET` | `512` | Lowered from 1024 so 3.x maps to `thinking_level=medium` (high timed out) |
| `GEMINI_TIER3_MAX_OUTPUT_TOK` | `10000` | Tier-3 ceiling (raised after a 4798-thinking-token escalation truncated) |
| `GEMINI_TIER3_CODE_EXECUTION` | `True` | Built-in Python sandbox on Gemini-3.x Pro calls (compute numerics instead of hallucinating) |
| `GEMINI_TIER3_TIMEOUT_S` | `38.0` | Per-call hard timeout for the Pro call only (must stay ≤ ~38 s vs the lamp's 45 s `THINKING_TIMEOUT_MS`) |

The numeric thinking budgets are mapped to Gemini-3.x string `thinking_level` enums by `gemini_thinking_config()` ([llm_base.py:69-102](Smart-Tutor-Lamp-backend/app/providers/llm_base.py#L69)): `<=0→"minimal"`, `<512→"low"`, `<1024→"medium"`, `>=1024→"high"`. (Gemini 2.5 keeps the numeric `thinkingBudget`; setting both fields on a 3.x call is a 400 error.)

### 5.3 Pre-router (deterministic gate)

[config.py:595-630](Smart-Tutor-Lamp-backend/app/config.py#L595):

| Var | Default | Effect |
|---|---|---|
| `PREROUTE_ENABLED` | `True` | Run the deterministic router before tier-1 |
| `PREROUTE_STT_ENABLED` | `True` | Fast Groq-Whisper pre-STT (~200 ms) for keyword routing, in parallel with image enhance |
| `PREROUTE_IMAGE_QUALITY_GATE` | `True` | Reject egregiously bad frames → "retake photo" with zero LLM spend |
| `PREROUTE_BLUR_MIN` | `30.0` | Variance-of-Laplacian floor (below = near-flat/blurry) |
| `PREROUTE_MIN_DIM_PX` | `240` | Min image short side in px |
| `PREROUTE_LUMA_MIN` | `22.0` | Mean brightness floor (below = near-black; no too-bright ceiling) |

### 5.4 TTS configuration

| Var | Default | Effect |
|---|---|---|
| `TTS_PROVIDER` | `cartesia` | `gemini\|piper\|cartesia\|kokoro_local` — governs the **lamp** audio leg only |
| `FRONTEND_TTS_PROVIDER` | `piper` | `piper\|none` — web bench TTS; type *excludes* gemini so the browser can never spend Gemini audio tokens ([config.py:74-82](Smart-Tutor-Lamp-backend/app/config.py#L74)) |
| `GEMINI_TTS_MODEL` / `GEMINI_TTS_VOICE` | `gemini-2.5-flash-preview-tts` / `Aoede` | |
| `GEMINI_TTS_STREAM` | `False` | When true, streams audio chunks as generated (1 request/turn + low first-audio latency); default is now unary (whole-utterance synth) |
| `GEMINI_TTS_STYLE` | `"calm, clear, and matter-of-fact. Speak at a steady, natural pace with an intelligent and helpful tone, avoiding any exaggerated enthusiasm"` | Natural-language tone/pace directive |
| `TTS_MAX_INPUT_CHARS` | `800` | Hard char cap to TTS per call (cost guard); 0 = no cap |
| `TTS_CHUNK_MODE` | `balanced` | `full\|hybrid\|single\|balanced` — chunking strategy when `GEMINI_TTS_STREAM=false` |
| `TTS_ENABLED` | `True` | Piper master toggle |
| `PIPER_MODE` | `library` | `library` (warm, ~0.2 s) vs `subprocess` (cold, ~2.5 s) |
| `PIPER_BIN` / `PIPER_MODEL` / `PIPER_CONFIG` | `piper` / `audio-tts/en_US-amy-medium.onnx` / `""` | Ships the bundled amy-medium voice by default; empty model disables Piper |
| `PIPER_SAMPLE_RATE` / `TTS_TARGET_SAMPLE_RATE` | `22050` / `24000` | Voice native rate → AUDIO_OUT contract rate |
| `TTS_CHUNK_BYTES` | `4096` | 85 ms @ 24 kHz int16 mono |
| `PIPER_SPEED`/`PIPER_NOISE_SCALE`/`PIPER_NOISE_W`/`PIPER_SENTENCE_SILENCE`/`PIPER_SPEAKER` | `0.95`/`0.667`/`0.8`/`0.35`/`-1` | Delivery tuning → Piper CLI flags |
| `TTS_WIRE_CODEC` | `opus` | `pcm\|adpcm\|opus` — wire encoding (degrades opus→adpcm→pcm) |
| `TTS_OPUS_BITRATE` / `OPUS_LIB_PATH` | `32000` / `""` | |

### 5.5 Storage, memory, image prep, debug

| Var | Default | Effect |
|---|---|---|
| `DATABASE_URL` / `DATABASE_SSL` | `""` / `""` (AUTO) | Postgres DSN; AUTO requires TLS for `*.supabase.co`/`*.pooler.supabase.com` |
| `REDIS_URL` | `""` | Single switch for all caching/acceleration |
| `STORAGE_BACKEND` | `local` | `off\|local\|s3\|r2` per-turn blob persistence |
| `STORAGE_LOCAL_DIR` / `STORAGE_PUBLIC_BASE_URL` | `./turn_blobs` / `""` | |
| `S3_BUCKET`/`S3_REGION`/`S3_ENDPOINT_URL`/`S3_ACCESS_KEY`/`S3_SECRET_KEY` | `""` | S3/R2/Supabase Storage |
| `DEV_CAPTURE_DUMP` / `DEV_CAPTURE_DIR` | `False` / `./turn_captures` | Per-turn debug folder (audio + every image stage + LLM JSON) |
| `TURN_TRACE_ENABLED` | `True` | Verbose `turn_traces` row per turn for the admin storyboard (passive, fire-and-forget) |
| `ENABLE_MEMORY` | `True` | L1+L2+L3 conversational memory master toggle |
| `MEMORY_COMPACT_THRESHOLD` | `8` | Turns before older turns are LLM-compacted into `sessions.summary` (L2) |
| `MEMORY_TAIL_SIZE` | `3` | Most-recent turns kept verbatim in the prompt (L1 tail) |
| `MEMORY_SESSION_IDLE_MIN` | `30` | Idle gap (min) before a fresh session starts |
| `ENABLE_MEMORY_COMPACTION` | `True` | Run the async L2 compaction LLM call |
| `ENABLE_IMAGE_ENHANCEMENT` | `True` | OpenCV/PIL clean before the VLM |
| `LAMP_IMAGE_UNMIRROR` | `False` | Left-right flip lamp JPEGs (lamp arrives upright; default off) |
| `IMAGE_PREP_EARLY` / `GEMINI_FILES_PREUPLOAD` | `True` / `True` | Enhance + pre-upload each image to Gemini Files API as it arrives (saves ~250-400 ms/turn) |
| `EMIT_DEBUG_JSON` | `True` | Echo the parsed `LlmReply` JSON as a `DEBUG_JSON` (0x40) WS frame |
| `DEBUG_PERCEIVED_QUESTION` | `False` | Force `problem_statement` transcription every turn + log `[PERCEIVED Q]` |

### 5.6 Nudge gate / guards / logging

| Var | Default | Effect |
|---|---|---|
| `SOLVE_MIN_NUDGES` | `1` | Nudges before a hard surrender ("just answer me") reveals the solution |
| `SOLVE_NUDGE_THRESHOLD` | `2` | Nudges before inferred-frustration reveal *(lowered 3 → 2, 2026-06-22)* |
| `SOLVE_REVEAL_MAX_OUTPUT_TOK` | `2500` | Output cap for solve-authorized reveal turns |
| `DISPUTE_GUARD` | `True` | Student says answer is wrong → fresh independent Pro re-derivation |
| `CHECK_VERDICT_GUARD` | `True` | Student asks to verify own work ("is my answer right?") → plain verdict, not a nudge (never reveals the solution) |
| `SEMANTIC_CHECK_ESCALATION` | `True` | Model self-tags query_type=check/mistake_id → floor at tier-2 |
| `MEMO_CONSISTENCY_REFUSE` / `MEMO_CAPTURE_QUESTION` | `False` / `False` | Memo answer↔path consistency; always-on question capture |
| `TFT_SHOW_MODEL_TAG` | `True` | Append `[model tN]` to the TFT card so the tier is visible on-device |
| `TFT_PROGRESSIVE_EQUATIONS` / `TFT_APPEND_EQUATIONS` | `True` / `True` | Progressive equation delivery; append-segment wire upgrade (flash firmware first) |
| `LATEX_PAYLOAD_CAP_BYTES` | `1_000_000` | Hard cap on one assembled TFT_FRAME payload |
| `LATEX_REDIS_CACHE` / `_TTL_S` / `_MAX_BYTES` | `True` / `3*24*3600` / `200_000` | Persistent LaTeX render cache in Redis |
| `LOG_LEVEL` | `INFO` | `DEBUG\|INFO\|WARNING\|ERROR` (flipped to production-safe 2026-06-11) |
| `SQL_ECHO` / `LOG_SQL_POOL` | `False` / `False` | Print SQL statements / pool events |
| `LOG_ALL_REQUESTS` | `True` | Log every request line, not just failures |

### 5.7 Auth & pairing

[config.py:293-332](Smart-Tutor-Lamp-backend/app/config.py#L293):

| Var | Default | Effect |
|---|---|---|
| `ENABLE_AUTH` | `False` | Master toggle. False = dev bypass (`dev-mode-no-auth` Bearer accepted) |
| `DEVICE_JWT_SECRET` / `DEVICE_JWT_ISS` | `""` / `lumos-auth` | HS256 lamp WS Bearer signing |
| `CLERK_SECRET_KEY` / `CLERK_WEBHOOK_SECRET` | `""` | Server-side Clerk verify + Svix webhook |
| `CLERK_PUBLISHABLE_KEY`/`CLERK_JWKS_URL`/`CLERK_ISSUER` | `""` | WS-path Clerk verify (browser `?token=`) |
| `FRONTEND_BASE_URL` | `http://localhost:3000` | URL embedded in the pairing QR (`{base}/pair/{6-char code}`) |
| `PAIRING_CODE_TTL_SEC` | `300` | 5-min pairing code TTL |
| `CORS_ALLOWED_ORIGINS` | `http://localhost:3000` | Comma-separated exact origins |
| `ADMIN_USER_IDS` / `ADMIN_EMAILS` | `""` | **Deprecated/ignored** — admin is now governed solely by the `admins` Postgres table |

---

## 6. Logging Subsystem

`configure_logging()` ([logging.py:31-96](Smart-Tutor-Lamp-backend/app/logging.py#L31)) is idempotent (safe under `--reload`; resets root handlers each call to avoid double-print). Mechanics:

- Level from `settings.LOG_LEVEL` (fallback INFO if empty/typo'd — an empty value must not silently enable the DEBUG firehose). `verbose = level <= DEBUG`.
- Forces `sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")` because Windows cp1252 can't encode the `→ ✓ ─` glyphs (UnicodeEncodeError would drop the line). Best-effort.
- Format: in DEBUG, appends `[filename:lineno]` so an error is one click from the line; in INFO+ keeps it compact.
- Single `StreamHandler(sys.stdout)` on the root; `app` and `lumos` loggers set to the same level.
- SQLAlchemy: `sqlalchemy.engine`/`.dialects` → INFO if `SQL_ECHO` else WARNING; `sqlalchemy.pool` → DEBUG if `LOG_SQL_POOL` else WARNING; `asyncpg` → level.
- Third-party HTTP: `httpx` → INFO (useful — Clerk JWKS/Gemini/Supabase calls); `httpcore` → DEBUG only when verbose (byte-level noise otherwise).

Combined with the middleware/handlers in `main.py`, every error is printed with a full traceback — the stated whole point.

---

## 7. The Wire Protocol

[protocol.py](Smart-Tutor-Lamp-backend/app/protocol.py) matches `HARDWARE_CONTEXT.md §4–§6` exactly.

**Wire format:** `[u8 type][u24 length BE][payload]` — a 4-byte outer header. `encode()` ([protocol.py:130-142](Smart-Tutor-Lamp-backend/app/protocol.py#L130)) packs type + 3 big-endian length bytes; `decode()` ([protocol.py:145-156](Smart-Tutor-Lamp-backend/app/protocol.py#L145)) validates `4 + n == len(buf)` and raises `ValueError` on a short frame or length mismatch.

**Hard rule:** every WS message ≤ ~4 KB in both directions — the lamp's ArduinoWebsockets library `bad_alloc`s on any single received message above its DRAM headroom and reboots. Enforced by `WS_HARD_MAX_BYTES = 4*1024` ([protocol.py:121](Smart-Tutor-Lamp-backend/app/protocol.py#L121)). Larger payloads MUST use the chunked protocols.

Wire-size constants ([protocol.py:121-124](Smart-Tutor-Lamp-backend/app/protocol.py#L121)):
- `WS_HARD_MAX_BYTES = 4096` — absolute ceiling; `Session.send_frame` refuses anything larger.
- `WS_MAX_FRAME_BYTES = 2048` — TFT chunker slice size (well under the ceiling, safe under heap fragmentation).
- `AUDIO_OUT_CHUNK_BYTES = 4096` (2048 int16 samples @ 24 kHz = 85.3 ms) and `AUDIO_OUT_PACE_S = 0.085` — exactly matches the lamp's 64 KB speaker ring drain rate.

**Frame types** (`FrameType(IntEnum)` [protocol.py:16-86](Smart-Tutor-Lamp-backend/app/protocol.py#L16)):

| Direction | Type | Hex | Meaning |
|---|---|---|---|
| Lamp→backend | `IMAGE_JPEG` | 0x01 | terminator for chunked image (or whole small image) |
| | `AUDIO_CHUNK` | 0x02 | int16 LE 16 kHz mono mic, 640 B / ~20 ms |
| | `AUDIO_END` | 0x03 | empty — **fires the LLM call** |
| | `CANCEL` | 0x04 | empty — user pressed Select |
| | `IMAGE_PART` | 0x05 | intermediate chunk of a chunked image |
| | `AUDIO_CHUNK_ADPCM` | 0x06 | uplink IMA/DVI ADPCM mic (4:1 = 8 KB/s vs 32 KB/s) |
| | `AUDIO_RESET` | 0x07 | lamp lost uplink chunks → discard streamed audio, full utterance follows |
| Backend→lamp | `AUDIO_OUT` | 0x10 | int16 LE 24 kHz TTS, 4 KB / 85 ms |
| | `AUDIO_OUT_END` | 0x11 | empty — **REQUIRED**, releases I2S back to mic |
| | `AUDIO_OUT_ADPCM` | 0x12 | ADPCM TTS (12 KB/s wire) |
| | `AUDIO_OUT_OPUS` | 0x13 | one Opus packet/frame (~4 KB/s) |
| | `TFT_FRAME` | 0x20 | terminator for chunked TFT frame (commits to LATEX page) |
| | `TFT_TEXT` | 0x21 | UTF-8 text card |
| | `TFT_CLEAR` | 0x22 | empty |
| | `TFT_PART` | 0x23 | intermediate TFT chunk ≤ 2 KB |
| | `TFT_LATEX_LOADING` | 0x24 | empty — show "rendering equation…" skeleton |
| | `TFT_APPEND` / `TFT_APPEND_BEGIN` | 0x25 / 0x26 | append-segment wire upgrade |
| | `STATE` | 0x30 | 1-byte enum |
| | `DEBUG_JSON` | 0x40 | dev echo of parsed `LlmReply` (real lamp drops it on `default:`) |
| Web-only | `TEXT_IN`/`TEXT_OUT`/`TEXT_OUT_END` | 0x50/0x51/0x52 | browser bench text channel |

**`StateByte`** ([protocol.py:89-96](Smart-Tutor-Lamp-backend/app/protocol.py#L89)): `IDLE=0x00`, `LISTENING=0x01`, `THINKING=0x02`, `SPEAKING=0x03`, `ERROR=0x04`, `UNPAIRED=0x05`.

---

## 8. Session State & Frame Handling

[session.py](Smart-Tutor-Lamp-backend/app/session.py) implements Layers 1.3/1.5 + 2: per-WebSocket state, frame ingest, and all TX helpers. One `Session` per connected lamp.

### 8.1 The `Turn` dataclass ([session.py:159-192](Smart-Tutor-Lamp-backend/app/session.py#L159))

Per-turn input buffer, reset on `AUDIO_END` handoff and on `CANCEL`. Fields:

| Field | Type | Meaning |
|---|---|---|
| `images` | `list[bytes]` | completed JPEGs this turn (1..`MAX_IMAGES_PER_TURN`) |
| `image_accum` | `bytearray` | in-flight image being assembled |
| `audio_pcm` | `bytearray` | accumulated 16 kHz mic PCM |
| `started_at` | `float` | monotonic creation time (includes idle) |
| `first_frame_at` | `float \| None` | monotonic time of first media frame (capture-latency anchor) |
| `audio_chunks` | `int` | count of audio chunks |
| `image_preps` | `list[asyncio.Task]` | early enhance + Files pre-upload tasks, 1:1 with `images` |
| `adpcm_rx_state` | `tuple \| None` | uplink ADPCM decoder state, continuous per turn |
| `duration_s` (property) | `float` | `len(audio_pcm) / _AUDIO_BYTES_PER_S` |

Ingest gates/constants ([session.py:147-156](Smart-Tutor-Lamp-backend/app/session.py#L147)): `_MAX_IMAGE_BYTES = 256*1024` (matches firmware TX assemble ceiling), `MAX_IMAGES_PER_TURN = 5`, `_MIN_AUDIO_S = 0.5`, `_MAX_AUDIO_S = 30.0`, `_AUDIO_BYTES_PER_S = 16_000 * 2`.

### 8.2 The `Session` class ([session.py:195-985](Smart-Tutor-Lamp-backend/app/session.py#L195))

State: `device_id`, `user_id` (Clerk ID from device_jwt; None in dev), `db_session_id` (DB sessions-row UUID), `ws`, `current_turn`, `tasks` dict, an `asyncio.Lock` `_send_lock` serialising all wire writes (Starlette's WebSocket is not safe for concurrent writes), TX counters, `_closed` flag, `last_activity` monotonic timestamp, and ADPCM/Opus encoder states for the downlink wire codec.

**Inbound dispatch — `on_frame(type_, payload)`** ([session.py:245-278](Smart-Tutor-Lamp-backend/app/session.py#L245)): bumps `last_activity`, stamps `first_frame_at` on the first media frame, then routes by frame type to `_on_image_part`, `_on_image_terminator`, `_on_audio_chunk`, `_on_audio_chunk_adpcm`, `AUDIO_RESET` handling, `_on_audio_end`, or `_on_cancel`. Unknown types log a warning and are dropped.

Key ingest mechanics:
- `_on_image_terminator` ([session.py:295-366](Smart-Tutor-Lamp-backend/app/session.py#L295)) validates the **JPEG magic** (SOI `\xff\xd8` at start; EOI `\xff\xd9` within the last 64 bytes) to drop partial/corrupt images, enforces `_MAX_IMAGE_BYTES` and `MAX_IMAGES_PER_TURN` (drops the image without flipping STATE(error) — the turn proceeds audio-only/with other images), and on success kicks off `prep_image()` early prep if `early_prep_enabled()`.
- `_on_audio_chunk_adpcm` decodes ADPCM into the same `Turn.audio_pcm` so everything downstream sees plain 16 kHz PCM. If `audioop` is missing (Py≥3.13 without `audioop-lts`), it warns once and discards.
- **`_on_audio_end`** ([session.py:405-480](Smart-Tutor-Lamp-backend/app/session.py#L405)) is the handoff point: snapshots `images` + `audio_bytes`, immediately resets `current_turn` so the next utterance can start, **gates duration**: `< 0.5 s` → drop as a likely false wake (cancel preps, send STATE(idle)); `> 30 s` → truncate to the cap (whole int16 frames). It cancels any still-running previous turn task (bounded 2 s drain — the half-duplex invariant forbids overlap), computes `last_capture_ms`, then spawns `orchestrator.run_turn(...)` as a named task with a done-callback.

**Outbound helpers** all funnel through `send_frame` ([session.py:541-604](Smart-Tutor-Lamp-backend/app/session.py#L541)):
- No-op when `_closed`. **Hard guard**: payload > `WS_HARD_MAX_BYTES` raises `ValueError` (so the bug surfaces in the per-turn try/except, not as a silent lamp reboot).
- Wraps the actual `ws.send_bytes` in `asyncio.wait_for(..., timeout=_SEND_TIMEOUT_S=2.0)`; on timeout, marks closed + `ws.close(code=1011)` + re-raises.
- Specialized senders: `send_state`, `send_tft_text` (UTF-8 ≤ `TFT_TEXT_MAX_BYTES=1900`, word-boundary + UTF-8-safe truncation), `send_tft_clear`, `send_tft_latex_loading`, `send_audio_out_chunk` (the wire-codec chokepoint — encodes PCM→opus/adpcm/pcm here), `stream_audio_out` (paced + chunked from a full blob), `stream_audio_out_iter` (paced from a live async source — the low-latency TTS path), `send_audio_out_end` (flushes opus tail, resets codec state), `send_tft_frame_chunked`, `send_tft_frame_append`, and `finalize_turn` (the REQUIRED `AUDIO_OUT_END` + `STATE(idle)` pair).

**Prime-burst pacing**: `_TTS_PRIME_CHUNKS = 12` ([session.py:141](Smart-Tutor-Lamp-backend/app/session.py#L141)) — the first 12 × 4 KB = 48 KB chunks ship back-to-back unpaced to fill the lamp's ~1 s pre-roll jitter buffer fast (low time-to-first-audio), then the rest pace at `AUDIO_OUT_PACE_S` to match the ring drain rate. `stream_audio_out_iter` applies natural back-pressure: while it sleeps between sends it stops pulling from the TTS generator, so Piper blocks on its stdout pipe and memory stays bounded.

---

## 9. The Turn Orchestrator

[orchestrator.py](Smart-Tutor-Lamp-backend/app/services/orchestrator.py) is Layer 8 — the heart of the backend. `TurnOrchestrator` is a **process-singleton** (`get_orchestrator()` [orchestrator.py:1570-1577](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1570)) so the LLM provider's HTTP/2 client + system prompt are built once at boot.

### 9.1 Construction ([orchestrator.py:43-84](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L43))

- `_turn1_prompt = get_turn1_prompt()` — static system prompt fetched once.
- `_llm = get_llm_provider()` — the configured primary.
- `_llm_pro` — a second provider instance pinned to `GEMINI_TIER3_MODEL`, built only when `GEMINI_TIER3_ENABLED` and primary is Gemini (else None → tier-3 requests clamp to tier-2).
- `_llm_fallback` — a cached Claude provider, built only when `CLAUDE_TIMEOUT_FALLBACK` is armed AND primary is Gemini (inert under full-swap; pure no-op when off).

### 9.2 `run_turn(...)` pipeline ([orchestrator.py:86-1074](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L86))

This is the complete control flow. A `TurnTracer` observes every phase passively (swallows its own errors; never alters flow). Steps:

1. **STATE(thinking)** — lamp shows the spinner.
2. **Memory load** ([orchestrator.py:151-154](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L151)) — `_load_history()` pulls the full 3-layer context (L3 learner profile + L2 session summary + L1 recent verbatim turns) via `session_memory.load_context`, with a hard **2 s cap** → degrade to "[Session start — no prior turns]" rather than stall the turn.
3. **Pre-router STT** — if enabled + audio present, kicks off `_safe_preroute_stt` (Groq Whisper, hard 1.2 s cap) concurrently with image enhancement.
4. **Image prep harvest / enhancement** — either harvest the early-prep tasks (enhance + Gemini Files pre-upload that ran during speech, bounded 8 s) or run `enhance_for_llm` in parallel threads (`asyncio.gather` + `asyncio.to_thread`), falling back to raw bytes on any failure.
5. **Deterministic pre-router** ([orchestrator.py:277-343](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L277)) — `preroute(transcript, image_quality, n_images)` returns a `decision` with `start_tier`, `retake_image`, prompt suffixes, focus label, and verification flags. A blurry/dark/tiny photo with thin transcript short-circuits to `retake_image_reply` (ZERO LLM spend) and returns.
6. **Prompt augmentation** — appends perceived-question suffix, continuation hint (follow-up detection), problem-memo answer key / question context, nudge-gate SOLVE authorization, dispute note, check-verdict note (verify-request → plain verdict). Snapshots a `sans_key_prompt` (escalations never carry the answer key).
7. **Tier dispatch** — `_call_tier(start_tier, ...)` (§9.3).
8. **Echo guard / Focus guard** — deterministic re-call once if the reply duplicates an earlier turn (4-word shingle containment ≥ 0.5, [orchestrator.py:1481-1508](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1481)) or answered the wrong worksheet question.
9. **Memo identity & escalation** ([orchestrator.py:606-784](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L606)) — `_should_escalate(reply, telemetry)` (§9.4) decides a tier-2/3 re-call. Hard problems / truncation / near-zero confidence skip-tier-jump straight to Pro. The Flash→Pro **handoff brief** drops audio (already transcribed) and forwards the image only if `image_needed`. **Escalation-revert** (Fix B): if the escalated tier fails but the lower tier was OK, revert — escalation must never downgrade a good answer.
10. **Solution-bleed guard / Reveal-completeness guard** — deterministic re-calls if a Socratic answer leaked the full solution, or an authorized reveal omitted the final answer.
11. **Memo save** — any escalated solve (`solution_outline` present, tier≥2) persists the ground truth so later tier-1 nudges run against it.
12. **STATE(speaking)/STATE(error)** — error iff `telemetry.status not in (None,"ok")`.
13. **Dispatch** ([orchestrator.py:986-1006](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L986)) — `dispatch_reply(session, reply, status, model_tag, trace)` runs the parallel TTS + TFT legs (§10.3, [dispatch.py](Smart-Tutor-Lamp-backend/app/services/dispatch.py)).
14. **Fire-and-forget persist** — `asyncio.create_task(self._persist_turn(...))` (Postgres turn row + Redis L1 + blobs + trace finalize).
15. **`finally`** — always `session.finalize_turn()` (the half-duplex `AUDIO_OUT_END` + `STATE(idle)` pair) and `gc.collect()` to reclaim matplotlib/cv2/TTS buffers before the next turn.

Cancellation (`asyncio.CancelledError`) traces the cancel and re-raises; any other exception flips STATE(error) + "Sorry, I had trouble — try again." and still finalizes.

### 9.3 `_call_tier(...)` — the single LLM choke point ([orchestrator.py:1078-1196](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1078))

Every initial call, escalation re-call, and guard corrective re-call passes through here. It:
- Appends `problem_memo.SOLVE_SUFFIX` for any tier ≥ 2 (so escalations write the internal solution).
- Selects model + thinking budget + output cap by tier:
  - **Tier 1**: `_llm.call(thinking=TIER1_THINKING_BUDGET, cap=TIER1_MAX_OUTPUT_TOK)`.
  - **Tier 2**: `_llm.call(thinking=TIER2_THINKING_BUDGET, cap=max(cap_override, TIER2_MAX_OUTPUT_TOK))`.
  - **Tier 3** (if `_llm_pro`): `_llm_pro.call(thinking=TIER3_THINKING_BUDGET, cap=max(cap_override, TIER3_MAX_OUTPUT_TOK), hard_timeout_s=TIER3_TIMEOUT_S)`.
- Forwards Gemini Files refs only to Gemini providers (`_ref_kw`).
- When the Claude fallback is armed, passes `hard_timeout_s=LLM_HARD_TIMEOUT_S` so a stalled Gemini tier fails fast (single attempt, no self-retry) and Claude answers.
- **Claude timeout-fallback** ([orchestrator.py:1171-1196](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1171)): if armed AND `telemetry.status in _FALLBACK_STATUSES` (`timeout`, `rate_limited`, `upstream_unavailable`), re-run the SAME prompt/history/transcript on Claude (parity inherited, no second Groq STT). If Claude itself fails, keep the Gemini failure (the safety net never raises).

### 9.4 The escalation algorithm ([orchestrator.py:1457-1547](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1457))

Constants: `_ESCALATE_QUERY_TYPES = {"derivation","calc","mistake_id"}`, `_ESCALATE_STATUSES = {"truncated"}`, `_FALLBACK_STATUSES = {"timeout","rate_limited","upstream_unavailable"}`.

`_should_escalate(reply, telemetry)` returns True iff (any one):
- `telemetry.status == "truncated"` (model literally ran out of room), OR
- (status ok) `reply.confidence < GEMINI_ESCALATE_CONFIDENCE` (0.45), OR
- `reply.difficulty == "hard"` AND `reply.query_type in _ESCALATE_QUERY_TYPES`, OR
- `SEMANTIC_CHECK_ESCALATION` AND `reply.query_type in {"check","mistake_id"}` (verification requests always escalate — the model's self-rated difficulty is untrustworthy here).
It returns False on actual errors (timeout/safety) so failures don't compound.

The escalation block additionally suppresses escalation while a matched answer-key memo is active **except** on truncated output or keyed-confidence < 0.3, and forces a Pro re-derivation on a dispute (regex or model-flagged).

---

## 10. Provider Abstractions (LLM & TTS)

### 10.1 LLM provider factory ([llm_base.py](Smart-Tutor-Lamp-backend/app/providers/llm_base.py))

`LlmProvider(ABC)` ([llm_base.py:142-199](Smart-Tutor-Lamp-backend/app/providers/llm_base.py#L142)) — every concrete provider sets `name`/`model` and implements:

```python
async def call(system_prompt, history_text, image_bytes, audio_bytes, *,
               thinking_budget=None, max_output_tokens=None,
               hard_timeout_s=None) -> tuple[LlmReply, dict]
```

returning `(parsed reply, telemetry)`. The **telemetry dict** ([llm_base.py:16-25, 189-199](Smart-Tutor-Lamp-backend/app/providers/llm_base.py#L16)) is provider-agnostic: `ttft_ms`, `total_ms`, `raw_chars`, `model`, `provider`, `status` (`ok|timeout|safety_block|bad_json|error|not_implemented` plus runtime `truncated|rate_limited|upstream_unavailable`), `error`. There's also an optional `preupload_image()` latency hook.

**Self-registration factory**: `@register_provider` ([llm_base.py:207-219](Smart-Tutor-Lamp-backend/app/providers/llm_base.py#L207)) populates `_PROVIDER_REGISTRY`. `get_llm_provider(name=None)` ([llm_base.py:222-249](Smart-Tutor-Lamp-backend/app/providers/llm_base.py#L222)) imports all four provider modules (so their decorators run), reads `LLM_PROVIDER` (default `gemini`), and returns a **cached** instance per provider name (so SDK/HTTP-2/TLS construction happens at most once per process — ~80 ms/turn saved). Unknown provider → `ValueError`.

Gemini-specific helpers `gemini_thinking_config()` (§5.2) and `gemini_code_execution_tool()` ([llm_base.py:105-139](Smart-Tutor-Lamp-backend/app/providers/llm_base.py#L105)) (pins the server-side Python sandbox to Gemini-3.x **Pro** only — 2.5 rejects tool+JSON; flash-lite loops on Socratic prompts) live here.

### 10.2 TTS provider factory ([tts_base.py](Smart-Tutor-Lamp-backend/app/providers/tts_base.py))

`TtsProvider(ABC)` — the PRIMITIVE is the streaming `synthesize(text, *, turn_id) -> AsyncIterator[bytes]` (yields 24 kHz mono int16 LE PCM in ≤ `TTS_CHUNK_BYTES` pieces AS produced), not `text → bytes`, because a buffered contract would force the whole utterance to synthesize before a single sample plays (1–3 s of dead air). `generate_speech()` is a default convenience method that drains the stream. Capability properties: `available`, `target_sample_rate`, `mode`, `incremental`, and `warmup()`.

`get_tts_provider(name=None)` ([tts_base.py:149-187](Smart-Tutor-Lamp-backend/app/providers/tts_base.py#L149)) returns a cached instance or **None** on every "no audio" path (off / unknown / failed-construct) so the audio leg degrades with one `is None` check. **Cost enforcement**: `_import_provider(chosen)` imports ONLY the selected provider's module — `TTS_PROVIDER=piper` never even imports `tts_gemini`, so the Gemini client is never built and zero audio tokens can be spent. `clamp_tts_text()` ([tts_base.py:202-222](Smart-Tutor-Lamp-backend/app/providers/tts_base.py#L202)) bounds input to `TTS_MAX_INPUT_CHARS` at a word boundary.

`TTSError` is defined here so every provider + consumer shares one exception type; an empty stream and a `TTSError` both mean "no audio this turn" — never crash a turn over TTS.

### 10.3 The reply schema ([schemas/llm_response.py](Smart-Tutor-Lamp-backend/app/schemas/llm_response.py))

`LlmReply` is the single JSON object the LLM emits per turn, with **three independent output channels**: `speech` (TTS words only), `display` (`Display{kind: text|none, content}` TFT card), and `latex_equations[]` (max 3 — `MAX_EQUATIONS`). Analytics fields: `confidence` (0–1, default 0.8), `query_type`, `subject`, `difficulty`. Memory/control fields (never spoken/shown): `user_input`, `problem_statement`, `image_needed`, `solution_outline`, `same_problem`, `student_stuck`, `student_disputes_prior`, and the grounding audit fields `ocr_text` + `bounding_box`.

`model_config = ConfigDict(extra="ignore")` so unsolicited Gemini keys don't nuke the reply. A `@model_validator(mode="before")` `_coerce_tolerant` ([llm_response.py:254-393](Smart-Tutor-Lamp-backend/app/schemas/llm_response.py#L254)) sanitises a structurally-valid-but-semantically-off reply before field validation (clamp confidence to [0,1] default 0.8, trim `latex_equations` to non-empty strings capped at 3, coerce unknown enums to defaults, ensure `display` is a valid dict, clamp `bounding_box` to 4 ints in [0,1000] with ymin<ymax/xmin<xmax) — every repair logs a WARNING because silent coercion hides prompt drift.

Hardcoded fallbacks: `FALLBACK_REPLY` (generic) plus status-specific `_UPSTREAM_UNAVAILABLE_REPLY`, `_RATE_LIMITED_REPLY`, `_TIMEOUT_REPLY`, `_TRUNCATED_REPLY`, selected by `fallback_for_status(status)`. `retake_image_reply(detail)` is the no-LLM pre-router gate reply (status stays "ok" so the lamp speaks+shows the guidance).

---

## 11. Storage, Persistence & Memory

### 11.1 Database engine ([db/session.py](Smart-Tutor-Lamp-backend/app/db/session.py))

The async SQLAlchemy engine is **lazy** — `_engine`/`_session_factory` stay None until `init_db()` is called from the lifespan, so dev (no DATABASE_URL) boots without asyncpg. `init_db(create_tables=True)` ([db/session.py:73-104](Smart-Tutor-Lamp-backend/app/db/session.py#L73)) builds `create_async_engine(DATABASE_URL, pool_size=10, max_overflow=10, pool_pre_ping=True, pool_recycle=1800, connect_args=_ssl_connect_args(...))`, makes an `async_sessionmaker(expire_on_commit=False)`, runs `Base.metadata.create_all`, and applies idempotent additive `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` for late-added trace columns.

`_ssl_connect_args()` ([db/session.py:33-52](Smart-Tutor-Lamp-backend/app/db/session.py#L33)) decides asyncpg's `ssl` arg from `DATABASE_SSL` + host: AUTO turns TLS on (`require`) for `*.supabase.co`/`*.supabase.com` and leaves local Postgres untouched. `get_db()` is the per-request FastAPI dependency (rolls back + logs on exception).

### 11.2 Three-layer memory

The orchestrator's `_history_text()` delegates to `app.services.session_memory.load_context(device_id, user_id, session_id)` — the same assembly the web bench uses, so memory is identical regardless of source. Layers (`SESSION_MEMORY_GUIDE.md`): **L1** recent verbatim turns (`MEMORY_TAIL_SIZE=3`), **L2** an LLM-compacted `sessions.summary` (triggered at `MEMORY_COMPACT_THRESHOLD=8` turns when `ENABLE_MEMORY_COMPACTION`), **L3** a durable per-learner profile. `record_turn(...)` is the single persistence entrypoint (Supabase `turns` + Redis L1 write-through + background L2 compaction); non-ok turns are skipped inside it (error fallbacks never become history). Redis is optional — without it L1 falls back to Postgres reads, revocation to the 30 s heartbeat, rate-limiting to in-memory.

### 11.3 Blobs & traces

`_persist_turn()` ([orchestrator.py:1267-1421](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1267)) fires two writes off the hot path: (a) the Postgres `turns` row (tagged with the paired user; first image URL in `turns.image_url`, full list in `turns.extra.image_urls`, `api_calls`/`timeline`/cost telemetry in `extra`), and (b) Redis L1 write-through. Raw media (image JPEGs + audio WAV) is uploaded via `app.storage.blobs` in a bounded (`15 s`) parallel gather, only for ok turns. The `TurnTracer` then finalizes a verbose `turn_traces` row for the admin storyboard (passive, best-effort).

---

## 12. End-to-End Request Lifecycle

The complete path of one student question, from WS connect to reply on the speaker:

```mermaid
sequenceDiagram
    participant Lamp as ESP32-S3 Lamp
    participant WS as ws_lamp.lamp_ws
    participant Sess as Session
    participant Orch as TurnOrchestrator
    participant Pre as escalation_router
    participant LLM as LlmProvider (Gemini)
    participant Disp as dispatch_reply
    participant TTS as TtsProvider
    participant DB as Postgres / Redis / blobs

    Lamp->>WS: WS connect + Authorization: Bearer <jwt|dev-mode-no-auth>
    WS->>WS: _authenticate_dev / _authenticate_prod (device_jwt + DB row)
    WS->>Sess: new Session(device_id, ws, user_id)
    WS->>DB: open_session() + log_event(ws_open)
    loop turn frames
      Lamp->>Sess: IMAGE_PART...IMAGE_JPEG (chunked, JPEG-magic checked)
      Sess->>Sess: early prep_image (enhance + Files pre-upload) during speech
      Lamp->>Sess: AUDIO_CHUNK... (16 kHz PCM, 640 B/20 ms)
      Lamp->>Sess: AUDIO_END (empty)
    end
    Sess->>Sess: gate duration (0.5s..30s), cancel prev turn
    Sess->>Orch: run_turn(session, images, audio_bytes, image_preps)
    Orch->>Lamp: STATE(thinking)
    Orch->>DB: load_context (L3+L2+L1, 2s cap)
    Orch->>Pre: preroute(groq_stt, image_quality, n_images)
    alt image too poor + thin transcript
      Orch->>Disp: dispatch retake_image_reply (zero LLM)
    else
      Orch->>LLM: _call_tier(start_tier) [thinking budget + output cap]
      LLM-->>Orch: (LlmReply, telemetry)
      opt _should_escalate or dispute
        Orch->>LLM: _call_tier(next_tier) handoff brief (audio dropped)
        LLM-->>Orch: (LlmReply, telemetry) [revert if worse]
      end
      opt Gemini server failure + fallback armed
        Orch->>LLM: Claude fallback (same prompt/history/transcript)
      end
      Orch->>Lamp: STATE(speaking) or STATE(error)
      Orch->>Disp: dispatch_reply(reply, status, model_tag)
      par audio leg
        Disp->>TTS: synthesize(speech) -> PCM chunks
        Disp->>Lamp: AUDIO_OUT (4 KB / 85 ms paced, prime-burst first 48 KB)
      and tft leg
        Disp->>Lamp: TFT_TEXT (+ TFT_LATEX_LOADING + chunked TFT_FRAME)
      end
    end
    Orch->>DB: _persist_turn (turns row + Redis L1 + blobs + trace) [fire-and-forget]
    Orch->>Lamp: finalize_turn() = AUDIO_OUT_END + STATE(idle)
    Lamp->>WS: (idle; mic re-armed)
```

Data transforms at each stage:
- **Ingest**: chunked binary frames → `Turn.images: list[bytes]` + `Turn.audio_pcm: bytearray` (16 kHz int16 PCM).
- **Enhance**: raw JPEG bytes → OpenCV/PIL-cleaned JPEG bytes (page detect, bleach, CLAHE+unsharp) → optionally a Gemini Files API ref.
- **Pre-route**: PCM → Groq Whisper transcript (string) + image-quality metrics → a `decision` (start tier, suffixes, retake flag).
- **LLM**: (system_prompt + history_text + images + audio) → `LlmReply` JSON + telemetry.
- **Dispatch**: `LlmReply.speech` → TTS PCM stream → AUDIO_OUT frames; `LlmReply.display`/`latex_equations` → TFT_TEXT/TFT_FRAME frames.
- **Persist**: `LlmReply` + telemetry → `turns` row + memory layers + blob URLs + trace row.

---

## 13. Error Handling, Timeouts, Retries & Fallbacks

| Concern | Mechanism | Location |
|---|---|---|
| Bad WS frame | `decode()` ValueError → log + drop, **socket stays open** | [ws_lamp.py:263-270](Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L263) |
| Frame-handler bug | `on_frame` wrapped in try/except → log, keep serving | [ws_lamp.py:272-280](Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L272) |
| Oversized outbound frame | `send_frame` raises `ValueError` (prevents lamp `bad_alloc` reboot) | [session.py:562-568](Smart-Tutor-Lamp-backend/app/session.py#L562) |
| Wire write hang | `asyncio.wait_for(send_bytes, 2.0)` → close 1011 | [session.py:573-588](Smart-Tutor-Lamp-backend/app/session.py#L573) |
| Idle WS | `WS_IDLE_TIMEOUT_S = 600.0` backstop; re-arms on any traffic or active turn | [ws_lamp.py:66, 236-258](Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L66) |
| Too-short audio | `< 0.5 s` → drop as false wake, STATE(idle) | [session.py:423-433](Smart-Tutor-Lamp-backend/app/session.py#L423) |
| Too-long audio | `> 30 s` → truncate to cap | [session.py:435-445](Smart-Tutor-Lamp-backend/app/session.py#L435) |
| Corrupt/partial image | JPEG-magic check → drop, turn continues | [session.py:319-328](Smart-Tutor-Lamp-backend/app/session.py#L319) |
| History store slow | 2 s cap → proceed stateless this turn | [orchestrator.py:1246-1257](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1246) |
| Early-prep hang | 8 s cap → fall back to inline enhancement | [orchestrator.py:188-223](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L188) |
| Pre-router STT fail | 1.2 s cap, best-effort → route without transcript | [orchestrator.py:1425-1454](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1425) |
| LLM call slow | `LLM_HARD_TIMEOUT_S = 20` (tier-3 `38`) → status `timeout` | [llm_base.py:38](Smart-Tutor-Lamp-backend/app/providers/llm_base.py#L38) |
| Gemini server failure | Claude timeout-fallback (same turn) when armed | [orchestrator.py:1171-1196](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1171) |
| Escalation worse | Escalation-revert (Fix B) keeps the good lower-tier answer | [orchestrator.py:750-761](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L750) |
| Bad/blocked LLM JSON | tolerant coercion + status-specific `fallback_for_status` reply | [llm_response.py:254-479](Smart-Tutor-Lamp-backend/app/schemas/llm_response.py#L254) |
| LLM error status | STATE(error) red LED + visual-only (dispatcher skips TTS) | [orchestrator.py:971-975](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L971), [dispatch.py:60-85](Smart-Tutor-Lamp-backend/app/services/dispatch.py#L60) |
| Hard turn failure | catch-all → STATE(error) + "Sorry, I had trouble" | [orchestrator.py:1034-1052](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1034) |
| Always | `finally: finalize_turn()` (AUDIO_OUT_END + STATE idle) | [orchestrator.py:1053-1060](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1053) |
| Blob upload slow | 15 s cap → store turn without media URLs | [orchestrator.py:1315-1325](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1315) |
| DB init fail (auth off) | continue stateless | [main.py:90-99](Smart-Tutor-Lamp-backend/app/main.py#L90) |
| Missing auth config (auth on) | RuntimeError at boot (fail loud) | [main.py:52-64](Smart-Tutor-Lamp-backend/app/main.py#L52) |
| Missing LLM key | `sys.exit(2)` at boot | [startup.py:60-62](Smart-Tutor-Lamp-backend/app/startup.py#L60) |
| LaTeX subset drift | `sys.exit(3)` at boot | [startup.py:85-89](Smart-Tutor-Lamp-backend/app/startup.py#L85) |

The orchestrator's only "retry" semantics are deterministic, **single** guard re-calls (echo, focus, solution-bleed, reveal-completeness) and the tier-escalation re-call — not blind retries. Each fires at most once and only when a specific failure signal is detected.

---

## 14. Integration Points & Cross-References

**Calls into the backend (callers):**
- **The ESP32-S3 firmware** connects to `/lamp/ws` with `Authorization: Bearer <device_jwt | dev-mode-no-auth>` and speaks the binary protocol of §7. The wire constants (`AUDIO_OUT_CHUNK_BYTES`, `WS_HARD_MAX_BYTES`, ADPCM/Opus reset boundaries) are kept in lock-step with the firmware (`HARDWARE_CONTEXT.md`, `tutor_lamp.ino`, `net_ws.cpp`, `spk_i2s.cpp`).
- **The Next.js frontend** calls the auth/pairing/admin HTTP routes and the web brain-bench `/api/frontend/ws` + `/api/frontend/simulate` (the same multimodal payload the lamp sends), driven by the same `_call_tier`/orchestration logic (lamp + web stay in lockstep).
- **Clerk** posts the `user.deleted` Svix webhook to `clerk_webhook`; **process supervisors / load balancers** poll `/healthz` (liveness) and `/readyz` (readiness — verifies Postgres + Redis + an LLM key).

**What the backend calls out to:**
- **LLM providers** (Gemini / OpenAI / Claude / DeepSeek) via the `providers/llm_*.py` adapters + Groq Whisper for upstream/pre-router STT.
- **TTS engines** (Gemini Flash TTS API or self-hosted Piper) via `providers/tts_*.py`.
- **Supabase Postgres + pgvector** (sessions, turns, memory, devices, pairing_codes, admins, model_providers, turn_traces, events) and **Supabase Storage / Cloudflare R2 / local FS** for blobs.
- **Redis** for L1 session cache + revocation pub/sub + rate-limit buckets.

**Internal cross-references:** the design layering and number scheme come from [BACKEND_DESIGN.md](Smart-Tutor-Lamp-backend/BACKEND_DESIGN.md) and [BACKEND_TODO.md](Smart-Tutor-Lamp-backend/BACKEND_TODO.md); the system-prompt architecture is in [system_prompt_arch.md](Smart-Tutor-Lamp-backend/system_prompt_arch.md); dev run instructions in [RUN.md](Smart-Tutor-Lamp-backend/RUN.md).

---

## 15. File-by-File / Function-by-Function Breakdown

### [app/main.py](Smart-Tutor-Lamp-backend/app/main.py) — FastAPI entrypoint (Layer 0)
- `configure_logging()` call + module-level `log` — runs first so import-time logs are captured.
- `lifespan(app)` — async startup/shutdown: self-tests → auth config check → DB init/seed → Redis init → TTS warmup → `yield` → dispose. (§4.4)
- `_log_validation_error(request, exc)` — logs 422 field detail, returns standard 422.
- `_log_unhandled(request, exc)` — catch-all 500 with traceback + clean JSON envelope.
- `_trace_requests(request, call_next)` — per-request timing + status-graded logging.
- Module body: slowapi limiter wiring, CORS, conditional `/blobs` mount, conditional auth-route mounting.

### [app/startup.py](Smart-Tutor-Lamp-backend/app/startup.py) — boot self-tests
- `_LATEX_SAMPLES` — 6 proven equations.
- `verify_llm_provider_configured()` — provider instantiable + API key present, else `sys.exit(2)`.
- `verify_latex_renderer()` — renders all samples, else `sys.exit(3)` (non-importable → WARNING only).
- `run_all_startup_checks()` — runs both in order.

### [app/config.py](Smart-Tutor-Lamp-backend/app/config.py) — settings (Layer 0)
- `load_dotenv(override=False)` — sync `.env` → `os.environ`.
- `class Settings(BaseSettings)` — every env var (§5).
- `settings = Settings()` — singleton.

### [app/logging.py](Smart-Tutor-Lamp-backend/app/logging.py) — central logging
- `configure_logging()` — idempotent root-handler setup, UTF-8 stdout, SQL/HTTP logger levels (§6).

### [app/protocol.py](Smart-Tutor-Lamp-backend/app/protocol.py) — wire primitives (Layer 1.1)
- `FrameType(IntEnum)`, `StateByte(IntEnum)`, wire-size constants.
- `encode(type_, payload)` / `decode(buf)` — the 4-byte header codec.

### [app/session.py](Smart-Tutor-Lamp-backend/app/session.py) — per-WS state (Layers 1.3/1.5 + 2)
- `_steer_opus_lib()`, `class _OpusWire` — optional Opus wire encoder.
- `@dataclass Turn` — per-turn input buffer (§8.1).
- `class Session` — frame ingest (`on_frame`, `_on_image_part`, `_on_image_terminator`, `_on_audio_chunk[_adpcm]`, `_on_audio_end`, `_on_cancel`, `_on_turn_done`, `close`) + TX helpers (`send_frame`, `send_state`, `send_tft_text`, `send_tft_clear`, `send_tft_latex_loading`, `send_audio_out_chunk`, `stream_audio_out`, `stream_audio_out_iter`, `send_audio_out_end`, `send_tft_frame_chunked`, `send_tft_frame_append`, `finalize_turn`, back-compat aliases). (§8.2)

### [app/routes/ws_lamp.py](Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py) — `/lamp/ws` (Layer 1.2)
- `_extract_bearer`, `_authenticate_dev`, `_authenticate_prod` (device_jwt + DB row), `_heartbeat` (30 s last_seen/revoke recheck), `_close_unlinked` (STATE(unpaired) + close 4402).
- `lamp_ws(ws)` — accept, build Session, open session row, spawn revocation watcher + heartbeat (auth), then the receive loop with `WS_IDLE_TIMEOUT_S` and per-frame decode→`on_frame`; `finally` finalizes the session.

### [app/routes/health.py](Smart-Tutor-Lamp-backend/app/routes/health.py)
- `healthz()` — liveness (always 200).
- `readyz()` — readiness (Postgres SELECT 1 + Redis ping + LLM key presence → 200/503).

### [app/services/orchestrator.py](Smart-Tutor-Lamp-backend/app/services/orchestrator.py) — turn pipeline (Layer 8)
- `class TurnOrchestrator.__init__` — build primary/Pro/fallback providers.
- `run_turn(...)` — the 15-step pipeline (§9.2).
- `_call_tier(...)` — single LLM choke point + Claude fallback (§9.3).
- `_tier_model_name`, `_model_tag`, `_load_history`, `_history_text`, `_persist_turn`.
- Module: `_safe_preroute_stt`, `_should_escalate`, `_looks_like_echo`, `_speech_caption`, escalation/fallback status sets, `get_orchestrator()` singleton.

### [app/providers/llm_base.py](Smart-Tutor-Lamp-backend/app/providers/llm_base.py) — LLM abstraction (Layer 4)
- Constants `LLM_HARD_TIMEOUT_S`, `LLM_MAX_OUTPUT_TOKENS`; `gemini_thinking_config`, `gemini_code_execution_tool`.
- `class LlmProvider(ABC)` (`call`, `preupload_image`, `_new_telemetry`).
- Factory: `register_provider`, `get_llm_provider`, `reset_provider_cache`, `list_providers`, `_ensure_all_providers_imported`.

### [app/providers/tts_base.py](Smart-Tutor-Lamp-backend/app/providers/tts_base.py) — TTS abstraction (Layer 7)
- `class TTSError`; `class TtsProvider(ABC)` (`synthesize`, `generate_speech`, `available`/`target_sample_rate`/`mode`/`incremental`, `warmup`).
- Factory: `register_tts_provider`, `get_tts_provider`, `reset_tts_provider_cache`, `list_tts_providers`, `clamp_tts_text`, lazy `_import_provider`/`_ensure_imported`.

### [app/schemas/llm_response.py](Smart-Tutor-Lamp-backend/app/schemas/llm_response.py) — reply schema (Layer 5.2)
- `class Display`, `class LlmReply` (three channels + analytics + memory/control + grounding), `_coerce_tolerant` validator.
- `FALLBACK_REPLY` + status-specific replies, `retake_image_reply`, `fallback_for_status`.

### [app/services/dispatch.py](Smart-Tutor-Lamp-backend/app/services/dispatch.py) — reply dispatcher (Layer 5.3)
- `dispatch_reply(session, reply, *, status, model_tag, trace)` — instant TFT_TEXT, conditional LaTeX skeleton, parallel `asyncio.gather(audio_leg, tft_leg)`; skips TTS + skeleton when `status != "ok"`.

### [app/db/session.py](Smart-Tutor-Lamp-backend/app/db/session.py) — async SQLAlchemy engine
- `_ssl_connect_args`, `get_engine`, `get_session_factory`, `init_db`, `_ensure_additive_columns`, `dispose_db`, `get_db`.

### Supporting modules (referenced, not the assigned focus)
`services/escalation_router.py` (pre-router + image-quality gate + follow-up/dispute helpers), `services/problem_memo.py` (solve-once/tutor-many answer key + nudge gate + guards), `services/session_memory.py` (L1/L2/L3 + `record_turn`), `services/image_prep.py` (early enhance + Files pre-upload), `services/turn_trace.py` (admin trace), `providers/image_preprocessor.py` (`enhance_for_llm`), `providers/latex_engine.py` (`LatexRenderer`), `storage/{turns,blobs,events,memory_vec,model_eval}.py`, and the `routes/` auth/pairing/admin/frontend surface.

---

*This document reflects the backend at git branch `backend`, grounded in the source files listed above. Line numbers are accurate as of the read; treat them as anchors, not contracts.*
