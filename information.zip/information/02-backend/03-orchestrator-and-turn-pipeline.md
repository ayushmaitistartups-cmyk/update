# Backend — Orchestrator & Turn Processing Pipeline (the Brain)

This is the definitive reference for the **turn processing pipeline** — the part of the Smart Tutor Lamp backend that takes one student "turn" (some captured images + a chunk of recorded audio) and turns it into a tutoring reply that the lamp speaks and shows. It documents the production orchestrator (`orchestrator.py`), the reply dispatcher (`dispatch.py`), the passive execution tracer (`turn_trace.py`), the solve-once/tutor-many problem memo (`problem_memo.py`), and the legacy "BAO" prototype (now under `app/legacy/`: `turn_handler.py` + `validator.py`). Every behavior, threshold, constant, branch and fallback described here is quoted from the actual code; nothing is invented. The pipeline is multi-tier (Flash → Flash-thinking → Pro), deterministically pre-routed, self-escalating, guarded against half a dozen failure modes, and instrumented end-to-end.

> **Updated 2026-07-05** (backend tip `a5533e5`). `orchestrator.py` (+427), `dispatch.py` (+753), `session.py` (+295), `problem_memo.py` (+366) and `escalation_router.py` (+201) grew substantially since the 2026-06-16 sync. The current pipeline adds: an **input-safety short-circuit** and **math-verifier** + **output-validator** wiring (§6, §10; detail in [doc 11](11-output-validator-guardrails-and-verifier.md)); three new guards — **open-start**, **MCQ option-completeness**, and **check-verdict** (§10); a **per-turn LLM-call budget** (`MAX_LLM_CALLS_PER_TURN`); **three dispatch modes** (scroll-document / sync-to-audio / legacy-parallel) plus graph and chemistry legs (§11); and, as of 2026-07-03/04, a **backgrounded conversational-memory load** (`history_task`, overlapping the L1/L2/L3 read with STT/image work instead of blocking on it first — see Step 2/6 below) plus the `assess_image_quality` gate moved off the event loop via `asyncio.to_thread`. Because these files grew, some line citations below have shifted by a few hundred lines from the code; the anchors and function names remain correct, and the newly-added behaviour is called out with current line numbers.

---

## Table of Contents

1. [Purpose & Responsibilities](#1-purpose--responsibilities)
2. [Where this lives in the system](#2-where-this-lives-in-the-system)
3. [Component & Module Map](#3-component--module-map)
4. [Key Data Structures](#4-key-data-structures)
5. [Configuration, Env Vars, Constants & Thresholds](#5-configuration-env-vars-constants--thresholds)
6. [The Complete Turn Workflow (entry → exit)](#6-the-complete-turn-workflow-entry--exit)
7. [The Tier System & `_call_tier`](#7-the-tier-system--_call_tier)
8. [Routing & Escalation Algorithms](#8-routing--escalation-algorithms)
9. [The Problem Memo (solve-once, tutor-many)](#9-the-problem-memo-solve-once-tutor-many)
10. [The Guard Stack (echo / focus / bleed / reveal / dispute)](#10-the-guard-stack)
11. [Reply Dispatch (`dispatch.py`)](#11-reply-dispatch-dispatchpy)
12. [Turn Tracing (`turn_trace.py`)](#12-turn-tracing-turn_tracepy)
13. [Persistence](#13-persistence)
14. [Error Handling, Timeouts, Retries, Fallbacks](#14-error-handling-timeouts-retries-fallbacks)
15. [Integration Points / Cross-References](#15-integration-points--cross-references)
16. [The Legacy "BAO" Prototype (`turn_handler.py` + `validator.py`)](#16-the-legacy-bao-prototype)
17. [Mermaid Diagrams](#17-mermaid-diagrams)
18. [File-by-file, function-by-function index](#18-file-by-file-function-by-function-index)

---

## 1. Purpose & Responsibilities

The orchestrator is **Layer 8 ("glue")** of the backend layering, sitting on top of Layer-3 prompt assembly and Layer-4 provider-agnostic LLM calls ([orchestrator.py:1-20](app/services/orchestrator.py#L1)). Its single public method, `TurnOrchestrator.run_turn`, owns the **entire lifecycle of one turn**:

> The documented lifecycle ([orchestrator.py:5-16](app/services/orchestrator.py#L5)):
> 1. `STATE(thinking)` — lamp shows orbiting-dot spinner
> 2. Layer 3 + 4: assemble prompt + call the configured LLM (TTFT-instrumented, timeout-bounded)
> 3. Layer 5: parse JSON → `LlmReply` (fallback on bad / timeout)
> 4. `STATE(speaking)` + `TFT_TEXT` — lamp pages off THINKING immediately
> 5. `asyncio.gather(audio leg, tft leg)` — PARALLEL, never sequential
> 6. `AUDIO_OUT_END` + `STATE(idle)` — `Session.finalize_turn` (REQUIRED; releases I2S to mic + returns LED to cyan)
> 7. Fire-and-forget persist

Concretely it is responsible for:

- **Process-singleton lifecycle** — build the LLM provider(s) + static system prompt **once per process** so every turn skips the TLS handshake and prompt build ([orchestrator.py:17-20](app/services/orchestrator.py#L17), [orchestrator.py:1570-1577](app/services/orchestrator.py#L1570)).
- **Pre-LLM image work** — enhance/unmirror images, harvest "early prep" Files-API uploads, run a deterministic image-quality gate.
- **Deterministic pre-routing** — pick a *starting* model tier from hard signals (image quality, transcript keywords) before paying for any LLM call ([orchestrator.py:277-343](app/services/orchestrator.py#L277)).
- **Tier dispatch + post-answer escalation** — climb Flash → Flash-thinking → Pro when the answer signals "needed more" ([orchestrator.py:447-784](app/services/orchestrator.py#L447)).
- **Problem-memo lifecycle** — load/match/save/flush the per-session answer key so repeated turns on one hard problem run cheaply ([orchestrator.py:376-445](app/services/orchestrator.py#L376), [problem_memo.py](app/services/problem_memo.py)).
- **A guard stack** — echo guard, focus guard, solution-bleed guard, reveal-completeness guard, dispute guard, check-verdict guard — each a deterministic detector that triggers exactly ONE corrective re-call (or injects a mode note) only when the condition actually holds.
- **Dispatch** — hand the parsed reply to `dispatch_reply` for parallel TTS + TFT delivery.
- **Persistence + tracing** — fire-and-forget writes to Postgres `turns`, Redis L1, blob storage, and the admin `turn_traces` audit row.
- **Half-duplex invariant** — ALWAYS call `finalize_turn` so the lamp's I2S TX is released back to the mic, even on cancel/error ([orchestrator.py:93-95](app/services/orchestrator.py#L93), [orchestrator.py:1053-1060](app/services/orchestrator.py#L1053)).

---

## 2. Where this lives in the system

```
ESP32-S3 lamp ──WS frames──► ws_lamp route ──► Session._on_audio_end
                                                      │  (collects images[] + audio_bytes)
                                                      ▼
                                       TurnOrchestrator.run_turn(...)   ◄── THIS DOCUMENT
                                          │
       ┌──────────────┬──────────────────┼──────────────────┬──────────────┐
       ▼              ▼                   ▼                  ▼              ▼
  escalation_   image_prep /        problem_memo      LlmProvider.call  dispatch_reply
  router        image_preprocessor  (Redis memo)      (gemini/claude…)  (TTS + TFT)
  (preroute)                                                                  │
                                                                             ▼
                                                                     Session.send_* (WS out)
       │
       ▼ (fire-and-forget)
  session_memory.record_turn (Postgres turns + Redis L1)
  TurnTracer.finalize (turn_traces row)
```

**Caller.** The orchestrator is invoked from `Session._on_audio_end`. The session cancels any still-running prior turn (bounded 2 s drain), then spawns `run_turn` as a named task ([session.py:453-480](app/session.py#L453)):

```python
orchestrator = get_orchestrator()
task = asyncio.create_task(
    orchestrator.run_turn(self, images, audio_bytes,
                          image_preps=list(turn.image_preps)),
    name=f"turn-{self.device_id}-{int(turn.started_at * 1000)}",
)
```

Just before spawning, the session stamps `self.last_capture_ms` (first media frame → AUDIO_END), which the tracer reads ([session.py:466-471](app/session.py#L466)).

The **web simulator** does NOT use `run_turn`; it has a parity implementation in `frontend_manager.py` that mirrors the same tier dispatch, escalation, memo, and guards ([escalation_router.py:4-6](app/services/escalation_router.py#L4)). Both surfaces share `escalation_router`, `problem_memo`, `dispatch`, `turn_trace`, and `session_memory`, so behavior is identical regardless of input source.

---

## 3. Component & Module Map

| Module | Role | Key entry points |
|---|---|---|
| `app/services/orchestrator.py` | The brain. One turn end-to-end. | `TurnOrchestrator.run_turn`, `_call_tier`, `_should_escalate`, `_looks_like_echo`, `get_orchestrator` |
| `app/services/dispatch.py` | Layer 5.3 middleware: reply → outbound frames (parallel TTS + TFT). | `dispatch_reply`, `_dispatch_audio_leg`, `_dispatch_tft_leg`, `_dispatch_equations` |
| `app/services/turn_trace.py` | Passive per-turn execution tracer → `turn_traces` admin audit. | `TurnTracer`, `.phase`, `.note`, `.mark`, `.finalize`, `clean_bbox` |
| `app/services/problem_memo.py` | Solve-once/tutor-many: per-session answer-key cache + reveal policy + leak detectors. | `load`, `matched`, `save`, `solve_authorized`, `solution_bleed`, `is_dispute`, `SOLVE_SUFFIX` |
| `app/services/escalation_router.py` | Deterministic PRE-router: image quality + text keywords → starting tier. | `assess_image_quality`, `classify_text`, `preroute`, `is_followup_text`, `focus_mismatch` |
| `app/schemas/llm_response.py` | Pydantic `LlmReply` schema + tolerant coercion + canned fallbacks. | `LlmReply`, `retake_image_reply`, `fallback_for_status` |
| `app/providers/llm_base.py` | Provider-agnostic `LlmProvider.call()` contract + global constants. | `get_llm_provider`, `LLM_HARD_TIMEOUT_S` |
| `app/services/turn_handler.py` + `validator.py` | **Legacy** "BAO" prototype (mocked LLM). Not the live path. | `handle_turn`, `validate_response` |

**Module dependency edges within the assigned set:**

- `orchestrator` imports `problem_memo`, `escalation_router` (preroute/assess/focus/followup), `turn_trace` (`TurnTracer`, `clean_bbox`), and lazily imports `dispatch.dispatch_reply` inside `run_turn`.
- `dispatch` imports `LlmReply` and lazily imports the TTS provider factory + `latex_renderer`.
- `turn_trace` imports only `settings` and lazily imports `blobs` + DB models at finalize time.
- `problem_memo` imports `cache` (Redis) + `settings`.
- `turn_handler` imports `validator.validate_response`.

---

## 4. Key Data Structures

### 4.1 `LlmReply` — the single JSON object the LLM emits per turn

Defined in [llm_response.py:71-252](app/schemas/llm_response.py#L71). It carries **three independent output channels** plus analytics + internal-memory fields:

| Field | Type / default | Channel / purpose |
|---|---|---|
| `speech` | `str` | TTS — spoken aloud; words only, ~50-word soft cap ([L91](app/schemas/llm_response.py#L91)). |
| `display` | `Display{kind: "text"\|"none", content: str}` | TFT text card. Note: **no `"latex"` kind** any more ([L36-68](app/schemas/llm_response.py#L36)). |
| `latex_equations` | `list[str]`, `max_length=MAX_EQUATIONS=3` | TFT LaTeX region, one renderable equation per entry ([L102-112](app/schemas/llm_response.py#L102)). |
| `confidence` | `float` default `0.8`, clamped `[0,1]` | Self-rating; **below `GEMINI_ESCALATE_CONFIDENCE` (0.45) escalates** ([L115-122](app/schemas/llm_response.py#L115)). |
| `query_type` | enum default `"other"` | `{concept, calc, formula, derivation, definition, check, mistake_id, other}` ([L29-30](app/schemas/llm_response.py#L29)). |
| `subject` | enum default `"other"` | `{math, physics, chemistry, biology, cs, language, history, other}`. Feeds the memo subject backstop. |
| `difficulty` | enum default `"medium"` | `{easy, medium, hard}`. Drives the skip-tier jump. |
| `user_input` | `str` default `""`, capped 200 | ≤15-word restatement of what the student asked. Conversation memory; never spoken/shown. |
| `problem_statement` | `str` default `""`, capped 400 in memo | Complete self-contained transcription. The Flash→Pro handoff brief. |
| `image_needed` | `bool` default `True` | Whether the image must ride along to the escalated tier. |
| `solution_outline` | `str` default `""`, capped 1800 in memo | The internal verified solution path → becomes the memo's answer key. |
| `same_problem` | `bool` default `True` | Is this turn the SAME problem as recent turns / the active answer key? Drives flushing. |
| `student_stuck` | `bool` default `False` | Per-turn stuck judgment → feeds the next turn's reveal gate. |
| `student_disputes_prior` | `bool` default `False` | Model's flag that the student challenges OUR prior answer → semantic dispute path. |
| `ocr_text` | `str` default `""`, capped 80 | Short TARGET LABEL of the region answered → focus mismatch check + admin overlay. |
| `bounding_box` | `list[int]\|None`, `[ymin,xmin,ymax,xmax]` 0-1000 | Region overlay for admin audit. |

`model_config = ConfigDict(extra="ignore")` so unsolicited extra keys never nuke the reply ([L88](app/schemas/llm_response.py#L88)). The `@model_validator(mode="before")` `_coerce_tolerant` ([L254-393](app/schemas/llm_response.py#L254)) repairs structurally-valid-but-semantically-off replies BEFORE field validation: clamps `confidence` to `[0,1]` (absent/null → schema default `0.8`; present-but-**garbage** → `0.3` since 2026-07-06, so a broken reply now routes TO escalation instead of suppressing it — see doc 13), trims `latex_equations` to non-empty strings capped at 3, coerces unknown enums to default, stringifies `speech`/`user_input`/`ocr_text`, re-validates `bounding_box`, and unwraps a `Display` instance to a dict (a bug-fixed path so canned fallbacks aren't blanked). **Every repair logs a `WARN`** so silent coercion can't hide prompt drift ([L274-281](app/schemas/llm_response.py#L274)).

### 4.2 Canned fallback replies

[llm_response.py:399-479](app/schemas/llm_response.py#L399):

- `FALLBACK_REPLY` — generic "Sorry, I had trouble…" (`confidence=0.0`).
- `_UPSTREAM_UNAVAILABLE_REPLY`, `_RATE_LIMITED_REPLY`, `_TIMEOUT_REPLY`, `_TRUNCATED_REPLY` — each a transient-failure message keyed to a telemetry `status`.
- `retake_image_reply(detail)` — a **no-LLM** reply with `status` effectively "ok" so the lamp SPEAKS + SHOWS the retake guidance (zero tokens) ([L450-461](app/schemas/llm_response.py#L450)).
- `fallback_for_status(status)` — dispatcher that picks the matching message ([L464-479](app/schemas/llm_response.py#L464)).

### 4.3 Telemetry dict (returned by every provider `call()`)

Shape from [llm_base.py:15-25](app/providers/llm_base.py#L15):

```python
{
  "ttft_ms":   int | None,   # call-start → first text chunk
  "total_ms":  int,          # call-start → JSON parsed
  "raw_chars": int,
  "model":     str,          # e.g. "gemini-2.5-flash"
  "provider":  str,
  "status":    "ok" | "timeout" | "safety_block" | "bad_json" | "error" | "not_implemented",
  "error":     str | None,
}
```

The orchestrator augments it per turn with keys it owns: `tier`, `escalated`, `escalation_reverted`, `echo_guard`, `focus_guard`, `bleed_guard`, `reveal_guard`, `fallback`, `fallback_from`, and (for persistence) `cost_usd`. A `status` of `None` or `"ok"` is treated as success everywhere (`status in (None, "ok")`).

### 4.4 `PrerouteDecision` (escalation_router)

[escalation_router.py:360-382](app/services/escalation_router.py#L360):

| Field | Default | Meaning |
|---|---|---|
| `start_tier` | `1` | The tier the turn ENTERS at. |
| `retake_image` | `False` | Short-circuit: ask the student to retake (zero LLM). |
| `retake_reason` / `retake_detail` | `""` | Machine tag / human message. |
| `require_option_verification` | `False` | MCQ → verify each option (adds `_OPTION_VERIFY_SUFFIX`). |
| `require_mistake_localization` | `False` | "where did I go wrong" → adds `_MISTAKE_LOCALIZE_SUFFIX`. |
| `focus_label` | `""` | Named target like `"Q5"` / `"Q5(B)"`. |
| `reasons` | `[]` | Audit trail of why this decision. |
| `.prompt_suffix` (property) | — | Concatenation of the three suffixes that apply ([L371-382](app/services/escalation_router.py#L371)). |

`ImageQualityVerdict` ([L40-48](app/services/escalation_router.py#L40)): `ok`, `reason` (`"blurry"|"too_dark"|"too_small"`), `detail`, `blur_var`, `min_dim`, `luma`. `TextSignals` ([L192-199](app/services/escalation_router.py#L192)): six booleans `hard/extreme/diagram/mistake/mcq/formula_def`.

### 4.5 The problem memo payload (Redis JSON)

Stored under key `memo:problem:{session_id}` ([problem_memo.py:43-44](app/services/problem_memo.py#L43)) with a 30-minute TTL (`_TTL_S = 30*60`). Fields ([problem_memo.py:68-85](app/services/problem_memo.py#L68)):

```json
{
  "statement": "...",   // capped 400 (_STATEMENT_CAP)
  "outline":   "...",   // capped 1800 (_OUTLINE_CAP); "" for a question-only memo
  "model":     "gemini-2.5-pro",
  "tier":      3,
  "subject":   "math",
  "label":     "Q5",    // named worksheet target → LABEL BACKSTOP
  "nudges":    0,        // keyed GUIDANCE turns served (reveal-gate counter)
  "stuck":     false     // model's most recent student_stuck judgment
}
```

**Single slot per session by design** — switching problems flushes; switching back re-pays one escalated solve ([problem_memo.py:20-24](app/services/problem_memo.py#L20)).

### 4.6 `TurnTracer` state

[turn_trace.py:132-155](app/services/turn_trace.py#L132): `trace_id` (uuid hex), `enabled` (= `TURN_TRACE_ENABLED`), `fields` (whitelisted scalar columns), `phases` (storyboard list), `extra` (anything non-whitelisted), `_t_start`, `_finalized`. Whitelisted columns are enumerated in `_SCALAR_FIELDS` ([L43-52](app/services/turn_trace.py#L43)); free-text columns are size-capped in `_TEXT_CAPS` ([L55-66](app/services/turn_trace.py#L55)).

---

## 5. Configuration, Env Vars, Constants & Thresholds

All settings live in `app/config.py`. Values below are the **defaults**.

### 5.1 Tier → model map (the central knob)

| Tier | Model | Thinking budget | Output cap | Setting refs |
|---|---|---|---|---|
| 1 (Flash) | base provider | `GEMINI_TIER1_THINKING_BUDGET = 0` | `GEMINI_TIER1_MAX_OUTPUT_TOK = 1200` | [config.py:441,447](app/config.py#L441) |
| 2 (Flash-thinking) | base provider | `GEMINI_TIER2_THINKING_BUDGET = 1024` | `GEMINI_TIER2_MAX_OUTPUT_TOK = 4000` | [config.py:448,465](app/config.py#L448) |
| 3 (Pro) | `GEMINI_TIER3_MODEL = "gemini-3.1-pro-preview"` | `GEMINI_TIER3_THINKING_BUDGET = 512` | `GEMINI_TIER3_MAX_OUTPUT_TOK = 10000` | [config.py:475,482,490](app/config.py#L475) |

The code comment at [orchestrator.py:452-455](app/services/orchestrator.py#L452) summarizes the intent as `1 → Flash thinking=0 cap=600 ; 2 → Flash thinking=512 cap=1500 ; 3 → Pro thinking=1024 cap=2500` — the **config values above are the live numbers** (the comment is illustrative/older).

### 5.2 Tier-3 / Pro enablement & timeout

- `GEMINI_TIER3_ENABLED = True` — when off, the routable ceiling is tier-2 ([config.py:474](app/config.py#L474), [escalation_router.py:385-388](app/services/escalation_router.py#L385)). The orchestrator only builds `self._llm_pro` when `GEMINI_TIER3_ENABLED` **AND** the base provider is `gemini` ([orchestrator.py:56-62](app/services/orchestrator.py#L56)).
- `GEMINI_TIER3_TIMEOUT_S = 38.0` — Pro gets its own longer window ([config.py:510](app/config.py#L510)); tier-1/2 use the global `LLM_HARD_TIMEOUT_S = 20.0` ([llm_base.py:38](app/providers/llm_base.py#L38)).
- `GEMINI_TIER3_CODE_EXECUTION = True` ([config.py:500](app/config.py#L500)).

### 5.3 Escalation thresholds

- `GEMINI_DYNAMIC_THINKING = True` — master switch for post-answer escalation ([config.py:440](app/config.py#L440)). Off → single-tier flow.
- `GEMINI_ESCALATE_CONFIDENCE = 0.45` — confidence below this escalates ([config.py:466](app/config.py#L466)).
- `SEMANTIC_CHECK_ESCALATION = True` — escalate every `check`/`mistake_id` turn ([config.py:579](app/config.py#L579)).
- Skip-tier jump constants live in `orchestrator`: `_ESCALATE_QUERY_TYPES = {"derivation","calc","mistake_id"}`, `_ESCALATE_STATUSES = {"truncated"}` ([orchestrator.py:1465-1466](app/services/orchestrator.py#L1465)).

### 5.4 Claude timeout-fallback

- `CLAUDE_TIMEOUT_FALLBACK = True` ([config.py:51](app/config.py#L51)). Armed by default; when the primary is gemini, the orchestrator builds `self._llm_fallback = get_llm_provider("claude")` ([orchestrator.py:70-76](app/services/orchestrator.py#L70)).
- `_FALLBACK_STATUSES = {"timeout","rate_limited","upstream_unavailable"}` — the **only** statuses that trigger a Claude re-run ([orchestrator.py:1479](app/services/orchestrator.py#L1479)). `error`, `bad_json`, `safety_block` are deliberately excluded ([orchestrator.py:1470-1478](app/services/orchestrator.py#L1470)).

### 5.5 Pre-router

- `PREROUTE_ENABLED = True`, `PREROUTE_STT_ENABLED = True`, `PREROUTE_IMAGE_QUALITY_GATE = True` ([config.py:605-612](app/config.py#L605)).
- Image-quality floors: `PREROUTE_BLUR_MIN = 30.0` (variance-of-Laplacian), `PREROUTE_MIN_DIM_PX = 240` (short side), `PREROUTE_LUMA_MIN = 22.0` (mean brightness) ([config.py:625-627](app/config.py#L625)).

### 5.6 Problem-memo / solve-reveal policy

- `SOLVE_MIN_NUDGES = 1` — nudges required before a hard surrender is honored ([config.py:520](app/config.py#L520)).
- `SOLVE_NUDGE_THRESHOLD = 2` — nudges required for the inferred-frustration reveal path ([config.py:583](app/config.py#L583)). *(Lowered 3 → 2 on 2026-06-22 so a persistently stuck student gets the walkthrough one turn sooner.)*
- `SOLVE_REVEAL_MAX_OUTPUT_TOK = 2500` — output cap for an authorized reveal ([config.py:586](app/config.py#L586)).
- `DISPUTE_GUARD = True` ([config.py:561](app/config.py#L561)).
- `CHECK_VERDICT_GUARD = True` — inject the verdict note when the student asks us to verify work they already have ("is my answer right?") ([config.py:633](app/config.py#L633)).
- `MEMO_CAPTURE_QUESTION = False` — always-on statement-only question capture ([config.py:546](app/config.py#L546)).
- `MEMO_CONSISTENCY_REFUSE = False` — refuse to cache a self-contradicting outline ([config.py:532](app/config.py#L532)).
- Memo internals: `_TTL_S = 30*60`, `_OUTLINE_CAP = 1800`, `_STATEMENT_CAP = 400`, `MIN_STATEMENT_CHARS = 20` ([problem_memo.py:36-40](app/services/problem_memo.py#L36), [L289](app/services/problem_memo.py#L289)).

### 5.7 Dispatch / TFT / TTS / image / debug

- `TFT_SHOW_MODEL_TAG = True` ([config.py:636](app/config.py#L636)); `TFT_PROGRESSIVE_EQUATIONS = True` ([config.py:675](app/config.py#L675)); `TFT_APPEND_EQUATIONS = True` ([config.py:687](app/config.py#L687)).
- `TTS_CHUNK_MODE = "balanced"` ([config.py:158](app/config.py#L158)); `TTS_CHUNK_BYTES = 4096` (= 85 ms @ 24 kHz int16 mono) ([config.py:201](app/config.py#L201)).
- `ENABLE_IMAGE_ENHANCEMENT = True` ([config.py:356](app/config.py#L356)); `LAMP_IMAGE_UNMIRROR = False` ([config.py:368](app/config.py#L368)).
- `EMIT_DEBUG_JSON = True` ([config.py:720](app/config.py#L720)); `DEBUG_PERCEIVED_QUESTION = False` ([config.py:733](app/config.py#L733)).
- `TURN_TRACE_ENABLED = True` ([config.py:276](app/config.py#L276)).
- Dispatch-local constants: `_CAPTION_BYTE_CAP = 200`, `_TTS_FIRST_PIECE_CHARS = 70`, `_TTS_LATER_PIECE_CHARS = 180` ([dispatch.py:459](app/services/dispatch.py#L459), [L533-534](app/services/dispatch.py#L533)).

---

## 6. The Complete Turn Workflow (entry → exit)

This walks `TurnOrchestrator.run_turn(session, images, audio_bytes, image_preps)` ([orchestrator.py:86-1074](app/services/orchestrator.py#L86)) inch by inch. `images` is a list of JPEG payloads (0..MAX images); `audio_bytes` is 16 kHz int16 PCM (audio duration ≈ `len(audio_bytes) / (16_000*2)` s).

### Step 0 — setup (always runs)

1. `t_start = time.monotonic()`; resolve `device_id` via `getattr(session, "device_id", "?")`.
2. `dev_capture.new_turn_dir(device_id)` — creates a per-turn dump folder **up front** (no-op unless `DEV_CAPTURE_DUMP`), so it exists even if the LLM later fails ([orchestrator.py:109-113](app/services/orchestrator.py#L109)).
3. Build the `TurnTracer(source="lamp", device_id, user_id, session_id)` and `tracer.mark(capture_latency_ms=session.last_capture_ms)` + a `"capture"` note ([orchestrator.py:128-143](app/services/orchestrator.py#L128)).

Everything from here to the persist call is inside one big `try/except CancelledError/except Exception/finally` ([orchestrator.py:146-1072](app/services/orchestrator.py#L146)).

### Step 1 — `STATE(thinking)`

`await session.send_state(StateByte.THINKING)` — lamp shows the spinner ([orchestrator.py:148](app/services/orchestrator.py#L148)).

### Step 2 — memory load (Layer 3), backgrounded

**Changed 2026-07-04** ("added memory leak protection and cpu crash"): the history load is now kicked off as a **background task** here, not awaited yet — `history_task = asyncio.create_task(self._load_history(session))` ([orchestrator.py:206](app/services/orchestrator.py#L206)). It used to be a blocking `await` right at turn start, serialized BEFORE the STT transcript (Step 3) and image enhancement (Step 4). Backgrounding it lets its ~200-600 ms cross-region (Supabase/Redis) latency overlap with — be hidden behind — the STT + image work that runs next, instead of adding on top of it. Because `_load_history` swallows ALL its own errors (its internal 2 s cap degrades to a stateless sentinel — see below), this task can never raise, so it's safe to leave un-awaited across the zero-LLM retake / safety short-circuits that return before its first real use.

The task is actually `await`-ed later, at its first use point — see Step 6 below, where `tracer.phase("memory_load", ...)` now wraps just that tail-wait rather than the whole load.

`_load_history` ([orchestrator.py:1623-1651](app/services/orchestrator.py#L1623)) reads the last 3 turns from Supabase via `session_memory.load_context(device_id, user_id, session_id)` — the full 3-layer context (L3 learner profile + L2 session summary + L1 recent verbatim) — under a **hard 2 s `asyncio.wait_for` cap**. On timeout or any error it degrades to the placeholder `"[Session start — no prior turns]"` rather than stalling the learner.

### Step 3 — pre-router STT kickoff (concurrent)

If `PREROUTE_ENABLED and PREROUTE_STT_ENABLED and audio_bytes`, spawn `preroute_text_task = asyncio.create_task(_safe_preroute_stt(audio_bytes, tracer))` **here** so the Groq-Whisper transcript (~200 ms) runs CONCURRENTLY with image enhancement ([orchestrator.py:173-177](app/services/orchestrator.py#L173)).

`_safe_preroute_stt` ([orchestrator.py:1425-1454](app/services/orchestrator.py#L1425)) calls `llm_claude._stt_via_groq` under a **1.2 s `wait_for`**; any failure (no `GROQ_API_KEY`, SDK missing, slow) returns `""` and routing degrades to the image-quality gate + heuristics. It records `stt_latency_ms` + a note. **Whisper is used only for routing** — the answering tier still re-transcribes audio internally.

### Step 4 — image prep / enhancement

Two mutually-exclusive paths:

**(a) Early-prep harvest** ([orchestrator.py:179-223](app/services/orchestrator.py#L179)). If `image_preps` was passed and `len(image_preps) == len(images)`: `await asyncio.wait_for(asyncio.gather(*image_preps, return_exceptions=True), timeout=8.0)`. Each prep yields `(enhanced bytes, Files-API ref)`; any per-image exception falls back to that image's raw bytes inline. `image_refs` becomes a list 1:1 with images (None entries → inline). On `TimeoutError` it calls `image_prep.cancel_preps(...)` and falls back to inline (`llm_images, image_refs = images, []`). The work ran while the student spoke, so this await is normally ~0 ms.

**(b) Inline enhancement** ([orchestrator.py:229-262](app/services/orchestrator.py#L229)). Only if `ENABLE_IMAGE_ENHANCEMENT and images and not harvested`: `asyncio.gather` of `asyncio.to_thread(enhance_for_llm, img, unmirror=LAMP_IMAGE_UNMIRROR, stages_out=...)` over each image (N images enhance in N threads in parallel — wall time ≈ slowest single image). `unmirror` flips lamp JPEGs upright (firmware `hmirror=1`). On any exception it swallows and uses raw bytes ([orchestrator.py:254-256](app/services/orchestrator.py#L254)). `stage_dicts` is only allocated when `DEV_CAPTURE` is on.

Then (best-effort, off-loop) `dev_capture.dump_turn_inputs(...)` writes raw + stages + FINAL_ images + audio ([orchestrator.py:264-275](app/services/orchestrator.py#L264)).

### Step 5 — deterministic pre-router

Defaults: `start_tier = 1`, `system_prompt = self._turn1_prompt`, `decision = None`, `preroute_text = ""` ([orchestrator.py:284-289](app/services/orchestrator.py#L284)).

If `PREROUTE_ENABLED` ([orchestrator.py:290-343](app/services/orchestrator.py#L290)):
1. Harvest the STT: `preroute_text = await preroute_text_task` (swallow errors → `""`).
2. If `PREROUTE_IMAGE_QUALITY_GATE and llm_images`: `image_quality = await asyncio.to_thread(assess_image_quality, llm_images)` (fixed 2026-07-04 — `assess_image_quality` is synchronous PIL decode + numpy Laplacian, ~50-150 ms/frame; calling it inline blocked the event loop, stalling every other lamp's WS for that long. Now off-thread — [orchestrator.py:351-353](app/services/orchestrator.py#L351). Same class of fix as the `frontend_manager.py` `/simulate` and `_solve_auto` call sites — doc 01 §… and doc 04 §7.4.).
3. `decision = preroute(preroute_text, image_quality, len(images))`.
4. `tracer.mark(whisper_transcript=...)` + a `"preroute"` note.
5. **Image-quality short-circuit** ([orchestrator.py:319-340](app/services/orchestrator.py#L319)): if `decision.retake_image`, build `retake_image_reply(decision.retake_detail)`, send `STATE(speaking)`, `dispatch_reply(... status="ok", model_tag="  [gate]"...)`, fire-and-forget `tracer.finalize`, and **return** (the `finally` still runs `finalize_turn`). **Zero LLM spend.**
6. Otherwise `start_tier = decision.start_tier` and `system_prompt = self._turn1_prompt + decision.prompt_suffix`.

If `PREROUTE_ENABLED` is False, it cancels the orphaned STT task ([orchestrator.py:344-349](app/services/orchestrator.py#L344)).

### Step 6 — prompt-suffix assembly (deterministic continuity & memo)

In order, the orchestrator appends to `system_prompt`:

1. **Perceived-question suffix** — if `DEBUG_PERCEIVED_QUESTION or MEMO_CAPTURE_QUESTION`, append `PERCEIVED_QUESTION_SUFFIX` ([orchestrator.py:437-439](app/services/orchestrator.py#L437)).
2. **Await the backgrounded history load** (added 2026-07-04 — see Step 2) — `with tracer.phase("memory_load", detail="L3 profile + L2 summary + L1 recent turns"): history_text = await history_task` ([orchestrator.py:450-451](app/services/orchestrator.py#L450)). By now the STT + image harvest/enhance + preroute above have run concurrently with the load, so this typically resolves instantly — the cross-region wait is hidden rather than eliminated. `_hist_has_turns` is derived from `history_text` immediately after ([orchestrator.py:454-455](app/services/orchestrator.py#L454)).
3. **Continuation hint** — if there ARE prior turns (`_hist_has_turns`) AND `preroute_text` AND `is_followup_text(preroute_text)`, append `CONTINUATION_HINT` ([orchestrator.py:463-467](app/services/orchestrator.py#L463)). A short reply-like transcript ("ok what next", "is it 12.5?") must not be re-derived as a fresh problem.
4. **Memo load** — `memo = await problem_memo.load(session.db_session_id)` (errors → None) ([orchestrator.py:505-509](app/services/orchestrator.py#L505)).
5. **Pre-call SOLVE authorization** — `solve_auth_reason = problem_memo.solve_authorized(memo, preroute_text, history_present=...)`; if truthy, append `solve_authorized_note(...)` ([orchestrator.py:510-526](app/services/orchestrator.py#L510)).
6. **Snapshot `sans_key_prompt = system_prompt`** BEFORE injecting the answer key — the escalated re-call must NOT carry the key ([orchestrator.py:533](app/services/orchestrator.py#L533)).
7. **Dispute / answer-key / question-context** ([orchestrator.py:540-601](app/services/orchestrator.py#L540)):
   - `dispute = DISPUTE_GUARD and problem_memo.is_dispute(preroute_text) and history_present`. If so, append `dispute_note(memo.statement)` and (if Pro is built) force `start_tier = 3` — bypassing key suppression entirely.
   - `elif memo:` append `answer_key_block(memo)`. If `start_tier > 1`, **clamp `start_tier → 1`** (flash + key is cheaper than re-solving) ([orchestrator.py:582-587](app/services/orchestrator.py#L582)).
   - `elif MEMO_CAPTURE_QUESTION:` load + inject `question_context_block(qmemo)` if a statement-only memo exists ([orchestrator.py:592-601](app/services/orchestrator.py#L592)).
8. **Check-verdict note** — `if CHECK_VERDICT_GUARD and not solve_auth_reason and not dispute and not reaffirm and problem_memo.is_check_request(preroute_text):` append `check_verdict_note()`. The student is asking us to VERIFY work they already have ("is my answer right?", "am I doing this right?", "check the solution") → give a plain VERDICT this turn (confirm if correct, first error only if wrong), not a Socratic nudge. **Gated behind surrender/dispute/re-affirm** so each keeps its handling; the note explicitly forbids revealing the full solution, never re-derives at Pro, and never counts as a nudge. Additive (coexists with an active answer key) and injected AFTER the `sans_key_prompt` snapshot so it never rides into an escalation re-call.

### Step 7 — first tier call

`tracer.mark(llm_raw_prompt_brief=..., llm_raw_system_prompt=system_prompt)` ([orchestrator.py:459-467](app/services/orchestrator.py#L459)), then:

```python
reply, telemetry = await self._call_tier(
    start_tier, system_prompt=system_prompt, history_text=history_text,
    images=llm_images, audio_bytes=audio_bytes, image_refs=image_refs,
    cap_override=(settings.SOLVE_REVEAL_MAX_OUTPUT_TOK if solve_auth_reason else None),
    preroute_text=preroute_text,
)
telemetry["tier"] = start_tier
```

([orchestrator.py:468-475](app/services/orchestrator.py#L468)). It records `mark_tier`, a `llm_tier{N}` note, and a structured INFO log line.

### Step 8 — the guard stack (each = ≤1 corrective re-call)

In order (full mechanics in [§10](#10-the-guard-stack)):

- **Echo guard** ([orchestrator.py:494-520](app/services/orchestrator.py#L494)) — if `_looks_like_echo(reply.speech, history_text)`, re-call same tier with `_ECHO_GUARD_NOTE`.
- **Focus guard** ([orchestrator.py:522-548](app/services/orchestrator.py#L522)) — if a `focus_label` was named and `focus_mismatch(label, reply.ocr_text)`, re-call same tier with `FOCUS_GUARD_NOTE`.
- **Visual grounding capture** ([orchestrator.py:550-561](app/services/orchestrator.py#L550)) — if `llm_images`, `tracer.mark(extracted_ocr_text=..., bounding_box=clean_bbox(...))`.

### Step 9 — memo identity verdict + nudge accounting

`memo_matched = problem_memo.matched(memo, same_problem=reply.same_problem, reply_subject=reply.subject, current_label=...)` ([orchestrator.py:567-569](app/services/orchestrator.py#L567)).

- If `memo` existed but **not matched** → the student moved on → `problem_memo.clear(...)` (flush the answer key) ([orchestrator.py:570-580](app/services/orchestrator.py#L570)).
- Else if a `qmemo` (question-only) exists and is stale → flush it ([orchestrator.py:583-593](app/services/orchestrator.py#L583)).
- **Post-call SOLVE authorization** — `solve_auth_now = solve_auth_reason or problem_memo.solve_authorized(memo if memo_matched else None, reply.user_input, preroute_text, history_present=...)` ([orchestrator.py:598-604](app/services/orchestrator.py#L598)). The model's `user_input` echo fills the gap when the lamp had no Whisper transcript.
- If `memo` matched: a **reveal** turn calls `problem_memo.touch(...)` (keep TTL, NOT a nudge); a **guidance** turn calls `problem_memo.record_nudge(..., stuck=reply.student_stuck)` ([orchestrator.py:606-616](app/services/orchestrator.py#L606)).

### Step 10 — post-answer escalation

The orchestrator tracks `cur_prompt/cur_history/cur_images/cur_audio/cur_refs` = inputs of the call that produced the CURRENT reply ([orchestrator.py:621-622](app/services/orchestrator.py#L621)). `ceiling = 3 if self._llm_pro else 2`. Full escalation logic in [§8](#8-routing--escalation-algorithms). On success it swaps `cur_*` to the escalation brief inputs; on failure (escalated tier returned non-ok while lower tier was ok) it **REVERTS** to the good lower-tier answer (Fix B, [orchestrator.py:743-761](app/services/orchestrator.py#L743)).

### Step 11 — solution-bleed guard, reveal guard, memo save

- **Solution-bleed guard** ([orchestrator.py:786-851](app/services/orchestrator.py#L786)) — see [§10.3](#103-solution-bleed-guard).
- **Reveal-completeness guard** ([orchestrator.py:853-880](app/services/orchestrator.py#L853)) — see [§10.4](#104-reveal-completeness-guard).
- **Memo save** ([orchestrator.py:882-914](app/services/orchestrator.py#L882)): `final_tier = telemetry.get("tier", start_tier)`. If `final_tier >= 2 and reply.solution_outline.strip()`, `problem_memo.save(...)` with `model=` resolved by tier. Else if `MEMO_CAPTURE_QUESTION`, `problem_memo.save_question(...)` (statement-only). This is why a preroute start at tier-2 ALSO produces a memo (because `_call_tier` appends `SOLVE_SUFFIX` to every tier ≥ 2 call).

### Step 12 — debug emission

`reply_json = reply.model_dump_json()` is logged. If `DEBUG_PERCEIVED_QUESTION`, a `[PERCEIVED Q]` line prints the model's `problem_statement`. `tracer.mark(llm_raw_response, confidence, final_tier, escalated)`. If `capture_dir`, dump the reply JSON. If `EMIT_DEBUG_JSON`, ship a `FrameType.DEBUG_JSON` WS frame BEFORE dispatch (best-effort) ([orchestrator.py:916-960](app/services/orchestrator.py#L916)).

### Step 13 — STATE + dispatch

`llm_failed = telemetry.get("status") not in (None, "ok")`. On failure → `STATE(error)` (red strobe); else `STATE(speaking)` ([orchestrator.py:962-975](app/services/orchestrator.py#L962)). Then inside `tracer.phase("dispatch")`:

```python
await dispatch_reply(session, reply, status=telemetry.get("status") or "ok",
                     model_tag=self._model_tag(telemetry), trace=_dispatch_trace)
```

([orchestrator.py:986-997](app/services/orchestrator.py#L986)). The `_dispatch_trace` dict is filled with `tts_ms` / `latex_ms` and recorded.

### Step 14 — fire-and-forget persist

`total_ms = int((time.monotonic() - t_start)*1000)`; `tracer.mark(status, processing_latency_ms=total_ms)`; then `asyncio.create_task(self._persist_turn(...))` ([orchestrator.py:1008-1020](app/services/orchestrator.py#L1008)). Persistence ([§13](#13-persistence)) never blocks the turn.

### Step 15 — cancel / error / finally

- `except asyncio.CancelledError:` → trace `status="cancelled"`, fire-and-forget `tracer.finalize`, **re-raise** ([orchestrator.py:1022-1033](app/services/orchestrator.py#L1022)).
- `except Exception:` → `tracer.fail(...)` + finalize, then `STATE(error)` + `send_tft_text("Sorry, I had trouble — try again.")` ([orchestrator.py:1034-1052](app/services/orchestrator.py#L1034)).
- `finally:` → **always** `await session.finalize_turn()` (the half-duplex finalizer), log the turn duration, and `gc.collect()` to reclaim matplotlib figures / cv2 arrays / TTS audio before the next turn ([orchestrator.py:1053-1072](app/services/orchestrator.py#L1053)). The cancel path skips `finalize_turn` cleanup because `Session._on_cancel` issues its own cleanup trio.

`run_turn` returns the parsed `LlmReply` on success, or `None` on cancel ([orchestrator.py:1074](app/services/orchestrator.py#L1074)).

---

## 7. The Tier System & `_call_tier`

`_call_tier(tier, *, system_prompt, history_text, images, audio_bytes, image_refs, cap_override, preroute_text)` ([orchestrator.py:1078-1196](app/services/orchestrator.py#L1078)) is the **single choke point** through which the initial call, every escalation re-call, AND every guard corrective re-call pass.

### 7.1 What it does, mechanically

1. **`SOLVE_SUFFIX` injection** — if `tier >= 2`, append `problem_memo.SOLVE_SUFFIX` so the stronger model writes the full solution internally (~150-250 output tokens, paid once per hard problem) ([orchestrator.py:1116-1117](app/services/orchestrator.py#L1116)).
2. **Single-attempt arming** — `armed = self._llm_fallback is not None`; if armed, pass `hard_timeout_s=LLM_HARD_TIMEOUT_S` so the provider sets `allow_retry=False` (fail fast → Claude answers, rather than burning a 2× self-retry) ([orchestrator.py:1119-1127](app/services/orchestrator.py#L1119)). When disarmed the call is byte-identical to pre-fallback behaviour (it doesn't even pass `hard_timeout_s`).
3. **`_ref_kw(provider)`** — forwards `image_refs` ONLY to a gemini provider that actually has non-None refs ([orchestrator.py:1106-1110](app/services/orchestrator.py#L1106)).
4. **Tier dispatch** ([orchestrator.py:1134-1161](app/services/orchestrator.py#L1134)):
   - `tier >= 3 and self._llm_pro is not None` → `self._llm_pro.call(...)` with `thinking_budget=GEMINI_TIER3_THINKING_BUDGET`, `max_output_tokens=max(cap_override or 0, GEMINI_TIER3_MAX_OUTPUT_TOK)`, `hard_timeout_s=GEMINI_TIER3_TIMEOUT_S`.
   - `tier == 2` → base `self._llm.call(...)` with `thinking_budget=512`, `max_output_tokens=max(cap_override or 0, 4000)`.
   - else (tier 1, or tier 3 with no Pro built → clamped) → base `self._llm.call(...)` with `thinking_budget=0`, `max_output_tokens=(cap_override or 900)`.
5. **Claude timeout-fallback** ([orchestrator.py:1163-1196](app/services/orchestrator.py#L1163)): if `armed and telemetry.get("status") in _FALLBACK_STATUSES`, re-run the SAME turn on `self._llm_fallback.call(...)` reusing `system_prompt` (all suffixes/memo/dispute inherited), `history_text`, `images`, `audio_bytes`, `transcript=preroute_text` (no second Groq call), `max_output_tokens=tier_cap`. Tags `telemetry["fallback"]=True`, `telemetry["fallback_from"]=f"gemini-tier{tier}"`. If Claude itself raises (non-Cancelled), it **keeps the Gemini failure result** — the safety net never raises ([orchestrator.py:1188-1195](app/services/orchestrator.py#L1188)).

`cap_override` exists for reveal turns: a full walkthrough doesn't fit the tier-1 nudge cap, so an authorized reveal uses `SOLVE_REVEAL_MAX_OUTPUT_TOK` and the same cap is handed to the Claude fallback ([orchestrator.py:1129-1133](app/services/orchestrator.py#L1129)).

### 7.2 `_tier_model_name` and `_model_tag`

- `_tier_model_name(tier)` returns `self._llm_pro.model` for tier ≥ 3 (when built), else `self._llm.model` ([orchestrator.py:1198-1203](app/services/orchestrator.py#L1198)).
- `_model_tag(telemetry)` builds the tiny TFT-only suffix (NOT spoken, NOT from the prompt) gated by `TFT_SHOW_MODEL_TAG`: `"  [⚡ backup brain · claude]"` on a fallback, else `"  [2.5-flash t1]"`-style after stripping `models/`, `gemini-`, `-preview`, `-latest` ([orchestrator.py:1205-1227](app/services/orchestrator.py#L1205)).

---

## 8. Routing & Escalation Algorithms

### 8.1 PRE-router (`escalation_router.preroute`)

Runs BEFORE any LLM call ([escalation_router.py:391-461](app/services/escalation_router.py#L391)):

1. **Image-quality short-circuit** — only when `PREROUTE_IMAGE_QUALITY_GATE`, an image was sent, the verdict is not-ok, AND `text_is_thin = len(text.split()) < 6`. A strong standalone text question is answered even with a poor incidental photo. On thin text → `retake_image = True` and return ([escalation_router.py:404-421](app/services/escalation_router.py#L404)).
2. `sig = classify_text(text)` and `ceiling = _max_routable_tier()` (3 if `GEMINI_TIER3_ENABLED` else 2).
3. **Focus label** — `d.focus_label = extract_focus_label(text)`.
4. **Hardness → start tier** ([escalation_router.py:431-441](app/services/escalation_router.py#L431)): `extreme` → `min(3, ceiling)`; `hard` → ≥2; `diagram` → ≥2.
5. **MCQ** → ≥2 + `require_option_verification`.
6. **Mistake** ("where did I go wrong") → ≥2 + `require_mistake_localization`.
7. `formula_def` with no escalating signal → stay tier-1.
8. `d.start_tier = min(d.start_tier, ceiling)`.

#### Image-quality metrics (the math)

`assess_image_quality(jpegs)` judges the **best** frame ([escalation_router.py:80-135](app/services/escalation_router.py#L80)). Per frame, decode to float32 grayscale, then:
- `blur = _laplacian_variance(gray)` — variance of the discrete Laplacian computed with numpy `roll` shifts (`-4·g + up + down + left + right`), 1px border trimmed because roll wraps ([escalation_router.py:63-77](app/services/escalation_router.py#L63)). Low variance = blurry.
- `min_dim = min(h, w)`, `luma = gray.mean()`.

Rejection rules (first match wins per frame):
- **too_small**: `min_dim < PREROUTE_MIN_DIM_PX (240)` **AND** `blur < PREROUTE_BLUR_MIN*4 (120)` — small is only rejected when it is *also* not clearly sharp ([escalation_router.py:109-113](app/services/escalation_router.py#L109)).
- **too_dark**: `luma < PREROUTE_LUMA_MIN (22.0)`. There is deliberately **no too-bright gate** ([escalation_router.py:114-121](app/services/escalation_router.py#L114)).
- **blurry**: `blur < PREROUTE_BLUR_MIN (30.0)`.
- else → a good frame exists, return `ok=True` immediately.

If no frame decodes, return `ok=True` (don't block on a decode quirk) ([escalation_router.py:133-135](app/services/escalation_router.py#L133)).

#### Text classification regexes

`classify_text` runs six case-insensitive word-boundary regexes ([escalation_router.py:141-216](app/services/escalation_router.py#L141)):
- `_HARD_PATTERNS`: `prove|proof|derive|derivation|from first principles|multi-step|integer-type|integer answer|rigoro|generalize|show that`.
- `_EXTREME_PATTERNS`: `jee-advanced|olympiad|imo|inpho|incho|putnam|jee advanced level`.
- `_DIAGRAM_PATTERNS`: `circuit|free-body|fbd|ray diagram|graph|plot|diagram|figure|geometry|triangle|vector field`.
- `_MISTAKE_PATTERNS`: the "where did I go wrong / check my work" family.
- MCQ: `_MCQ_PHRASE` OR ≥2 `_MCQ_OPTION_STEM` matches.
- `_FORMULA_DEF_PATTERNS`: `what is the formula|define|definition of|…`.

#### Focus extraction

`extract_focus_label("question 5 part b") → "Q5(B)"`, `"q. 12" → "Q12"` ([escalation_router.py:225-246](app/services/escalation_router.py#L225)). `label_number("Q5(B)") → "5"` — parts share the number ([escalation_router.py:249-253](app/services/escalation_router.py#L249)).

### 8.2 POST-answer escalation (`_should_escalate` + the run_turn branch)

`_should_escalate(reply, telemetry)` ([orchestrator.py:1522-1547](app/services/orchestrator.py#L1522)) returns True iff ANY of:
1. `telemetry.status in _ESCALATE_STATUSES` (i.e. `"truncated"` — the model literally ran out of room).
2. On a successful tier-1 only: `reply.confidence < GEMINI_ESCALATE_CONFIDENCE (0.45)`.
3. `reply.difficulty == "hard" and reply.query_type in {"derivation","calc","mistake_id"}`.
4. `SEMANTIC_CHECK_ESCALATION and reply.query_type in {"check","mistake_id"}` — escalate every check (the model's self-rating is untrustworthy here). Returns `False` early on actual errors (timeout/safety) so it doesn't compound ([orchestrator.py:1529-1530](app/services/orchestrator.py#L1529)).

The actual escalation branch ([orchestrator.py:643-784](app/services/orchestrator.py#L643)) gates on a conjunction:

```
GEMINI_DYNAMIC_THINKING and start_tier < ceiling
and not telemetry.get("fallback")          # Claude already answered → final
and (_should_escalate(reply, telemetry) or _sem_dispute)
and (not memo_matched
     or telemetry.status in _ESCALATE_STATUSES
     or reply.confidence < 0.3
     or _sem_dispute)
```

Notes:
- **Claude fallback is final** — climbing a higher Gemini tier would hit the same dead model ([orchestrator.py:644-647](app/services/orchestrator.py#L644)).
- **Keyed suppression** — while a matched answer key is active, escalation is suppressed UNLESS truncated, OR keyed `confidence < 0.3` (a model holding the correct key is never hopeless → the key doesn't actually apply, a self-healing stale-memo escape), OR semantic dispute ([orchestrator.py:638-652](app/services/orchestrator.py#L638)).
- **Semantic dispute** — `_sem_dispute = DISPUTE_GUARD and not dispute and history_present and self._llm_pro and reply.student_disputes_prior` ([orchestrator.py:632-634](app/services/orchestrator.py#L632)). The model itself flags a challenge to our prior answer → promote to a fresh Pro re-derivation (dispute note, no key), overriding memo suppression.

**Skip-tier jump** ([orchestrator.py:661-669](app/services/orchestrator.py#L661)): `next_tier = start_tier + 1` normally, but `next_tier = 3` directly when `start_tier == 1 and ceiling >= 3 and (status in _ESCALATE_STATUSES OR difficulty == "hard" OR confidence <= 0.30 OR _sem_dispute)`. Hard problems and maximal-failure signals go STRAIGHT to Pro because Flash-with-thinking (tier 2) is not a useful middle hop on hard problems (observed twice in prod 2026-06-11).

The orchestrator sends `session.send_tft_text("\x02Thinking harder")` — the `\x02` prefix marks it as a THINKING-spinner caption so the lamp updates in place rather than treating it as the answer card ([orchestrator.py:670-677](app/services/orchestrator.py#L670)).

**Flash→Pro handoff brief** ([orchestrator.py:692-722](app/services/orchestrator.py#L692)): if `_stmt = problem_memo.usable_statement(reply.problem_statement)` is non-empty (≥ 20 chars), the escalated call receives the **text brief** instead of raw audio: `esc_history = problem_memo.escalation_brief(...)`, `esc_audio = b""` (already transcribed), and the image rides along ONLY if `reply.image_needed` — saving audio + image input tokens at the stronger model's rates. An empty/degenerate statement falls back to the full original inputs (never escalate on less signal than tier-1 had). When the image IS forwarded, the re-call reuses the same Files-API refs (upload paid once per turn).

`_esc_prompt = sans_key_prompt` (the stronger model never sees the stale/being-redone key); on a semantic dispute it appends `dispute_note(...)`. The escalated re-call goes through `_call_tier(next_tier, ...)`. After it, the **escalation-must-not-downgrade revert** (Fix B) applies if the escalated tier failed but the previous tier was ok ([orchestrator.py:743-761](app/services/orchestrator.py#L743)).

---

## 9. The Problem Memo (solve-once, tutor-many)

[problem_memo.py](app/services/problem_memo.py). A student grinds one problem across many turns. Without a memo every hard follow-up re-pays the Pro call just for one Socratic nudge. The memo caches the verified solution (Redis, per session, single slot, 30-min TTL) and injects it into later tier-1 turns as an `[INTERNAL ANSWER KEY]`, so flash nudges with Pro-grade ground truth at flash prices, and escalation is suppressed while the key is active ([problem_memo.py:1-25](app/services/problem_memo.py#L1)). **Fail-open everywhere** — no Redis → no memo → pre-memo behavior, never an error.

### 9.1 Lifecycle functions

- `save(session_id, *, problem_statement, solution_outline, model, tier, subject, focus_label)` ([L47-94](app/services/problem_memo.py#L47)) — overwrites the slot, only when an outline exists. Runs `answer_path_contradiction` first; if `MEMO_CONSISTENCY_REFUSE`, refuses to cache a self-contradicting key (next turn re-escalates). Resets `nudges=0, stuck=False`.
- `load(session_id)` ([L97-107](app/services/problem_memo.py#L97)) — returns the memo only if it has an `outline` (answer-key-only).
- `load_question` / `save_question` ([L110-154](app/services/problem_memo.py#L110)) — statement-only (no outline) capture for `MEMO_CAPTURE_QUESTION`; never downgrades a solved memo.
- `touch` ([L179-189](app/services/problem_memo.py#L179)) — refresh TTL on a matched reveal turn (not a nudge).
- `record_nudge(..., stuck=)` ([L192-207](app/services/problem_memo.py#L192)) — `nudges += 1`, store `stuck`, restart TTL.
- `clear` ([L210-214](app/services/problem_memo.py#L210)) — delete the slot.

### 9.2 `matched` — the identity verdict (with two backstops)

[problem_memo.py:217-247](app/services/problem_memo.py#L217). Over the model's `same_problem` flag:
- `same_problem is False` → not matched.
- **LABEL BACKSTOP** (strongest, model gets no vote): if both the memo's label and the current label carry a number and they differ (`\d{1,3}` mismatch) → not matched. Parts share the number, so `Q5` vs `Q5(B)` stays matched.
- **SUBJECT BACKSTOP**: if the model says same but classifies a different subject (neither `"other"`) → stale.
- Otherwise → matched.

### 9.3 The reveal policy — `solve_authorized`

[problem_memo.py:503-530](app/services/problem_memo.py#L503). Deterministic (the LLM never decides reveal alone). Returns `""` (stay Socratic) or a reason tag:

- **With a memo** (per-problem state exists): hard surrender (`wants_full_solution`) counts only after `nudges >= SOLVE_MIN_NUDGES (1)`; soft frustration (`frustration_cue`) OR the stored `memo.stuck` authorizes only after `nudges >= SOLVE_NUDGE_THRESHOLD (2)`.
- **Without a memo** (never escalated, no counter): hard surrender is honored only when `history_present` (never on a cold first attempt).

`wants_full_solution` matches `_GIVEUP_RE` (unmistakable surrender: "i give up", "just tell me", "what's the final answer") ([L354-384](app/services/problem_memo.py#L354)). `frustration_cue` matches `_FRUSTRATION_RE` (soft: "idk", "i'm stuck", "this is too hard") — never an instant reveal ([L368-390](app/services/problem_memo.py#L368)). When authorized, `solve_authorized_note(reason, nudges)` injects the SOLVE-mode switch with an empathetic-transition instruction ([L533-556](app/services/problem_memo.py#L533)).

### 9.4 Dispute detection

`is_dispute(*texts)` ([L455-468](app/services/problem_memo.py#L455)): matches the broad `_DISPUTE_RE` ("that's wrong", "are you sure", "recheck", "i got a different answer", …) BUT suppresses when the text is clearly **own-work verification** (`_OWN_WORK_CHECK_RE`: "check my working", "is my answer right") AND carries no hard "your answer is wrong" marker (`_HARD_DISPUTE_RE`). Own-work checks are a CHECK (tier-2 verify path), not a dispute (tier-3 fresh re-derive). `dispute_note(statement)` forces an INDEPENDENT from-scratch re-solve that distrusts every prior answer and verifies by substitution ([L471-500](app/services/problem_memo.py#L471)).

### 9.5 Check-verdict detection (the "is my answer right?" reliability fix)

`is_check_request(*texts)`: True when the student asks us to **verify work they already have** — a request for a VERDICT, not a nudge and not a solve. Superset of `_OWN_WORK_CHECK_RE` plus `_CHECK_REQUEST_RE` for the phrasings it misses ("am I doing this right?", bare "check the solution/answer/working", "did I solve it right"). When it fires (and the turn is NOT a surrender, dispute, or re-affirm), `check_verdict_note()` is injected — the **deterministic counterpart to the prompt's RULE 4 verdict carve-out**, so the verdict behavior no longer depends on the model choosing to follow prompt guidance. The note enforces verify-before-accuse, confirm-and-stop when correct, first-error-only when wrong, "ask for their answer if you can't see it," and the anti-flip-flop same-verdict rule — and it **explicitly forbids revealing the full solution** (state isolation + nudge gate untouched). Toggle: `CHECK_VERDICT_GUARD` (default `True`). Note: detection keys off the transcribed `preroute_text`, so a lamp turn with no STT falls back to the prompt-only verdict rule.

### 9.5 Leak / consistency detectors (the math)

Helpers normalize math for fuzzy comparison:
- `_normalize_math(s)` — lowercase, strip `\left/\right`, `\cmd → cmd`, drop whitespace/`${}()[]\,;:!` ([L566-573](app/services/problem_memo.py#L566)).
- `_distinctive_numbers(s)` — tokens with ≥2 digits or any decimal/fraction (`\d+(?:[.,/]\d+)+|\d{2,}`). Single digits never count ([L576-580](app/services/problem_memo.py#L576)).

- **`answer_path_contradiction(outline)`** ([L587-628](app/services/problem_memo.py#L587)) — the memo-poison gate. Precision-biased to ~zero false positives: fires ONLY when the `ANSWER:` is a clean 2-4-digit integer (no LaTeX structure), the `PATH:` is a numeric derivation, AND that integer appears nowhere else in the outline.
- **`solution_bleed(outline, speech, display_content, *, problem_statement)`** ([L631-673](app/services/problem_memo.py#L631)) — returns a machine tag when the user channels leaked the answer:
  - `answer_verbatim`: normalized `ANSWER` (len ≥ 4) appears in `speech\ndisplay`.
  - `answer_number:N`: a distinctive answer number (minus GIVEN values from the statement) appears in the user text.
  - `derivation_dump`: ≥3 enumerated step markers (`_STEP_MARK_RE`).
  - `derivation_dump_latex`: ≥4 `\\` row breaks (web KaTeX only — the lamp's mathtext forbids `\\`, so lamp turns can't false-positive).
  - `boxed_answer`: a `\boxed{...}`.
  - The DUMP checks are outline-independent so they also catch a confident tier-1 turn never asked to solve.
- **`reveal_incomplete(outline, speech, display_content)`** ([L676-706](app/services/problem_memo.py#L676)) — mirror image: True when a SOLVE-authorized reply walked the method but OMITTED the answer value (compares both normalized and raw spellings, because brace stripping can glue digits).

### 9.6 Prompt blocks the memo injects

`answer_key_block` ([L250-277](app/services/problem_memo.py#L250)), `question_context_block` ([L157-176](app/services/problem_memo.py#L157)), `escalation_brief` ([L299-332](app/services/problem_memo.py#L299)), `dispute_note`, `solve_authorized_note`, and the guard notes `SOLUTION_GUARD_NOTE` ([L724-734](app/services/problem_memo.py#L724)) and `REVEAL_GUARD_NOTE` ([L711-719](app/services/problem_memo.py#L711)). The big one is `SOLVE_SUFFIX` ([L745-804](app/services/problem_memo.py#L745)) — appended to every tier ≥ 2 call; it instructs the model to fully solve internally, fill `problem_statement` + `solution_outline` in the labeled `TYPE/KEY IDEA/FORMULAS/PATH/ANSWER/PITFALLS` format (multipart per (a)/(b)/(c)), verify numerics BY CODE when a tool is available, and keep STATE ISOLATION (no answer in user channels).

---

## 10. The Guard Stack

All five guards share the same philosophy: a deterministic detector that triggers **exactly ONE** corrective re-call, paid only when the failure actually occurred.

### 10.1 Echo guard

`_looks_like_echo(speech, history_text)` ([orchestrator.py:1481-1508](app/services/orchestrator.py#L1481)). Uses **4-word shingle containment** against each `"You answered: …"` segment in the injected history: build the set of 4-grams of the reply (require ≥10), and for each prior reply segment (also ≥10 shingles), if `len(cur & prev) / min(len(cur), len(prev)) >= 0.5` → echo. Copied sentences share long word runs; a genuinely fresh reply on the same topic shares almost none. On a trip, re-call same tier with `_ECHO_GUARD_NOTE` ([orchestrator.py:1511-1519](app/services/orchestrator.py#L1511)).

### 10.2 Focus guard

`focus_mismatch(target_label, ocr_text)` ([escalation_router.py:256-266](app/services/escalation_router.py#L256)). The student named question N (`label_number`), but the model's `ocr_text` self-report lists only OTHER question numbers (and at least one number is present). An `ocr_text` mentioning the target anywhere passes (cross-references are legitimate). On a trip, re-call same tier with `FOCUS_GUARD_NOTE.format(target=, seen=)` ([orchestrator.py:528-548](app/services/orchestrator.py#L528)).

### 10.3 Solution-bleed guard

[orchestrator.py:786-851](app/services/orchestrator.py#L786). Picks the outline/statement to check by tier: `final_tier >= 2` uses the reply's own `solution_outline`/`problem_statement`; a keyed matched tier-1 uses the memo's `outline`/`statement`; otherwise nothing. Calls `problem_memo.solution_bleed(...)`. **Stands down only on a system-level authorization** (`solve_auth_now`) — raw surrender words alone no longer lift the guard, so a first-attempt "just tell me" still gets a nudge ([orchestrator.py:811-814](app/services/orchestrator.py#L811)). On a trip, re-call `final_tier` with `cur_prompt + SOLUTION_GUARD_NOTE` using the `cur_*` inputs. The corrective re-call may skip the internal solve, so it preserves the first pass's `solution_outline`/`problem_statement` so the memo still gets ground truth ([orchestrator.py:837-840](app/services/orchestrator.py#L837)).

### 10.4 Reveal-completeness guard

[orchestrator.py:853-880](app/services/orchestrator.py#L853). Only when `status ok AND solve_auth_now AND memo_matched AND memo`. Builds `_chan = display.content + "\n" + "\n".join(latex_equations)` and checks `problem_memo.reveal_incomplete(memo.outline, reply.speech, _chan)`. On a trip, re-call `final_tier` with `REVEAL_GUARD_NOTE` and `cap_override=SOLVE_REVEAL_MAX_OUTPUT_TOK`.

### 10.5 Dispute guard (two flavors)

- **Regex dispute** (`dispute`, [orchestrator.py:416-425](app/services/orchestrator.py#L416)) — pre-call; forces `start_tier = 3` (if Pro built) and injects `dispute_note`, bypassing key suppression.
- **Semantic dispute** (`_sem_dispute`, [orchestrator.py:632-634](app/services/orchestrator.py#L632)) — post-call, driven by `reply.student_disputes_prior`; forces the escalation to the ceiling with the dispute note. A dispute WINS over the check/false-alarm escalation (forces tier-3, not 2).

### 10.6 Open-start / first-step guard (NEW 2026-07-03)

[orchestrator.py:759-781](app/services/orchestrator.py#L759). Fixes "nudges starting mid-solution on open-ended queries." When `OPEN_START_GUARD` and the turn was flagged `_open_start_turn` (the pre-router's `is_open_start_request` fired, e.g. "help me start this") and `problem_memo.mid_solution_without_orientation(...)` detects the reply jumped into the middle of a solution without orienting the student, it re-calls the same tier once with `START_GUARD_NOTE`. Stands down if the focus/echo guard already re-called this turn. Related pre-router pieces: `START_HINT` (injected when open-start is detected) and the tier-2 headroom bump `start_tier = max(start_tier, 2)`.

### 10.7 MCQ option-completeness guard (NEW 2026-07-03)

[orchestrator.py:1150-1184](app/services/orchestrator.py#L1150). Memo-independent. When `OPTION_COMPLETENESS_GUARD` is on and `problem_memo.option_reveal_incomplete(...)` finds a multiple-choice answer that named a letter/option without stating the actual chosen value (or vice-versa), it re-calls `final_tier` once with `OPTION_GUARD_NOTE`. Pairs with the pre-router's `require_option_verification` (MCQ → tier-2) and the reply's new `is_mcq` field. Objective questions (MSQ / true-false / fill-in) instead route to a **direct verdict** rather than a Socratic nudge — see [04-escalation-and-model-selection.md](04-escalation-and-model-selection.md) (`_OBJECTIVE_VERDICT_SUFFIX`).

### 10.8 Input-safety short-circuit, math verifier & output validator

Three deterministic checks from the guardrail layer are wired into `run_turn` (full detail in [doc 11](11-output-validator-guardrails-and-verifier.md)):
- **Input-safety short-circuit** ([orchestrator.py:394-415](app/services/orchestrator.py#L394)) — after the pre-router, `input_guard.screen_input` classifies the transcript; a distress/harm/sexual verdict dispatches `input_guard.safe_reply` at **zero LLM spend** and returns; an injection attempt is only FLAGGED (the deterministic reveal gate is never weakened). Gated `SAFETY_GUARD_ENABLED`.
- **Math verifier** ([orchestrator.py:886-905](app/services/orchestrator.py#L886)) — gated `MATH_VERIFY_ENABLED`; runs `math_verifier.verify` in a thread, time-boxed by `MATH_VERIFY_TIMEOUT_S`, fail-open. Its DISAGREEMENT (`_verify_disagree`) becomes an escalation SIGNAL feeding the gate at [:907-920](app/services/orchestrator.py#L907), never a replacement answer.
- **Output validator** ([orchestrator.py:1320-1335](app/services/orchestrator.py#L1320)) — gated `OUTPUT_VALIDATOR_ENABLED` and ok status, immediately before `dispatch_reply`; `output_validator.validate(reply, ..., surface="lamp")` strips stray LaTeX from the voice, trims over-long speech, flags unrenderable equations, and swaps an unsafe reply. Fail-open.
- **Per-turn LLM-call budget** — every real tier call funnels through `_tier_call` ([orchestrator.py:658-666](app/services/orchestrator.py#L658)), which stamps a cumulative count into telemetry; the escalation gate refuses to climb once `llm_calls >= MAX_LLM_CALLS_PER_TURN` (default 6).

---

## 11. Reply Dispatch (`dispatch.py`)

`dispatch_reply(session, reply, *, status="ok", model_tag="", trace=None, error_detail=None)` ([dispatch.py:71](app/services/dispatch.py#L71)) is **Layer 5.3 middleware** — the single source of truth for backend→lamp per-turn frame ordering. It does NOT touch `STATE` bytes or `AUDIO_OUT_END` (the orchestrator brackets dispatch with half-duplex setup/teardown).

> **Updated 2026-07-03 — `dispatch.py` grew +753 lines and now selects one of THREE dispatch modes** by config flag (the legacy parallel path below is the fallback):
> - **Scroll-document mode** (`_dispatch_document_mode`, [dispatch.py:761-894](app/services/dispatch.py#L761), gated `TFT_SCROLL_DOC`) — pre-composes an ordered block document (text + equations + graph + chemistry, via `providers/document.py`) during TTS synthesis, reveals the manifest on first audio, and interleaves element JPEGs with audio pacing. See [06-tts-and-media.md](06-tts-and-media.md) §6.5.
> - **Sync-to-audio mode** (`_dispatch_synced`, [dispatch.py:258-585](app/services/dispatch.py#L258), gated `TFT_SYNC_TO_AUDIO`) — holds the text + LaTeX reveal until first audio, pre-streams equation pixels, supports a JPEG equation codec (`TFT_IMAGE_CODEC="jpeg"`), and runs the **graph leg** (`_graph_leg`, [:516-544](app/services/dispatch.py#L516)) and **structure leg** (`_structure_leg`).
> - **Default legacy-parallel mode** ([dispatch.py:174-219](app/services/dispatch.py#L174)) — the instant-TFT-text + skeleton + `asyncio.gather(audio, TFT, structure)` path documented below.
>
> Two new content legs run across the modes: the **graph leg** (`GRAPH_ENABLED` → `graph_renderer` → `send_graph_jpeg`/`TFT_GRAPH_JPEG`) and the **chemistry structure leg** (`_dispatch_structure_leg`, [dispatch.py:897-942](app/services/dispatch.py#L897), `CHEM_STRUCTURE_ENABLED` → `rdkit_renderer` → `send_chem_jpeg`/`TFT_CHEM_JPEG`, capped at `MAX_STRUCTURES`, fail-open per step). Both are documented in [06-tts-and-media.md](06-tts-and-media.md) §6.3–6.4.

### 11.1 The dispatch graph

1. **INSTANT TFT_TEXT** — always sent, regardless of status, so the lamp stops the spinner ASAP. Payload = `_scrub_math_markup(_text_card_payload(reply))` + `model_tag` ([dispatch.py:93-109](app/services/dispatch.py#L93)).
2. **LaTeX skeleton** — only when `is_ok AND any non-empty latex_equations`: `send_tft_latex_loading()` ([dispatch.py:111-118](app/services/dispatch.py#L111)).
3. **PARALLEL legs** — `asyncio.gather(_timed("tts_ms", _dispatch_audio_leg(...)), _timed("latex_ms", _dispatch_tft_leg(...)))` ([dispatch.py:127-146](app/services/dispatch.py#L127)). The `audio_done = asyncio.Event()` coordinates the two (see below).

### 11.2 Status-driven gating

`status` (from telemetry) controls three suppressions ([dispatch.py:60-85](app/services/dispatch.py#L60)):
- `status != "ok"` → **SKIP TTS entirely** (error speech is visual-only, paired with the red LED — saves TTS $ and avoids the false UX of the AI "talking" when it failed).
- `status != "ok"` → **SKIP the LaTeX skeleton** (error replies have no meaningful LaTeX).
- STILL send TFT_TEXT with the error fallback text so the user can READ what went wrong.

### 11.3 `_text_card_payload` (the three UX modes)

[dispatch.py:487-524](app/services/dispatch.py#L487):
- `kind == "text"` → FULL `display.content` (up to ~1900 B, capped by `Session.send_tft_text`). Empty content falls through to caption-from-speech.
- `kind in ("latex","none")` → `reply.speech` as a ≤ `_CAPTION_BYTE_CAP` (200) teaser, word-boundary cut.

`_scrub_math_markup` ([dispatch.py:462-484](app/services/dispatch.py#L462)) is a safety net that strips LaTeX markup leaked into prose ("$\int x^2$" → "int x^2") and logs a WARN (it is NOT a renderer; equations belong in `latex_equations[]`). Fast no-op path when there's no `$` or `\`.

### 11.4 Audio leg

`_dispatch_audio_leg` ([dispatch.py:149-186](app/services/dispatch.py#L149)) wraps `_audio_leg_impl` and ALWAYS signals `done_evt` on the way out (skip/success/error/cancel) so the TFT leg can release deferred equations. It sends `AUDIO_OUT_END` the moment the stream ends (BEFORE `done_evt`), because bytes are FIFO on the socket — if END waited for `finalize_turn` it would queue behind a 70-140 KB equation segment and reach the lamp seconds late (speaker holds I2S, mic deaf). The lamp tolerates the duplicate END from `finalize_turn`.

`_audio_leg_impl` ([dispatch.py:188-265](app/services/dispatch.py#L188)) — Layer 7 TTS. Three guards in order: non-ok status → skip; empty/whitespace speech → skip; TTS unavailable → skip gracefully (lamp stays silent, still shows text + LaTeX). Provider-agnostic via `get_tts_provider()` (`TTS_PROVIDER = cartesia | gemini | piper`, default `cartesia`). For an incremental provider (Cartesia/Piper) it feeds `tts.synthesize(speech)` directly; for a whole-utterance provider it wraps in `_sentence_streamed` so first audio tracks the first clause. Streams via `session.stream_audio_out_iter(...)`. `CancelledError` propagates; `TTSError`/`Exception` → visual-only.

`_tts_chunks` ([dispatch.py:537-569](app/services/dispatch.py#L537)) splits at clause boundaries by `TTS_CHUNK_MODE`: `"single"` → one piece; `"hybrid"` → first short clause + the rest merged (2 calls, fast first audio); `"full"` → ~180-char pieces. `_sentence_streamed` ([dispatch.py:572-619](app/services/dispatch.py#L572)) does one-ahead prefetch (synthesize piece N+1 while pacing piece N), skips failed pieces, cancels all in-flight tasks on `CancelledError`.

### 11.5 TFT / LaTeX leg

`_dispatch_tft_leg` ([dispatch.py:268-296](app/services/dispatch.py#L268)) — non-ok short-circuits. Equations now live in `reply.latex_equations` (orthogonal to `display.kind`). If equations → `_dispatch_equations(session, equations, audio_done)`; else the text card was already sent.

`_dispatch_equations` ([dispatch.py:299-451](app/services/dispatch.py#L299)) packs all equations into one multi-frame `TFT_FRAME` (L/R navigable). It is defensive on every failure (per-equation render errors fall back to `[render error]` placeholder frames so indices stay aligned). Each equation renders in a worker thread via `render_one_equation_cached` (matplotlib is synchronous CPU work; inlining it would starve the parallel TTS leg). A Redis cache hit skips matplotlib.

**Progressive delivery** (`TFT_PROGRESSIVE_EQUATIONS and len(equations) > 1`): after each equation renders, re-ship the cumulative pack (pack output is a byte-prefix of the next pack, so identical bytes overwrite identical bytes). **Audio-first downlink gate**: eq1 ships the moment it renders, but every LATER send waits until `audio_done` is set — on the RTT-capped WAN a mid-speech pack starves the lamp's speaker ring (observed 2026-06-10: 9.2 s gap while 307 KB monopolized the downlink). If eq2+ finished while speech still streamed, it waits on `audio_done` with a **90 s** `wait_for` bound, then ships the remainder ([dispatch.py:382-409](app/services/dispatch.py#L382)). With `TFT_APPEND_EQUATIONS`, later sends carry only the new frames (`full[:6] + full[6 + frames_shipped*frame_size:]`); else a full cumulative re-send.

---

## 12. Turn Tracing (`turn_trace.py`)

The tracer is an **OBSERVER, never a participant** ([turn_trace.py:9-17](app/services/turn_trace.py#L9)): every public method swallows its own errors; `phase(...)` measures the wrapped block but re-raises its exception untouched; persistence is best-effort + bounded; gated by `TURN_TRACE_ENABLED` (off → every call is a no-op).

### 12.1 API

- `phase(name, detail)` → `_Phase` context manager (or `_NULL_PHASE` when disabled) that times the block and `note()`s its duration + outcome; `__exit__` returns `False` so it never swallows the exception ([turn_trace.py:88-129](app/services/turn_trace.py#L88), [L159-166](app/services/turn_trace.py#L159)).
- `note(name, *, ms, status, detail)` — append one storyboard entry (capped: phase ≤80, status ≤24, detail ≤400) ([turn_trace.py:168-181](app/services/turn_trace.py#L168)).
- `mark(**fields)` — set whitelisted scalar columns (text-capped per `_TEXT_CAPS`) or stash everything else in `extra`. None values are skipped, so a typo'd key can never crash the INSERT ([turn_trace.py:183-199](app/services/turn_trace.py#L183)).
- `mark_tier(tier, latency_ms)` — record into `tier{1,2,3}_latency_ms` ([turn_trace.py:201-204](app/services/turn_trace.py#L201)).
- `fail(detail)` — flip `status="error"`, set `error_detail` ([turn_trace.py:206-208](app/services/turn_trace.py#L206)).

### 12.2 `finalize`

[turn_trace.py:212-236](app/services/turn_trace.py#L212). Idempotent (`_finalized` flag). Sets `processing_latency_ms` (if not already), uploads any media the caller didn't link (`_upload_media`, one shared 15 s `_BLOB_TIMEOUT_S` bound), then `_write_row(turn_id)`. `_write_row` ([L280-319](app/services/turn_trace.py#L280)) self-gates on `get_session_factory()`, coerces `session_id`/`turn_id` to UUID (bad/None → NULL), and INSERTs a `TurnTrace` row with `phases` + `extra` JSON. Any failure leaves NULLs / no row — exactly like `blobs.py`/`turns.py`.

`clean_bbox(value)` ([turn_trace.py:69-83](app/services/turn_trace.py#L69)) re-sanitises a model bounding box (exactly 4 numbers → ints clamped 0-1000, ymin<ymax & xmin<xmax, else None) so a future caller can never persist garbage coordinates.

### 12.3 Phases the orchestrator records

`capture` → `memory_load` → `stt_whisper` → `image_enhance` → `preroute` → (`retake_short_circuit`) → `llm_tier1/2/3` → `echo_guard_recall` / `focus_guard_recall` / `solution_bleed_recall` / `reveal_guard_recall` → `dispatch` (with sub-notes `tts_stream` / `latex_render` / `graph_render`). The verbatim system prompt is captured via `llm_raw_system_prompt` (cap 24 000), the prompt delta via `llm_raw_prompt_brief` (cap 6 000), the parsed reply via `llm_raw_response` (cap 20 000).

> **Updated 2026-07-09 → 07-11 — latency instrumentation for the admin Analytics tab.** Two new scalar trace columns were added to `_SCALAR_FIELDS` ([turn_trace.py](app/services/turn_trace.py), and mirrored as additive `turn_traces` columns in `db/session.py`):
>
> - **`model_select_ms`** — the deterministic pre-router / tier-decision time (workflow step 4). Set in the orchestrator from the pre-route timing (`tracer.mark(model_select_ms=…)` alongside the existing `preroute` storyboard note); NULL when the pre-router is short-circuited.
> - **`graph_render_ms`** — server-side plot→JPEG render time (render only, not the WS send) — the screen-render sibling of `latex_latency_ms`; the orchestrator marks it from `_dispatch_trace["graph_ms"]` and adds a `graph_render` note.
>
> The dispatch paths were also taught to record their own render/voice timings so *every* delivery mode feeds the same analytics stages: the **sync-to-audio** path (`_dispatch_synced`) now accumulates equation-render `latex_ms`, real voice `tts_ms`, and `graph_ms` (it previously recorded none of `latex_ms`); the **document-mode** path (`_dispatch_document_mode`) pulls `eq_ms`/`graph_ms` from a `stats` sink threaded into `document.compose(reply, stats=…)` plus its own `tts_ms`. Finally, the orchestrator now persists the provider error string into **`error_detail`** for *graceful* failures (timeout / bad_json / rate_limited / …), not just hard exceptions, so the Analytics "Reason" column (§13 of doc 10) shows *what* broke. These columns feed `_PERF_STAGES` and the per-question rows in [10-formatting-schemas-and-admin.md](10-formatting-schemas-and-admin.md) §13.

---

## 13. Persistence

`_persist_turn(session, reply, telemetry, total_ms, images, audio_bytes, llm_images, tracer)` ([orchestrator.py:1267-1421](app/services/orchestrator.py#L1267)) runs fire-and-forget. It performs:

1. **Raw media upload** (only for `status in (None, "ok")`) — parallel `asyncio.gather` of N `blobs.upload_image` + one `blobs.upload_audio`, under a **15 s** `wait_for`; on timeout/error it stores the turn without media URLs ([orchestrator.py:1296-1325](app/services/orchestrator.py#L1296)).
2. **`extra` block** — `image_count`, `image_urls`, `api_calls` (`2 if escalated else 1`), `timeline` (`[{"step":"model","ms":llm_ms,"where":"server"}]`), and on a fallback turn `fallback`/`fallback_from` ([orchestrator.py:1338-1350](app/services/orchestrator.py#L1338)). The back-compat single `image_url` column gets the first non-None URL; the full list lives in `extra.image_urls` (no schema migration) ([orchestrator.py:1283-1290](app/services/orchestrator.py#L1283)).
3. **Cost estimate** — if `telemetry.cost_usd is None`, fill it best-effort from `model_catalog` using the final call's token counts ([orchestrator.py:1358-1370](app/services/orchestrator.py#L1358)).
4. **`record_turn`** — `session_memory.record_turn(...)` (Supabase `turns` + Redis L1 write-through + L2 compaction). Non-ok turns are dropped inside `record_turn` (error fallbacks never become history). `turn_id` is pre-generated so the trace row can reference it ([orchestrator.py:1372-1386](app/services/orchestrator.py#L1372)).
5. **Trace finalize** — `tracer.mark(raw_image_url, raw_audio_url)` (reuse uploaded URLs), pass the enhanced frame (`llm_images[0]` if it differs from `images[0]`), and `tracer.finalize(turn_id=...)` (turn_id only for ok turns) ([orchestrator.py:1388-1406](app/services/orchestrator.py#L1388)).

`_load_history` reads the same `turns` rows back (the durable source of truth), so no separate hot cache is required ([orchestrator.py:1229-1265](app/services/orchestrator.py#L1229)).

---

## 14. Error Handling, Timeouts, Retries, Fallbacks

| Stage | Timeout / bound | On failure |
|---|---|---|
| History load | 2 s `wait_for` | `"[Session start — no prior turns]"` (stateless turn) |
| Pre-router STT | 1.2 s `wait_for` | `""` → route on image quality + heuristics only |
| Early-prep harvest | 8 s `wait_for` | `cancel_preps` + inline path with raw bytes |
| Inline enhancement | none (threaded) | swallow → raw bytes to the LLM |
| Tier 1/2 LLM call | `LLM_HARD_TIMEOUT_S = 20 s` | telemetry `status` → escalate / fallback / canned reply |
| Tier 3 LLM call | `GEMINI_TIER3_TIMEOUT_S = 38 s` | same |
| Claude fallback | inherits tier cap | keep the Gemini failure result if Claude raises |
| Blob upload (persist) | 15 s `wait_for` | store turn without media URLs |
| Blob upload (trace) | 15 s `_BLOB_TIMEOUT_S` | row keeps NULL URLs |
| Progressive eq wait | 90 s `wait_for` on `audio_done` | ship remaining equations anyway |

**Status → behavior:**
- `None`/`"ok"` → success path.
- `"truncated"` → escalate (in `_ESCALATE_STATUSES`); `STATE(error)`; dispatch suppresses TTS; `_TRUNCATED_REPLY` if surfaced.
- `"timeout"`/`"rate_limited"`/`"upstream_unavailable"` → in `_FALLBACK_STATUSES` → Claude fallback when armed, else canned reply + `STATE(error)`.
- `"error"`/`"bad_json"`/`"safety_block"` → NOT fallback-eligible (client/config faults or model-did-answer-but-malformed); surface as the normal failure ([orchestrator.py:1470-1478](app/services/orchestrator.py#L1470)).

**Escalation-must-not-downgrade (Fix B)** — if the escalated tier returns non-ok but the lower tier was ok, REVERT to the good lower-tier answer (`escalation_reverted = True`) so the student never hears "reply too long / timed out" instead of a perfectly good answer ([orchestrator.py:743-761](app/services/orchestrator.py#L743)).

**Half-duplex invariant** — the `finally` block ALWAYS calls `session.finalize_turn()` so the lamp's I2S TX is released back to the mic, even on error ([orchestrator.py:1053-1060](app/services/orchestrator.py#L1053)). On cancel, the orchestrator re-raises and lets `Session._on_cancel` own the cleanup trio ([session.py:492-517](app/session.py#L492)).

**Tracer never breaks a turn** — every tracer call swallows its own errors; `phase()` re-raises the wrapped block's exception untouched, so the turn flow is byte-for-byte unchanged whether tracing is on or off.

---

## 15. Integration Points / Cross-References

**Calls IN (what invokes the orchestrator):**
- `Session._on_audio_end` (lamp WS path) → `run_turn` ([session.py:473-480](app/session.py#L473)).
- Web simulator → `frontend_manager.py` parity implementation (separate, mirrors the same logic).

**Calls OUT (what the orchestrator + its modules invoke):**
- **Providers** — `get_llm_provider()` / `LlmProvider.call()` ([llm_base.py](app/providers/llm_base.py)); Gemini (`llm_gemini.py`), Claude fallback (`llm_claude.py`, also `_stt_via_groq`), Pro (`self._llm_pro`).
- **Image** — `image_preprocessor.enhance_for_llm`, `image_prep` (early prep + `cancel_preps`).
- **Routing** — `escalation_router` (`preroute`, `assess_image_quality`, `is_followup_text`, `focus_mismatch`, suffixes).
- **Memory** — `session_memory.load_context` / `record_turn`; `cache` (Redis) via `problem_memo`.
- **Output** — `dispatch.dispatch_reply` → `tts_base` (TTS) + `latex_renderer` (matplotlib → RGB565) → `Session.send_*` (WS frames defined in `protocol.py`: `FrameType`, `StateByte`).
- **Storage** — `blobs` (image/audio), `dev_capture` (dev dumps), `db.models.TurnTrace`, `model_catalog` (cost).

**Firmware side (ESP32-S3):** the orchestrator's `STATE`/`TFT_*`/`AUDIO_OUT`/`DEBUG_JSON` frames drive the lamp pages; the `\x02` THINKING caption prefix and the half-duplex `AUDIO_OUT_END` ordering are firmware contracts (HARDWARE_CONTEXT §5.x). Lamp JPEGs arrive left-right mirrored (`hmirror=1`) → `LAMP_IMAGE_UNMIRROR`.

**Frontend / DB:** `turns` (Postgres) feeds the admin dashboard (timeline, cost, tokens, model); `turn_traces` (Postgres) backs `GET /api/frontend/admin/turns/{id}/trace` — the visual pipeline audit with the OCR/bounding-box overlay; the `pgvector` memory store is a TODO hook in `_persist_turn`/`_load_history` ([memory_vec.py:37-38](app/storage/memory_vec.py#L37)).

---

## 16. The Legacy "BAO" Prototype

`turn_handler.py` ([turn_handler.py:1-55](app/services/turn_handler.py#L1)) and `validator.py` ([validator.py:1-64](app/services/validator.py#L1)) are an **earlier, mocked prototype** of the "BAO architecture" (Phase 1-4), NOT the live pipeline. They are documented for completeness; nothing in the lamp/web path calls `handle_turn`.

`handle_turn(session_id, student_profile, audio_stream, image_ref=None)`:
1. **Exam track** — `exam_type = student_profile.get("exam_type","other").lower()`; `exam_track = "technical" if exam_type in ["jee","gate","neet"] else "conceptual"` ([turn_handler.py:18-20](app/services/turn_handler.py#L18)).
2. The LLM call is **mocked** — a hardcoded `llm_response` dict with `is_confident: 0.55` "to force escalation" ([turn_handler.py:25-36](app/services/turn_handler.py#L25)). The comment notes Redis caching + the real Gemini/Groq call are omitted.
3. `validation_res = validate_response(llm_response, exam_track)`.
4. If `action == "escalate"`, simulate a Gemini-Pro escalation by setting `is_confident = 0.9` and prefixing the voice with "I double checked this." then re-validate ([turn_handler.py:41-46](app/services/turn_handler.py#L41)).
5. Return `validation_res["response"]`.

`validate_response(response, exam_track)` ([validator.py:31-63](app/services/validator.py#L31)) runs 6 checks:
- **Check 1 (confidence gate):** `is_confident < 0.60` → `{"action":"escalate"}`. (Distinct from the live `GEMINI_ESCALATE_CONFIDENCE = 0.45`.)
- **Check 2 (track mismatch):** conceptual track + `kind=="latex"` → downgrade to text, strip `$`/`\`.
- **Check 3 (voice symbols):** `clean_voice` strips `\ $ ** # _ $$`.
- **Check 4 (voice length):** > 4 sentences → `trim_to_sentences(…, 4)`.
- **Check 5 (TFT text length):** text card > 200 chars → truncate to 200.
- **Check 6 (LaTeX validity):** technical + `kind=="latex"` + `not is_valid_latex` (brace-balance check) → downgrade to text.

**Key divergences from the live pipeline** (so the reader doesn't confuse them): the prototype uses a `kind=="latex"` display kind (removed from the real `LlmReply` — equations now live in `latex_equations[]`), an `is_confident`/`voice_output`/`tft_display` reply shape (vs `confidence`/`speech`/`display`+`latex_equations`), a single mocked escalation (vs the real multi-tier dispatch + skip-tier jump + Claude fallback), a 0.60 confidence gate (vs 0.45), and no memo, no pre-router, no tracer, no guards, no dispatch. Treat `turn_handler.py`/`validator.py` as historical design intent realized by `orchestrator.py`.

---

## 17. Mermaid Diagrams

### 17.1 One full turn — flowchart

```mermaid
flowchart TD
    A[Session._on_audio_end] --> B[run_turn: setup tracer + capture_dir]
    B --> C["STATE(thinking)"]
    C --> D[memory_load: 2s cap -> history_text]
    D --> E[spawn Groq STT task 1.2s]
    E --> F{image_preps 1:1?}
    F -- yes --> G[early-prep harvest 8s -> enhanced + Files refs]
    F -- no --> H[inline enhance threaded or raw bytes]
    G --> I[PRE-ROUTER]
    H --> I
    I --> J{retake_image?}
    J -- yes --> K[retake_image_reply -> dispatch -> finalize -> RETURN, 0 LLM]
    J -- no --> L[assemble suffixes: continuation, memo key / dispute / question-context]
    L --> M["_call_tier(start_tier)"]
    M --> N{echo guard?}
    N -- trip --> M2[re-call same tier + ECHO note]
    N -- ok --> O{focus guard?}
    M2 --> O
    O -- trip --> M3[re-call same tier + FOCUS note]
    O -- ok --> P[memo matched? + nudge/touch]
    M3 --> P
    P --> Q{should_escalate or sem_dispute?}
    Q -- yes --> R[skip-tier jump? build handoff brief -> _call_tier next_tier]
    R --> S{escalated failed but prev ok?}
    S -- yes --> T[REVERT to good lower-tier answer]
    S -- no --> U[keep escalated]
    Q -- no --> V[no escalation]
    T --> W{solution-bleed guard?}
    U --> W
    V --> W
    W -- trip and not authorized --> W2[re-call + SOLUTION_GUARD note]
    W -- ok --> X{reveal guard? authorized keyed}
    W2 --> X
    X -- trip --> X2[re-call + REVEAL_GUARD note]
    X -- ok --> Y[memo save if tier>=2 + outline]
    X2 --> Y
    Y --> Z{status ok?}
    Z -- no --> Z1["STATE(error)"]
    Z -- yes --> Z2["STATE(speaking)"]
    Z1 --> DA[dispatch_reply]
    Z2 --> DA
    DA --> DB[fire-and-forget _persist_turn + trace finalize]
    DB --> FIN["finally: finalize_turn + gc.collect"]
    K --> FIN
```

### 17.2 Dispatch — parallel legs sequence

```mermaid
sequenceDiagram
    participant O as orchestrator
    participant D as dispatch_reply
    participant A as audio leg (TTS)
    participant T as tft leg (LaTeX)
    participant L as Lamp
    O->>D: dispatch_reply(reply, status, model_tag)
    D->>L: TFT_TEXT (instant caption + model_tag)
    alt status==ok and has equations
        D->>L: TFT_LATEX_LOADING (skeleton)
    end
    par audio leg
        D->>A: _dispatch_audio_leg
        A->>L: AUDIO_OUT chunks (paced 85ms/4KB)
        A->>L: AUDIO_OUT_END (the moment stream ends)
        A-->>D: set audio_done
    and tft leg
        D->>T: _dispatch_tft_leg
        T->>L: eq1 TFT_FRAME (ships immediately)
        Note over T: eq2+ wait on audio_done (90s bound)
        T->>L: remaining eq pack (after audio_done)
    end
    D-->>O: trace.tts_ms / latex_ms
```

### 17.3 Tier dispatch + Claude fallback (`_call_tier`)

```mermaid
flowchart TD
    A["_call_tier(tier)"] --> B{tier >= 2?}
    B -- yes --> C[append SOLVE_SUFFIX]
    B -- no --> D[no suffix]
    C --> E{armed? hard_timeout_s}
    D --> E
    E --> F{tier resolves to?}
    F -- "tier>=3 and Pro built" --> G["Pro.call thinking=512 cap>=10000 timeout=38s"]
    F -- "tier==2" --> H["Flash.call thinking=512 cap>=4000 timeout=20s"]
    F -- "tier 1 / clamped" --> I["Flash.call thinking=0 cap=900 timeout=20s"]
    G --> J{armed and status in FALLBACK_STATUSES?}
    H --> J
    I --> J
    J -- "timeout/rate_limited/upstream_unavailable" --> K["Claude.call same prompt+history+transcript -> fallback=True"]
    J -- ok / other failure --> L[return reply, telemetry]
    K --> L
```

---

## 18. File-by-file, function-by-function index

### `app/services/orchestrator.py`
- `TurnOrchestrator.__init__` ([L43-84](app/services/orchestrator.py#L43)) — build turn1 prompt + base provider + optional Pro (`_llm_pro`) + optional Claude fallback (`_llm_fallback`).
- `run_turn` ([L86-1074](app/services/orchestrator.py#L86)) — the full pipeline ([§6](#6-the-complete-turn-workflow-entry--exit)).
- `_call_tier` ([L1078-1196](app/services/orchestrator.py#L1078)) — single LLM call choke point ([§7](#7-the-tier-system--_call_tier)).
- `_tier_model_name` ([L1198-1203](app/services/orchestrator.py#L1198)), `_model_tag` ([L1205-1227](app/services/orchestrator.py#L1205)).
- `_load_history` ([L1229-1257](app/services/orchestrator.py#L1229)), `_history_text` ([L1259-1265](app/services/orchestrator.py#L1259)).
- `_persist_turn` ([L1267-1421](app/services/orchestrator.py#L1267)) — fire-and-forget writes ([§13](#13-persistence)).
- `_safe_preroute_stt` ([L1425-1454](app/services/orchestrator.py#L1425)) — bounded Groq Whisper.
- `_looks_like_echo` ([L1481-1508](app/services/orchestrator.py#L1481)), `_should_escalate` ([L1522-1547](app/services/orchestrator.py#L1522)), `_speech_caption` ([L1551-1563](app/services/orchestrator.py#L1551)).
- `get_orchestrator` ([L1570-1577](app/services/orchestrator.py#L1570)) — process-singleton.
- Module constants: `_ESCALATE_QUERY_TYPES`, `_ESCALATE_STATUSES`, `_FALLBACK_STATUSES`, `_ECHO_GUARD_NOTE` ([L1465-1519](app/services/orchestrator.py#L1465)).

### `app/services/dispatch.py`
- `dispatch_reply` ([L52-146](app/services/dispatch.py#L52)) — entrypoint + graph.
- `_dispatch_audio_leg` ([L149-186](app/services/dispatch.py#L149)), `_audio_leg_impl` ([L188-265](app/services/dispatch.py#L188)).
- `_dispatch_tft_leg` ([L268-296](app/services/dispatch.py#L268)), `_dispatch_equations` ([L299-451](app/services/dispatch.py#L299)).
- `_scrub_math_markup` ([L462-484](app/services/dispatch.py#L462)), `_text_card_payload` ([L487-524](app/services/dispatch.py#L487)) (alias `_short_caption`).
- `_tts_chunks` ([L537-569](app/services/dispatch.py#L537)), `_sentence_streamed` ([L572-619](app/services/dispatch.py#L572)).

### `app/services/turn_trace.py`
- `clean_bbox` ([L69-83](app/services/turn_trace.py#L69)), `_Phase`/`_NullPhase` ([L88-129](app/services/turn_trace.py#L88)).
- `TurnTracer.__init__/phase/note/mark/mark_tier/fail` ([L132-208](app/services/turn_trace.py#L132)).
- `finalize`/`_upload_media`/`_write_row` ([L212-319](app/services/turn_trace.py#L212)).
- `_SCALAR_FIELDS`, `_TEXT_CAPS`, `_BLOB_TIMEOUT_S` ([L43-85](app/services/turn_trace.py#L43)).

### `app/services/problem_memo.py`
- Lifecycle: `save`/`load`/`load_question`/`save_question`/`touch`/`record_nudge`/`clear` ([L47-214](app/services/problem_memo.py#L47)).
- `matched` ([L217-247](app/services/problem_memo.py#L217)), `question_context_block`/`answer_key_block` ([L157-176](app/services/problem_memo.py#L157), [L250-277](app/services/problem_memo.py#L250)).
- `usable_statement` ([L292-296](app/services/problem_memo.py#L292)), `escalation_brief` ([L299-332](app/services/problem_memo.py#L299)).
- `wants_full_solution`/`frustration_cue`/`is_dispute`/`dispute_note` ([L378-500](app/services/problem_memo.py#L378)).
- `is_check_request`/`check_verdict_note` — the check-verdict guard (verify-request → plain verdict, not a nudge).
- `solve_authorized`/`solve_authorized_note` ([L503-556](app/services/problem_memo.py#L503)).
- `answer_path_contradiction`/`solution_bleed`/`reveal_incomplete` ([L587-706](app/services/problem_memo.py#L587)).
- Notes/suffixes: `REVEAL_GUARD_NOTE`/`SOLUTION_GUARD_NOTE`/`SOLVE_SUFFIX` ([L711-804](app/services/problem_memo.py#L711)).

### `app/services/turn_handler.py` + `app/services/validator.py` (legacy)
- `handle_turn` ([turn_handler.py:8-54](app/services/turn_handler.py#L8)).
- `validate_response` + helpers `is_valid_latex`/`clean_voice`/`count_sentences`/`trim_to_sentences` ([validator.py:3-63](app/services/validator.py#L3)).

### Supporting (read for grounding, documented inline above)
- `app/services/escalation_router.py` — `preroute`, `assess_image_quality`, `classify_text`, `extract_focus_label`, `focus_mismatch`, `is_followup_text`, suffixes/notes.
- `app/schemas/llm_response.py` — `LlmReply`, `Display`, `_coerce_tolerant`, canned fallbacks, `retake_image_reply`, `fallback_for_status`.
- `app/providers/llm_base.py` — `LLM_HARD_TIMEOUT_S=20.0`, `LLM_MAX_OUTPUT_TOKENS=900`, telemetry shape, `get_llm_provider`.
- `app/session.py` — `_on_audio_end` (caller), `_on_cancel` (cleanup).
- `app/config.py` — every threshold/constant in [§5](#5-configuration-env-vars-constants--thresholds).
