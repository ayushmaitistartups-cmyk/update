# Backend — HTTP Routes & REST API

This is the definitive reference for the Smart Tutor Lamp backend's HTTP/REST surface — every router under [`app/routes/`](../../Smart-Tutor-Lamp-backend/app/routes), the request/response schemas they bind to, the auth dependencies they gate on, the rate limits they enforce, and the exact step-by-step logic of each endpoint. It is grounded entirely in the code: `admin.py`, `clerk_webhook.py`, `device_lamp.py`, `device_user.py`, `frontend_manager.py`, `health.py`, `pairing_info.py`, and a summary of `ws_lamp.py` (the binary WebSocket protocol is detailed in the protocol doc). The FastAPI app is a single ASGI service ([`app/main.py`](../../Smart-Tutor-Lamp-backend/app/main.py)) that exposes three audiences: the **lamp** (public, `device_id`+`device_secret`-authed), the **frontend** (Clerk-session-authed), and **admins** (Clerk ∩ admin allowlist). All routes except the two health probes and the lamp WS are mounted **only when `ENABLE_AUTH=True`**.

## Table of Contents

1. [Purpose & Responsibility](#1-purpose--responsibility)
2. [Architecture & Mounting](#2-architecture--mounting)
3. [Authentication & Dependency Stack](#3-authentication--dependency-stack)
4. [Rate Limiting](#4-rate-limiting)
5. [Error Envelope & Global Handlers](#5-error-envelope--global-handlers)
6. [Complete Endpoint Reference Table](#6-complete-endpoint-reference-table)
7. [Per-Route Detail](#7-per-route-detail)
   - [7.1 health.py](#71-healthpy--liveness--readiness)
   - [7.2 device_lamp.py](#72-device_lamppy--lamp-facing-pairing)
   - [7.3 pairing_info.py](#73-pairing_infopy--pairing-card)
   - [7.4 device_user.py](#74-device_userpy--frontend-device-crud)
   - [7.5 clerk_webhook.py](#75-clerk_webhookpy--lifecycle-events)
   - [7.6 frontend_manager.py](#76-frontend_managerpy--identity-profile-analytics-brain-bench)
   - [7.7 admin.py](#77-adminpy--system-wide-read-dashboard)
   - [7.8 ws_lamp.py](#78-ws_lamppy--summary)
8. [Key Algorithms](#8-key-algorithms)
9. [Configuration, Constants & Env Vars](#9-configuration-constants--env-vars)
10. [Edge Cases, Errors, Timeouts, Fallbacks](#10-edge-cases-errors-timeouts-fallbacks)
11. [Integration Points (Cross-References)](#11-integration-points-cross-references)
12. [Mermaid Diagrams](#12-mermaid-diagrams)

---

## 1. Purpose & Responsibility

The routes layer is the **boundary** of the Python backend. It is responsible for:

- **Device enrollment & pairing** — turning a freshly-flashed ESP32-S3 lamp into a user-bound device (mint pairing code → user claims it → mint `device_jwt`).
- **Frontend identity & onboarding** — telling the Next.js app who the logged-in user is, storing the onboarding profile, and serving per-user analytics.
- **The web "brain bench" / simulator** — `/simulate`, `/solve`, `/solve/compare`, plus a streaming WebSocket gateway, all reusing the same multi-LLM brain the lamp uses.
- **Admin dashboard** — read-only, system-wide rollups across all users/devices/sessions/turns/events + a manual media-retention sweep.
- **Lifecycle webhooks** — Clerk `user.deleted` → revoke that user's devices.
- **Health probes** — liveness (`/healthz`) and readiness (`/readyz`).

Two strict boundaries hold throughout (per `IMPLEMENTATION_AUTH_PAIRING.md §0.1`):

1. **The lamp NEVER touches Clerk-authed endpoints.** It authenticates with `device_id`+`device_secret` (argon2id) on HTTP pairing routes, and a `device_jwt` (HS256) on the WS upgrade.
2. **Clerk tokens stop at the Python boundary.** Frontend routes verify the Clerk session token; the lamp never sees a Clerk token.

A subtle but repeated code convention: **every limiter-decorated route file deliberately omits `from __future__ import annotations`**. Under stringized annotations the `@limiter.limit` (slowapi) wrapper makes FastAPI resolve `body: SomeIn` against slowapi's module globals, misclassify the body as a query param, and 422 with `loc ('query','body')`. See the explanatory comments in [frontend_manager.py:17](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L17), [device_lamp.py:10](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L10), and [device_user.py:16](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L16). `health.py`, `pairing_info.py`, and `clerk_webhook.py` (none of which use `@limiter.limit`) keep the `from __future__` import.

---

## 2. Architecture & Mounting

All routers are assembled in [`app/main.py`](../../Smart-Tutor-Lamp-backend/app/main.py). **Three** routers are **always** mounted (health, lamp WS, and — since 2026-07 — OTA, so a lamp can always self-update); the rest are mounted **only inside `if settings.ENABLE_AUTH:`**.

| Router | Module | Prefix | Tag | Mounted when |
|---|---|---|---|---|
| `health_router` | `health.py` | *(none)* | — | always ([main.py:282](../../Smart-Tutor-Lamp-backend/app/main.py#L282)) |
| `ws_router` | `ws_lamp.py` | *(none)* | — | always ([main.py:283](../../Smart-Tutor-Lamp-backend/app/main.py#L283)) |
| `ota_router` | `ota.py` | `/lamp/ota` | `ota` | **always** ([main.py:284](../../Smart-Tutor-Lamp-backend/app/main.py#L284)) |
| `device_lamp_router` | `device_lamp.py` | `/api/device` | `pairing-lamp` | `ENABLE_AUTH` ([main.py:319](../../Smart-Tutor-Lamp-backend/app/main.py#L319)) |
| `device_user_router` | `device_user.py` | `/api` | `devices-user` | `ENABLE_AUTH` ([main.py:320](../../Smart-Tutor-Lamp-backend/app/main.py#L320)) |
| `pairing_info_router` | `pairing_info.py` | `/api` | `pairing-user` | `ENABLE_AUTH` ([main.py:321](../../Smart-Tutor-Lamp-backend/app/main.py#L321)) |
| `clerk_webhook_router` | `clerk_webhook.py` | `/api/clerk` | `webhook` | `ENABLE_AUTH` ([main.py:322](../../Smart-Tutor-Lamp-backend/app/main.py#L322)) |
| `frontend_manager_router` | `frontend_manager.py` | `/api/frontend` | `frontend-manager` | `ENABLE_AUTH` ([main.py:323](../../Smart-Tutor-Lamp-backend/app/main.py#L323)) |
| `admin_router` | `admin.py` | `/api/frontend/admin` | `admin` | `ENABLE_AUTH` ([main.py:324](../../Smart-Tutor-Lamp-backend/app/main.py#L324)) |
| `pilot_router` | `pilot.py` | `/api/frontend/pilot` | `pilot` | `ENABLE_AUTH` ([main.py:325](../../Smart-Tutor-Lamp-backend/app/main.py#L325)) |
| `admin_pilot_router` | `admin_pilot.py` | `/api/frontend/admin/pilot` | `admin-pilot` | `ENABLE_AUTH` ([main.py:326](../../Smart-Tutor-Lamp-backend/app/main.py#L326)) |
| `insights_router` | `insights.py` | `/api/frontend/admin/pilot/insights` | `insights` | `ENABLE_AUTH` ([main.py:327](../../Smart-Tutor-Lamp-backend/app/main.py#L327)) |

When `ENABLE_AUTH=False` the auth/pairing/frontend/pilot routers are **not mounted**, so calls 404 cleanly instead of returning a misleading 503 (Clerk isn't configured in dev). The lamp WS and the OTA poll still work (the OTA poll is unauthenticated by design). The lamp WS runs under a `dev-lamp` identity ([main.py:329-330](../../Smart-Tutor-Lamp-backend/app/main.py#L329)).

> The **pilot / insights / OTA** endpoint families and their per-route logic are documented in depth in [12-pilot-insights-ota-and-taggers.md](12-pilot-insights-ota-and-taggers.md); this doc lists them in the reference table below for completeness.

**Cross-cutting middleware / handlers wired in `main.py`:**
- **slowapi**: `app.state.limiter = limiter` + a `RateLimitExceeded → 429` handler ([main.py:141-142](../../Smart-Tutor-Lamp-backend/app/main.py#L141)).
- **`RequestValidationError` handler** ([main.py:153](../../Smart-Tutor-Lamp-backend/app/main.py#L153)) — logs the offending fields at WARNING and returns the standard 422 body.
- **catch-all `Exception` handler** ([main.py:164](../../Smart-Tutor-Lamp-backend/app/main.py#L164)) — only fires for *unhandled* exceptions (HTTPException keeps FastAPI's handler); logs the full stack and returns `{"detail": {"error":"internal server error","code":"INTERNAL_ERROR"}}` with 500.
- **request tracer** `_trace_requests` ([main.py:179](../../Smart-Tutor-Lamp-backend/app/main.py#L179)) — times every request; logs 5xx at ERROR, 4xx at WARNING, 2xx at DEBUG (or INFO when `LOG_ALL_REQUESTS`).
- **CORS** ([main.py:221](../../Smart-Tutor-Lamp-backend/app/main.py#L221)) — exact-match `allow_origins` from `CORS_ALLOWED_ORIGINS` plus a localhost/127.0.0.1 regex; `allow_credentials=True`; methods `GET/POST/PUT/DELETE/OPTIONS`; headers `Authorization, Content-Type, svix-id, svix-timestamp, svix-signature`.
- **`/blobs` static mount** ([main.py:241-253](../../Smart-Tutor-Lamp-backend/app/main.py#L241)) — only when `STORAGE_BACKEND == "local"`; serves `STORAGE_LOCAL_DIR` so the admin trace view can play back UUID-named media in dev.

---

## 3. Authentication & Dependency Stack

There are **five distinct authentication mechanisms**, each implemented by a dependency or inline helper.

### 3.1 `current_clerk_user` — Clerk session (HTTP frontend)
File: [`app/deps/clerk.py`](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py).

Verifies `Authorization: Bearer <Clerk session token>` (or cookie) against Clerk's JWKS via the `clerk-backend-api` SDK and returns the **Clerk user ID** (`payload["sub"]`, e.g. `user_2abc…`) — the value stored in `devices.user_id`. Key mechanics:

- **`ENABLE_AUTH=False` → 503 `AUTH_DISABLED`** ([clerk.py:253](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L253)). So the dep is inert in dev.
- **Verified-token cache** ([clerk.py:100-130](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L100)): a Clerk verify is a synchronous JWKS fetch + RSA verify (100s of ms warm, seconds cold). The cache keys the payload by the exact token string with `_VERIFY_TTL_SEC = 30.0` and `_VERIFY_CACHE_MAX = 1024`. A per-token `asyncio.Lock` collapses a concurrent burst (the dashboard fires `/me`+`/profile`+`/analytics` with the same token) into ONE verify; the rest await and hit the warm cache. Trade-off: a revoked session stays honored for up to 30 s. When the cache is full it's cleared wholesale ([clerk.py:127](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L127)).
- **Cookie sessions** (no bearer) can't safely key the cache, so they verify directly every time ([clerk.py:275](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L275)).
- **Authorized parties (`azp`)** ([clerk.py:137-175](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L137)): mirrors the CORS policy — accepts `FRONTEND_BASE_URL`, each `CORS_ALLOWED_ORIGINS` entry, AND each localhost↔127.0.0.1 twin. A token whose `azp` isn't byte-for-byte in this list is rejected (`USER_AUTH_FAIL`). Empty list → `None` → azp check skipped (signature+expiry still enforced).
- **The verify runs in a threadpool** ([clerk.py:217](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L217)) so the event loop stays free.
- Stashes the full payload at `request.state.clerk_payload` so routes can read `email`/`primary_email` claims without re-verifying.
- Failures → **401 `USER_AUTH_FAIL`**; missing `sub` → 401; SDK missing → 503 `AUTH_SDK_MISSING`; secret unset → 503 `AUTH_DISABLED`.

### 3.2 `require_admin` — Clerk session ∩ admin allowlist
File: [`app/deps/admin.py`](../../Smart-Tutor-Lamp-backend/app/deps/admin.py). Depends on `current_clerk_user`, then calls `app.services.admin.is_admin(db, clerk_user_id, jwt_email)` where `jwt_email = payload.get("email") or payload.get("primary_email")`. Non-admin → **403 `NOT_ADMIN`** ([admin.py:39-42](../../Smart-Tutor-Lamp-backend/app/deps/admin.py#L39)). Returns the Clerk user_id so admin routes read identically to other frontend routes. The docstring notes the allowlist is the `admins` table (no `.env` fallback).

### 3.3 `verify_ws_token` — Clerk session (WebSocket)
File: [`app/deps/clerk_ws.py`](../../Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py). Browsers can't set an `Authorization` header on `new WebSocket()`, so the Clerk JWT arrives in `?token=`. This module verifies it **directly against Clerk's public JWKS** with `pyjwt[crypto]` (no Clerk secret needed). It:
- Derives the JWKS URL / issuer from `CLERK_JWKS_URL` / `CLERK_ISSUER`, or decodes the host from `CLERK_PUBLISHABLE_KEY` (`pk_<env>_<base64(host$)>`) ([clerk_ws.py:32-59](../../Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py#L32)).
- Decodes with `algorithms=["RS256"]`, `issuer=...`, requiring claims `sub`, `exp`, `iat`, with `leeway=10` for clock drift ([clerk_ws.py:85-92](../../Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py#L85)).
- Rejects a token issued >30 s in the future ([clerk_ws.py:98](../../Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py#L98)).
- Returns `sub` (Clerk user_id), or raises `WsAuthError` → the route closes the socket with **code 4401**.

### 3.4 Device-secret auth (lamp HTTP pairing)
File: [`app/deps/device_auth.py`](../../Smart-Tutor-Lamp-backend/app/deps/device_auth.py). Not a FastAPI `Depends` — the secret lives in the JSON body. Two inline helpers used by `device_lamp.py`:
- `hash_secret(secret)` → argon2id hash with **argon2-cffi library defaults (t=3, m=64 MiB, p=4)** ([device_auth.py:15-17](../../Smart-Tutor-Lamp-backend/app/deps/device_auth.py#L15)).
- `verify_secret(stored_hash, candidate)` → constant-time; returns `False` on mismatch OR any parse error (corrupt row) — never raises ([device_auth.py:45-61](../../Smart-Tutor-Lamp-backend/app/deps/device_auth.py#L45)).

### 3.5 `device_jwt` (lamp WS)
File: [`app/services/device_jwt.py`](../../Smart-Tutor-Lamp-backend/app/services/device_jwt.py). **HS256** signed with the backend's own `DEVICE_JWT_SECRET` (NOT Clerk's). Claims: `sub`=device_id, `uid`=clerk_user_id, `iat`, `iss`=`DEVICE_JWT_ISS` (default `lumos-auth`), `ver`=`JWT_VERSION` (=1). **No `exp` claim** — revocation is canonical via `devices.revoked_at` checked at WS-connect. `verify_device_jwt` rejects bad signature, wrong issuer, malformed JSON, `ver < JWT_VERSION`, or missing `sub`/`uid` ([device_jwt.py:55-87](../../Smart-Tutor-Lamp-backend/app/services/device_jwt.py#L55)).

### 3.6 Svix webhook signature (Clerk webhook)
`clerk_webhook.py` verifies the Svix signature over the raw body using `CLERK_WEBHOOK_SECRET` — see §7.5.

---

## 4. Rate Limiting

File: [`app/deps/rate_limit.py`](../../Smart-Tutor-Lamp-backend/app/deps/rate_limit.py). A single module-singleton `Limiter` keyed by **remote IP** (`get_remote_address`). Storage is Redis (`REDIS_URL`) when configured so workers share buckets, else `memory://`.

Critical configuration ([rate_limit.py:26-53](../../Smart-Tutor-Lamp-backend/app/deps/rate_limit.py#L26)):
- `headers_enabled=False` — MUST stay False unless every limited route declares a `response: Response` param, else slowapi 500s trying to inject `X-RateLimit-*` headers onto pydantic returns.
- `swallow_errors=True` + `in_memory_fallback_enabled=True` — **fail OPEN**: a Redis storage error allows the request and degrades to per-worker in-memory buckets rather than 500-ing every endpoint (an unhandled 500 would also skip CORS and surface as a bogus CORS error in the browser).
- `storage_options={"socket_connect_timeout": 1, "socket_timeout": 1}` — a dead Redis fails in ~1 s instead of hanging ~5 s.

Per-endpoint limits are declared with `@limiter.limit("…")`; the Clerk webhook is intentionally **unlimited** (signature-verified). Exact limits are in the [endpoint table](#6-complete-endpoint-reference-table).

---

## 5. Error Envelope & Global Handlers

Every 4xx/5xx the routes raise uses the **`{"error": <human>, "code": <MACHINE_CODE>}`** envelope (schema [`ApiError`](../../Smart-Tutor-Lamp-backend/app/schemas/auth.py#L101)). FastAPI's built-in `HTTPException` handler serializes `detail={...}` unchanged, so no custom handler is needed for these ([main.py:203-206](../../Smart-Tutor-Lamp-backend/app/main.py#L203)).

Machine codes observed across routes: `AUTH_DISABLED`, `AUTH_SDK_MISSING`, `USER_AUTH_FAIL`, `NOT_ADMIN`, `DEV_AUTH_FAIL`, `CODE_NOT_FOUND`, `CODE_EXPIRED`, `ALREADY_PAIRED`, `NOT_FOUND`, `NOT_OWNER`, `INTERNAL`, `INTERNAL_ERROR`, `BRAIN_UNAVAILABLE`, `BRAIN_BUSY`, `BRAIN_ERROR`, `EMPTY_INPUT`, `TRACE_NOT_FOUND`, `WEBHOOK_BAD_HEADERS`, `WEBHOOK_BAD_SIG`.

---

## 6. Complete Endpoint Reference Table

> Auth column: **Public** = no auth; **Device** = `device_id`+`device_secret` in body; **Clerk** = `current_clerk_user`; **Admin** = `require_admin`; **Clerk-WS** = `verify_ws_token`; **device_jwt** = lamp JWT; **Svix** = signed webhook.

### HTTP endpoints

| Method | Path | Auth | Rate limit | Request | Success | Module |
|---|---|---|---|---|---|---|
| GET | `/healthz` | Public | none | — | 200 `{ok:true}` | health.py |
| GET | `/readyz` | Public | none | — | 200/503 `{ready,checks}` | health.py |
| POST | `/api/device/register` | Device | 30/hour | `DeviceRegisterIn` | 200 `DeviceRegisterOut` | device_lamp.py |
| POST | `/api/device/poll-pairing` | Device | 40/minute | `DevicePollIn` | 200 `DevicePollOut` | device_lamp.py |
| GET | `/api/pairing-info/{code}` | Public | none | path `code` | 200 `PairingInfoOut` | pairing_info.py |
| POST | `/api/device/complete-pairing` | Clerk | 30/hour | `CompletePairingIn` | 200 `CompletePairingOut` | device_user.py |
| GET | `/api/devices` | Clerk | 60/minute | — | 200 `DeviceListOut` | device_user.py |
| POST | `/api/device/{device_id}/unlink` | Clerk | 60/minute | path `device_id` | 204 No Content | device_user.py |
| POST | `/api/device/{device_id}/rename` | Clerk | 60/minute | `DeviceRenameIn` | 200 `DeviceRenameOut` | device_user.py |
| POST | `/api/clerk/webhook` | Svix | unlimited | raw Svix body | 200 `{ok:true[,revoked]}` | clerk_webhook.py |
| GET | `/api/frontend/me` | Clerk | 120/minute | — | 200 `MeOut` | frontend_manager.py |
| GET | `/api/frontend/profile` | Clerk | 120/minute | — | 200 `ProfileOut\|null` | frontend_manager.py |
| PUT | `/api/frontend/profile` | Clerk | 30/minute | `ProfileIn` | 200 `ProfileOut` | frontend_manager.py |
| GET | `/api/frontend/analytics` | Clerk | 60/minute | — | 200 `AnalyticsOut` | frontend_manager.py |
| GET | `/api/frontend/analytics/detail` | Clerk | 60/minute | `?days=1..90` | 200 `AnalyticsDetailOut` | frontend_manager.py |
| POST | `/api/frontend/simulate` | Clerk | 30/minute | multipart `text/audio/image/images` | 200 `SimResponse` | frontend_manager.py |
| GET | `/api/frontend/models` | Clerk | 120/minute | — | 200 `ModelsOut` | frontend_manager.py |
| POST | `/api/frontend/solve` | Clerk | 30/minute | multipart `text/model/audio/image/images` | 200 `SolveOut` | frontend_manager.py |
| POST | `/api/frontend/solve/compare` | Clerk | 15/minute | multipart `text/models/audio/image/images` | 200 `CompareOut` | frontend_manager.py |
| POST | `/api/frontend/feedback` | Clerk | 60/minute | `FeedbackIn` | 200 `FeedbackOut` | frontend_manager.py |
| GET | `/api/frontend/admin/overview` | Admin | 60/minute | `?days=1..90` | 200 `AdminOverviewOut` | admin.py |
| GET | `/api/frontend/admin/models` | Admin | 60/minute | `?days=1..90` | 200 `AdminModelsOut` | admin.py |
| GET | `/api/frontend/admin/users` | Admin | 60/minute | `?limit=1..1000` | 200 `AdminUsersOut` | admin.py |
| GET | `/api/frontend/admin/devices` | Admin | 60/minute | `?limit=1..1000` | 200 `AdminDevicesOut` | admin.py |
| GET | `/api/frontend/admin/sessions` | Admin | 60/minute | `?limit=1..500` | 200 `AdminSessionsOut` | admin.py |
| GET | `/api/frontend/admin/turns` | Admin | 60/minute | `?limit=1..200&user_id&status` | 200 `AdminTurnsOut` | admin.py |
| GET | `/api/frontend/admin/turns/{turn_id}/trace` | Admin | 120/minute | path `turn_id` | 200 `AdminTurnTraceOut` | admin.py |
| GET | `/api/frontend/admin/media` | Admin | 60/minute | — | 200 `AdminMediaOut` | admin.py |
| POST | `/api/frontend/admin/media/cleanup` | Admin | 10/minute | `MediaCleanupIn` | 200 `MediaCleanupOut` | admin.py |
| GET | `/api/frontend/admin/events` | Admin | 60/minute | `?limit=1..500` | 200 `AdminEventsOut` | admin.py |
| GET | `/api/frontend/admin/performance` | Admin | 60/minute | `?days=1..90` | 200 `AdminPerfOut` | admin.py |
| GET | `/api/frontend/admin/models` | Admin | 60/minute | `?days=1..90` | 200 `AdminModelsOut` | admin.py |
| POST | `/api/frontend/admin/ota/release` | Admin | 10/minute | raw `.bin` body, `?version&notes` | 200 `AdminOtaReleaseOut` | admin.py |
| GET | `/api/frontend/admin/ota/releases` | Admin | 60/minute | — | 200 `AdminOtaReleasesOut` | admin.py |
| DELETE | `/api/frontend/admin/ota/release/{id}` | Admin | 30/minute | path `release_id` | 200 `AdminOtaReleaseOut` | admin.py |
| GET | `/lamp/ota/version` | Public | none | — | 200 plain text `{ver}\n{url}\n` | ota.py |
| GET | `/lamp/ota/firmware.bin` | Public | none | — | 200 octet-stream / 404 | ota.py |
| POST | `/api/frontend/pilot/turn-feedback` | Clerk | 120/minute | `TurnFeedbackIn` | 200 `TurnFeedbackOut` | pilot.py |
| POST | `/api/frontend/pilot/survey` | Clerk | 30/minute | `SurveyIn` | 200 `SurveyOut` | pilot.py |
| GET | `/api/frontend/pilot/survey/status` | Clerk | 60/minute | — | 200 `SurveyStatusOut` | pilot.py |
| POST | `/api/frontend/pilot/report` | Clerk | 30/minute | `ProblemReportIn` | 200 `ProblemReportOut` | pilot.py |
| GET | `/api/frontend/pilot/personalization` | Clerk | 60/minute | — | 200 `PersonalizationOut` | pilot.py |
| POST | `/api/frontend/pilot/personalization` | Clerk | 30/minute | `PersonalizationIn` | 200 `PersonalizationSaveOut` | pilot.py |
| POST | `/api/frontend/pilot/consent` | Clerk | 30/minute | `ConsentIn` | 200 `ConsentOut` | pilot.py |
| GET | `/api/frontend/admin/pilot/cohorts` | Admin | 60/minute | — | 200 `CohortsOut` | admin_pilot.py |
| GET | `/api/frontend/admin/pilot/funnel` | Admin | 60/minute | `?cohort` | 200 `FunnelOut` | admin_pilot.py |
| GET | `/api/frontend/admin/pilot/feedback` | Admin | 60/minute | `?days=1..90&cohort` | 200 `FeedbackSummaryOut` | admin_pilot.py |
| GET | `/api/frontend/admin/pilot/surveys` | Admin | 60/minute | `?cohort` | 200 `SurveyResultsOut` | admin_pilot.py |
| GET | `/api/frontend/admin/pilot/reports` | Admin | 60/minute | `?status&cohort&limit=1..500` | 200 `ProblemReportsOut` | admin_pilot.py |
| POST | `/api/frontend/admin/pilot/reports/{id}/status` | Admin | 60/minute | `ReportStatusIn` | 200 `ReportStatusOut` | admin_pilot.py |
| GET | `/api/frontend/admin/pilot/insights/topics` | Admin | 60/minute | `?exam&cohort&limit=1..500` | 200 `TopicStrengthOut` | insights.py |
| GET | `/api/frontend/admin/pilot/insights/coverage` | Admin | 60/minute | `?exam&cohort` | 200 `CoverageOut` | insights.py |
| GET | `/api/frontend/admin/pilot/insights/engagement` | Admin | 60/minute | `?cohort` | 200 `EngagementOut` | insights.py |
| GET | `/api/frontend/admin/pilot/insights/mistakes` | Admin | 60/minute | `?cohort` | 200 `MistakesOut` | insights.py |
| GET | `/api/frontend/admin/pilot/insights/quality` | Admin | 60/minute | `?cohort` | 200 `QualityOut` | insights.py |

> Full per-route logic for the pilot/insights/OTA families is in [doc 12](12-pilot-insights-ota-and-taggers.md). The `admin.py` `/performance`, `/models`, and `/ota/*` endpoints (new since 2026-06-16) are detailed in [10-formatting-schemas-and-admin.md](10-formatting-schemas-and-admin.md) §14.

### WebSocket endpoints

| Path | Auth | Close codes | Module |
|---|---|---|---|
| `/lamp/ws` | device_jwt (or `dev-lamp` when `ENABLE_AUTH=False`) | 4401 bad jwt, 4402 unlinked, 1000 idle | ws_lamp.py |
| `/api/frontend/ws` | Clerk-WS (`?token=`) | 4401 bad token, 1002 bad frame | frontend_manager.py |

---

## 7. Per-Route Detail

### 7.1 health.py — liveness & readiness
File: [`app/routes/health.py`](../../Smart-Tutor-Lamp-backend/app/routes/health.py). Router has no prefix; both probes are always mounted.

**`GET /healthz`** ([health.py:27](../../Smart-Tutor-Lamp-backend/app/routes/health.py#L27)) — LIVENESS. Always returns `200 {"ok": true}`. No dependency checks. Used by process supervisors / k8s liveness to decide whether to RESTART.

**`GET /readyz`** ([health.py:33](../../Smart-Tutor-Lamp-backend/app/routes/health.py#L33)) — READINESS. Returns `JSONResponse({"ready": bool, "checks": {...}}, status=200 if ready else 503)`. Logic:
1. **Postgres** — if `ENABLE_AUTH` or `DATABASE_URL`: open a session from `get_session_factory()` and `await db.execute(text("SELECT 1"))`. Success → `checks["database"]="ok"`; exception → `"error: <ExcName>"` + `ready=False`. Not configured → `"disabled"` (does NOT fail readiness).
2. **Redis** — if `REDIS_URL`: `get_client()`; if `None` → `"configured-but-unavailable"` + `ready=False`; else `await client.ping()` → `"ok"`; exception → `"error: <ExcName>"` + `ready=False`. Not configured → `"disabled"`.
3. **LLM key** — config check only (no live call): `has_llm_key = any(GEMINI/OPENAI/ANTHROPIC/DEEPSEEK API keys)`. `"ok"` or `"missing"`; missing → `ready=False`.

A dependency that isn't configured reports `"disabled"` and does NOT fail the check — the backend degrades cleanly.

### 7.2 device_lamp.py — lamp-facing pairing
File: [`app/routes/device_lamp.py`](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py). Prefix `/api/device`, tag `pairing-lamp`. Two **public** HTTPS endpoints; auth is `device_id`+`device_secret` in the JSON body, verified via argon2id. References `IMPLEMENTATION_AUTH_PAIRING.md §6.1.1 / §6.1.2`.

#### `POST /api/device/register` ([device_lamp.py:40](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L40)) — rate 30/hour
- **Request** `DeviceRegisterIn`: `device_id` (4-64 chars), `device_secret` (8-256 chars).
- **Response** `DeviceRegisterOut` (two shapes discriminated by `status`):
  - `status="pending"` → `pairing_code`, `pairing_url`, `expires_in` populated, `device_jwt=null`.
  - `status="already_paired"` → `device_jwt` populated, QR fields null.

**Step-by-step:**
1. **Opportunistic global housekeeping** — `DELETE FROM pairing_codes WHERE expires_at < now()` ([device_lamp.py:63-67](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L63)). `/register` is rare (30/hr/IP) so this is a cheap self-healing sweep; no cron needed.
2. `device = db.get(Device, device_id)`.
3. **First boot** (device is `None`): create a `Device` row with `device_secret_hash = hash_secret(device_secret)`, no user. `flush()`.
4. **Existing device**: `verify_secret(stored_hash, device_secret)`. Mismatch → **401 `DEV_AUTH_FAIL`**.
5. **Recovery path** — if existing device has `user_id is not None and revoked_at is None` (already paired, but the lamp is registering without a usable JWT): delete any stale pairing codes for this device, mint a fresh `device_jwt` for the SAME user, commit, return `DeviceRegisterOut(status="already_paired", device_jwt=token)` ([device_lamp.py:97-106](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L97)). This guarantees a paired lamp always leaves the QR screen. (A revoked device has `user_id=NULL` here and falls through to the normal pending path.)
6. **One live code per device**: `DELETE pairing_codes WHERE device_id = …` ([device_lamp.py:113](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L113)) so an old QR photographed earlier can't still pair.
7. **Code generation with collision retry**: loop up to **8 times** calling `generate_pairing_code()` (6 chars `[A-Z0-9]`, 36⁶≈2.1B keyspace) and check `db.get(PairingCode, code)` for clash. Exhaustion → **500 `INTERNAL`** ([device_lamp.py:117-126](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L117)).
8. Insert a `PairingCode` with `status="pending"`, `user_id=None`, `device_jwt=None`, `expires_at = now + PAIRING_CODE_TTL_SEC` (300 s). Commit.
9. Build `pairing_url = f"{FRONTEND_BASE_URL.rstrip('/')}/pair/{code}"` and return `pairing_code`, `pairing_url`, `expires_in=PAIRING_CODE_TTL_SEC` ([device_lamp.py:140-148](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L140)).

Idempotent: a lamp that reboots mid-pairing re-POSTs the same credentials and gets a fresh code.

#### `POST /api/device/poll-pairing` ([device_lamp.py:151](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L151)) — rate 40/minute
- **Request** `DevicePollIn`: `device_id`, `device_secret`, `pairing_code` (6-8 chars).
- **Response** `DevicePollOut` (`model_config = extra="forbid"`): `status ∈ {pending, paired, expired}`; `device_jwt` only present on `paired`.

**Step-by-step:**
1. `device = db.get(Device, device_id)`; if `None` OR `verify_secret` fails → **401 `DEV_AUTH_FAIL`**.
2. `pc = db.get(PairingCode, pairing_code)`; `None` → **404 `CODE_NOT_FOUND`**.
3. **Ownership guard**: if `pc.device_id != device_id` → **404 `CODE_NOT_FOUND`** (don't leak that a code belongs to another device).
4. **Expiry**: if `pc.expires_at < now`, delete the row, commit, return `status="expired"` (lazy cleanup).
5. `pc.status == "pending"` → return `status="pending"`.
6. `pc.status == "paired"` → **single-use**: capture `device_jwt`, delete the row, commit, return `status="paired", device_jwt=token`. The next poll then 404s, which tells the lamp to stop polling ([device_lamp.py:198-203](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L198)).
7. **Defensive**: any other status → return `status="expired"`.

The lamp polls every 3 s (~20/min) over the 5-min TTL (~100 polls). The 40/min limit leaves headroom for two lamps behind one NAT ([device_lamp.py:156-159](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L156)).

### 7.3 pairing_info.py — pairing card
File: [`app/routes/pairing_info.py`](../../Smart-Tutor-Lamp-backend/app/routes/pairing_info.py). Prefix `/api`, tag `pairing-user`. Public so a logged-out user on `/pair/[code]` gets a clean 404/410 instead of leaking auth shape (Clerk middleware gates the *page*, not this endpoint).

#### `GET /api/pairing-info/{code}` ([pairing_info.py:26](../../Smart-Tutor-Lamp-backend/app/routes/pairing_info.py#L26))
- **Response** `PairingInfoOut`: `device_id`, `friendly_name`, `expires_at`.

**Step-by-step:**
1. `pc = db.get(PairingCode, code)`; `None` → **404 `CODE_NOT_FOUND`**.
2. `pc.expires_at < now` → **410 `CODE_EXPIRED`**.
3. `device = db.get(Device, pc.device_id)`; `None` → **404 `CODE_NOT_FOUND`** (defensive — the row outlived its device).
4. If `device.user_id is not None and revoked_at is None` (already linked) → **409 `ALREADY_PAIRED`**.
5. Return `device_id`, `friendly_name`, `expires_at`.

### 7.4 device_user.py — frontend device CRUD
File: [`app/routes/device_user.py`](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py). Prefix `/api`, tag `devices-user`. Every route gates on `current_clerk_user` and enforces ownership via `devices.user_id == verified clerk_user_id`. Constant: `ONLINE_WINDOW = timedelta(seconds=60)` ([device_user.py:48](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L48)).

#### `POST /api/device/complete-pairing` ([device_user.py:51](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L51)) — Clerk, 30/hour
- **Request** `CompletePairingIn`: `pairing_code` (6-8 chars). **Response** `CompletePairingOut`: `device_id`, `friendly_name`.

**Step-by-step (transactional, race-safe):**
1. `pc = db.get(PairingCode, pairing_code)`; `None` → **404 `CODE_NOT_FOUND`**; expired → **410 `CODE_EXPIRED`**.
2. **`SELECT … FOR UPDATE`** on the device row (`.with_for_update()`) to serialize concurrent claims ([device_user.py:83](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L83)). Missing → **404 `CODE_NOT_FOUND`** (`code="CODE_NOT_FOUND"`, msg "unknown device").
3. **Conflict check**: if device already linked (`user_id is not None and revoked_at is None`) AND `device.user_id != clerk_user_id` → **409 `ALREADY_PAIRED`**. Same user re-claiming → allowed (mint fresh JWT).
4. Set `device.user_id = clerk_user_id`, `paired_at = now`, `revoked_at = None`.
5. `token = sign_device_jwt(device_id, clerk_user_id)`; set `pc.user_id`, `pc.status = "paired"`, `pc.device_jwt = token`. Commit. The lamp's next `/poll-pairing` then receives the token.
6. **Audit**: `log_event(device_id, clerk_user_id, "paired", {friendly_name})` (fire-and-forget, no-op without DB).
7. Return `device_id`, `friendly_name`.

#### `GET /api/devices` ([device_user.py:125](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L125)) — Clerk, 60/minute
- **Response** `DeviceListOut`: `{devices: [DeviceListItem]}`.

Query: `Device WHERE user_id == clerk_user_id AND revoked_at IS NULL ORDER BY paired_at DESC NULLS LAST`. For each row builds a `DeviceListItem` with `online = bool(last_seen_at and (now - last_seen_at) <= ONLINE_WINDOW)` (i.e. seen within 60 s) ([device_user.py:148-157](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L148)).

#### `POST /api/device/{device_id}/unlink` ([device_user.py:161](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L161)) — Clerk, 60/minute, **204 No Content**
1. `device = db.get(Device, device_id)`; `None` → **404 `NOT_FOUND`**.
2. Ownership: `device.user_id != clerk_user_id` → **403 `NOT_OWNER`**.
3. Set `revoked_at = now`, `user_id = None`. Commit.
4. `publish_revoked(device_id)` — fire-and-forget Redis signal to any WS gateway holding this lamp's socket (close 4402). If Redis is off, the WS heartbeat catches up within ~30 s.
5. `clear_history(device_id)` — wipe the device-scoped short-term conversation history so the NEXT pairing of this physical lamp can't see the prior owner's turns.
6. `log_event(device_id, clerk_user_id, "unlinked", {})`. Return `None`.

#### `POST /api/device/{device_id}/rename` ([device_user.py:209](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L209)) — Clerk, 60/minute
- **Request** `DeviceRenameIn`: `friendly_name` (1-60 chars). **Response** `DeviceRenameOut`: `device_id`, `friendly_name`.
1. `device = db.get(Device, device_id)`; `None` → **404 `NOT_FOUND`**; not owner → **403 `NOT_OWNER`**.
2. `device.friendly_name = body.friendly_name.strip()`. Commit. Return the new name.

### 7.5 clerk_webhook.py — lifecycle events
File: [`app/routes/clerk_webhook.py`](../../Smart-Tutor-Lamp-backend/app/routes/clerk_webhook.py). Prefix `/api/clerk`, tag `webhook`. References `IMPLEMENTATION_AUTH_PAIRING.md §6.1.9 / §10 case 10`.

#### `POST /api/clerk/webhook` ([clerk_webhook.py:33](../../Smart-Tutor-Lamp-backend/app/routes/clerk_webhook.py#L33)) — Svix-signed, unlimited
Subscribed events: `user.deleted` (act), `user.created`/`user.updated` (no-op).

**Step-by-step — verify FIRST, then work:**
1. If `CLERK_WEBHOOK_SECRET` unset → **503 `AUTH_DISABLED`** (refuse to silently accept unsigned events).
2. Import `svix.webhooks`; if missing → **503 `AUTH_SDK_MISSING`**.
3. Read raw `payload = await request.body()`; collect headers `svix-id`, `svix-timestamp`, `svix-signature`; missing any → **400 `WEBHOOK_BAD_HEADERS`**.
4. `event = Webhook(CLERK_WEBHOOK_SECRET).verify(payload, headers)`; `WebhookVerificationError` → **400 `WEBHOOK_BAD_SIG`** (logged at WARNING).
5. Extract `event_type` and `data`.
6. **`user.deleted`** ([clerk_webhook.py:80-110](../../Smart-Tutor-Lamp-backend/app/routes/clerk_webhook.py#L80)):
   - `clerk_user_id = data["id"]`; missing → return `{ok:true}` (log WARNING).
   - `SELECT Device WHERE user_id == clerk_user_id`. For each: set `revoked_at = now`, `user_id = None`, collect `device_id`. Commit.
   - For each revoked device: `publish_revoked(device_id)` (snaps live sockets to close 4402) AND `clear_history(device_id)` (the account is gone; its conversation must not survive a re-pair).
   - Return `{ok:true, revoked: <count>}`.
7. Any other event → return `{ok:true}` silently so Clerk doesn't retry.

The Svix signature is the **only** thing standing between an attacker and free user-deletion, hence verify-before-work.

### 7.6 frontend_manager.py — identity, profile, analytics, brain bench
File: [`app/routes/frontend_manager.py`](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py) (~2100 lines). Prefix `/api/frontend`, tag `frontend-manager`. Every HTTP route gates on `current_clerk_user`; the lamp never reaches these. This is the largest router — it covers identity/profile/analytics, the legacy tiered `/simulate`, the multi-LLM `/solve` family, feedback, and a streaming WS gateway.

#### Identity / profile / analytics

**`GET /me`** ([frontend_manager.py:96](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L96)) — 120/min. Returns `MeOut{user_id, email, has_profile, onboarding_complete, is_admin}`. Loads the profile via `get_profile`; resolves `email` from the JWT payload (`email`/`primary_email`) else the persisted profile `extra.email` ([frontend_manager.py:109-110](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L109)); resolves `is_admin` via `admin.is_admin(db, clerk_user_id, email)` so the frontend's Admin nav needs no extra round-trip.

**`GET /profile`** ([frontend_manager.py:124](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L124)) — 120/min. `response_model=ProfileOut | None`. Returns the profile mapped by `_profile_out`, or **`200` + `null` body** when not onboarded (a normal state, not a 404 — the frontend redirects to `/onboarding`).

**`PUT /profile`** ([frontend_manager.py:138](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L138)) — 30/min. Body `ProfileIn` (validated fields below). Calls `upsert_profile(...)` writing `full_name`, `phone`, `target_exam`, `prep_duration`, `onboarding_complete=True`, and an `extra` JSONB bag (`email`, `learning_style`, `explain_depth`, `study_rhythm`, `focus_subject`, `strong_subject`, `weak_subject`). Returns `ProfileOut`.

`_profile_out(row)` ([frontend_manager.py:78](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L78)) flattens the durable row + its `extra` JSONB into `ProfileOut`.

`ProfileIn` validation ([schemas/frontend.py:32](../../Smart-Tutor-Lamp-backend/app/schemas/frontend.py#L32)): `full_name` (2-120), `email` (≤254, optional), `phone` (≤32, optional), `target_exam ∈ {JEE,NEET,CAT,UPSC}`, `prep_duration` (1-60), plus optional `learning_style/explain_depth/study_rhythm/focus_subject/strong_subject/weak_subject`. `extra="ignore"` so unknown fields are dropped.

**`GET /analytics`** ([frontend_manager.py:168](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L168)) — 60/min. Returns `AnalyticsOut` from `user_analytics(db, clerk_user_id)` (device counts, turn counts, 7-day, sessions, subject mix, per-device summaries). Tolerant of an empty `turns` table (zeros).

**`GET /analytics/detail`** ([frontend_manager.py:179](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L179)) — 60/min, `?days=1..90` (default 14). Returns `AnalyticsDetailOut` (timeline `daily`, distributions, latency `p50/p95`, `escalated_pct`, `recent` turns) from `user_analytics_detail`.

#### `POST /simulate` ([frontend_manager.py:195](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L195)) — Clerk, 30/min
The **legacy** one-shot multimodal simulate for the `/simulator` page. `multipart/form-data`: `text` (Form), `audio` (File), `image` (File, legacy single), `images` (File list). Returns `gemini_brain.SimResponse` `{speech, display, confidence, query_type, subject, difficulty, user_input, …}`. It mirrors the lamp orchestrator's tiered Gemini dispatch.

Detailed flow ([frontend_manager.py:216-640](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L216)):
1. **Guard**: `gemini_brain.available()` else **503 `BRAIN_UNAVAILABLE`**.
2. **Concurrent context load**: `ctx_task = _load_turn_context(db, clerk_user_id)` runs in parallel with input reading + enhancement ([frontend_manager.py:226](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L226)). `_load_turn_context` ([frontend_manager.py:754](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L754)) fetches `profile` ∥ (`open_session` → `load_context`) for `device_id = f"websim-{clerk_user_id}"`; returns `(profile, device_id, session_id, history)`.
3. **Read inputs**: read the WAV; merge legacy `image` + `images[]`, drop empties, `_dedupe_blobs` (sha256, order-preserving — older builds double-send the first photo), cap at `MAX_IMAGES_PER_TURN` (truncate, not reject).
4. **Image enhancement**: if `ENABLE_IMAGE_ENHANCEMENT`, run `enhance_for_llm(b, max_dim=2048)` off-thread per blob (CLAHE + unsharp + contrast). `max_dim=2048` (not the default 1280) preserves small-handwriting pixels. Swallows its own errors (returns raw bytes).
5. **Empty input** → cancel ctx_task, **422 `EMPTY_INPUT`**.
6. `profile, device_id, session_id, history = await ctx_task`.
7. **Deterministic PRE-router** (if `PREROUTE_ENABLED`): assemble `preroute_text` from typed text, or a fast Groq-Whisper transcript via `_safe_sim_stt` when audio-only and `PREROUTE_STT_ENABLED`; assess `image_quality = await asyncio.to_thread(assess_image_quality, image_blobs)` when `PREROUTE_IMAGE_QUALITY_GATE` (fixed 2026-07-04 — `assess_image_quality` is synchronous/CPU-bound PIL+numpy work, so calling it inline was blocking the event loop on every turn's pre-route gate; now off-thread, same fix as the `_solve_auto` call site — [doc 04 §7.4](04-escalation-and-model-selection.md)); call `preroute(text, image_quality, n_images)` → `start_tier`, `prompt_suffix`, `focus_label`, `retake_image`. **Retake short-circuit**: if image too poor, return a "please retake" `SimResponse` with **zero LLM spend** ([frontend_manager.py:308-316](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L308)).
8. **Problem memo** (solve-once, tutor-many): `problem_memo.load(session_id)`; pre-call **nudge gate** (`solve_authorized`); **dispute guard** (`is_dispute` → fresh Pro re-derivation, no answer key, force tier-3 if enabled); else inject the cached `answer_key_block` and clamp `start_tier→1`; else (if `MEMO_CAPTURE_QUESTION`) inject a question-context block.
9. **Tiered dispatch**: `_sim_call_tier(start_tier, …)`; then a series of guards (see §8): semantic-dispute backstop, focus guard, memo identity verdict, smart-skip escalation loop, solution-bleed guard, reveal-completeness guard. Persist the ground-truth solution to the memo on an escalated solve.
10. **Error handling** ([frontend_manager.py:607-623](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L607)): on any exception, if the message contains `503/UNAVAILABLE/high demand/429/RESOURCE_EXHAUSTED` → **503 `BRAIN_BUSY`**, else **502 `BRAIN_ERROR`**.
11. **Persistence** (fire-and-forget): `_persist_simulation` maps the web `{speech, display}` onto the lamp's `LlmReply` and writes to Supabase `turns` + Redis L1 + a background L3 refresh, tagged `source=simulation, channel=web`, `device_id=websim-<user>`.

#### Multi-LLM evaluation surface (`/models`, `/solve`, `/solve/compare`, `/feedback`)

These route through the provider-agnostic `generate_solution()` so the web never knows which SDK answered, and they add latency/token/cost telemetry.

**`GET /models`** ([frontend_manager.py:900](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L900)) — 120/min. Returns `ModelsOut{models:[ModelInfo], default_model}`. Each `ModelInfo` flags `available` only when its provider's API key is configured (`model_catalog.is_available`), plus `vision/audio/input_per_mtok/output_per_mtok/note/is_default`.

**`POST /solve`** ([frontend_manager.py:1464](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1464)) — 30/min. Multipart `text`, `model` (Form), `audio`, `image`, `images`. Returns `SolveOut{response: SimResponse, meta: SolveMeta}`.
- Concurrent `_load_turn_context` ∥ `_read_solve_inputs` (shared reader: WAV + merged/deduped/capped/enhanced blobs + `enhance_ms`). Empty input (after cancel) → **422 `EMPTY_INPUT`**.
- A **passive `TurnTracer`** (`source="simulator"`) records the storyboard for the admin trace (upload, image_enhance, stt skip, etc.) — every tracer call swallows its own errors; the solve flow is unaffected.
- `model == "auto"` → run `_solve_auto(...)` (the lamp's full tiered plan with a per-step `AutoStep` breakdown) bounded by `asyncio.wait_for(timeout=SOLVE_TIMEOUT_S)`; timeout → a `status="timeout"` `SolveResult`.
- Otherwise a **direct model pick**: optional dispute-guard note injection, then `generate_solution(model, …)`, then a **direct-pick solution-bleed guard** (`SOLVE_DIRECT_BLEED_GUARD`) that re-calls within the remaining wall-clock budget and bills BOTH calls honestly ([frontend_manager.py:1568-1627](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1568)).
- Pre-generates `request_id`, `response_id`, `turn_uuid` so the HTTP reply hands the frontend a `response_id` for feedback WITHOUT waiting on the fire-and-forget `_persist_solve_eval`. Finalizes the tracer (fire-and-forget). Returns `SolveOut`.

**`POST /solve/compare`** ([frontend_manager.py:1706](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1706)) — 15/min. Multipart with repeated `models` (or comma-separated). Parses model ids, de-dupes preserving order, **caps to the catalog size** so a crafted request can't fan out unbounded provider calls, and **drops `"auto"`** (multi-call flow doesn't fit the grid). Runs `generate_solution` for each model **concurrently via `asyncio.gather`**, persists one `model_requests` + N `model_responses` (compare turns are NOT mirrored into `turns` to avoid inflating history), returns `CompareOut{results:[SolveOut]}` in request order.

**`POST /feedback`** ([frontend_manager.py:1778](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1778)) — 60/min. Body `FeedbackIn{response_id, thumbs∈{up,down}?, rating∈1..5?, feedback_text≤2000?}`. Calls `record_feedback(...)` (UPSERT per (response, user)). Returns `FeedbackOut{ok}`.

**Helpers worth naming:** `_meta` ([frontend_manager.py:971](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L971)) builds `SolveMeta` from a `SolveResult`; `_tok_words(tok)` = `round(tok * 0.75)` (token→word estimate for the non-technical trace); `_vendor_price` defaults to `(0.30, 2.50)` USD/Mtok when a vendor isn't in the catalog; `_step_cost` = `i*p_in/1e6 + (o+thinking)*p_out/1e6` rounded to 6 dp; `_persist_solve_eval` ([frontend_manager.py:1796](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1796)) writes the eval rows and mirrors successful single-model answers into `turns`.

#### Streaming brain WebSocket — `WS /api/frontend/ws`
([frontend_manager.py:1920](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1920)) — auth via `verify_ws_token(?token=)`; bad token → close **4401**. Uses the **same binary frame protocol as the lamp** (`app/protocol.py`) so browser and physical lamp hit the same brain.

Flow:
1. Verify the Clerk WS token; accept; send `STATE(IDLE)`; load profile via `_load_profile_ws`.
2. Receive loop: ignore non-binary frames; decode each via `_decode` → bad frame closes **1002**.
3. Frame handling: `CANCEL` cancels the in-flight turn + clears audio + `STATE(IDLE)`; `IMAGE_JPEG` stores `latest_image`; `AUDIO_CHUNK` appends; `TEXT_IN` cancels in-flight then starts `_drive_turn` with text; `AUDIO_END` joins PCM → WAV (`_pcm_to_wav` at `BRAIN_AUDIO_SAMPLE_RATE`=16000, mono/16-bit) then starts a turn; other frames dropped silently.
4. `_build_stream` picks `gemini_brain.respond` when available, else `web_simulator.respond`.
5. `_drive_turn` ([frontend_manager.py:2030](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2030)) streams `BrainEvent`s: `state`→STATE frame; `text`→TEXT_OUT + sentence-buffer split (`_SENTENCE_END_RE = ([.!?])(\s|$)`) → `_speak_sentence` per completed sentence (first audio lands ~700 ms after end-of-speech); `text_end`→flush tail + TEXT_OUT_END; finally AUDIO_OUT_END.
   - **FRONTEND ISOLATION** ([frontend_manager.py:2032-2039](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2032)): TTS uses `FRONTEND_TTS_PROVIDER` (Literal `piper`/`none`), NOT `TTS_PROVIDER`. The browser surface can therefore NEVER call Gemini TTS or spend Gemini audio tokens — flipping `TTS_PROVIDER=gemini` affects the ESP32 lamp only. `get_tts_provider("piper")` also lazily imports only `tts_piper`.
6. On exception: send `STATE(ERROR)`, `TFT_TEXT("Sorry, the brain stumbled…")`, AUDIO_OUT_END, `STATE(IDLE)`. On disconnect/finally: cancel and await the in-flight task (3 s timeout).

### 7.7 admin.py — system-wide read dashboard
File: [`app/routes/admin.py`](../../Smart-Tutor-Lamp-backend/app/routes/admin.py). Prefix `/api/frontend/admin`, tag `admin`. Every route gates on `require_admin`. **Read-only by design** — nothing mutates except `/media/cleanup`. Routes delegate to `app.services.admin` (`admin_svc`) and `app.services.media_cleanup` (`media_svc`); they surface the `SUPABASE_QUERIES.md` cookbook insights to a web dashboard.

| Endpoint | Service call | Query params | Notes |
|---|---|---|---|
| `GET /overview` | `admin_svc.overview(db, days)` | `days=1..90` (14) | health snapshot + cost + daily activity + distributions + event counts |
| `GET /models` | `admin_svc.model_stats(db, days)` | `days=1..90` (14) | 60/min; multi-LLM eval rollups from `model_*` tables (NOT `turns`) |
| `GET /users` | `admin_svc.list_users(db, limit)` | `limit=1..1000` (200) | every onboarded user + paired count, turns, spend, last activity |
| `GET /devices` | `admin_svc.list_devices(db, limit)` | `limit=1..1000` (300) | all lamps + pairing status + online flag + owner |
| `GET /sessions` | `admin_svc.list_sessions(db, limit)` | `limit=1..500` (100) | recent sessions across all lamps |
| `GET /turns` | `admin_svc.list_turns(db, limit, user_id, status)` | `limit=1..200` (50), `user_id`, `status` (alias) | latest turns system-wide, optional filters; empty strings → `None` |
| `GET /turns/{turn_id}/trace` | `admin_svc.turn_trace(db, turn_id)` | path | full per-turn pipeline audit; 120/min |
| `GET /media` | `media_svc.media_stats(db)` | — | storage snapshot card |
| `POST /media/cleanup` | `media_svc.cleanup_media(db, days)` | body `MediaCleanupIn` | 10/min; MANUAL retention only |
| `GET /events` | `admin_svc.list_events(db, limit)` | `limit=1..500` (100) | recent lifecycle events |

All list endpoints wrap rows in `{rows:[...]}`. The response schemas ([schemas/admin.py](../../Smart-Tutor-Lamp-backend/app/schemas/admin.py)) default every field so a not-yet-migrated table renders empty rather than 500-ing.

**`GET /turns/{turn_id}/trace`** ([admin.py:148](../../Smart-Tutor-Lamp-backend/app/routes/admin.py#L148)) — accepts a `turns.id` (normal) OR a `turn_traces.id` (failed/retake turns that never wrote a `turns` row). `None` → **404 `TRACE_NOT_FOUND`**. For each of `raw_audio_url/raw_image_url/enhanced_image_url`, runs `_browser_url` ([admin.py:134](../../Smart-Tutor-Lamp-backend/app/routes/admin.py#L134)): a `file://` URI is rewritten to `{request.base_url}/blobs/{filename}` (the static mount); `http(s)`/relative URLs pass through untouched.

**`POST /media/cleanup`** ([admin.py:186](../../Smart-Tutor-Lamp-backend/app/routes/admin.py#L186)) — body `MediaCleanupIn{days=1..365 (14)}`. The ONLY deletion path (no scheduled auto-delete anywhere). Deletes stored audio/images older than `days` days and nulls their URL pointers; turn/trace rows + all text/timing data are untouched. Batched per call; the `MediaCleanupOut` reports `turns_cleared/traces_cleared/objects_deleted/remaining_turns/remaining_traces`. Wraps the service in try/except → `MediaCleanupOut(ok=False, error=...)` on failure ([admin.py:201-205](../../Smart-Tutor-Lamp-backend/app/routes/admin.py#L201)).

### 7.8 ws_lamp.py — summary
File: [`app/routes/ws_lamp.py`](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py). The **lamp's** WebSocket endpoint `WS /lamp/ws` (Layer 1.2). Full binary protocol detail belongs to the protocol doc; the HTTP/auth-relevant facts:

- **Auth modes** by `ENABLE_AUTH`:
  - `False` (dev): `_authenticate_dev` accepts any Bearer (incl. literal `dev-mode-no-auth`) → identity `("dev-lamp", None, None)`; dev turns persist with `user_id=NULL`.
  - `True` (prod): `_authenticate_prod` verifies `device_jwt` then a per-connect DB check: `devices.user_id IS NOT NULL`, `revoked_at IS NULL`, `user_id == jwt["uid"]`. Failure → close **4401** (bad jwt) or **4402** (unlinked). Success bumps `last_seen_at`.
- **Close codes**: `WS_CLOSE_BAD_JWT = 4401`, `WS_CLOSE_UNLINKED = 4402`, idle close `1000`.
- **On accept**: open a `sessions` row (`open_session`), `log_event("ws_open")`. For prod auth, spawn (a) a `watch_revocation` task — a Redis-published unlink closes the socket within ~1 s with `STATE(0x05 UNPAIRED)` then 4402; and (b) a `HEARTBEAT_S = 30.0` s heartbeat that bumps `last_seen_at` and re-checks `revoked_at` (the Redis-down fallback).
- **Idle backstop**: `WS_IDLE_TIMEOUT_S = 600.0` s. Implemented via `asyncio.wait_for(ws.receive_bytes(), timeout=…)` because Starlette's `iter_bytes` blocks forever on a half-dead TCP. Re-arms (doesn't close) when a turn is in flight or there's been traffic in either direction within the window.
- **Resilience**: a malformed frame is logged + dropped (no close); a `session.on_frame` exception is logged but the socket stays open.
- **On close/finally**: `log_event("ws_close")`, `finalize_session(...)` (closes the sessions row + refreshes the L3 learner profile), `session.close()`.

---

## 8. Key Algorithms

### 8.1 Pairing-code generation & collision retry
`generate_pairing_code()` ([pairing.py:18](../../Smart-Tutor-Lamp-backend/app/services/pairing.py#L18)) draws 6 chars from `string.ascii_uppercase + string.digits` (36 chars) via `secrets.choice` (CSPRNG). Keyspace 36⁶ ≈ 2.1 B. `/register` loops up to **8** attempts checking `db.get(PairingCode, code)`; exhaustion → 500. With a 5-min TTL + rate limits the loop "fires ~never".

### 8.2 Online detection
`/api/devices` flags `online = bool(last_seen_at and (now - last_seen_at) <= ONLINE_WINDOW)` with `ONLINE_WINDOW = 60 s`. `last_seen_at` is bumped on WS connect and every 30 s heartbeat — so a lamp stays "online" for up to one heartbeat past its last beat.

### 8.3 Verified-token caching (login hot path)
See §3.1. Cache by exact token string, 30 s TTL, per-token lock collapsing a burst to one JWKS verify; full-cache clears wholesale. The cache lives in `app/deps/clerk.py`.

### 8.4 Web tiered escalation — `_sim_pick_next_tier` / `_sim_resolve_tier`
([frontend_manager.py:647-691](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L647)). The web smart-skip router mirrors the lamp orchestrator's `_pick_next_tier`, routing purely on the model's self-reported analytics (the web brain has no per-call truncation `status`). `_sim_pick_next_tier(sim, current_tier)`:
1. `confidence >= 0.75` AND `difficulty ∈ {easy,medium}` → `target = None` (ship).
2. `difficulty == "hard"` AND (`confidence < 0.7` OR `query_type ∈ {derivation,calc,mistake_id}`) → **`target = 3`** (HARD → Pro directly; flash-with-thinking observed truncating).
3. `confidence <= 0.30` (inclusive — 0.30 was slipping to t2) → `target = 3`.
4. `confidence < GEMINI_ESCALATE_CONFIDENCE` → `target = 2`.
5. else `None`.
- **Semantic check floor**: if `SEMANTIC_CHECK_ESCALATION` and `query_type ∈ {check, mistake_id}`, set `floor = 3 if hard else 2` and `target = max(target, floor)` (does NOT gate on difficulty — the self-rating is unreliable for verification turns).

`_sim_resolve_tier(target)` clamps: `≥4 → 3`; `≥3 and not GEMINI_TIER3_ENABLED → 2`; `None` stops the loop. The escalation `while` loop runs only while `GEMINI_DYNAMIC_THINKING` and (`not memo_matched` or `confidence < 0.3`).

### 8.5 Per-tier dispatch & cost
`_sim_call_tier` / `_auto_call` map tier→model/budget identically to the lamp: tier 1/2 use `GEMINI_MODEL` (Flash), tier 3 uses `GEMINI_TIER3_MODEL` (Pro), each with its own `GEMINI_TIER{1,2,3}_THINKING_BUDGET` and `_MAX_OUTPUT_TOK`. Tier ≥2 appends `problem_memo.SOLVE_SUFFIX` so the stronger model writes the full internal solution for the memo. `cap_override` (reveal turns) raises the output cap to `SOLVE_REVEAL_MAX_OUTPUT_TOK` so an authorized full walkthrough can't truncate into the salvage path. `_auto_call` additionally returns usage telemetry for the per-step breakdown.

### 8.6 Image dedup & enhancement
`_dedupe_blobs` ([frontend_manager.py:778](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L778)) hashes each blob with sha256 and drops byte-identical duplicates, order-preserving (older frontends send the first photo in both `image` and `images[]`; the dup was enhanced twice — 2× CPU + an OpenCV memory burst that OOM-killed the free tier — and billed twice by Gemini). Enhancement runs `enhance_for_llm(b, max_dim=2048)` per blob off-thread via `asyncio.to_thread` + `asyncio.gather`.

### 8.7 Solve-once, tutor-many (problem memo) + guards
Across `/simulate` and `_solve_auto`: load a per-session memo; a matched memo injects an internal **answer key** and clamps to tier-1; an unmatched memo is flushed; an escalated solve SAVES the ground truth so later turns nudge at tier-1 prices. Defensive corrective re-calls (each "best-effort", degrade to shipping as-is, never 500): **focus guard** (asked Q-N but model OCR'd other numbers), **solution-bleed guard** (a tier≥2/keyed reply leaked the answer into speech/display/KaTeX), **reveal-completeness guard** (an authorized reveal that omitted the final answer), **dispute guard** (regex + semantic model-flag → fresh Pro re-derivation, no key). `_solve_auto` additionally guards each extra call with `_low_budget(reserve_s=20.0)` — skip a guard re-call when within ~20 s of `SOLVE_TIMEOUT_S` (shipping an imperfect reply beats `wait_for` discarding the already-paid result).

### 8.8 Sentence streaming (WS bench)
`_SENTENCE_END_RE = re.compile(r"([.!?])(\s|$)")`; `_split_sentence` returns the first complete sentence + the remainder so each sentence is handed to TTS as it completes (~700 ms first-audio latency, `BACKEND_DESIGN.md §3`).

---

## 9. Configuration, Constants & Env Vars

Settings live in [`app/config.py`](../../Smart-Tutor-Lamp-backend/app/config.py). Those that affect the routes:

| Setting | Default | Used by / effect |
|---|---|---|
| `ENABLE_AUTH` | — | Mounts (or not) every auth/pairing/frontend/admin router; gates `current_clerk_user`; selects WS auth mode |
| `DATABASE_URL` | — | Required for auth; enables persistence; affects `/readyz` |
| `REDIS_URL` | — | Limiter shared storage; revocation pub/sub; history; `/readyz` |
| `CLERK_SECRET_KEY` | — | `current_clerk_user` SDK verify |
| `CLERK_WEBHOOK_SECRET` | — | Svix verify; unset → webhook 503 |
| `CLERK_PUBLISHABLE_KEY` / `CLERK_JWKS_URL` / `CLERK_ISSUER` | — | WS token verify (`/api/frontend/ws`) |
| `DEVICE_JWT_SECRET` | `""` | HS256 device_jwt sign/verify |
| `DEVICE_JWT_ISS` | `lumos-auth` | device_jwt issuer claim |
| `PAIRING_CODE_TTL_SEC` | `300` | Pairing code lifetime + `expires_in` |
| `FRONTEND_BASE_URL` | `http://localhost:3000` | `pairing_url`; an authorized party |
| `CORS_ALLOWED_ORIGINS` | — | CORS exact list + authorized parties |
| `SOLVE_TIMEOUT_S` | `30.0` | `_solve_auto` wall clock; `_low_budget` reserve |
| `FRONTEND_TTS_PROVIDER` | `piper` (`piper`/`none`) | WS bench TTS isolation (never Gemini) |
| `BRAIN_AUDIO_SAMPLE_RATE` | `16000` | `_pcm_to_wav` |
| `ENABLE_IMAGE_ENHANCEMENT` | — | Whether `/simulate`/`/solve` run `enhance_for_llm` |
| `PREROUTE_ENABLED` / `PREROUTE_STT_ENABLED` / `PREROUTE_IMAGE_QUALITY_GATE` | — | Deterministic pre-router gating |
| `GEMINI_MODEL` / `GEMINI_TIER3_MODEL` / `GEMINI_TIER3_ENABLED` | — | Tier→model map |
| `GEMINI_TIER{1,2,3}_THINKING_BUDGET` / `_MAX_OUTPUT_TOK` | — | Per-tier budgets |
| `GEMINI_DYNAMIC_THINKING` / `GEMINI_ESCALATE_CONFIDENCE` / `SEMANTIC_CHECK_ESCALATION` | — | Escalation gate |
| `SOLVE_REVEAL_MAX_OUTPUT_TOK` | — | Reveal-turn output cap |
| `DISPUTE_GUARD` / `SOLVE_DIRECT_BLEED_GUARD` / `MEMO_CAPTURE_QUESTION` | — | Guards / memo capture |
| `STORAGE_BACKEND` / `STORAGE_LOCAL_DIR` / `STORAGE_PUBLIC_BASE_URL` | — | `/blobs` mount; admin trace URL rewriting |
| `LOG_ALL_REQUESTS` | — | Request tracer verbosity |

**In-code constants:** `ONLINE_WINDOW = 60 s` ([device_user.py:48](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L48)); pairing collision retries = 8; `_VERIFY_TTL_SEC = 30 s` / `_VERIFY_CACHE_MAX = 1024` ([clerk.py:100](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L100)); `WS_CLOSE_BAD_JWT=4401` / `WS_CLOSE_UNLINKED=4402` / `HEARTBEAT_S=30.0` / `WS_IDLE_TIMEOUT_S=600.0` ([ws_lamp.py:48-66](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L48)); `JWT_VERSION=1` ([device_jwt.py:24](../../Smart-Tutor-Lamp-backend/app/services/device_jwt.py#L24)); `PAIRING_CODE_LEN=6` ([pairing.py:15](../../Smart-Tutor-Lamp-backend/app/services/pairing.py#L15)); token→word factor `0.75` ([frontend_manager.py:968](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L968)); default vendor price `(0.30, 2.50)`; `_low_budget reserve_s=20.0`.

---

## 10. Edge Cases, Errors, Timeouts, Fallbacks

- **`ENABLE_AUTH=False`**: frontend/pairing routers unmounted → 404; `current_clerk_user` → 503 `AUTH_DISABLED`; lamp WS uses `dev-lamp`.
- **No DB / DB init failure with auth off**: app continues **stateless** (no session/turn persistence); all persistence is fire-and-forget and swallows errors, so the bench/lamp still answer ([main.py:90-101](../../Smart-Tutor-Lamp-backend/app/main.py#L90)).
- **Redis down**: limiter fails OPEN (in-memory fallback, ~1 s timeout); revocation falls back to the 30 s WS heartbeat `revoked_at` check; history degrades to none.
- **Pairing recovery**: an already-paired lamp without a JWT gets `already_paired` + a fresh JWT from `/register`; a single-use `/poll-pairing` paired result is deleted so the next poll 404s.
- **Expired codes**: swept opportunistically in `/register` and lazily in `/poll-pairing`/`/pairing-info`; surfaced as `status="expired"` (poll) or **410 `CODE_EXPIRED`** (info/complete).
- **Concurrent claims**: `complete-pairing` serializes with `SELECT … FOR UPDATE`; cross-user conflict → **409 `ALREADY_PAIRED`**.
- **Empty multimodal input**: 422 `EMPTY_INPUT` (after cancelling the concurrent context task).
- **Provider overload**: `/simulate` → 503 `BRAIN_BUSY` on transient overload strings, else 502 `BRAIN_ERROR`; `/solve` AUTO `is_busy_error` → `status="busy"`; AUTO timeout → `status="timeout"`.
- **Image too many**: truncated to `MAX_IMAGES_PER_TURN`, never rejected. **Image enhancement failure**: logged, raw frames used.
- **`/solve/compare` fan-out cap**: de-duped + capped to catalog size; `"auto"` dropped.
- **Bad WS frame**: lamp WS drops it (no close); bench WS closes 1002. **Half-dead TCP**: lamp WS idle backstop closes 1000 after 600 s of true silence.
- **Guards are best-effort**: focus/bleed/reveal/dispute guards each degrade to shipping the reply as-is — never a 500.
- **Admin trace not found**: 404 `TRACE_NOT_FOUND`. **Media cleanup failure**: `MediaCleanupOut(ok=False)` (200, not 500).
- **Persistence never blocks**: every `_persist_*` is `asyncio.create_task` / fire-and-forget and swallows exceptions.

---

## 11. Integration Points (Cross-References)

**Inbound (who calls the routes):**
- **Firmware (ESP32-S3 lamp)** → `POST /api/device/register`, `POST /api/device/poll-pairing`, `WS /lamp/ws` (device_jwt Bearer). Never touches Clerk routes.
- **Next.js frontend** → all `/api/frontend/*`, `/api/devices`, `/api/device/{id}/{unlink,rename}`, `/api/device/complete-pairing`, `/api/pairing-info/{code}`, `WS /api/frontend/ws`. The dashboard fires `/me`+`/profile`+`/analytics` concurrently (the token cache exists for exactly this).
- **Web simulator page** → `/api/frontend/simulate`, `/models`, `/solve`, `/solve/compare`, `/feedback`, `WS /api/frontend/ws`.
- **Admin dashboard** (`lib/admin.ts`) → `/api/frontend/admin/*`.
- **Clerk** → `POST /api/clerk/webhook` (Svix-signed).
- **Load balancers / k8s** → `/healthz`, `/readyz`.

**Outbound (what the routes call):**
- **DB models** ([app/db/models.py](../../Smart-Tutor-Lamp-backend/app/db/models.py)): `Device`, `PairingCode`, `UserProfile`, `Session`, `Turn`, `TurnTrace`, `Event`, model-eval tables. Postgres/Supabase via `get_db` / `get_session_factory`.
- **Services**: `device_jwt` (sign/verify), `pairing` (code gen), `revocation` (`publish_revoked`/`watch_revocation`/Redis), `memory.clear_history`, `session_memory` (`load_context`/`record_turn`/`update_user_memory`/`finalize_session`), `problem_memo`, `escalation_router` (`preroute`/`assess_image_quality`/`focus_mismatch`), `model_solver` (`generate_solution`/`is_busy_error`), `model_catalog`, `analytics`, `admin` (`is_admin` + rollups), `media_cleanup`, `turn_trace.TurnTracer`.
- **Providers**: `gemini_brain` (`simulate`/`respond`/`available`/`SimResponse`), `web_simulator`, `tts_base.get_tts_provider`, `image_preprocessor.enhance_for_llm`, `llm_claude._stt_via_groq`.
- **Storage**: `user_profiles`, `turns.open_session`, `events.log_event`, `model_eval` (`record_request`/`record_response`/`record_feedback`/`seed_providers`).
- **Protocol**: `app/protocol.py` (`FrameType`, `StateByte`, `encode`/`decode`) — shared with firmware.
- **Database (pgvector)**: memory/vectors are reached via the session_memory/problem_memo services, not the routes directly.

---

## 12. Mermaid Diagrams

### 12.1 Pairing lifecycle (lamp + frontend + DB)

```mermaid
sequenceDiagram
    participant Lamp as ESP32 Lamp
    participant Reg as POST /api/device/register
    participant Poll as POST /api/device/poll-pairing
    participant FE as Next.js /pair/[code]
    participant Info as GET /api/pairing-info/{code}
    participant Comp as POST /api/device/complete-pairing
    participant DB as Postgres (devices, pairing_codes)

    Lamp->>Reg: device_id + device_secret
    Reg->>DB: sweep expired codes; upsert Device (argon2 hash)
    alt already paired, no JWT
        Reg-->>Lamp: 200 {status:"already_paired", device_jwt}
    else first/unpaired
        Reg->>DB: delete old codes; INSERT PairingCode(pending, ttl=300s)
        Reg-->>Lamp: 200 {pairing_code, pairing_url, expires_in}
    end
    loop every 3s (≤40/min)
        Lamp->>Poll: device_id + secret + code
        Poll->>DB: get PairingCode
        Poll-->>Lamp: {status:"pending"}
    end
    FE->>Info: GET /api/pairing-info/{code}
    Info->>DB: validate code + device (not expired, not linked)
    Info-->>FE: {device_id, friendly_name, expires_at}
    FE->>Comp: Clerk Bearer + {pairing_code}
    Comp->>DB: SELECT device FOR UPDATE; set user_id, paired_at
    Comp->>DB: pc.status="paired", pc.device_jwt=sign_device_jwt()
    Comp-->>FE: 200 {device_id, friendly_name}
    Lamp->>Poll: next poll
    Poll->>DB: status=="paired" → delete row (single-use)
    Poll-->>Lamp: 200 {status:"paired", device_jwt}
    Lamp->>Lamp: store JWT, leave QR screen, open /lamp/ws
```

### 12.2 `POST /api/frontend/solve` control flow

```mermaid
flowchart TD
    A[POST /solve multipart] --> B[verify Clerk token]
    B --> C[ctx_task: profile ∥ session→history]
    B --> D[_read_solve_inputs: WAV + dedupe + cap + enhance]
    C --> E{empty input?}
    D --> E
    E -- yes --> F[cancel ctx; 422 EMPTY_INPUT]
    E -- no --> G[TurnTracer source=simulator]
    G --> H{model == auto?}
    H -- yes --> I[_solve_auto wait_for SOLVE_TIMEOUT_S]
    I --> I1[pre-route → tier-1 → guards → escalation loop]
    I -- timeout --> I2[SolveResult status=timeout]
    H -- no --> J[generate_solution model]
    J --> K{direct-pick bleed guard?}
    K -- tripped + not authorized --> L[one corrective re-call, bill both]
    K -- ok --> M[keep result]
    I1 --> N[build response_id/turn_uuid]
    I2 --> N
    L --> N
    M --> N
    N --> O[fire-and-forget _persist_solve_eval + tracer.finalize]
    O --> P[return SolveOut response+meta]
```

### 12.3 Auth decision per audience

```mermaid
flowchart LR
    subgraph Lamp
      R1[/register, /poll-pairing/] --> AS[device_id+secret argon2id]
      WL[/lamp/ws/] --> DJ[device_jwt HS256 + DB row check]
    end
    subgraph Frontend
      FR[/api/frontend/*, /api/devices.../] --> CC[current_clerk_user JWKS+cache]
      WB[/api/frontend/ws/] --> CW[verify_ws_token ?token=]
    end
    subgraph Admin
      AD[/api/frontend/admin/*/] --> RA[require_admin = Clerk ∩ admins table]
    end
    subgraph Public
      H[/healthz, /readyz, /pairing-info/] --> NA[no auth]
      WH[/api/clerk/webhook/] --> SV[Svix signature]
    end
```
