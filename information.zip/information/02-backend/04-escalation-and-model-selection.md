# Backend — Escalation Router, Model Catalog & Solver (Algorithm)

This is the definitive reference for how the Smart Tutor Lamp backend decides **which LLM to use, when to start strong, and when to climb to a stronger model**. It covers three cooperating layers: a **deterministic pre-router** (`escalation_router.py`) that picks a *starting* tier before any LLM call from cheap signals (image quality + question keywords); a **model catalog** (`model_catalog.py`) that is the single source of truth for every selectable model, its provider, prices, and capabilities; and a **provider-agnostic solver** (`model_solver.py`) plus the **model-eval persistence/schema** machinery that runs and records the comparison bench. It also documents the *post-answer* escalation gates (`_should_escalate` / `_sim_pick_next_tier`) and the legacy `validator.py`, quoting every threshold, constant, and decision branch from the code.

> All line citations point into the backend repo `Smart-Tutor-Lamp-backend/`. Links are relative to that repo root.
>
> **Updated 2026-07-03** (`escalation_router.py` +201). New pre-router outputs since the last sync (all in `preroute`, [escalation_router.py:564-648](app/services/escalation_router.py#L564)): **MCQ** → `require_option_verification` + tier-2 ([:616-619](app/services/escalation_router.py#L616)); **objective types** (MSQ / true-false / fill-in-the-blank) → tier-2 ([:623-626](app/services/escalation_router.py#L623)); **objective-verdict** → `require_objective_verdict` ([:630-633](app/services/escalation_router.py#L630)), which emits `_OBJECTIVE_VERDICT_SUFFIX` **alone** (a *direct verdict*, never a Socratic nudge for objective questions — commit `dc9a936`); **mistake-localization** → `require_mistake_localization` + `_MISTAKE_LOCALIZE_SUFFIX` (verify-before-accuse, anti-flip-flop). The **frustration-nudge threshold was lowered to 2** (commit `8db448f`): it is `settings.SOLVE_NUDGE_THRESHOLD` (config default 2), read in `problem_memo.solve_authorized` ([problem_memo.py:712](app/services/problem_memo.py#L712)); `SOLVE_MIN_NUDGES` (=1) gates the hard-surrender path. The **check-verdict guard** (`is_check_request` → `check_verdict_note`) is documented in [03-orchestrator-and-turn-pipeline.md](03-orchestrator-and-turn-pipeline.md) §9.5.

---

## Table of contents

1. [Purpose & responsibility](#1-purpose--responsibility)
2. [Architecture overview](#2-architecture-overview)
3. [The two escalation gates (pre vs post)](#3-the-two-escalation-gates-pre-vs-post)
4. [`escalation_router.py` — deterministic pre-router](#4-escalation_routerpy--deterministic-pre-router)
   - [4.1 Image-quality gate](#41-image-quality-gate-algorithm)
   - [4.2 Text classifier (keyword/pattern rules)](#42-text-classifier-keywordpattern-rules)
   - [4.3 Focus target extraction](#43-focus-target-extraction-multi-question-worksheets)
   - [4.4 Follow-up detection](#44-follow-up-detection)
   - [4.5 `PrerouteDecision` + the decision tree](#45-preroutedecision--the-decision-tree)
5. [`model_catalog.py` — model tiers, costs, capabilities](#5-model_catalogpy--model-tiers-costs-capabilities)
   - [5.1 `ModelSpec` data structure](#51-modelspec-data-structure)
   - [5.2 The full catalog (every model)](#52-the-full-catalog-every-model)
   - [5.3 Pricing overrides & indexes](#53-pricing-overrides--indexes)
   - [5.4 Helpers: availability, cost, lookup](#54-helpers-availability-cost-lookup)
6. [`model_solver.py` — provider abstraction & dispatch](#6-model_solverpy--provider-abstraction--dispatch)
7. [Post-answer escalation gates (orchestrator + web)](#7-post-answer-escalation-gates-orchestrator--web)
8. [`validator.py` — legacy BAO output validator](#8-validatorpy--legacy-bao-output-validator)
9. [Model-eval schemas & persistence](#9-model-eval-schemas--persistence)
10. [Configuration, environment variables & constants](#10-configuration-environment-variables--constants)
11. [Edge cases, errors, timeouts, fallbacks](#11-edge-cases-errors-timeouts-fallbacks)
12. [Integration points (who calls what)](#12-integration-points-who-calls-what)
13. [Mermaid diagrams](#13-mermaid-diagrams)

---

## 1. Purpose & responsibility

The escalation/model-selection subsystem answers four questions per question asked:

1. **Can we even read the image?** A blurry/dark/tiny photo cannot be OCR'd, so the pre-router *short-circuits to a retake request with zero LLM spend* rather than letting a model hallucinate over mush ([escalation_router.py:9-12](app/services/escalation_router.py#L9)).
2. **How hard does this look BEFORE we spend?** Deterministic keyword/pattern rules read the question text and pick a *starting tier* (1/2/3) and answer-shaping flags ([escalation_router.py:13-16](app/services/escalation_router.py#L13)).
3. **Which concrete model backs each tier / each bench pick, and what does it cost?** The catalog maps a public id → provider, vendor model string, per-token prices, and modality flags ([model_catalog.py:1-9](app/services/model_catalog.py#L1)).
4. **Did the cheap model actually succeed?** *After* tier-1 answers, a second gate (`_should_escalate` on the lamp, `_sim_pick_next_tier` on the web) reads the model's self-reported `confidence`/`difficulty`/`query_type` and climbs toward a stronger model when warranted.

The design philosophy is **speculative escalation**: try cheap first, climb only on signal. From the plan, this pays "~1.5× cost on hard, 1× on easy" versus "10× across the board" for always-using-Pro ([ESCALATION_PLAN.md:422](ESCALATION_PLAN.md#L422)).

The assigned files split by role:

| File | Role |
|---|---|
| `app/services/escalation_router.py` | **PRE**-router: deterministic image-quality gate + text tiering + focus/follow-up signals. PURE, no I/O, no LLM. |
| `app/services/model_catalog.py` | Single source of truth for selectable models, prices, capabilities. |
| `app/services/model_solver.py` | Provider-agnostic `generate_solution(...)` — one uniform `SolveResult` from any of Gemini/OpenAI/Claude/DeepSeek. |
| `app/services/validator.py` | Legacy "BAO" output validator with its own confidence-escalate gate and voice/LaTeX cleanup. |
| `app/schemas/model_eval.py` | Pydantic response shapes for `/api/frontend/models`, `/solve`, `/solve/compare` (incl. the AUTO per-step breakdown). |
| `app/storage/model_eval.py` | Persistence for `model_requests`/`model_responses`/`model_feedback`, and `model_providers` registry seeding. |
| `ESCALATION_PLAN.md` | Postmortem (thinking-tokens truncation bug) + the forward multi-tier plan. |

---

## 2. Architecture overview

```
                         QUESTION (text / voice / image)
                                     │
            ┌────────────────────────┴────────────────────────┐
            │           PRE-ROUTER (escalation_router.preroute) │  PURE, no LLM
            │  • assess_image_quality()  → retake? (0 spend)    │
            │  • classify_text()         → start_tier, flags    │
            │  • extract_focus_label()   → "Q5(B)"              │
            └────────────────────────┬────────────────────────┘
                                     │ start_tier, prompt_suffix
                                     ▼
            ┌─────────────────────────────────────────────────┐
            │  TIER DISPATCH                                    │
            │   lamp:  orchestrator._call_tier(start_tier)     │
            │   web :  frontend_manager._solve_auto/_auto_call │
            │  Tier→model:  GEMINI_TIER{1,2,3}_* config        │
            └────────────────────────┬────────────────────────┘
                                     │ reply (SimResponse/LlmReply)
                                     ▼
            ┌─────────────────────────────────────────────────┐
            │  POST-ANSWER GATE                                 │
            │   lamp: _should_escalate(reply, telemetry)       │
            │   web : _sim_pick_next_tier(sim, current_tier)   │
            │   → climb toward ceiling (skip-tier on HARD)     │
            └────────────────────────┬────────────────────────┘
                                     │
                                     ▼  final reply + per-step telemetry
            ┌─────────────────────────────────────────────────┐
            │  MODEL CATALOG  (estimate_cost, is_available)    │  ← prices every step
            │  MODEL-EVAL STORAGE (record_request/response)    │  ← persists the bench
            └─────────────────────────────────────────────────┘
```

The catalog is read by: the dropdown endpoint, `model_solver.generate_solution` (to resolve a `ModelSpec` and price the result), and `storage/model_eval.seed_providers` (to mirror the catalog into the DB). The `"auto"` catalog id is a *routing alias* that runs the whole tiered flow above via `_solve_auto`, not a single model.

---

## 3. The two escalation gates (pre vs post)

The module docstring states the relationship explicitly: the existing routers escalate **after** tier-1 answers keyed on the model's *self-reported* confidence/difficulty, "which is unreliable." The pre-router runs **before** tier-1 and decides a starting tier from *deterministic* signals; "the model-self-reported post-answer escalation stays as the SECOND gate, climbing from `start_tier`" ([escalation_router.py:2-22](app/services/escalation_router.py#L2)).

| | **Gate 1 — Pre-router** | **Gate 2 — Post-answer** |
|---|---|---|
| Where | `escalation_router.preroute()` | `orchestrator._should_escalate()` / `frontend_manager._sim_pick_next_tier()` |
| Runs | BEFORE any LLM call | AFTER tier-1 (and each subsequent tier) |
| Inputs | image bytes, question text, image count | the model's `confidence`/`difficulty`/`query_type` + per-call `status` |
| Output | `start_tier` (1/2/3), retake flag, answer-shaping flags, focus label | next target tier (2/3) or None to ship |
| Cost | Zero (pure CPU) | Each climb is another full LLM call |
| Determinism | Fully deterministic | Depends on the model's self-rating |

---

## 4. `escalation_router.py` — deterministic pre-router

The whole module is **pure and deterministic — no I/O, no LLM — so it is cheap and unit-testable** ([escalation_router.py:18](app/services/escalation_router.py#L18)). Both surfaces (lamp orchestrator, web `_solve_auto`) call `preroute(...)`.

### 4.1 Image-quality gate (algorithm)

**Data structure — `ImageQualityVerdict`** ([escalation_router.py:40-48](app/services/escalation_router.py#L40)):

| Field | Type | Meaning |
|---|---|---|
| `ok` | `bool` (default `True`) | Did the best frame pass all gates? |
| `reason` | `str` | Machine tag: `"blurry"` \| `"too_dark"` \| `"too_small"` |
| `detail` | `str` | Human-readable message surfaced to the user on retake |
| `blur_var` | `float \| None` | Variance-of-Laplacian focus metric for the reported frame |
| `min_dim` | `int \| None` | Shorter side in pixels |
| `luma` | `float \| None` | Mean grayscale brightness |

**`_decode_gray(jpeg)`** ([escalation_router.py:50-60](app/services/escalation_router.py#L50)) — lazily imports `numpy` + `PIL`, opens the JPEG, converts to grayscale `"L"`, returns a `float32` `(H,W)` array, or `None` on any failure. Lazy import keeps the module import-cheap for callers that only want the text rules.

**`_laplacian_variance(gray)`** ([escalation_router.py:63-77](app/services/escalation_router.py#L63)) — the standard focus/blur metric. It computes the discrete Laplacian with plain numpy shifts (no scipy):

```python
lap = (-4.0*g
       + np.roll(g, 1, axis=0) + np.roll(g, -1, axis=0)
       + np.roll(g, 1, axis=1) + np.roll(g, -1, axis=1))
```

It trims the 1-px border (because `np.roll` wraps around → bogus edge values there) and returns `float(lap.var())`. **Low variance = few sharp edges = blurry.**

**`assess_image_quality(jpegs)`** ([escalation_router.py:80-135](app/services/escalation_router.py#L80)) — judges the **best of the supplied frames** (the user may capture several; one good one is enough). For each decodable frame it computes `min_dim = min(h,w)`, `luma = gray.mean()`, `blur = _laplacian_variance(gray)`, then applies the gates **in this order**:

1. **`too_small`** — fires only when the frame is *both* small *and* not crisp:
   ```python
   if (min_dim < settings.PREROUTE_MIN_DIM_PX        # default 240 px
           and blur < settings.PREROUTE_BLUR_MIN * 4):  # 4× the blur floor = 30*4 = 120
   ```
   The 4× rule is deliberate: smallness alone is *not* unreadable. A 304×166 crop with `blur_var 6836` was being false-retaken in prod (2026-06-12) on this gate; smallness only matters when it *causes* illegibility, which the sharpness metric already measures — so a small frame is rejected only when it is *also* not clearly sharp ([escalation_router.py:102-113](app/services/escalation_router.py#L102)).
2. **`too_dark`** — `elif luma < settings.PREROUTE_LUMA_MIN` (default 22.0). Near-black frames are genuinely unreadable.
3. *(No too-bright gate, on purpose.)* The lamp shines on white notebook paper, so a perfectly readable page is often near-white; rejecting "too bright" would drop legitimate content ([escalation_router.py:118-121](app/services/escalation_router.py#L118)).
4. **`blurry`** — `elif blur < settings.PREROUTE_BLUR_MIN` (default 30.0).
5. **Pass** — `else: return ImageQualityVerdict(True, ...)` immediately (a good frame exists; short-circuit the loop).

For failing frames it tracks the **"least bad"** one (the highest `blur_var`) to report ([escalation_router.py:129-131](app/services/escalation_router.py#L129)).

Defensive endings:
- If no frame decodes at all (`any_decoded` stays False): `return ImageQualityVerdict(True)` — **don't block a turn on a decode quirk** ([escalation_router.py:133-134](app/services/escalation_router.py#L133)).
- Otherwise return the best failing verdict (or `ok=True`).

### 4.2 Text classifier (keyword/pattern rules)

All regexes are case-insensitive with word boundaries (so "proven" doesn't trip "prove"). The six pattern groups ([escalation_router.py:141-189](app/services/escalation_router.py#L141)):

| Constant | Matches (verbatim from code) | Signal | Effect |
|---|---|---|---|
| `_HARD_PATTERNS` | `prove\|proof\|derive\|derivation\|from first principles\|multi[\s-]?step\|integer[\s-]?type\|integer answer\|rigoro\|generalize\|show that` | `hard` | start ≥ tier-2 |
| `_EXTREME_PATTERNS` | `jee[\s-]?advanced\|olympiad\|imo\|inpho\|incho\|putnam\|jee advanced level` | `extreme` | start ≥ tier-3 (if enabled) |
| `_DIAGRAM_PATTERNS` | `circuit\|free[\s-]?body\|fbd\|ray diagram\|graph\|plot\|diagram\|figure\|geometry\|triangle\|vector field` | `diagram` | start ≥ tier-2 |
| `_MISTAKE_PATTERNS` | the "where did I go wrong / check my work / is this correct / what did I mess up" family | `mistake` | tier-2 + mistake localization |
| `_MCQ_PHRASE` + `_MCQ_OPTION_STEM` | "which of the following / choose the correct / correct option / options: / mark the correct"; OR ≥ 2 `(a) / A.` option stems | `mcq` | tier-2 + option verification |
| `_MSQ_PATTERNS` / `_TRUE_FALSE_PATTERNS` / `_FILL_BLANK_PATTERNS` | "select all that apply / one or more / multiple correct"; "true or false / T-F / is the statement true"; "fill in the blank(s) / complete the sentence / `___`" | `objective` (with `mcq`) | tier-2 (verify before the verdict) |
| `_OBJECTIVE_ANSWER_CLAIM` | the student NAMES their objective answer + asks if it's right — "is (B) correct", "I marked B", "is option C right", "my answer is B", "is it true/false" | `objective_verify` | tier-2 + **direct verdict** (no Socratic nudge) |
| `_FORMULA_DEF_PATTERNS` | `what is the formula\|which formula\|state the formula\|define\|definition of\|what is the (value\|si unit) of\|what does .* stand for\|formula for` | `formula_def` | stay tier-1 |

**`TextSignals`** — a dataclass of **eight** booleans: `hard, extreme, diagram, mistake, mcq, formula_def, objective, objective_verify`. The last two (added for the **objective-verdict policy**) cover the four objective question types — MCQ / multiple-select / true-false / fill-in-the-blank — which have a single verifiable answer and **no multi-step process to protect**, so a "is my answer right?" on them earns a direct verdict instead of a nudge.

**`classify_text(text)`** — strips the text; empty/None → all-False `TextSignals()` (no signal → caller keeps tier-1). `objective = mcq or msq or tf or fill`; `objective_verify = answer_claim or (objective and mistake)` — i.e. a NAMED objective answer ("is (B) right") implies it on its own, OR an explicit objective question type plus a generic check ("is this right?"). The remaining booleans are direct `.search()` hits. The prompt rule is the **primary** path (the question TYPE is usually only visible in the image, which the pre-router can't see); `objective_verify` is the deterministic booster for text-visible cases.

### 4.3 Focus target extraction (multi-question worksheets)

For worksheets with several questions, the router extracts *which* question the student named so the answer can be scoped to it.

- **`_FOCUS_Q_RE`** ([escalation_router.py:225-229](app/services/escalation_router.py#L225)) matches `question 5`, `Q5`, `q. 5`, `number 5`, `problem 5`, optionally a part `5(b)` / `question 5 part b`.
- **`extract_focus_label(text)`** ([escalation_router.py:233-246](app/services/escalation_router.py#L233)) → `"Q5(B)"` for "question 5 part b", `"Q12"` for "q. 12", `""` when no mention. It uppercases the part.
- **`label_number(label)`** ([escalation_router.py:249-253](app/services/escalation_router.py#L249)) — extracts the bare number (`"Q5(B)" → "5"`). Parts share the number, so `Q5` and `Q5(B)` compare equal at this level.
- **`focus_mismatch(target_label, ocr_text)`** ([escalation_router.py:256-266](app/services/escalation_router.py#L256)) — deterministic focus check. Both the target and the model's `ocr_text` self-report must carry a number to fire; an `ocr_text` mentioning the target *anywhere* passes (cross-references like "Q5 using Q4" are legitimate). Returns `bool(seen) and want not in seen`.
- **`focus_suffix(label)`** ([escalation_router.py:269-281](app/services/escalation_router.py#L269)) — the per-turn FOCUS directive injected when a question is named ("Answer ONLY {label}. Other questions … are context noise…").
- **`FOCUS_GUARD_NOTE`** ([escalation_router.py:328-334](app/services/escalation_router.py#L328)) — corrective re-call note used when the model's reported focus disagrees with what was asked. Used by `_solve_auto`'s focus-guard step ([frontend_manager.py:1219-1230](app/routes/frontend_manager.py#L1219)).

### 4.4 Follow-up detection

These rules counter the anti-stale prompt hardening that made the model treat too many turns as FRESH (web follow-ups like "ok what next" were answered as new questions, observed 2026-06-13) ([escalation_router.py:284-289](app/services/escalation_router.py#L284)).

- **`_NEW_PROBLEM_VERBS`** ([escalation_router.py:290-292](app/services/escalation_router.py#L290)) — `solve\|integrate\|differentiate\|evaluate\|find\|compute\|calculate\|prove\|derive\|simplify\|factor\|determine`.
- **`_FOLLOWUP_OPENER`** ([escalation_router.py:293-297](app/services/escalation_router.py#L293)) — anchored to start-of-string: yes/no/ok/yeah/hmm/right/got it/thanks/then what/what next/continue/why/so/is it/etc.
- **`is_followup_text(text)`** ([escalation_router.py:300-312](app/services/escalation_router.py#L300)): returns False if empty, False if it names a focus question, False if it contains a new-problem verb; otherwise True when it opens with a follow-up word **OR** is `len(t.split()) <= 6` words. Callers gate the resulting `CONTINUATION_HINT` on history being non-empty so a fresh session never gets it.
- **`CONTINUATION_HINT`** ([escalation_router.py:317-323](app/services/escalation_router.py#L317)) — the deterministic system-prompt note appended when `is_followup_text` fires mid-conversation.

### 4.5 `PrerouteDecision` + the decision tree

**Answer-shaping suffixes:**
- **`_OPTION_VERIFY_SUFFIX`** — "Solve it INDEPENDENTLY first, then CHECK your result against each given option…".
- **`_MISTAKE_LOCALIZE_SUFFIX`** — VERDICT-NEUTRAL: "VERIFY BEFORE YOU ACCUSE… a correct answer reached by a shortcut is CORRECT, and a missing intermediate line is NOT a mistake…". This neutrality is the false-alarm fix that makes the broad `_MISTAKE_PATTERNS` matching harmless.
- **`_OBJECTIVE_VERDICT_SUFFIX`** — the **objective-verdict policy** directive. When the question is an objective type (MCQ / MSQ / true-false / fill-in-the-blank) and the student asks whether *their* answer/option is right, it instructs a **DIRECT verdict** ("verify it yourself first; CORRECT → say so plainly; WRONG → state the correct answer + a one-line why; MULTIPLE-SELECT → which selections are right/wrong/missed"), explicitly noting that a chosen option is a *committed answer to verify, not a fishing guess* — so the no-reveal default does not apply. In `prompt_suffix` this note **supersedes** the generic option-verify / mistake-localize notes (it is emitted ALONE) so the model never gets two overlapping check directives.

**Data structure — `PrerouteDecision`**:

| Field | Default | Meaning |
|---|---|---|
| `start_tier` | `1` | The tier the dispatch enters at |
| `retake_image` | `False` | Short-circuit: ask the user to retake (no LLM call) |
| `retake_reason` | `""` | Machine tag (`blurry`/`too_dark`/`too_small`) |
| `retake_detail` | `""` | Human message |
| `require_option_verification` | `False` | MCQ — verify each option |
| `require_mistake_localization` | `False` | "check my work" turn |
| `require_objective_verdict` | `False` | objective Q + "is my answer right?" → direct verdict |
| `focus_label` | `""` | `"Q5"` / `"Q5(B)"` named target |
| `reasons` | `[]` | Audit trail of which rules fired |
| `prompt_suffix` *(property)* | — | The objective-verdict note ALONE when set; otherwise the option-verify + mistake-localize notes; always plus the focus suffix |

**`_max_routable_tier()`** ([escalation_router.py:385-388](app/services/escalation_router.py#L385)) — `return 3 if settings.GEMINI_TIER3_ENABLED else 2`. This mirrors `frontend_manager._sim_resolve_tier` so the pre- and post-routers agree on the ceiling.

**`preroute(text, image_quality, image_count)`** ([escalation_router.py:391-461](app/services/escalation_router.py#L391)) — the entry point. Step by step:

1. **Image-quality short-circuit** ([escalation_router.py:408-421](app/services/escalation_router.py#L408)) — only when *all* of:
   - `settings.PREROUTE_IMAGE_QUALITY_GATE` is on, and
   - `image_quality is not None`, and
   - `not image_quality.ok`, and
   - `image_count > 0`.
   Then it checks `text_is_thin = len((text or "").split()) < 6`. **If the text is thin (< 6 words)** it sets `retake_image=True`, records `image_<reason>`, and **returns immediately — no LLM call this turn.** If the text is *not* thin (a strong standalone text question), the poor image is tolerated and it just records `image_<reason>_but_text_present` and continues.

2. **Classify text** — `sig = classify_text(text)`; `ceiling = _max_routable_tier()`.

3. **Focus target** ([escalation_router.py:426-429](app/services/escalation_router.py#L426)) — `d.focus_label = extract_focus_label(text)`; records `focus_<label>` if found.

4. **Hardness → start tier** ([escalation_router.py:431-440](app/services/escalation_router.py#L431)):
   - `if sig.extreme: d.start_tier = max(d.start_tier, min(3, ceiling))` → `extreme_marker`
   - `if sig.hard:    d.start_tier = max(d.start_tier, 2)` → `hard_marker`
   - `if sig.diagram: d.start_tier = max(d.start_tier, 2)` → `diagram_marker`

5. **MCQ** — `start_tier = max(start_tier, 2)`, `require_option_verification = True`, reason `mcq`.

5b. **Other objective types** (`sig.objective` — MSQ / true-false / fill-blank) — `start_tier = max(start_tier, 2)`, reason `objective` (so the verdict is verified before it is given).

5c. **Objective verdict** (`sig.objective_verify` — objective Q + "is MY answer/option right?") — `start_tier = max(start_tier, 2)`, `require_objective_verdict = True`, reason `objective_verdict`. `prompt_suffix` then emits the `_OBJECTIVE_VERDICT_SUFFIX` ALONE (it supersedes the option-verify / mistake-localize notes).

6. **Mistake localization** — `start_tier = max(start_tier, 2)`, `require_mistake_localization = True`, reason `mistake_localization`.

7. **Pure formula/definition** — only records `formula_definition` *when* `start_tier == 1` (i.e. no escalating signal also fired). It never lowers a tier already raised.

8. **Clamp + default** ([escalation_router.py:458-461](app/services/escalation_router.py#L458)) — `d.start_tier = min(d.start_tier, ceiling)`; if no reasons fired, append `default_tier1`.

**Worked examples** (all from the rules above):

| Input text | image | Result |
|---|---|---|
| "what is the formula for kinetic energy" | good | `start_tier=1`, reasons `[formula_definition]` |
| "prove that √2 is irrational" | none | `start_tier=2`, reasons `[hard_marker]` |
| "solve this JEE Advanced mechanics problem" | good | `start_tier=3` (if `GEMINI_TIER3_ENABLED`), reasons `[extreme_marker]` |
| "which of the following is correct? (a)… (b)…" | good | `start_tier=2`, `require_option_verification`, reasons `[mcq]` |
| "I marked (B). Is my option correct?" | good | `start_tier=2`, `require_objective_verdict`, reasons `[objective_verdict]` — **direct verdict**, suffix supersedes option-verify |
| "is it true or false? I think true" | good | `start_tier=2`, `require_objective_verdict`, reasons `[objective, objective_verdict]` |
| "where did I go wrong here?" | good | `start_tier=2`, `require_mistake_localization`, reasons `[mistake_localization]` |
| "" (no/thin text) | blurry | `retake_image=True`, reason `image_blurry` — **0 LLM spend** |
| "Derive the lens equation, question 4(b)" | blurry | `start_tier=2`? No — text < 6 words? "derive the lens equation question 4(b)" is ≥ 6 words, so image tolerated; `hard_marker`, `focus_Q4(B)` |

---

## 5. `model_catalog.py` — model tiers, costs, capabilities

> "the single source of truth for which LLMs the web bench can compare, and what they cost." Adding a future model is a **one-line edit** — append a `ModelSpec` ([model_catalog.py:1-9](app/services/model_catalog.py#L1)).

### 5.1 `ModelSpec` data structure

`@dataclass(frozen=True)` ([model_catalog.py:34-45](app/services/model_catalog.py#L34)):

| Field | Type | Meaning |
|---|---|---|
| `id` | `str` | Public id the frontend sends back (stable key) |
| `label` | `str` | Human label for the dropdown / dashboard |
| `provider` | `str` | `"gemini"` \| `"openai"` \| `"claude"` \| `"deepseek"` |
| `vendor_model` | `str` | The exact model id passed to the provider SDK |
| `input_per_mtok` | `float` | USD per **1,000,000** input (prompt) tokens |
| `output_per_mtok` | `float` | USD per **1,000,000** output (completion) tokens |
| `vision` | `bool` (default False) | Accepts image input natively |
| `audio` | `bool` (default False) | Accepts raw audio natively (else STT upstream) |
| `note` | `str` (default "") | Short UI caveat |

Pricing is **USD per 1M tokens (input/output), matching how every vendor publishes rates**; the numbers are public list prices, "estimates used to show a comparable 'estimated cost' per request, not billing-grade accounting" ([model_catalog.py:11-16](app/services/model_catalog.py#L11)).

### 5.2 The full catalog (every model)

Built by `_build_catalog()` ([model_catalog.py:53-161](app/services/model_catalog.py#L53)). Vendor model strings for OpenAI/Claude/DeepSeek read from settings/env so an operator can pin a snapshot without editing code; Gemini pins the two public tiers directly because the bench wants both Flash AND Pro.

| `id` | label | provider | `vendor_model` | in $/Mtok | out $/Mtok | vision | audio | note |
|---|---|---|---|---:|---:|:-:|:-:|---|
| `auto` | Auto (tiered escalation) | gemini | `auto` | 0.30 | 2.50 | ✓ | ✓ | Routing alias; runs the lamp's escalation plan, step breakdown shown. Tier-1 pricing only — steps carry real per-call cost. |
| `gemini-2.5-flash` | Gemini 2.5 Flash | gemini | `gemini-2.5-flash` | 0.30 | 2.50 | ✓ | ✓ | **DEFAULT** |
| `gemini-2.5-flash-lite` | Gemini 2.5 Flash Lite | gemini | `gemini-2.5-flash-lite` | 0.10 | 0.40 | ✓ | ✓ | |
| `gemini-2.0-flash` | Gemini 2.0 Flash | gemini | `gemini-2.0-flash` | 0.10 | 0.40 | ✓ | ✓ | |
| `gemini-2.0-flash-lite` | Gemini 2.0 Flash Lite | gemini | `gemini-2.0-flash-lite` | 0.075 | 0.30 | ✓ | ✓ | |
| `gemini-2.5-pro` | Gemini 2.5 Pro | gemini | `gemini-2.5-pro` | 1.25 | 10.00 | ✓ | ✓ | |
| `gemini-3.5-flash` | Gemini 3.5 Flash | gemini | `gemini-3.5-flash` | 0.40 | 3.00 | ✓ | ✓ | Newest flash — bench vs 2.5 Flash before lamp adoption. |
| `gemini-3-flash` | Gemini 3 Flash | gemini | `gemini-3-flash-preview` | 0.40 | 3.00 | ✓ | ✓ | Preview. |
| `gemini-3.1-flash-lite` | Gemini 3.1 Flash Lite | gemini | `gemini-3.1-flash-lite` | 0.10 | 0.40 | ✓ | ✓ | Preview. |
| `gemini-3.1-pro` | Gemini 3.1 Pro | gemini | `gemini-3.1-pro-preview` | 2.00 | 12.00 | ✓ | ✓ | Preview — the lamp's tier-3 ceiling for JEE-Advanced depth. |
| `gemini-3-pro` | Gemini 3 Pro | gemini | `gemini-3-pro-preview` | 2.00 | 12.00 | ✓ | ✓ | Preview. |
| `gpt-5` | GPT-5 | openai | `os.getenv("OPENAI_MODEL_GPT5","gpt-5")` | 1.25 | 10.00 | ✓ | ✗ | Voice questions transcribed via Whisper. |
| `gpt-5-mini` | GPT-5 Mini | openai | `os.getenv("OPENAI_MODEL_GPT5_MINI","gpt-5-mini")` | 0.25 | 2.00 | ✓ | ✗ | Voice transcribed via Whisper. |
| `deepseek` | DeepSeek | deepseek | `settings.DEEPSEEK_MODEL` (`deepseek-chat`) | 0.27 | 1.10 | ✗ | ✗ | Text-only — can't see images; voice via Whisper. |
| `claude` | Claude | claude | `settings.ANTHROPIC_MODEL` (`claude-sonnet-4-6`) | 3.00 | 15.00 | ✓ | ✗ | Voice transcribed via Whisper. |

The default the dropdown lands on: **`DEFAULT_MODEL_ID = "gemini-2.5-flash"`** ([model_catalog.py:166](app/services/model_catalog.py#L166)) — "the one key that's already wired in dev." Audio for non-audio providers (OpenAI/Claude/DeepSeek) is transcribed upstream with Groq Whisper, so those models *also* need `GROQ_API_KEY` to answer a voice question, but are usable for text/image without it ([model_catalog.py:17-20](app/services/model_catalog.py#L17)).

### 5.3 Pricing overrides & indexes

**`_apply_pricing_overrides(catalog)`** ([model_catalog.py:169-195](app/services/model_catalog.py#L169)) — reads the `MODEL_PRICING_JSON` env var so prices can be corrected in prod without a code deploy:

```
MODEL_PRICING_JSON='{"gpt-5": {"input_per_mtok": 1.1, "output_per_mtok": 9.0}}'
```

Empty → returns the catalog unchanged. Malformed JSON → a WARN and the original catalog (**never breaks boot**). For each id present, it `dataclasses.replace`s only `input_per_mtok`/`output_per_mtok`, defaulting to the spec's existing values; unknown ids and non-dict prices are skipped. Original ordering is preserved.

**Module-level indexes** (built once at import) ([model_catalog.py:198-206](app/services/model_catalog.py#L198)):
- `_CATALOG` — overrides applied to `_build_catalog()`.
- `_BY_ID` — `id → ModelSpec`.
- `_BY_VENDOR` — `vendor_model.lower() → ModelSpec`, **excluding `"auto"`** (it is a routing alias, not a billable vendor model). This lets a persisted turn carrying `telemetry["model"]` like `"gemini-3.1-pro-preview"` be priced without knowing its public catalog id.

### 5.4 Helpers: availability, cost, lookup

| Function | Behavior |
|---|---|
| `list_models()` ([:210](app/services/model_catalog.py#L210)) | Every model in dropdown order. |
| `get_model(model_id)` ([:215](app/services/model_catalog.py#L215)) | Resolve a public id; `None → DEFAULT_MODEL_ID`; lowercases+strips. |
| `get_by_vendor_model(vendor_model)` ([:222](app/services/model_catalog.py#L222)) | Resolve from a *vendor* string. Exact match first, then a **tolerant prefix match** (`v.startswith(vm) or vm.startswith(v)`) so a `-preview`/`-latest`/date suffix still resolves. None when nothing matches. |
| `_provider_key(provider)` ([:239](app/services/model_catalog.py#L239)) | Maps provider → the configured API key from settings (`GEMINI_API_KEY`/`OPENAI_API_KEY`/`ANTHROPIC_API_KEY`/`DEEPSEEK_API_KEY`). |
| `is_available(spec)` ([:248](app/services/model_catalog.py#L248)) | `bool(_provider_key(spec.provider))` — a model can answer only when its provider key is set. |
| `needs_groq_for_audio(spec)` ([:253](app/services/model_catalog.py#L253)) | `not spec.audio` — true for providers that must transcribe voice upstream. |
| `estimate_cost(spec, in_tok, out_tok)` ([:258](app/services/model_catalog.py#L258)) | See below. |

**Cost algorithm** ([model_catalog.py:258-272](app/services/model_catalog.py#L258)):

```python
if input_tokens is None and output_tokens is None:
    return None                       # UI shows "—", never a misleading $0.00
cost = 0.0
if input_tokens:  cost += (input_tokens  / 1_000_000.0) * spec.input_per_mtok
if output_tokens: cost += (output_tokens / 1_000_000.0) * spec.output_per_mtok
return round(cost, 6)
```

So a Gemini 2.5 Pro request with 1500 input + 800 output tokens costs `1500/1e6*1.25 + 800/1e6*10.00 = 0.001875 + 0.008 = $0.009875` → rounded to `0.009875`.

---

## 6. `model_solver.py` — provider abstraction & dispatch

`generate_solution(...)` is "the single entry point the rest of the app calls to get an answer from ANY model, without knowing which provider is behind it" ([model_solver.py:1-19](app/services/model_solver.py#L1)). All four providers answer in the **same** `SimResponse` shape and get the **same** system prompt so the comparison is apples-to-apples.

**`SolveResult` data structure** ([model_solver.py:64-78](app/services/model_solver.py#L64)): `model_id`, `label`, `provider`, `response: SimResponse`, `status` (`"ok"|"not_configured"|"timeout"|"error"` — and `"busy"` is also produced), `latency_ms`, `input_tokens`, `output_tokens`, `total_tokens`, `estimated_cost`, `error`, and `extra: dict` (transcript, image_seen flag, AUTO steps…).

**Timeout** ([model_solver.py:50-61](app/services/model_solver.py#L50)): a single model call is capped at `settings.SOLVE_TIMEOUT_S` (the config default is `30.0` per [config.py:178](app/config.py#L178); the docstring notes 85s on Render). `_solve_timeout_s()` falls back to `_FALLBACK_TIMEOUT_S = 30.0` if config is unavailable.

**`generate_solution` control flow** ([model_solver.py:108-177](app/services/model_solver.py#L108)):

1. `images = images or []`; `spec = model_catalog.get_model(model_id)`; `t0 = time.monotonic()`.
2. **Unknown id** → synthesize a *ghost* `ModelSpec` and return `status="error"` ("That model isn't in the catalog.") so the caller still gets a labelled result instead of an exception ([model_solver.py:128-138](app/services/model_solver.py#L128)).
3. **Not configured** → if `not model_catalog.is_available(spec)`, return `status="not_configured"` ("…add its API key to enable it.") ([model_solver.py:140-145](app/services/model_solver.py#L140)).
4. **Dispatch under a timeout** ([model_solver.py:147-159](app/services/model_solver.py#L147)) — `await asyncio.wait_for(_dispatch(...), timeout=timeout_s)`. On `asyncio.TimeoutError` → `status="timeout"` ("… took longer than Ns — try again.").
5. **`CancelledError`** is re-raised (cooperative cancellation).
6. **Backstop `except Exception`** ([model_solver.py:162-177](app/services/model_solver.py#L162)): if `is_busy_error(e)` (matches any of `_BUSY_MARKERS = ("503","UNAVAILABLE","high demand","429","RESOURCE_EXHAUSTED","overloaded","try again later")`), return `status="busy"` with a friendly "servers are busy" message and one WARN line. Otherwise `log.exception` and return `status="error"`.

**Never raises** to the caller — every failure path returns a `SolveResult` with a graceful fallback `SimResponse` ([model_solver.py:27-29](app/services/model_solver.py#L27)).

**`_dispatch(spec, …)`** ([model_solver.py:180-197](app/services/model_solver.py#L180)) — branches on `spec.provider` to `_solve_gemini` / `_solve_openai` / `_solve_claude` / `_solve_deepseek`; unknown provider → `status="error"`.

**`_finalize(...)`** ([model_solver.py:200-216](app/services/model_solver.py#L200)) — assembles the `SolveResult`: reads `input/output/total` tokens from the provider usage dict (synthesizes total = in+out if missing), computes `latency_ms`, and calls `model_catalog.estimate_cost(spec, in_tok, out_tok)`.

**Per-provider solvers:**

- **`_solve_gemini`** ([model_solver.py:220-235](app/services/model_solver.py#L220)) — if `spec.vendor_model == "auto"`, it returns an error ("Auto (tiered escalation) runs only in single-solve mode.") — the AUTO pseudo-model must never reach a raw Gemini call (would 404); this is a safety net since the `/solve` route's `_solve_auto` handles it. Otherwise calls `gemini_brain.simulate_with_usage(...)` with native audio+image.
- **`_solve_openai`** ([model_solver.py:239-272](app/services/model_solver.py#L239)) — native vision; audio transcribed via `_maybe_transcribe`. Sends `response_format={"type":"json_object"}`. Usage from `_openai_usage`.
- **`_solve_claude`** ([model_solver.py:276-313](app/services/model_solver.py#L276)) — native vision; audio via Whisper; `max_tokens=1500`; appends "reply with ONLY the raw JSON object, no prose, no code fences." Usage read from `resp.usage.input_tokens/output_tokens`.
- **`_solve_deepseek`** ([model_solver.py:317-349](app/services/model_solver.py#L317)) — text-only (OpenAI-compatible API via `DEEPSEEK_BASE_URL`). If images were attached, prepends a note that this model can't see images; sets `extra["image_seen"] = False`.

**Shared helpers:**
- `_solve_system_prompt` ([:353](app/services/model_solver.py#L353)) — `_system_prompt(profile) + _STRUCTURED_SUFFIX + extra_instruction`, reused from `gemini_brain` so all models get identical tutor + structured-output instructions.
- `_user_block` ([:361](app/services/model_solver.py#L361)) — assembles prior session context + transcript + the actual question; explicitly tags a stated problem as a FRESH question.
- `_maybe_transcribe` ([:383](app/services/model_solver.py#L383)) — returns `("",None)` when no audio; an error message when audio is present but `GROQ_API_KEY` is missing or STT fails (so the caller can fail clearly).
- `_stt_via_groq` ([:400-412](app/services/model_solver.py#L400)) — WAV → text via Groq `whisper-large-v3`; forwards a real WAV as-is, else `_pcm_to_wav`. **Fixed 2026-07-04**: opens the client via `async with AsyncGroq(api_key=settings.GROQ_API_KEY) as client:` ([model_solver.py:408-411](app/services/model_solver.py#L408)) instead of a bare `AsyncGroq(...)` — this model-solver copy of the STT helper had the same unclosed-httpx-pool leak as `llm_claude._stt_via_groq` (doc 05 §7); now both close the connection pool after each call.
- `_parse_sim` ([:438](app/services/model_solver.py#L438)) — parse the model's JSON into `SimResponse`. Tries direct `model_validate_json`; on failure strips ```json fences/prose via `_strip_json_noise` and retries; **last resort** salvages the `speech` string via `_salvage_sim` so raw JSON/LaTeX soup is never spoken (returns `ok=False`).

---

## 7. Post-answer escalation gates (orchestrator + web)

After tier-1 (or the pre-routed `start_tier`) answers, the second gate decides whether to climb. The two surfaces implement parallel logic.

**Constants** ([orchestrator.py:1465-1466](app/services/orchestrator.py#L1465)):
```python
_ESCALATE_QUERY_TYPES = {"derivation", "calc", "mistake_id"}
_ESCALATE_STATUSES    = {"truncated"}
```

### 7.1 Lamp — `_should_escalate(reply, telemetry)`

([orchestrator.py:1522-1547](app/services/orchestrator.py#L1522)) returns **True iff** the tier-1 reply warrants a tier-2 re-call, evaluated in order:

1. `telemetry["status"] in _ESCALATE_STATUSES` (i.e. `"truncated"`) → **True**. The model literally couldn't finish.
2. `telemetry["status"] not in (None, "ok")` → **False**. Don't compound on real errors (timeout / safety).
3. `reply.confidence < settings.GEMINI_ESCALATE_CONFIDENCE` (default **0.45**) → **True**.
4. `reply.difficulty == "hard" and reply.query_type in _ESCALATE_QUERY_TYPES` → **True**.
5. **Semantic check floor:** if `settings.SEMANTIC_CHECK_ESCALATION` (default True) **and** `reply.query_type in {"check","mistake_id"}` → **True**, *not gated on difficulty* (the model's self-rating is untrustworthy for verification requests).
6. Else **False**.

### 7.2 Lamp — the escalation block (skip-tier jump)

([orchestrator.py:643-669](app/services/orchestrator.py#L643)). The `ceiling = 3 if self._llm_pro is not None else 2`. The whole block fires only if `GEMINI_DYNAMIC_THINKING` and `start_tier < ceiling` and not a Claude fallback and `(_should_escalate(...) or _sem_dispute)` and the memo conditions allow it. Then `next_tier = start_tier + 1`, **but a skip-tier jump to tier-3** happens when `start_tier == 1 and ceiling >= 3` AND any of:
- `telemetry["status"] in _ESCALATE_STATUSES` (truncated), or
- `reply.difficulty == "hard"`, or
- `reply.confidence <= 0.30` (inclusive — "0.30 exactly once slipped a strict < to tier 2"), or
- `_sem_dispute` (the model flagged a challenge to our prior answer).

A "Thinking harder" caption is pushed to the lamp, then the **Flash→Pro handoff brief** drops audio (already transcribed) and rides the image along only if `image_needed` ([orchestrator.py:692-709](app/services/orchestrator.py#L692)).

### 7.3 Web — `_sim_pick_next_tier(sim, current_tier)`

([frontend_manager.py:647-679](app/routes/frontend_manager.py#L647)) mirrors the lamp logic but routes purely on the model's self-reported analytics (the web brain has no per-call `status`, so there is **no truncation branch**). Returns the TARGET tier (2/3) or None:

```python
if sim.confidence >= 0.75 and sim.difficulty in {"easy","medium"}:        target = None
elif sim.difficulty == "hard" and (sim.confidence < 0.7
        or sim.query_type in {"derivation","calc","mistake_id"}):         target = 3
elif sim.confidence <= 0.30:                                              target = 3
elif sim.confidence < settings.GEMINI_ESCALATE_CONFIDENCE:               target = 2   # < 0.45
else:                                                                     target = None
# SEMANTIC CHECK FLOOR (MAX, never downgrades):
if settings.SEMANTIC_CHECK_ESCALATION and sim.query_type in {"check","mistake_id"}:
    floor = 3 if sim.difficulty == "hard" else 2
    target = floor if target is None else max(target, floor)
```

**`_sim_resolve_tier(target)`** ([frontend_manager.py:682-691](app/routes/frontend_manager.py#L682)) clamps the request to what's wired: `target >= 4 → 3`; `target >= 3 and not GEMINI_TIER3_ENABLED → 2`; None stops the dispatch loop.

### 7.4 Web — the AUTO flow (`_solve_auto`) end to end

([frontend_manager.py:1029-…](app/routes/frontend_manager.py#L1029)) is "the lamp's escalation plan on the web bench, with a per-step breakdown." The sequence:

1. **Pre-route** — if no typed text and `PREROUTE_STT_ENABLED` + audio, run `_safe_sim_stt` (Groq Whisper, bounded to 1.5 s — [frontend_manager.py:694-708](app/routes/frontend_manager.py#L694)). Build `image_quality` from `await asyncio.to_thread(assess_image_quality, image_blobs)` (fixed 2026-07-04 — `assess_image_quality` is synchronous/CPU-bound PIL+numpy work; calling it inline was blocking the event loop on every turn's pre-route gate whenever image-quality gating is enabled, now offloaded to a thread), then `decision = preroute(preroute_text, image_quality, len(image_blobs))`.
2. **Retake short-circuit** — if `decision.retake_image`, return a text `SimResponse` with the retake message, `final_tier=0`, note "pre-route retake — zero LLM spend" ([frontend_manager.py:1100-1115](app/routes/frontend_manager.py#L1100)). `start_tier = decision.start_tier`, `extra_instruction = decision.prompt_suffix`.
3. **Problem memo + nudge gate + dispute** — load the per-session answer key; a regex/semantic *dispute* forces `start_tier = 3` (if tier-3 enabled) with a fresh re-derivation, no key; a matched memo clamps `start_tier = 1` (flash + key beats a cold Pro start) ([frontend_manager.py:1119-1156](app/routes/frontend_manager.py#L1119)).
4. **First call** — `current = _sim_resolve_tier(start_tier) or 1`; `_auto_call(current, …)`; append an `AutoStep` (`role` = "keyed-nudge" or "first-pass").
5. **Semantic dispute backstop** — if the model itself flags `student_disputes_prior`, one promotion to tier-3 ([frontend_manager.py:1194-1214](app/routes/frontend_manager.py#L1194)).
6. **Focus guard** — `focus_mismatch(focus_label, ocr_text)` → one corrective re-call (`role="focus-guard"`) ([frontend_manager.py:1219-1243](app/routes/frontend_manager.py#L1219)).
7. **Escalation loop** ([frontend_manager.py:1286-1322](app/routes/frontend_manager.py#L1286)):
   ```python
   while settings.GEMINI_DYNAMIC_THINKING and (not memo_matched or result.confidence < 0.3):
       target = _sim_resolve_tier(_sim_pick_next_tier(result, current))
       if target is None or target <= current: break
       … handoff brief (drop audio; drop image unless image_needed) …
       result, usage, vendor, ms = await _auto_call(target, …)
       append AutoStep(role="escalation"); current = target
   ```
8. **Solution-bleed guard** ([frontend_manager.py:1324-1370](app/routes/frontend_manager.py#L1324)) — if a tier≥2 (or keyed tier-1) reply *leaked* the internal solution into speech/display, one corrective Socratic re-call (`role="bleed-guard"`), unless a `_low_budget()` reserve (20 s of the `SOLVE_TIMEOUT_S` wall clock) is exhausted.

Each LLM call becomes one `AutoStep` in `extra["steps"]`; `_result(...)` sums all steps' tokens and `estimated_cost` into the final `SolveResult` ([frontend_manager.py:1055-1071](app/routes/frontend_manager.py#L1055)).

---

## 8. `validator.py` — legacy BAO output validator

> **UPDATE 2026-07-01, path corrected 2026-07-03:** `validator.py` has been **moved to `app/legacy/validator.py`** (report task 2.1; the quarantine holds only `validator.py` + `turn_handler.py`) — it is dead and operates on a schema that no longer exists, and `tests/test_no_legacy_imports.py` fails CI if `app/` re-imports it. The **live** output validator is now `app/services/output_validator.py` (operates on `LlmReply`/`SimResponse`, runs pre-dispatch on both surfaces). See [11-output-validator-guardrails-and-verifier.md](11-output-validator-guardrails-and-verifier.md).

`validator.py` is a **separate, simpler** confidence/escalation + cleanup layer labelled "Output validator for BAO architecture" ([validator.py:1](app/services/validator.py#L1)). It is *not* the catalog/solver path above; it operates on a `dict` response and an `exam_track` string. Documented for completeness.

**`validate_response(response, exam_track)`** ([validator.py:31-63](app/services/validator.py#L31)) runs six checks in order:

1. **Confidence gate** — `if response.get("is_confident", 1.0) < 0.60: return {"action":"escalate", …}`. This is a distinct threshold (**0.60**) from the main path's `GEMINI_ESCALATE_CONFIDENCE` (0.45) / `_sim_pick_next_tier` (0.75/0.70/0.45/0.30) and a distinct field name (`is_confident` vs `confidence`).
2. **Track mismatch** — `if exam_track == "conceptual" and tft_display["kind"] == "latex"`: downgrade to plain text, strip `$` and `\`.
3. **Voice symbols** — `clean_voice` strips `["\\","$","**","#","_","$$"]` from `voice_output`.
4. **Voice too long** — `if count_sentences(voice_output) > 4: trim_to_sentences(…, 4)`. Sentences are split on `.`.
5. **TFT text too long** — `if kind == "text" and len(content) > 200: content = content[:200]`.
6. **LaTeX validity** — `if exam_track == "technical" and kind == "latex" and not is_valid_latex(content)`: downgrade to text.

Helpers: `is_valid_latex` ([validator.py:3-14](app/services/validator.py#L3)) is a brace-balance stack check (returns True iff every `{` has a matching `}`); `clean_voice`, `count_sentences`, `trim_to_sentences`. Result: `{"action":"escalate"|"send", "response": …}`.

---

## 9. Model-eval schemas & persistence

### 9.1 `app/schemas/model_eval.py`

Pydantic shapes for `/api/frontend/models`, `/solve`, `/solve/compare`. The answer body reuses `gemini_brain.SimResponse` so every model returns one uniform shape ([model_eval.py:1-16](app/schemas/model_eval.py#L1)).

| Model | Key fields |
|---|---|
| `ModelInfo` ([:19](app/schemas/model_eval.py#L19)) | `id, label, provider, available, vision, audio, input_per_mtok, output_per_mtok, note, is_default` — one dropdown row. |
| `ModelsOut` ([:33](app/schemas/model_eval.py#L33)) | `models: list[ModelInfo]`, `default_model`. |
| `AutoStep` ([:38](app/schemas/model_eval.py#L38)) | One LLM call inside AUTO: `tier (1/2/3)`, `model` (vendor that answered), `role` (`first-pass`/`escalation`/`keyed-nudge`/`bleed-guard`/`reveal-guard`/`focus-guard`), `reason`, `latency_ms`, `input_tokens`, `thinking_tokens`, `output_tokens`, `estimated_cost`, `confidence`. |
| `SolveMeta` ([:56](app/schemas/model_eval.py#L56)) | Per-invocation telemetry: `model_id, label, provider, status, latency_ms`, token counts, `estimated_cost`, `error`, `response_id`; **AUTO only:** `steps: list[AutoStep]`, `escalated`, `final_tier`, `memo_active`. |
| `FeedbackIn` ([:84](app/schemas/model_eval.py#L84)) | `response_id`, `thumbs: "up"/"down"`, `rating: 1-5`, `feedback_text` (≤2000). |
| `FeedbackOut` ([:94](app/schemas/model_eval.py#L94)) | `ok: bool`. |
| `SolveOut` ([:98](app/schemas/model_eval.py#L98)) | `response: SimResponse` + `meta: SolveMeta`. |
| `CompareOut` ([:104](app/schemas/model_eval.py#L104)) | `results: list[SolveOut]` (request order preserved). |

`AutoStep` and `SolveMeta` both set `model_config = ConfigDict(protected_namespaces=())` so fields like `model_id`/`model` don't collide with pydantic's protected `model_` namespace.

### 9.2 `app/storage/model_eval.py`

Persists every model invocation to dedicated `model_requests` / `model_responses` / `model_feedback` tables (distinct from the lamp's `turns`), and seeds `model_providers`. Same discipline as `turns.py`: **DB-availability-gated** (`_session_factory()` returns None instead of raising) and **crash-safe** (every error logged + swallowed — persistence MUST NEVER break a bench request) ([model_eval.py:1-16](app/storage/model_eval.py#L1)). IDs are generated by the caller (the `/solve` endpoint) and passed in, so the HTTP response can hand the frontend a `response_id` without waiting on the fire-and-forget DB write.

| Function | Behavior |
|---|---|
| `record_request(...)` ([:47](app/storage/model_eval.py#L47)) | Insert one `model_requests` row (`selected_model[:500]`, image_count, had_audio, channel="web"). Fire-and-forget; swallows all errors. |
| `record_response(...)` ([:85](app/storage/model_eval.py#L85)) | Insert one `model_responses` row. **Failures/timeouts are KEPT** (they're the failure-rate metric); `success_status = (status == "ok")`; `generated_answer[:8000]`. |
| `record_feedback(...)` ([:132](app/storage/model_eval.py#L132)) | UPSERT keyed on `(response_id, user_id)`. Validates the target response exists (no orphan feedback), clamps `rating` to 1-5 and `thumbs` to up/down, `feedback_text[:2000]`. Merges — only overwrites fields actually provided. Returns True/False. |
| `seed_providers()` ([:191](app/storage/model_eval.py#L191)) | Upsert the in-code catalog into `model_providers` (label/version/active/pricing) so the registry is queryable in SQL. `active_status = model_catalog.is_available(spec)`. Best-effort, called once at startup after `init_db`. |

Helpers: `_session_factory()` (never raises), `_as_uuid()` (tolerant parse → None on failure).

---

## 10. Configuration, environment variables & constants

All from `app/config.py` unless noted. Defaults shown.

**Pre-router knobs** ([config.py:605-627](app/config.py#L605)):

| Setting | Default | Effect |
|---|---|---|
| `PREROUTE_ENABLED` | `True` | Master switch for the pre-router in `_solve_auto`. |
| `PREROUTE_STT_ENABLED` | `True` | Run Groq Whisper for a fast transcript when no typed text. |
| `PREROUTE_IMAGE_QUALITY_GATE` | `True` | Run the blur/dark/small image gate. |
| `PREROUTE_BLUR_MIN` | `30.0` | Variance-of-Laplacian floor; below = blurry. Used `*4` for the small-frame override. |
| `PREROUTE_MIN_DIM_PX` | `240` | Min short-side px (real captures are ≥480p). |
| `PREROUTE_LUMA_MIN` | `22.0` | Mean brightness floor; below = near-black. |

**Tier / escalation knobs** ([config.py:404-510](app/config.py#L404)):

| Setting | Default | Effect |
|---|---|---|
| `GEMINI_DYNAMIC_THINKING` | `True` | Master switch for two/multi-tier dispatch. False → single tier. |
| `GEMINI_TIER1_THINKING_BUDGET` | `0` | Tier-1 no thinking (fastest, cheapest). |
| `GEMINI_TIER1_MAX_OUTPUT_TOK` | `1200` | Raised (600→900→1200) because escaped-LaTeX JSON hit MAX_TOKENS and force-escalated (worst-cost outcome). |
| `GEMINI_TIER2_THINKING_BUDGET` | `1024` | Deep reasoning. |
| `GEMINI_TIER2_MAX_OUTPUT_TOK` | `4000` | Raised 2500→4000 because Gemini-3.x budget 1024 maps to thinking_level=high, which spikes. |
| `GEMINI_ESCALATE_CONFIDENCE` | `0.45` | confidence below this → escalate. |
| `GEMINI_TIER3_ENABLED` | `True` | Enabled — wires the Pro tier (the pre-router ceiling becomes 3). |
| `GEMINI_TIER3_MODEL` | `gemini-3.1-pro-preview` | The tier-3 model. |
| `GEMINI_TIER3_THINKING_BUDGET` | `512` | Lowered 1024→512 (1024 → thinking_level=high → tier-3 timeouts). |
| `GEMINI_TIER3_MAX_OUTPUT_TOK` | `10000` | Tier-3 is the ceiling: truncation here has no escalation left. |
| `GEMINI_TIER3_CODE_EXECUTION` | `True` | Gemini-3.x built-in Python sandbox for numerics. |
| `GEMINI_TIER3_TIMEOUT_S` | `38.0` | Per-call hard timeout for the Pro call only (≤ lamp firmware's 45 s THINKING_TIMEOUT_MS). |
| `GEMINI_TIER4_ENABLED` | `False` | Bridge tier (DeepSeek R1 / Claude Opus) — deferred/proposed. |
| `SEMANTIC_CHECK_ESCALATION` | `True` | Escalate any `check`/`mistake_id` turn (skip-tier sends hard ones to Pro). |
| `DISPUTE_GUARD` | `True` | A challenge to OUR prior answer forces a fresh Pro re-derivation. |
| `CHECK_VERDICT_GUARD` | `True` | A verify-request ("is my answer right?") injects `check_verdict_note` → plain verdict, not a nudge; never reveals the solution or re-derives at Pro. |

**Solver / catalog knobs:**

| Setting | Default | Effect |
|---|---|---|
| `SOLVE_TIMEOUT_S` | `30.0` ([config.py:178](app/config.py#L178)) | Per-model-call wall clock in `model_solver`/`_solve_auto`. |
| `ANTHROPIC_MODEL` | `claude-sonnet-4-6` ([config.py:41](app/config.py#L41)) | Catalog `claude` vendor model. |
| `DEEPSEEK_MODEL` | `deepseek-chat` ([config.py:54](app/config.py#L54)) | Catalog `deepseek` vendor model. |
| `DEEPSEEK_BASE_URL` | `https://api.deepseek.com` ([config.py:55](app/config.py#L55)) | OpenAI-compatible endpoint. |
| `MODEL_PRICING_JSON` (env) | unset | Runtime price overrides; malformed → ignored. |
| `OPENAI_MODEL_GPT5` / `_MINI` (env) | `gpt-5` / `gpt-5-mini` | OpenAI vendor model pins. |
| `GROQ_API_KEY` | — | Required for voice on non-audio providers + the pre-router STT. |
| `GEMINI/OPENAI/ANTHROPIC/DEEPSEEK_API_KEY` | — | Provider availability (`is_available`). |

**In-code constants:** `DEFAULT_MODEL_ID="gemini-2.5-flash"`; `_FALLBACK_TIMEOUT_S=30.0`; `_BUSY_MARKERS` (model_solver); `_ESCALATE_QUERY_TYPES={"derivation","calc","mistake_id"}`, `_ESCALATE_STATUSES={"truncated"}` (orchestrator).

---

## 11. Edge cases, errors, timeouts, fallbacks

- **Undecodable / no image** → `assess_image_quality` returns `ok=True` so a decode quirk never blocks a turn ([escalation_router.py:133-134](app/services/escalation_router.py#L133)).
- **Poor image but strong text** → tolerated (text ≥ 6 words); records `image_<reason>_but_text_present` and continues ([escalation_router.py:414-421](app/services/escalation_router.py#L414)).
- **Tier-3 requested but disabled** → clamped to tier-2 by `_sim_resolve_tier` and the pre-router `ceiling` ([frontend_manager.py:689-690](app/routes/frontend_manager.py#L689), [escalation_router.py:388](app/services/escalation_router.py#L388)).
- **Unknown model id** → ghost spec + `status="error"`, never an exception ([model_solver.py:128-138](app/services/model_solver.py#L128)).
- **Missing provider key** → `status="not_configured"` ([model_solver.py:140-145](app/services/model_solver.py#L140)).
- **Timeout** → `asyncio.wait_for` → `status="timeout"` ([model_solver.py:154-159](app/services/model_solver.py#L154)).
- **Provider overload (503/429)** → `status="busy"`, friendly amber message, single WARN ([model_solver.py:163-172](app/services/model_solver.py#L163)).
- **Voice without `GROQ_API_KEY`** on a non-audio provider → clear error ("ask in text, or pick Gemini for voice.") ([model_solver.py:389-391](app/services/model_solver.py#L389)).
- **Unparseable JSON** → fence-strip retry, then `_salvage_sim` plain-text fallback (`ok=False`) ([model_solver.py:438-459](app/services/model_solver.py#L438)).
- **SDK missing** (`openai`/`anthropic`/`groq`) → `status="error"` "SDK not installed" ([model_solver.py:243-245](app/services/model_solver.py#L243)).
- **Low budget** → `_solve_auto` skips guard re-calls when within 20 s of the `SOLVE_TIMEOUT_S` wall clock — shipping a slightly imperfect reply beats `asyncio.wait_for` discarding paid-for tokens ([frontend_manager.py:1042-1052](app/routes/frontend_manager.py#L1042)).
- **AUTO dispatched to provider layer** → `_solve_gemini` returns an explicit error rather than a raw 404 ([model_solver.py:222-229](app/services/model_solver.py#L222)).
- **DB off** → all `storage/model_eval` functions no-op (return early); the UI hides the feedback affordance when `response_id` is None.
- **Truncation (thinking-tokens bug)** → the root cause documented in the plan: Gemini's hidden chain-of-thought shares the `max_output_tokens` pool; fix is explicit `ThinkingConfig(thinkingBudget=…)` per tier, and `status="truncated"` force-escalates ([ESCALATION_PLAN.md:38-42](ESCALATION_PLAN.md#L38)).
- **All tiers fail** → canonical `FALLBACK_REPLY` ("Sorry, I had trouble answering that…"), lamp shows STATE(error) red LED ([ESCALATION_PLAN.md:398-407](ESCALATION_PLAN.md#L398)).

---

## 12. Integration points (who calls what)

**Calls INTO this subsystem:**
- `frontend_manager._solve_auto` calls `assess_image_quality`, `preroute`, `extract_focus_label` (via decision), `focus_mismatch` + `FOCUS_GUARD_NOTE`, and the post gates `_sim_pick_next_tier`/`_sim_resolve_tier` ([frontend_manager.py:1090-1322](app/routes/frontend_manager.py#L1090)).
- `orchestrator.run_turn` calls the pre-router for the lamp (`start_tier`, retake) and `_should_escalate` as the post gate ([orchestrator.py:278-342](app/services/orchestrator.py#L278), [orchestrator.py:648](app/services/orchestrator.py#L648)).
- The `/solve` and `/solve/compare` routes call `model_solver.generate_solution(...)` for direct model picks, and `_solve_auto` for the `"auto"` id.
- The `/api/frontend/models` endpoint reads `model_catalog.list_models()`/`is_available` to build `ModelsOut`.
- App startup calls `storage/model_eval.seed_providers()` after `init_db`.

**This subsystem calls OUT to:**
- `app.config.settings` — every threshold/flag.
- `numpy` + `PIL` (lazy) — image decode/blur.
- `gemini_brain` — `simulate_with_usage`, `SimResponse`, `_system_prompt`, `_STRUCTURED_SUFFIX`, `_salvage_sim`.
- `llm_gemini._strip_json_noise` — JSON repair.
- Groq Whisper (`whisper-large-v3`) — STT for non-audio providers + the pre-router transcript.
- The provider SDKs: `google-genai` (Gemini), `openai` (OpenAI + DeepSeek base-url), `anthropic` (Claude).
- DB models `ModelRequest`/`ModelResponse`/`ModelFeedback`/`ModelProvider`.

**Cross-references to other parts of the system:**
- **Firmware** — the lamp supplies a fast Groq-Whisper transcript (or typed text on web) to `preroute`; the firmware `THINKING_TIMEOUT_MS = 45 s` caps `GEMINI_TIER3_TIMEOUT_S = 38 s` ([config.py:508-510](app/config.py#L508)). The "\x02Thinking harder" caption marks the lamp's THINKING spinner ([orchestrator.py:670-677](app/services/orchestrator.py#L670)).
- **Frontend** — the model dropdown + the AUTO per-step storyboard render `ModelInfo`/`SolveMeta`/`AutoStep`; `estimated_cost`/`status` drive the per-model UI; `response_id` attaches feedback.
- **Database (Supabase/Postgres)** — `model_requests`/`model_responses`/`model_feedback`/`model_providers` tables (separate from `turns`); the plan proposes `final_tier`/`escalation_path` columns on `turns` for tier-mix analytics ([ESCALATION_PLAN.md:341-364](ESCALATION_PLAN.md#L341)).

---

## 13. Mermaid diagrams

### 13.1 Pre-router decision flow (`preroute`)

```mermaid
flowchart TD
    A[preroute text, image_quality, image_count] --> B{IMAGE_QUALITY_GATE on<br/>AND image present<br/>AND not image_quality.ok<br/>AND image_count > 0}
    B -- yes --> C{text < 6 words?}
    C -- yes --> D[retake_image = True<br/>RETURN: 0 LLM spend]
    C -- no --> E[record image_reason_but_text_present]
    B -- no --> E
    E --> F[sig = classify_text<br/>ceiling = 3 if TIER3_ENABLED else 2]
    F --> G[focus_label = extract_focus_label]
    G --> H{sig.extreme?}
    H -- yes --> H1[start_tier = max start, min 3, ceiling]
    H --> I{sig.hard or sig.diagram?}
    I -- yes --> I1[start_tier = max start, 2]
    F --> J{sig.mcq?}
    J -- yes --> J1[start_tier = max start, 2<br/>require_option_verification]
    F --> K{sig.mistake?}
    K -- yes --> K1[start_tier = max start, 2<br/>require_mistake_localization]
    F --> L{sig.formula_def and start_tier == 1?}
    L -- yes --> L1[reason formula_definition<br/>stay tier-1]
    H1 & I1 & J1 & K1 & L1 & E --> M[start_tier = min start_tier, ceiling]
    M --> N[RETURN PrerouteDecision]
```

### 13.2 Full AUTO flow with both gates (web `_solve_auto`)

```mermaid
sequenceDiagram
    participant U as /solve route (auto)
    participant SA as _solve_auto
    participant PR as escalation_router.preroute
    participant LLM as _auto_call (Gemini tier N)
    participant G as _sim_pick_next_tier
    participant CAT as model_catalog
    participant DB as storage.model_eval

    U->>SA: text, audio, images, profile, history
    SA->>PR: assess_image_quality + preroute
    alt image unreadable AND text thin
        PR-->>SA: retake_image=True
        SA-->>U: retake message (final_tier=0, 0 spend)
    else proceed
        PR-->>SA: start_tier, prompt_suffix, focus_label
        SA->>LLM: tier=start_tier (first-pass / keyed-nudge)
        LLM-->>SA: SimResponse (confidence, difficulty, query_type)
        SA->>CAT: estimate_cost per step
        loop while DYNAMIC_THINKING and (not memo_matched or conf<0.3)
            SA->>G: _sim_pick_next_tier(result, current)
            G-->>SA: target tier (2/3) or None
            alt target > current
                SA->>LLM: tier=target (escalation, handoff brief)
                LLM-->>SA: stronger SimResponse
            else
                Note over SA: break — ship current
            end
        end
        SA->>SA: focus-guard / bleed-guard re-calls (budget permitting)
        SA-->>U: SolveResult + AutoStep[] + final meta
        U->>DB: record_request / record_response (fire-and-forget)
    end
```

### 13.3 Post-answer gate — lamp `_should_escalate` + skip-tier

```mermaid
flowchart TD
    A[tier reply + telemetry] --> B{status == truncated?}
    B -- yes --> ESC[escalate = True]
    B -- no --> C{status not in null/ok?}
    C -- yes --> NO[escalate = False<br/>don't compound errors]
    C -- no --> D{confidence < 0.45?}
    D -- yes --> ESC
    D -- no --> E{difficulty==hard AND<br/>query_type in derivation/calc/mistake_id?}
    E -- yes --> ESC
    E -- no --> F{SEMANTIC_CHECK_ESCALATION AND<br/>query_type in check/mistake_id?}
    F -- yes --> ESC
    F -- no --> NO
    ESC --> G{start_tier==1 AND ceiling>=3 AND<br/>truncated OR hard OR conf<=0.30 OR dispute?}
    G -- yes --> H[next_tier = 3 SKIP-TIER JUMP]
    G -- no --> I[next_tier = start_tier + 1]
    H & I --> J[Flash to Pro handoff brief<br/>drop audio, image only if image_needed]
```

---

*End of reference. Every threshold, constant, and branch above is quoted from the cited code; nothing is inferred beyond what the source files and `ESCALATION_PLAN.md` state.*
