# Backend — LLM Providers, Brain & Grounding

This is the definitive reference for the Smart Tutor Lamp backend's LLM layer: the provider abstraction (`LlmProvider`), the four concrete providers (Gemini, OpenAI, Claude, DeepSeek), the web "brain" (`gemini_brain`), the shared JSON parsing/telemetry machinery, the search-grounding stub, and the multi-tier Claude timeout-fallback strategy. Every behaviour described below is grounded in the actual source — exact model identifiers, constants, thresholds, retry policies and control flow are quoted from the code. Read this when you need to understand how a turn's text input becomes a validated `LlmReply`, how providers are swapped via one env var, and what happens when Gemini fails.

---

## Table of Contents

1. [Purpose & responsibility](#1-purpose--responsibility)
2. [Architecture overview](#2-architecture-overview)
3. [The provider abstraction — `llm_base.py`](#3-the-provider-abstraction--llm_basepy)
   - [3.1 Shared constants](#31-shared-constants)
   - [3.2 The `gemini_thinking_config` shim](#32-the-gemini_thinking_config-shim)
   - [3.3 The `gemini_code_execution_tool` shim](#33-the-gemini_code_execution_tool-shim)
   - [3.4 The `LlmProvider` ABC](#34-the-llmprovider-abc)
   - [3.5 The factory / registry](#35-the-factory--registry)
4. [The output contract — `LlmReply`](#4-the-output-contract--llmreply)
5. [Reference provider — `llm_gemini.py`](#5-reference-provider--llm_geminipy)
   - [5.1 Client singleton & httpx workaround](#51-client-singleton--httpx-workaround)
   - [5.2 `GeminiProvider.call()` — control flow & retries](#52-geminiprovidercall--control-flow--retries)
   - [5.3 `_drain()` — building multimodal contents](#53-_drain--building-multimodal-contents)
   - [5.4 `_drain_unary` vs `_drain_stream`](#54-_drain_unary-vs-_drain_stream)
   - [5.5 `preupload_image()` — Files API latency hook](#55-preupload_image--files-api-latency-hook)
   - [5.6 Error classification helpers](#56-error-classification-helpers)
   - [5.7 `_parse_or_fallback` — the shared JSON parser](#57-_parse_or_fallback--the-shared-json-parser)
   - [5.8 Back-compat wrappers](#58-back-compat-wrappers)
6. [OpenAI provider — `llm_openai.py`](#6-openai-provider--llm_openaipy)
7. [Claude provider — `llm_claude.py`](#7-claude-provider--llm_claudepy)
8. [DeepSeek provider — `llm_deepseek.py`](#8-deepseek-provider--llm_deepseekpy)
9. [The web brain — `gemini_brain.py`](#9-the-web-brain--gemini_brainpy)
10. [Grounding / search — `grounding.py`](#10-grounding--search--groundingpy)
11. [The Claude timeout-fallback strategy](#11-the-claude-timeout-fallback-strategy)
12. [Configuration & environment variables](#12-configuration--environment-variables)
13. [Edge cases, errors, timeouts, retries](#13-edge-cases-errors-timeouts-retries)
14. [Integration points](#14-integration-points)
15. [Diagrams](#15-diagrams)
16. [Capability matrix & model-id summary](#16-capability-matrix--model-id-summary)

---

## 1. Purpose & responsibility

This layer is **Layer 4 of `BACKEND_TODO.md`** — the *swappable AI brain*. Its single responsibility: convert a turn's inputs (system prompt + history text + image(s) + audio) into a validated `LlmReply` JSON object plus a provider-agnostic telemetry dict, **without leaking any vendor SDK into the orchestrator**. ([llm_base.py:1-7](app/providers/llm_base.py#L1))

The design goal is stated at the top of the base module: *"Every concrete provider (Gemini, OpenAI, Claude, DeepSeek, ...) implements the same `LlmProvider.call()` contract so the orchestrator never imports any specific SDK. Switch providers by setting `LLM_PROVIDER` in .env — no code change required."* ([llm_base.py:4-7](app/providers/llm_base.py#L4))

Two surfaces consume this layer:

- **The lamp** (ESP32 over WebSocket) → `app/services/orchestrator.py` builds a provider via `get_llm_provider()` and calls `provider.call(...)` per tier. The lamp renders LaTeX with a **matplotlib mathtext subset**.
- **The web simulator / bench** (`/api/frontend/*`) → uses `app/providers/gemini_brain.py` directly (a separate, KaTeX-targeted code path), which renders **full LaTeX** including aligned environments. The two surfaces are deliberately separate because they have different display contracts. ([gemini_brain.py:1-12](app/providers/gemini_brain.py#L1))

---

## 2. Architecture overview

```
app/providers/
├── llm_base.py        ← LlmProvider ABC + factory/registry + shared constants
│                        + gemini_thinking_config / gemini_code_execution_tool shims
├── llm_gemini.py      ← GeminiProvider (REFERENCE impl) + _parse_or_fallback
│                        + _strip_json_noise + _extract_http_status + back-compat wrappers
├── llm_openai.py      ← OpenAIProvider (GPT-4o, audio+image+text, JSON mode)
├── llm_claude.py      ← ClaudeProvider (text+image; Groq Whisper STT upstream) + _stt_via_groq
├── llm_deepseek.py    ← DeepSeekProvider (text only; reuses Groq STT helper)
├── gemini_brain.py    ← WEB brain (SimResponse, structured one-shot, retries)
└── grounding.py       ← GoogleSearchGrounder (MOCK stub, not wired)
```

Key cross-module dependencies:

- `llm_openai.py`, `llm_claude.py`, `llm_deepseek.py` all **import `_parse_or_fallback` from `llm_gemini`** ([llm_openai.py:30](app/providers/llm_openai.py#L30), [llm_claude.py:33](app/providers/llm_claude.py#L33), [llm_deepseek.py:34](app/providers/llm_deepseek.py#L34)).
- `llm_deepseek.py` **imports `_stt_via_groq` from `llm_claude`** to avoid duplicating the STT helper ([llm_deepseek.py:35](app/providers/llm_deepseek.py#L35)).
- `gemini_brain.py` borrows the `gemini_thinking_config` and `gemini_code_execution_tool` shims from `llm_base` ([gemini_brain.py:608](app/providers/gemini_brain.py#L608), [gemini_brain.py:623](app/providers/gemini_brain.py#L623)).
- All providers output the same `LlmReply` schema (`app/schemas/llm_response.py`); the web brain outputs the parallel `SimResponse`.

---

## 3. The provider abstraction — `llm_base.py`

### 3.1 Shared constants

| Constant | Value | Meaning / effect |
|---|---|---|
| `LLM_HARD_TIMEOUT_S` | `20.0` | Wall-clock ceiling for any call; > 20 s falls back. Bumped 12→20 s after free-tier Gemini Flash hit the old 12 s ceiling on Mumbai→us-central1 multimodal calls. ([llm_base.py:38](app/providers/llm_base.py#L38)) |
| `LLM_MAX_OUTPUT_TOKENS` | `900` | Provider-level default output-token cap. 600 fit a typical reply, but equation-heavy JSON (escaped LaTeX doubles every backslash's token cost) hit MAX_TOKENS at 590 in prod (2026-06-11). 900 covers equation-heavy replies; it's a ceiling, not a spend. ([llm_base.py:66](app/providers/llm_base.py#L66)) |

The `LLM_HARD_TIMEOUT_S` docstring quantifies the irreducible latency it must accommodate: network RTT India→US-Central 200-500 ms each way, ~170 KB multimodal upload 250-400 ms, audio analysis of a 5 s clip 2-5 s, vision 1-3 s, generation 1-3 s — realistic p95 free-tier total 12-15 s, so 20 s "catches the long tail without making genuinely-stuck calls last forever." ([llm_base.py:39-53](app/providers/llm_base.py#L39))

> **Note:** the `llm_gemini.py` comment at [llm_gemini.py:37](app/providers/llm_gemini.py#L37) still says "Total time still bounded by LLM_HARD_TIMEOUT_S = 8 s" — this is a stale comment; the actual constant is 20.0.

`LLM_MAX_OUTPUT_TOKENS` is the **provider-level default** (used by Claude/DeepSeek/OpenAI and untiered calls). The lamp orchestrator overrides it per tier via `settings.GEMINI_TIER1/2/3_MAX_OUTPUT_TOK`. ([llm_base.py:60-65](app/providers/llm_base.py#L60))

### 3.2 The `gemini_thinking_config` shim

`gemini_thinking_config(model, thinking_budget)` builds the correct `ThinkingConfig` for the model family, because Gemini 2.5 and 3.x use different APIs ([llm_base.py:69-102](app/providers/llm_base.py#L69)):

- **Gemini 2.5** uses `thinkingBudget` (an integer token count; `0` disables thinking).
- **Gemini 3.x** uses a string `thinking_level` enum. Setting *both* `thinkingBudget` and `thinking_level` on the same call returns a 400 ("only one of thinking budget and thinking level"), so the shim emits exactly one field per model family.

The numeric→enum mapping for `gemini-3*` models (verified live, with observed thought-token draw on flash-lite):

```
budget <= 0    → "minimal"  (~0 thoughts; the true off — tier-1 router)
budget <  512  → "low"      (~111 thoughts)
budget < 1024  → "medium"   (~210 thoughts)
budget >= 1024 → "high"     (~422+ thoughts; tier-2 deep / pro)
```

The model id is normalized via `(model or "").lower().removeprefix("models/")`. For non-3.x models it returns `types.ThinkingConfig(thinkingBudget=thinking_budget)`. It returns `None` (= model default) if the installed SDK predates `thinking_level`, and **never raises**. ([llm_base.py:91-102](app/providers/llm_base.py#L91))

### 3.3 The `gemini_code_execution_tool` shim

`gemini_code_execution_tool(model)` returns a `types.Tool(code_execution=types.ToolCodeExecution())` — Google's server-side Python sandbox — so the model *computes* numerics instead of hallucinating them. ([llm_base.py:105-139](app/providers/llm_base.py#L105))

Strict gating (each rule probed live):

- **Only Gemini 3.x** can combine code execution with `response_schema` JSON mode; 2.5 models reject the combo with `400 "Tool use with a response mime type: 'application/json' is unsupported"` (probed 2026-06-12).
- **Pro only** (`gemini-3* … pro`, *not* flash / flash-lite): the function returns `None` unless `m.startswith("gemini-3") and "pro" in m`. A flash-lite tier-1 call with the tool attached looped on a Socratic prompt → `finish_reason TOO_MANY_TOOL_CALLS`, output blew to 5471 tokens (probed 2026-06-13).
- **Caller audio gate:** the API rejects AUDIO parts on a call carrying this tool (`400 "mime type audio/... is not supported for code execution"`); inline-JPEG and Files-ref images are fine. Callers must skip the tool when the call includes audio. ([llm_base.py:116-120](app/providers/llm_base.py#L116))

The live probe showed it's a latency/cost win: **8.4 s / ~520 thinking tokens with the tool vs 42.7 s / ~5 760 thinking tokens** grinding the same product mentally. ([llm_base.py:112-114](app/providers/llm_base.py#L112)) Returns `None` for non-pro/non-3.x models or an SDK without the type — never raises. ([llm_base.py:131-139](app/providers/llm_base.py#L131))

### 3.4 The `LlmProvider` ABC

```python
class LlmProvider(ABC):
    name:  ClassVar[str] = "abstract"   # short id used in .env (e.g. "gemini")
    model: ClassVar[str] = ""           # vendor's model id (e.g. "gemini-2.5-flash")
```
([llm_base.py:142-147](app/providers/llm_base.py#L142))

The abstract `call()` signature (the contract every provider must satisfy):

```python
async def call(
    self,
    system_prompt: str,
    history_text: str,
    image_bytes: bytes,
    audio_bytes: bytes,
    *,
    thinking_budget:    int | None = None,
    max_output_tokens:  int | None = None,
    hard_timeout_s:     float | None = None,
) -> tuple[LlmReply, dict]:
```
([llm_base.py:149-160](app/providers/llm_base.py#L149))

Contract semantics from the docstring ([llm_base.py:161-176](app/providers/llm_base.py#L161)):

- Returns `(parsed reply, telemetry dict)`.
- `thinking_budget` / `max_output_tokens` are per-call overrides for the orchestrator's two-tier dispatch; `None` = the provider's default. Providers without thinking ignore `thinking_budget`.
- `hard_timeout_s` overrides the provider's wall-clock ceiling for *this* call (tier-3 Pro passes a longer window). **A provider honoring a custom value should treat it as a single attempt (no fresh-retry)** so the bounded window can't double.

> **Signature drift note:** the *concrete* `GeminiProvider.call` and `ClaudeProvider.call` accept `images: list[bytes]` (plural) plus extra kwargs (`image_refs`, `transcript`, `**_`), whereas the ABC and the `OpenAIProvider`/`DeepSeekProvider` stubs still declare the singular `image_bytes: bytes`. The orchestrator calls with `images=[...]` (a list), so only the Gemini and Claude providers match the live call site today. ([llm_gemini.py:186-197](app/providers/llm_gemini.py#L186), [llm_claude.py:63-75](app/providers/llm_claude.py#L63) vs [llm_openai.py:58-64](app/providers/llm_openai.py#L58))

Two more ABC members:

- `preupload_image(self, jpeg)` — an **optional latency hook**: upload one JPEG to the provider's file store BEFORE the turn's call (lamp images arrive seconds before AUDIO_END). Returns an opaque handle (or `None`). Default base impl returns `None` (unsupported). ([llm_base.py:179-186](app/providers/llm_base.py#L179))
- `_new_telemetry()` — bootstraps a fresh telemetry dict. ([llm_base.py:189-199](app/providers/llm_base.py#L189))

**Telemetry dict shape** (every provider returns this; keeps persistence provider-agnostic) ([llm_base.py:16-25](app/providers/llm_base.py#L16), [llm_base.py:189-199](app/providers/llm_base.py#L189)):

```python
{
  "ttft_ms":   None,                 # ms call-start → first text chunk
  "total_ms":  0,                    # ms call-start → JSON parsed
  "raw_chars": 0,                    # length of raw response buffer
  "model":     self.model,           # e.g. "gemini-2.5-flash"
  "provider":  self.name,            # e.g. "gemini"
  "status":    "ok",                 # ok|timeout|safety_block|bad_json|error|not_implemented|...
  "error":     None,
  "_t0":       time.monotonic(),     # internal start marker
}
```

Statuses observed across providers: `ok`, `timeout`, `safety_block`, `bad_json`, `truncated`, `error`, `rate_limited`, `upstream_unavailable`. (The base docstring's enumeration is a subset; `truncated`/`rate_limited`/`upstream_unavailable` come from `llm_gemini`/`_parse_or_fallback`.)

### 3.5 The factory / registry

A module-level registry and per-name instance cache drive provider selection ([llm_base.py:203-204](app/providers/llm_base.py#L203)):

```python
_PROVIDER_REGISTRY: dict[str, type[LlmProvider]] = {}
_INSTANCE_CACHE:    dict[str, LlmProvider]       = {}
```

- **`@register_provider`** — decorator: each subclass self-registers under `cls.name.lower()`. Raises `ValueError` if `name` is empty or `"abstract"`. ([llm_base.py:207-219](app/providers/llm_base.py#L207))
- **`get_llm_provider(name=None)`** — returns a **cached** instance of the configured provider. Resolution order: explicit `name` arg → `os.getenv("LLM_PROVIDER", "gemini")`, then `.lower().strip()`. Caching means SDK client construction (HTTP/2 pool, TLS handshake) happens at most once per process — *"Across many WS sessions this saves ~80 ms per turn."* Unknown provider → `ValueError` listing known names. ([llm_base.py:222-249](app/providers/llm_base.py#L222))
- **`reset_provider_cache()`** — drops cached instances (for tests / `.env` hot-reload). ([llm_base.py:252-255](app/providers/llm_base.py#L252))
- **`list_providers()`** — sorted registered names (for `/healthz`). ([llm_base.py:258-261](app/providers/llm_base.py#L258))
- **`_ensure_all_providers_imported()`** — imports `llm_gemini`, `llm_openai`, `llm_claude`, `llm_deepseek` so their `@register_provider` decorators run. Lazy-imported inside the function so circular imports are impossible. ([llm_base.py:264-274](app/providers/llm_base.py#L264))

---

## 4. The output contract — `LlmReply`

Every provider must emit a JSON that validates against `LlmReply` (`app/schemas/llm_response.py`). This is **Layer 5.2** and matches the system prompts in `app/prompts/turn{1,2}_system.py`. ([llm_response.py:1-11](app/schemas/llm_response.py#L1))

Three independent output channels ([llm_response.py:74-86](app/schemas/llm_response.py#L74)):

- `speech` → TTS (words only; no LaTeX/markdown).
- `display` → the TFT text card (`Display{kind: "text"|"none", content: str}`; prose that may reference `eq1`/`eq2`/`eq3`).
- `latex_equations: list[str]` → the TFT LaTeX region, **hard cap `MAX_EQUATIONS = 3`** ([llm_response.py:25](app/schemas/llm_response.py#L25), [llm_response.py:102-112](app/schemas/llm_response.py#L102)). `max_length=3` feeds Gemini's `response_schema` `maxItems` so the constrained decoder cannot overshoot.

Analytics fields stored in Postgres `turns`: `confidence` (float `0.8` default, `ge=0.0, le=1.0`), `query_type`, `subject`, `difficulty`. ([llm_response.py:114-136](app/schemas/llm_response.py#L114)) `confidence` below `0.45` is what the orchestrator uses to escalate (see `GEMINI_ESCALATE_CONFIDENCE`).

Conversation-memory / memo fields (never spoken or shown): `user_input`, `problem_statement`, `image_needed`, `solution_outline`, `same_problem`, `student_stuck`, `student_disputes_prior`. ([llm_response.py:138-224](app/schemas/llm_response.py#L138)) Visual-grounding audit fields: `ocr_text`, `bounding_box` (`[ymin, xmin, ymax, xmax]`, each 0-1000). ([llm_response.py:226-252](app/schemas/llm_response.py#L226))

**`model_config = ConfigDict(extra="ignore")`** — extra keys are dropped, not errored, so a rogue field can't nuke the whole reply. ([llm_response.py:88](app/schemas/llm_response.py#L88))

**The tolerant pre-validator `_coerce_tolerant`** (`@model_validator(mode="before")`) sanitises a semantically-off-but-structurally-valid reply BEFORE field validation so a single bad *analytics* field never discards the user-facing `speech`/`display` ([llm_response.py:254-393](app/schemas/llm_response.py#L254)):

- `confidence` → `float(...)` clamped to `[0,1]`. An **absent/null** field uses the schema default `0.8`; a **present-but-unparseable (garbage)** value now defaults to **`0.3`** (2026-07-06) — default-to-uncertain, so a broken reply *routes to* escalation instead of suppressing it (the old fail-high 0.8 hid the uncertainty of exactly the replies least likely to be right). Both paths log a WARN.
- `latex_equations` → keep only non-empty strings, capped at `MAX_EQUATIONS` (logs when it trims, since a dropped eqN dangles any "eqN" reference in `display.content`).
- `query_type`/`subject`/`difficulty` → coerced to their schema default if not a known enum (valid sets at [llm_response.py:29-33](app/schemas/llm_response.py#L29)).
- `speech` → coerced to `str`; `user_input` capped at 200 chars; `ocr_text` capped at 80 chars.
- `bounding_box` → exactly 4 ints clamped `[0,1000]` with `ymin<ymax` and `xmin<xmax`, else `None`.
- `display` → unwrap a `Display` instance to dict, ensure a valid `{kind, content}` (invalid `kind` → `none`, which BLANKS the text card — logged).

**Status → fallback mapping** via `fallback_for_status(status)` ([llm_response.py:464-479](app/schemas/llm_response.py#L464)):

| status | reply constant | spoken text |
|---|---|---|
| `upstream_unavailable` | `_UPSTREAM_UNAVAILABLE_REPLY` | "The Gemini servers are busy right now…" |
| `rate_limited` | `_RATE_LIMITED_REPLY` | "I have hit my per-minute rate limit…" |
| `timeout` | `_TIMEOUT_REPLY` | "The model took too long to answer…" |
| `truncated` | `_TRUNCATED_REPLY` | "That answer came out longer than I can fit…" |
| anything else | `FALLBACK_REPLY` | "Sorry, I had trouble answering that…" |

All fallback replies have `confidence=0.0`. `retake_image_reply(detail)` is a no-LLM reply with `status="ok"` and `confidence=1.0` used by the pre-router's image-quality gate. ([llm_response.py:399-461](app/schemas/llm_response.py#L399))

---

## 5. Reference provider — `llm_gemini.py`

`GeminiProvider` is the reference implementation; other providers follow its shape so the orchestrator never imports an SDK directly. ([llm_gemini.py:1-8](app/providers/llm_gemini.py#L1))

```python
@register_provider
class GeminiProvider(LlmProvider):
    name  = "gemini"
    model = os.getenv("GEMINI_MODEL", "gemini-3.1-flash-lite")
```
([llm_gemini.py:127-143](app/providers/llm_gemini.py#L127))

Its headline feature is **schema-constrained output**: `response_schema=LlmReply` makes Gemini's decoder reject any token that would produce a non-matching JSON, dropping `bad_json` failures to ~0% for < 10 ms cost. ([llm_gemini.py:129-140](app/providers/llm_gemini.py#L129), [llm_gemini.py:402-415](app/providers/llm_gemini.py#L402))

### 5.1 Client singleton & httpx workaround

The `genai.Client` is cached at module scope, keyed on the API key so a `.env` hot-reload re-inits ([llm_gemini.py:88-124](app/providers/llm_gemini.py#L88)):

```python
_CLIENT: genai.Client | None = None
_CLIENT_KEY: str = ""
_HTTPX_TIMEOUT_S = 60.0
```

`_client_singleton()` FORCES an httpx async transport via `http_options.httpx_async_client` to bypass a **google-genai 2.6.0 aiohttp bug**: the SDK's SSE reader calls `aiohttp.StreamReader.readline(max_line_length=…)`, a kwarg modern aiohttp's `readline` doesn't accept (`TypeError`). Passing an httpx client makes the SDK's `_use_aiohttp()` return `False` and take its working httpx line-iterator path. ([llm_gemini.py:100-124](app/providers/llm_gemini.py#L100))

The httpx transport timeout is `60.0` s — deliberately well above the app's own per-call bound (`LLM_HARD_TIMEOUT_S` enforced via `asyncio.wait_for`), so the *app's* timeout fires first; the 60 s is just a hung-socket backstop. (httpx defaults to 5 s, which would abort legitimate 10-16 s multimodal calls.) ([llm_gemini.py:92-97](app/providers/llm_gemini.py#L92)) The same client is reused by Gemini TTS (`tts_gemini`). `__init__` simply grabs `self._client = _client_singleton()`. ([llm_gemini.py:145-146](app/providers/llm_gemini.py#L145))

### 5.2 `GeminiProvider.call()` — control flow & retries

Signature ([llm_gemini.py:186-197](app/providers/llm_gemini.py#L186)): `call(system_prompt, history_text, images: list[bytes], audio_bytes, *, thinking_budget=None, max_output_tokens=None, hard_timeout_s=None, image_refs=None)`.

Step-by-step:

1. **Bootstrap telemetry**, resolve per-call overrides ([llm_gemini.py:198-216](app/providers/llm_gemini.py#L198)):
   - `effective_thinking_budget = thinking_budget if not None else settings.GEMINI_THINKING_BUDGET`
   - `effective_max_output_tokens = max_output_tokens if not None else LLM_MAX_OUTPUT_TOKENS`
   - `eff_timeout = hard_timeout_s if not None else LLM_HARD_TIMEOUT_S`
   - `allow_retry = hard_timeout_s is None` — **a custom timeout means a single attempt** (no fresh-retry), so the bounded window stays under the firmware watchdog.
2. **No client → immediate error fallback** with `status="error"`, `error="GEMINI_API_KEY not configured"`. ([llm_gemini.py:218-222](app/providers/llm_gemini.py#L218))
3. **Outer retry loop** `for attempt in range(_OUTER_RETRY_MAX + 1)` (= 1 initial + up to 2 retries) ([llm_gemini.py:231-302](app/providers/llm_gemini.py#L231)):
   - Calls `await asyncio.wait_for(self._drain(...), timeout=eff_timeout)`; on success, `break`.
   - **`asyncio.TimeoutError`** (a stall, usually `ttft=None` — a pre-generation queue/upload stall): if `allow_retry and attempt < _TIMEOUT_RETRY_MAX` (=1), retry once on a fresh request; else set `status="timeout"` and return `fallback_for_status("timeout")`. ([llm_gemini.py:239-255](app/providers/llm_gemini.py#L239))
   - **`asyncio.CancelledError`** (FRAME_CANCEL) → re-raise; caller cleans up; ship no further frames. ([llm_gemini.py:256-258](app/providers/llm_gemini.py#L256))
   - **Other `Exception`**: classify via `_extract_http_status(e)` → `code`; `status_transient = code in _TRANSIENT_STATUS_CODES`; `network_err = code is None and _is_network_error(e)`. Compute `retry_budget`:
     ```python
     retry_budget = (
         0 if not allow_retry
         else _NETWORK_RETRY_MAX if network_err          # = 1
         else _OUTER_RETRY_MAX if status_transient        # = 2
         else 0
     )
     ```
     ([llm_gemini.py:259-272](app/providers/llm_gemini.py#L259)) If `attempt < retry_budget`, sleep `_OUTER_RETRY_BASE_S * (2 ** attempt)` (0.6 s, then 1.2 s) and `continue`. ([llm_gemini.py:273-283](app/providers/llm_gemini.py#L273)) Otherwise classify the final status: `429 → "rate_limited"`; transient-or-network → `"upstream_unavailable"`; else `"error"`. Transient/network logged at WARNING (no traceback); real bugs logged via `log.exception`. Returns `fallback_for_status(status)`. ([llm_gemini.py:284-302](app/providers/llm_gemini.py#L284))
4. **Post-success**: set `raw_chars`, `total_ms`. If `not buffer.strip()` → `status="safety_block"`, return `FALLBACK_REPLY`. Else `return _parse_or_fallback(buffer, telemetry)`. ([llm_gemini.py:304-312](app/providers/llm_gemini.py#L304))

Retry constants ([llm_gemini.py:38-58](app/providers/llm_gemini.py#L38)):

| Constant | Value | Applies to |
|---|---|---|
| `_TRANSIENT_STATUS_CODES` | `{429, 500, 502, 503, 504}` | server-side transient errors |
| `_OUTER_RETRY_MAX` | `2` | 5xx/429 retries on top of the SDK's tenacity |
| `_OUTER_RETRY_BASE_S` | `0.6` | backoff base → 0.6 s, 1.2 s |
| `_NETWORK_RETRY_MAX` | `1` | transport drops (no HTTP status) — tighter because each retry re-bills the call |
| `_TIMEOUT_RETRY_MAX` | `1` | hard-timeout stalls — one fresh request usually escapes the stuck slot |
| `_FILES_PREUPLOAD_TIMEOUT_S` | `8.0` | Files-API pre-upload bound |

### 5.3 `_drain()` — building multimodal contents

`_drain(system_prompt, history_text, images, audio_bytes, telemetry, image_refs=None)` builds the `contents` list and calls Gemini ([llm_gemini.py:314-419](app/providers/llm_gemini.py#L314)):

1. **History part first**: `types.Part.from_text(text=history_text or "[Session start — no prior turns]")`. (google-genai v1+ requires keyword args.) ([llm_gemini.py:341-343](app/providers/llm_gemini.py#L341))
2. **One image Part per JPEG, in capture order** (multi-image support). For each image `i`: if a pre-uploaded Files ref with a `.uri` exists (aligned 1:1 with `images`), send `types.Part.from_uri(file_uri=uri, mime_type="image/jpeg")` (tiny URI, ~250-400 ms less upload); else inline `types.Part.from_bytes(data=img, mime_type="image/jpeg")`. ([llm_gemini.py:344-362](app/providers/llm_gemini.py#L344))
3. **Audio**: raw PCM is wrapped as WAV via `wrap_pcm_as_wav(audio_bytes)` (44-byte RIFF header) because `generateContent` only accepts audio inside a container (wav/mp3/aiff/aac/ogg/flac); raw `audio/pcm` is a Multimodal-Live-only MIME type that 400s here. Appended as `types.Part.from_bytes(data=wav_audio, mime_type="audio/wav")`. ([llm_gemini.py:363-371](app/providers/llm_gemini.py#L363))
4. **Thinking config**: `gemini_thinking_config(self.model, telemetry["thinking_budget"])` — emits `thinkingBudget` for 2.5, `thinking_level` for 3.x. ([llm_gemini.py:378-383](app/providers/llm_gemini.py#L378))
5. **Code-execution tool**: only attached when `settings.GEMINI_TIER3_CODE_EXECUTION and not audio_bytes` AND `gemini_code_execution_tool(self.model)` returns non-`None` (Gemini-3.x Pro). The audio gate is enforced here. ([llm_gemini.py:396-400](app/providers/llm_gemini.py#L396))
6. **Build `GenerateContentConfig`** with `system_instruction=system_prompt`, `response_mime_type="application/json"`, `response_schema=LlmReply`, `max_output_tokens=telemetry["max_output_tokens"]`, `temperature=settings.GEMINI_TEMPERATURE`, `thinking_config`, `tools`. ([llm_gemini.py:402-415](app/providers/llm_gemini.py#L402))
7. **Dispatch**: `if settings.GEMINI_USE_STREAM` → `_drain_stream`, else `_drain_unary` (the DEFAULT). ([llm_gemini.py:417-419](app/providers/llm_gemini.py#L417))

### 5.4 `_drain_unary` vs `_drain_stream`

**`_drain_unary`** (the default) — one HTTP request, one response object ([llm_gemini.py:421-498](app/providers/llm_gemini.py#L421)):

- Calls `self._client.aio.models.generate_content(...)`.
- **Safety block check** on `response.prompt_feedback.block_reason` → log WARN, set `ttft_ms`, return `""` (which the caller turns into `safety_block`). ([llm_gemini.py:433-438](app/providers/llm_gemini.py#L433))
- Pulls `finish_reason` from `candidates[0]`, and usage from `usage_metadata`: `prompt_token_count`, `candidates_token_count`, `total_token_count`, `thoughts_token_count` → telemetry `llm_input_tok` / `llm_output_tok` / `llm_thinking_tok`. ([llm_gemini.py:443-460](app/providers/llm_gemini.py#L443))
- Detects whether the code-exec sandbox actually ran (scans candidate parts for `executable_code` / `code_execution_result`) → `telemetry["code_exec"]`. ([llm_gemini.py:468-479](app/providers/llm_gemini.py#L468))
- Logs `[GEMINI] finish=… input=… thinking=… output=… total=… text_chars=… code_exec=… tool_tok=…`. ([llm_gemini.py:481-486](app/providers/llm_gemini.py#L481))
- Loud WARN if `finish_reason` contains `MAX_TOKENS` (our cap was the limiter). ([llm_gemini.py:490-496](app/providers/llm_gemini.py#L490))

**`_drain_stream`** (kept for when google-genai/aiohttp coexist cleanly AND sentence-level TTS lands) — `generate_content_stream(...)`, records true TTFT on the first non-empty chunk, handles per-chunk `prompt_feedback`, accumulates `buffer`. Currently disabled by default because of the aiohttp `readline` bug. ([llm_gemini.py:500-520](app/providers/llm_gemini.py#L500), [llm_gemini.py:324-337](app/providers/llm_gemini.py#L324))

### 5.5 `preupload_image()` — Files API latency hook

The only provider that overrides `preupload_image` ([llm_gemini.py:148-184](app/providers/llm_gemini.py#L148)):

- Uploads one JPEG to the Gemini Files API via `self._client.aio.files.upload(...)`, bounded by `asyncio.wait_for(..., _FILES_PREUPLOAD_TIMEOUT_S=8.0)`.
- Runs *while the user is still speaking* (kicked off by `app/services/image_prep.py` when the IMAGE_JPEG terminator lands), removing the ~250-400 ms upload from the critical path. The later `call()` sends the file URI instead of inline base64. An escalated tier-2/3 re-call reuses the same ref (no second upload).
- Files API storage is FREE (20 GB cap, 48 h auto-expiry); referencing bills the same image tokens as inline bytes.
- Returns `None` on any failure or non-`ACTIVE` state (a `PROCESSING`/`FAILED` ref would 400 the generate call) → the caller falls back to inline bytes. **Can never break a turn.**

### 5.6 Error classification helpers

- **`_is_network_error(exc)`** — walks the `__cause__`/`__context__` chain (with a `seen` set to avoid cycles) looking for `httpx.TransportError` (the base of NetworkError/Timeout/ProtocolError). True ⇒ a flaky-network failure that retrying recovers; an HTTP 4xx/5xx is NOT one (handled by the status-code path). ([llm_gemini.py:69-82](app/providers/llm_gemini.py#L69))
- **`_extract_http_status(exc)`** — tries `.code` then `.status_code` (int), else scrapes a leading numeric token from the message (e.g. `"503 UNAVAILABLE."`). Returns `None` when not classifiable. ([llm_gemini.py:524-545](app/providers/llm_gemini.py#L524))

### 5.7 `_parse_or_fallback` — the shared JSON parser

`_parse_or_fallback(buffer, telemetry)` is **imported and reused by every other provider**. ([llm_gemini.py:570-618](app/providers/llm_gemini.py#L570)) Logic:

1. Try strict `LlmReply.model_validate_json(buffer)` → success returns `(reply, telemetry)`.
2. On failure, try lenient `LlmReply.model_validate(json.loads(buffer))`.
3. On failure, run **`_strip_json_noise(buffer)`** — drops ```` ```json ```` fences / prose preamble and slices to the outermost `{...}` ([llm_gemini.py:549-566](app/providers/llm_gemini.py#L549)) — and re-validate the repaired string (only if it differs). This is a no-op for clean Gemini output but recovers Claude/DeepSeek/OpenAI replies that wrap the object.
4. **Truncation heuristic**: if the buffer `startswith("{")` (well-formed prefix) but `count("{") > count("}")` (unbalanced braces), the model ran out of output tokens mid-stream → `status="truncated"`. Otherwise → `status="bad_json"` (records both strict & lenient exception types). Returns `fallback_for_status(status)`. ([llm_gemini.py:594-618](app/providers/llm_gemini.py#L594))

This distinction matters operationally: `truncated` ⇒ raise `LLM_MAX_OUTPUT_TOKENS` or tighten the prompt's brevity cap; `bad_json` ⇒ the model emitted genuinely invalid JSON.

### 5.8 Back-compat wrappers

For legacy call sites ([llm_gemini.py:621-666](app/providers/llm_gemini.py#L621)):

- `_as_image_list(image_arg)` — normalises a single `bytes`/`None` into the list-of-images shape.
- `call_multimodal_stream(...)` (DEPRECATED), `collect_llm_response(stream)` (DEPRECATED), `collect_with_telemetry(...)` (DEPRECATED) — all wrap the new class API.

---

## 6. OpenAI provider — `llm_openai.py`

A **stub** (skeleton compiles) for GPT-4o, *"the closest multimodal alternative to Gemini Flash"* — audio + image + JSON output. ([llm_openai.py:1-15](app/providers/llm_openai.py#L1))

```python
@register_provider
class OpenAIProvider(LlmProvider):
    name  = "openai"
    model = os.getenv("OPENAI_MODEL", "gpt-4o")
```
([llm_openai.py:37-42](app/providers/llm_openai.py#L37))

- **`__init__`**: reads `OPENAI_API_KEY`; if present, lazily imports `from openai import AsyncOpenAI` and builds the client. An `ImportError` (SDK not installed) → disabled (`self._available = False`). ([llm_openai.py:44-56](app/providers/llm_openai.py#L44))
- **`call(system_prompt, history_text, image_bytes, audio_bytes)`** — note the singular `image_bytes` (does NOT match the orchestrator's `images=[...]` call site). No `*` keyword params. ([llm_openai.py:58-64](app/providers/llm_openai.py#L58)) Flow: not-available → `error` fallback; else `await asyncio.wait_for(self._chat(...), timeout=LLM_HARD_TIMEOUT_S)`; `TimeoutError` → `status="timeout"`; `CancelledError` → re-raise; other → `status="error"`; empty buffer → `status="safety_block"`; else `_parse_or_fallback`. ([llm_openai.py:65-100](app/providers/llm_openai.py#L65))
- **`_chat`** builds the content array text → image → audio ([llm_openai.py:102-143](app/providers/llm_openai.py#L102)):
  - text part: `history_text or "[Session start]"`.
  - image: base64 `data:image/jpeg;base64,...` via `image_url`.
  - audio: `input_audio` with `format="pcm16"` (GPT-4o-audio-preview accepts base64 PCM); a comment notes non-audio variants need upstream Whisper STT.
  - Streaming `chat.completions.create(..., response_format={"type": "json_object"}, max_tokens=LLM_MAX_OUTPUT_TOKENS, temperature=0.7, stream=True)`. TTFT recorded on the first non-empty `delta.content`.

**Notable**: temperature is **hardcoded `0.7`** here (unlike Gemini/Claude which read settings). No retry loop, no per-call overrides, no `thinking_budget`/`hard_timeout_s` — it is a single-attempt stub. JSON correctness relies on OpenAI's `json_object` mode + `_parse_or_fallback`.

---

## 7. Claude provider — `llm_claude.py`

The Anthropic provider — *"Claude (Sonnet 4 / Opus 4) accepts text + image natively but does NOT accept raw audio bytes."* To use Claude you must run an STT step upstream (Groq Whisper) and pass the transcript as user text. ([llm_claude.py:1-17](app/providers/llm_claude.py#L1))

```python
@register_provider
class ClaudeProvider(LlmProvider):
    name  = "claude"
    model = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6")
```
([llm_claude.py:41-47](app/providers/llm_claude.py#L41))

- **`__init__`**: reads `ANTHROPIC_API_KEY`; lazily imports `anthropic` → `anthropic.AsyncAnthropic(api_key=...)`. `ImportError` → disabled. ([llm_claude.py:49-61](app/providers/llm_claude.py#L49))
- **`call(...)`** — the **drift-fixed, orchestrator-compatible** signature ([llm_claude.py:63-76](app/providers/llm_claude.py#L63)):
  ```python
  async def call(self, system_prompt, history_text, images: list[bytes], audio_bytes, *,
                 thinking_budget=None, max_output_tokens=None, hard_timeout_s=None,
                 transcript: str|None=None, image_refs: list|None=None, **_):
  ```
  - `thinking_budget` and `image_refs` are **accepted and ignored** (Claude has no thinking-budget knob; Files refs are Gemini-only); `**_` absorbs any future kwargs. ([llm_claude.py:88-92](app/providers/llm_claude.py#L88))
  - `eff_max_tokens = max_output_tokens if not None else LLM_MAX_OUTPUT_TOKENS`; `eff_timeout = hard_timeout_s if not None else LLM_HARD_TIMEOUT_S`. ([llm_claude.py:96-100](app/providers/llm_claude.py#L96))

Control flow:

1. Not available → `status="error"` fallback. ([llm_claude.py:102-106](app/providers/llm_claude.py#L102))
2. **Step 1 — resolve transcript** (Claude can't take raw audio): `text = (transcript or "").strip()`. If empty and audio present, STT inline via `asyncio.wait_for(_stt_via_groq(audio_bytes), timeout=8.0)`. A failed/slow STT degrades to no-transcript (image + history still answer) rather than failing loud. ([llm_claude.py:108-119](app/providers/llm_claude.py#L108)) Building `user_text`: `f"{history_text}\n\nLearner said: {text!r}"` if a transcript exists, else just `history_text`. ([llm_claude.py:121](app/providers/llm_claude.py#L121))
3. **Step 2 — build content**: `[{"type":"text","text":user_text}]` + one base64 `image` block per JPEG in `images`. ([llm_claude.py:123-135](app/providers/llm_claude.py#L123))
4. **Step 3 — call** `asyncio.wait_for(self._chat(...), timeout=eff_timeout)`. `TimeoutError` → `status="timeout"`; `CancelledError` → re-raise; other → `status="error"` (with `log.exception`). Then `raw_chars`, `total_ms`, and `_parse_or_fallback(buffer, telemetry)`. **Never raises** out of `call()`. ([llm_claude.py:137-158](app/providers/llm_claude.py#L137))

**`_chat`** ([llm_claude.py:160-187](app/providers/llm_claude.py#L160)): Claude has no JSON-mode flag, so it appends `"\n\nIMPORTANT: respond with ONLY the raw JSON, no prose."` to the system prompt and trusts the model (Pydantic catches drift). Uses `self._client.messages.stream(model=self.model, max_tokens=max_tokens, system=..., messages=[{"role":"user","content":content}], temperature=settings.CLAUDE_TEMPERATURE)`. TTFT recorded on the first `piece` from `stream.text_stream`. Best-effort usage capture via `stream.get_final_message().usage` → `telemetry["llm_input_tok"]` / `llm_output_tok`.

**`temperature=settings.CLAUDE_TEMPERATURE`** (default `0.3`) — deliberately separate from `GEMINI_TEMPERATURE` because the scales differ: Gemini accepts 0.0-2.0, Claude only 0.0-1.0. ([llm_claude.py:169](app/providers/llm_claude.py#L169), [config.py:428-438](app/config.py#L428))

**`_stt_via_groq(audio_bytes)`** (module-level; reused by DeepSeek) ([llm_claude.py:191-224](app/providers/llm_claude.py#L191)):

- Wraps raw 16 kHz mono int16-LE PCM as an in-memory WAV (`wave` stdlib; channels=1, sampwidth=2, framerate=16000) with `buf.name = "command.wav"`.
- Imports `from groq import AsyncGroq`; requires `GROQ_API_KEY` (raises `RuntimeError` if missing).
- **Client lifecycle (fixed 2026-07-04):** the client is now opened via `async with AsyncGroq(api_key=api_key) as client:` ([llm_claude.py:218-223](app/providers/llm_claude.py#L218)) rather than a bare `AsyncGroq(...)` — previously the underlying httpx connection pool (TCP sockets + file descriptors) was never closed. This helper runs on the **pre-router STT path of every turn**, so the leak was per-turn, not rare; on a long-lived process it would exhaust sockets / leak memory.
- Calls `client.audio.transcriptions.create(model="whisper-large-v3-turbo", file=buf, response_format="text")` and returns the string. *"~150-200 ms for a 3 s clip. Cheapest fast STT today."*

---

## 8. DeepSeek provider — `llm_deepseek.py`

A **stub** for `deepseek-chat` / `deepseek-reasoner` — text only, no native audio or image. ([llm_deepseek.py:1-20](app/providers/llm_deepseek.py#L1))

```python
@register_provider
class DeepSeekProvider(LlmProvider):
    name  = "deepseek"
    model = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")
```
([llm_deepseek.py:42-47](app/providers/llm_deepseek.py#L42))

- **`__init__`**: reads `DEEPSEEK_API_KEY`; DeepSeek serves an **OpenAI-compatible API**, so it builds `AsyncOpenAI(api_key=..., base_url=os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com"))`. `ImportError` → disabled. ([llm_deepseek.py:49-65](app/providers/llm_deepseek.py#L49))
- **`call(system_prompt, history_text, image_bytes, audio_bytes)`** — singular `image_bytes`, no keyword overrides (same drift as OpenAI). ([llm_deepseek.py:67-73](app/providers/llm_deepseek.py#L67)) Flow:
  1. Not available → `error` fallback.
  2. **STT upstream** via `_stt_via_groq(audio_bytes)` (reused from `llm_claude`); any exception → `status="error"`, `error="STT failed: ..."`. ([llm_deepseek.py:82-89](app/providers/llm_deepseek.py#L82))
  3. **Image is not visible to DeepSeek** — if `image_bytes` present, it appends a flag `"[NOTE: A desk image was provided but DeepSeek can't see it. Answer based on the spoken query alone.]"`. A real captioner (BLIP / Gemini Flash) is a TODO. ([llm_deepseek.py:91-98](app/providers/llm_deepseek.py#L91))
  4. `user_text = f"{history_text}\n\nLearner said: {transcript!r}{image_hint}"`.
  5. `asyncio.wait_for(self._chat(...), timeout=LLM_HARD_TIMEOUT_S)`; timeout/cancel/error handling identical to OpenAI; then `_parse_or_fallback`. ([llm_deepseek.py:100-121](app/providers/llm_deepseek.py#L100))
- **`_chat`** ([llm_deepseek.py:123-142](app/providers/llm_deepseek.py#L123)): streaming `chat.completions.create(model=self.model, messages=[system, user], response_format={"type":"json_object"}, max_tokens=LLM_MAX_OUTPUT_TOKENS, temperature=0.7, stream=True)`. TTFT on first `delta.content`. Temperature hardcoded `0.7`.

---

## 9. The web brain — `gemini_brain.py`

A **separate** Gemini multimodal path for the browser bench (`/api/frontend/simulate` + `/api/frontend/ws`). It is intentionally distinct from the lamp's orchestrator/`llm_gemini` because the web renders LaTeX with **KaTeX** (full LaTeX, aligned envs) while the lamp uses a matplotlib mathtext subset. It collapses STT + reasoning into one multimodal call (Gemini takes raw audio, no separate transcription). ([gemini_brain.py:1-12](app/providers/gemini_brain.py#L1))

**Module state & retry policy** ([gemini_brain.py:29-46](app/providers/gemini_brain.py#L29)):

```python
_client = None
_TRANSIENT_STATUS = {429, 500, 502, 503, 504}
_SIM_RETRIES = 2
_SIM_BACKOFF_S = 0.8
```

- `_status_code(exc)` — pulls an HTTP status from a google-genai error (`.code`/`.status_code`, else a leading numeric token). ([gemini_brain.py:38-46](app/providers/gemini_brain.py#L38))
- `available()` → `bool(settings.GEMINI_API_KEY)`. ([gemini_brain.py:49-50](app/providers/gemini_brain.py#L49))
- `_get_client()` — lazily builds `genai.Client(api_key=settings.GEMINI_API_KEY)` (note: **plain client, not the httpx-forced singleton** that `llm_gemini` uses). ([gemini_brain.py:53-58](app/providers/gemini_brain.py#L53))

**`_system_prompt(profile)`** ([gemini_brain.py:61-230](app/providers/gemini_brain.py#L61)) — the large "Lumos" tutor prompt for JEE/NEET aspirants, with sections: WHO YOU ARE, HOW YOU TALK (speech vs screen channels), FOCUS (multi-question pages — answer ONLY the target, pointer/occlusion handling), WHAT TO ANSWER (driven by `query_type` with per-type voice word caps: mistake_id ≤35, check ≤35, formula ≤25, definition ≤15, calc ≤45, derivation ≤45, concept ≤45, other ≤20), the SOCRATIC GATE (GUIDANCE-by-default vs SOLVE mode entered only via a `[SOLVE AUTHORIZED]` note or an explicit surrender after ≥1 hint), HOW DEEP, VERIFY YOUR OWN MATH, and CHECKING THE STUDENT'S WORK (verify-before-accuse). If a `profile` is given it appends a "Student profile" block built from `target_exam`, `prep_duration`, `full_name`, and `extra` keys (`learning_style`, `explain_depth`, `study_rhythm`, `focus_subject`, `strong_subject`, `weak_subject`).

**`_build_parts(user_text, audio_wav, images)`** ([gemini_brain.py:233-257](app/providers/gemini_brain.py#L233)) — images first (one `Part.from_bytes` per JPEG in capture order), then audio (`audio/wav`) followed by a literal text part `"(The student just asked the above out loud. Answer them.)"`, then user text; falls back to `"(no input)"` if empty.

**`respond(...)`** ([gemini_brain.py:260-304](app/providers/gemini_brain.py#L260)) — the *streaming* path. Yields a `BrainEvent` timeline: `state=THINKING`, then per text chunk `state=SPEAKING` (once) + `text` events, then `text_end` + `state=IDLE`. If nothing was produced, yields a graceful "I couldn't make that out…" line. Uses `client.aio.models.generate_content_stream(model=settings.GEMINI_MODEL, ...)`.

**The structured one-shot path** (the primary bench API):

- `SimResponse` (Pydantic) — the web's parallel to `LlmReply` ([gemini_brain.py:319-412](app/providers/gemini_brain.py#L319)). Fields: `speech`, `display: Display{type: "latex"|"text"|"none", latex, text}`, `confidence` (default 0.8, `ge=0, le=1`; *"Below 0.7 → hedge"*; also drives the bench's two-tier escalation), `query_type`, `subject`, `difficulty`, `user_input`, `problem_statement`, `solution_outline`, `same_problem`, `student_stuck`, `student_disputes_prior`, `image_needed`, `ocr_text`, `bounding_box`. The docstrings note this is an *"identical contract to the lamp's LlmReply"* so one schema/dashboard covers both surfaces.
- `_STRUCTURED_SUFFIX` ([gemini_brain.py:415-468](app/providers/gemini_brain.py#L415)) — the "YOUR REPLY FORMAT (browser bench)" instructions: speech vs display complement-never-repeat, KaTeX rules, graphs/plots warning (KaTeX can't draw graphs → describe in speech, equation in latex), and the ocr_text/bounding_box audit instructions.
- `build_system_prompt(profile, extra_instruction="")` ([gemini_brain.py:471-482](app/providers/gemini_brain.py#L471)) — assembles `_system_prompt(profile) + _STRUCTURED_SUFFIX + extra_instruction`, plus a `PERCEIVED_QUESTION_SUFFIX` when `settings.DEBUG_PERCEIVED_QUESTION or settings.MEMO_CAPTURE_QUESTION`. Exposed so the trace layer can persist exactly what the model was primed with.

**`simulate(...)`** ([gemini_brain.py:485-523](app/providers/gemini_brain.py#L485)) — back-compat wrapper returning only the `SimResponse`. **`simulate_with_usage(...)`** ([gemini_brain.py:526-687](app/providers/gemini_brain.py#L526)) is the workhorse:

1. Build parts (legacy `image_jpeg` folded into `[image_jpeg]`; `images` wins if both given). ([gemini_brain.py:549-552](app/providers/gemini_brain.py#L549))
2. If `history_text` is present and not "no prior turns", inject a **CONTINUATION hint**: it tries `from app.services.escalation_router import CONTINUATION_HINT, is_followup_text` and, if `is_followup_text(user_text)`, prepends `CONTINUATION_HINT`; then inserts a large `[Conversation so far…]` background-only framing part (with the FRESH-vs-CONTINUATION rules and the `same_problem` breadcrumb obedience instructions). ([gemini_brain.py:553-593](app/providers/gemini_brain.py#L553))
3. Build `cfg_kwargs`: `system_instruction=build_system_prompt(profile, extra_instruction)`, `response_mime_type="application/json"`, `response_schema=SimResponse`. ([gemini_brain.py:594-603](app/providers/gemini_brain.py#L594))
4. If `thinking_budget is not None`, attach `gemini_thinking_config(model or settings.GEMINI_MODEL, thinking_budget)` (2.5→budget, 3.x→level). ([gemini_brain.py:604-611](app/providers/gemini_brain.py#L604))
5. If `max_output_tokens is not None`, set it. ([gemini_brain.py:612-613](app/providers/gemini_brain.py#L612))
6. Code-execution tool: `if settings.GEMINI_TIER3_CODE_EXECUTION and not audio_wav` → `gemini_code_execution_tool(model or settings.GEMINI_MODEL)` (same audio gate as the lamp). ([gemini_brain.py:622-626](app/providers/gemini_brain.py#L622))
7. **Retry loop** `for attempt in range(_SIM_RETRIES + 1)`: call `client.aio.models.generate_content(...)`; on exception with a status in `_TRANSIENT_STATUS` and `attempt < _SIM_RETRIES`, sleep `_SIM_BACKOFF_S * (2 ** attempt)` (0.8 s, 1.6 s) and retry; else re-raise. ([gemini_brain.py:629-648](app/providers/gemini_brain.py#L629))
8. `_extract_usage(resp)` → `{input_tokens, output_tokens, total_tokens, thinking_tokens}` from `usage_metadata` (best-effort, `None` when absent). ([gemini_brain.py:720-728](app/providers/gemini_brain.py#L720))
9. Code-exec visibility logging when tools were attached. ([gemini_brain.py:656-669](app/providers/gemini_brain.py#L656))
10. **Parse**: prefer `resp.parsed` (a `SimResponse`); else `SimResponse.model_validate(json.loads(resp.text or "{}"))`; else `_salvage_sim(resp.text or "")`. ([gemini_brain.py:671-687](app/providers/gemini_brain.py#L671))

**`_salvage_sim(raw)`** ([gemini_brain.py:690-717](app/providers/gemini_brain.py#L690)) — a truncated/garbled structured reply must NEVER reach the user as raw JSON (observed live: a MAX_TOKENS-cut reply dumped the whole blob into the spoken answer). It regex-extracts the `"speech"` string (the first field the model writes, so it usually survives the cut), un-escapes it, and returns a `SimResponse(speech=speech[:2000], display=Display(type="none"), confidence=0.25)`. **`confidence=0.25` is deliberate**: a truncated reply is a maximal failure signal, and `0.25 ≤ 0.30` makes the escalation gate send the turn to Pro (mirroring the lamp's `status=truncated → tier-3` rule). If even speech extraction fails, a clean apology with `confidence=0.25`.

---

## 10. Grounding / search — `grounding.py`

`grounding.py` is a **mock / placeholder** for Google Search Grounding (intended for UPSC/SSC current-affairs). The entire module ([grounding.py:1-13](app/providers/grounding.py#L1)):

```python
class GoogleSearchGrounder:
    def __init__(self):
        pass

    async def get_grounding_context(self, query: str) -> str:
        """
        Mock implementation of Google Search Grounding.
        In reality, calls the Vertex AI Search or Google Search API to get recent context.
        """
        return "MOCK_GROUNDING: Data based on recent search results up to 2026."
```

**It is not wired into any active code path.** A repo-wide search shows `GoogleSearchGrounder` / `get_grounding_context` are referenced only in this file. The notion of grounding survives elsewhere as a *prompt-level* `needs_grounding` flag in `app/prompts/classifier.py` and `app/prompts/conceptual_module.py` (UPSC Current Affairs → "use grounding data if available, else flag [VERIFY]"), but those classifier prompts live under `app/prompts/_unused/` for the active versions — i.e. real web-search grounding is **planned but unimplemented**.

> **Important distinction:** the heavily-used "grounding" in this codebase is **visual grounding** — the `ocr_text` / `bounding_box` audit fields on `LlmReply`/`SimResponse` that record *which* region of an image the model answered and *where*. That is a fully-wired feature (see [llm_response.py:226-252](app/schemas/llm_response.py#L226) and `gemini_brain`'s `_STRUCTURED_SUFFIX`), and is unrelated to the `GoogleSearchGrounder` web-search stub.

---

## 11. The Claude timeout-fallback strategy

The product end-goal: **the student must NEVER hear "the model took too long."** ([CLAUDE_FALLBACK_GUIDE.md:1-9](CLAUDE_FALLBACK_GUIDE.md#L1)) When Gemini fails at any tier, the orchestrator immediately re-runs the SAME turn on Claude and speaks Claude's answer. Claude is used ONLY on a Gemini failure; a normal successful turn never touches Claude. ([CLAUDE_FALLBACK_GUIDE.md:0-12](CLAUDE_FALLBACK_GUIDE.md#L1))

### 11.1 Why parity is automatic, not rebuilt

Before calling a tier, the orchestrator has already assembled `system_prompt` (base prompt + pre-router suffixes + memo answer-key + dispute note + SOLVE_SUFFIX at tier≥2 + always-on guards), `history_text` (L1 recent · L2 summary · L3 profile), `preroute_text` (the Groq Whisper transcript), and `images`/`audio`. The fallback re-runs Claude with these SAME variables, so every prompt-level guard, the memo, the history, the dispute note, and the question-inference instructions are all present in Claude's call — *"Parity is structural. You do not rebuild a single guard — you reuse the prompt."* ([CLAUDE_FALLBACK_GUIDE.md:34-59](CLAUDE_FALLBACK_GUIDE.md#L34)) Post-reply guards (echo / solution-bleed / reveal / focus) inspect the returned `LlmReply` and are provider-agnostic.

### 11.2 The trigger set — the live code vs the guide

The guide documents the trigger set as ([CLAUDE_FALLBACK_GUIDE.md:66-67](CLAUDE_FALLBACK_GUIDE.md#L66)):

```python
_FALLBACK_STATUSES = {"timeout", "rate_limited", "upstream_unavailable", "error"}
```

But the **live orchestrator** uses a *narrower* set that excludes `"error"`:

```python
_FALLBACK_STATUSES = {"timeout", "rate_limited", "upstream_unavailable"}
```
([orchestrator.py:1479](app/services/orchestrator.py#L1479))

The rationale is in the call-site comment: *"A Gemini SERVER failure (`_FALLBACK_STATUSES`) → re-run the SAME turn on Claude. A successful Gemini call (or a malformed/blocked answer, or a client/config `error`) never reaches this block."* ([orchestrator.py:1164-1170](app/services/orchestrator.py#L1164)) So a `bad_json` / `safety_block` (Gemini *did* answer) and a client/config `error` do **not** invoke Claude — only genuine server-side failure modes do.

### 11.3 The hook — folded into `_call_tier`

`_call_tier` is the single choke point through which the initial call, every escalation re-call, and every guard corrective re-call pass — so wrapping it covers all tiers in one place. ([CLAUDE_FALLBACK_GUIDE.md:116-142](CLAUDE_FALLBACK_GUIDE.md#L116)) The live implementation ([orchestrator.py:1126-1199](app/services/orchestrator.py#L1126)):

1. `armed = self._llm_fallback is not None`; when armed, `_to_kw = {"hard_timeout_s": LLM_HARD_TIMEOUT_S}` is passed to tiers 1 & 2 so each Gemini tier is a **single fast-fail attempt** (no self-retry, since a custom `hard_timeout_s` sets `allow_retry=False`). ([orchestrator.py:1126-1128](app/services/orchestrator.py#L1126))
2. The Gemini call is made at the chosen tier (tier≥3 uses `self._llm_pro` with `GEMINI_TIER3_THINKING_BUDGET`, `GEMINI_TIER3_TIMEOUT_S`, `GEMINI_TIER3_MAX_OUTPUT_TOK`; tier 2 / tier 1 use `self._llm` with their respective budgets and caps). ([orchestrator.py:1134-1163](app/services/orchestrator.py#L1134))
3. `if armed and telemetry.get("status") in _FALLBACK_STATUSES:` → call `self._llm_fallback.call(system_prompt=…, history_text=…, images=…, audio_bytes=…, transcript=preroute_text, max_output_tokens=tier_cap)`, set `telemetry["fallback"]=True` and `telemetry["fallback_from"]=f"gemini-tier{tier}"`. ([orchestrator.py:1171-1186](app/services/orchestrator.py#L1171))
4. **The safety net must never raise**: if Claude itself fails, the `except Exception` keeps the original Gemini failure reply/telemetry (the pre-existing dead-end path) rather than crashing the turn. `asyncio.CancelledError` is re-raised. ([orchestrator.py:1187-1198](app/services/orchestrator.py#L1187))

The fallback is built once in `__init__`, only when the primary is Gemini ([orchestrator.py:73](app/services/orchestrator.py#L73), [CLAUDE_FALLBACK_GUIDE.md:107-117](CLAUDE_FALLBACK_GUIDE.md#L107)):

```python
self._llm_fallback = None
if settings.CLAUDE_TIMEOUT_FALLBACK and self._llm.name == "gemini":
    self._llm_fallback = get_llm_provider("claude")
```

### 11.4 No double STT, no escalation after fallback

- **Transcript reuse**: passing `transcript=preroute_text` means Claude skips its own STT (the pre-router already ran Groq Whisper), keeping the Claude leg to ~2 s. ([CLAUDE_FALLBACK_GUIDE.md:159-166](CLAUDE_FALLBACK_GUIDE.md#L159), [llm_claude.py:108-119](app/providers/llm_claude.py#L108))
- **Do not escalate after a fallback** (`if telemetry.get("fallback"): break`) — Claude is used *because Gemini is down*, so climbing to Gemini Pro makes no sense. ([CLAUDE_FALLBACK_GUIDE.md:147-156](CLAUDE_FALLBACK_GUIDE.md#L147))

### 11.5 Budget — under the 45 s firmware watchdog

The lamp firmware gives up after 45 s total. The fallback keeps each Gemini tier to a single attempt so failures are fast ([CLAUDE_FALLBACK_GUIDE.md:237-258](CLAUDE_FALLBACK_GUIDE.md#L237)):

| Path | Rough time | Under 45 s? |
|---|---|---|
| tier-1 fails (single 20 s) + Claude (~2 s) | ~22 s | yes |
| tier-1 OK (5 s) → tier-2 fails (20 s) + Claude (~2 s) | ~27 s | yes |
| dispute → tier-3 Pro fails (single) + Claude (~2 s) | ~40 s | tight |

The tier-3 timeout `GEMINI_TIER3_TIMEOUT_S = 38.0` is chosen so Pro-fail + Claude + dispatch stays under the firmware's `THINKING_TIMEOUT_MS = 45 s`. ([config.py:502-509](app/config.py#L502))

### 11.6 The TFT "backup brain" indicator

When `telemetry["fallback"]` is true, `orchestrator._model_tag(telemetry)` shows `[⚡ backup brain · claude]` on the TFT text card ONLY (never in `reply.speech`), gated by `settings.TFT_SHOW_MODEL_TAG` — the student hears a normal answer; the screen quietly shows the backup brain. ([CLAUDE_FALLBACK_GUIDE.md:194-217](CLAUDE_FALLBACK_GUIDE.md#L194))

### 11.7 The two Claude modes

`CLAUDE_BRANCH_GUIDE.md` documents two modes sharing one `ClaudeProvider`:

- **Priority — timeout fallback** (`CLAUDE_TIMEOUT_FALLBACK=true`, Gemini stays primary): the §11.3 hook. ([CLAUDE_BRANCH_GUIDE.md:65-171](CLAUDE_BRANCH_GUIDE.md#L65))
- **Secondary — full swap** (`LLM_PROVIDER=claude`): every lamp turn runs Claude. Escalation is OFF for Claude — `_llm_pro` is already `None` for non-Gemini, and the escalation block is AND-gated with `self._llm.name == "gemini"`. Claude makes one primary call per turn; same-tier corrective guards still re-call Claude (they are guards, not escalation). The memo-WRITE and the check/dispute tier-bumps wait for a future Claude "Pro" (Opus) tier (§10). ([CLAUDE_BRANCH_GUIDE.md:399-469](CLAUDE_BRANCH_GUIDE.md#L399))

The two knobs compose: the fallback only builds when the primary is Gemini, so `LLM_PROVIDER=claude` makes the fallback moot. ([CLAUDE_BRANCH_GUIDE.md:233-237](CLAUDE_BRANCH_GUIDE.md#L233))

---

## 12. Configuration & environment variables

From `app/config.py::settings` (relevant keys):

| Setting | Default | Effect |
|---|---|---|
| `LLM_PROVIDER` | `"gemini"` | `Literal["gemini","openai","claude","deepseek"]` — picks the lamp provider. ([config.py:32](app/config.py#L32)) |
| `GEMINI_API_KEY` | `""` | Gemini auth; empty → `_client_singleton()` returns `None` → `status="error"`. ([config.py:34](app/config.py#L34)) |
| `GEMINI_MODEL` | `"gemini-3.1-flash-lite"` | The tier-1/2 model id. ([config.py:35](app/config.py#L35)) |
| `ANTHROPIC_MODEL` | `"claude-sonnet-4-6"` | Claude model id. ([config.py:41](app/config.py#L41)) |
| `CLAUDE_TIMEOUT_FALLBACK` | `True` | Arms the §11 fallback (only builds when primary is Gemini). ([config.py:51](app/config.py#L51)) |
| `GEMINI_USE_STREAM` | `False` | `True` → `_drain_stream`; default uses `_drain_unary`. ([config.py:389](app/config.py#L389)) |
| `GEMINI_THINKING_BUDGET` | `0` | Legacy single-tier thinking budget (provider default). ([config.py:404](app/config.py#L404)) |
| `GEMINI_TEMPERATURE` | `1.0` | Lamp Gemini sampling temperature (scale 0-2). A brief lowering to `0.4` was subsequently reverted, so the default is back to `1.0`. ([config.py](app/config.py)) |
| `CLAUDE_TEMPERATURE` | `0.3` | Claude sampling temperature (scale 0-1; separate from Gemini). ([config.py:438](app/config.py#L438)) |
| `GEMINI_DYNAMIC_THINKING` | `True` | Enables the orchestrator's tier escalation. ([config.py:440](app/config.py#L440)) |
| `GEMINI_TIER1_THINKING_BUDGET` | `0` | Fast tier — no thinking. ([config.py:441](app/config.py#L441)) |
| `GEMINI_TIER1_MAX_OUTPUT_TOK` | `1200` | Tier-1 output cap (overrides `LLM_MAX_OUTPUT_TOKENS`). ([config.py:447](app/config.py#L447)) |
| `GEMINI_TIER2_THINKING_BUDGET` | `1024` | Deep tier — maps to `thinking_level="high"` on 3.x. ([config.py:448](app/config.py#L448)) |
| `GEMINI_TIER2_MAX_OUTPUT_TOK` | `4000` | Tier-2 cap (thinking spikes eat the budget). ([config.py:465](app/config.py#L465)) |
| `GEMINI_ESCALATE_CONFIDENCE` | `0.45` | `confidence` below this → escalate. ([config.py:466](app/config.py#L466)) |
| `GEMINI_TIER3_ENABLED` | `True` | Builds `self._llm_pro` (Gemini-only). ([config.py:474](app/config.py#L474)) |
| `GEMINI_TIER3_MODEL` | `"gemini-3.1-pro-preview"` | Tier-3 Pro model id. ([config.py:475](app/config.py#L475)) |
| `GEMINI_TIER3_THINKING_BUDGET` | `512` | → `thinking_level="medium"` on 3.x (lowered from 1024 after timeouts). ([config.py:482](app/config.py#L482)) |
| `GEMINI_TIER3_MAX_OUTPUT_TOK` | `10000` | Tier-3 ceiling (thinking + JSON). ([config.py:490](app/config.py#L490)) |
| `GEMINI_TIER3_CODE_EXECUTION` | `True` | Enables the code-exec tool (gated to 3.x Pro, audio-free). ([config.py:500](app/config.py#L500)) |
| `GEMINI_TIER3_TIMEOUT_S` | `38.0` | Tier-3 Pro per-call hard timeout (≤ ~38 s to stay under the 45 s watchdog). ([config.py:510](app/config.py#L510)) |
| `MEMO_CAPTURE_QUESTION` | `False` | Appends `PERCEIVED_QUESTION_SUFFIX` (web brain). ([config.py:546](app/config.py#L546)) |
| `DEBUG_PERCEIVED_QUESTION` | `False` | Logs the model's perceived question; appends the suffix. ([config.py:733](app/config.py#L733)) |

**Env vars read directly via `os.getenv` (not in `settings`):** `LLM_PROVIDER` (in the factory), `GEMINI_MODEL`/`ANTHROPIC_MODEL`/`OPENAI_MODEL`/`DEEPSEEK_MODEL` (class-attr defaults), `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `DEEPSEEK_API_KEY`, `DEEPSEEK_BASE_URL`, `GROQ_API_KEY`, `GEMINI_API_KEY`. The Claude/DeepSeek model class attributes are read **once at class-definition time** (`model = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6")`), so changing the env after import requires a fresh process.

---

## 13. Edge cases, errors, timeouts, retries

| Scenario | Handling | Where |
|---|---|---|
| No API key | `status="error"`, immediate `FALLBACK_REPLY` (Gemini: `_client is None`; others: `not self._available`). | [llm_gemini.py:218-222](app/providers/llm_gemini.py#L218), [llm_openai.py:67-71](app/providers/llm_openai.py#L67) |
| SDK not installed | `ImportError` in `__init__` → provider disabled (`_available=False`). | [llm_claude.py:56-59](app/providers/llm_claude.py#L56) |
| Hard timeout (Gemini) | One fresh retry if `allow_retry` (custom timeout disables it), then `status="timeout"` + `_TIMEOUT_REPLY`. | [llm_gemini.py:239-255](app/providers/llm_gemini.py#L239) |
| 429 rate limit | Retry up to `_OUTER_RETRY_MAX=2` (0.6/1.2 s backoff), then `status="rate_limited"` + `_RATE_LIMITED_REPLY`. | [llm_gemini.py:259-302](app/providers/llm_gemini.py#L259) |
| 5xx (500/502/503/504) | Retry up to 2, then `status="upstream_unavailable"`. | [llm_gemini.py:284-302](app/providers/llm_gemini.py#L284) |
| TCP drop / reset (no HTTP status) | `_is_network_error` walks the cause chain; retry once (`_NETWORK_RETRY_MAX=1`), then `upstream_unavailable`. | [llm_gemini.py:69-82](app/providers/llm_gemini.py#L69) |
| Empty response buffer | `status="safety_block"` + `FALLBACK_REPLY`. | [llm_gemini.py:307-310](app/providers/llm_gemini.py#L307) |
| Gemini safety block | `prompt_feedback.block_reason` → return `""` → caller → `safety_block`. | [llm_gemini.py:433-438](app/providers/llm_gemini.py#L433) |
| Truncated JSON | Unbalanced braces after a `{` prefix → `status="truncated"` + `_TRUNCATED_REPLY`. | [llm_gemini.py:594-609](app/providers/llm_gemini.py#L594) |
| Genuinely bad JSON | After repair attempt fails → `status="bad_json"` + `FALLBACK_REPLY`. | [llm_gemini.py:610-618](app/providers/llm_gemini.py#L610) |
| Off-spec analytics fields | `_coerce_tolerant` clamps/defaults instead of discarding the reply. | [llm_response.py:254-393](app/schemas/llm_response.py#L254) |
| Claude STT fails/slow | Degrade to no-transcript (image + history still answer); bounded by `wait_for(..., 8.0)`. | [llm_claude.py:113-119](app/providers/llm_claude.py#L113) |
| DeepSeek STT fails | Hard `status="error"` (no audio = no usable input). | [llm_deepseek.py:83-89](app/providers/llm_deepseek.py#L83) |
| DeepSeek image present | Cannot see it → injects a text NOTE; answers from speech alone. | [llm_deepseek.py:91-98](app/providers/llm_deepseek.py#L91) |
| FRAME_CANCEL mid-turn | `asyncio.CancelledError` re-raised by every provider (never swallowed). | [llm_gemini.py:256-258](app/providers/llm_gemini.py#L256), [llm_claude.py:147-148](app/providers/llm_claude.py#L147) |
| Web bench transient | `simulate_with_usage` retries `_SIM_RETRIES=2` with 0.8/1.6 s backoff. | [gemini_brain.py:629-648](app/providers/gemini_brain.py#L629) |
| Web bench truncated/garbled | `_salvage_sim` extracts `speech`, returns `confidence=0.25` to force escalation. | [gemini_brain.py:690-717](app/providers/gemini_brain.py#L690) |
| Files pre-upload slow/fails | `None` (bounded 8 s) → caller uses inline bytes; never breaks a turn. | [llm_gemini.py:148-184](app/providers/llm_gemini.py#L148) |
| Claude fallback itself fails | `except Exception` keeps the Gemini failure result; never crashes the turn. | [orchestrator.py:1187-1198](app/services/orchestrator.py#L1187) |

**Provider invariant:** `call()` never raises (except `CancelledError`); every failure path returns `(reply, telemetry)`. This is what lets the orchestrator's persistence path stay simple.

---

## 14. Integration points

**Upstream — what calls this layer:**

- **`app/services/orchestrator.py`** (the lamp): builds `self._llm = get_llm_provider()` ([orchestrator.py:49](app/services/orchestrator.py#L49)), optionally `self._llm_pro` (Gemini tier-3) and `self._llm_fallback` (Claude) ([orchestrator.py:73](app/services/orchestrator.py#L73)). `_call_tier` invokes `provider.call(...)` per tier ([orchestrator.py:1136-1186](app/services/orchestrator.py#L1136)). The lamp WS entry is `app/routes/ws_lamp.py`.
- **`app/services/image_prep.py`**: calls `get_llm_provider().preupload_image(jpeg)` during the user's speech to warm the Gemini Files API. ([image_prep.py:70-73](app/services/image_prep.py#L70))
- **`app/routes/frontend_manager.py`** (the web `/api/frontend/*`): calls `gemini_brain.simulate(...)` / `simulate_with_usage(...)` / `respond(...)`. ([frontend_manager.py:729](app/routes/frontend_manager.py#L729), [frontend_manager.py:1021](app/routes/frontend_manager.py#L1021), [frontend_manager.py:1939](app/routes/frontend_manager.py#L1939))
- **`app/services/model_solver.py`** (the web bench's multi-model solver): calls `gemini_brain.simulate_with_usage(...)` and has provider branches for cost/usage. ([model_solver.py:230](app/services/model_solver.py#L230))

**Downstream — what this layer calls / depends on:**

- `app/schemas/llm_response.py` — `LlmReply`, `FALLBACK_REPLY`, `fallback_for_status`.
- `app/providers/audio_preprocessor.py` — `wrap_pcm_as_wav` (Gemini audio container). ([llm_gemini.py:24](app/providers/llm_gemini.py#L24))
- `google.genai` SDK (Gemini), `anthropic` SDK (Claude), `openai` SDK (OpenAI + DeepSeek), `groq` SDK (Claude/DeepSeek STT), `httpx` (transport).
- `app/config.py::settings`, `app/protocol.StateByte` (web brain `BrainEvent` states), `app/providers/web_simulator.BrainEvent`.
- `app/services/escalation_router` — the web brain lazily imports `CONTINUATION_HINT` / `is_followup_text`; the lamp uses it for pre-router suffixes (provider-agnostic).

**Cross-system contracts:**

- **Firmware (`tutor_lamp.ino`)**: the `THINKING_TIMEOUT_MS = 45 s` watchdog bounds the whole turn; `GEMINI_TIER3_TIMEOUT_S` and the single-attempt fallback are tuned to stay under it.
- **Database**: the analytics fields (`confidence`, `query_type`, `subject`, `difficulty`) and the visual-grounding fields (`ocr_text`, `bounding_box`) on `LlmReply` are persisted to the Postgres `turns` / `turn_traces` tables ([llm_response.py:1-11](app/schemas/llm_response.py#L1), [orchestrator.py:550](app/services/orchestrator.py#L550)).
- **Frontend (Next.js)**: consumes `SimResponse` from the web bench (KaTeX rendering of `display.latex`).

---

## 15. Diagrams

### 15.1 Lamp turn — provider call, retries, and Claude fallback

```mermaid
flowchart TD
    A[orchestrator._call_tier] --> B{tier?}
    B -->|tier>=3| C[self._llm_pro.call<br/>GEMINI_TIER3_* + hard_timeout_s=38s]
    B -->|tier 2| D[self._llm.call<br/>budget 512, cap 4000]
    B -->|tier 1| E[self._llm.call<br/>budget 0, cap 900]
    C --> F[GeminiProvider.call]
    D --> F
    E --> F
    F --> G{client?}
    G -->|no| H[status=error<br/>FALLBACK_REPLY]
    G -->|yes| I[outer retry loop<br/>max 1+2 attempts]
    I --> J["await wait_for(_drain, eff_timeout)"]
    J -->|TimeoutError| K{allow_retry<br/>& attempt<1?}
    K -->|yes| I
    K -->|no| L[status=timeout]
    J -->|429/5xx| M{attempt<br/>< retry_budget?}
    M -->|yes| I
    M -->|no| N[rate_limited /<br/>upstream_unavailable]
    J -->|CancelledError| O[re-raise]
    J -->|success| P{buffer empty?}
    P -->|yes| Q[status=safety_block]
    P -->|no| R[_parse_or_fallback]
    R --> S{valid JSON?}
    S -->|yes| T[LlmReply, status=ok]
    S -->|truncated| U[status=truncated]
    S -->|bad| V[status=bad_json]
    L --> W{armed &<br/>status in _FALLBACK_STATUSES?}
    N --> W
    Q --> W
    T --> W
    U --> W
    V --> W
    W -->|yes| X[self._llm_fallback.call<br/>SAME prompt+history,<br/>transcript=preroute_text]
    W -->|no| Z[return reply, telemetry]
    X --> Y[telemetry.fallback=True]
    Y --> Z
```

### 15.2 `_drain` → Gemini multimodal request assembly

```mermaid
sequenceDiagram
    participant Call as call()
    participant Drain as _drain()
    participant Shim as llm_base shims
    participant Gem as genai.Client
    Call->>Drain: system_prompt, history, images, audio, image_refs
    Drain->>Drain: Part.from_text(history or "[Session start]")
    loop each image
        alt Files ref has .uri
            Drain->>Drain: Part.from_uri(file_uri)
        else inline
            Drain->>Drain: Part.from_bytes(jpeg)
        end
    end
    opt audio present
        Drain->>Drain: wrap_pcm_as_wav -> Part.from_bytes(audio/wav)
    end
    Drain->>Shim: gemini_thinking_config(model, budget)
    Shim-->>Drain: ThinkingConfig (2.5 budget / 3.x level)
    opt code-exec enabled AND no audio
        Drain->>Shim: gemini_code_execution_tool(model)
        Shim-->>Drain: Tool or None (3.x Pro only)
    end
    Drain->>Gem: generate_content(config: schema=LlmReply, JSON mime)
    Gem-->>Drain: response (text + usage_metadata + finish_reason)
    Drain-->>Call: buffer string
```

---

## 16. Capability matrix & model-id summary

From the base-module docstring and each provider's class attribute ([llm_base.py:9-13](app/providers/llm_base.py#L9)):

| Provider (`name`) | Default model id (env override) | Audio | Image | Text | Status | File |
|---|---|---|---|---|---|---|
| `gemini` | `gemini-3.1-flash-lite` (`GEMINI_MODEL`) | native | native (multi + Files API) | yes | **reference, fully implemented** | [llm_gemini.py:143](app/providers/llm_gemini.py#L143) |
| `openai` | `gpt-4o` (`OPENAI_MODEL`) | `input_audio` pcm16 | base64 data URL | JSON mode | stub (skeleton) | [llm_openai.py:42](app/providers/llm_openai.py#L42) |
| `claude` | `claude-sonnet-4-6` (`ANTHROPIC_MODEL`) | NO — Groq Whisper STT upstream | base64 (multi) | yes | functional (fallback brain + full swap) | [llm_claude.py:47](app/providers/llm_claude.py#L47) |
| `deepseek` | `deepseek-chat` (`DEEPSEEK_MODEL`; or `deepseek-reasoner`) | NO — Groq STT upstream | NO (text NOTE only) | yes | stub (needs captioner) | [llm_deepseek.py:47](app/providers/llm_deepseek.py#L47) |

Additional fixed model ids referenced in code:

- **Gemini Pro (tier-3)**: `gemini-3.1-pro-preview` (`GEMINI_TIER3_MODEL`). ([config.py:475](app/config.py#L475))
- **STT (Claude / DeepSeek)**: Groq `whisper-large-v3-turbo`, `response_format="text"`. ([llm_claude.py:216-220](app/providers/llm_claude.py#L216))
- **Web bench**: `settings.GEMINI_MODEL` by default; per-request `model` override supported (e.g. `gemini-3*` for code-execution + thinking_level testing). ([gemini_brain.py:633](app/providers/gemini_brain.py#L633))

The web brain (`gemini_brain`) is a parallel Gemini path that does NOT use `LlmProvider`/`get_llm_provider`; it talks to `genai.Client` directly and emits `SimResponse` (KaTeX) rather than `LlmReply` (mathtext).
