# Backend — Pilot Program, Insights, OTA & Offline Taggers

> Added 2026-07-03, unchanged as of the 2026-07-05 re-sync (backend tip `a5533e5`; the 07-03/04 commits touched rendering/memory internals, not these subsystems). This documents four **new operational / instrumentation subsystems** that landed after the 2026-06-16 doc sync. None of them sits on the live question→answer hot path — they are cohort-trial instrumentation (pilot), read-only learning analytics (insights), firmware self-update (OTA), and offline batch classifiers (taggers). They share one design rule with the rest of the backend: **instrumentation must never break a request** — every write is DB-availability-gated and swallows its own exceptions.

Grounded in `Smart-Tutor-Lamp-backend/app/`. See also: [01-routes-and-api.md](01-routes-and-api.md) for where these routers mount, [08-memory-workers-and-analytics.md](08-memory-workers-and-analytics.md) for the per-user analytics they complement, [10-formatting-schemas-and-admin.md](10-formatting-schemas-and-admin.md) for the admin dashboard surface.

---

## Table of Contents

1. [The Pilot Program (beta-cohort instrumentation)](#1-the-pilot-program-beta-cohort-instrumentation)
2. [Insights (learning analytics)](#2-insights-learning-analytics)
3. [OTA (over-the-air firmware updates)](#3-ota-over-the-air-firmware-updates)
4. [Offline Topic & Mistake Taggers](#4-offline-topic--mistake-taggers)
5. [How the four subsystems relate](#5-how-the-four-subsystems-relate)

---

## 1. The Pilot Program (beta-cohort instrumentation)

**What "pilot" means here.** Not aviation, not QA device-testers — a **beta cohort trial** of the Smart Tutor Lamp with ~10-15 students ([pilot.py:2-3](Smart-Tutor-Lamp-backend/app/routes/pilot.py#L2), [admin_pilot.py:10](Smart-Tutor-Lamp-backend/app/services/admin_pilot.py#L10)). It is a bundle of "low-blast-radius Green features" that instrument the trial: turn feedback, before/after surveys, one-tap problem reports, a preference profile, an immutable consent log, and an activation funnel. Cohort membership is a `user_profiles.cohort` tag. Both pilot routers mount **only when `ENABLE_AUTH=True`** ([main.py:313,317,325-326](Smart-Tutor-Lamp-backend/app/main.py#L313)).

### 1.1 Files

| File | Role |
|---|---|
| `app/routes/pilot.py` | Student-facing router `prefix="/api/frontend/pilot"`, Clerk-gated ([pilot.py:45](Smart-Tutor-Lamp-backend/app/routes/pilot.py#L45)) |
| `app/routes/admin_pilot.py` | Admin read-rollups + one triage write, `prefix="/api/frontend/admin/pilot"`, `require_admin` ([admin_pilot.py:33](Smart-Tutor-Lamp-backend/app/routes/admin_pilot.py#L33)) |
| `app/schemas/pilot.py` | Student request/response models |
| `app/schemas/admin_pilot.py` | Admin dashboard response models (every field defaulted → empty, never 500) |
| `app/services/admin_pilot.py` | Admin rollup service (raw SQL; reuses savepoint-guarded `_rows`/`_scalar` from `services/admin`) |
| `app/storage/pilot.py` | ORM persistence (DB-gated, crash-safe), lazy-imported per call |

Two DB helpers keep both routers isolated from the annotation-eval subtleties of slowapi: **neither route module uses `from __future__ import annotations`** (deliberate — `@limiter.limit` inspects the concrete `Request` type at import) ([pilot.py:15-16](Smart-Tutor-Lamp-backend/app/routes/pilot.py#L15)).

### 1.2 Student-facing endpoints (`routes/pilot.py`)

All gate on `current_clerk_user`; each stamps `request.state.clerk_user_id` before persisting. `_MAX_JSON_BYTES = 16_000` caps free-form JSON blobs; oversized blobs are zeroed rather than rejected ([pilot.py:49-56](Smart-Tutor-Lamp-backend/app/routes/pilot.py#L49)).

| Method + Path | Line | Rate | Req → Resp | Behavior |
|---|---|---|---|---|
| POST `/turn-feedback` | [:59-76](Smart-Tutor-Lamp-backend/app/routes/pilot.py#L59) | 120/min | `TurnFeedbackIn` → `TurnFeedbackOut` | UPSERT one rating per (turn, user) via `store.record_turn_feedback` (thumbs, reason ≤60, resolution, 1-5 rating, ≤2000-char text) |
| POST `/survey` | [:79-95](Smart-Tutor-Lamp-backend/app/routes/pilot.py#L79) | 30/min | `SurveyIn` → `SurveyOut` | append-only `baseline`/`exit`/`weekly` questionnaire; rejects if `answers` blob too big |
| GET `/survey/status` | [:98-107](Smart-Tutor-Lamp-backend/app/routes/pilot.py#L98) | 60/min | — → `SurveyStatusOut` | latest ISO timestamp per survey kind |
| POST `/report` | [:110-142](Smart-Tutor-Lamp-backend/app/routes/pilot.py#L110) | 30/min | `ProblemReportIn` → `ProblemReportOut` | one-tap bug report + context snapshot; **fires a best-effort email alert** as a fire-and-forget `asyncio.create_task(send_email(...))` when `ok and settings.PROBLEM_REPORT_EMAIL_ENABLED` |
| GET `/personalization` | [:145-154](Smart-Tutor-Lamp-backend/app/routes/pilot.py#L145) | 60/min | — → `PersonalizationOut` | student preference profile (empty when unset) |
| POST `/personalization` | [:157-173](Smart-Tutor-Lamp-backend/app/routes/pilot.py#L157) | 30/min | `PersonalizationIn` → `PersonalizationSaveOut` | **collection only** — not yet wired into the tutor system prompt ([:165-166](Smart-Tutor-Lamp-backend/app/routes/pilot.py#L165)) |
| POST `/consent` | [:176-190](Smart-Tutor-Lamp-backend/app/routes/pilot.py#L176) | 30/min | `ConsentIn` → `ConsentOut` | append one immutable audit row (pilot_participation / data_processing / parental) |

### 1.3 Admin endpoints (`routes/admin_pilot.py`)

All `require_admin`, `60/minute`, `AsyncSession` via `Depends(get_db)`, delegating to `services/admin_pilot as svc`. Empty-string query defaults normalize to `None` (no filter). `set_report_status` is the **only** write and is the single triage action.

| Method + Path | Line | Query | Resp | Service |
|---|---|---|---|---|
| GET `/cohorts` | [:36-44](Smart-Tutor-Lamp-backend/app/routes/admin_pilot.py#L36) | — | `CohortsOut` | `list_cohorts` — `DISTINCT user_profiles.cohort` |
| GET `/funnel` | [:47-57](Smart-Tutor-Lamp-backend/app/routes/admin_pilot.py#L47) | `cohort` | `FunnelOut` | `funnel` — signed_up→onboarded→paired→asked→succeeded |
| GET `/feedback` | [:60-71](Smart-Tutor-Lamp-backend/app/routes/admin_pilot.py#L60) | `days` 1-90, `cohort` | `FeedbackSummaryOut` | `feedback_summary` — thumbs/avg-rating/reason-mix + recent 50 |
| GET `/surveys` | [:74-84](Smart-Tutor-Lamp-backend/app/routes/admin_pilot.py#L74) | `cohort` | `SurveyResultsOut` | `survey_results` — per-kind counts, NPS, per-subject confidence delta (exit − baseline) |
| GET `/reports` | [:87-99](Smart-Tutor-Lamp-backend/app/routes/admin_pilot.py#L87) | `status`, `cohort`, `limit` 1-500 | `ProblemReportsOut` | `problem_reports` — open/triaged/resolved counts + rows |
| POST `/reports/{id}/status` | [:102-115](Smart-Tutor-Lamp-backend/app/routes/admin_pilot.py#L102) | body `ReportStatusIn` | `ReportStatusOut` | `set_report_status` — UPDATE status ∈ open/triaged/resolved |

Every admin query supports an optional cohort filter joined to `user_profiles.cohort` via the NULL-safe cast `_COHORT = "(CAST(:cohort AS text) IS NULL OR p.cohort = CAST(:cohort AS text))"` ([admin_pilot.py:26-27](Smart-Tutor-Lamp-backend/app/services/admin_pilot.py#L26)). The subject confidence deltas key off `_CONF_SUBJECTS = ("physics","chemistry","mathematics","biology")` ([:23-24](Smart-Tutor-Lamp-backend/app/services/admin_pilot.py#L23)), and `_navg(key)` builds a JSONB-answer average guarded against non-numeric values ([:30-34](Smart-Tutor-Lamp-backend/app/services/admin_pilot.py#L30)).

### 1.4 Persistence (`storage/pilot.py`)

Same discipline as `storage/model_eval.py`: `_session_factory()` returns `None` when the engine is uninitialized (no-op → `False`), and every function swallows its own errors ([pilot.py:1-13,24-30](Smart-Tutor-Lamp-backend/app/storage/pilot.py#L1)). ORM-based (no Redis). Functions and their tables:

| Function | Line | Table | Notes |
|---|---|---|---|
| `record_turn_feedback(...)` | [:45-116](Smart-Tutor-Lamp-backend/app/storage/pilot.py#L45) | `turn_feedback` | UPSERT per (turn, user); rejects orphan feedback (verifies `TurnRecord` exists); merges only user-provided fields |
| `feedback_for_turns(user_id, turn_ids)` | [:119-149](Smart-Tutor-Lamp-backend/app/storage/pilot.py#L119) | `turn_feedback` | pre-fills the analytics 👍/👎 widget (consumed by the recent-turns feed, not the routes) |
| `submit_survey(...)` | [:153-177](Smart-Tutor-Lamp-backend/app/storage/pilot.py#L153) | `survey_responses` | append-only; rejects unknown `survey_kind` |
| `survey_status(user_id)` | [:180-202](Smart-Tutor-Lamp-backend/app/storage/pilot.py#L180) | `survey_responses` | `MAX(submitted_at)` per kind |
| `record_problem_report(...)` | [:206-233](Smart-Tutor-Lamp-backend/app/storage/pilot.py#L206) | `problem_reports` | append one report + JSONB context |
| `upsert_personalization(...)` | [:237-279](Smart-Tutor-Lamp-backend/app/storage/pilot.py#L237) | `student_personalization` | per-user partial overwrite |
| `get_personalization(user_id)` | [:282-303](Smart-Tutor-Lamp-backend/app/storage/pilot.py#L282) | `student_personalization` | — |
| `record_consent(...)` | [:307-332](Smart-Tutor-Lamp-backend/app/storage/pilot.py#L307) | `user_consents` | immutable audit append |

The backing ORM models (`TurnFeedback`, `SurveyResponse`, `ProblemReport`, `StudentPersonalization`, `UserConsent`, plus `SyllabusTopic`/`TurnTopic`/`TurnMistake` in §4) live in `app/db/models.py` and are documented in the database catalog ([folder_details/05-database.md](../folder_details/05-database.md), out of this doc-set's scope).

---

## 2. Insights (learning analytics)

`app/services/insights.py` + `app/routes/insights.py` + `app/schemas/insights.py` — a **read-only, admin-gated, cohort-filterable learning-analytics surface** that completes the "P1/P2" analytics on top of the offline topic/mistake tagging pipeline (§4). Router `prefix="/api/frontend/admin/pilot/insights"`, tag `insights`, mounts **only when `ENABLE_AUTH=True`** ([insights.py:33](Smart-Tutor-Lamp-backend/app/routes/insights.py#L33), [main.py:315,327](Smart-Tutor-Lamp-backend/app/main.py#L315)).

The service reuses the savepoint-guarded `_rows`/`_scalar` executors from `services/admin` (so an un-migrated tag table degrades to empty), and joins across `turns ⨝ turn_topics ⨝ syllabus_topics ⨝ turn_feedback ⨝ sessions ⨝ turn_mistakes`, all cohort-scoped via `_COHORT` and exam-scoped via `_EXAM = "(CAST(:exam AS text) IS NULL OR CAST(:exam AS text) = ANY(s.exams))"` ([insights.py:20-22](Smart-Tutor-Lamp-backend/app/services/insights.py#L20)).

### 2.1 Endpoints (all GET, `require_admin`, `60/minute`)

| Path | Line | Resp | What it computes |
|---|---|---|---|
| `/topics` | [:36-49](Smart-Tutor-Lamp-backend/app/routes/insights.py#L36) | `TopicStrengthOut` | per-topic rollup: questions, avg time, escalation %, avg confidence, got-it rate, and a composite **0-100 struggle score** |
| `/coverage` | [:52-63](Smart-Tutor-Lamp-backend/app/routes/insights.py#L52) | `CoverageOut` | syllabus coverage — touched vs untouched topics per subject + a 15-row sample of never-asked topics |
| `/engagement` | [:66-76](Smart-Tutor-Lamp-backend/app/routes/insights.py#L66) | `EngagementOut` | DAU/WAU/MAU, sessions, study-hours (per-session duration capped at 2 h), questions/active-day, longest streak (gaps-and-islands), returning users |
| `/mistakes` | [:79-89](Smart-Tutor-Lamp-backend/app/routes/insights.py#L79) | `MistakesOut` | overall mistake-type split + top-12 topics by mistake count with dominant type (from `turn_mistakes`) |
| `/quality` | [:92-102](Smart-Tutor-Lamp-backend/app/routes/insights.py#L92) | `QualityOut` | escalation %, drop-off %, feedback resolution/thumbs breakdown |

The struggle score (`_struggle`, [insights.py:25-34](Smart-Tutor-Lamp-backend/app/services/insights.py#L25)) starts at the escalation %, adds up to +35 for slowness over 15 s (1/sec) and +30·still-stuck-rate, clamped 0-100 — explicitly a proxy, not graded mastery. All response schemas default every field so a not-yet-populated metric renders empty/zero rather than 500-ing ([schemas/insights.py](Smart-Tutor-Lamp-backend/app/schemas/insights.py)).

---

## 3. OTA (over-the-air firmware updates)

`app/routes/ota.py` + `app/services/ota_release.py` — the lamp polls the backend at boot for newer firmware and flashes itself. Unlike everything else in this doc, the OTA **poll** router mounts **unconditionally** (independent of `ENABLE_AUTH`) so a lamp can always self-update ([main.py:29,284](Smart-Tutor-Lamp-backend/app/main.py#L284)); the admin **publish** console lives in `routes/admin.py` (see §3.3).

### 3.1 The release model

The firmware `.bin` lives **in Postgres** (`firmware_releases.bin bytea`), served by the backend itself — a release needs no S3/CDN and no redeploy ([ota_release.py:1-6](Smart-Tutor-Lamp-backend/app/services/ota_release.py#L1)). Versioning is a **single monotonic integer** (`version`); there is no semver, no per-device targeting, no staged rollout, no hardware-model gating. Only the newest 5 releases are kept — `_KEEP = 5`, older rows pruned on each publish (~1.5 MB/row) ([:20,41-45](Smart-Tutor-Lamp-backend/app/services/ota_release.py#L20)).

### 3.2 Lamp-facing endpoints (`routes/ota.py`, `prefix="/lamp/ota"`, no auth, no rate limit)

- **`GET /lamp/ota/version`** ([ota.py:42-59](Smart-Tutor-Lamp-backend/app/routes/ota.py#L42)) → **plain text** `"{version}\n{bin_url}\n"`. Precedence: a DB-published release with `version>0` wins ([:52-53](Smart-Tutor-Lamp-backend/app/routes/ota.py#L52)); else the env fallback `OTA_FIRMWARE_VERSION` + `OTA_FIRMWARE_URL` (a self-hosted URL) ([:55-58](Smart-Tutor-Lamp-backend/app/routes/ota.py#L55)); else `"0\n"` (nothing published → lamp no-ops). The bin URL is built from `request.base_url` with `http→https` force-rewritten (Render terminates TLS) ([:33-39](Smart-Tutor-Lamp-backend/app/routes/ota.py#L33)). The lamp's `ota.cpp` flashes only if the returned integer is **strictly greater** than its compiled `FIRMWARE_VERSION`.
- **`GET /lamp/ota/firmware.bin`** ([ota.py:62-79](Smart-Tutor-Lamp-backend/app/routes/ota.py#L62)) → the current release's bytes, served straight from `bytea` as an `application/octet-stream` attachment; **404** when no DB release exists (e.g. when the env-var URL path is in use).

### 3.3 Admin OTA console (`routes/admin.py`)

- **`POST /api/frontend/admin/ota/release`** ([admin.py:82-106](Smart-Tutor-Lamp-backend/app/routes/admin.py#L82), `require_admin`, 10/min) — publish: raw request body = the `.bin`, `version` (≥1) / `notes` as query params; validates size 1000 B – 4 MB (400 `BAD_BIN`/`BIG_BIN`) → `ota_release.publish` (demotes all `is_current`, inserts current, prunes to 5, commits).
- **`GET /api/frontend/admin/ota/releases`** ([:109-118](Smart-Tutor-Lamp-backend/app/routes/admin.py#L109)) — release history, metadata only → `ota_release.list_releases`.
- **`DELETE /api/frontend/admin/ota/release/{release_id}`** ([:121-131](Smart-Tutor-Lamp-backend/app/routes/admin.py#L121), 30/min) → `ota_release.delete_release`.

Service functions: `publish` ([:23-48](Smart-Tutor-Lamp-backend/app/services/ota_release.py#L23)), `current_meta` (light, no bytes — powers the frequent poll, [:51-57](Smart-Tutor-Lamp-backend/app/services/ota_release.py#L51)), `current_bin` ([:60-67](Smart-Tutor-Lamp-backend/app/services/ota_release.py#L60)), `list_releases` ([:70-76](Smart-Tutor-Lamp-backend/app/services/ota_release.py#L70)), `delete_release` ([:79-86](Smart-Tutor-Lamp-backend/app/services/ota_release.py#L79)). Config: `OTA_FIRMWARE_VERSION` (default `0`), `OTA_FIRMWARE_URL` ([config.py:925-926](Smart-Tutor-Lamp-backend/app/config.py#L925)).

---

## 4. Offline Topic & Mistake Taggers

> ⚠️ **Two unrelated "tagging" concepts — do not conflate.** (1) The live pipeline writes **inline rich-analytics columns** `topic`/`concepts`/`error_type` directly onto the `turns` row (model-emitted, gated by `RICH_ANALYTICS_ENABLED`; see [turns.py:271-273](Smart-Tutor-Lamp-backend/app/storage/turns.py#L271)). (2) This subsystem is the **offline batch tagger** — separate `turn_topics` / `turn_mistakes` tables, populated by workers that never touch the live turn path. The offline tags are consumed by **`services/insights.py`** (§2), **not** by `services/analytics.py`.

There is **no queue and no automatic trigger**. Each worker is a Postgres anti-join poll — `WHERE status='ok' AND <tag row> IS NULL`, newest-first, `LIMIT` batch (default 200) — run by an operator/cron via `python -m scripts.tag_topics` / `scripts.tag_mistakes`. A row is **always** written (even `unmapped`/`none`), so a turn is never reprocessed; a forced re-tag UPSERTs on `UNIQUE(turn_id)`. All LLM stages use `settings.GEMINI_MODEL` (default `gemini-3.1-flash-lite`) and degrade to keyword-only when the Gemini client is absent.

### 4.1 Topic tagger (`services/topic_tagger.py` + `workers/topic_tag.py`)

Maps one turn's text (`transcript + " " + speech`) to exactly one `syllabus_topics` row (a ~185-row controlled vocabulary keyed on `code`, format `[A-Z]+-\d+`). Two-stage, cheapest-first ([topic_tagger.py:1-20](Smart-Tutor-Lamp-backend/app/services/topic_tagger.py#L1)):

1. **`keyword_match`** ([:98-152](Smart-Tutor-Lamp-backend/app/services/topic_tagger.py#L98)) — deterministic scorer over the exam+subject-filtered candidate set. Score = token overlap + a **+5** phrase bonus when the full topic name appears. Accept when `best_phrase OR (overlap ≥ 3 AND margin ≥ 1)`; confidence 0.35–0.9. `source="keyword"`.
2. **`llm_match`** ([:185-203](Smart-Tutor-Lamp-backend/app/services/topic_tagger.py#L185)) — only when keyword is ambiguous and `use_llm`: a blocking Gemini call (via `asyncio.to_thread`) picks EXACTLY one candidate code or NONE; validated against `[A-Z]+-\d+`. `source="llm"`, confidence 0.7.

Unmatched turns are stored `source="unmapped"` (all-NULL topic). The worker (`run_batch`/`tag_all`, [topic_tag.py:86,118](Smart-Tutor-Lamp-backend/app/workers/topic_tag.py#L86)) UPSERTs into `turn_topics` `ON CONFLICT (turn_id)`, per-row try/except, single commit, never raises. `_SUBJECT_MAP` canonicalizes model subjects → `Physics/Chemistry/Biology/Mathematics` ([:33-41](Smart-Tutor-Lamp-backend/app/services/topic_tagger.py#L33)).

### 4.2 Mistake tagger (`services/mistake_tagger.py` + `workers/mistake_tag.py`)

Classifies the kind of student error from question + tutor reply into a **fixed 8-category taxonomy** `MISTAKE_TYPES` ([mistake_tagger.py:23-32](Smart-Tutor-Lamp-backend/app/services/mistake_tagger.py#L23)): `conceptual`, `calculation`, `formula`, `sign`, `unit`, `procedural`, `careless`, `none`. (This same list is imported by `insights.mistakes` for its labels.)

1. **`keyword_prepass`** ([:53-61](Smart-Tutor-Lamp-backend/app/services/mistake_tagger.py#L53)) — only short-circuits the clear "correct" case (confirm phrase present, no error language) → `none`, confidence 0.8. It can detect "no mistake" but cannot *type* a real mistake.
2. **`llm_classify`** ([:98-107](Smart-Tutor-Lamp-backend/app/services/mistake_tagger.py#L98)) — a Gemini call strongly biased toward `none` ("when unsure, answer none"); parses the first token in `VALID`.

Worker (`mistake_tag.py`) UPSERTs into `turn_mistakes` `ON CONFLICT (turn_id)`, same crash-safety. CLIs `scripts/tag_topics.py` / `scripts/tag_mistakes.py` accept `--limit`, `--once` (single batch vs drain), `--no-llm` (keyword-only, zero API cost), `--model`.

### 4.3 Tables (`app/db/models.py`)

- `syllabus_topics` — controlled vocabulary: `id, exams text[], subject, unit, topic, code (unique), aliases JSONB, class_level, sort_order, active`.
- `turn_topics` — `id, turn_id (UNIQUE), topic_id, topic_code, subject, confidence, source, raw, model, created_at`.
- `turn_mistakes` — `id, turn_id (UNIQUE), mistake_type, confidence, source, raw, model, created_at`.

No DB-level foreign keys (house style) — `turn_id`/`topic_id` are plain join columns.

---

## 5. How the four subsystems relate

```
LIVE TURN (hot path)                          OFFLINE / OPERATIONAL (this doc)
──────────────────────────                    ─────────────────────────────────
lamp/web turn → orchestrator                  cron:  python -m scripts.tag_topics
   │  writes turns row                                │  anti-join poll (status='ok'
   │  (+ inline topic/concepts/error_type              │   AND no turn_topics/turn_mistakes)
   │   when RICH_ANALYTICS_ENABLED)                     ▼
   ▼                                           turn_topics / turn_mistakes  ◄─ §4 taggers
 turns ──────────────────────────────┐                 │
   ▲                                  │                 ▼
   │ pilot student widgets            │        services/insights.py  ──►  /admin/pilot/insights
   │ (feedback / survey / report      │        (topics/coverage/engagement/     §2
   │  / consent) → §1 pilot tables    │         mistakes/quality, cohort-scoped)
   │                                  │
 user_profiles.cohort  ◄─────────────┘        admin/pilot rollups (funnel/feedback/  §1
                                              surveys/reports)  ◄── admin_pilot.py

 lamp boot ──► GET /lamp/ota/version ──► (version>compiled?) ──► GET /firmware.bin  §3
                                          served from firmware_releases.bin (Postgres)
```

- **Pilot** and **insights** both key on `user_profiles.cohort`, so a cohort filter is consistent across the feedback rollups and the learning analytics.
- **Insights** is the sole consumer of the **taggers'** output; the per-user dashboard analytics (`services/analytics.py`, doc 08 §13) reads only the `turns` row's own columns and does **not** join the tag tables.
- **OTA** is fully independent — the only subsystem here that touches the lamp directly, and the only one mounted without `ENABLE_AUTH`.
