# Backend — Authentication, Device Pairing & Security

This is the definitive reference for how the Smart Tutor Lamp backend authenticates **humans** (via Clerk over HTTP and WebSocket), authenticates **devices** (via a backend-owned `device_jwt` and an argon2id-hashed `device_secret`), binds a physical lamp to a user account through a single-use **pairing code**, and revokes that binding sub-second across replicas via Redis pub/sub. It also covers the slowapi rate limiter, the admin allowlist gate, and the Svix-signed Clerk lifecycle webhook. Everything below is grounded in the actual code in `D:/clartiy/Smart-Tutor-Lamp-backend` and cross-referenced to `IMPLEMENTATION_AUTH_PAIRING.md`.

The cardinal rule of this subsystem (the "strict identity boundary," [IMPLEMENTATION_AUTH_PAIRING.md §0.1](../../Smart-Tutor-Lamp-backend/IMPLEMENTATION_AUTH_PAIRING.md)): **the ESP32 lamp NEVER talks to Clerk.** Clerk owns only the human-identity layer (browser side); the Python backend owns the device-identity layer (`device_id`, `device_secret`, `device_jwt`), signed and verified with its own secret. Clerk could be swapped out without changing one line of firmware.

---

## Table of contents

1. [Purpose & responsibility](#1-purpose--responsibility)
2. [Architecture & components](#2-architecture--components)
3. [Identities & secrets (the six materials)](#3-identities--secrets-the-six-materials)
4. [Data structures (DB models & Pydantic schemas)](#4-data-structures-db-models--pydantic-schemas)
5. [User authentication — Clerk over HTTP](#5-user-authentication--clerk-over-http)
6. [User authentication — Clerk over WebSocket](#6-user-authentication--clerk-over-websocket)
7. [Admin gate](#7-admin-gate)
8. [Device authentication — secret hash/verify](#8-device-authentication--secret-hashverify)
9. [Device JWT — mint & verify](#9-device-jwt--mint--verify)
10. [Pairing — code generation & full flow](#10-pairing--code-generation--full-flow)
11. [WebSocket gateway device auth (the lamp connect path)](#11-websocket-gateway-device-auth-the-lamp-connect-path)
12. [Token revocation (Redis pub/sub + DB)](#12-token-revocation-redis-pubsub--db)
13. [Clerk lifecycle webhook (Svix)](#13-clerk-lifecycle-webhook-svix)
14. [Rate limiting (slowapi)](#14-rate-limiting-slowapi)
15. [Configuration, env vars, constants](#15-configuration-env-vars-constants)
16. [Edge cases, error handling, timeouts, fallbacks](#16-edge-cases-error-handling-timeouts-fallbacks)
17. [Integration points & cross-references](#17-integration-points--cross-references)
18. [File-by-file / function-by-function reference](#18-file-by-file--function-by-function-reference)

---

## 1. Purpose & responsibility

This subsystem is **Layer 10** of the backend (`ENABLE_AUTH` toggle in [config.py:297](../../Smart-Tutor-Lamp-backend/app/config.py#L297)). Its responsibilities:

- **Human identity (Clerk).** Verify the browser's Clerk session token on every frontend → backend HTTP call and on the brain-bench WebSocket, returning the **Clerk user ID** (`user_2abc…`) — the value stored as `devices.user_id`.
- **Device identity.** Hash and verify each lamp's `device_secret` (argon2id), and mint/verify the long-lived `device_jwt` (HS256 with the backend's own `DEVICE_JWT_SECRET`).
- **Pairing.** Generate single-use, 5-minute pairing codes; surface device info to the `/pair/[code]` page; and atomically bind a device row to a Clerk user when the user clicks "Link."
- **Revocation.** Flip `devices.revoked_at` on unlink / account-deletion and fan the revocation out over Redis pub/sub so any live WebSocket closes within ~1 s; degrade to a 30 s DB-poll heartbeat when Redis is absent.
- **Defense.** Rate-limit lamp and frontend endpoints, gate the admin surface against a durable allowlist table, and verify the Clerk webhook's Svix signature before doing any work.

The whole surface is mounted **only when `ENABLE_AUTH=True`** ([main.py:258-274](../../Smart-Tutor-Lamp-backend/app/main.py#L258)). In dev (`ENABLE_AUTH=False`) the pairing routes are not registered (accidental calls 404 cleanly instead of 503-ing on missing Clerk config), and the lamp WS accepts any Bearer mapped to a single bench identity `dev-lamp`.

---

## 2. Architecture & components

The two auth modes never cross: Clerk tokens stop at the HTTP/WS frontend boundary; `device_jwt` lives only on the lamp ↔ backend leg.

```mermaid
flowchart TB
  subgraph Browser["Browser (Next.js + Clerk SDK)"]
    FE["/pair/[code] · /devices · /admin · /simulator"]
  end
  subgraph Clerk["Clerk (managed)"]
    CK["session tokens · JWKS · webhooks (Svix)"]
  end
  subgraph BE["Python backend (FastAPI + uvicorn)"]
    DEPclerk["deps/clerk.py\ncurrent_clerk_user (HTTP)"]
    DEPws["deps/clerk_ws.py\nverify_ws_token (WS ?token=)"]
    DEPadmin["deps/admin.py\nrequire_admin"]
    DEPdev["deps/device_auth.py\nhash/verify_secret"]
    DEPrl["deps/rate_limit.py\nslowapi Limiter"]
    SVjwt["services/device_jwt.py\nsign/verify_device_jwt"]
    SVpair["services/pairing.py\ngenerate_pairing_code"]
    SVrev["services/revocation.py\nRedis pub/sub"]
    RTlamp["routes/device_lamp.py\n/register /poll-pairing"]
    RTuser["routes/device_user.py\n/complete-pairing /devices /unlink /rename"]
    RTinfo["routes/pairing_info.py\nGET /pairing-info/{code}"]
    RThook["routes/clerk_webhook.py\nPOST /clerk/webhook"]
    WS["routes/ws_lamp.py\n/lamp/ws gateway"]
    DB[(Postgres: devices, pairing_codes, admins)]
    RD[(Redis: rate buckets + revoke pub/sub)]
  end
  subgraph Lamp["ESP32-S3 lamp"]
    LMP["device_secret (NVS) + device_jwt (NVS)"]
  end

  FE -- "Bearer Clerk token" --> DEPclerk
  FE -- "?token= Clerk JWT (WS)" --> DEPws
  DEPclerk --> CK
  DEPws --> CK
  CK -- "Svix-signed user.*" --> RThook
  DEPadmin --> DEPclerk
  RTuser --> DEPclerk
  RTinfo --> DB
  RTuser --> SVjwt
  RTuser --> SVrev
  RTlamp --> DEPdev
  RTlamp --> SVpair
  RTlamp --> SVjwt
  LMP -- "device_secret in body (HTTPS)" --> RTlamp
  LMP -- "Bearer device_jwt (WSS)" --> WS
  WS --> SVjwt
  WS --> DB
  WS --> SVrev
  SVrev --> RD
  RThook --> SVrev
```

Modules (all under `D:/clartiy/Smart-Tutor-Lamp-backend/app`):

| Module | Role |
|---|---|
| [deps/clerk.py](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py) | Clerk session verify for **HTTP** routes (`clerk-backend-api` SDK + JWKS), with a 30 s per-token cache. |
| [deps/clerk_ws.py](../../Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py) | Clerk session verify for the **WebSocket** path (`pyjwt` against public JWKS). |
| [deps/admin.py](../../Smart-Tutor-Lamp-backend/app/deps/admin.py) | `require_admin` — layers an allowlist check on top of `current_clerk_user`. |
| [deps/device_auth.py](../../Smart-Tutor-Lamp-backend/app/deps/device_auth.py) | argon2id `hash_secret` / `verify_secret` for the lamp's `device_secret`. |
| [deps/rate_limit.py](../../Smart-Tutor-Lamp-backend/app/deps/rate_limit.py) | The module-singleton slowapi `Limiter`. |
| [services/device_jwt.py](../../Smart-Tutor-Lamp-backend/app/services/device_jwt.py) | HS256 mint/verify of `device_jwt`. |
| [services/pairing.py](../../Smart-Tutor-Lamp-backend/app/services/pairing.py) | CSPRNG pairing-code generator + display formatter. |
| [services/revocation.py](../../Smart-Tutor-Lamp-backend/app/services/revocation.py) | Redis client lifecycle + revocation publish/subscribe. |
| [services/admin.py](../../Smart-Tutor-Lamp-backend/app/services/admin.py) | `is_admin` resolver (admins table) + admin dashboard queries. |
| [routes/device_lamp.py](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py) | `/register`, `/poll-pairing` (lamp-facing, public). |
| [routes/device_user.py](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py) | `/complete-pairing`, `/devices`, `/unlink`, `/rename` (Clerk-authed). |
| [routes/pairing_info.py](../../Smart-Tutor-Lamp-backend/app/routes/pairing_info.py) | `GET /pairing-info/{code}` (public confirmation card data). |
| [routes/clerk_webhook.py](../../Smart-Tutor-Lamp-backend/app/routes/clerk_webhook.py) | `POST /clerk/webhook` (Svix-signed `user.*`). |
| [routes/ws_lamp.py](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py) | `/lamp/ws` gateway: verifies `device_jwt` + DB row per connect. |
| [schemas/auth.py](../../Smart-Tutor-Lamp-backend/app/schemas/auth.py) | Pydantic request/response contracts. |
| [db/models.py](../../Smart-Tutor-Lamp-backend/app/db/models.py) | `Device`, `PairingCode`, `Admin` ORM models. |

---

## 3. Identities & secrets (the six materials)

Per [IMPLEMENTATION_AUTH_PAIRING.md §4](../../Smart-Tutor-Lamp-backend/IMPLEMENTATION_AUTH_PAIRING.md) there are six distinct identity materials. **Do not conflate them.**

| Name | Stored where | Lifetime | Who knows it | Purpose |
|---|---|---|---|---|
| `device_id` | Lamp NVS + `devices.device_id` (PK) | forever | lamp, backend, owner (visible) | Stable name, MAC-derived (`lamp-7C9EB42F`). |
| `device_secret` | Lamp NVS + `devices.device_secret_hash` (argon2id) | forever (rotatable) | lamp + backend only | Proves "I am this lamp." Never in QR, never shown to user, never seen by Clerk. |
| `pairing_code` | `pairing_codes` row | 5 min (`PAIRING_CODE_TTL_SEC`) | lamp, backend, briefly user (in URL) | Bridges "this lamp" ↔ "this logged-in user." |
| Clerk user record | Clerk's servers | account lifetime | Clerk, browser, backend (via API) | The human identity. |
| Clerk session token | Browser cookie / `getToken()` | rolling (≤ ~60 s) | browser + backend (when verifying) | Proves "this browser is a logged-in user." **Never near the lamp.** |
| `device_jwt` | Lamp NVS (revocation in `devices.revoked_at`) | indefinite, revocable | lamp + backend | Lamp's WS bearer. HS256, **backend's own secret**, no Clerk involvement. |

Generation, per the spec: `device_id` = `"lamp-" + last 6 MAC hex`; `device_secret` = 32 random bytes from `esp_random()` (sent once to `/register`, backend stores `argon2id(secret)`); `pairing_code` = backend CSPRNG 6×`[A-Z0-9]`; `device_jwt` = minted at `/complete-pairing` with HS256 over `DEVICE_JWT_SECRET`.

---

## 4. Data structures (DB models & Pydantic schemas)

### 4.1 `Device` ([db/models.py:41-76](../../Smart-Tutor-Lamp-backend/app/db/models.py#L41))

One row per physical lamp; `device_id` is the primary key (no surrogate id, no FK from `pairing_codes` is enforced at DB level for `device_id` reference in the ORM — `device_id` on `PairingCode` is a plain `String`).

| Field | Type | Notes |
|---|---|---|
| `device_id` | `String` PK | e.g. `"lamp-7C9EB42F"`. |
| `device_secret_hash` | `String` NOT NULL | argon2id of the 64-hex device secret. |
| `user_id` | `String` NULL | Clerk user ID or NULL when unpaired/revoked. |
| `friendly_name` | `String` NOT NULL | default + server_default `"Tutor Lamp"`. |
| `paired_at` | `DateTime(tz=True)` NULL | set at successful claim. |
| `last_seen_at` | `DateTime(tz=True)` NULL | bumped by WS gateway on connect + every 30 s heartbeat. |
| `revoked_at` | `DateTime(tz=True)` NULL | set on unlink / account delete. Coexists with `user_id=NULL` for audit clarity (we know it WAS paired, then revoked). |
| `created_at` | `DateTime(tz=True)` NOT NULL | server_default `now()`. |

Index: partial `devices_user_idx` on `user_id WHERE user_id IS NOT NULL` — `/api/devices` filters by `user_id IS NOT NULL`, so orphan rows are not indexed.

The "paired and active" predicate used throughout the codebase is: **`user_id IS NOT NULL AND revoked_at IS NULL`**.

### 4.2 `PairingCode` ([db/models.py:79-106](../../Smart-Tutor-Lamp-backend/app/db/models.py#L79))

Short-lived bridge row. `code` is the PK (so a code is globally unique).

| Field | Type | Notes |
|---|---|---|
| `code` | `String` PK | the 6-char code (raw, no dash). |
| `device_id` | `String` NOT NULL | which lamp this code is for. |
| `user_id` | `String` NULL | filled at claim time. |
| `status` | `String` NOT NULL | CHECK `IN ('pending','paired','expired')`. |
| `device_jwt` | `String` NULL | minted into the row at claim, read back by the lamp's poll. |
| `expires_at` | `DateTime(tz=True)` NOT NULL | `now() + PAIRING_CODE_TTL_SEC`. |
| `created_at` | `DateTime(tz=True)` NOT NULL | server_default `now()`. |

Constraints/indexes: `CheckConstraint pairing_codes_status_check`, `Index pairing_codes_device_idx` on `device_id`. (The register route also references `pairing_codes_expires_idx` in a comment as the backing index for the expiry sweep.)

### 4.3 `Admin` ([db/models.py:384-414](../../Smart-Tutor-Lamp-backend/app/db/models.py#L384))

The durable admin allowlist (the **sole** source of truth; the `ADMIN_USER_IDS`/`ADMIN_EMAILS` env vars are deprecated and ignored).

| Field | Type | Notes |
|---|---|---|
| `user_id` | `String` PK | Clerk ID — join key. |
| `email` | `String` NULL | stored lower-cased for display + email-allowlist match. |
| `note` | `String` NULL | free text. |
| `created_at` | `DateTime(tz=True)` NOT NULL | — |

Index `admins_email_idx` on `email WHERE email IS NOT NULL`.

### 4.4 Pydantic schemas ([schemas/auth.py](../../Smart-Tutor-Lamp-backend/app/schemas/auth.py))

Lamp-facing:
- `DeviceRegisterIn` — `device_id` (4–64 chars), `device_secret` (8–256 chars) ([auth.py:21](../../Smart-Tutor-Lamp-backend/app/schemas/auth.py#L21)).
- `DeviceRegisterOut` — discriminated by `status: Literal["pending","already_paired"]` (default `"pending"` so older firmware still works). `pending` → `pairing_code`/`pairing_url`/`expires_in` set, `device_jwt` null; `already_paired` → `device_jwt` set (recovery), QR fields null ([auth.py:26-44](../../Smart-Tutor-Lamp-backend/app/schemas/auth.py#L26)).
- `DevicePollIn` — `device_id`, `device_secret`, `pairing_code` (6–8 chars) ([auth.py:47](../../Smart-Tutor-Lamp-backend/app/schemas/auth.py#L47)).
- `DevicePollOut` — `model_config extra="forbid"`, `status: Literal["pending","paired","expired"]`, `device_jwt` only on `paired` ([auth.py:53](../../Smart-Tutor-Lamp-backend/app/schemas/auth.py#L53)).

Frontend-facing: `PairingInfoOut` (device_id, friendly_name, expires_at), `CompletePairingIn` (pairing_code 6–8), `CompletePairingOut`, `DeviceListItem`/`DeviceListOut`, `DeviceRenameIn` (friendly_name 1–60), `DeviceRenameOut` ([auth.py:63-95](../../Smart-Tutor-Lamp-backend/app/schemas/auth.py#L63)).

Error envelope: `ApiError { error: str, code: str }` — the shape every 4xx/5xx detail follows ([auth.py:101](../../Smart-Tutor-Lamp-backend/app/schemas/auth.py#L101)). In code the error is raised as `HTTPException(status_code=…, detail={"error": …, "code": …})`.

---

## 5. User authentication — Clerk over HTTP

File: [deps/clerk.py](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py). The single dependency every frontend HTTP route gates on is `current_clerk_user`, which returns the **Clerk user ID** (`sub` claim).

### 5.1 Lazy SDK resolution

The `clerk-backend-api` SDK moved symbol locations across versions, so the module resolves `AuthenticateRequestOptions` and the free `authenticate_request` function **once** and caches them. `_resolve_auth_symbols()` ([clerk.py:45-63](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L45)) scans, in order, `clerk_backend_api`, `clerk_backend_api.security`, `clerk_backend_api.jwks_helpers`, taking whatever each exposes. The result is memoized in module globals guarded by `_symbols_resolved` so the scan runs once, not per request.

The `Clerk` client itself is built lazily by `_get_clerk_client()` ([clerk.py:66-84](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L66)): if `CLERK_SECRET_KEY` is empty → `503 AUTH_DISABLED`; if the SDK isn't installed → `503 AUTH_SDK_MISSING`; otherwise `Clerk(bearer_auth=settings.CLERK_SECRET_KEY)`. Lazy construction means the app boots even when `ENABLE_AUTH=False`.

### 5.2 The verified-token cache (the hot-login optimization)

Verifying a Clerk session token is a **synchronous JWKS fetch + RSA verify** over the network to `api.clerk.com` — 100s of ms warm, seconds cold. A single dashboard render fires `/profile` + `/me` + `/analytics` concurrently with the **same** token, and every navigation repays it. So the module caches the verified payload **keyed by the exact token string** ([clerk.py:87-130](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L87)):

- `_VERIFY_TTL_SEC = 30.0` — cache lifetime.
- `_VERIFY_CACHE_MAX = 1024` — bound; when full, `_cache_put` **clears the entire cache** (and the lock dict) — crude but cheap because entries are tiny and short-lived.
- `_verify_cache: dict[token → (payload, expiry_monotonic)]`.
- `_verify_locks: dict[token → asyncio.Lock]` — one in-flight lock per token.

`_cache_get` ([clerk.py:113](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L113)) checks `time.monotonic()` against the stored expiry and evicts on expiry.

Trade-off (documented in the code): a session revoked mid-token-life stays honored for at most `_VERIFY_TTL_SEC` (30 s).

### 5.3 `azp` (authorized parties) — mirroring CORS

`_authorized_parties()` ([clerk.py:137-175](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L137), `@lru_cache(maxsize=1)`) builds the set of token `azp` claim values the verifier will accept. Clerk rejects byte-for-byte any token whose `azp` isn't in the list (`TOKEN_INVALID_AUTHORIZED_PARTIES → SIGNED_OUT → 401 USER_AUTH_FAIL`). Because the same browser may open the app at `localhost:3000` **or** `127.0.0.1:3000` (or a LAN IP for phone testing), the function:

1. Seeds from `FRONTEND_BASE_URL` plus each comma-split entry of `CORS_ALLOWED_ORIGINS`.
2. Strips a trailing `/` from each.
3. For each origin matching the localhost regex `^(https?://)(localhost|127\.0\.0\.1)(:\d+)?$` ([clerk.py:134](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L134)), also adds the `localhost ↔ 127.0.0.1` twin with the same scheme + port (`_LOCALHOST_HOSTS = ("localhost","127.0.0.1")`).
4. Returns a sorted tuple. **Empty → `()`**, in which case the caller passes `None` and the `azp` check is skipped (signature + expiry still fully enforced). Real deployed origins stay exact-match, preserving `azp` protection in prod.

This is the documented cause of the "admin row exists but the Admin page never loads" failure: without the twin, `/me` 401s at verification before `is_admin()` ever runs.

### 5.4 `_verify_clerk` — the actual verification ([clerk.py:178-237](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L178))

1. Get the client + resolved symbols; if `AuthenticateRequestOptions` is unresolvable → `503 AUTH_SDK_MISSING`.
2. Build `authorized_parties` from `_authorized_parties()`.
3. Clerk's `authenticate_request` expects an **httpx.Request** (`Requestish`), not a Starlette request, so it rebuilds one carrying the incoming `Authorization` + `Cookie` headers (Clerk can read the token from either): `httpx.Request(method, url, headers=dict(request.headers))`.
4. `opts = AuthenticateRequestOptions(authorized_parties=authorized_parties or None)`.
5. The verify call is **synchronous + network I/O**, so it runs in `run_in_threadpool` to keep the uvicorn loop free. `_verify()` prefers `client.authenticate_request(httpx_req, opts)` (v5+) and falls back to the free `authenticate_request(...)`.
6. Any exception → `401 USER_AUTH_FAIL` (warn-logged).
7. If `state.is_signed_in` is falsy, it logs the machine-readable `state.reason` (e.g. `token-invalid-authorized-parties`, `token-expired`) and raises `401 USER_AUTH_FAIL`. Logging the reason is what makes an `azp` mismatch debuggable.
8. Returns `state.payload` (or `{}`).

### 5.5 `current_clerk_user` — the dependency ([clerk.py:240-293](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L240))

- If `not settings.ENABLE_AUTH` → `503 AUTH_DISABLED`.
- `_bearer_token(request)` ([clerk.py:106](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L106)) reads `Authorization`, requires a case-insensitive `bearer ` prefix, returns the trimmed token or `None`.
- **Cookie-based session (no bearer)** → can't safely key a cache → verify directly via `_verify_clerk`.
- **Bearer present** → fast path: `_cache_get(token)`; on hit, finish immediately. On miss, take the per-token lock (`_verify_locks.setdefault(token, asyncio.Lock())`), re-check the cache inside the lock (double-checked locking — a concurrent burst collapses to one verify; the others block then hit the now-warm cache), then `_verify_clerk` + `_cache_put`.
- `_finish(payload)` ([clerk.py:260](../../Smart-Tutor-Lamp-backend/app/deps/clerk.py#L260)) extracts `payload["sub"]` (the Clerk user ID); missing → `401 USER_AUTH_FAIL`. It stashes the full payload on `request.state.clerk_payload` so routes can read extra claims (e.g. email from a JWT template) without re-verifying, then returns the user ID.

```mermaid
flowchart TD
  A[HTTP request to gated route] --> B{ENABLE_AUTH?}
  B -- no --> X503[503 AUTH_DISABLED]
  B -- yes --> C[extract Bearer]
  C --> D{Bearer present?}
  D -- no, cookie --> E[_verify_clerk direct]
  D -- yes --> F{cache hit?}
  F -- yes --> G[_finish payload]
  F -- no --> H[acquire per-token lock]
  H --> I{cache hit now?}
  I -- yes --> G
  I -- no --> J[_verify_clerk in threadpool]
  J --> K[_cache_put TTL 30s]
  K --> G
  E --> G
  G --> L{sub present?}
  L -- no --> X401[401 USER_AUTH_FAIL]
  L -- yes --> M[return clerk_user_id, stash payload]
```

Usage on a route ([device_user.py:57-62](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L57)):

```python
async def complete_pairing(request, body, clerk_user_id: str = Depends(current_clerk_user), db = Depends(get_db)):
    ...
```

---

## 6. User authentication — Clerk over WebSocket

File: [deps/clerk_ws.py](../../Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py). This exists **only** because browsers can't set an `Authorization` header on `new WebSocket()`. The frontend passes the Clerk JWT in `?token=`, and the backend verifies it against Clerk's **public JWKS** with `pyjwt` (no secret). Used by the brain-bench WebSocket `/api/frontend/ws` ([frontend_manager.py:1920-1926](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1920)), **not** by the lamp.

- `WsAuthError` ([clerk_ws.py:28](../../Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py#L28)) — raised on any failure; the route closes the socket with code **4401**.
- `_derive_host(pub_key)` ([clerk_ws.py:32](../../Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py#L32)) — Clerk publishable keys are `pk_<env>_<base64(host$)>`. It splits on `_` (maxsplit 2), takes the third part, right-pads base64 to a multiple of 4 (`padded = body + "=" * (-len(body) % 4)`), base64-decodes, decodes UTF-8, and strips a trailing `$`.
- `_jwks_url()` ([clerk_ws.py:44](../../Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py#L44)) — `CLERK_JWKS_URL` if set, else `https://{derived_host}/.well-known/jwks.json`. If neither → `WsAuthError`.
- `_issuer()` ([clerk_ws.py:55](../../Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py#L55)) — `CLERK_ISSUER` if set, else `https://{derived_host}` or `None`.
- `_client()` ([clerk_ws.py:62](../../Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py#L62)) — lazily builds and caches a `PyJWKClient(_jwks_url(), cache_keys=True)`; raises `WsAuthError` if `pyjwt` isn't installed.

`verify_ws_token(token)` ([clerk_ws.py:73-103](../../Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py#L73)):

1. `None`/empty token → `WsAuthError("missing token query param")`.
2. Fetch the RS256 signing key for the JWT's kid: `_client().get_signing_key_from_jwt(token).key`.
3. `jwt.decode(token, signing_key, algorithms=["RS256"], issuer=_issuer(), options={"require": ["sub","exp","iat"], "verify_iss": bool(_issuer())}, leeway=10)`. **`leeway=10`** tolerates 10 s of clock drift (Clerk session tokens are short-lived). `verify_iss` is only enforced if an issuer was resolvable.
4. Any non-`WsAuthError` exception (`ExpiredSignature`, `InvalidIssuer`, `PyJWTError`, network) → `WsAuthError(f"invalid token: {type(e).__name__}")`.
5. **Future-dated guard:** if `iat > time.time() + 30` → `WsAuthError("token issued in the future")`.
6. Missing `sub` → `WsAuthError`. Otherwise return `sub` (Clerk user ID).

---

## 7. Admin gate

File: [deps/admin.py](../../Smart-Tutor-Lamp-backend/app/deps/admin.py). `require_admin` guards `/api/frontend/admin/*`.

`require_admin(request, clerk_user_id=Depends(current_clerk_user), db=Depends(get_db))` ([admin.py:27-43](../../Smart-Tutor-Lamp-backend/app/deps/admin.py#L27)):
1. Verifies the Clerk session as usual (via the layered `current_clerk_user` dependency), stashing `request.state.clerk_user_id`.
2. Reads a JWT email from the stashed `clerk_payload` (`payload["email"]` or `payload["primary_email"]`) if a Clerk JWT template added one.
3. Calls `is_admin(db, clerk_user_id, jwt_email)`; on `False` → `403 NOT_ADMIN`. Otherwise returns the Clerk user ID (same contract as `current_clerk_user`, so admin routes read identically).

`is_admin` ([services/admin.py:149-206](../../Smart-Tutor-Lamp-backend/app/services/admin.py#L149)):
- Resolves an email cheaply through `_email_for` ([admin.py:129](../../Smart-Tutor-Lamp-backend/app/services/admin.py#L129)) in order: (1) the JWT email claim, (2) `user_profiles.extra->>'email'` persisted at onboarding, (3) a direct Clerk Backend API lookup `client.users.get(user_id)` via `_clerk_email` ([admin.py:100](../../Smart-Tutor-Lamp-backend/app/services/admin.py#L100), run in threadpool, positively cached in `_clerk_email_cache`). The Clerk call fires only pre-onboarding.
- The lookup branches on whether an email resolved (to avoid asyncpg's `AmbiguousParameterError` on a type-less `$2 IS NOT NULL` bind): with an email, `SELECT 1 FROM admins WHERE user_id = :uid OR lower(email) = :email LIMIT 1`; without, `SELECT 1 FROM admins WHERE user_id = :uid LIMIT 1`.
- Runs **directly on the request session** (deliberately not via the error-swallowing `_scalar`). On exception (e.g. a poisoned/aborted txn after a schema change), it logs the real cause and **retries on a brand-new session** from `get_session_factory()`. If both fail → returns `False` (**fail-closed** — deny rather than wrongly grant admin).

The `admins` table is the **sole** source of truth; nothing reads `ADMIN_USER_IDS`/`ADMIN_EMAILS`.

---

## 8. Device authentication — secret hash/verify

File: [deps/device_auth.py](../../Smart-Tutor-Lamp-backend/app/deps/device_auth.py). These are plain functions (not FastAPI `Depends`) because the secret lives in the JSON body, not a header.

- `_get_hasher()` ([device_auth.py:28](../../Smart-Tutor-Lamp-backend/app/deps/device_auth.py#L28)) lazily builds an `argon2.PasswordHasher()` with library defaults: **argon2id, t=3, m=64 MiB, p=4** (per the module docstring). Lazy so dev can boot without `argon2-cffi`.
- `hash_secret(secret) -> str` ([device_auth.py:40](../../Smart-Tutor-Lamp-backend/app/deps/device_auth.py#L40)) — one-way argon2id hash of the 64-hex device secret, stored in `devices.device_secret_hash`.
- `verify_secret(stored_hash, candidate) -> bool` ([device_auth.py:45-61](../../Smart-Tutor-Lamp-backend/app/deps/device_auth.py#L45)) — **constant-time**. Returns `True` on match; `False` on `VerifyMismatchError`; `False` (warn-logged) on `VerificationError` (corrupt stored hash); `False` (exception-logged) on any other error. **Never raises** — a malformed row rejects cleanly.

Callers: `/register` upserts via `hash_secret` and verifies with `verify_secret` ([device_lamp.py:75,81](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L75)); `/poll-pairing` verifies with `verify_secret` ([device_lamp.py:169](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L169)).

---

## 9. Device JWT — mint & verify

File: [services/device_jwt.py](../../Smart-Tutor-Lamp-backend/app/services/device_jwt.py). The `device_jwt` is the lamp's WSS bearer.

Crypto/constants:
- `ALG = "HS256"` ([device_jwt.py:21](../../Smart-Tutor-Lamp-backend/app/services/device_jwt.py#L21)).
- `JWT_VERSION = 1` ([device_jwt.py:25](../../Smart-Tutor-Lamp-backend/app/services/device_jwt.py#L25)) — bump to force every paired lamp to re-pair (gateway rejects `ver < N`).
- Signed with `DEVICE_JWT_SECRET` (the backend's own secret, **not Clerk's**). `_require_secret()` ([device_jwt.py:33](../../Smart-Tutor-Lamp-backend/app/services/device_jwt.py#L33)) raises `RuntimeError` if unset (with the `openssl rand -base64 64` hint).
- **No `exp` claim** — revocation is canonical via `devices.revoked_at` checked at WS-connect time; the lamp never refreshes.
- `InvalidDeviceJwt` ([device_jwt.py:28](../../Smart-Tutor-Lamp-backend/app/services/device_jwt.py#L28)) — raised on verify failure; the WS gateway catches it and closes 4401.

`sign_device_jwt(device_id, clerk_user_id) -> str` ([device_jwt.py:43-52](../../Smart-Tutor-Lamp-backend/app/services/device_jwt.py#L43)) builds claims:

```json
{ "sub": "<device_id>", "uid": "<clerk_user_id>", "iat": <epoch>,
  "iss": "<DEVICE_JWT_ISS>", "ver": 1 }
```

`DEVICE_JWT_ISS` defaults to `"lumos-auth"`. `uid` carries the **raw** Clerk user ID — so the WS gateway just compares `devices.user_id == jwt.uid`, no Clerk call at connect.

`verify_device_jwt(token) -> dict` ([device_jwt.py:55-87](../../Smart-Tutor-Lamp-backend/app/services/device_jwt.py#L55)):
1. `jose.jwt.decode(token, secret, algorithms=["HS256"], issuer=DEVICE_JWT_ISS, options={"verify_exp": False, "require_iat": True})`. **`verify_exp=False`** opts out of expiry (none is issued); **`require_iat=True`** mandates `iat`. A `JWTError` (bad signature / wrong issuer / malformed) → `InvalidDeviceJwt("jwt decode failed: …")`.
2. **Version drift:** `claims.get("ver", 0) < JWT_VERSION` → `InvalidDeviceJwt("jwt protocol version too old …")`.
3. Missing `sub` or `uid` → `InvalidDeviceJwt("jwt missing sub or uid")`.
4. Returns claims. The caller MUST additionally check `devices.user_id == claims['uid']` and `devices.revoked_at IS NULL` (runtime state, not cryptographic facts).

---

## 10. Pairing — code generation & full flow

### 10.1 Code generation ([services/pairing.py](../../Smart-Tutor-Lamp-backend/app/services/pairing.py))

- `PAIRING_ALPHABET = string.ascii_uppercase + string.digits` → `A-Z0-9`, **36 chars** ([pairing.py:14](../../Smart-Tutor-Lamp-backend/app/services/pairing.py#L14)).
- `PAIRING_CODE_LEN = 6` → keyspace **36⁶ ≈ 2.1 billion** ([pairing.py:15](../../Smart-Tutor-Lamp-backend/app/services/pairing.py#L15)).
- `generate_pairing_code()` ([pairing.py:18](../../Smart-Tutor-Lamp-backend/app/services/pairing.py#L18)) — `"".join(secrets.choice(PAIRING_ALPHABET) for _ in range(6))` using the **CSPRNG** `secrets`. With the 5-min TTL + rate limits, collision risk is essentially zero, but the route still collision-checks.
- `pretty_code(code)` ([pairing.py:23](../../Smart-Tutor-Lamp-backend/app/services/pairing.py#L23)) — display form `ABC-123` (TFT shows this; the backend accepts only the raw 6-char form, so callers strip the dash).

### 10.2 `POST /api/device/register` ([device_lamp.py:40-148](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L40))

Lamp-facing, public, idempotent. Rate limit `@limiter.limit("30/hour")` (firmware re-registers ~12/hr at the 5-min TTL plus reboots — 10/hr would 429 a lamp left on the QR screen). Returns `DeviceRegisterOut`.

Control flow:
1. **Opportunistic global housekeeping:** `DELETE FROM pairing_codes WHERE expires_at < now()` ([device_lamp.py:63](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L63)) — a cheap self-healing sweep (no cron) since `/register` is infrequent.
2. `device = db.get(Device, body.device_id)`.
3. **First boot** (`device is None`): create `Device(device_id, device_secret_hash=hash_secret(secret))`, `db.add`, `db.flush()`. No user yet.
4. **Existing device:** `verify_secret(hash, secret)`; mismatch → `401 DEV_AUTH_FAIL`.
5. **Recovery path** — if `device.user_id is not None and device.revoked_at is None` (already paired and active, but the lamp is calling `/register` without a usable JWT — lost it / NVS wipe / polls failed): delete any stale pending codes for the device, **re-mint a fresh `device_jwt` for the SAME user**, commit, and return `DeviceRegisterOut(status="already_paired", device_jwt=token)`. This guarantees a paired lamp always leaves the QR screen rather than being stranded by a 409. (A revoked/unlinked device has `user_id=NULL` here and falls through to normal pending/QR re-pair.)
6. **One live code per device:** `DELETE FROM pairing_codes WHERE device_id = …` ([device_lamp.py:113](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L113)) — without this, an old QR photographed earlier could still pair until its TTL. After this, exactly one code is ever valid per device.
7. **Code allocation with collision retry:** loop up to **8** times — `generate_pairing_code()`, check `db.get(PairingCode, code)`; on no clash, break. If all 8 collide (effectively never) → `500 INTERNAL` ([device_lamp.py:117-126](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L117)).
8. Insert `PairingCode(code, device_id, user_id=None, status="pending", device_jwt=None, expires_at=now()+PAIRING_CODE_TTL_SEC)`; commit.
9. Build `pairing_url = f"{FRONTEND_BASE_URL.rstrip('/')}/pair/{code}"` and return `{pairing_code, pairing_url, expires_in=PAIRING_CODE_TTL_SEC}` (status defaults `"pending"`).

### 10.3 `POST /api/device/poll-pairing` ([device_lamp.py:151-206](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L151))

Lamp-facing, public, polled every 3 s. Rate limit `@limiter.limit("40/minute")` (lamp polls ~20/min for the full 5-min TTL; 40/min leaves headroom for a couple lamps behind one NAT). Returns `DevicePollOut`.

1. `device = db.get(Device, body.device_id)`; if `None` **or** `not verify_secret(...)` → `401 DEV_AUTH_FAIL`.
2. `pc = db.get(PairingCode, body.pairing_code)`; `None` → `404 CODE_NOT_FOUND`.
3. **Don't leak cross-device existence:** if `pc.device_id != body.device_id` → `404 CODE_NOT_FOUND`.
4. If `pc.expires_at < now()` → delete the row (lazy cleanup), commit, return `{status: "expired"}`.
5. If `status == "pending"` → `{status: "pending"}`.
6. If `status == "paired"` → read `pc.device_jwt or ""`, **delete the row** (single-use), commit, return `{status: "paired", device_jwt: token}`. Subsequent polls 404 and the lamp stops.
7. Defensive default (any other status) → `{status: "expired"}`.

### 10.4 `GET /api/pairing-info/{code}` ([routes/pairing_info.py](../../Smart-Tutor-Lamp-backend/app/routes/pairing_info.py))

Frontend-facing but **public** (the `/pair/[code]` page enforces login via Clerk middleware; the endpoint stays public so a logged-out landing gets a clean 404/410 instead of leaking auth shape). Returns `PairingInfoOut`.

1. `pc = db.get(PairingCode, code)`; `None` → `404 CODE_NOT_FOUND`.
2. `pc.expires_at < now(utc)` → `410 CODE_EXPIRED`.
3. `device = db.get(Device, pc.device_id)`; `None` → `404 CODE_NOT_FOUND` (defensive — cascade should prevent the pairing row outliving its device).
4. If `device.user_id is not None and device.revoked_at is None` → `409 ALREADY_PAIRED`.
5. Return `{device_id, friendly_name, expires_at}`.

### 10.5 `POST /api/device/complete-pairing` ([device_user.py:51-122](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L51))

Frontend-facing, **Clerk-authed** (`Depends(current_clerk_user)`), rate limit `@limiter.limit("30/hour")`. This is where the binding happens, transactionally with a row lock. Returns `CompletePairingOut`.

1. Stash `request.state.clerk_user_id` (for the limiter key + audit).
2. `pc = db.get(PairingCode, body.pairing_code)`; `None` → `404 CODE_NOT_FOUND`. `pc.expires_at < now()` → `410 CODE_EXPIRED`.
3. **Lock the device row:** `SELECT … FROM devices WHERE device_id = pc.device_id FOR UPDATE` (`with_for_update()`) → serializes concurrent `/complete-pairing` calls (the §10 edge-case-2 race). `None` → `404 CODE_NOT_FOUND`.
4. **Ownership/conflict:** if `device.user_id is not None and device.revoked_at is None`:
   - same user re-claiming → allowed (mint a fresh JWT);
   - different user → `409 ALREADY_PAIRED`.
5. Set `device.user_id = clerk_user_id`, `device.paired_at = now()`, `device.revoked_at = None`.
6. `token = sign_device_jwt(device.device_id, clerk_user_id)`; write into the pairing row: `pc.user_id = clerk_user_id`, `pc.status = "paired"`, `pc.device_jwt = token`.
7. `db.commit()`.
8. Fire-and-forget audit: `log_event(device_id, clerk_user_id, "paired", {"friendly_name": …})`.
9. Return `{device_id, friendly_name}`.

The lamp's **next 3-s poll** then sees `status="paired"`, receives the JWT, and the pairing row is deleted (§10.3 step 6).

### 10.6 The end-to-end pairing sequence

```mermaid
sequenceDiagram
    autonumber
    participant Lamp
    participant BE as Python backend
    participant FE as Next.js frontend
    participant CK as Clerk
    participant U as User

    Lamp->>BE: POST /api/device/register {device_id, device_secret}
    Note over BE: sweep expired codes · upsert device (argon2id)<br/>drop stale codes · gen pairing_code (36^6, TTL 300s)
    BE-->>Lamp: 200 {pairing_code, pairing_url, expires_in=300}
    Lamp->>Lamp: render QR of pairing_url on TFT
    loop every 3s until paired/expired
        Lamp->>BE: POST /api/device/poll-pairing {id, secret, code}
        BE-->>Lamp: {status:"pending"}
    end
    U->>FE: scan QR → open /pair/[code]
    FE->>CK: Clerk middleware — signed in?
    CK-->>FE: session (after sign-in if needed)
    FE->>BE: GET /api/pairing-info/{code} (public)
    BE-->>FE: 200 {device_id, friendly_name, expires_at}
    U->>FE: click "Link this lamp"
    FE->>BE: POST /api/device/complete-pairing (Bearer Clerk token) {pairing_code}
    BE->>CK: current_clerk_user → verify (JWKS, cached 30s)
    CK-->>BE: payload.sub = clerk_user_id
    Note over BE: SELECT device FOR UPDATE<br/>set user_id/paired_at, revoked_at=NULL<br/>sign_device_jwt → pc.status="paired", pc.device_jwt=jwt<br/>commit · log_event "paired"
    BE-->>FE: 200 {device_id, friendly_name}
    Lamp->>BE: POST /api/device/poll-pairing (next tick)
    Note over BE: status="paired" → read jwt · DELETE pairing row
    BE-->>Lamp: {status:"paired", device_jwt:"eyJ…"}
    Lamp->>Lamp: NVS save device_jwt · clear QR
    Lamp->>BE: WSS connect Authorization: Bearer <device_jwt>
    Note over BE: verify_device_jwt + DB row check → accept
```

### 10.7 `/devices`, `/unlink`, `/rename` ([device_user.py:125-238](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L125))

All Clerk-authed; ownership enforced by `device.user_id == clerk_user_id`.

- `GET /api/devices` (`60/minute`) — `SELECT … WHERE user_id = clerk_user_id AND revoked_at IS NULL ORDER BY paired_at DESC NULLS LAST`. Each item's `online = bool(last_seen_at and (now - last_seen_at) <= ONLINE_WINDOW)`, where `ONLINE_WINDOW = timedelta(seconds=60)` ([device_user.py:48](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L48)).
- `POST /api/device/{id}/unlink` (`60/minute`, 204) — `404 NOT_FOUND` if missing; `403 NOT_OWNER` if `user_id != clerk_user_id`. Else set `revoked_at = now()`, `user_id = None`, commit; **`publish_revoked(device_id)`** (fire-and-forget Redis signal); `clear_history(device_id)` (wipe short-term history so the next owner can't see prior turns); `log_event(…, "unlinked", {})`.
- `POST /api/device/{id}/rename` (`60/minute`, 200) — same 404/403 guards; `device.friendly_name = body.friendly_name.strip()`, commit, return `{device_id, friendly_name}`.

---

## 11. WebSocket gateway device auth (the lamp connect path)

File: [routes/ws_lamp.py](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py), endpoint `@router.websocket("/lamp/ws")` ([ws_lamp.py:175](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L175)). This is the **device_jwt** auth path (distinct from the Clerk WS in §6).

Constants:
- `WS_CLOSE_BAD_JWT = 4401` — invalid/expired device_jwt ([ws_lamp.py:48](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L48)).
- `WS_CLOSE_UNLINKED = 4402` — device unlinked ([ws_lamp.py:49](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L49)).
- `HEARTBEAT_S = 30.0` — last_seen bump + revoke re-check cadence ([ws_lamp.py:53](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L53)).
- `WS_IDLE_TIMEOUT_S = 600.0` — 10-min idle backstop (the lamp legitimately sends no app frame while idle; uvicorn ping/pong is the primary dead-TCP detector) ([ws_lamp.py:66](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L66)).

`_extract_bearer(authz)` ([ws_lamp.py:69](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L69)) — splits on whitespace; expects exactly `["bearer", "<jwt>"]` (case-insensitive scheme); else `""`.

Two auth modes by `settings.ENABLE_AUTH`:
- **Dev** (`_authenticate_dev` [ws_lamp.py:78](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L78)): returns `("dev-lamp", None, None)` regardless of the Bearer — turns persist with `user_id=NULL`.
- **Prod** (`_authenticate_prod` [ws_lamp.py:84-132](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L84)):
  1. Empty JWT → `(None, None, 4401)`.
  2. `verify_device_jwt(jwt)`; `InvalidDeviceJwt` → warn + `(None, None, 4401)`.
  3. Extract `device_id = claims["sub"]`, `uid = claims["uid"]`.
  4. Open a fresh session, `row = db.get(Device, device_id)`, and reject (`(None, None, 4402)`) if `row is None OR row.user_id is None OR row.revoked_at is not None OR row.user_id != uid` — i.e. unknown / unpaired / revoked / wrong-user (the §6.4 step 4-5 check).
  5. On accept: `row.last_seen_at = now()`, commit; return `(device_id, uid, None)`.

Connection lifecycle ([ws_lamp.py:175-294](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L175)):
- If auth failed, `ws.close(code=fail_code or 4401)` and return (no `accept`).
- Else `ws.accept()`, build `Session(device_id, ws, user_id=user_id)`, `open_session(...)` for the DB session row, `log_event(…, "ws_open", …)`.
- **Prod side-tasks:** `watch_revocation(device_id, _on_revoked)` (closes 4402 on a Redis revoke message) and `_heartbeat(device_id, ws, stop)`.
- `_heartbeat` ([ws_lamp.py:135-159](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L135)) every `HEARTBEAT_S`: re-`get(Device)`; if `row is None or revoked_at is not None or user_id is None` → `_close_unlinked(ws)` and return; else bump `last_seen_at`. This is the **Redis-down fallback** for revocation (≤ 30 s).
- `_close_unlinked(ws)` ([ws_lamp.py:162](../../Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L162)): best-effort send `STATE(0x05 UNPAIRED)` so the lamp wipes its JWT locally before its WS lib surfaces the close, then `ws.close(code=4402)`.
- Main loop uses `asyncio.wait_for(ws.receive_bytes(), timeout=WS_IDLE_TIMEOUT_S)`. On idle timeout it re-arms if a turn is in flight or there's been recent activity (`session.has_active_turn() or session.seconds_idle() < WS_IDLE_TIMEOUT_S`); otherwise closes 1000. Malformed frames are logged + dropped (socket stays open); a raising frame handler is caught (socket stays open).
- `finally`: `stop.set()`, cancel side-tasks, `log_event(…, "ws_close", …)`, `finalize_session(...)`, `session.close()`.

---

## 12. Token revocation (Redis pub/sub + DB)

File: [services/revocation.py](../../Smart-Tutor-Lamp-backend/app/services/revocation.py). The canonical revocation signal is **`devices.revoked_at`** in Postgres; Redis pub/sub only accelerates propagation to sub-second.

- `CHANNEL_PREFIX = "device:revoked:"`; `channel_for(device_id) = f"device:revoked:{device_id}"` ([revocation.py:39,44](../../Smart-Tutor-Lamp-backend/app/services/revocation.py#L39)).
- The `redis` import is **optional** ([revocation.py:29-35](../../Smart-Tutor-Lamp-backend/app/services/revocation.py#L29)) so dev without the package still imports the module.

`init_redis()` ([revocation.py:48-100](../../Smart-Tutor-Lamp-backend/app/services/revocation.py#L48)) — called on FastAPI startup ([main.py:108-109](../../Smart-Tutor-Lamp-backend/app/main.py#L108)). No-op (warn) if `REDIS_URL` unset or `redis` not installed. Otherwise builds a client with resilience config: `decode_responses=True`, `socket_keepalive=True`, `socket_connect_timeout=5`, `socket_timeout=5`, `health_check_interval=30`, `retry_on_timeout=True` (dropped on a `TypeError` from a future redis-py that removed the kwarg, keeping the core resilience). Then an **eager `ping()`** surfaces misconfig at boot; a failed ping sets `_client = None` (fan-out disabled). `dispose_redis()` ([revocation.py:103](../../Smart-Tutor-Lamp-backend/app/services/revocation.py#L103)) `aclose()`s on shutdown ([main.py:130-131](../../Smart-Tutor-Lamp-backend/app/main.py#L130)).

`publish_revoked(device_id)` ([revocation.py:117-126](../../Smart-Tutor-Lamp-backend/app/services/revocation.py#L117)) — fire-and-forget; if `_client is None` returns silently; on Redis error logs and continues. **Never raises** (the DB write is the truth). Publishes the literal `"1"`.

`watch_revocation(device_id, on_revoked)` ([revocation.py:129-184](../../Smart-Tutor-Lamp-backend/app/services/revocation.py#L129)) — started per WS connection as a task, cancelled on close:
- If `_client is None` returns (poll fallback only).
- Subscribes to `channel_for(device_id)`, then loops `pubsub.get_message(ignore_subscribe_messages=True, timeout=15.0)`.
- Crucial detail: an **idle pub/sub channel trips the connection's `socket_timeout` as a read-timeout** every few seconds — this is **expected, not a failure**. On `RedisError`/`OSError` it sleeps 0.5 s and re-arms (it does NOT die on the first idle read). `CancelledError` propagates.
- Any data message (only `"1"` is ever published) → `await on_revoked()` (which calls `_close_unlinked`) and returns.
- `finally` unsubscribes + `aclose()`s the pubsub object.

```mermaid
flowchart LR
  subgraph Triggers
    U[Frontend Unlink] --> W1[device_user.unlink_device]
    H[Clerk user.deleted] --> W2[clerk_webhook]
  end
  W1 --> R[set revoked_at=now, user_id=NULL · commit]
  W2 --> R
  R --> P[publish_revoked device:revoked:id]
  P --> RD[(Redis pub/sub)]
  RD --> WW[watch_revocation per live WS]
  WW --> C[_close_unlinked: STATE 0x05 + close 4402]
  R -.Redis down fallback.-> HB[_heartbeat 30s re-reads revoked_at] --> C
```

Degradation: if Redis is down, `publish_revoked` no-ops and `watch_revocation` returns immediately, but the 30-s `_heartbeat` re-reads `devices.revoked_at` and closes 4402 within ≤ 30 s. Revocations stay **correct**, just slower.

---

## 13. Clerk lifecycle webhook (Svix)

File: [routes/clerk_webhook.py](../../Smart-Tutor-Lamp-backend/app/routes/clerk_webhook.py), `POST /api/clerk/webhook`. The Svix signature is the only thing between an attacker and a free user-deletion exploit, so **verify first, then work**.

1. If `CLERK_WEBHOOK_SECRET` unset → `503 AUTH_DISABLED` (refuse to silently accept unsigned events).
2. Import `svix.webhooks`; missing → `503 AUTH_SDK_MISSING`.
3. Read raw `payload = await request.body()`.
4. Require headers `svix-id`, `svix-timestamp`, `svix-signature`; a `KeyError` → `400 WEBHOOK_BAD_HEADERS` (message names the missing header).
5. `Webhook(CLERK_WEBHOOK_SECRET).verify(payload, headers)` → on `WebhookVerificationError` → `400 WEBHOOK_BAD_SIG` (warn-logged).
6. Extract `event_type` and `data` defensively (`event` may be a dict).
7. **`user.deleted`** ([clerk_webhook.py:80-110](../../Smart-Tutor-Lamp-backend/app/routes/clerk_webhook.py#L80)):
   - `clerk_user_id = data.get("id")`; missing → log + `{"ok": True}` (don't bounce Clerk).
   - `SELECT Device WHERE user_id = clerk_user_id`; for each row set `revoked_at = now()`, `user_id = None`, collect `device_id`s; `db.commit()`.
   - For each revoked id: `publish_revoked(device_id)` (snap live sockets to 4402) and `clear_history(device_id)` (the account is gone; its conversation must not survive a future re-pair).
   - Return `{"ok": True, "revoked": <n>}`.
8. **`user.created` / `user.updated` / anything else** → `{"ok": True}` (accept silently so Clerk doesn't retry). The webhook is **not rate-limited** (it's signature-verified).

---

## 14. Rate limiting (slowapi)

File: [deps/rate_limit.py](../../Smart-Tutor-Lamp-backend/app/deps/rate_limit.py). A single module-singleton `Limiter`, registered in `main.py` as `app.state.limiter` with the `RateLimitExceeded` handler `_rate_limit_exceeded_handler` ([main.py:140-142](../../Smart-Tutor-Lamp-backend/app/main.py#L140)).

Limiter config ([rate_limit.py:26-53](../../Smart-Tutor-Lamp-backend/app/deps/rate_limit.py#L26)):
- `key_func = get_remote_address` — keys by **remote IP** for all endpoints. (The spec's per-`device_id`/per-user keying is documented as a stronger guard, but reading the JSON body inside a sync slowapi key_func is fragile across starlette versions; remote-IP is a good proxy because each lamp sits behind its own NAT.)
- `storage_uri = settings.REDIS_URL or "memory://"` — shared buckets across uvicorn workers when Redis is set, else in-memory (fine for single-worker dev).
- `headers_enabled = False` — MUST stay False unless every limited endpoint declares a `response: Response` param; otherwise slowapi's `_inject_headers` 500s on the pydantic/None return values. Limiting works either way; this only drops the informational `X-RateLimit-*` headers.
- **Fail-open on Redis trouble:** `swallow_errors=True` (a storage error allows the request rather than 500-ing) and `in_memory_fallback_enabled=True` (degrade to local buckets when Redis is unreachable). This prevents the cascade where a 500 skips CORSMiddleware → browser reports a bogus CORS error → the whole frontend bricks.
- `storage_options={"socket_connect_timeout": 1, "socket_timeout": 1}` — short timeouts so a dead Redis fails in ~1 s instead of hanging ~5 s before falling back (ignored by `memory://`).

Per-endpoint limits as actually applied via decorators:

| Endpoint | Decorator | Source |
|---|---|---|
| `POST /api/device/register` | `30/hour` | [device_lamp.py:47](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L47) |
| `POST /api/device/poll-pairing` | `40/minute` | [device_lamp.py:159](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L159) |
| `POST /api/device/complete-pairing` | `30/hour` | [device_user.py:56](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L56) |
| `GET /api/devices` | `60/minute` | [device_user.py:130](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L130) |
| `POST /api/device/{id}/unlink` | `60/minute` | [device_user.py:165](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L165) |
| `POST /api/device/{id}/rename` | `60/minute` | [device_user.py:214](../../Smart-Tutor-Lamp-backend/app/routes/device_user.py#L214) |
| `POST /api/clerk/webhook` | none | (signature-verified) |
| `GET /api/pairing-info/{code}` | none | (public, read-only) |

> Note: the **applied** decorator values differ from the spec table in [IMPLEMENTATION_AUTH_PAIRING.md §6.5](../../Smart-Tutor-Lamp-backend/IMPLEMENTATION_AUTH_PAIRING.md) (which suggested 10/hr register and 60/5min poll). The code comments explain why the real values were raised: 10/hr would 429 a lamp left on the QR screen; 60/5min (one per 5 s) would strand a 3-s poll loop ~3 min in.

The `@limiter.limit` wrapper also forces a notable workaround: `device_lamp.py` and `device_user.py` **omit** `from __future__ import annotations` because that makes FastAPI resolve stringized body annotations against slowapi's globals and misclassify `body: …In` as a query param (422) ([device_lamp.py:10-13](../../Smart-Tutor-Lamp-backend/app/routes/device_lamp.py#L10)).

---

## 15. Configuration, env vars, constants

From [config.py](../../Smart-Tutor-Lamp-backend/app/config.py) (`pydantic-settings`, `.env`-driven, `extra="ignore"`):

| Var | Default | Effect |
|---|---|---|
| `ENABLE_AUTH` | `False` | Master toggle. False = dev bypass (WS accepts any Bearer as `dev-lamp`, pairing routes NOT mounted). True = full Clerk + device_jwt flow ([config.py:297](../../Smart-Tutor-Lamp-backend/app/config.py#L297)). |
| `DEVICE_JWT_SECRET` | `""` | HS256 signing key for `device_jwt`. Generate with `openssl rand -base64 64`. Rotating invalidates every lamp's JWT → forces re-pair. Unset → `RuntimeError` on mint/verify ([config.py:302](../../Smart-Tutor-Lamp-backend/app/config.py#L302)). |
| `DEVICE_JWT_ISS` | `"lumos-auth"` | `iss` claim, enforced on verify ([config.py:303](../../Smart-Tutor-Lamp-backend/app/config.py#L303)). |
| `CLERK_SECRET_KEY` | `""` | Server-side Clerk session verification (HTTP path). Empty → `503 AUTH_DISABLED` ([config.py:307](../../Smart-Tutor-Lamp-backend/app/config.py#L307)). |
| `CLERK_WEBHOOK_SECRET` | `""` | Svix signing secret. Empty → webhook 503 ([config.py:308](../../Smart-Tutor-Lamp-backend/app/config.py#L308)). |
| `CLERK_PUBLISHABLE_KEY` | `""` | `pk_<env>_<base64(host$)>`; the WS path derives JWKS URL + issuer from it ([config.py:316](../../Smart-Tutor-Lamp-backend/app/config.py#L316)). |
| `CLERK_JWKS_URL` | `""` | Override the derived JWKS URL (WS path) ([config.py:317](../../Smart-Tutor-Lamp-backend/app/config.py#L317)). |
| `CLERK_ISSUER` | `""` | Override the derived issuer (WS path) ([config.py:318](../../Smart-Tutor-Lamp-backend/app/config.py#L318)). |
| `FRONTEND_BASE_URL` | `http://localhost:3000` | The host embedded in `pairing_url`; also seeds `azp`. Keep short for crisp QR ([config.py:329](../../Smart-Tutor-Lamp-backend/app/config.py#L329)). |
| `PAIRING_CODE_TTL_SEC` | `300` | Pairing-code TTL + the `expires_in` returned to the lamp ([config.py:332](../../Smart-Tutor-Lamp-backend/app/config.py#L332)). |
| `CORS_ALLOWED_ORIGINS` | `http://localhost:3000` | Comma-separated; mirrored into the `azp` allowlist ([config.py:349](../../Smart-Tutor-Lamp-backend/app/config.py#L349)). |
| `REDIS_URL` | `""` | Single switch for rate-limit shared storage + revocation pub/sub. Empty → in-memory buckets + 30 s heartbeat revocation fallback ([config.py:228](../../Smart-Tutor-Lamp-backend/app/config.py#L228)). |
| `ADMIN_USER_IDS` / `ADMIN_EMAILS` | `""` | **DEPRECATED / ignored** — admin is governed solely by the `admins` table ([config.py:344-345](../../Smart-Tutor-Lamp-backend/app/config.py#L344)). |

Code-level constants (not env): `_VERIFY_TTL_SEC=30.0`, `_VERIFY_CACHE_MAX=1024` (clerk.py); `leeway=10`, future-iat tolerance `+30` (clerk_ws.py); `JWT_VERSION=1`, `ALG="HS256"` (device_jwt.py); `PAIRING_ALPHABET` (36), `PAIRING_CODE_LEN=6` (pairing.py); collision-retry `range(8)` (device_lamp.py); `ONLINE_WINDOW=60s` (device_user.py); `WS_CLOSE_BAD_JWT=4401`, `WS_CLOSE_UNLINKED=4402`, `HEARTBEAT_S=30.0`, `WS_IDLE_TIMEOUT_S=600.0` (ws_lamp.py); `CHANNEL_PREFIX="device:revoked:"`, pubsub `timeout=15.0`, socket timeouts `5`, `health_check_interval=30` (revocation.py); rate-limit `socket_*_timeout=1` (rate_limit.py).

---

## 16. Edge cases, error handling, timeouts, fallbacks

- **Auth disabled but route called.** `current_clerk_user` returns `503 AUTH_DISABLED`; pairing routes aren't even mounted in dev (clean 404). Webhook with no secret → `503 AUTH_DISABLED`.
- **Missing SDKs.** clerk-backend-api → `503 AUTH_SDK_MISSING`; pyjwt (WS) → `WsAuthError` → close 4401; svix → `503 AUTH_SDK_MISSING`; argon2 only imported lazily.
- **Clock drift.** WS Clerk path allows `leeway=10` and rejects tokens with `iat > now+30`. The backend assumes correct NTP-synced wall clock (assumption A7); the lamp clock is **not** trusted, which is why `device_jwt` has no `exp`.
- **Stale / replayed pairing codes.** `/register` deletes all prior codes for the device (one live code rule) + sweeps all expired codes; `/poll-pairing` and `/pairing-info` treat `expires_at < now` as expired (410/`expired`); `/poll-pairing` deletes the row once `paired` (single-use). A code paired to a different device returns 404 (no existence leak).
- **Concurrent claim race.** `/complete-pairing` does `SELECT … FOR UPDATE` on the device row, serializing concurrent claims; a second user gets `409 ALREADY_PAIRED`, the same user re-claiming gets a fresh JWT.
- **Lamp lost its JWT but is still paired.** `/register` recovery path re-mints a JWT for the same user (`status="already_paired"`) instead of 409, so the lamp always leaves the QR screen.
- **Revoked/unlinked lamp reconnects.** WS `_authenticate_prod` rejects (`revoked_at IS NOT NULL` or `user_id IS NULL` or `user_id != uid`) with 4402; the lamp wipes its JWT and re-enters pairing.
- **Verify-cache vs revocation.** A revoked Clerk session is honored for ≤ 30 s (HTTP verify cache TTL). Device revocation is sub-second via Redis, ≤ 30 s via heartbeat if Redis is down.
- **Redis unreachable.** Rate limiter fails **open** (`swallow_errors` + in-memory fallback, 1 s timeouts). Revocation fan-out disabled but DB truth + 30 s heartbeat keep it correct. `watch_revocation` treats idle read-timeouts as normal and self-heals.
- **Corrupt argon2 hash.** `verify_secret` returns `False` (logged), never raises.
- **Admin lookup on a poisoned txn.** `is_admin` retries on a fresh session; double failure → fail-closed (deny).
- **WS resilience.** Malformed lamp frames and raising frame handlers are logged and dropped without closing the socket; idle timeout re-arms during active turns / recent traffic; 10-min backstop only closes a genuinely wedged socket (close 1000, lamp reconnects).
- **Webhook robustness.** `user.deleted` with no `data.id` → `{"ok": True}` (no bounce); unknown events → 200 silently to avoid Clerk retries.

---

## 17. Integration points & cross-references

**What this subsystem calls:**
- `app.db.session.get_db` / `get_session_factory` — async SQLAlchemy sessions.
- `app.db.models.Device` / `PairingCode` / `Admin` — the data.
- `app.services.memory.clear_history` — wipe short-term history on unlink / account delete.
- `app.storage.events.log_event` — fire-and-forget audit (`paired`, `unlinked`, `ws_open`, `ws_close`).
- `app.storage.turns.open_session` + `app.services.session_memory.finalize_session` — WS session lifecycle.
- `app.protocol` (`FrameType`, `StateByte`, `encode`) — the `STATE(0x05 UNPAIRED)` bye-byte on revoke.
- External: Clerk (`clerk-backend-api` SDK + JWKS), `pyjwt` (WS), `python-jose` (`jose`), `argon2-cffi`, `svix`, `slowapi`, `redis.asyncio`.

**What calls this subsystem:**
- **Firmware (ESP32)** — `provisioning::ensure_paired()` POSTs `/register` then polls `/poll-pairing`, saves `device_jwt` to NVS, then `net_ws` connects WSS with `Authorization: Bearer <device_jwt>` ([IMPLEMENTATION_AUTH_PAIRING.md §8](../../Smart-Tutor-Lamp-backend/IMPLEMENTATION_AUTH_PAIRING.md)). The lamp never touches Clerk.
- **Frontend (Next.js + Clerk)** — `/pair/[code]` → `GET /pairing-info` + `POST /complete-pairing`; `/devices` → `GET /devices`, `/rename`, `/unlink`; all with `Authorization: Bearer <Clerk session token>` via `getToken()`. The brain-bench page opens `/api/frontend/ws?token=<Clerk JWT>` ([frontend_manager.py:1920](../../Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1920)). The `/admin` dashboard hits `require_admin`-gated routes.
- **Clerk** — fires Svix-signed `user.*` webhooks to `POST /api/clerk/webhook`.
- **`main.py`** — mounts the routers only when `ENABLE_AUTH=True` ([main.py:258-272](../../Smart-Tutor-Lamp-backend/app/main.py#L258)); registers the limiter + 429 handler ([main.py:140-142](../../Smart-Tutor-Lamp-backend/app/main.py#L140)); calls `init_redis()`/`dispose_redis()` on startup/shutdown ([main.py:108,130](../../Smart-Tutor-Lamp-backend/app/main.py#L108)); installs `CORSMiddleware`.
- **DB / admin analytics** — `health_snapshot` counts `devices_paired` (`user_id IS NOT NULL AND revoked_at IS NULL`), `devices_revoked`, `online_devices`, `pairing_codes_live` ([services/admin.py:210-232](../../Smart-Tutor-Lamp-backend/app/services/admin.py#L210)).

---

## 18. File-by-file / function-by-function reference

### `app/deps/clerk.py` (HTTP Clerk auth)
- `_resolve_auth_symbols()` — one-time cross-version SDK symbol resolution.
- `_get_clerk_client()` — lazy `Clerk` client; 503 on missing key/SDK.
- `_bearer_token(request)` — parse `Authorization: Bearer`.
- `_cache_get` / `_cache_put` — 30 s per-token verified-payload cache; clears wholesale at 1024 entries.
- `_authorized_parties()` (`@lru_cache`) — `azp` allowlist mirroring CORS + localhost/127.0.0.1 twins.
- `_verify_clerk(request)` — threadpool JWKS+RSA verify; 401 on failure, logs `state.reason`.
- `current_clerk_user(request)` → `str` — the dependency; cache-aware, per-token locked; stashes `request.state.clerk_payload`.

### `app/deps/clerk_ws.py` (WebSocket Clerk auth)
- `WsAuthError`, `_derive_host`, `_jwks_url`, `_issuer`, `_client` (cached `PyJWKClient`).
- `verify_ws_token(token)` → `str` — RS256 decode against public JWKS; requires `sub/exp/iat`; `leeway=10`; future-iat guard; returns `sub`.

### `app/deps/admin.py`
- `require_admin(...)` → `str` — `current_clerk_user` + `is_admin`; 403 `NOT_ADMIN`.

### `app/deps/device_auth.py`
- `_get_hasher()` — lazy argon2id PasswordHasher (t=3, m=64 MiB, p=4).
- `hash_secret(secret)` / `verify_secret(stored_hash, candidate)` — constant-time, never-raises verify.

### `app/deps/rate_limit.py`
- `limiter` — slowapi `Limiter` keyed by IP, Redis-or-memory storage, fail-open, 1 s socket timeouts.

### `app/services/device_jwt.py`
- `ALG`, `JWT_VERSION`, `InvalidDeviceJwt`, `_require_secret`.
- `sign_device_jwt(device_id, clerk_user_id)` → HS256 token `{sub, uid, iat, iss, ver}` (no exp).
- `verify_device_jwt(token)` → claims; `verify_exp=False`, `require_iat=True`; version + sub/uid checks.

### `app/services/pairing.py`
- `PAIRING_ALPHABET` (36), `PAIRING_CODE_LEN` (6), `generate_pairing_code()` (CSPRNG), `pretty_code()`.

### `app/services/revocation.py`
- `channel_for`, `init_redis` (resilient client + eager ping), `dispose_redis`, `get_client`.
- `publish_revoked(device_id)` — fire-and-forget `"1"`, never raises.
- `watch_revocation(device_id, on_revoked)` — per-WS subscriber; idle-timeout tolerant; calls `on_revoked` on first message.

### `app/services/admin.py` (auth-relevant parts)
- `_primary_email_of`, `_clerk_email` (cached Clerk Backend API lookup), `_email_for` (JWT → profile → Clerk).
- `is_admin(db, user_id, jwt_email)` — admins-table lookup; fresh-session retry; fail-closed.

### `app/routes/device_lamp.py` (lamp-facing, public)
- `register(...)` — `30/hour`; sweep+upsert+recovery+one-live-code+collision-retry+mint code.
- `poll_pairing(...)` — `40/minute`; verify secret, lookup code, pending/paired(single-use)/expired.

### `app/routes/device_user.py` (frontend-facing, Clerk-authed)
- `complete_pairing(...)` — `30/hour`; `FOR UPDATE` device lock, bind + mint, write JWT into pairing row.
- `list_devices(...)` — `60/minute`; owner-scoped, 60 s online window.
- `unlink_device(...)` — `60/minute`; 204; revoke + publish + clear history + audit.
- `rename_device(...)` — `60/minute`; ownership-checked rename.

### `app/routes/pairing_info.py`
- `pairing_info(code, db)` — public; 404/410/409; returns `PairingInfoOut`.

### `app/routes/clerk_webhook.py`
- `clerk_webhook(request, db)` — Svix verify first; `user.deleted` cascade-revoke + publish + clear history; others 200.

### `app/routes/ws_lamp.py` (device_jwt gateway)
- `_extract_bearer`, `_authenticate_dev`, `_authenticate_prod` (jwt + DB row check), `_heartbeat` (30 s revoke re-check), `_close_unlinked` (STATE 0x05 + 4402), `lamp_ws` (full connection lifecycle, side-tasks, idle backstop).

### `app/schemas/auth.py`
- `DeviceRegisterIn/Out`, `DevicePollIn/Out`, `PairingInfoOut`, `CompletePairingIn/Out`, `DeviceListItem/Out`, `DeviceRenameIn/Out`, `ApiError`.

### `app/db/models.py` (auth tables)
- `Device`, `PairingCode`, `Admin` (+ partial indexes and the status CHECK constraint).

---

_Re-verified against backend db470f6 on 2026-07-06: no auth/pairing/security code has changed since this doc was written (last commits touching `app/deps/device_auth.py`, `app/services/pairing.py`, `app/routes/pairing_info.py`, `app/schemas/auth.py` date from 2026-05-26/28). The WS session hardening of 2026-07-04 (hard audio/image accumulator caps in `app/session.py`) is documented in docs 02 and 08._
