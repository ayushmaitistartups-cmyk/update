# Backend — TTS, Audio/Image Preprocessing & LaTeX Rendering

This is the definitive reference for the Smart Tutor Lamp backend's **media plane**: turning the LLM's `speech` field into paced 24 kHz audio the lamp speaker can play, making the lamp's raw microphone PCM and OV5640 JPEGs legible to the vision-LLM, rendering `latex_equations` into RGB565 frames the ESP32 TFT can paint, and reclaiming the per-turn blobs once they age out. Everything here is grounded in the actual code under `app/providers/` and `app/services/`. The unifying constraints are **latency** (first audio byte should reach the lamp ~700 ms after end-of-speech) and **cost/RAM** (a 512 MB free-tier host, paid Gemini audio tokens, a bandwidth-capped WAN), and every algorithm below is shaped by one or both.

---

## Table of Contents

1. [Purpose & Responsibilities](#1-purpose--responsibilities)
2. [Architecture Overview](#2-architecture-overview)
3. [TTS Subsystem](#3-tts-subsystem)
   - [3.1 The Abstract Provider & Factory (`tts_base.py`)](#31-the-abstract-provider--factory-tts_basepy)
   - [3.2 Gemini TTS Provider (`tts_gemini.py`)](#32-gemini-tts-provider-tts_geminipy)
   - [3.3 Piper TTS Provider (`tts_piper.py`)](#33-piper-tts-provider-tts_piperpy)
   - [3.4 Cartesia Provider (`tts_cartesia.py`) — LIVE](#34-cartesia-provider-tts_cartesiapy--live)
   - [3.5 Voice Assets (`audio-tts/`)](#35-voice-assets-audio-tts)
   - [3.6 The Wire Codec (PCM / ADPCM / Opus)](#36-the-wire-codec-pcm--adpcm--opus)
   - [3.7 How the Dispatcher Drives TTS](#37-how-the-dispatcher-drives-tts)
4. [Audio Preprocessing (`audio_preprocessor.py`)](#4-audio-preprocessing-audio_preprocessorpy)
5. [Image Preprocessing (`image_preprocessor.py` + `services/image_prep.py`)](#5-image-preprocessing)
   - [5.1 Tunables & Constants](#51-tunables--constants)
   - [5.2 Entry Point & Guards](#52-entry-point--guards)
   - [5.3 The OpenCV Pipeline](#53-the-opencv-pipeline-stage-by-stage)
   - [5.4 The PIL Fallback](#54-the-pil-fallback)
   - [5.5 Early Prep Service](#55-early-prep-service-servicesimage_preppy)
6. [LaTeX → RGB565 Rendering (+ Graph, Chemistry & the Scroll-Document model)](#6-latex--rgb565-rendering)
   - [6.1 The Engine (`latex_engine.py`)](#61-the-engine-latex_enginepy)
   - [6.2 The Wrapper (`latex_renderer.py`)](#62-the-wrapper-latex_rendererpy)
   - [6.3 Graph Rendering (`graph_renderer.py`)](#63-graph-rendering-graph_rendererpy--restored-end-to-end)
   - [6.4 Chemistry Structure Rendering (`rdkit_renderer.py`)](#64-chemistry-structure-rendering-rdkit_rendererpy--rdkit)
   - [6.5 The Scrollable-Document Composer (`document.py`)](#65-the-scrollable-document-composer-documentpy--the-assembly-list-tft-model)
7. [Media Cleanup & Retention (`services/media_cleanup.py`)](#7-media-cleanup--retention-servicesmedia_cleanuppy)
8. [Configuration Reference](#8-configuration-reference)
9. [Edge Cases, Errors, Timeouts, Fallbacks](#9-edge-cases-errors-timeouts-fallbacks)
10. [Integration Points](#10-integration-points)
11. [Diagrams](#11-diagrams)

---

## 1. Purpose & Responsibilities

This layer sits between the reasoning LLM and the lamp/ESP32 hardware. Its jobs:

| Responsibility | Module | Triggered by |
|---|---|---|
| Synthesise `reply.speech` → paced 24 kHz PCM | `tts_base`, `tts_gemini`, `tts_piper` | `dispatch._dispatch_audio_leg` |
| Wrap lamp mic PCM into a WAV container Gemini REST accepts | `audio_preprocessor` | `llm_gemini._drain` |
| Rectify/enhance camera JPEGs so the VLM can read handwriting | `image_preprocessor`, `services/image_prep` | `session._on_image_terminator`, orchestrator |
| Render `latex_equations` → RGB565 TFT frames | `latex_engine`, `latex_renderer` | `dispatch._dispatch_equations` |
| Render `graph` (GraphSpec) → color JPEG (interactive) | `graph_renderer` | `dispatch._graph_leg` |
| Render `structures` (SMILES) → color JPEG (chemistry page) | `rdkit_renderer` | `dispatch._dispatch_structure_leg` |
| Compose an ordered scroll-document (text+eq+graph+chem blocks) | `document` | `dispatch._dispatch_document_mode` |
| Compress the AUDIO_OUT stream for a capped WAN | `session.send_audio_out_chunk` (codec chokepoint) | every audio chunk |
| Delete aged per-turn blobs on admin demand | `services/media_cleanup` | `POST /api/frontend/admin/media/cleanup` |

The cross-cutting design rule everywhere in this layer is **fail-open / degrade-to-visual**: TTS failure → silent turn (text + LaTeX still ship); enhancement failure → original bytes sent; LaTeX render failure → placeholder frame. A media problem must **never crash a turn** ([tts_base.py:47](app/providers/tts_base.py#L47), [image_preprocessor.py:154](app/providers/image_preprocessor.py#L154)).

---

## 2. Architecture Overview

```
                    LLM JSON reply  { speech, display, latex_equations }
                                       │
              ┌────────────────────────┼─────────────────────────────┐
              ▼                        ▼                              ▼
      _dispatch_audio_leg       _dispatch_tft_leg(text)        _dispatch_equations
              │                                                      │
   get_tts_provider() ── factory (TTS_PROVIDER)            latex_renderer.render_*
        │        │                                                   │
   GeminiTts   PiperTts ── TTSService                       LatexRenderer (matplotlib)
        │        │                                                   │
   synthesize()  synthesize()  ── async iterator of 24 kHz PCM   RGB565 frames
        └────────┬───────┘                                          │
                 ▼                                                   ▼
   session.stream_audio_out_iter()                    session.send_tft_frame_chunked()
                 ▼                                                   ▼
   send_audio_out_chunk()  ── WIRE CODEC (pcm|adpcm|opus)    TFT_PART / TFT_FRAME frames
                 ▼                                                   ▼
            WebSocket  ───────────────────────────────────────►  ESP32 lamp
```

The **input side** (lamp → backend) runs the preprocessors:

```
FRAME_AUDIO_CHUNK (16 kHz int16 PCM)  ──► audio_preprocessor.wrap_pcm_as_wav ──► Gemini REST
FRAME_IMAGE_JPEG  (OV5640 JPEG)       ──► image_preprocessor.enhance_for_llm  ──► VLM
                                          (kicked off early by services/image_prep)
```

Key structural choices:
- **Streaming is the primitive.** Every provider implements `synthesize()` as an *async iterator* of PCM chunks, not `text -> bytes`. The buffered `generate_speech()` exists only for tests ([tts_base.py:60-87](app/providers/tts_base.py#L60)).
- **One env var swaps engines.** The factory pattern (`tts_base`) mirrors `llm_base` so `dispatch.py`/`frontend_manager.py` never import a concrete engine ([tts_base.py:125-187](app/providers/tts_base.py#L125)).
- **Lazy per-provider import = cost firewall.** Choosing `piper` never imports `tts_gemini`, so the Gemini client is never built and zero audio tokens can be spent ([tts_base.py:233-244](app/providers/tts_base.py#L233)).
- **The LaTeX engine is vendored into the backend** (a stripped copy of root `Latex_engine_tft.py`) so startup has no `sys.path` hacks ([latex_engine.py:1-19](app/providers/latex_engine.py#L1)).

---

## 3. TTS Subsystem

### 3.1 The Abstract Provider & Factory (`tts_base.py`)

This file defines the contract every engine honours and the factory that selects one.

**The wire contract** (module docstring, [tts_base.py:32-37](app/providers/tts_base.py#L32)):
> mono int16 LE PCM @ `settings.TTS_TARGET_SAMPLE_RATE` (24 kHz), delivered as chunks of ≤ `settings.TTS_CHUNK_BYTES` (4 KB) so each AUDIO_OUT frame stays under the lamp's ~4 KB DRAM ceiling.

**`class TTSError(RuntimeError)`** ([tts_base.py:47-51](app/providers/tts_base.py#L47)) — the single hard-failure exception. Defined here (not in a concrete provider) so every provider and every consumer imports the *same* type. Callers treat `TTSError` AND an empty stream identically: "no audio this turn".

**`class TtsProvider(ABC)`** ([tts_base.py:54-122](app/providers/tts_base.py#L54)):

| Member | Kind | Meaning |
|---|---|---|
| `name` | ClassVar str | short id used in `.env` (set by the registration decorator) |
| `synthesize(text, *, turn_id=None)` | abstract | yields 24 kHz mono int16 LE PCM in ≤ `TTS_CHUNK_BYTES` pieces as produced. Empty/whitespace → yield nothing; `TTSError` only on hard failure; propagate `CancelledError` unchanged ([tts_base.py:60-75](app/providers/tts_base.py#L60)) |
| `generate_speech(text)` | concrete default | drains `synthesize()` into one PCM blob — NOT the hot path ([tts_base.py:77-87](app/providers/tts_base.py#L77)) |
| `available` | property (True) | can it produce audio right now (key/model present)? |
| `target_sample_rate` | property | reads `settings.TTS_TARGET_SAMPLE_RATE` |
| `mode` | property | human label for logs |
| `incremental` | property (True) | does `synthesize()` yield PROGRESSIVELY within one call? **Drives dispatcher behaviour** — see §3.7 ([tts_base.py:108-117](app/providers/tts_base.py#L108)) |
| `warmup()` | async no-op | best-effort boot pre-warm |

**The factory** — module-level registries and functions:

- `_REGISTRY: dict[str, type[TtsProvider]]` and `_INSTANCE_CACHE: dict[str, TtsProvider]` ([tts_base.py:126-127](app/providers/tts_base.py#L126)).
- `register_tts_provider(name)` — parametrised decorator; each concrete provider self-registers under its `.env` id; rejects empty/`"abstract"` ([tts_base.py:130-146](app/providers/tts_base.py#L130)).
- `get_tts_provider(name=None)` — the main entry. Resolution: explicit arg → `settings.TTS_PROVIDER` → `"piper"` default. Returns **None** (never raises) on every "no audio" path: `""`/`"none"`/`"off"`, unknown id, or construction failure ([tts_base.py:149-187](app/providers/tts_base.py#L149)). Caches the instance so the SDK client / Piper voice is built **at most once per process**.
- `reset_tts_provider_cache()` — for tests / hot-reload ([tts_base.py:190-193](app/providers/tts_base.py#L190)).
- `list_tts_providers()` — diagnostics; imports *every* module ([tts_base.py:196-199](app/providers/tts_base.py#L196)).
- `clamp_tts_text(text)` — the **cost guard**: if `len(text) > TTS_MAX_INPUT_CHARS` (default 800), truncate at a word boundary (`text[:cap].rsplit(" ", 1)[0]`) and log loudly. `cap <= 0` → unchanged. Shared by every provider so the guard lives in exactly one place ([tts_base.py:202-222](app/providers/tts_base.py#L202)).

**Lazy import mechanics**: `_MODULE_FOR_NAME = {"gemini": "tts_gemini", "piper": "tts_piper", "cartesia": "tts_cartesia"}`. `_import_provider(name)` imports ONLY the chosen module so its `@register_tts_provider` decorator runs — this is the teeth behind "piper bypasses gemini": importing `tts_gemini` is what would register/build it, and that import only happens for the engine actually chosen. A missing optional SDK degrades to "not registered", not a crash.

> Note: `config.py` types `TTS_PROVIDER` as `Literal["gemini", "piper", "cartesia", "kokoro_local"]`. `gemini`, `piper`, and **`cartesia` (now live — the default lamp engine)** are all mapped in `_MODULE_FOR_NAME`; only `kokoro_local` remains a reserved placeholder (registers nothing → `get_tts_provider` returns None → silent/visual-only turn).

### 3.2 Gemini TTS Provider (`tts_gemini.py`)

The API-based, zero-local-infra option. A **still-supported alternative** to the default Cartesia lamp engine (`TTS_PROVIDER=gemini`).

**Why it's shaped this way** (three latency tricks, [tts_gemini.py:8-26](app/providers/tts_gemini.py#L8)):
1. **Shared warm client** — reuses the exact `genai.Client` the LLM path already opened (`llm_gemini._client_singleton`), so the HTTP/2 pool + TLS session are already warm; the TTS call pays no handshake ([tts_gemini.py:104-113](app/providers/tts_gemini.py#L104)).
2. **Optional streaming** (`GEMINI_TTS_STREAM`, default `False` → UNARY) — when enabled, pulls audio parts off `generate_content_stream` and yields them the instant they arrive.
3. **Native 24 kHz** — Gemini emits mono int16 LE PCM at 24 kHz (already the lamp's format), so the common path does ZERO resampling.

**Module constants:**
- `TTS_HARD_TIMEOUT_S = 20.0` — bounds the *unary* call so a stuck request can't hang the turn forever ([tts_gemini.py:77](app/providers/tts_gemini.py#L77)).
- `_TTS_TRANSIENT_STATUS = {429, 500, 502, 503, 504}`, `_TTS_RETRIES = 2`, `_TTS_BACKOFF_S = 0.6` — transient-retry policy mirroring the LLM path ([tts_gemini.py:82-84](app/providers/tts_gemini.py#L82)).

**Optional-SDK guards**: `from google.genai import types` sets `_GENAI_OK`; `audioop` (stdlib ≤3.12) falls back to `audioop_lts`, else `None` ([tts_gemini.py:50-63](app/providers/tts_gemini.py#L50)).

**`class GeminiTtsProvider(TtsProvider)`** (`@register_tts_provider("gemini")`):
- `__init__` ([tts_gemini.py:104-119](app/providers/tts_gemini.py#L104)) — obtains the shared client only if `_GENAI_OK and settings.TTS_ENABLED`; caches `_model`, `_voice`, `_style`, `_stream`, `_dst_rate`, `_chunk_bytes` from settings.
- `available` → `bool(self._client and _GENAI_OK and settings.TTS_ENABLED)`.
- `mode` → `"gemini:stream"` or `"gemini:unary"`.
- `incremental` → `bool(self._stream)`. With streaming on, one `synthesize()` streams audio chunks (dispatcher streams that one call straight to the lamp → 1 request/turn AND low latency). With streaming off, `synthesize()` is unary, so report False and let the dispatcher sentence-chunk ([tts_gemini.py:129-139](app/providers/tts_gemini.py#L129)).

**`synthesize()`** ([tts_gemini.py:142-186](app/providers/tts_gemini.py#L142)) — the streaming primitive. Mechanics:
1. Raise `TTSError` if not `available`.
2. **Cost guard first**: `text = clamp_tts_text(text.strip())`; empty → return.
3. Iterate `_raw_audio(text, turn_id)` → `(raw_pcm, src_rate)`.
4. **Resample only if `src_rate != self._dst_rate`**: `audioop.ratecv(raw_pcm, 2, 1, src_rate, self._dst_rate, rate_state)` with `rate_state` carried across chunks for continuity. If `audioop is None`, raise `TTSError` (Py≥3.13 needs `audioop-lts`).
5. Log first-byte latency once.
6. **Re-slice to ≤ `_chunk_bytes`**: accumulate into `leftover`, `yield leftover[:chunk_bytes]` while it's ≥ chunk size. The trailing remainder is padded with `b"\x00"` if odd-length (never split an int16 sample on the wire) and yielded.

**`_raw_audio()`** ([tts_gemini.py:189-256](app/providers/tts_gemini.py#L189)) — transport: streaming first, unary fallback.
- **Streaming path** (`self._stream`): `await self._client.aio.models.generate_content_stream(model, contents, config)`; for each chunk, `_iter_audio_parts(chunk)` → yields `(pcm, rate)`, sets `produced=True`. On exception: re-raise `CancelledError`; if `produced` (mid-output failure) just stop the stream (can't un-send); if pre-output, log and fall through to unary.
- **Unary path** (fallback or `GEMINI_TTS_STREAM=false`): retry loop over `range(_TTS_RETRIES + 1)`. `await asyncio.wait_for(generate_content(...), timeout=TTS_HARD_TIMEOUT_S)`. `TimeoutError` → `TTSError`. On other exceptions, if `_status_code(e) in _TTS_TRANSIENT_STATUS and attempt < _TTS_RETRIES`: sleep `_TTS_BACKOFF_S * (2 ** attempt)` (exponential backoff: 0.6 s, 1.2 s) and retry; else `TTSError`. After response, walk parts; if none, raise `TTSError("...no audio (safety block or text-only response)")`.

**Helpers:**
- `_styled(text)` — prepends `GEMINI_TTS_STYLE` as a delivery directive: `f"{self._style}: {text}"`. This is the only thing that goes "in the prompt" for TTS — it shapes DELIVERY (tone/pace/emotion), NOT timbre (that's the voice) ([tts_gemini.py:258-265](app/providers/tts_gemini.py#L258)).
- `_audio_config()` — builds `GenerateContentConfig(response_modalities=["AUDIO"], speech_config=SpeechConfig(voice_config=VoiceConfig(prebuilt_voice_config=PrebuiltVoiceConfig(voice_name=self._voice))))`. **Required**: without `response_modalities=["AUDIO"]` + a `speech_config`, the model returns text not audio ([tts_gemini.py:267-280](app/providers/tts_gemini.py#L267)).
- `_iter_audio_parts(obj)` — defensively walks `candidates[].content.parts[].inline_data.data`; a safety-blocked response has no candidates so this yields nothing ([tts_gemini.py:284-299](app/providers/tts_gemini.py#L284)).
- `_rate_from_mime(mime)` — parses `rate=` out of e.g. `audio/L16;codec=pcm;rate=24000`; defaults to `TTS_TARGET_SAMPLE_RATE` when missing ([tts_gemini.py:302-315](app/providers/tts_gemini.py#L302)).
- `_status_code(exc)` — pulls `.code`/`.status_code` or a leading numeric token like `503 UNAVAILABLE` ([tts_gemini.py:87-95](app/providers/tts_gemini.py#L87)).

**Voice / model defaults** ([config.py:113-124](app/config.py#L113)): `GEMINI_TTS_MODEL="gemini-2.5-flash-preview-tts"`, `GEMINI_TTS_VOICE="Aoede"` (prebuilt: Kore, Puck, Charon, Zephyr, Aoede, Fenrir…), `GEMINI_TTS_STREAM=False` (UNARY), `GEMINI_TTS_STYLE="calm, clear, and matter-of-fact. Speak at a steady, natural pace with an intelligent and helpful tone, avoiding any exaggerated enthusiasm"`.

### 3.3 Piper TTS Provider (`tts_piper.py`)

The self-hosted, $0, fully-offline CPU voice. This file contains the heavyweight `TTSService` plus a thin `PiperTtsProvider` adapter.

**Two modes** (`PIPER_MODE`, [tts_piper.py:5-22](app/providers/tts_piper.py#L5)):
- **`library`** (default, low latency) — load the `.onnx` voice ONCE in-process via the `piper` Python package and keep it warm. Per-turn synthesis skips the ~2 s model-load a fresh subprocess pays; TTFB drops from ~2.5 s → ~0.2 s. Synthesis (CPU-bound onnxruntime) runs in a worker thread, bridged to the loop via a queue.
- **`subprocess`** (fallback) — spawn the `piper` CLI per turn and stream its raw stdout. Used when the Python package isn't importable or the model file isn't found. Self-contained but pays model-load per turn.

**Optional-SDK guards**: `from piper import PiperVoice` + `from piper.config import SynthesisConfig` set `_PIPER_LIB_OK`; `audioop`/`audioop_lts` same as Gemini ([tts_piper.py:46-73](app/providers/tts_piper.py#L46)). `_spawn_argv = asyncio.subprocess.create_subprocess_exec` is aliased so the literal `exec(` substring never appears (scanner-friendly) ([tts_piper.py:75-77](app/providers/tts_piper.py#L75)).

**`class TTSService`** ([tts_piper.py:80-368](app/providers/tts_piper.py#L80)):

`__init__` resolves binary, model, and mode ([tts_piper.py:85-150](app/providers/tts_piper.py#L85)):
- `_bin = shutil.which(PIPER_BIN)` or the literal path if it contains a slash.
- `_model = PIPER_MODEL or None`, `_cfg = PIPER_CONFIG or None`.
- `_src_rate = PIPER_SAMPLE_RATE` (22050), `_dst_rate = TTS_TARGET_SAMPLE_RATE` (24000), `_chunk_bytes = TTS_CHUNK_BYTES` (4096).
- **Delivery tuning math** ([tts_piper.py:96-103](app/providers/tts_piper.py#L96)):
  - `_length_scale = round(1.0 / max(0.1, PIPER_SPEED), 4)` — `PIPER_SPEED` is intuitive (1.0 normal, >1 faster); Piper's `length_scale` is its inverse (>1 = slower), so it's inverted. The `max(0.1, ...)` divisor clamp prevents a 0/negative speed blowing up.
  - `_noise_scale = PIPER_NOISE_SCALE` (0.667, voice variability), `_noise_w = PIPER_NOISE_W` (0.8, phoneme-length variability), `_sentence_silence = PIPER_SENTENCE_SILENCE` (0.35 s), `_speaker = int(PIPER_SPEAKER)` (-1 = single-speaker).
- **Mode resolution & availability fallback** ([tts_piper.py:105-139](app/providers/tts_piper.py#L105)): computes `lib_ok = _PIPER_LIB_OK and model_file_exists`, `sub_ok = bin and model`. If `TTS_ENABLED` is off → disabled. If mode=`subprocess`: use it if `sub_ok`, else fall back to library if `lib_ok`, else disabled. If mode=`library` (default): use it if `lib_ok`, else fall back to subprocess if `sub_ok`, else disabled. This means a half-configured environment still produces audio when possible.
- A startup `TTSError` is raised only if enabled AND `_src_rate != _dst_rate` AND `audioop is None` (resampling impossible) ([tts_piper.py:145-150](app/providers/tts_piper.py#L145)).

Properties: `available` → `_enabled`; `mode` → resolved mode; `target_sample_rate` → `_dst_rate`.

`warmup()` ([tts_piper.py:164-172](app/providers/tts_piper.py#L164)) — preloads the in-process voice (library mode only) so the first turn isn't cold; best-effort.

`synthesize()` ([tts_piper.py:174-188](app/providers/tts_piper.py#L174)) — raises `TTSError` if disabled; empty text → return; dispatches to `_synthesize_library` or `_synthesize_subprocess`.

`_ensure_voice()` ([tts_piper.py:191-214](app/providers/tts_piper.py#L191)) — lazy load under `_load_lock` (so concurrent turns don't double-load); `PiperVoice.load(model, cfg)` in a thread; then **trusts the voice's real `config.sample_rate`** to auto-correct a mismatched `PIPER_SAMPLE_RATE`.

`_synthesize_library()` ([tts_piper.py:216-275](app/providers/tts_piper.py#L216)) — the warm path:
1. Build a `SynthesisConfig(length_scale, noise_scale, noise_w_scale, speaker_id=...)`.
2. A worker function `_produce()` runs `voice.synthesize(text, syn)` in `loop.run_in_executor(None, ...)`; onnxruntime releases the GIL during inference so the loop isn't stalled. Each `chunk.audio_int16_bytes` is pushed to an `asyncio.Queue` via `loop.call_soon_threadsafe(queue.put_nowait, b)`. Exceptions are pushed as the item; a `DONE` sentinel always lands in `finally`.
3. The consumer awaits `queue.get()`; on an `Exception` item it raises `TTSError`; on PCM it resamples (`audioop.ratecv` with carried `rate_state`) if rates differ, accumulates into `leftover`, and yields `_chunk_bytes` slices, then the final remainder. On consumer cancel/early-break the worker finishes its short in-flight synthesis in the background (onnxruntime has no mid-inference cancel) and its puts land in an unread, GC'd queue — bounded (one utterance), brief.

`_synthesize_subprocess()` ([tts_piper.py:278-368](app/providers/tts_piper.py#L278)) — the fallback path:
1. Build argv: `[bin, "--model", model, "--output_raw", "--length_scale", ..., "--noise_scale", ..., "--noise_w", ..., "--sentence_silence", ...]`, plus `--config` and `--speaker` if set.
2. Spawn via `_spawn_argv(*cmd, stdin/stdout/stderr=PIPE)`.
3. Two helper tasks: `_feed_stdin` writes the UTF-8 text then closes stdin (swallows `BrokenPipeError`/`ConnectionResetError`); `_drain_stderr` reads stderr.
4. Read loop: reads `src_read = max(chunk_bytes, int(chunk_bytes * src_rate/dst_rate) + 64)` bytes (so post-resample output ≈ one wire chunk), resamples if needed, yields `_chunk_bytes` slices.
5. On non-zero `returncode`, read stderr (0.5 s timeout) and raise `TTSError(f"piper exited rc=...")`.
6. **`finally`**: if still running, `proc.kill()` then `wait()` with 2 s timeout; cancel the feeder/stderr tasks. This is the cancellation cleanup that the dispatcher's `CancelledError` path relies on.

`get_tts()` ([tts_piper.py:371-378](app/providers/tts_piper.py#L371)) — module singleton accessor (one warm voice).

**`class PiperTtsProvider(TtsProvider)`** (`@register_tts_provider("piper")`, [tts_piper.py:382-416](app/providers/tts_piper.py#L382)) — a thin face over `TTSService`: `__init__` grabs `get_tts()` (reuses the warm singleton, so selecting `TTS_PROVIDER=piper` never loads the `.onnx` twice). It forwards `available`, `target_sample_rate`, `mode`, `warmup`, and `synthesize` (applying the same `clamp_tts_text` guard — here bounding CPU+airtime, not $). It inherits `generate_speech` (drains the stream). It does **not** override `incremental`, so it is `True` (Piper streams progressively).

### 3.4 Cartesia Provider (`tts_cartesia.py`) — LIVE

The **default lamp speech engine** (`TTS_PROVIDER=cartesia`) and a **real streaming provider** ([tts_cartesia.py:40](app/providers/tts_cartesia.py#L40)) — `class CartesiaTtsProvider(TtsProvider)` decorated `@register_tts_provider("cartesia")`. It synthesizes via a single **`POST https://api.cartesia.ai/tts/bytes`** with `output_format.container="raw"`, reading the response body **progressively** through httpx, and requests output **AS** the lamp's native wire format (24 kHz mono int16 LE PCM) so there is **no server-side resample**. Because the body streams continuously, `incremental=True` → the dispatcher pipes this one call straight to the lamp via `stream_audio_out_iter()` and **`TTS_CHUNK_MODE` is bypassed entirely** (no sentence-chunking, no mid-speech gap).

**Why it was added** (header docstring): the Gemini *preview* TTS is capped at **100 requests/day**, slow (~8–12 s for a long reply), and has no usable incremental streaming (which forced the chunking workaround). Cartesia Sonic streams with a **~170 ms first byte**, has **no daily cap** (usage-based), and continuous audio — so the chunking workaround disappears.

**Config** ([config.py](app/config.py)): `CARTESIA_API_KEY`; `CARTESIA_MODEL` (default **`sonic-3.5`**; also `sonic-3`/`sonic-2`); `CARTESIA_VOICE_ID` (default a "Skylar" UUID); `CARTESIA_VERSION` (`2025-04-16`); `CARTESIA_LANGUAGE` (`en`); `CARTESIA_TIMEOUT_S` (**20**, lowered from 30 on 2026-07-04 — a single-shot safety net aligned with the 20 s LLM/TTS hard timeouts; first byte is ~170-200 ms so this only bounds a hang, never adds latency). **Tutor voice style** → Cartesia `generation_config`: `CARTESIA_SPEED` (0.9, clamped 0.6–1.5), `CARTESIA_VOLUME` (1.2, clamped 0.5–2.0), `CARTESIA_EMOTION` (off by default). Note `GEMINI_TTS_STYLE` does **not** apply to Cartesia — it shapes delivery via these structured controls + voice choice. Needs `httpx` (pinned in `requirements.txt`, else `TTS_PROVIDER=cartesia` ImportErrors on Render). The lazy per-provider import means selecting `cartesia` never imports `tts_gemini` — the Gemini path stays byte-for-byte untouched.

### 3.5 Voice Assets (`audio-tts/`)

The directory holds the Piper voice models that `PIPER_MODEL` points at:
- `en_US-amy-medium.onnx` (~63 MB) + `en_US-amy-medium.onnx.json`
- `en_US-amy-low.onnx` (~63 MB) + `en_US-amy-low.onnx.json`

The `.onnx.json` carries the inference defaults and native rate. For amy-medium ([audio-tts/en_US-amy-medium.onnx.json](audio-tts/en_US-amy-medium.onnx.json)):
- `audio.sample_rate = 22050` (matches the `PIPER_SAMPLE_RATE` default; the engine still auto-corrects from `voice.config.sample_rate` at load).
- `inference: { noise_scale: 0.667, length_scale: 1, noise_w: 0.8 }` — the same defaults exposed as `PIPER_*` settings.
- `phoneme_type: "espeak"`, `espeak.voice: "en-us"`, `num_speakers: 1`, `language.code: "en_US"`.

`PIPER_MODEL` now defaults to `audio-tts/en_US-amy-medium.onnx` (relative to backend cwd); setting it empty disables Piper entirely ([config.py:197](app/config.py#L197)).

### 3.6 The Wire Codec (PCM / ADPCM / Opus)

`synthesize()` always produces 24 kHz int16 PCM, but the *wire* can carry it compressed. The single chokepoint is `Session.send_audio_out_chunk()` ([session.py:648-711](app/session.py#L648)), selected by `TTS_WIRE_CODEC` ([config.py:638-663](app/config.py#L638)):

| Codec | Wire rate | Frame type | Notes |
|---|---|---|---|
| `pcm` | 48 KB/s | `AUDIO_OUT` | int16 LE as-is. Required for firmware predating the ADPCM frame. Odd byte count → padded with `\x00`. |
| `adpcm` | 12 KB/s (4:1) | `AUDIO_OUT_ADPCM` (0x12) | IMA/DVI ADPCM via `audioop.lin2adpcm(pcm, 2, self._adpcm_state)` carrying state across chunks. THE fix for voice breaking on a ~20 KB/s WAN. |
| `opus` (default) | ~4 KB/s | `AUDIO_OUT_OPUS` (0x13) | `_OpusWire` (opuslib @ 24 kHz mono VOIP). Needs `pip install opuslib` + system libopus; `OPUS_LIB_PATH` steers ctypes. |

**Degradation chain** opus → adpcm → pcm: if opus construction fails, `_opus_dead` latches and it degrades to adpcm; if `audioop` is missing, adpcm degrades to pcm — each step warns once ([session.py:669-704](app/session.py#L669)). Encoding happens HERE so upstream pacing logic stays in PCM-time (85 ms of audio per chunk) regardless of compressed wire size. `send_audio_out_end()` flushes the Opus tail and resets BOTH codec states so the next stream starts bit-aligned on both ends ([session.py:852-871](app/session.py#L852)).

### 3.7 How the Dispatcher Drives TTS

`dispatch._audio_leg_impl` ([dispatch.py:188-266](app/services/dispatch.py#L188)) is the consumer. Guards (in order, each saves synthesis cost):
1. `status != "ok"` → SKIP (error fallback speech is for visual display, not to be spoken).
2. empty/whitespace `speech` → SKIP.
3. `tts is None or not tts.available` → SKIP gracefully (text + LaTeX still ship).

Then it branches on `incremental` ([dispatch.py:244-252](app/services/dispatch.py#L244)):
- **`incremental == True`** (Piper, or Gemini with streaming on) → feed `tts.synthesize(speech, turn_id)` directly to `session.stream_audio_out_iter()`.
- **`incremental == False`** (Gemini unary) → wrap in `_sentence_streamed(tts, speech, turn_id)` which sentence-chunks so first audio tracks the FIRST clause.

**Sentence chunking** ([dispatch.py:531-569](app/services/dispatch.py#L531)): `_tts_chunks(text)` splits at clause boundaries (`(?<=[.!?,;:])\s+`) per `TTS_CHUNK_MODE`:
- `single` → `[text]` (1 call/turn, slowest first audio).
- `balanced` (**default**) → gap-free 2-piece for slow TTS: a first short clause then the remaining clauses merged, so first audio tracks the FIRST clause with no mid-speech gap.
- `hybrid` → first short clause (~70 chars, `_TTS_FIRST_PIECE_CHARS`) then ALL remaining clauses merged into one (`target = inf`) → exactly 2 calls.
- `full` → later pieces capped at ~180 chars (`_TTS_LATER_PIECE_CHARS`) → ~3-4 calls.

`_sentence_streamed` ([dispatch.py:572-...](app/services/dispatch.py#L572)) does **one-ahead prefetch**: it kicks off `_synth_full(piece[0])`, and while piece N is paced to the lamp it synthesises piece N+1, so there's no inter-piece gap (the provider runs faster than real-time). A failed piece is skipped (non-fatal); `CancelledError` cancels every in-flight task in the `finally`. *(This whole path is bypassed when `incremental` is True — Cartesia (the lamp default) and Piper always stream, and Gemini streams only when `GEMINI_TTS_STREAM=true`. Since Gemini now defaults to UNARY, a Gemini turn IS sentence-chunked here by default.)*

**Pacing** ([session.py:774-850](app/session.py#L774)): `stream_audio_out_iter` re-slices the incoming async byte stream to exactly `chunk_bytes` (4 KB) frames (decoupling wire size from provider chunk size). The first `_TTS_PRIME_CHUNKS = 12` chunks ship back-to-back (prime burst, fills the lamp's pre-roll jitter buffer fast → low TTFA); every chunk after is preceded by an `AUDIO_OUT_PACE_S` (~85 ms) sleep. Back-pressure: during the sleeps it isn't pulling from the iterator, so the upstream generator suspends and Piper blocks on its stdout pipe — memory stays bounded.

**END ordering** ([dispatch.py:149-185](app/services/dispatch.py#L149)): `_dispatch_audio_leg` wraps `_audio_leg_impl` and ALWAYS sends `AUDIO_OUT_END` the moment the stream ends (BEFORE releasing the `done_evt` that gates the TFT leg's deferred equation re-sends), so on the thin FIFO WAN the END marker isn't queued behind a 70-140 KB LaTeX append. The duplicate END from `finalize_turn` is tolerated.

---

## 4. Audio Preprocessing (`audio_preprocessor.py`)

**Purpose**: make the lamp's raw mic PCM safe to ship to a Gemini VLM. The lamp's `FRAME_AUDIO_CHUNK` is int16 LE PCM at 16 kHz mono, already NS/ALE/AGC'd on-device — so this module does **NOT touch the samples**, it only wraps them in a container Gemini's REST `generateContent` accepts ([audio_preprocessor.py:1-24](app/providers/audio_preprocessor.py#L1)).

**Why it exists** ([audio_preprocessor.py:9-16](app/providers/audio_preprocessor.py#L9)): Gemini's REST path accepts `{audio/wav, audio/mp3, audio/aiff, audio/aac, audio/ogg, audio/flac}` but NOT the literal `audio/pcm;rate=16000` (that's Multimodal-Live-only). Without a WAV header Gemini returns 400 / empty / safety_block and the turn falls back to FALLBACK_REPLY. A WAV header is 44 bytes and ~0 latency.

**Constants** ([audio_preprocessor.py:34-37](app/providers/audio_preprocessor.py#L34)): `PCM_SAMPLE_RATE_HZ = 16_000`, `PCM_CHANNELS = 1`, `PCM_SAMPLE_WIDTH_B = 2`.

**`wrap_pcm_as_wav(pcm_bytes, *, sample_rate=16000, channels=1, sample_width=2)`** ([audio_preprocessor.py:40-86](app/providers/audio_preprocessor.py#L40)):
1. Empty input → `b""`.
2. **Whole-frame guard**: if `len(pcm_bytes) % (channels * sample_width) != 0`, log a warning and truncate to the last whole frame: `usable = (len // 2) * 2`. (An odd byte count is a lamp-side protocol bug; the `wave` module insists on whole-frame writes.) If truncation empties it → `b""`.
3. Write a RIFF/WAVE/PCM blob via `wave.open(BytesIO, "wb")` with `setnchannels/setsampwidth/setframerate/writeframes`, return `buf.getvalue()`.
4. **Fail-open**: on any exception (practically impossible for stdlib `wave`), log and return the original `pcm_bytes` so the caller still has something to send.

**Consumers** ([audio_preprocessor.py:18-23](app/providers/audio_preprocessor.py#L18)): `providers/llm_gemini.py::_drain` MUST wrap. NOT used by `llm_openai` (GPT-4o-audio takes raw `pcm16`) or `llm_claude` (wraps internally for Groq STT).

---

## 5. Image Preprocessing

Two files cooperate: `image_preprocessor.py` (the heavy, synchronous pipeline) and `services/image_prep.py` (the async early-prep orchestration). The goal is to make the lamp's fixed-focus OV5640 JPEG (shot at q≈10-20 under a desk lamp) legible to the VLM.

### 5.1 Tunables & Constants

All in [image_preprocessor.py:51-123](app/providers/image_preprocessor.py#L51):

| Constant | Value | Effect |
|---|---|---|
| `MAX_DIM_PX` | 1280 | cap longest edge for VLM upload |
| `OUT_QUALITY` | 88 | output JPEG quality |
| `MIN_SHARPNESS_WARN` | 60.0 | sharpness gate is **log-only** here (camera_server.py rejects at 60) |
| `PAGE_MIN_AREA_FRAC` | 0.18 | page contour must be ≥18% of frame |
| `PAGE_MAX_AR` | 3.5 | page aspect-ratio bound |
| `PAGE_DETECT_SCALE` | 700.0 | downscale long side to 700 px for detection |
| `PAGE_BINARY_GROW_PX` | 6 | dilate the binary mask |
| `PAGE_QUAD_PADDING` | 0.04 | expand the page quad 4% outward |
| `DENOISE_STRENGTH` | 1 | 0=off, 1=light, 2=medium bilateral |
| `DESKEW_MAX_ANGLE` | 6.0 | max deskew rotation (deg) |
| `ENABLE_PAGE_WARP` | **False** | Stage 1 perspective warp — OFF (grabbed the desk as the page) |
| `ENABLE_DESKEW` | **False** | Stage 3 rotation — OFF (can rotate-crop) |
| `ENABLE_BLEACH` | **False** | Stage 4 illumination flatten — OFF (ghosting-prone) |
| `KEEP_ORIGINAL_MIN_SHARP` | 250.0 | half-res Laplacian-var floor for the keep-original guard (~500+ at full res) |
| `ENHANCE_MAX_CONCURRENCY` | 2 | process-wide cap; backed by `_ENHANCE_GATE = threading.BoundedSemaphore(2)` |
| `PRESHRINK_FACTOR` | 1.5 | frames whose long side > 1.5× max_dim are DCT-domain pre-shrunk |
| PIL-fallback knobs | `AUTOCONTRAST_CUT=1`, `CONTRAST_FACTOR=1.10`, `SATURATION_FACTOR=1.05`, `SHARPNESS_FACTOR=1.35`, `UNSHARP_RADIUS=1.2`, `UNSHARP_PERCENT=80`, `UNSHARP_THRESHOLD=2` | used only when cv2 is missing |

**Critical design note** ([image_preprocessor.py:71-82](app/providers/image_preprocessor.py#L71)): the geometric/destructive stages (warp, deskew, bleach) are **OFF by default** — the default pipeline is **ENHANCE-ONLY** (keep the full frame, do non-destructive denoise + CLAHE + mild unsharp). The page-detect+warp was mis-firing (grabbing the wood table as the "page" quad) and the divide-by-background bleach over-processed into ghosting. The helper functions for those stages still exist and are documented below for completeness, but they don't run unless a flag is flipped.

`cv2`/`numpy` import sets `_HAVE_CV2` (else PIL-only fallback) ([image_preprocessor.py:39-47](app/providers/image_preprocessor.py#L39)).

### 5.2 Entry Point & Guards

**`enhance_for_llm(jpeg_bytes, *, max_dim=1280, quality=88, unmirror=False, stages_out=None)`** ([image_preprocessor.py:129-191](app/providers/image_preprocessor.py#L129)) — the public sync entry (callers run it via `asyncio.to_thread`):
1. Empty → `b""`.
2. `jpeg_bytes = _preshrink_oversized(...)` — runs OUTSIDE the concurrency gate (cheap), so a queued 4K frame shrinks while waiting.
3. `with _ENHANCE_GATE:` → `out = _run_pipeline(...)` (at most 2 heavy runs at once).
4. **Keep-original guard**: if `out` differs from input AND `len(out) > len(input)` AND `_quick_sharpness(input) >= KEEP_ORIGINAL_MIN_SHARP (250)`, return the ORIGINAL — enhancement grew the file but the input was already sharp, so the enhanced one would just cost more Gemini image tokens for zero readability gain.
5. Log passthrough vs enhanced with timing.

**`_run_pipeline(...)`** ([image_preprocessor.py:194-216](app/providers/image_preprocessor.py#L194)) — dispatches to `_enhance_cv2`; on exception falls back to `_enhance_pil`. If `_HAVE_CV2` is False, warns once and uses PIL.

**`_preshrink_oversized(jpeg_bytes, max_dim)`** ([image_preprocessor.py:219-247](app/providers/image_preprocessor.py#L219)) — DCT-domain downscale-before-decode: if the JPEG's long side > `max_dim * PRESHRINK_FACTOR`, call `im.draft("RGB", (max_dim//2, max_dim//2))` (PIL `draft` only scales by 1/2,1/4,1/8 and never below the requested size), `convert("RGB")`, re-save at q92 (above the pipeline's q88 so no double-compression artefact survives). A 4K (24 MB full-res bitmap) thus decodes at ~1920 px and never materialises in memory. Non-JPEG / acceptable size / any failure → original bytes.

**`_quick_sharpness(jpeg_bytes)`** ([image_preprocessor.py:250-266](app/providers/image_preprocessor.py#L250)) — variance-of-Laplacian on a HALF-RES grayscale decode (`cv2.IMREAD_REDUCED_GRAYSCALE_2`, ~10-20 ms). Returns None if cv2 missing or on failure (guard then doesn't fire — fail-open).

### 5.3 The OpenCV Pipeline (stage by stage)

**`_enhance_cv2(...)`** ([image_preprocessor.py:285-362](app/providers/image_preprocessor.py#L285)):
- Decode `cv2.imdecode(arr, IMREAD_COLOR)`; None → return original.
- **Unmirror** (if `unmirror`): `cv2.flip(img, 1)` BEFORE any geometry so downstream sees the true scene.
- **Stage 0 — sharpness gate**: `_centre_weighted_sharpness(gray0)`; warn if `< MIN_SHARPNESS_WARN (60)` (never drops the turn — the user is already waiting).
- **Stage 1 — page warp** (OFF): if `ENABLE_PAGE_WARP`, `_detect_page_quad` + `_warp_quad_to_rectangle`; else `warped = img` (full frame).
- **Stage 2 — denoise**: `_denoise(warped)` (runs by default, `DENOISE_STRENGTH=1`).
- **Stage 3 — deskew** (OFF): `_deskew_small` only if `ENABLE_DESKEW`.
- **Stage 4 — bleach** (OFF): `_bleach_background` only if `ENABLE_BLEACH`.
- **Stage 5 — CLAHE + unsharp**: `_clahe_unsharp(flattened)` (the actual default enhancement).
- **Resize**: if longest edge > `max_dim`, `cv2.resize(..., INTER_AREA)`.
- **Encode**: `cv2.imencode(".jpg", cleaned, [IMWRITE_JPEG_QUALITY, quality])`; failure → original.

Stage internals (the real math):

- **`_centre_weighted_sharpness(gray)`** ([image_preprocessor.py:366-371](app/providers/image_preprocessor.py#L366)) — crop the centre third (`rh=h//3, rw=w//3`) and return `cv2.Laplacian(crop, CV_64F).var()`.
- **`_detect_page_quad(img)`** ([image_preprocessor.py:414-462](app/providers/image_preprocessor.py#L414)) — downscale to `PAGE_DETECT_SCALE/max(h,w)`; gray → `bilateralFilter(9,60,60)` → Otsu threshold → `MORPH_CLOSE` (5×5, 3 iters) → dilate by `PAGE_BINARY_GROW_PX`. Find external contours, sort by area, examine the top 5: skip any below `PAGE_MIN_AREA_FRAC * frame_area`; try `approxPolyDP` at `eps_frac ∈ (0.02..0.10)` looking for a convex 4-vertex polygon, else `minAreaRect`/`boxPoints`. Order corners, validate (`_valid_quad`), scale back to full res, expand outward (`_expand_quad_outward`).
- **`_order_corners(pts)`** ([image_preprocessor.py:375-384](app/providers/image_preprocessor.py#L375)) — TL=argmin(sum), TR=argmin(diff), BR=argmax(sum), BL=argmax(diff).
- **`_valid_quad(...)`** ([image_preprocessor.py:387-397](app/providers/image_preprocessor.py#L387)) — average width/height must be ≥25% of the frame and aspect ratio within `(1/PAGE_MAX_AR, PAGE_MAX_AR)`.
- **`_expand_quad_outward(...)`** ([image_preprocessor.py:400-411](app/providers/image_preprocessor.py#L400)) — push corners out by `PAGE_QUAD_PADDING * mean_extent`, clipped to frame bounds.
- **`_warp_quad_to_rectangle(...)`** ([image_preprocessor.py:465-484](app/providers/image_preprocessor.py#L465)) — compute width/height from corner distances, `getPerspectiveTransform` + `warpPerspective(INTER_CUBIC, BORDER_REPLICATE)`. <50px either dim → return original.
- **`_denoise(img)`** ([image_preprocessor.py:488-493](app/providers/image_preprocessor.py#L488)) — strength 1 → `bilateralFilter(d=5, sigmaColor=25, sigmaSpace=25)`; strength 2 → `d=7, 45, 45`.
- **`_deskew_small(...)`** ([image_preprocessor.py:497-530](app/providers/image_preprocessor.py#L497)) — Canny(50,150) → `HoughLinesP(threshold=100, minLineLength=w//4, maxLineGap=20)`; need ≥5 lines; collect angles within `±max_angle`; take the `median`; if `|median| ≥ 0.3°` rotate via `getRotationMatrix2D` + `warpAffine(INTER_CUBIC, BORDER_REPLICATE, white border)`.
- **`_bleach_background(img)`** ([image_preprocessor.py:534-561](app/providers/image_preprocessor.py#L534)) — paper-masked illumination flatten: build a per-channel background via `MORPH_CLOSE` (kernel `k = max(31, (short//20)|1)`) + Gaussian blur (`sigma=k/6`); `bleached = clip(img/max(bg,1)*255)`; build a mask from background luminance (`paper_white = 95th-percentile`, `lo=0.40*paper_white`, `hi=0.90*paper_white`) so only bright pixels are flattened; blend `mask*bleached + (1-mask)*img`. (Prevents noise amplification on dark desk/hands.)
- **`_clahe_unsharp(img)`** ([image_preprocessor.py:565-575](app/providers/image_preprocessor.py#L565)) — convert to LAB, apply `createCLAHE(clipLimit=1.2, tileGridSize=(8,8))` to the L channel, merge back to BGR, then mild unsharp `addWeighted(enhanced, 1.4, GaussianBlur(sigma=1.0), -0.4, 0)` (the 1.4/-0.4 amount was tuned down from 1.6/-0.6 to avoid haloing).

**Dev-capture taps**: `_emit_stage_cv2(stages_out, name, img)` ([image_preprocessor.py:272-282](app/providers/image_preprocessor.py#L272)) encodes each stage to JPEG into `stages_out` under `NN_<stage>` keys — only when `stages_out is not None` (production hot path does ZERO extra work). Stage names: `00_decoded`, `00b_unmirror`, `01_warp`/`01_nowarp`, `02_denoise`, `03_deskew`, `04_bleach`, `05_clahe_unsharp`, `06_resized`.

### 5.4 The PIL Fallback

**`_enhance_pil(...)`** ([image_preprocessor.py:596-637](app/providers/image_preprocessor.py#L596)) — used only when cv2 is unavailable: decode → `exif_transpose` → RGB → optional `ImageOps.mirror` → thumbnail to `max_dim` (LANCZOS) → `autocontrast(cutoff=1, preserve_tone)` → `Contrast(1.10)` → `Color(1.05)` → `Sharpness(1.35)` → `UnsharpMask(1.2, 80, 2)` → save JPEG (q88, optimize). Any failure → original bytes. Stage taps via `_emit_stage_pil` ([image_preprocessor.py:581-593](app/providers/image_preprocessor.py#L581)).

### 5.5 Early Prep Service (`services/image_prep.py`)

Runs image work **while the user is still speaking**, moving it off the critical path between end-of-speech and the first LLM token ([image_prep.py:1-27](app/services/image_prep.py#L1)).

- **`@dataclass PreppedImage`** ([image_prep.py:41-47](app/services/image_prep.py#L41)): `raw: bytes` (exactly as lamp sent, persisted to blobs), `enhanced: bytes` (what the LLM sees; == raw if enhancement off/failed), `ref: Any|None` (Gemini Files API handle or None).
- **`early_prep_enabled()`** ([image_prep.py:49-52](app/services/image_prep.py#L49)) — `IMAGE_PREP_EARLY` AND NOT `DEV_CAPTURE_DUMP` (the capture dump needs the legacy inline path's per-stage taps).
- **`prep_image(raw)`** ([image_prep.py:55-80](app/services/image_prep.py#L55)) — never raises:
  1. If `ENABLE_IMAGE_ENHANCEMENT`: `enhanced = await asyncio.to_thread(enhance_for_llm, raw, unmirror=LAMP_IMAGE_UNMIRROR)`; on exception → `enhanced = raw`.
  2. If `GEMINI_FILES_PREUPLOAD`: `ref = await get_llm_provider().preupload_image(enhanced)` (base class returns None; GeminiProvider uploads to the FREE Files API — 20 GB, 48 h auto-expiry; referencing bills the SAME image tokens as inline). Attempted ONCE, never retried; failure → `ref=None` (legacy inline-bytes path).
- **`cancel_preps(tasks)`** ([image_prep.py:83-88](app/services/image_prep.py#L83)) — cancels still-running prep tasks if the turn is dropped.

Call flow ([image_prep.py:11-17](app/services/image_prep.py#L11)): `session._on_image_terminator()` → `asyncio.create_task(prep_image(raw))`; `orchestrator.run_turn()` awaits the tasks at AUDIO_END (normally already done) and uses `enhanced` + `ref` (None refs fall back to inline bytes).

---

## 6. LaTeX → RGB565 Rendering

The lamp can't render LaTeX; the backend rasterises `latex_equations` into raw RGB565 pixel frames the ESP32 TFT (240×320 ILI9341/ST7789, used landscape as 320 W × 240 H) paints directly via `pushColors`.

### 6.1 The Engine (`latex_engine.py`)

A vendored, stripped copy of root `Latex_engine_tft.py` keeping only the renderer + cache ([latex_engine.py:1-19](app/providers/latex_engine.py#L1)). Engine = **matplotlib mathtext** (a SUBSET of LaTeX — allowed commands enforced by `app/prompts/_latex_rules.py`). Matplotlib runs `Agg` headless ([latex_engine.py:30-32](app/providers/latex_engine.py#L30)).

**Constants** ([latex_engine.py:40-98](app/providers/latex_engine.py#L40)):
- `LATEX_SUPERSAMPLE = 1.25` — render at 1.25× target DPI then LANCZOS-downscale for anti-aliasing. Lowered from 1.5 to cut render-time RAM (figure buffer scales with DPI²).
- `EQ_HEIGHT_MIN_PX = 32`, `EQ_HEIGHT_MAX_PX = 90` — rendered equation height bounds. The lamp's combined-view LaTeX slot is `LAMP_COMBINED_LATEX_AREA_H_PX = 110` px; with 10 px top padding and a 90 px equation ceiling there's a 10 px safety margin so the equation never touches the divider.
- Multi-equation label-badge geometry: `LABEL_FONT_H_PX=11`, `LABEL_BOTTOM_MARGIN_PX=4`, `LABEL_GAP_PX=4`, `LABEL_Y_TOP = 110-4-11 = 95`, `EQ_HEIGHT_MAX_WITH_LABEL_PX = 95-4-10 = 81`.

**`rel_to_pixel(rel_x, rel_y, w, h)`** ([latex_engine.py:101-104](app/providers/latex_engine.py#L101)) — maps [-1,1] relative coords to pixel coords (`px=(rel_x+1)/2*w`, `py=(1-rel_y)/2*h`).

**`@dataclass DisplayConfig`** ([latex_engine.py:112-158](app/providers/latex_engine.py#L112)) — all render parameters. Fields: `width=240`, `height=320`, `orientation=LANDSCAPE`, `eq_max_height=0.2`, `anchor_x=-1.0`, `anchor_y=1.0`, `bg_color="#000000"`, `fg_color="#FFFFFF"`, `dpi=200`, `font_scale=1.0`, `brightness=1.0`, `contrast=1.2`, `sharpness=1.3`, `padding_px=10`, `output_format="rgb565"`, `math_fontset="stix"`, `color_order="BGR"`. Computed props: `render_w`/`render_h` (swap for landscape → 320×240), `short_axis_px`, and **`eq_height_px`**: `raw = int(eq_max_height * short_axis_px)` then clamped to `[32, 90]` (so 0.2 × 240 = 48 px default; out-of-range ratios are silently clamped, never raise).

**`class LatexPreprocessor`** ([latex_engine.py:161-184](app/providers/latex_engine.py#L161)) — a cheap string-replace pass. `ALIASES` maps LLM-natural commands to mathtext: `\integral→\int`, `\derivative→\frac{d}{dx}`, `\inf→\infty`, `\oo→\infty`, `\cross→\times`, `\dot_product→\cdot`, `\limits→""`, `\inftyty→\infty`. `process(raw)` strips `$$...$$`/`$...$` delimiters, applies aliases, and re-wraps in `$...$`.

**`class LatexRenderer`** ([latex_engine.py:187-562](app/providers/latex_engine.py#L187)) — holds the config, a `LatexPreprocessor`, and a `threading.Lock` (matplotlib is NOT thread-safe). `_configure_matplotlib` sets `rcParams` (fontset, colors). Key methods:

- **`render(latex_raw)`** ([latex_engine.py:203-265](app/providers/latex_engine.py#L203)) — the single-equation path (with scroll animation). Preprocess → `_render_latex_tight` → resize to `target_h` (clamped 32-90). Compute `total_w = new_w + pad*2`:
  - **Fits screen** (`total_w <= render_w`) → one frame at the anchor position.
  - **Too wide** → horizontal scroll: `step=12 px/frame`, `pause_frames=6` held at start and end, bounded by `max_bytes=16_000_000` (the wire protocol's 3-byte length cap) / `frame_bytes_size = render_w*render_h*2`. If too many frames, recompute `step` to fit. Returns all frames concatenated.
- **`_render_latex_tight(latex)`** ([latex_engine.py:338-372](app/providers/latex_engine.py#L338)) — the matplotlib call (under `_lock`). `ss_dpi = dpi * LATEX_SUPERSAMPLE`, `font_size = max(12, int(eq_height_px*0.55*font_scale))`, figure size derived from font size. `ax.text(0.5, 0.5, latex, ...)`; **on exception draws a red `$\mathrm{[render\ error]}$`** instead of raising inside the figure. `savefig(png, bbox_inches="tight")` now runs inside a `try/finally: plt.close(fig)` ([latex_engine.py:346-366](app/providers/latex_engine.py#L346)) — previously `plt.close(fig)` ran only on the success path, so a `savefig`/`add_axes` exception left the figure pinned in matplotlib's global figure registry forever (a slow OOM under repeated per-equation renders); every path now releases it. Then **tight-crop**: build a mask of pixels differing from `bg_color` by >5 in any channel, find the bounding box, pad by 2 px, crop.
- **`_post_process(img)`** ([latex_engine.py:309-317](app/providers/latex_engine.py#L309)) — applies `Brightness`/`Contrast`/`Sharpness` if != 1.0.
- **`_encode(img)`** ([latex_engine.py:319-324](app/providers/latex_engine.py#L319)) — RGB565 (or PNG if not configured for rgb565).
- **`render_with_labels(latex_raw, label, show_next_cue, max_frames=10)`** ([latex_engine.py:326-421](app/providers/latex_engine.py#L326)) — returns a LIST of frame bytes (this is what `latex_renderer` actually drives). Height ceiling drops to `EQ_HEIGHT_MAX_WITH_LABEL_PX (81)` when a label/cue is present. STATIC (single, centred) if it fits; else SCROLL bounded to `max_frames` steps with NO pause/hold frames (manual ◀/▶ navigation): `step = ceil(shift_dist/(n_steps-1))`, guaranteeing the last frame lands exactly on `end_x`. Then stamps a small dim "eqN" badge on every frame and (optionally) a "next eq >" cue on the LAST frame via `_draw_labels`.
- **`_draw_labels(img, label, show_next_cue)`** ([latex_engine.py:423-460](app/providers/latex_engine.py#L423)) — bottom-right `eqN` badge (`#999999`) and bottom-left `next eq >` cue (warm dim yellow `#C0B070`), placed in the label row range so they never overlap the equation. Never raises.
- **`render_single_static(latex_raw, label=None)`** ([latex_engine.py:462-549](app/providers/latex_engine.py#L462)) — renders ONE equation as exactly ONE static frame, NEVER scrolling: iteratively shrinks height (up to 6 passes, `target_h *= 0.85` each, ~50% total) until it fits horizontally or hits `EQ_HEIGHT_MIN_PX`. Centres, pins to top with padding, optionally stamps the label.
- **`_to_rgb565(img, color_order)`** (static, [latex_engine.py:551-562](app/providers/latex_engine.py#L551)) — the **pixel-packing math**: `r = pix.R >> 3` (5 bits), `g = pix.G >> 2` (6 bits), `b = pix.B >> 3` (5 bits). For BGR order: `rgb565 = (b<<11)|(g<<5)|r`; else RGB. Then **byte-swap to big-endian**: `rgb565_be = ((rgb565 & 0xFF) << 8) | ((rgb565 >> 8) & 0xFF)`. Output is `uint16.tobytes()` — exactly what `tft_ui::on_tft_frame` expects via `pushColors(swap=false)`.

**`class RenderCache`** ([latex_engine.py:565-600](app/providers/latex_engine.py#L565)) — a tiny LRU keyed on a SHA-1 of `(latex + config fields)`. `get` promotes the key to MRU; `put` evicts the oldest (`_order.pop(0)`) when full. Default `max_size=64` (the wrapper builds one with 128).

### 6.2 The Wrapper (`latex_renderer.py`)

The thin shim the orchestrator/dispatcher uses ([latex_renderer.py:1-33](app/providers/latex_renderer.py#L1)).

**The payload cap** — `MAX_TFT_PAYLOAD_BYTES` ([latex_renderer.py:73-77](app/providers/latex_renderer.py#L73)): read from `settings.LATEX_PAYLOAD_CAP_BYTES` (default **1_000_000**, ~6 scroll frames), falling back to `1_000_000` if config is unavailable. The lamp's PSRAM accumulator (`LATEX_CACHE_BYTES`) is 3 MB and the ESP32's DRAM fragments under a multi-thousand-chunk flood — a payload near/over that resets the socket MID-RECEIVE (WinError 10054), cancelling the WHOLE turn (audio included). The cap bounds the total at the source, comfortably under the lamp buffer and the u8 `n_frames` header field's 255-frame ceiling.

**Wire-frame height** — `LAMP_FRAME_H_PX = LAMP_COMBINED_LATEX_AREA_H_PX = 110` ([latex_renderer.py:89-105](app/providers/latex_renderer.py#L89)): the engine composes on a full 320×240 canvas but everything visible lives in the top 110 rows. Since RGB565 is row-major, truncating each frame to `W×110×2` IS the top-110 crop — the discarded tail is the all-background region the lamp clips anyway (saves 83 KB/frame on the WAN). The wire header carries H=110 so no firmware change is needed.

**Singletons** ([latex_renderer.py:107-111](app/providers/latex_renderer.py#L107)): `_CFG = DisplayConfig(LANDSCAPE)`, `_RENDERER = LatexRenderer(_CFG)`, `_CACHE = RenderCache(128)`, `_LOCK` (matplotlib not thread-safe).

**Top-level functions:**
- `render(latex_str)` ([latex_renderer.py:114-129](app/providers/latex_renderer.py#L114)) → `(W, H, n_frames, pixels)`; cache-checked; raises whatever matplotlib raises (caller decides). `n_frames = len(pixels)//(W*H*2)`.
- `build_tft_frame_payload(W, H, n_frames, pixels)` ([latex_renderer.py:132-138](app/providers/latex_renderer.py#L132)) — `struct.pack(">HHBB", W, H, n_frames, 0) + pixels` (6-byte inner header `[u16 W BE][u16 H BE][u8 n_frames][u8 rsv]`).
- `render_and_pack(latex_str)` ([latex_renderer.py:141-144](app/providers/latex_renderer.py#L141)) — one-call convenience.

**Per-equation primitives:**
- `_frame_geometry()` ([latex_renderer.py:154-160](app/providers/latex_renderer.py#L154)) → `(W, H, frame_size_b, total_frame_cap)` where `H = min(110, render_h)`, `frame_size_b = W*H*2 = 320*110*2 = 70,400 B` per wire frame (the engine's full-canvas frames are 320×240×2 = 153.6 KB, but each is cropped to the top 110 rows), `frame_cap = max(1, MAX_TFT_PAYLOAD_BYTES // frame_size_b)` (≈14 frames at the 1 MB default cap).
- `per_eq_frame_budget(n_eqs)` ([latex_renderer.py:163-168](app/providers/latex_renderer.py#L163)) → `max(3, frame_cap // n_eqs)` — shares the total budget across equations (single equation scrolls smoothly; several stay coarser but all fit).
- `_render_one_equation_impl(eq, index, n_total, per_eq_frames)` ([latex_renderer.py:171-209](app/providers/latex_renderer.py#L171)) → `(normalized_frames, render_ok)`. Label = `f"eq{index+1}"` if `n_total>1` else None; `show_next_cue = index < n_total-1`. Calls `render_with_labels` under `_LOCK`; **on exception** re-renders a `\mathrm{[eqN render error]}` placeholder (and if THAT fails, a single black frame `b"\x00"*frame_size_b`), setting `ok=False`. **Normalizes** every frame to exactly `frame_size_b` (truncate-to-crop or zero-pad) — this is the top-110 crop done "for free".
- `render_one_equation(...)` ([latex_renderer.py:212-221](app/providers/latex_renderer.py#L212)) — NEVER raises; same cache-key requirement (index/n_total affect the baked-in badge/cue).
- **`pack_equation_frames(eq_frames)`** ([latex_renderer.py:224-264](app/providers/latex_renderer.py#L224)) — assembles per-equation frame lists into ONE payload: 6-byte header + frames + a **per-equation frame-count trailer** (one byte per equation). Enforces `frame_cap` exactly (truncates mid-equation, drops fully-overflowed equations, logs a `capped` warning). The header is `struct.pack(">HHBB", W, H, n_frames, n_eq)`; the trailer is `bytes(eq_frame_counts)`. **Prefix property**: output for `eq_frames[0..k]` is a byte-prefix (pixels region) of the output for `[0..k+1]` — that's what makes the progressive cumulative re-send safe on the lamp's shared PSRAM accumulator (identical bytes overwrite identical bytes).

**Persistent Redis cache** ([latex_renderer.py:267-329](app/providers/latex_renderer.py#L267)) — formulas recur (PE=mgh, quadratic formula…) and a render costs seconds on the throttled free tier while the in-process LRU dies on every deploy.
- `_eq_cache_key(eq, index, n_total, per_eq_frames)` — SHA-1 of `f"v1|{eq}|{label}|{cue}|{per_eq_frames}|{W}x{H}|{LATEX_SUPERSAMPLE}"`, prefixed `latex:eq:`. Keyed on EVERYTHING that affects pixels.
- `render_one_equation_cached(...)` (async) — if `LATEX_REDIS_CACHE` and `cache.enabled()`, try a Redis GET → base64-decode → split into `frame_size_b` chunks (validates `len % frame_size_b == 0`). Miss → `asyncio.to_thread(_render_one_equation_impl, ...)` (keeps the loop free for the parallel audio leg) → **write-through ONLY genuine renders** (`render_ok` True) and only if `0 < len(blob) <= LATEX_REDIS_CACHE_MAX_BYTES (200_000)`, with TTL `LATEX_REDIS_CACHE_TTL_S` (3 days). Caching an error placeholder is explicitly avoided (a transient OOM would otherwise serve "[eqN render error]" for the whole TTL). Fail-open on any Redis hiccup.

**`render_equations_and_pack(equations)`** ([latex_renderer.py:332-395](app/providers/latex_renderer.py#L332)) — the multi-equation top-level. Filters empties; computes `per_eq_frames = per_eq_frame_budget(n)`; renders each (stopping early once `total_frames >= frame_cap` to skip expensive renders that would be dropped); `pack_equation_frames(rendered)`; logs a per-equation + total timing summary (`[LATEX-TIMING]`) so you can split "is it ESP or backend?" against the lamp's `[latex-rx]` log. Empty list → `b""`.

The packed payload must be shipped via `session.send_tft_frame_chunked(payload)` — `send_frame(TFT_FRAME, payload)` directly would hit the 4 KB hard guard ([latex_renderer.py:19-21](app/providers/latex_renderer.py#L19)).

### 6.3 Graph Rendering (`graph_renderer.py`) — restored end-to-end

> **History:** graph rendering was dropped in an earlier prototype and **re-added end-to-end on 2026-06-26** ("added GRAPHS end to end", commit `47c2a9e`). Any older statement that "graphs were removed" is now false. It is gated `GRAPH_ENABLED` (default `True`, [config.py:872](app/config.py#L872)).

The LLM emits a **spec, not data and not code**: `LlmReply.graph` is a `GraphSpec` (§10.7 of doc 10 / the schema) with `kind ∈ {function, parametric, implicit}`, a `curves[]` list (each a `{expr, y_expr?, label?}`, max 4 plotted), and optional `x_range`/`y_range`/`title`/labels. The backend computes `y` from the formula so there are no hallucinated points.

**Process-wide render concurrency gate** (added 2026-07-04, "added memory leak protection and cpu crash"): every ASYNC caller — per-turn dispatch AND interactive pan/zoom — MUST render through **`render_graph_gated(spec, *, view=None, quality=85, chrome=0.0, timeout=None)`** ([graph_renderer.py:50-59](app/providers/graph_renderer.py#L50)), never `render_graph` directly. It's backed by a lazily-built (binds to the running event loop) `asyncio.Semaphore` ([graph_renderer.py:40-47](app/providers/graph_renderer.py#L40)) sized from **`settings.GRAPH_RENDER_CONCURRENCY`** (default **2**, [config.py:883](app/config.py#L883)) — a **process-wide** cap, not per-lamp: each render pins a full matplotlib Agg figure + numpy grids, so an unbounded pan/zoom burst OR many lamps rendering per-turn graphs at once would otherwise stack live figures into an OOM kill on the 512 MB Render box; the semaphore bounds LIVE figures across ALL connected lamps/turns regardless of how many instances are running (scaling out doesn't raise the per-process ceiling). It offloads the sync `render_graph` call to a thread via `asyncio.to_thread` and optionally bounds it with `asyncio.wait_for(timeout=...)`.

**`render_graph(spec, *, view=None, quality=80, chrome=0.0, w=LAMP_SCREEN_W, h=LAMP_SCREEN_H)`** ([graph_renderer.py:161-328](app/providers/graph_renderer.py#L161)) — the underlying sync renderer `render_graph_gated` wraps:
- Evaluates every formula through a **restricted-AST evaluator** — `safe_eval(expr, variables)` parses `mode="eval"`, rejects any node outside `_ALLOWED_NODES`, blocks names/calls outside the `_FUNCS`/`_CONSTS` whitelist, and evals with `{"__builtins__":{}}` ([graph_renderer.py:91-109](app/providers/graph_renderer.py#L91)). No arbitrary code, numpy-only math.
- Pole/asymptote handling: `_clamp_range`, `_robust_ylim` (2nd–98th percentile window), `_break_asymptotes` (insert `NaN` at discontinuities) ([:113-158](app/providers/graph_renderer.py#L113)).
- **Implicit-plot grid is 300×300** (down from 400×400, [graph_renderer.py:205-209](app/providers/graph_renderer.py#L205)) — visually identical at the lamp's 320×240 output but ~44% less array memory per render (the `meshgrid`+`Z`+touch-locus-mask allocation is the single biggest per-render cost, so this directly lowers the OOM ceiling on the 512 MB box).
- **`chrome` parameter** ([graph_renderer.py:161-172](app/providers/graph_renderer.py#L161), applied via `fig.tight_layout(rect=...)` at [graph_renderer.py:301-306](app/providers/graph_renderer.py#L301)) — reserves this fraction of height at BOTH the top and bottom (clamped to `[0, 0.25]`, plus an extra `0.07` at the top when a title is present, to clear the bar). The full-screen interactive graph is drawn at (0,0) with the lamp's top status bar and hint strip painted OVER it, so without this reserve the title (top) and x-axis numbers (bottom) hide underneath. Both live async call sites — [dispatch.py](app/services/dispatch.py)'s per-turn render and `session.py`'s `_on_graph_view` interactive re-render (§ below) — pass `chrome=0.09`; the inline scroll-document figure passes `chrome=0.0` (it's scrolled, not chromed, so there's no chrome to clear).
- **Dark theme** set explicitly (`_BG=#000000`, `_FG=#FFFFFF`, bright cyan/amber/green/red curve palette) so plots match the white-on-black LaTeX equations. The "blank-graph bug" fix ([graph_renderer.py:219-223](app/providers/graph_renderer.py#L219)) — the old implicit-contour used black (`colors="k"`) curves that were invisible on the black panel — is the concrete evidence of the restore.
- **Output** = a **color JPEG** (matplotlib PNG → PIL → `JPEG(quality, optimize=True)`, because `savefig`'s `quality=` kwarg was removed). Returns a **5-tuple `(rx0, rx1, ry0, ry1, jpeg_bytes)`** — the actual displayed window (incl. auto-fitted y) + the bytes. Fail-open: bad/empty spec or any exception → `None`.
- **Leaked-figure fix**: `fig = None` before the `try` ([graph_renderer.py:173](app/providers/graph_renderer.py#L173)) and a `finally: if fig is not None: plt.close(fig)` ([graph_renderer.py:329-339](app/providers/graph_renderer.py#L329)) — a mid-render exception (between `plt.figure()` and the normal success-path `plt.close(fig)`) used to leave the figure pinned in pyplot's global figure registry forever (a slow OOM under repeated renders); every path now releases it (no-op on the success/early-return paths that already closed it).
- **Interactivity:** the returned window lets the lamp open an interactive arena at the same view. `session.cache_graph_spec(spec, graph_id)` keeps the spec backend-side, keyed per `graph_id` so a scroll-document turn can carry several focusable graphs ([session.py:1089-1105](app/session.py#L1089)), and `_on_graph_view` re-renders it at a new range on lamp pan/zoom when `GRAPH_ENABLED and GRAPH_INTERACTIVE` ([session.py:1200-1255](app/session.py#L1200) — see [02-websocket-protocol.md §8.5](02-websocket-protocol.md) for the request-coalescing added alongside this render-gate work).
- **Transport:** shipped by the sync-dispatch graph leg via `session.send_graph_jpeg(x0,x1,y0,y1,jpeg,…)` → **`TFT_GRAPH_JPEG`** frame, now rendered through `render_graph_gated(spec_d, quality=..., chrome=0.09, timeout=settings.LATEX_RENDER_TIMEOUT_S)` ([dispatch.py:534-540](app/services/dispatch.py#L534)). JPEG over the wire; RGB565 decode happens on-device.

### 6.4 Chemistry Structure Rendering (`rdkit_renderer.py`) — RDKit

New in 2026-07 ("added CHEM RDKIT", commit `4f89153`). Gated `CHEM_STRUCTURE_ENABLED` (default `True`, [config.py:889](app/config.py#L889)); requires the `rdkit` dependency (added to `requirements.txt` — safe to install always, the renderer degrades to a no-op if absent). This is the chemistry analogue of the LaTeX engine, for the **2D molecular structures** (skeletal/bond-line, rings, functional groups, simple reactions) that matplotlib mathtext cannot draw. Chemistry **equations/formulae still go through the LaTeX/mathtext path** — only 2D structures use RDKit.

Detection is the **model's** job: `LlmReply.structures` is a list of `ChemStructure` (`{smiles, caption?}`, max 4, L/R navigable) that the model emits only when a structure helps; there is no chemistry-vs-maths regex, and a mixed turn works (equation via the LaTeX path + structure via this renderer).

**`render_structure(smiles, *, w=None, h=None, quality=None)`** ([rdkit_renderer.py:63-98](app/providers/rdkit_renderer.py#L63)):
- Input = a SMILES string, or **reaction SMILES** containing `">>"` (`A.B>>C.D`).
- Reaction branch: `rdChemReactions.ReactionFromSmarts(useSmiles=True)` → `Draw.ReactionToImage` → fit onto the panel; molecule branch: `Chem.MolFromSmiles` → `Draw.MolToImage` → `_fit_on_canvas` (aspect-preserving thumbnail centred on a `w×h` canvas) ([:49-90](app/providers/rdkit_renderer.py#L49)).
- **Output** = a color **JPEG** at panel size, returned as `(w, h, jpeg_bytes)`. `available()` hard-checks `_RD_OK`; fail-open (not-OK / empty / unparseable / any exception → `None`).
- **Transport:** the dispatch structure leg (`_dispatch_structure_leg`, runs on BOTH dispatch paths, [dispatch.py:897-942](app/services/dispatch.py#L897)) renders each ordered structure via `asyncio.to_thread` and ships it full-screen via `session.send_chem_jpeg(...)` → **`TFT_CHEM_JPEG` (0x2A)** to the lamp's chemistry page, fail-open per step, capped at `MAX_STRUCTURES`.

### 6.5 The Scrollable-Document Composer (`document.py`) — the "assembly list" TFT model

`app/providers/document.py` is a newer TFT rendering model that replaces "one big image" with an **ordered list of BLOCKS** the lamp stacks vertically and scrolls like a feed. Gated by `TFT_SCROLL_DOC` on the dispatch side (`_dispatch_document_mode`, [dispatch.py:761-894](app/services/dispatch.py#L761)). Everything derives from the panel size (`LAMP_SCREEN_W/H`) so it re-flows for landscape OR portrait with no code change. Fail-open throughout — a bad element degrades to a placeholder / is skipped; the composer never raises.

**Block types** ([document.py:33-38](app/providers/document.py#L33)): `BLK_TEXT (0)` — a paragraph rendered **natively on the lamp** (crisp GFXFF; the backend sends only UTF-8 + an RGB565 colour, the lamp computes its own height); `BLK_EQ (1)` — a mathtext equation rendered here to a grayscale JPEG at panel width; `BLK_GRAPH (2)` — a graph JPEG; `BLK_CHEM (3)` — a molecular-structure JPEG.

- **`compose(reply, *, screen_w, screen_h)`** ([document.py:288-351](app/providers/document.py#L288)) — `LlmReply → ordered blocks`. It **splices each equation into the prose where it is referenced** (`eq1`/`eq2`… via `_EQ_REF`), appends any unreferenced equations, then the graph (using `graph_renderer` and caching `gspec`/`gwin` for the interactive arena), then the chemistry structures (each with an optional caption block). Equations reuse the mathtext engine via `_render_equation` — wide equations **shrink-to-fit** by default (`_EQ_OPERATOR_WRAP = False`, [:113](app/providers/document.py#L113)); operator-wrapping at relations/±is implemented but deferred to v1.1.
- **`build_manifest(blocks, *, kind)`** ([document.py:381-397](app/providers/document.py#L381)) — the wire manifest: `[u8 version][u8 kind][u16 n_blocks]`, then per block a type byte + (text → `[u16 color][u16 len][utf8]`; graph → `[u16 height][f32 x0,x1,y0,y1]` window for the arena; other element → `[u16 height]`). Element pixels stream separately keyed by block index; `compose_transcript` builds a native-text page of the full spoken text (the "read what was said" view).
- **Transport:** `session.send_document_manifest` / `send_document_element(_chunked)` ([session.py:1136-1172](app/session.py#L1136)). The dispatcher pre-composes the document during TTS synthesis, reveals the manifest on first audio, then interleaves element JPEGs with audio pacing ([dispatch.py:794-830](app/services/dispatch.py#L794)).
- **Preview helpers** `preview` / `preview_viewports` ([document.py:401-466](app/providers/document.py#L401)) are **test/diagnostic only** (they approximate the firmware composite with a PIL font) — not shipped.

> **New backend→lamp TFT frames** introduced by the graph/chemistry/document work: `TFT_GRAPH_JPEG`, `TFT_CHEM_JPEG` (0x2A), the document manifest/element frames, plus a JPEG equation codec (`TFT_IMAGE_CODEC="jpeg"` → `send_tft_image_jpeg`/`send_tft_image_commit`) and an append variant (`TFT_APPEND_EQUATIONS` → `send_tft_frame_append`). The send helpers all live in `session.py:1008-1250` (`send_graph_jpeg`, `send_chem_jpeg`, `send_document_manifest`/`send_document_element`, `send_tft_frame_append`); the on-wire opcodes are defined in `app/protocol.py`. (These postdate the [02-websocket-protocol.md](02-websocket-protocol.md) sync — cross-check `protocol.py` for the exact byte values.)

---

## 7. Media Cleanup & Retention (`services/media_cleanup.py`)

**Purpose**: the admin's "Delete media older than N days" button. Deletes the per-turn blobs (question audio, raw/enhanced images) referenced by `turns` and `turn_traces` rows older than a cutoff, then NULLs the URL columns. **The DB rows themselves are NEVER touched** — only the media files and their URL pointers ([media_cleanup.py:1-17](app/services/media_cleanup.py#L1)). It is **DELIBERATELY MANUAL** — no scheduler, no background task, no TTL — it runs only on `POST /api/frontend/admin/media/cleanup`.

**`_MAX_ROWS_PER_RUN = 400`** ([media_cleanup.py:33](app/services/media_cleanup.py#L33)) — per-click row budget so one click can never wedge a free-tier worker; the response reports what remains so the admin clicks again.

**`media_stats(db)`** ([media_cleanup.py:36-84](app/services/media_cleanup.py#L36)) — storage snapshot for the admin card. Best-effort per metric (each query degrades to `{}` on failure via a nested transaction). Counts `turns` and `turn_traces` rows with media + oldest timestamp. If `STORAGE_BACKEND ∈ {s3, r2}` and `S3_BUCKET`, reads exact object count + bytes from `storage.objects` (Supabase keeps object metadata in the same Postgres — no S3 API call). Returns backend, bucket, `turns_with_media`, `traces_with_media`, `storage_objects`, `storage_bytes`, `oldest_media_at`.

**`cleanup_media(db, *, days)`** ([media_cleanup.py:87-175](app/services/media_cleanup.py#L87)) — one manual pass:
1. **Clamp** `days = max(1, min(int(days or 14), 365))`.
2. **Collect the batch** (oldest first, ≤400 each): `turns` older than `now() - make_interval(days => :d)` with any of `image_url`, `audio_url`, or `extra->'image_urls'` set; `turn_traces` with any of `raw_audio_url`, `raw_image_url`, `enhanced_image_url`. Resolve every URL to a storage key via `blobs.key_from_url(...)` (skipping falsy).
3. **Delete from storage FIRST**: `deleted = await blobs.delete_keys(keys)`. If `keys` non-empty but `deleted == 0` (total storage failure — misconfigured bucket/network), **abort and change nothing** → returns `{"ok": False, ...}` so it's safely retryable. URLs stay if the delete fails.
4. **Null the URL pointers** for the processed rows only AFTER the storage delete succeeded: `turns` set `image_url=NULL, audio_url=NULL` and merge `extra` with `{"image_urls": [], "media_purged": true}`; `turn_traces` set the three URL columns NULL. `db.commit()`.
5. **Report what's left** past the cutoff (so the UI can say "click again"): `remaining_turns`, `remaining_traces`. Returns `{ok, error, turns_cleared, traces_cleared, objects_deleted, remaining_turns, remaining_traces}`.

The ordering invariant (delete blob, *then* null the URL) means a failed delete leaves the row intact for a retry ([media_cleanup.py:124-150](app/services/media_cleanup.py#L124)).

---

## 8. Configuration Reference

All defaults from [app/config.py](app/config.py).

**TTS selection & contract:**
| Var | Default | Effect |
|---|---|---|
| `TTS_PROVIDER` | `cartesia` | engine for the LAMP (**`cartesia`** default \| `gemini` \| `piper`; `kokoro_local` = reserved, silent). NB: `get_tts_provider`'s hardcoded fallback when unset is still `"piper"` |
| `CARTESIA_API_KEY` / `CARTESIA_MODEL` / `CARTESIA_VOICE_ID` | — / `sonic-3.5` / "Skylar" | Cartesia provider (live): key, model, voice |
| `CARTESIA_SPEED` / `CARTESIA_VOLUME` / `CARTESIA_EMOTION` | `0.9` / `1.2` / `""` | Cartesia tutor-voice style (clamped) |
| `FRONTEND_TTS_PROVIDER` | `piper` | engine for the web brain-bench WS — TYPE EXCLUDES `gemini` so the browser can never spend Gemini audio tokens ([config.py:75-82](app/config.py#L75)) |
| `TTS_ENABLED` | `True` | master audio on/off |
| `TTS_TARGET_SAMPLE_RATE` | `24000` | AUDIO_OUT contract rate |
| `TTS_CHUNK_BYTES` | `4096` | 85 ms @ 24 kHz int16 mono; wire chunk cap |
| `TTS_MAX_INPUT_CHARS` | `800` | `clamp_tts_text` cost cap (0 = no cap) |
| `TTS_CHUNK_MODE` | `balanced` | `single`\|`hybrid`\|`balanced`\|`full` — Gemini sentence-chunking knob (only when `GEMINI_TTS_STREAM=false`); `balanced` = gap-free 2-piece for slow TTS. **Bypassed entirely on the Cartesia path** (continuous audio). |
| `TTS_WIRE_CODEC` | `opus` | `pcm`\|`adpcm`\|`opus` wire compression (degradation chain opus→adpcm→pcm) |
| `TTS_OPUS_BITRATE` | `32000` | Opus target bits/s |
| `OPUS_LIB_PATH` | `""` | libopus path for ctypes steering on rootless hosts |

**Gemini TTS:** `GEMINI_TTS_MODEL=gemini-2.5-flash-preview-tts`, `GEMINI_TTS_VOICE=Aoede`, `GEMINI_TTS_STREAM=False` (UNARY), `GEMINI_TTS_STYLE="calm, clear, and matter-of-fact. Speak at a steady, natural pace with an intelligent and helpful tone, avoiding any exaggerated enthusiasm"`.

**Piper:** `PIPER_MODE=library`, `PIPER_BIN=piper`, `PIPER_MODEL=audio-tts/en_US-amy-medium.onnx` (empty disables), `PIPER_CONFIG=""`, `PIPER_SAMPLE_RATE=22050`, `PIPER_SPEED=0.95`, `PIPER_NOISE_SCALE=0.667`, `PIPER_NOISE_W=0.8`, `PIPER_SENTENCE_SILENCE=0.35`, `PIPER_SPEAKER=-1`.

**Image prep:** `ENABLE_IMAGE_ENHANCEMENT=True`, `LAMP_IMAGE_UNMIRROR=False`, `IMAGE_PREP_EARLY=True`, `GEMINI_FILES_PREUPLOAD=True`, `DEV_CAPTURE_DUMP=False`, `DEV_CAPTURE_DIR=./turn_captures`. (Image-preprocessor tunables are module constants, not env vars — §5.1.)

**LaTeX:** `LATEX_PAYLOAD_CAP_BYTES=1_000_000`, `LATEX_REDIS_CACHE=True`, `LATEX_REDIS_CACHE_TTL_S=259200` (3 days), `LATEX_REDIS_CACHE_MAX_BYTES=200_000`. Progressive delivery: `TFT_PROGRESSIVE_EQUATIONS=True`, `TFT_APPEND_EQUATIONS=True`.

**Graph rendering** (§6.3): `GRAPH_ENABLED=True`, `GRAPH_JPEG_QUALITY=80`, `GRAPH_INTERACTIVE=True`, `GRAPH_RENDER_CONCURRENCY=2` (process-wide cap on concurrent matplotlib renders — the OOM-prevention ceiling on the 512 MB box, added 2026-07-04) ([config.py:875-883](app/config.py#L875)).

**Chemistry structure rendering** (§6.4): `CHEM_STRUCTURE_ENABLED=True`, `CHEM_STRUCTURE_JPEG_QUALITY=85` ([config.py:889-890](app/config.py#L890)); requires the `rdkit` dependency (no-op if absent). `LAMP_SCREEN_W=320`, `LAMP_SCREEN_H=240` feed both renderers' default panel size.

**TFT delivery mode** (§6.5): `TFT_SCROLL_DOC` (scrollable-document composer), `TFT_SYNC_TO_AUDIO` (hold text/LaTeX until first audio), `TFT_IMAGE_CODEC` (`raw`|`jpeg` for equations), `TFT_INTERLEAVE_AUDIO_FRAMES` (audio/element interleave). These select which of the three dispatch modes in `dispatch.py` runs (document / sync / legacy-parallel).

**Storage / cleanup:** `STORAGE_BACKEND=local` (`off`\|`local`\|`s3`\|`r2`), `STORAGE_LOCAL_DIR=./turn_blobs`, `STORAGE_PUBLIC_BASE_URL=""`, `S3_BUCKET/S3_REGION/S3_ENDPOINT_URL/S3_ACCESS_KEY/S3_SECRET_KEY`.

---

## 9. Edge Cases, Errors, Timeouts, Fallbacks

**TTS:**
- Unknown/unimplemented `TTS_PROVIDER` → `get_tts_provider` returns None → silent turn.
- Provider construction failure → caught, returns None ([tts_base.py:181-187](app/providers/tts_base.py#L181)).
- `clamp_tts_text` over-long speech → truncated at a word boundary, logged.
- **Gemini**: 20 s hard timeout on unary; transient 429/5xx retried twice with exponential backoff (0.6 s, 1.2 s); streaming failure pre-output → unary fallback; failure mid-output → stop the stream; no audio (safety block / text-only) → `TTSError`; non-24 kHz response → `audioop.ratecv` resample (raises if audioop missing); odd trailing byte → padded.
- **Piper**: mode auto-fallback (library↔subprocess) for half-configured environments; rate mismatch with no audioop → startup `TTSError`; subprocess non-zero exit → `TTSError` with stderr; `finally` kills the process (2 s timeout) and cancels feeder/stderr tasks on cancel.
- Dispatcher treats `TTSError` and empty stream identically: log + visual-only ([dispatch.py:262-265](app/services/dispatch.py#L262)).
- Wire codec degradation chain opus → adpcm → pcm; each warns once.

**Audio preprocess**: odd/partial frame → truncate to whole frames; WAV wrap failure → original PCM returned; empty → `b""`.

**Image preprocess**: every failure (decode, processing, encode) returns the ORIGINAL bytes (fail-open); cv2 pipeline exception → PIL fallback → its own try/except → original; preshrink failure → full decode path; quick-sharpness failure → guard doesn't fire; concurrency capped at 2 to avoid OOM thrash; keep-original guard avoids paying tokens for a bigger-but-not-better enhancement.

**LaTeX**: matplotlib parse error inside the figure → red `[render error]` text; `_render_one_equation_impl` → `[eqN render error]` placeholder → last-ditch black frame (`render_ok=False`, never cached); payload cap truncates/drops overflow frames with a warning; eq_height clamped at multiple layers; Redis hiccup → render normally; error placeholders never poison the cache.

**Cleanup**: `days` clamped to [1, 365]; storage delete of 0/N keys → abort, no rows modified (retryable); per-metric stats degrade to zero/None.

---

## 10. Integration Points

**What this layer is called BY:**
- `app/services/dispatch.py::_audio_leg_impl` → `get_tts_provider().synthesize()` (the lamp WS audio leg).
- `app/routes/frontend_manager.py::_drive_turn` → the web brain-bench WS, using `FRONTEND_TTS_PROVIDER` (never Gemini).
- `app/services/dispatch.py::_dispatch_equations` → `latex_renderer.render_equations_and_pack` / `render_one_equation_cached` (progressive path).
- `app/services/image_prep.py::prep_image` → `image_preprocessor.enhance_for_llm` (kicked off by `session._on_image_terminator`, awaited by `orchestrator.run_turn`).
- `app/providers/llm_gemini.py::_drain` → `audio_preprocessor.wrap_pcm_as_wav`.
- `POST /api/frontend/admin/media/cleanup` → `media_cleanup.cleanup_media` / `media_stats`.

**What this layer calls:**
- TTS providers → `llm_gemini._client_singleton` (shared warm client), the `piper` package / CLI, `audioop`/`audioop_lts`.
- Audio out → `session.stream_audio_out_iter` → `send_audio_out_chunk` (wire codec) → WebSocket frames `AUDIO_OUT`(0x10ish)/`AUDIO_OUT_ADPCM`(0x12)/`AUDIO_OUT_OPUS`(0x13) + `AUDIO_OUT_END`.
- LaTeX → matplotlib (Agg), PIL, numpy → `session.send_tft_frame_chunked` → `TFT_PART`/`TFT_FRAME` frames; `app/services/cache` (Redis).
- Image prep → `llm_base.get_llm_provider().preupload_image` (Gemini Files API).
- Cleanup → `app/storage/blobs` (`key_from_url`, `delete_keys`), SQLAlchemy against `turns`/`turn_traces`.

**Firmware cross-references (the wire contracts this layer must satisfy):**
- `tutor_lamp/spk_i2s.cpp` — expects mono int16 LE PCM @ 24 kHz; 64 KB ring drains at ~85 ms/4 KB (drives the pacing).
- `tutor_lamp/tft_ui.cpp::on_tft_frame` — `pushColors(swap=false)`, RGB565 BGR byte-swapped; `LATEX_AREA_H = 110` (the wire-frame height); `LATEX_CACHE_BYTES = 3 MB` PSRAM accumulator (the payload cap); L/R buttons navigate equation frames using the per-equation trailer.
- The ESP32's ~5.7 KB TCP window over ~250 ms RTT caps delivery at ~20 KB/s (drives ADPCM/Opus and the LaTeX payload cap).

**DB cross-references**: `turns` (`image_url`, `audio_url`, `extra->image_urls`, `asked_at`) and `turn_traces` (`raw_audio_url`, `raw_image_url`, `enhanced_image_url`, `created_at`); Supabase `storage.objects` for stats.

---

## 11. Diagrams

### TTS hot path (lamp audio leg)

```mermaid
sequenceDiagram
    participant ORC as orchestrator.run_turn
    participant D as dispatch._audio_leg_impl
    participant F as tts_base.get_tts_provider
    participant P as Provider.synthesize()
    participant S as session.stream_audio_out_iter
    participant C as send_audio_out_chunk (wire codec)
    participant L as ESP32 lamp

    ORC->>D: reply (status, speech)
    D->>D: guard: status==ok? speech non-empty?
    D->>F: get_tts_provider()
    F-->>D: provider | None
    alt provider None / unavailable
        D-->>ORC: visual-only (no audio)
    else available
        D->>D: incremental? (Gemini-stream / Piper = yes)
        Note over D: if not incremental → _sentence_streamed (chunk by TTS_CHUNK_MODE)
        D->>P: synthesize(clamp_tts_text(speech))
        loop async PCM chunks (≤4 KB, 24 kHz)
            P-->>S: 24 kHz int16 PCM
            S->>S: re-slice to 4 KB; first 12 unpaced (prime burst)
            S->>C: chunk
            C->>C: encode pcm|adpcm|opus (degrade chain)
            C->>L: AUDIO_OUT / _ADPCM / _OPUS frame
            S->>S: sleep ~85 ms (back-pressure)
        end
        D->>L: AUDIO_OUT_END (early, before TFT eq re-sends)
    end
```

### Image prep + LaTeX render (turn assembly)

```mermaid
flowchart TD
    A[lamp FRAME_IMAGE_JPEG] --> B[session._on_image_terminator]
    B --> C[create_task prep_image raw]
    C --> D{ENABLE_IMAGE_ENHANCEMENT?}
    D -->|yes| E[enhance_for_llm in thread]
    E --> E1[preshrink oversized DCT]
    E1 --> E2[concurrency gate sem=2]
    E2 --> E3{cv2 available?}
    E3 -->|yes| E4[denoise + CLAHE + unsharp full frame]
    E3 -->|no| E5[PIL: autocontrast+contrast+sharpness+unsharp]
    E4 --> F[keep-original guard]
    E5 --> F
    D -->|no| F2[enhanced = raw]
    F --> G{GEMINI_FILES_PREUPLOAD?}
    F2 --> G
    G -->|yes once| H[preupload_image to Files API]
    G -->|no/fail| I[ref = None inline bytes]
    H --> J[PreppedImage raw/enhanced/ref]
    I --> J
    J --> K[orchestrator.run_turn awaits + sends to VLM]

    L[reply.latex_equations] --> M[render_equations_and_pack]
    M --> N[per_eq_frame_budget]
    N --> O[render_one_equation_cached]
    O --> P{Redis hit?}
    P -->|hit| Q[decode base64 frames]
    P -->|miss| R[matplotlib render_with_labels in thread]
    R --> S[RGB565 BGR byteswap + top-110 crop]
    S --> T[write-through if render_ok]
    Q --> U[pack_equation_frames header+frames+trailer]
    T --> U
    U --> V[send_tft_frame_chunked TFT_PART/TFT_FRAME]
    V --> W[ESP32 TFT]
```
