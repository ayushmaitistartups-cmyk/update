# Backend — Output Validator, Guardrails & Math Verifier

> Added 2026-07-01. **Updated 2026-07-05** (backend tip `a5533e5`; unchanged since the 2026-07-03 re-verify — the 07-03/04 commits touched rendering/memory internals, not this guardrail layer) — re-verified against the current code: `render_test` is now **FLAG-only** (equations are never dropped), `render_check.py` is a fast **syntactic heuristic** rather than a real test-render, and the new graph/chemistry/analytics config flags are catalogued in §5. This documents the **code-enforced validation + guardrail layer** built from `system-quality-improvement-report.md` (report tasks 2.x, 3.2, 4, 6). It sits *after* the LLM parse and *before* dispatch, on BOTH surfaces (lamp `orchestrator.py`, web `frontend_manager._solve_auto`). Everything here is **deterministic, pure, and fail-open** — an error ships the original reply unchanged, and every check is a no-op on an already-clean reply.

The design principle: the system prompt *asks* the model to behave; this layer *enforces* it in code. A prompt rule can be ignored by a clever student or a drifting model — a deterministic gate cannot.

---

## 1. New modules

| Module | Role |
|---|---|
| `app/services/output_validator.py` | The post-parse / pre-dispatch **gate** (report §4). An ordered check registry that REPAIRS (strip stray LaTeX, drop un-renderable equations, trim over-long speech), REPLACES (unsafe output → safe reply), or PASSES. Works on `LlmReply` (lamp) and `SimResponse` (web). |
| `app/services/render_check.py` | The **render-guard** (report §4.4 / §6.5). **Updated 2026-07-03:** it is now a fast **syntactic heuristic** (`equation_renderable`, `@lru_cache(maxsize=2048)`, [render_check.py:73-93](app/services/render_check.py#L73)) — a brace/`$`/`\left`-`\right` balance check ([:53-70](app/services/render_check.py#L53)) plus a tiny high-confidence `_DENYLIST` (`\boxed`, `\begin{`, `\substack`, `\overset`, `\underset`, `\cancel`, [:35-42](app/services/render_check.py#L35)). It deliberately does **not** invoke the real matplotlib path (docstring [:9-14](app/services/render_check.py#L9)) and deliberately does **not** denylist chemistry commands (so valid chemistry is never false-failed). `filter_renderable(eqs)` is **FLAG-ONLY** ([:104-117](app/services/render_check.py#L104)) — it returns `(original_list_unchanged, dropped_list)` and never removes/reorders (removing an equation would desync the `eqN` refs). Fail-open (any error → keep). |
| `app/services/math_verifier.py` | The **answer verifier** (report §3.2 / Addendum C). Independently recomputes the answer from the model's hidden `equation`/`given` fields (a self-contained **numpy-free** AST-whitelisted `_safe_eval` over stdlib `ast`+`math`, [math_verifier.py:82-117](app/services/math_verifier.py#L82); the module docstring's "numpy" mention is stale) and — for chemistry — counts atoms to check a balanced reaction ([:310-326](app/services/math_verifier.py#L310)) + computes molar masses over a static `_ATOMIC` table ([:329-336](app/services/math_verifier.py#L329)). Verdicts `AGREE`/`DISAGREE`/`UNCERTAIN`/`SKIPPED` ([:30-33](app/services/math_verifier.py#L30)); anything ambiguous/unparseable returns UNCERTAIN/SKIPPED (never a false DISAGREE). Its DISAGREEMENT is an escalation signal, never a replacement. |
| `app/services/input_guard.py` | The **child-safety + injection** guard (report §6.2/§6.3). `screen_input` classifies a transcript as distress / actionable-harm / sexual / injection; `screen_output_text` scans outgoing text; `safe_reply` returns a deterministic redirect. Tuned for near-zero false positives on ordinary homework (textbook science on weapons is fine). |
| `app/legacy/` | Quarantine for the dead BAO modules — **only** `validator.py` (toy LaTeX-bracket checker) + `turn_handler.py` (mock turn handler), plus `README.md`/`__init__.py` (verified at tip `80f04b6`). Superseded by `orchestrator.py` (turn flow) + `output_validator.py` (the real gate). `tests/test_no_legacy_imports.py` fails CI if `app/` re-imports any of them. Note: the five dead *prompts* remain under `app/prompts/_unused/` (not moved to `app/legacy/`), and `app/formatting/` (`tft_formatter.py`, `track_router.py`) is still a live directory. |

## 2. The check registry (order matters — report §6.4)

`output_validator.validate(reply, *, query_type, subject, surface)`:

| # | Check | Verdict | What it does |
|---|---|---|---|
| 1 | `output_safety` | REPLACE | unsafe speech/display → `input_guard.safe_reply(...)`; returns immediately |
| 2 | `speech_purity` | REPAIR | strip `$`, LaTeX commands, markdown from the spoken channel |
| 3 | `display_purity` | REPAIR | strip math notation from the TFT text card (keeps `eqN` tokens) |
| 4 | `render_test` | **FLAG** | lamp only — flags (via the `render_check` heuristic) equations the mathtext renderer likely can't draw, but **KEEPS them** so `eqN` refs never desync ([output_validator.py:191-209](app/services/output_validator.py#L191)). Changed from REPAIR→FLAG on 2026-07-03. |
| 5 | `voice_cap` | REPAIR | trim speech to the per-`query_type` word ceiling — whole sentences only, never mid-thought, never empty |
| 6 | `dangling_eqn` | FLAG | display references `eqN` with no matching equation (logged, prose untouched) |

Registry defined in `_validate` ([output_validator.py:150-235](app/services/output_validator.py#L150)); `output_safety` short-circuits and returns immediately on an unsafe reply ([:156-170](app/services/output_validator.py#L156)). Per-type voice caps (`_VOICE_CAPS`, [output_validator.py:39-43](app/services/output_validator.py#L39)): definition 15 · formula 25 · check/mistake_id 35 · calc/derivation/concept/other 45 (`_HARD_VOICE_CAP=45` for unknown types).

## 3. Wiring

- **Lamp (`orchestrator.py`):** an **input-safety short-circuit** after the pre-router (distress/harm transcript → safe redirect at zero LLM spend; injection is flagged only, never weakening the deterministic reveal gate); the **math verifier** feeds the escalation gate (`_verify_disagree`), guarded by `MATH_VERIFY_ENABLED`; the **output validator** runs immediately before `dispatch_reply`; a **per-turn LLM-call budget** backstop (`MAX_LLM_CALLS_PER_TURN`) on the escalation gate.
- **Web (`frontend_manager._solve_auto`):** ⚠️ **Correction (2026-07-06):** the `_solve_auto` wiring this bullet originally described (input-safety short-circuit, output validator in `_result`, `MAX_LLM_CALLS_PER_TURN` loop bound) was added in `4d79344` but **removed the same day in `1ed9d99`**. As of `db470f6`, `output_validator` / `input_guard` / `math_verifier` are imported **only by `orchestrator.py`** — the code-enforced stack is **lamp-only**. What the web path DOES keep is the **prompt-side** guard: `gemini_brain.build_system_prompt` prepends the `app/prompts/_guardrails.py` GUARDRAILS block, gated by `SAFETY_GUARD_ENABLED` (default `True`).
- **Traces (report §3.7):** `output_validator`, `math_verify`, `input_safety_short_circuit`, and `injection_flagged` are recorded as `tracer.note(...)` entries + `telemetry["validator"]` / `telemetry["verify_status"]`, so the admin dashboard shows exactly what the gate did.

## 4. Schema additions (report §2.4)

`LlmReply` gained hidden, **checkable** verifier fields — all internal, never spoken/shown, and **gated by `MATH_VERIFY_ENABLED`** (the `response_schema` twin strips them when off → zero extra tokens). *(Correction 2026-07-06: this is **lamp-only** — the web `SimResponse` never carried these fields; see the §3 web bullet.)* Since `db470f6` the group sits **first** in the schema (derive-before-declare scaffold):

`equation` · `given` (dict) · `unknown` · `final_answer` · `answer_units` · `method_tag` · `verification_summary`.

`_coerce_tolerant` now also coerces a malformed `given` to `{}` so a bad value never nukes the reply. The lamp prompt injects a gated `VERIFY` capture block (`_VERIFIER_RULES`) only when the flag is on.

## 5. Config flags (`app/config.py`)

| Flag | Default | Effect |
|---|---|---|
| `OUTPUT_VALIDATOR_ENABLED` | `True` | master switch for the gate |
| `SAFETY_GUARD_ENABLED` | `True` | input + output safety scan (child-facing) |
| `INJECTION_GUARD_ENABLED` | `True` | flag injection attempts (never weakens the reveal gate) |
| `RENDER_CHECK_ENABLED` | `True` | drop un-renderable equations |
| `ENFORCE_VOICE_CAPS` | `True` | trim over-long speech (whole sentences only) |
| `MAX_LLM_CALLS_PER_TURN` | `6` | per-turn call budget backstop |
| `MATH_VERIFY_ENABLED` | `True` | numeric/chem/MCQ-option verifier (hidden fields + numpy/chem/option checks). **Default `False → True` on 2026-07-06** — the free verifier now runs every quantitative turn; its DISAGREE feeds the escalation gate. See doc 13. |
| `MATH_VERIFY_TIMEOUT_S` | `2.0` | time-box for a future symbolic (sympy) path |

The verifier now also runs an **MCQ option-match** check (`math_verifier.verify_option_match`, gated on the reply's `is_mcq` flag): a computed `final_answer` matching no listed option is a wrong-equation signal that OUTRANKS a substitute-back agree (the option list is external ground truth substitute-back can't provide). See doc 13.

Verified against `app/config.py` on 2026-07-06 (`MATH_VERIFY_ENABLED` default flipped to `True`; the other seven unchanged). Adjacent **new** rendering/analytics flags added since the original write — they drive downstream rendering surfaces, **not** the validator registry (which still has exactly the six checks above):

| Flag | Default | Effect | Line |
|---|---|---|---|
| `GRAPH_ENABLED` | `True` | enable the `graph` reply channel → matplotlib plot → JPEG on a graphs page | [config.py:872](app/config.py#L872) |
| `GRAPH_JPEG_QUALITY` | `80` | graph JPEG quality | [config.py:873](app/config.py#L873) |
| `GRAPH_INTERACTIVE` | `True` | allow the lamp to pan/zoom a cached graph spec | [config.py:874](app/config.py#L874) |
| `CHEM_STRUCTURE_ENABLED` | `True` | enable the `structures` reply channel → RDKit skeletal depiction → JPEG on a chemistry page | [config.py:889](app/config.py#L889) |
| `CHEM_STRUCTURE_JPEG_QUALITY` | `85` | chemistry JPEG quality | [config.py:890](app/config.py#L890) |
| `RICH_ANALYTICS_ENABLED` | `True` | emit `topic`/`concepts`/`error_type` on the reply (stored in `turns`, never shown) | [config.py:900](app/config.py#L900) |

## 6. Prompt changes (reports 2.1/2.3/2.5/2.6/2.8)

- **2.1** — the BAO `validator.py` + `turn_handler.py` moved to `app/legacy/` (the CI-guarded quarantine). The five dead prompts live under `app/prompts/_unused/`, and `app/formatting/` (`tft_formatter.py`, `track_router.py`) remains a live directory — neither was moved into `app/legacy/`.
- **2.3** — one conservative de-duplication in the web prompt's HOW YOU TALK (the voice cap is stated authoritatively in WHAT TO ANSWER).
- **2.5** — a `SUBJECT NOTES` block on the lamp prompt (biology concept-not-math; chemistry balance; physics/math plausibility).
- **2.6** — a `CALIBRATION` few-shot block (nudge-vs-leak, mistake-localize, check→verdict, channel-split).
- **2.8** — per-query-type voice caps in RULE 1 (now also **enforced** in code by the validator).

## 7. Tests

New pytest files: `test_output_validator.py`, `test_render_check.py`, `test_math_verifier.py`, `test_input_guard.py`, `test_no_legacy_imports.py` (50 tests, all green). Verified: valid chemistry is KEPT while `\boxed`/`aligned`/broken LaTeX is dropped; the verifier agrees on a correct projectile/Ohm/combustion answer and disagrees on a wrong one, blocks code-injection input, and never emits a false disagree; the safety guard catches distress/harm/injection without flagging textbook science. A forward-compat fix to `graph_renderer.py` (`ast.Num` was removed in Python 3.12+) lets the suite run on modern interpreters.

**Verifier contract reminder:** it validates *execution, not setup*. A wrong formula still yields a faithful wrong number, so its result is only ever an **escalation signal** (agreement → confidence; disagreement → climb a tier) — it never silently replaces the model's answer. See report Addendum C.
