# Backend — Brain Optimization, Eval Harness, Prompt Versioning & CI

> Added 2026-07-06 (backend tip after the `improvment/08` implementation pass). This documents the changeset that implemented the "structure the brain like a professional AI/prompt engineer" plan from `improvment/08_brain_optimization_and_testing.md`. It is the canonical record for: the accuracy-default flips, the MCQ option-match verifier, the schema reasoning-scaffold reorder, implicit-cache observability, prompt versioning, and the new `evals/` harness + CI. Where an older doc still cites a pre-2026-07-06 default, **this doc wins**.

Grounded in `Smart-Tutor-Lamp-backend/`. See also: [11-output-validator-guardrails-and-verifier.md](11-output-validator-guardrails-and-verifier.md) (the verifier this builds on), [04-escalation-and-model-selection.md](04-escalation-and-model-selection.md) (the escalation gate the verifier feeds), [05-llm-providers.md](05-llm-providers.md) and [10-formatting-schemas-and-admin.md](10-formatting-schemas-and-admin.md) (the schema + defaults).

---

## Table of Contents

1. [What changed and why](#1-what-changed-and-why)
2. [Accuracy defaults flipped](#2-accuracy-defaults-flipped)
3. [MCQ option-match verifier](#3-mcq-option-match-verifier)
4. [Schema as a reasoning scaffold](#4-schema-as-a-reasoning-scaffold)
5. [Implicit-cache observability](#5-implicit-cache-observability)
6. [Prompt-as-code: versioning + budget](#6-prompt-as-code-versioning--budget)
7. [The eval harness (`evals/`)](#7-the-eval-harness-evals)
8. [CI](#8-ci)
9. [What was deliberately deferred](#9-what-was-deliberately-deferred)

---

## 1. What changed and why

The brain was already sophisticated (deterministic pre-router, tiered thinking dispatch, guard stack, output validator). The gap was **measurement and a few dormant/miscalibrated defaults**, not missing machinery. This pass turned on the free accuracy levers, made the implicit-cache discount observable, gave the prompt a version + budget, and — most importantly — built the `evals/` harness so "accuracy" becomes a number with a confidence interval instead of a vibe.

Every change respects the change-control rule (`improvment/08` §7): behaviour-neutral or flag-guarded; the two quality-coupled default flips (temperature, confidence) are flagged for a paired eval once a valid `GEMINI_API_KEY` is available. Nothing on the §9 "forbidden" list (no cached Socratic replies, no trimmed guardrails, no dropped escalation) was touched.

## 2. Accuracy defaults flipped

| Setting | Old | New | File | Rationale |
|---|---|---|---|---|
| `MATH_VERIFY_ENABLED` | `False` | **`True`** | `config.py` | The free numpy/chem/option verifier was dormant. Now runs every quantitative turn; a DISAGREE feeds the escalation gate (`orchestrator._verify_disagree`) — never replaces the answer. ~30-80 extra output tokens on quantitative turns only. |
| `GEMINI_TEMPERATURE` | `1.0` | **`0.4`** → later reverted to **`1.0`** | `config.py` | This pass lowered it to 0.4 (the config comment argued for 0.3-0.4 for schema-constrained math). Being quality-coupled, it was pending a golden-set A/B; the code default was subsequently **restored to `1.0`** (the current production value), so downstream docs cite `1.0`. Re-tune via the `evals/` harness before changing again. |
| parse-failure `confidence` | `0.8` | **`0.3`** (garbage only) | `llm_response.py` `_coerce_tolerant` | A GARBAGE confidence defaulting to 0.8 sat above the 0.45 escalation gate → a broken reply *suppressed* its own escalation. Now garbage → 0.3 (routes to escalation). An **absent/null** field still uses the 0.8 schema default (omission ≠ garbage). |

## 3. MCQ option-match verifier

`math_verifier.verify_option_match(problem_statement, claimed_answer)` — added because JEE/NEET are mostly multiple-choice and substitute-back is structurally blind to a wrong *formula* (it faithfully verifies the wrong number). The option list is external ground truth the model didn't produce.

- **Gated on the reply's `is_mcq` flag** (so multi-part "(a)/(b)" labels never parse as options), requires ≥2 options incl. A and B with numeric values; anything unclean → `UNCERTAIN`/`SKIPPED` (never a false DISAGREE).
- In `math_verifier.verify(...)` a clean option **miss OUTRANKS** a substitute-back agree: a wrong equation that self-consistently computes its own wrong number is still caught when that number matches no option.
- Tests: `tests/test_math_verifier.py` — `test_option_match_*`, `test_verify_gates_option_match_on_is_mcq`, `test_verify_option_miss_outranks_numeric_agree`.

## 4. Schema as a reasoning scaffold

The hidden verifier fields (`equation`, `given`, `unknown`, `verification_summary`, `final_answer`, `answer_units`, `method_tag`) moved to the **top** of `LlmReply`, before `speech`/`display`. Gemini's constrained decoder generates JSON keys in schema property order, and generation is sequential — so the model must **derive** (equation → givens → verification) before it **declares** `final_answer` and only then **phrases** the spoken/shown answer. This is a chain-of-thought effect at zero prompt-token cost, effective even on the thinking=0 tier-1 path.

The long *conditional* fields (`problem_statement`, `solution_outline`) deliberately stay AFTER the presentation channels, so the truncation-salvage of `speech` (which extracts the leading `speech` value) is unaffected. Field order verified to still parse through `_coerce_tolerant`.

## 5. Implicit-cache observability

Gemini implicit caching discounts cache-hit prefix tokens ~90% (the ~7,667-token static system prompt is the intended prefix). To **verify** the discount rather than assume it, `usage_metadata.cached_content_token_count` is now captured into `telemetry["llm_cached_tok"]`, printed in the `[GEMINI]` log line and the per-tier trace note, and mirrored on the web path (`gemini_brain._extract_usage` → `cached_tokens`). The prompt is already byte-stable per process; the remaining lever (moving per-turn notes off `system_instruction` so the prefix reliably hits) is tracked in `improvment/08` §4.1, not yet done.

## 6. Prompt-as-code: versioning + budget

- **`PROMPT_VERSION`** (`turn1_system.py`, currently `"1.0.0"`) — semver, with a bump-on-edit changelog in the file header. Stamped into `turn_traces` (`llm_raw_prompt_brief`) and every eval result, so a paired eval regression is attributable to a specific prompt revision.
- **`tests/test_prompt_version_budget.py`** enforces four invariants: PROMPT_VERSION is semver; `get_turn1_prompt()` is byte-stable within a process (a varying prefix kills every implicit-cache hit); the assembled prompt stays within a char/token budget (fails the PR if the monolith re-accretes); per-turn notes are newline-prefixed append blocks (prefix-stability contract).

## 7. The eval harness (`evals/`)

The measurement layer for the >95%-answer-accuracy target (`improvment/08` §6). New directory in the backend root:

| File | Role |
|---|---|
| `evals/cases/*.jsonl` | the golden set — one JSON case per line (schema documented atop `graders.py`) |
| `evals/graders.py` | programmatic grading (numeric tolerance / option letter+value / string alternatives / refusal-redirect) + `wilson_interval` + exact `mcnemar_exact_p`. Pure, no network. |
| `evals/run_evals.py` | drives the **real** backend path (`model_solver.generate_solution` — same prompt/schema/coercion/provider stack, direct model pick); `--selftest` runs offline; writes stratified results + Wilson CIs + cost/latency to `evals/results/` |
| `evals/report.py` | one-run summary, or **paired** comparison of two runs (exact McNemar on shared case ids — the honest before/after for a prompt/model/config change) |
| `evals/README.md` | how to run it + the rules that keep it honest |

**Seed set (~50 cases):** JEE physics/math/chemistry, NEET biology, plus refusal/injection/perception. This is the **Phase-1 pilot gate** (`improvment/08` §6.1) — enough to catch gross regressions, NOT enough to *claim* 95% (that needs ~300 cases at 97% observed, ~1,475 at 96%; §6.3). Grow it from real failing pilot turns.

**Statistics discipline:** every rate ships with a 95% Wilson interval; version comparisons use paired McNemar (detects a 97→95 regression with far fewer cases than unpaired). Offline coverage in `tests/test_evals_graders.py` (grader logic + golden-set integrity).

## 8. CI

> **Removed 2026-07-08 (`e53ce33`).** The `.github/workflows/backend-ci.yml` workflow described below was **deleted two days after it landed** — the `backend` branch no longer runs GitHub Actions. (The `samiul` `docs/` folder added 2026-07-07 also included a README whose CI badge was fixed in `5077d5d` "fixed readme ci error" before the workflow itself was dropped.) The **13 script-style test conversions** below are unaffected — those tests still run under pytest locally. This section is retained as the historical record of what the 07-06 pass shipped.

`.github/workflows/backend-ci.yml` (ran on push/PR to the `backend` branch): ruff (non-blocking until the lint debt is burned down), FastAPI import smoke, `pytest`, and the eval graders selftest. Excluded only the tests needing resources CI doesn't provide — `test_gemini_to_esp_live` (live API + monkeypatches globals) and `test_chem_structure` (the optional `rdkit` native lib). Also in this pass: **13 script-style tests** that used to abort pytest collection with a module-level `sys.exit` were converted to run under both pytest and standalone.

## 9. What was deliberately deferred

Per the change-control rule, two high-value but **quality-coupled** items are gated behind a golden-set paired baseline (which needs a valid API key — the local dev key was invalid at implementation time):

- The **§10 prompt restructure/trim** (7,667 → ~4,500-5,000 tok; one shared `PEDAGOGY_CORE` + per-surface display contract; instruction-hierarchy block; say-each-rule-once) — `improvment/08` roadmap step 7.
- The **escalation retarget** (mid-hard → Gemini 3 Flash, Pro only for verifier-flagged/dispute) — step 8.

Doing either blind (without a before/after eval) is on the `improvment/08` §9 forbidden list.
