# Backend — Lamp WebSocket Protocol & Real-time Pipeline

This document is the definitive reference for the binary WebSocket protocol that connects the ESP32-S3 "Smart Tutor Lamp" to its Python FastAPI backend, and the real-time pipeline that turns a recorded question into streamed TTS speech and rendered display frames. It covers the connection handshake and authentication (dev + prod), the complete frame/opcode catalog in both directions, the 4-byte wire framing and its hard size budget, audio in/out streaming + pacing, codecs (PCM/ADPCM/Opus), ordering and half-duplex invariants, keepalive/heartbeats, idle timeouts, error handling, and the end-to-end control flow from "lamp records audio" to "backend streams TTS back". Everything here is grounded in the actual source files cited inline; nothing is invented.

The protocol primitives live in [`app/protocol.py`](app/protocol.py); the WebSocket endpoint and auth in [`app/routes/ws_lamp.py`](app/routes/ws_lamp.py); per-connection state and all frame send/receive helpers in [`app/session.py`](app/session.py); the per-turn pipeline in [`app/services/orchestrator.py`](app/services/orchestrator.py); the outbound dispatch (TTS + LaTeX legs) in [`app/services/dispatch.py`](app/services/dispatch.py); the lamp-side pairing HTTP endpoints in [`app/routes/device_lamp.py`](app/routes/device_lamp.py); and the firmware-facing protocol contract in [`IMPLEMENTATION_WEBSOCKET.md`](IMPLEMENTATION_WEBSOCKET.md).

---

## Table of contents

1. [Purpose and responsibility](#1-purpose-and-responsibility)
2. [Architecture overview](#2-architecture-overview)
3. [The wire format (4-byte header)](#3-the-wire-format-4-byte-header)
4. [Complete frame / opcode catalog](#4-complete-frame--opcode-catalog)
5. [Size budget, constants and codecs](#5-size-budget-constants-and-codecs)
6. [Connection lifecycle: pairing → handshake → auth](#6-connection-lifecycle-pairing--handshake--auth)
7. [The receive loop, keepalive and idle timeout](#7-the-receive-loop-keepalive-and-idle-timeout)
8. [Inbound processing: lamp → backend](#8-inbound-processing-lamp--backend)
9. [Outbound processing: backend → lamp](#9-outbound-processing-backend--lamp)
10. [The full turn pipeline (record → stream TTS)](#10-the-full-turn-pipeline-record--stream-tts)
11. [The dispatch graph (TTS leg + TFT leg)](#11-the-dispatch-graph-tts-leg--tft-leg)
12. [Ordering guarantees and half-duplex invariants](#12-ordering-guarantees-and-half-duplex-invariants)
13. [Error handling, timeouts, retries and fallbacks](#13-error-handling-timeouts-retries-and-fallbacks)
14. [Configuration and environment variables](#14-configuration-and-environment-variables)
15. [File-by-file / function-by-function breakdown](#15-file-by-file--function-by-function-breakdown)
16. [Integration points](#16-integration-points)
17. [Sequence diagram](#17-sequence-diagram)

---

## 1. Purpose and responsibility

The lamp talks to its backend over **one persistent secure WebSocket** (`wss://<host>:443/lamp/ws`). All traffic — mic audio in, the wake-time JPEG(s), the TTS PCM/codec stream out, the TFT (display) pixel frames, and small control bytes — multiplexes through that single socket as **binary** WebSocket messages, each carrying exactly one application frame with a 4-byte self-describing header ([IMPLEMENTATION_WEBSOCKET.md §0](IMPLEMENTATION_WEBSOCKET.md), [§4.2](IMPLEMENTATION_WEBSOCKET.md)).

There is **no REST on the hot path**, no polling, and no second TCP connection for a turn. One socket per device, opened at boot, reconnected on drop. WebSocket is used over REST specifically to amortise the TCP+TLS handshake across the whole session (saving ~300 ms per voice turn) and to let the server **push** TTS audio and TFT frames without the device having to ask ([IMPLEMENTATION_WEBSOCKET.md §0](IMPLEMENTATION_WEBSOCKET.md)).

The backend's responsibilities in this area are:

- **Authenticate** the lamp on WS upgrade (dev bypass or prod `device_jwt` + DB row check) — [`ws_lamp.py:175`](app/routes/ws_lamp.py#L175).
- **Frame** all messages with the 4-byte header and **enforce the lamp's hard size ceiling** so a too-large message can never crash the device — [`protocol.py:130`](app/protocol.py#L130), [`session.py:541`](app/session.py#L541).
- **Accumulate** chunked inbound media (multi-part images, streamed mic audio) into a per-turn buffer — [`session.py:280`](app/session.py#L280)–[`session.py:404`](app/session.py#L404).
- **Drive** the per-turn pipeline (STATE bytes → LLM → parallel TTS + LaTeX dispatch → finalize) — [`orchestrator.py:86`](app/services/orchestrator.py#L86).
- **Pace** outbound audio to exactly match the lamp's speaker drain rate, and **chunk** large TFT payloads so they never exceed the per-message ceiling — [`session.py:713`](app/session.py#L713), [`session.py:874`](app/session.py#L874).
- **Maintain liveness** via uvicorn ping/pong (primary), a 30 s DB heartbeat (prod), a Redis revocation watcher (prod), and a 10-minute idle backstop — [`ws_lamp.py:135`](app/routes/ws_lamp.py#L135), [`ws_lamp.py:232`](app/routes/ws_lamp.py#L232).

The lamp-facing pairing endpoints in [`device_lamp.py`](app/routes/device_lamp.py) are HTTP (not WebSocket), but they mint the `device_jwt` the lamp later presents on the WS upgrade — so they are the *precondition* for the protocol and are documented in §6.

---

## 2. Architecture overview

### 2.1 Modules

| Module | Role |
|---|---|
| [`app/protocol.py`](app/protocol.py) | Wire primitives — `FrameType` / `StateByte` enums, `encode`/`decode`, and the size-budget constants. No I/O. |
| [`app/routes/ws_lamp.py`](app/routes/ws_lamp.py) | The `/lamp/ws` FastAPI WebSocket endpoint: auth, accept, side-task spawn (heartbeat + revocation watcher), the receive loop, idle timeout, teardown. |
| [`app/session.py`](app/session.py) | `Session` (per-connection state + all send/receive helpers) and `Turn` (per-utterance input buffer). The single chokepoint where every outbound frame is encoded, size-guarded, locked and sent. |
| [`app/services/orchestrator.py`](app/services/orchestrator.py) | `TurnOrchestrator.run_turn` — the per-turn lifecycle: STATE(thinking) → LLM tiers → STATE(speaking)/STATE(error) → dispatch → finalize. |
| [`app/services/dispatch.py`](app/services/dispatch.py) | `dispatch_reply` — decides which outbound frames a parsed `LlmReply` produces and runs the TTS leg + TFT leg in parallel. |
| [`app/routes/device_lamp.py`](app/routes/device_lamp.py) | HTTP `POST /api/device/register` and `POST /api/device/poll-pairing` — first-boot enrolment, pairing-code mint, and JWT delivery. |
| [`app/services/device_jwt.py`](app/services/device_jwt.py) | Mint + verify the `device_jwt` (HS256, no `exp`). |
| [`app/services/revocation.py`](app/services/revocation.py) | Redis pub/sub `watch_revocation` for instant unlink. |

The router is mounted at startup: `app.include_router(ws_router)` is always on, while the pairing routes are only wired when `ENABLE_AUTH=True` ([`main.py:234`](app/main.py#L234), [`main.py:258`](app/main.py#L258)–[`main.py:266`](app/main.py#L266)).

### 2.2 Key data structures

**`FrameType(IntEnum)`** — [`protocol.py:16`](app/protocol.py#L16). The one-byte opcode for every frame. Ranges: lamp→backend `0x01..0x07`, backend→lamp `0x10..0x40`, web-only superset `0x50..0x52`. (Full catalog in §4.)

**`StateByte(IntEnum)`** — [`protocol.py:89`](app/protocol.py#L89). The single-byte payload of a `STATE` (`0x30`) frame: `IDLE=0x00`, `LISTENING=0x01`, `THINKING=0x02`, `SPEAKING=0x03`, `ERROR=0x04`, `UNPAIRED=0x05`.

**`Turn` (dataclass)** — [`session.py:159`](app/session.py#L159). Per-utterance input buffer, reset on `AUDIO_END` handoff and on `CANCEL`:

| Field | Type | Meaning |
|---|---|---|
| `images` | `list[bytes]` | Completed JPEGs (1..`MAX_IMAGES_PER_TURN`) assembled this turn. |
| `image_accum` | `bytearray` | The in-flight image being assembled from `IMAGE_PART` chunks. |
| `audio_pcm` | `bytearray` | Accumulated 16 kHz mono int16 LE mic PCM. |
| `started_at` | `float` | `time.monotonic()` when the `Turn` object was created (includes idle). |
| `first_frame_at` | `float \| None` | Monotonic time of the FIRST media frame — the real capture-latency anchor. |
| `audio_chunks` | `int` | Count of `AUDIO_CHUNK`/decoded-ADPCM chunks received. |
| `image_preps` | `list[asyncio.Task]` | Early per-image enhance + Gemini Files pre-upload tasks, 1:1 with `images`. |
| `adpcm_rx_state` | `tuple \| None` | UPLINK IMA/DVI ADPCM decoder state `(predicted, index)`, continuous per turn. |
| `duration_s` (property) | `float` | `len(audio_pcm) / (16000*2)` — derived utterance length in seconds. |

**`Session`** — [`session.py:195`](app/session.py#L195). One per connected lamp. Holds `device_id`, `user_id` (Clerk ID from the JWT, `None` in dev), `db_session_id` (DB sessions-row UUID), the live `ws`, the `current_turn`, a `tasks` dict (one in-flight `"turn"` task at a time), an `asyncio.Lock` serialising all `send_bytes`, TX counters, `last_activity` (monotonic, bumped on every inbound AND outbound frame), the per-stream ADPCM encoder state `_adpcm_state`, and the lazily-built Opus encoder `_opus`.

**`_OpusWire`** — [`session.py:89`](app/session.py#L89). Per-stream Opus encoder: slices the 24 kHz mono int16 stream into 20 ms (480-sample / 960-byte) frames, carrying a sub-frame tail across chunks and zero-padding it at `flush()`. One encoded packet per WS frame.

---

## 3. The wire format (4-byte header)

Every WebSocket *message* carries exactly **one** application frame ([IMPLEMENTATION_WEBSOCKET.md §4.2](IMPLEMENTATION_WEBSOCKET.md)). The frame layout, defined and implemented in [`protocol.py:1`](app/protocol.py#L1):

```
 0       1               4                                       4 + N
 ├───────┼───────────────┼───────────────────────────────────────┤
 │ type  │ length (BE)   │ payload                               │
 │ u8    │ u24, network  │ N bytes                               │
 └───────┴───────────────┴───────────────────────────────────────┘
```

- `type` — 1 byte, the opcode (`FrameType`).
- `length` — 3 bytes, **big-endian / network byte order**, the payload length. Range `0 … 16 777 215` (`_MAX_PAYLOAD = (1 << 24) - 1`, [`protocol.py:127`](app/protocol.py#L127)).
- `payload` — exactly `length` bytes; structure depends on `type`.

All frames are sent as **binary** WS messages, even when the payload is UTF-8 text (`TFT_TEXT`). One application frame == one WS message; never split or merge ([IMPLEMENTATION_WEBSOCKET.md §4.2](IMPLEMENTATION_WEBSOCKET.md)).

### 3.1 `encode` — [`protocol.py:130`](app/protocol.py#L130)

```python
def encode(type_: int, payload: bytes = b"") -> bytes:
    n = len(payload)
    if n > _MAX_PAYLOAD:
        raise ValueError(f"payload too large ({n} > {_MAX_PAYLOAD})")
    return bytes((int(type_) & 0xFF,
                  (n >> 16) & 0xFF, (n >> 8) & 0xFF, n & 0xFF)) + payload
```

Mechanically: it masks the type to one byte, splits the 24-bit length into three big-endian bytes, concatenates them with the payload. It raises `ValueError` if the payload would overflow the 24-bit length field. Note: `encode` enforces only the **24-bit** ceiling; the much stricter **4 KB** per-message ceiling is enforced one level up in `Session.send_frame` (§5).

### 3.2 `decode` — [`protocol.py:145`](app/protocol.py#L145)

```python
def decode(buf: bytes) -> tuple[int, bytes]:
    if len(buf) < 4:
        raise ValueError(f"short frame ({len(buf)} bytes, need >= 4)")
    type_ = buf[0]
    n = (buf[1] << 16) | (buf[2] << 8) | buf[3]
    if 4 + n != len(buf):
        raise ValueError("length mismatch: ...")
    return type_, bytes(buf[4 : 4 + n])
```

The inverse: it rejects buffers shorter than 4 bytes, reconstructs the big-endian length, and **strictly validates** that the declared length exactly matches the buffer (`4 + n == len(buf)`), raising `ValueError` on mismatch. The WS receive loop catches that `ValueError`, logs it, and **drops the frame without closing the socket** ([`ws_lamp.py:263`](app/routes/ws_lamp.py#L263)).

---

## 4. Complete frame / opcode catalog

All opcodes are defined in [`protocol.py:16`](app/protocol.py#L16). The firmware-facing v1 subset is also tabulated in [IMPLEMENTATION_WEBSOCKET.md §4.3](IMPLEMENTATION_WEBSOCKET.md); the protocol has since grown the ADPCM/Opus/append/web opcodes below.

### 4.1 Lamp → backend

| Hex | Name | Payload | Meaning |
|---|---|---|---|
| `0x01` | `IMAGE_JPEG` | raw JPEG (or terminator of a chunked image) | One per captured image, before audio. Whole JPEG if small, else the terminator after `IMAGE_PART`s. [`protocol.py:18`](app/protocol.py#L18) |
| `0x02` | `AUDIO_CHUNK` | int16 LE 16 kHz mono, 640 B / ~20 ms | Streamed mic audio during the command. [`protocol.py:19`](app/protocol.py#L19) |
| `0x03` | `AUDIO_END` | empty | End of utterance — fires the LLM call. [`protocol.py:20`](app/protocol.py#L20) |
| `0x04` | `CANCEL` | empty | User pressed Select — abort the turn. [`protocol.py:21`](app/protocol.py#L21) |
| `0x05` | `IMAGE_PART` | intermediate chunk of a chunked image | Accumulated into `Turn.image_accum`. [`protocol.py:22`](app/protocol.py#L22) |
| `0x06` | `AUDIO_CHUNK_ADPCM` | IMA/DVI ADPCM mic audio (4:1) | Uplink codec: 8 KB/s instead of raw PCM's 32 KB/s. Decoder state continuous per turn; backend decodes into `Turn.audio_pcm`. [`protocol.py:23`](app/protocol.py#L23) |
| `0x07` | `AUDIO_RESET` | empty | Lamp detected uplink TX drops → backend discards ALL streamed audio + decoder state; the full utterance follows from the lamp's `cmd_buf` copy, then `AUDIO_END`. Delivery guarantee for collapsing links. [`protocol.py:30`](app/protocol.py#L30) |

### 4.2 Backend → lamp

| Hex | Name | Payload | Meaning |
|---|---|---|---|
| `0x10` | `AUDIO_OUT` | int16 LE 24 kHz mono TTS, 4 KB chunks / 85 ms pacing | TTS speech (PCM frame; the default wire codec is now `opus`/`AUDIO_OUT_OPUS`). [`protocol.py:37`](app/protocol.py#L37) |
| `0x11` | `AUDIO_OUT_END` | empty | **REQUIRED** — releases the lamp's I2S back to the mic. [`protocol.py:38`](app/protocol.py#L38) |
| `0x12` | `AUDIO_OUT_ADPCM` | IMA/DVI ADPCM (4:1) TTS, 1 KB chunk = 85.3 ms | Sent instead of `AUDIO_OUT` when `TTS_WIRE_CODEC=adpcm`: 12 KB/s vs 48 KB/s. Decoder state continuous, resets at `AUDIO_OUT_END`. [`protocol.py:39`](app/protocol.py#L39) |
| `0x13` | `AUDIO_OUT_OPUS` | one Opus packet/frame (20 ms @ 24 kHz, ~80–120 B @ 32 kbps) | Sent when `TTS_WIRE_CODEC=opus`; lamp needs `USE_OPUS_DECODER=1`. ~4 KB/s wire. Encoder dropped / `OPUS_RESET_STATE` at `AUDIO_OUT_END`. [`protocol.py:46`](app/protocol.py#L46) |
| `0x20` | `TFT_FRAME` | `[W H nFrames rsv][RGB565 pixels]` (or terminator of a chunked frame) | Display content — equation render, etc. Inner layout in [IMPLEMENTATION_WEBSOCKET.md §4.4](IMPLEMENTATION_WEBSOCKET.md). [`protocol.py:51`](app/protocol.py#L51) |
| `0x21` | `TFT_TEXT` | UTF-8, ≤ 1900 B (lamp `s_text[2048]`) | Plain-text card. [`protocol.py:52`](app/protocol.py#L52), [`session.py:613`](app/session.py#L613) |
| `0x22` | `TFT_CLEAR` | empty | Blank the display. [`protocol.py:53`](app/protocol.py#L53) |
| `0x23` | `TFT_PART` | intermediate chunk of a chunked TFT frame, ≤ 2 KB | Chunker slices. [`protocol.py:54`](app/protocol.py#L54) |
| `0x24` | `TFT_LATEX_LOADING` | empty | Lamp shows a "rendering equation…" skeleton in the TOP half. Sent before the chunked `TFT_FRAME`; not sent if the reply has no LaTeX. [`protocol.py:55`](app/protocol.py#L55) |
| `0x25` | `TFT_APPEND` | append-segment terminator | Splices NEW frames' pixels after pixels the lamp already holds (byte-prefix property). Only when `TFT_APPEND_EQUATIONS=true`; flash firmware first. [`protocol.py:60`](app/protocol.py#L60) |
| `0x26` | `TFT_APPEND_BEGIN` | empty | Arms the lamp's accumulator to write following `TFT_PART`s AFTER the committed pack. [`protocol.py:69`](app/protocol.py#L69) |
| `0x30` | `STATE` | 1 byte (`StateByte`) | Drives LED/page state. [`protocol.py:73`](app/protocol.py#L73) |
| `0x40` | `DEBUG_JSON` | UTF-8 JSON of the parsed `LlmReply` | Dev echo. Real lamp falls through `default:` and silently drops it. [`protocol.py:74`](app/protocol.py#L74) |

### 4.3 Web-only superset (browser ⇄ backend, `/api/frontend/ws`)

These reuse the same framing for the web brain-bench so the browser and the lamp hit identical wire code. They sit ABOVE the lamp's range; a physical lamp silently drops unknown types ([`protocol.py:79`](app/protocol.py#L79)):

| Hex | Name | Direction | Payload |
|---|---|---|---|
| `0x50` | `TEXT_IN` | web → backend | user-typed message (UTF-8). [`protocol.py:84`](app/protocol.py#L84) |
| `0x51` | `TEXT_OUT` | backend → web | streamed assistant text token (UTF-8). [`protocol.py:85`](app/protocol.py#L85) |
| `0x52` | `TEXT_OUT_END` | backend → web | end of an assistant message. [`protocol.py:86`](app/protocol.py#L86) |

### 4.4 Unknown opcodes

Both sides MUST silently drop unknown `type` values and NOT close the connection ([IMPLEMENTATION_WEBSOCKET.md §4.3](IMPLEMENTATION_WEBSOCKET.md)). On the backend, an unhandled inbound type hits the `else` branch in `Session.on_frame` and is logged at WARNING only ([`session.py:277`](app/session.py#L277)). On the lamp, unknown types fall through `default:` in `handle_server_frame`.

---

## 5. Size budget, constants and codecs

The dominant hardware constraint is the lamp's `ArduinoWebsockets` library allocating a contiguous DRAM `std::string` of `len(payload)` bytes for **every** received WS message. Beyond ~4 KB, that alloc fails under WiFi+camera+I2S load + DRAM fragmentation → `std::bad_alloc` → `terminate()` → reboot ([`protocol.py:99`](app/protocol.py#L99)–[`protocol.py:120`](app/protocol.py#L120)). The constants in [`protocol.py:121`](app/protocol.py#L121)–[`protocol.py:124`](app/protocol.py#L124):

| Constant | Value | Effect |
|---|---|---|
| `WS_HARD_MAX_BYTES` | `4 * 1024` (4096) | Absolute ceiling. `Session.send_frame` **refuses** any payload above this and raises `ValueError` so the bug surfaces in the per-turn try/except instead of as a silent reboot. |
| `WS_MAX_FRAME_BYTES` | `2 * 1024` (2048) | Slice size for the TFT chunker — stays well under the ceiling even under heap fragmentation. |
| `AUDIO_OUT_CHUNK_BYTES` | `4 * 1024` (4096) | 2048 int16 LE samples @ 24 kHz = 85.3 ms playback. Largest legitimate single frame. |
| `AUDIO_OUT_PACE_S` | `0.085` | One audio chunk every 85 ms — matches the lamp's 24 kHz mono drain rate so the 64 KB speaker ring never overflows. |

### 5.1 Inbound ingest gates ([`session.py:147`](app/session.py#L147)–[`session.py:164`](app/session.py#L164))

| Constant | Value | Effect |
|---|---|---|
| `_MAX_IMAGE_BYTES` | `256 * 1024` | Per-image cap, lock-step with the firmware's `TX_ASSEMBLE_BYTES`. Over-cap images are dropped (turn continues). |
| `MAX_IMAGES_PER_TURN` | `5` | Defense-in-depth vs a tampered lamp; extra images dropped + logged. |
| `_MIN_AUDIO_S` | `0.5` | Utterances shorter than this are dropped as a likely false wake. |
| `_MAX_AUDIO_S` | `30.0` | Utterances longer are TRUNCATED to the cap (whole int16 frames only), not discarded. |
| `_AUDIO_BYTES_PER_S` | `16_000 * 2` (32000) | int16 LE @ 16 kHz mono — the divisor for `duration_s`. |
| `_MAX_AUDIO_BYTES` | `int((_MAX_AUDIO_S + 5.0) * _AUDIO_BYTES_PER_S)` (~35 s) | Added 2026-07-04. **Hard mid-stream ceiling** on `Turn.audio_pcm` — see §8.2. |
| `_MAX_IMAGE_ACCUM_HARD` | `_MAX_IMAGE_BYTES * 2` (512 KB) | Added 2026-07-04. **Hard mid-stream ceiling** on `Turn.image_accum` — see §8.1. |

### 5.2 TTS streaming constants ([`session.py:129`](app/session.py#L129)–[`session.py:141`](app/session.py#L141))

| Constant | Value | Effect |
|---|---|---|
| `_SEND_TIMEOUT_S` | `2.0` | Per-`send_bytes` timeout; on timeout the socket is closed with code 1011. |
| `_TTS_PRIME_CHUNKS` | `12` | The first 12 × 4 KB = 48 KB of TTS ship **unpaced** (prime burst) to fill the lamp's ~1 s pre-roll jitter buffer (`spk_i2s.cpp PREROLL_BYTES = 48 KB`) fast; the rest are paced at realtime. |

### 5.3 The three wire codecs

The wire codec is selected by `settings.TTS_WIRE_CODEC` (`pcm` | `adpcm` | `opus`, default `opus`) and applied at the single chokepoint `Session.send_audio_out_chunk` ([`session.py:648`](app/session.py#L648)). Upstream pacing/prime-burst logic always works in **PCM-time** (85 ms of audio per chunk); the wire carries whatever codec is selected. The **degradation chain is opus → adpcm → pcm**, each step warning once:

- **opus** ([`session.py:673`](app/session.py#L673)): a `_OpusWire` is lazily built on the first chunk. On construction failure (`opuslib`/libopus missing) `_opus_dead` latches and the codec degrades. Each PCM chunk is right-padded to even length, encoded into one-or-more 20 ms Opus packets, each sent as a separate `AUDIO_OUT_OPUS` frame.
- **adpcm** ([`session.py:691`](app/session.py#L691)): if `audioop` (stdlib ≤3.12, or `audioop-lts` on ≥3.13) is missing, it warns once and falls back to PCM. Otherwise `audioop.lin2adpcm(pcm, 2, self._adpcm_state)` encodes 4:1 with **continuous encoder state across the whole stream** (including across per-sentence synth pieces), sent as `AUDIO_OUT_ADPCM`.
- **pcm** ([`session.py:706`](app/session.py#L706)): odd byte counts are padded (a protocol bug otherwise — the lamp's I2S writer would split a sample), then sent as `AUDIO_OUT`.

Codec state is **reset at the stream boundary** in `send_audio_out_end` ([`session.py:852`](app/session.py#L852)): any sub-frame Opus tail is flushed as a final padded packet, `_opus` is dropped, and `_adpcm_state` is set to `None` — so the next stream starts bit-aligned with the lamp's decoder (which resets at `AUDIO_OUT_END` too).

The **uplink** ADPCM decoder is the mirror image: `_on_audio_chunk_adpcm` calls `audioop.adpcm2lin(payload, 2, self.current_turn.adpcm_rx_state)` and feeds the resulting PCM into the same `Turn.audio_pcm` buffer, so everything downstream sees plain 16 kHz PCM ([`session.py:368`](app/session.py#L368)).

---

## 6. Connection lifecycle: pairing → handshake → auth

### 6.1 Pairing (HTTP, prerequisite for the WS auth)

Before a lamp can authenticate the WS upgrade in prod, it must own a `device_jwt`. Two public HTTPS endpoints (no Clerk, no JWT — auth is `device_id` + `device_secret` in the JSON body, verified with argon2id) provide it, in [`device_lamp.py`](app/routes/device_lamp.py):

**`POST /api/device/register`** ([`device_lamp.py:48`](app/routes/device_lamp.py#L48), rate-limited `30/hour`):
1. Opportunistically deletes ALL expired pairing codes (self-healing sweep) — [`device_lamp.py:63`](app/routes/device_lamp.py#L63).
2. Looks up the `Device` by `device_id`. If absent → first-boot enrolment: store the argon2 hash of `device_secret`, no user yet ([`device_lamp.py:71`](app/routes/device_lamp.py#L71)). If present → verify the secret; mismatch → `401` with `DEV_AUTH_FAIL` ([`device_lamp.py:81`](app/routes/device_lamp.py#L81)).
3. **Recovery path**: if the device is already paired-and-active (`user_id IS NOT NULL` and `revoked_at IS NULL`) but is calling `/register` (lost its JWT / NVS wipe), re-mint a fresh `device_jwt` for the SAME user and return `status="already_paired"` so the lamp leaves the QR screen without re-scanning ([`device_lamp.py:97`](app/routes/device_lamp.py#L97)–[`device_lamp.py:106`](app/routes/device_lamp.py#L106)).
4. Otherwise drop any prior pairing rows for this device (one live code per device), generate a unique 6-char code (8-try collision loop over a 36⁶ keyspace), persist a `pending` `PairingCode` with TTL `PAIRING_CODE_TTL_SEC` (default 300 s), and return `pairing_code` / `pairing_url` / `expires_in` ([`device_lamp.py:113`](app/routes/device_lamp.py#L113)–[`device_lamp.py:148`](app/routes/device_lamp.py#L148)).

**`POST /api/device/poll-pairing`** ([`device_lamp.py:160`](app/routes/device_lamp.py#L160), rate-limited `40/minute`): the lamp polls every 3 s for the whole 5-min TTL. It verifies the device secret, validates that the code exists AND belongs to this device (404 otherwise, to avoid leaking codes for other devices), and returns one of:
- `expired` — past TTL (lazily deleted) — [`device_lamp.py:189`](app/routes/device_lamp.py#L189).
- `pending` — not yet linked by a user — [`device_lamp.py:195`](app/routes/device_lamp.py#L195).
- `paired` — returns the `device_jwt` and **deletes the row** (single-use; subsequent polls 404 and the lamp stops polling) — [`device_lamp.py:198`](app/routes/device_lamp.py#L198).

The request/response shapes are pydantic models in [`schemas/auth.py`](app/schemas/auth.py): `DeviceRegisterIn`/`DeviceRegisterOut`, `DevicePollIn`/`DevicePollOut` ([`schemas/auth.py:21`](app/schemas/auth.py#L21)–[`schemas/auth.py:58`](app/schemas/auth.py#L58)).

### 6.2 The `device_jwt`

Minted by `sign_device_jwt(device_id, clerk_user_id)` ([`device_jwt.py:43`](app/services/device_jwt.py#L43)): HS256, signed with the **backend's own** `DEVICE_JWT_SECRET` (not Clerk's), with claims `{sub: device_id, uid: clerk_user_id, iat, iss, ver: 1}`. **There is no `exp` claim** — revocation is canonical via `devices.revoked_at` checked at WS-connect time ([`device_jwt.py:7`](app/services/device_jwt.py#L7)).

`verify_device_jwt(token)` ([`device_jwt.py:55`](app/services/device_jwt.py#L55)) decodes with `verify_exp=False` and `require_iat=True`, validates the issuer, raises `InvalidDeviceJwt` on bad signature / wrong issuer / malformed JSON / `ver < JWT_VERSION` / missing `sub`/`uid`. The caller must additionally check the DB row (runtime state, not crypto).

### 6.3 WS handshake & authentication ([`ws_lamp.py:175`](app/routes/ws_lamp.py#L175))

The lamp upgrades `wss://<host>:443/lamp/ws` with header `Authorization: Bearer <device_jwt>`. The endpoint:

1. Extracts the bearer token via `_extract_bearer` (lowercase "bearer" + token; empty string otherwise) — [`ws_lamp.py:69`](app/routes/ws_lamp.py#L69).
2. Picks the auth mode by `settings.ENABLE_AUTH` — [`ws_lamp.py:180`](app/routes/ws_lamp.py#L180):
   - **Dev (`False`)**: `_authenticate_dev` accepts ANY bearer (including the literal `dev-mode-no-auth`) and maps to the single bench identity `("dev-lamp", None, None)` — dev turns persist with `user_id=NULL` ([`ws_lamp.py:78`](app/routes/ws_lamp.py#L78)).
   - **Prod (`True`)**: `_authenticate_prod` ([`ws_lamp.py:84`](app/routes/ws_lamp.py#L84)) lazily imports the auth deps, runs `verify_device_jwt` (failure → close `4401`), then a per-connect DB check requiring **all** of: `Device` row present, `user_id IS NOT NULL` (paired), `revoked_at IS NULL` (not unlinked), and `user_id == jwt["uid"]` (same Clerk user). Any failure → close `4402`. On success it bumps `devices.last_seen_at` and returns `(device_id, uid, None)`.
3. If auth failed (`device_id is None`), close with the failure code (or `4401` default) and return — **never** `accept()`. Otherwise `await ws.accept()` ([`ws_lamp.py:185`](app/routes/ws_lamp.py#L185)–[`ws_lamp.py:192`](app/routes/ws_lamp.py#L192)).
4. Construct the `Session`, open a DB `sessions` row (`open_session`), log a `ws_open` lifecycle event ([`ws_lamp.py:195`](app/routes/ws_lamp.py#L195)–[`ws_lamp.py:205`](app/routes/ws_lamp.py#L205)).
5. In prod only, spawn two side-tasks ([`ws_lamp.py:210`](app/routes/ws_lamp.py#L210)–[`ws_lamp.py:229`](app/routes/ws_lamp.py#L229)): a **revocation watcher** (`watch_revocation` → `_on_revoked` → `_close_unlinked`) and a **30 s heartbeat** (`_heartbeat`).

**Close codes** (per the auth-pairing spec §11.2):

| Code | Meaning | Source |
|---|---|---|
| `4401` (`WS_CLOSE_BAD_JWT`) | invalid / expired `device_jwt` | [`ws_lamp.py:48`](app/routes/ws_lamp.py#L48) |
| `4402` (`WS_CLOSE_UNLINKED`) | device unlinked / revoked / wrong user | [`ws_lamp.py:49`](app/routes/ws_lamp.py#L49) |
| `1000` | normal close (idle timeout) | [`ws_lamp.py:255`](app/routes/ws_lamp.py#L255) |
| `1011` | internal error (send timeout) | [`session.py:585`](app/session.py#L585) |

### 6.4 Revocation & heartbeat (prod)

- **`watch_revocation(device_id, on_revoked)`** ([`revocation.py:129`](app/services/revocation.py#L129)) subscribes to Redis channel `device:revoked:<id>` and runs `on_revoked` on the first message — closing the socket within ~1 s. It polls `get_message(timeout=15.0)` and treats timeouts/`None` as "still watching" so an idle pub/sub survives the whole session. No-op if Redis is unconfigured.
- **`_heartbeat`** ([`ws_lamp.py:135`](app/routes/ws_lamp.py#L135)) wakes every `HEARTBEAT_S = 30.0` s: if the `Device` row is gone / `revoked_at` set / `user_id` cleared, it calls `_close_unlinked` (covers Redis being down); otherwise it bumps `last_seen_at`. It exits cleanly when the `stop` event is set.
- **`_close_unlinked(ws)`** ([`ws_lamp.py:162`](app/routes/ws_lamp.py#L162)) best-effort sends `STATE(0x05 UNPAIRED)` so the lamp wipes its JWT locally before its WS lib surfaces the close code, then closes `4402`.

---

## 7. The receive loop, keepalive and idle timeout

The endpoint's main loop ([`ws_lamp.py:231`](app/routes/ws_lamp.py#L231)–[`ws_lamp.py:280`](app/routes/ws_lamp.py#L280)) uses explicit `receive_bytes()` + `asyncio.wait_for` rather than Starlette's `iter_bytes()` so it can apply an idle timeout — `iter_bytes` would block forever on a half-dead TCP, leaking an orchestrator task per dropped lamp and burning LLM tokens.

```python
while True:
    try:
        msg = await asyncio.wait_for(ws.receive_bytes(), timeout=WS_IDLE_TIMEOUT_S)
    except asyncio.TimeoutError:
        if session.has_active_turn() or session.seconds_idle() < WS_IDLE_TIMEOUT_S:
            continue                       # re-arm — healthy idle / mid-turn
        await ws.close(code=1000); break   # genuinely wedged → close, lamp reconnects
    except WebSocketDisconnect as e:
        break
    try:
        type_, payload = decode(msg)
    except ValueError as e:
        log.warning(...); continue          # one bad frame ≠ kill the session
    try:
        await session.on_frame(type_, payload)
    except Exception:
        log.exception(...)                  # a buggy handler must NOT take down the loop
```

### 7.1 Keepalive layers

| Layer | Mechanism | Period |
|---|---|---|
| **Primary** dead-TCP detector | uvicorn's WS ping/pong (`ws_ping_interval` / `ws_ping_timeout`); the lamp auto-answers protocol pings | (uvicorn config) — [`ws_lamp.py:56`](app/routes/ws_lamp.py#L56) |
| **Idle backstop** | `WS_IDLE_TIMEOUT_S = 600.0` (10 min) — catches a genuinely wedged socket only | 600 s — [`ws_lamp.py:66`](app/routes/ws_lamp.py#L66) |
| **DB heartbeat** (prod) | `_heartbeat` bumps `last_seen_at` + re-checks `revoked_at` | `HEARTBEAT_S = 30.0` |
| **Revocation** (prod) | Redis pub/sub | ~instant |

The idle backstop is deliberately **long** because the lamp legitimately sends NO application frame while idle (wake-word detection is local) and protocol pings don't surface as `receive_bytes` ([`ws_lamp.py:56`](app/routes/ws_lamp.py#L56)–[`ws_lamp.py:66`](app/routes/ws_lamp.py#L66)). On timeout the loop **re-arms** (does not close) if a turn is still streaming OR there was ANY traffic in either direction within the window — `last_activity` is bumped on outbound sends too ([`session.py:599`](app/session.py#L599)), so a long TTS playback can never trip it.

### 7.2 Teardown ([`ws_lamp.py:283`](app/routes/ws_lamp.py#L283)–[`ws_lamp.py:294`](app/routes/ws_lamp.py#L294))

The `finally` block always: sets `stop`, cancels both side-tasks, logs a `ws_close` lifecycle event (paired with `ws_open`), calls `finalize_session` (closes the DB session row + refreshes the L3 learner profile in the background), and `await session.close()` (cancels any in-flight turn task and gives it one event-loop turn to finish its `finally:` cleanup).

---

## 8. Inbound processing: lamp → backend

`Session.on_frame(type_, payload)` ([`session.py:245`](app/session.py#L245)) is the inbound dispatcher. On every frame it:
1. Bumps `last_activity = time.monotonic()` (feeds the idle timeout).
2. Stamps `current_turn.first_frame_at` on the FIRST media frame (`IMAGE_PART`/`IMAGE_JPEG`/`AUDIO_CHUNK`/`AUDIO_CHUNK_ADPCM`) — the capture-latency anchor for the admin trace.
3. Routes by opcode.

### 8.1 Image assembly

- **`IMAGE_PART` (0x05)** → `_on_image_part` ([`session.py:310`](app/session.py#L310)): extends `image_accum`; logs (not enforces) an overflow warning when `accum + part > _MAX_IMAGE_BYTES` — the cap check happens at the terminator. **Hard ceiling (added 2026-07-04):** before that, if `len(accum) >= _MAX_IMAGE_ACCUM_HARD` (512 KB = 2× `_MAX_IMAGE_BYTES`) the part is dropped outright ([`session.py:316-317`](app/session.py#L316)) — protects against a lamp that streams `IMAGE_PART` and never sends the `IMAGE_JPEG` terminator, which would otherwise grow `image_accum` unbounded (a per-session OOM distinct from the terminator-time reject above; a genuinely oversized-but-finite image still crosses `_MAX_IMAGE_BYTES` and is rejected there as before).
- **`IMAGE_JPEG` (0x01)** → `_on_image_terminator` ([`session.py:295`](app/session.py#L295)): finalises the in-flight image. If `image_accum` is non-empty it appends the terminator payload and clears the accumulator; otherwise the terminator payload IS the whole JPEG (single-frame case) or a zero-byte end-of-image marker. It then **validates JPEG magic** (`\xff\xd8` SOI at the head AND `\xff\xd9` EOI within the last 64 bytes) — a corrupt/partial image is dropped and the turn continues audio-only. Oversized (`> _MAX_IMAGE_BYTES`) or over-cap (`>= MAX_IMAGES_PER_TURN`) images are dropped (no `STATE(error)` — one bad frame shouldn't punish the user). On success the image is appended to `Turn.images` and, if `IMAGE_PREP_EARLY` is on, an `asyncio.create_task(prep_image(...))` enhance+pre-upload task is launched immediately (runs during the user's speech) and tracked 1:1 in `Turn.image_preps`.

### 8.2 Audio accumulation

- **`AUDIO_CHUNK` (0x02)** → `_on_audio_chunk` ([`session.py:424`](app/session.py#L424)): drops a trailing odd byte (with a warning), extends `Turn.audio_pcm`, increments `audio_chunks`, and logs every 25th chunk. **Hard ceiling (added 2026-07-04):** before extending, if `len(audio_pcm) >= _MAX_AUDIO_BYTES` (~35 s, 5 s past the legit 30 s limit) the chunk is dropped instead ([`session.py:435-443`](app/session.py#L435)), logging a one-time warning ("no AUDIO_END?") the first time it crosses. This protects against a lamp that streams audio and never sends `AUDIO_END`, which would otherwise grow `audio_pcm` unbounded — a per-session OOM distinct from `AUDIO_END`'s own truncate-to-30s (§8.3 step 4), which still applies to a genuine (but finite) oversized utterance that does complete.
- **`AUDIO_CHUNK_ADPCM` (0x06)** → `_on_audio_chunk_adpcm` ([`session.py:404`](app/session.py#L404)): if `audioop` is missing, audio is **discarded** with a one-time error; otherwise it decodes to PCM (continuous per-turn `adpcm_rx_state`) and funnels into `_on_audio_chunk` (so it's subject to the same hard ceiling above).
- **`AUDIO_RESET` (0x07)** ([`session.py:262`](app/session.py#L262)): the lamp lost uplink chunks and is about to re-send the WHOLE utterance from its local copy — so the backend **clears** `audio_pcm`, resets `audio_chunks = 0` and `adpcm_rx_state = None`, then the authoritative copy decodes from a fresh state.

### 8.3 `AUDIO_END` (0x03) — the turn trigger ([`session.py:405`](app/session.py#L405))

This is where ingest hands off to the pipeline:
1. **Snapshot + reset**: `turn = self.current_turn; self.current_turn = Turn()` immediately, so the next utterance can begin collecting while this one processes.
2. Compute `dur_s = len(audio_bytes) / _AUDIO_BYTES_PER_S`.
3. **Min-duration gate**: `dur_s < 0.5` → drop the turn (likely false wake), cancel any image-prep tasks, send `STATE(IDLE)` so the LED returns to cyan, return.
4. **Max-duration gate**: `dur_s > 30.0` → truncate `audio_bytes` to `30 s` worth of whole int16 frames (`max_bytes -= max_bytes % 2`).
5. **One-turn-in-flight invariant**: if a previous `"turn"` task is still alive, cancel it and `await asyncio.wait_for(asyncio.shield(old), timeout=2.0)` so its `finalize_turn()` (AUDIO_OUT_END + STATE idle) lands BEFORE the new turn's `STATE(thinking)` — otherwise a stale idle could clobber the new spinner.
6. Stamp `session.last_capture_ms` (first-frame → AUDIO_END).
7. Spawn `orchestrator.run_turn(self, images, audio_bytes, image_preps=...)` as a named task, store it under `"turn"`, and attach `_on_turn_done` (which pops the task and logs a crash if it raised but wasn't cancelled — [`session.py:482`](app/session.py#L482)).

### 8.4 `CANCEL` (0x04) ([`session.py:492`](app/session.py#L492))

`_on_cancel`: cancels any in-flight image-prep tasks, resets `current_turn`, cancels and awaits the in-flight `"turn"` task, then emits the **half-duplex cleanup trio** — `TFT_CLEAR`, `AUDIO_OUT_END` (so the lamp releases I2S TX back to the mic even if it was mid-playback), and `STATE(IDLE)`.

### 8.5 `GRAPH_VIEW` — interactive pan/zoom re-render ([`session.py:1200`](app/session.py#L1200)–[`session.py:1255`](app/session.py#L1255))

`_on_graph_view(payload)`: the lamp's graph page pan/zoom re-render, gated on `GRAPH_ENABLED and GRAPH_INTERACTIVE`. Payload = `[u8 graph_id][f32 x0][f32 x1][f32 y0][f32 y1]` (BE, 17 B); a 16-byte payload from older firmware is accepted with `graph_id` defaulting to 0. `graph_id` selects WHICH cached spec to re-render — `self._graph_specs.get(int(graph_id) & 0xFF)` — since a scroll-document turn can carry several focusable graphs (see [06-tts-and-media.md §6.3](06-tts-and-media.md), `cache_graph_spec`); this is the backend counterpart of the firmware's new `graph_id` prefix byte on `GRAPH_VIEW` for multi-graph-per-document support ([01-firmware/02-display-and-ui.md §4.7](../01-firmware/02-display-and-ui.md)). A missing spec, or a malformed/NaN window, is silently ignored.

**Request coalescing (added 2026-07-04, "cpu crash Iteration 1 done"):** a fast pan/zoom drag fires many `GRAPH_VIEW` messages faster than a single render completes — previously each one triggered its own `render_graph` call, so renders could pile up concurrently. Now the handler keeps only the LATEST requested window via a `_graph_pending` / `_graph_draining` pair ([`session.py:1231-1255`](app/session.py#L1231)):
- Every incoming request overwrites `self._graph_pending = (graph_id, x0, x1, y0, y1)`.
- If a drain loop is already running (`self._graph_draining`), the new request just returns — the running loop will pick it up.
- Otherwise the caller becomes the drain loop: it sets `_graph_draining = True` and loops, each iteration taking whatever is currently in `_graph_pending` (clearing it first), looking up that `graph_id`'s spec, and rendering via `render_graph_gated(spec, view=..., quality=GRAPH_JPEG_QUALITY, chrome=0.09)` (the process-wide concurrency-gated renderer — [06-tts-and-media.md §6.3](06-tts-and-media.md)), shipping the result with `send_graph_jpeg`, then looping back to check `_graph_pending` again. The loop exits (clearing `_graph_draining` in a `finally`) once no request arrived while the last render was in flight.

This collapses an arbitrarily fast pan/zoom burst to **one render per finished frame** instead of one render per incoming message, and — combined with the render-concurrency semaphore — bounds both in-flight renders and queued work to a constant, memory-safe amount regardless of how fast the lamp drags.

---

## 9. Outbound processing: backend → lamp

Every outbound frame funnels through `Session.send_frame` ([`session.py:541`](app/session.py#L541)) — the single point that encodes, size-guards, serialises, and accounts:

1. If `self._closed`, drop silently (avoids Starlette's noisy post-teardown `RuntimeError`).
2. **Hard guard**: `len(payload) > WS_HARD_MAX_BYTES (4096)` → raise `ValueError` ("Lamp would bad_alloc + reboot"). This is the load-bearing protection against device crashes.
3. `encode(type_, payload)` → bytes.
4. `async with self._send_lock:` serialise writes (Starlette's WebSocket is not safe for concurrent writes — e.g. CANCEL cleanup racing a TFT_PART stream).
5. `await asyncio.wait_for(self.ws.send_bytes(frame), timeout=_SEND_TIMEOUT_S (2.0))`. On `TimeoutError`: mark `_closed`, close the socket with **code 1011**, re-raise. On any other exception (usually `WebSocketDisconnect` mid-write): mark `_closed`, re-raise.
6. Increment `_tx_frames` / `_tx_bytes`, bump `last_activity`, and log a one-liner every 256 frames.

### 9.1 Small control frames

- `send_state(byte)` → `STATE` (0x30) with a 1-byte payload — [`session.py:606`](app/session.py#L606).
- `send_tft_text(s)` → `TFT_TEXT` (0x21), UTF-8 capped at `TFT_TEXT_MAX_BYTES = 1900` with a **UTF-8-safe word-boundary cut** (walks back to a space if past the halfway mark, then trims any incomplete multi-byte lead bytes so the lamp's font renderer never sees a half-glyph) — [`session.py:615`](app/session.py#L615).
- `send_tft_clear()` → `TFT_CLEAR` (0x22) — [`session.py:635`](app/session.py#L635).
- `send_tft_latex_loading()` → `TFT_LATEX_LOADING` (0x24), emitted before a chunked LaTeX `TFT_FRAME` — [`session.py:638`](app/session.py#L638).

### 9.2 Audio out

- `send_audio_out_chunk(pcm)` ([`session.py:648`](app/session.py#L648)): the codec chokepoint (§5.3). Raises `ValueError` if `len(pcm) > AUDIO_OUT_CHUNK_BYTES`.
- `stream_audio_out(pcm, ...)` ([`session.py:713`](app/session.py#L713)): slices a whole PCM blob into `chunk_bytes` (4 KB) frames and paces them. The **first `_TTS_PRIME_CHUNKS` ship unpaced** (prime burst), then `await asyncio.sleep(pace_s)` between sends; the sleep is **skipped after the last chunk** so the speaker drains promptly. Re-raises `CancelledError` cleanly.
- `stream_audio_out_iter(pcm_chunks, ...)` ([`session.py:774`](app/session.py#L774)): the **low-latency live path** used by the TTS leg. It consumes an async iterator as the provider produces audio, **re-slicing the byte stream to exactly `chunk_bytes`** (decoupling wire chunk size from provider chunk size), prime-bursts the first 12 chunks, paces the rest, pads a final odd-length partial chunk, and provides **back-pressure** (while sleeping it isn't pulling from the iterator, so Piper blocks on its stdout pipe and memory stays bounded). Returns total PCM bytes sent.
- `send_audio_out_end()` ([`session.py:852`](app/session.py#L852)): flushes the Opus tail, resets both codec states, sends `AUDIO_OUT_END` (0x11).

### 9.3 TFT out (chunked)

- `send_tft_frame_chunked(payload)` ([`session.py:874`](app/session.py#L874)): if `payload <= WS_MAX_FRAME_BYTES` send a single `TFT_FRAME`; otherwise send `TFT_PART` (0x23) slices of `WS_MAX_FRAME_BYTES` until the tail, then a single `TFT_FRAME` (0x20) terminator that commits the page. Cancellation-safe: a missing terminator is itself the abort signal (the lamp's PSRAM accumulator resets on the next part cycle).
- `send_tft_frame_append(segment)` ([`session.py:920`](app/session.py#L920)): sends `TFT_APPEND_BEGIN` (0x26) → `TFT_PART`s → `TFT_APPEND` (0x25) terminator, splicing only the new equation frames after the committed pack. Only valid when `TFT_APPEND_EQUATIONS=true` AND a base pack already shipped this turn.

### 9.4 The half-duplex finalizer

`finalize_turn()` ([`session.py:963`](app/session.py#L963)) sends `AUDIO_OUT_END` then `STATE(IDLE)` — the pair the lamp REQUIRES to re-arm the mic. Idempotent on the lamp, safe to call multiple times. The orchestrator calls it in its `finally`, and the early `AUDIO_OUT_END` in the dispatch audio leg means the lamp gets the duplicate END tolerantly (`acquire_i2s_tx` clears stale end-marks).

---

## 10. The full turn pipeline (record → stream TTS)

`TurnOrchestrator.run_turn(session, images, audio_bytes, image_preps)` ([`orchestrator.py:86`](app/services/orchestrator.py#L86)) is the per-turn lifecycle, consumed by `Session._on_audio_end`. Mechanically, on the WS-frame timeline:

1. **`STATE(thinking)`** ([`orchestrator.py:148`](app/services/orchestrator.py#L148)) — the lamp shows the orbiting-dot spinner.
2. **Memory load** — L3 profile + L2 summary + L1 recent turns into `history_text` ([`orchestrator.py:151`](app/services/orchestrator.py#L151)).
3. **Image prep harvest / enhancement** — early-prep tasks (started in `session.py` while the user spoke) are awaited with an 8 s bound; otherwise images are enhanced inline off the event loop (`asyncio.to_thread(enhance_for_llm, ...)`, with `unmirror=LAMP_IMAGE_UNMIRROR` because lamp JPEGs arrive left-right mirrored) ([`orchestrator.py:179`](app/services/orchestrator.py#L179)–[`orchestrator.py:262`](app/services/orchestrator.py#L262)).
4. **Deterministic pre-router** (optional, `PREROUTE_ENABLED`) — a fast Groq Whisper transcript (kicked off concurrently with enhancement) + image-quality gate decide a starting tier and whether to short-circuit to a "retake the photo" reply with **zero LLM spend** ([`orchestrator.py:277`](app/services/orchestrator.py#L277)–[`orchestrator.py:343`](app/services/orchestrator.py#L343)). A retake still sends `STATE(SPEAKING)` then `dispatch_reply(...)` and returns (finalizer still runs).
5. **Tiered LLM call** (`_call_tier`) with an 8 s TTFT-instrumented timeout; tiers map 1→Flash thinking=0, 2→Flash thinking=1024, 3→Pro. Post-answer **escalation** climbs toward the ceiling on truncation / low confidence / hard reasoning, and several guards (echo, focus, solution-bleed, reveal-completeness) may re-call once. (Full tier logic is below `run_turn` in the same file.)
6. **`STATE(speaking)` or `STATE(error)`** ([`orchestrator.py:971`](app/services/orchestrator.py#L971)–[`orchestrator.py:975`](app/services/orchestrator.py#L975)) — `STATE(error)` (red strobe) if the provider's telemetry `status` is not `ok`/`None`, else `STATE(speaking)`.
7. **Optional `DEBUG_JSON`** ([`orchestrator.py:949`](app/services/orchestrator.py#L949)) — when `EMIT_DEBUG_JSON`, the parsed reply JSON is sent as one small frame BEFORE dispatch (real lamp drops it).
8. **Dispatch** ([`orchestrator.py:990`](app/services/orchestrator.py#L990)) — `dispatch_reply(session, reply, status=..., model_tag=..., trace=...)` runs the parallel TTS + LaTeX legs (§11).
9. **Persist** (fire-and-forget) — `asyncio.create_task(self._persist_turn(...))` ([`orchestrator.py:1015`](app/services/orchestrator.py#L1015)).
10. **`finally: finalize_turn()`** ([`orchestrator.py:1053`](app/services/orchestrator.py#L1053)) — ALWAYS emits `AUDIO_OUT_END` + `STATE(idle)` (even on error), then `gc.collect()` to reclaim transient buffers. The cancel path skips this because `Session._on_cancel` issues the cleanup trio itself.

On `CancelledError` the orchestrator marks the trace `cancelled` and re-raises; on any other exception it sends `STATE(error)` + a "Sorry, I had trouble — try again." `TFT_TEXT` ([`orchestrator.py:1022`](app/services/orchestrator.py#L1022)–[`orchestrator.py:1052`](app/services/orchestrator.py#L1052)).

---

## 11. The dispatch graph (TTS leg + TFT leg)

`dispatch_reply` ([`dispatch.py:52`](app/services/dispatch.py#L52)) is the single source of truth for the backend→lamp per-turn ordering. It does NOT touch `STATE` bytes or `AUDIO_OUT_END` — those bracket the dispatch in the orchestrator/audio leg. Its sequence:

1. **Instant `TFT_TEXT`** ([`dispatch.py:97`](app/services/dispatch.py#L97)–[`dispatch.py:109`](app/services/dispatch.py#L109)) — always sent (even on error) so the lamp stops showing the spinner ASAP. The text is chosen by `_text_card_payload` ([`dispatch.py:487`](app/services/dispatch.py#L487)) per `display.kind` (`text` → full `display.content`; `latex`/`none` → `reply.speech` capped at `_CAPTION_BYTE_CAP = 200`) and scrubbed of leaked LaTeX markup by `_scrub_math_markup` ([`dispatch.py:462`](app/services/dispatch.py#L462)). An optional `model_tag` is appended to the card only (shown, not spoken).
2. **`TFT_LATEX_LOADING` skeleton** ([`dispatch.py:114`](app/services/dispatch.py#L114)) — ONLY when `status == ok` AND the reply has ≥1 non-empty equation (`has_equations`). Avoids a skeleton-then-`TFT_CLEAR` flicker on padded `[""]` equation lists.
3. **Parallel legs** ([`dispatch.py:140`](app/services/dispatch.py#L140)) — `asyncio.gather(_dispatch_audio_leg, _dispatch_tft_leg)` so audio chunks and `TFT_PART` chunks **interleave on the wire** (the 85 ms pace sleeps yield the loop to the display leg). An `asyncio.Event audio_done` coordinates the two.

### 11.1 Audio leg ([`dispatch.py:149`](app/services/dispatch.py#L149))

`_dispatch_audio_leg` wraps `_audio_leg_impl` and ALWAYS signals `done_evt` on every exit path (skip / success / error / cancel). It sends `AUDIO_OUT_END` **the moment the stream ends** (before releasing the TFT leg's deferred equation send) because bytes are FIFO on the socket — if END queued behind a 70–140 KB append segment it would reach the lamp seconds late and hold I2S (mic deaf). It skips the early END on cancel (Session._on_cancel owns that).

`_audio_leg_impl` ([`dispatch.py:188`](app/services/dispatch.py#L188)) has three SKIP guards before any synthesis cost: (1) non-`ok` status → skip (error speech is visual-only); (2) empty/whitespace speech → skip; (3) TTS provider unavailable → skip gracefully. Then it picks the provider via `get_tts_provider()` (gemini | piper). For incremental providers (Piper) it feeds `tts.synthesize(speech, turn_id)` straight into `session.stream_audio_out_iter`; for whole-utterance providers (Gemini unary) it wraps in `_sentence_streamed` so first audio tracks the first short clause.

`_sentence_streamed` ([`dispatch.py:572`](app/services/dispatch.py#L572)) splits speech into TTS pieces via `_tts_chunks` (governed by `TTS_CHUNK_MODE`: `single` = 1 piece; `hybrid` = first short clause + the rest merged = 2 calls; `full` = ~180-char groups; `balanced` = the default — a middle-ground splitter between `hybrid` and `full`), with `_TTS_FIRST_PIECE_CHARS = 70` / `_TTS_LATER_PIECE_CHARS = 180`, and **one-ahead prefetch** (synthesises piece N+1 while pacing piece N), re-slicing to `TTS_CHUNK_BYTES` and cancelling all in-flight synth tasks on `CancelledError`.

### 11.2 TFT leg ([`dispatch.py:268`](app/services/dispatch.py#L268))

`_dispatch_tft_leg` short-circuits on non-`ok` status. For replies with equations it calls `_dispatch_equations` ([`dispatch.py:299`](app/services/dispatch.py#L299)), which renders each equation in a worker thread (`render_one_equation_cached` → `asyncio.to_thread`; a Redis cache hit skips matplotlib), packs frames via `pack_equation_frames`, and ships via `send_tft_frame_chunked` (or `send_tft_frame_append` when `TFT_APPEND_EQUATIONS`).

**Progressive delivery** (`TFT_PROGRESSIVE_EQUATIONS` + multi-eq turns): eq1 ships the moment it renders, but every LATER equation **waits for the audio leg to release the wire** (`audio_done.is_set()`), with a 90 s bound so a wedged audio leg can't hold equations hostage — because a mid-speech multi-hundred-KB pack starves the lamp's speaker ring (observed 2026-06-10: 9.2 s gap). The byte-prefix property of the cumulative pack makes the re-sends safe on the lamp without firmware changes.

---

## 12. Ordering guarantees and half-duplex invariants

From [IMPLEMENTATION_WEBSOCKET.md §4.6](IMPLEMENTATION_WEBSOCKET.md) and enforced across `session.py` / `dispatch.py`:

- WebSocket guarantees **in-order delivery within one direction**. The lamp may rely on `AUDIO_OUT*` arriving in send order; the backend may rely on `AUDIO_CHUNK` arriving in send order.
- **No ordering guarantee between directions** — the lamp may see `STATE(thinking)` before its own `AUDIO_END` fully flushes.
- `IMAGE_JPEG` for a turn MUST precede any `AUDIO_CHUNK` of that turn; `AUDIO_END` MUST be the last lamp→backend frame of a turn.
- `AUDIO_OUT_END` MUST be the last `AUDIO_OUT*` frame of a turn — the lamp uses it to drain its speaker ring and return to idle.
- **Turns are implied** by the `AUDIO_END` → `AUDIO_OUT_END` boundary; there is no explicit turn-id in v1.
- **Half-duplex invariant**: the lamp's I2S is shared between speaker and mic. After speaking, the lamp needs `AUDIO_OUT_END` + `STATE(idle)` to release I2S TX back to the mic — hence `finalize_turn` is mandatory on every exit path, and `CANCEL` cleanup sends `AUDIO_OUT_END` even if no audio was playing.
- **One turn in flight**: a new `AUDIO_END` cancels-and-drains the previous turn task before spawning the next ([`session.py:453`](app/session.py#L453)).

The backend→lamp normal-turn frame order (per [IMPLEMENTATION_WEBSOCKET.md §10.3](IMPLEMENTATION_WEBSOCKET.md), realised across orchestrator + dispatch):

```
STATE(thinking)
[TFT_TEXT caption]              ← instant, kills spinner gap
[TFT_LATEX_LOADING]?            ← only if reply has LaTeX
STATE(speaking)
[AUDIO_OUT* × N]  ‖  [TFT_PART* + TFT_FRAME]   ← interleaved, parallel
AUDIO_OUT_END                  ← early, the moment TTS ends
STATE(idle)                    ← finalize_turn
```

---

## 13. Error handling, timeouts, retries and fallbacks

| Situation | Handling | Location |
|---|---|---|
| Malformed inbound frame (`decode` ValueError) | Log + drop the frame; keep the socket open | [`ws_lamp.py:263`](app/routes/ws_lamp.py#L263) |
| Frame handler raises | Log + keep socket open (defence in depth) | [`ws_lamp.py:272`](app/routes/ws_lamp.py#L272) |
| Idle > 10 min with no traffic and no active turn | Close 1000; lamp reconnects | [`ws_lamp.py:248`](app/routes/ws_lamp.py#L248) |
| Outbound payload > 4 KB | `send_frame` raises `ValueError` (prevents lamp bad_alloc reboot) | [`session.py:562`](app/session.py#L562) |
| `send_bytes` timeout (> 2 s) | Mark closed, close 1011, re-raise | [`session.py:577`](app/session.py#L577) |
| `send_bytes` disconnect mid-write | Mark `_closed`, re-raise; later sends no-op | [`session.py:589`](app/session.py#L589) |
| Utterance < 0.5 s | Drop as false wake, send `STATE(idle)` | [`session.py:423`](app/session.py#L423) |
| Utterance > 30 s | Truncate to 30 s of whole int16 frames | [`session.py:435`](app/session.py#L435) |
| Corrupt/partial JPEG | Drop image (JPEG-magic check), turn continues audio-only | [`session.py:319`](app/session.py#L319) |
| Uplink chunk loss (`AUDIO_RESET`) | Discard streamed audio + decoder state; await full re-send | [`session.py:262`](app/session.py#L262) |
| `audioop` missing on uplink | Discard ADPCM mic audio with one-time error | [`session.py:378`](app/session.py#L378) |
| Opus/ADPCM encoder unavailable | Degrade opus→adpcm→pcm, warn once | [`session.py:673`](app/session.py#L673)–[`session.py:704`](app/session.py#L704) |
| LLM provider error (non-`ok` status) | `STATE(error)` + visual-only `TFT_TEXT`; TTS skipped; `finalize_turn` restores idle | [`orchestrator.py:971`](app/services/orchestrator.py#L971), [`dispatch.py:224`](app/services/dispatch.py#L224) |
| Turn task crash | `_on_turn_done` logs it; `finally` still finalizes | [`session.py:482`](app/session.py#L482) |
| `CANCEL` (0x04) | Cancel turn + image preps, emit cleanup trio | [`session.py:492`](app/session.py#L492) |
| Device revoked mid-session | `STATE(unpaired)` + close 4402 (Redis or 30 s heartbeat) | [`ws_lamp.py:162`](app/routes/ws_lamp.py#L162) |
| Bad/expired/wrong-user JWT | Close 4401 / 4402 before `accept()` | [`ws_lamp.py:84`](app/routes/ws_lamp.py#L84) |
| TTS piece synthesis failure | Skip that piece (non-fatal) | [`dispatch.py:604`](app/services/dispatch.py#L604) |
| Progressive eq2+ with wedged audio leg | 90 s bound, then ship anyway | [`dispatch.py:403`](app/services/dispatch.py#L403) |

LLM-level retries/escalation (echo/focus/solution-bleed/reveal guards and tier escalation) live in `run_turn` and re-call the model rather than touching the wire; they are out of scope for the protocol but affect *what* eventually streams out.

---

## 14. Configuration and environment variables

Defined in [`app/config.py`](app/config.py); the protocol-relevant subset:

| Setting | Default | Effect |
|---|---|---|
| `ENABLE_AUTH` | `False` | `False` = dev bypass (`dev-lamp`); `True` = JWT + DB-row prod auth, pairing routes mounted, heartbeat + revocation watcher spawned. [`config.py:297`](app/config.py#L297) |
| `PAIRING_CODE_TTL_SEC` | `300` | Pairing-code lifetime. [`config.py:332`](app/config.py#L332) |
| `FRONTEND_BASE_URL` | `http://localhost:3000` | Base for the `pairing_url` (`{base}/pair/{code}`). [`config.py:329`](app/config.py#L329) |
| `TTS_PROVIDER` | `cartesia` | LAMP speech engine (gemini \| piper \| cartesia \| kokoro_local). [`config.py:72`](app/config.py#L72) |
| `TTS_WIRE_CODEC` | `opus` | `pcm` (`AUDIO_OUT` 48 KB/s) \| `adpcm` (`AUDIO_OUT_ADPCM` 12 KB/s) \| `opus` (`AUDIO_OUT_OPUS` ~4 KB/s). [`config.py:656`](app/config.py#L656) |
| `TTS_OPUS_BITRATE` | `32000` | Opus target bits/s. [`config.py:658`](app/config.py#L658) |
| `OPUS_LIB_PATH` | `""` | Explicit libopus path for hosts without a system lib. [`config.py:663`](app/config.py#L663) |
| `TTS_CHUNK_MODE` | `balanced` | TTS piece splitting (single \| hybrid \| full \| balanced). [`config.py:158`](app/config.py#L158) |
| `TTS_CHUNK_BYTES` | `4096` | TTS re-slice size (85 ms @ 24 kHz). [`config.py:201`](app/config.py#L201) |
| `TFT_PROGRESSIVE_EQUATIONS` | `True` | Re-ship the cumulative pack after each equation renders. [`config.py:675`](app/config.py#L675) |
| `TFT_APPEND_EQUATIONS` | `True` | Use `TFT_APPEND_BEGIN`/`TFT_APPEND` (0x25/0x26) — flash firmware first. [`config.py:687`](app/config.py#L687) |
| `TFT_SHOW_MODEL_TAG` | `True` | Append a tier/model tag to the TFT card. [`config.py:636`](app/config.py#L636) |
| `EMIT_DEBUG_JSON` | `True` | Send the parsed reply as a `DEBUG_JSON` (0x40) frame. [`config.py:720`](app/config.py#L720) |
| `DEVICE_JWT_SECRET` / `DEVICE_JWT_ISS` | (env) | HS256 signing secret + issuer for `device_jwt`. [`device_jwt.py:33`](app/services/device_jwt.py#L33) |

Endpoint-level constants in [`ws_lamp.py`](app/routes/ws_lamp.py): `WS_CLOSE_BAD_JWT=4401`, `WS_CLOSE_UNLINKED=4402`, `HEARTBEAT_S=30.0`, `WS_IDLE_TIMEOUT_S=600.0`. Protocol constants in [`protocol.py`](app/protocol.py): `WS_HARD_MAX_BYTES=4096`, `WS_MAX_FRAME_BYTES=2048`, `AUDIO_OUT_CHUNK_BYTES=4096`, `AUDIO_OUT_PACE_S=0.085`.

---

## 15. File-by-file / function-by-function breakdown

### 15.1 `app/protocol.py`
- `FrameType` ([:16](app/protocol.py#L16)) — opcode enum (see §4). `StateByte` ([:89](app/protocol.py#L89)) — STATE payload enum.
- Size constants ([:121](app/protocol.py#L121)) — `WS_HARD_MAX_BYTES`, `WS_MAX_FRAME_BYTES`, `AUDIO_OUT_CHUNK_BYTES`, `AUDIO_OUT_PACE_S`; `_MAX_PAYLOAD` ([:127](app/protocol.py#L127)).
- `encode(type_, payload)` ([:130](app/protocol.py#L130)) — pack 4-byte header + payload; ValueError above 24-bit length.
- `decode(buf)` ([:145](app/protocol.py#L145)) — unpack + strict length validation; ValueError on short/mismatched buffer.

### 15.2 `app/routes/ws_lamp.py`
- `_extract_bearer(authz)` ([:69](app/routes/ws_lamp.py#L69)) — parse `Bearer <token>`.
- `_authenticate_dev(_)` ([:78](app/routes/ws_lamp.py#L78)) — return `("dev-lamp", None, None)`.
- `_authenticate_prod(jwt)` ([:84](app/routes/ws_lamp.py#L84)) — verify JWT + 4-condition DB row check; bump `last_seen_at`; return `(device_id, uid, None)` or `(None, None, close_code)`.
- `_heartbeat(device_id, ws, stop)` ([:135](app/routes/ws_lamp.py#L135)) — 30 s `last_seen_at` bump + revoke re-check.
- `_close_unlinked(ws)` ([:162](app/routes/ws_lamp.py#L162)) — STATE(unpaired) + close 4402.
- `lamp_ws(ws)` ([:175](app/routes/ws_lamp.py#L175)) — `@router.websocket("/lamp/ws")`: auth → accept → open session/DB row/event → spawn side-tasks → receive loop → teardown.

### 15.3 `app/session.py`
- `_steer_opus_lib()` ([:57](app/session.py#L57)) — point ctypes at `OPUS_LIB_PATH`.
- `_OpusWire` ([:89](app/session.py#L89)) — per-stream Opus encoder (`encode`/`flush`).
- `Turn` dataclass ([:159](app/session.py#L159)) — per-utterance input buffer (§2.2).
- `Session.__init__` ([:198](app/session.py#L198)); `seconds_idle` ([:235](app/session.py#L235)); `has_active_turn` ([:239](app/session.py#L239)).
- Inbound: `on_frame` ([:245](app/session.py#L245)), `_on_image_part` ([:280](app/session.py#L280)), `_on_image_terminator` ([:295](app/session.py#L295)), `_on_audio_chunk_adpcm` ([:368](app/session.py#L368)), `_on_audio_chunk` ([:388](app/session.py#L388)), `_on_audio_end` ([:405](app/session.py#L405)), `_on_turn_done` ([:482](app/session.py#L482)), `_on_cancel` ([:492](app/session.py#L492)), `close` ([:519](app/session.py#L519)).
- Outbound: `send_frame` ([:541](app/session.py#L541)), `send_state` ([:606](app/session.py#L606)), `send_tft_text` ([:615](app/session.py#L615)), `send_tft_clear` ([:635](app/session.py#L635)), `send_tft_latex_loading` ([:638](app/session.py#L638)), `send_audio_out_chunk` ([:648](app/session.py#L648)), `stream_audio_out` ([:713](app/session.py#L713)), `stream_audio_out_iter` ([:774](app/session.py#L774)), `send_audio_out_end` ([:852](app/session.py#L852)), `send_tft_frame_chunked` ([:874](app/session.py#L874)), `send_tft_frame_append` ([:920](app/session.py#L920)), `finalize_turn` ([:963](app/session.py#L963)). Back-compat aliases ([:974](app/session.py#L974)).

### 15.4 `app/routes/device_lamp.py`
- `register` ([:48](app/routes/device_lamp.py#L48)) — `POST /api/device/register`.
- `poll_pairing` ([:160](app/routes/device_lamp.py#L160)) — `POST /api/device/poll-pairing`.

### 15.5 `app/services/dispatch.py`
- `dispatch_reply` ([:52](app/services/dispatch.py#L52)) — entrypoint: TFT_TEXT → skeleton → gather(audio, tft).
- `_dispatch_audio_leg` ([:149](app/services/dispatch.py#L149)) — signals `done_evt`, early AUDIO_OUT_END.
- `_audio_leg_impl` ([:188](app/services/dispatch.py#L188)) — three skip guards + provider stream.
- `_dispatch_tft_leg` ([:268](app/services/dispatch.py#L268)) / `_dispatch_equations` ([:299](app/services/dispatch.py#L299)) — render + chunked/append ship, progressive gate.
- `_scrub_math_markup` ([:462](app/services/dispatch.py#L462)); `_text_card_payload` ([:487](app/services/dispatch.py#L487)); `_tts_chunks` ([:537](app/services/dispatch.py#L537)); `_sentence_streamed` ([:572](app/services/dispatch.py#L572)).

---

## 16. Integration points

**What calls this:**
- **Firmware** (`net_ws.cpp`, per [IMPLEMENTATION_WEBSOCKET.md](IMPLEMENTATION_WEBSOCKET.md)) opens `wss://<host>/lamp/ws` with `Authorization: Bearer <device_jwt>`, sends `IMAGE_JPEG`/`IMAGE_PART`/`AUDIO_CHUNK`(`_ADPCM`)/`AUDIO_END`/`CANCEL`/`AUDIO_RESET`, and consumes `STATE`/`AUDIO_OUT*`/`TFT_*` on a single `on_frame` callback.
- **The web simulator / brain-bench** reuses the same framing on `/api/frontend/ws` with the `0x50..0x52` superset opcodes ([`protocol.py:79`](app/protocol.py#L79)).
- **FastAPI** mounts the WS router unconditionally and the pairing routes only in prod ([`main.py:234`](app/main.py#L234), [`main.py:266`](app/main.py#L266)).

**What this calls:**
- `Session._on_audio_end` → `orchestrator.get_orchestrator().run_turn(...)` ([`session.py:464`](app/session.py#L464)).
- `run_turn` → `dispatch.dispatch_reply(...)` ([`orchestrator.py:986`](app/services/orchestrator.py#L986)).
- Dispatch → `app/providers/tts_base.get_tts_provider()` and `Session.stream_audio_out_iter`; LaTeX → `app/providers/latex_renderer.*`.
- Image prep → `app/services/image_prep.py`; enhancement → `app/providers/image_preprocessor.enhance_for_llm`.
- Auth → `app/services/device_jwt.verify_device_jwt`, `app/db.models.Device`, `app/db.session.get_session_factory`, `app/services/revocation.watch_revocation`.
- Persistence → `app/storage/turns.open_session`, `app/storage/events.log_event`, `app/services/session_memory.finalize_session` ([`ws_lamp.py:199`](app/routes/ws_lamp.py#L199)–[`ws_lamp.py:293`](app/routes/ws_lamp.py#L293)).

**Database (Supabase/Postgres):** `Device` (pairing + `revoked_at` + `last_seen_at`), `PairingCode` (TTL-bounded), `sessions` (one row per WS connection), and turn/trace/event tables referenced via the storage layer.

---

## 17. Sequence diagram

```mermaid
sequenceDiagram
    autonumber
    participant L as Lamp (ESP32-S3)
    participant WS as ws_lamp.py (/lamp/ws)
    participant S as Session
    participant O as TurnOrchestrator
    participant D as dispatch_reply
    participant T as TTS / LaTeX

    Note over L,WS: Boot — pairing already done, lamp holds device_jwt
    L->>WS: WSS upgrade + Authorization: Bearer <device_jwt>
    alt ENABLE_AUTH=True
        WS->>WS: verify_device_jwt + DB row check (paired, !revoked, same uid)
        WS-->>L: close 4401/4402 on failure
    else dev
        WS->>WS: _authenticate_dev → "dev-lamp"
    end
    WS->>WS: ws.accept(); spawn heartbeat + revocation watcher (prod)
    Note over WS: uvicorn ping/pong keeps TCP alive; 10-min idle backstop

    Note over L: wake word fires locally
    L->>S: IMAGE_PART × N → IMAGE_JPEG (per image, validate JPEG magic)
    S->>S: assemble Turn.images[]; start early image prep
    L->>S: AUDIO_CHUNK / AUDIO_CHUNK_ADPCM × M (20 ms each)
    S->>S: append decoded PCM → Turn.audio_pcm
    L->>S: AUDIO_END (empty)
    S->>S: gate 0.5s..30s; snapshot; reset current_turn
    S->>O: run_turn(images, audio_bytes, image_preps)

    O-->>L: STATE(thinking)
    O->>O: load history, enhance images, pre-route, tiered LLM call (8 s TTFT)
    alt status == ok
        O-->>L: STATE(speaking)
    else provider error
        O-->>L: STATE(error)
    end
    opt EMIT_DEBUG_JSON
        O-->>L: DEBUG_JSON (parsed reply; real lamp drops it)
    end

    O->>D: dispatch_reply(reply, status)
    D-->>L: TFT_TEXT (caption, instant)
    opt reply has LaTeX (status ok)
        D-->>L: TFT_LATEX_LOADING (skeleton)
    end
    par audio leg
        D->>T: synthesize(speech)  (gemini/piper)
        T-->>D: 24 kHz PCM chunks (streamed)
        D-->>L: AUDIO_OUT* (4 KB / 85 ms paced; prime-burst first 48 KB)
        D-->>L: AUDIO_OUT_END (early, the moment TTS ends)
    and tft leg
        D->>T: render equations (worker thread / Redis cache)
        D-->>L: TFT_PART* + TFT_FRAME  (gated behind audio_done for eq2+)
    end

    O-->>L: STATE(idle)  (finalize_turn — releases I2S to mic)
    O->>O: gc.collect(); fire-and-forget persist

    opt user presses Select
        L->>S: CANCEL
        S->>O: cancel turn task + image preps
        S-->>L: TFT_CLEAR, AUDIO_OUT_END, STATE(idle)
    end
```

```mermaid
flowchart TD
    A["receive_bytes (wait_for WS_IDLE_TIMEOUT_S)"] -->|TimeoutError| B{active turn or<br/>recent traffic?}
    B -->|yes| A
    B -->|no| C["close 1000 → lamp reconnects"]
    A -->|WebSocketDisconnect| Z["break → teardown"]
    A -->|bytes| D["decode(msg)"]
    D -->|ValueError| E["log + drop frame (keep socket)"]
    E --> A
    D -->|ok| F["session.on_frame(type, payload)"]
    F -->|raises| G["log + keep socket open"]
    G --> A
    F --> H{opcode}
    H -->|IMAGE_PART/JPEG| I["assemble Turn.images"]
    H -->|AUDIO_CHUNK*| J["append Turn.audio_pcm"]
    H -->|AUDIO_RESET| K["clear streamed audio + decoder"]
    H -->|AUDIO_END| L["gate dur → run_turn"]
    H -->|CANCEL| M["cancel + cleanup trio"]
    H -->|unknown| N["log WARNING, drop"]
    I --> A
    J --> A
    K --> A
    L --> A
    M --> A
    N --> A
```
