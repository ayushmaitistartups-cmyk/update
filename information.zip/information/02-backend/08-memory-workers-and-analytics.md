# Backend — Memory, Vector Embeddings, Background Workers & Analytics

This document is the definitive reference for the Smart Tutor Lamp backend's **memory subsystem** (short-term Redis hot cache, long-term Supabase/Postgres learner profile, on-demand LLM session compaction), the **vector-embeddings / ANN retrieval seam** (planned but unimplemented), the **background workers** (transcription, embedding, daily rollup — all stubs today), the **cache seam**, and the **per-user analytics aggregation** that powers the web dashboard. Everything below is grounded in the actual code in `Smart-Tutor-Lamp-backend/`; where a file is a deliberate stub (raises `NotImplementedError`) this is stated explicitly and the intended design is reproduced from the file's own docstring rather than invented.

---

## Table of Contents

1. [Purpose & Responsibility](#1-purpose--responsibility)
2. [High-Level Architecture](#2-high-level-architecture)
3. [The Three-Layer Memory Model](#3-the-three-layer-memory-model)
4. [Layer 1 — Short-Term Verbatim Memory (`services/memory.py`)](#4-layer-1--short-term-verbatim-memory-servicesmemorypy)
5. [Layer 1 Durable Fallback (`storage/turns.py`)](#5-layer-1-durable-fallback-storageturnspy)
6. [The Memory Orchestrator (`services/session_memory.py`)](#6-the-memory-orchestrator-servicessession_memorypy)
7. [The Smart-Compaction Algorithm (L2)](#7-the-smart-compaction-algorithm-l2)
8. [Layer 3 — Cross-Session Learner Profile](#8-layer-3--cross-session-learner-profile)
9. [Storage CRUD (`user_memory.py`, `user_profiles.py`)](#9-storage-crud-user_memorypy-user_profilespy)
10. [Vector Embeddings & ANN Retrieval (`storage/memory_vec.py`)](#10-vector-embeddings--ann-retrieval-storagememory_vecpy)
11. [Background Workers (`workers/`)](#11-background-workers-workers)
12. [The Cache Seam (`services/cache.py`) & the Shared Redis Client](#12-the-cache-seam-servicescachepy--the-shared-redis-client)
13. [Analytics Aggregation (`services/analytics.py`)](#13-analytics-aggregation-servicesanalyticspy)
14. [Configuration, Environment Variables & Constants](#14-configuration-environment-variables--constants)
15. [Edge Cases, Error Handling, Timeouts, Fallbacks](#15-edge-cases-error-handling-timeouts-fallbacks)
16. [Integration Points / Cross-References](#16-integration-points--cross-references)
17. [Mermaid Diagrams](#17-mermaid-diagrams)

---

## 1. Purpose & Responsibility

This part of the backend answers one question on every turn: **"What does the tutor already know about this learner and this conversation, and how do we keep that context bounded?"** It also answers a second, offline question: **"What can we tell the learner about their own usage?"** (analytics).

Concretely the subsystem is responsible for:

- **Making each LLM call stateful** by injecting a compact `history_text` block (≈380 tokens) assembled from three layers of memory, fetched in parallel and character-capped so the prompt never grows unbounded as a session gets longer.
- **Persisting every successful turn** durably to Postgres (`turns`) and to a Redis hot cache (L1), so that the conversation survives reconnects and process restarts.
- **Compacting** older turns of a long session into a 2–3 sentence LLM-generated summary plus verbatim "keeper" facts (L2), so token budget stays fixed regardless of session length.
- **Distilling a cross-session learner profile** (subjects studied, difficulty, an LLM 1–2 sentence summary) at session end (L3).
- Providing the **same memory assembly to both input surfaces** — the physical lamp (over WebSocket) and the web `/simulate` bench — so behaviour is identical regardless of input source.
- Providing **per-user analytics rollups** for the web dashboard, tolerant of an un-migrated database.
- Holding the **seams** for two future features that are intentionally deferred: long-term **pgvector** semantic memory (Layer 3.3) and **background workers** for transcription / embedding / daily metric rollup (Layer 9.3/9.4).

A foundational design principle runs through the whole subsystem: **persistence and compaction must NEVER break a live turn.** Every DB/Redis/LLM call here is availability-gated and swallows its own exceptions; the worst case degrades to "memoryless / stateless" rather than crashing the response path.

---

## 2. High-Level Architecture

```
                 ┌─────────────────────── ENTRY POINTS ───────────────────────┐
   Physical lamp │  orchestrator._load_history / _persist_turn (WebSocket)     │
   Web bench     │  frontend_manager.simulate (HTTP /api/frontend/simulate)    │
   Session end   │  ws_lamp finally → finalize_session                          │
   Dashboard     │  frontend_manager /analytics + /analytics/detail (HTTP GET) │
                 └────────────────────────────┬───────────────────────────────┘
                                              │
                       ┌──────────────────────┴───────────────────────┐
                       ▼                                               ▼
        app/services/session_memory.py                    app/services/analytics.py
        (the memory ORCHESTRATOR)                          (read-only rollups)
        ┌──────────────────────────────┐                  ┌──────────────────────┐
        │ load_context  (read L3+L2+L1) │                  │ user_analytics       │
        │ record_turn   (write durable+ │                  │ user_analytics_detail│
        │               L1 + compaction)│                  └──────────┬───────────┘
        │ finalize_session (close+L3)   │                             │
        │ update_user_memory (L3 only)  │                             │ raw SQL on
        │ _maybe_compact / _compact_…   │                             │ turns/sessions
        └──────┬──────────┬────────┬────┘                             ▼
               │          │        │                              Postgres
   L1 hot ─────┘          │        └──── L2/L3 reads/writes ──►   (sessions,
   app/services/memory.py │                                        turns,
   (Redis lists)          │ L1 durable fallback                    user_memory,
        │                 ▼                                         user_profiles,
        │      app/storage/turns.py                                 devices)
        │      (write_turn / load_recent_turns / open_session)
        ▼
   app/services/revocation.get_client()  ←── shared Redis client (decode_responses=True)
        ▲                                       used by: memory.py, cache.py, session resume cache
        └── app/services/cache.py  (cget/cset/cdel — generic NO-OP-when-off seam)

   DEFERRED (stubs, raise NotImplementedError):
     app/storage/memory_vec.py   (pgvector ANN — Layer 3.3)
     app/workers/transcribe.py   (Groq Whisper — Layer 9.3)
     app/workers/embed.py        (embeddings → pgvector — Layer 3.3/9.3)
     app/workers/rollup.py       (daily materialised view — Layer 9.4)
```

**Module inventory of the assigned files:**

| File | Status | Responsibility |
|---|---|---|
| [memory.py](Smart-Tutor-Lamp-backend/app/services/memory.py) | **Live** | L1 Redis short-term verbatim history (last 3 turns/device) |
| [session_memory.py](Smart-Tutor-Lamp-backend/app/services/session_memory.py) | **Live** | The 3-layer memory orchestrator: assembly, persistence, compaction, L3 |
| [analytics.py](Smart-Tutor-Lamp-backend/app/services/analytics.py) | **Live** | Per-user dashboard rollups (read-only) |
| [cache.py](Smart-Tutor-Lamp-backend/app/services/cache.py) | **Live (no-op)** | Generic cache seam (NO-OP until `REDIS_URL` set) |
| [workers/embed.py](Smart-Tutor-Lamp-backend/app/workers/embed.py) | **Stub** | Embedding worker (`NotImplementedError`) |
| [workers/rollup.py](Smart-Tutor-Lamp-backend/app/workers/rollup.py) | **Stub** | Daily metrics rollup (`NotImplementedError`) |
| [workers/transcribe.py](Smart-Tutor-Lamp-backend/app/workers/transcribe.py) | **Stub** | Offline Whisper transcription (`NotImplementedError`) |
| [storage/memory_vec.py](Smart-Tutor-Lamp-backend/app/storage/memory_vec.py) | **Stub** | pgvector long-term ANN store (`NotImplementedError`) |
| [storage/user_memory.py](Smart-Tutor-Lamp-backend/app/storage/user_memory.py) | **Live** | CRUD for `user_memory` (L3 row) |
| [storage/user_profiles.py](Smart-Tutor-Lamp-backend/app/storage/user_profiles.py) | **Live** | CRUD for `user_profiles` (web onboarding profile) |

---

## 3. The Three-Layer Memory Model

The design (documented in [SESSION_MEMORY_GUIDE.md §0](Smart-Tutor-Lamp-backend/SESSION_MEMORY_GUIDE.md)) splits memory into three layers, each with a different storage tier, latency, and decay rate. The injected `history_text` is assembled bottom-up as **L3 + L2 + L1**:

| Layer | Name | Storage | Latency | Token budget | Char cap | Scope |
|---|---|---|---|---|---|---|
| **L3** | User profile | Supabase `user_memory` + `user_profiles` | ~5 ms | ~60 tok | `_L3_CAP = 360` | Entire learner lifetime (`userScoped`) |
| **L2** | Session summary | Supabase `sessions.summary` | ~5 ms | ~120 tok | `_L2_CAP = 480` | One session arc (`storyScoped`) |
| **L1** | Recent verbatim | Redis hot → Supabase fallback | < 1 ms | ~200 tok | own caps | Last N verbatim turns (`characterScoped`) |

The total budget is **fixed at ≈380 tokens** regardless of how long the session runs — compaction (§7) keeps it bounded. The character caps are defined at [session_memory.py:40-41](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L40):

```python
_L3_CAP = 360
_L2_CAP = 480
```

Note: these live-code caps are slightly different from the guide's original `240`/`480` — the L3 cap was widened in code to fit the declarative onboarding profile plus the behavioural summary, per the comment at [session_memory.py:38-41](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L38).

Each layer's content is wrapped in **XML-style tags** (`<learner_profile>`, `<session_summary>`, `<recent_turns>`) so the LLM cleanly separates injected DATA from system-prompt INSTRUCTIONS — the prompt references these exact tag names. See [session_memory.py:96-103](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L96).

---

## 4. Layer 1 — Short-Term Verbatim Memory (`services/memory.py`)

[memory.py](Smart-Tutor-Lamp-backend/app/services/memory.py) is the Redis-backed hot path for the **last 3 turns** of a device's current conversation. It is a thin wrapper over a Redis list keyed per device.

### 4.1 Constants & key shape

[memory.py:32-38](Smart-Tutor-Lamp-backend/app/services/memory.py#L32):

```python
HISTORY_KEY_PREFIX = "lamp:hist:"
HISTORY_DEPTH       = 3        # last N turns kept
HISTORY_TTL_S       = 24 * 60 * 60   # 86 400 s = 24 h
EMPTY_HISTORY_TEXT = "[Session start — no prior turns]"
```

`_key(device_id)` produces `lamp:hist:<device_id>` ([memory.py:41-42](Smart-Tutor-Lamp-backend/app/services/memory.py#L41)). The namespaced prefix lets revocation pub/sub, the session cache, and history share one Redis instance without colliding.

### 4.2 `load_history(device_id) -> str` ([memory.py:45-64](Smart-Tutor-Lamp-backend/app/services/memory.py#L45))

- Gets the shared client via `revocation.get_client()`. If `None` (Redis unconfigured) returns `EMPTY_HISTORY_TEXT` immediately — the system degrades to memoryless mode rather than crashing.
- Reads `LRANGE key 0 HISTORY_DEPTH-1` → the 3 most recent JSON records (newest-first because writes use `LPUSH`).
- Any exception during `lrange` is logged and falls back to `EMPTY_HISTORY_TEXT`.
- Empty list → `EMPTY_HISTORY_TEXT`. Otherwise renders via `_format`.

### 4.3 `push_turn(...)` ([memory.py:67-115](Smart-Tutor-Lamp-backend/app/services/memory.py#L67))

Fire-and-forget write at the **head** of the device list. Signature carries the rich per-turn data:

```python
async def push_turn(device_id, *, speech, display_kind, display_content="",
                    user_input="", same_problem=True, problem_tag="",
                    asked_at=None) -> None
```

The stored record (a JSON dict) with its **field-by-field truncation caps** ([memory.py:96-104](Smart-Tutor-Lamp-backend/app/services/memory.py#L96)):

| Field | Source | Cap | Notes |
|---|---|---|---|
| `asked_at` | `asked_at` or `now(utc)` | — | ISO-8601 |
| `asked` | `user_input` | **200 chars** | the learner's question (model restatement) |
| `speech` | `speech` | **500 chars** | TTS spoken text |
| `display` | `display_kind` | — | `"text"` / `"none"` |
| `content` | `display_content` | **300 chars** | the dense TFT text card prose |
| `same_problem` | `same_problem` | — | bool — drives NEW-PROBLEM demarcation |
| `ptag` | `problem_tag` | **160 chars** | the model's per-turn problem identity |

The three Redis commands run as an **atomic, non-transactional pipeline** (one RTT) at [memory.py:109-113](Smart-Tutor-Lamp-backend/app/services/memory.py#L109):

```python
async with client.pipeline(transaction=False) as pipe:
    pipe.lpush(key, payload)
    pipe.ltrim(key, 0, HISTORY_DEPTH - 1)   # keep only newest 3
    pipe.expire(key, HISTORY_TTL_S)          # 24 h TTL
    await pipe.execute()
```

All errors are caught and logged; persistence never blocks the response path.

### 4.4 `clear_history(device_id)` ([memory.py:118-133](Smart-Tutor-Lamp-backend/app/services/memory.py#L118))

`DEL lamp:hist:<device_id>`. **Privacy-critical**: it MUST be called when a device is unlinked or its user deleted, because the history key is device-scoped — without it, the next user to pair the same physical lamp would have the previous user's turns fed into their LLM context (a cross-user leak). Callers:
- [device_user.py:197-199](Smart-Tutor-Lamp-backend/app/routes/device_user.py#L197) — on device unlink.
- [clerk_webhook.py:99-104](Smart-Tutor-Lamp-backend/app/routes/clerk_webhook.py#L99) — on Clerk account deletion.

### 4.5 `_format(raw)` — rendering + NEW-PROBLEM trimming ([memory.py:152-197](Smart-Tutor-Lamp-backend/app/services/memory.py#L152))

This is the most subtle piece of L1. The raw list is newest-first (LPUSH); the renderer prints **oldest-first** so the LLM reads in natural order. Mechanically:

1. Parse each JSON entry; **skip corrupted entries** silently (better than blowing up the turn). Empty → `EMPTY_HISTORY_TEXT`.
2. `items.reverse()` → oldest-first.
3. **Find the most-recent problem switch.** Iterate; `cut` is set to the index of the most recent turn (excluding index 0, which has no in-window predecessor) where `same_problem is False`:
   ```python
   cut = 0
   for idx, t in enumerate(items):
       if idx > 0 and t.get("same_problem", True) is False:
           cut = idx
   kept = items[cut:]
   ```
4. If `cut > 0`, the pre-switch turns are **physically removed** and replaced with a single content-free `_BREADCRUMB` string ([memory.py:144-150](Smart-Tutor-Lamp-backend/app/services/memory.py#L144)). The breadcrumb tells the model an earlier, **different** problem is "finished and set aside" and that it **MUST NOT reference any variable, diagram, figure, value, or constraint** from it. This stops stale-attention bleed between problems while keeping recoverability and a strict negative constraint.
5. Each kept turn renders as one line. When the turn has both a `content` card and `display == "text"`, the body becomes `speech | display: content`. If the learner question (`asked`) is present, the line is `"i. Student asked: X — You answered: Y"`; otherwise `"i. (timestamp, display=…) body"`.

Design notes baked into the comments: trimming is driven **only by the deliberate model signal** `same_problem=False` (no fuzzy text matching), so a genuine same-problem continuation is **never** trimmed (`cut` stays 0 → full history). Crucially, **only the LLM-context rendering trims** — the durable `turns` rows in Supabase are untouched, so a UI history tab reads the full conversation.

---

## 5. Layer 1 Durable Fallback (`storage/turns.py`)

When Redis is unavailable, L1 falls back to Postgres via [turns.py](Smart-Tutor-Lamp-backend/app/storage/turns.py). This file is the **minimal durable writer** for sessions and turns; the richer compaction layer sits on top of the same tables.

### 5.1 `open_session(device_id, user_id) -> str | None` ([turns.py:53-136](Smart-Tutor-Lamp-backend/app/storage/turns.py#L53))

Resume-or-open logic for a session row:
- **Fast path:** read the cached active session id from Redis (`lamp:sid:<device_id>` via `cache.cget`). If the cached row exists, belongs to the **same user** (`row.user_id == user_id` or both `None`), and is **fresh** (`now - last_activity_at < _SESSION_IDLE_MIN*60` i.e. < 30 min), it's reactivated (`ended_at=None`, `last_activity_at=now`) and returned — avoiding the resume query.
- **Source of truth (Postgres):** a single SQL `SELECT … WHERE device_id=:d AND user_id IS NOT DISTINCT FROM :u AND last_activity_at > now() - make_interval(mins => :m) ORDER BY last_activity_at DESC LIMIT 1`. `IS NOT DISTINCT FROM` makes a `NULL` user_id (dev mode) match `NULL`. A re-paired DIFFERENT user won't resume → a fresh session, so history never bleeds across users.
- On no match, inserts a new `SessionRecord`. The chosen sid is written back to the cache with TTL `_SID_CACHE_TTL_S = (30 + 5) * 60 = 2100 s`.
- Returns `None` when the DB is unavailable or on error (e.g. `last_activity_at` column missing on an un-migrated DB). Turns then persist with `session_id=NULL` but still carry `user_id`.

### 5.2 `_decay_resistance(query_type, difficulty)` ([turns.py:157-163](Smart-Tutor-Lamp-backend/app/storage/turns.py#L157))

Computed at **write time** and stored on the row; consumed at compaction time by the importance score (§7). Identical to the helper in `session_memory.py` and the guide. The base table by `query_type`:

| query_type | base | | query_type | base |
|---|---|---|---|---|
| `derivation` | **0.90** | | `concept` | 0.65 |
| `formula` | 0.85 | | `mistake_id` | 0.60 |
| `calc` | 0.75 | | `check` | 0.20 |
| `definition` | 0.70 | | `other` | 0.20 |
| (unknown) | **0.40** | | | |

Difficulty modifier added to base: `hard: +0.10`, `medium: 0.0`, `easy: -0.15`, then clamped to `[0.0, 1.0]`:
```python
return max(0.0, min(1.0, base + mod))
```
So a `formula/hard` turn = `0.85 + 0.10 = 0.95` (slow decay, kept verbatim); a `check/easy` turn = `0.20 - 0.15 = 0.05` (fast decay, summarised away first).

### 5.3 `write_turn(...)` ([turns.py:166-276](Smart-Tutor-Lamp-backend/app/storage/turns.py#L166))

Inserts one `turns` row and atomically bumps the session count. Key mechanics:
- **Guard:** skips entirely when `telemetry["status"]` is not in `(None, "ok")` ([turns.py:188-189](Smart-Tutor-Lamp-backend/app/storage/turns.py#L188)) — error fallbacks never become history. No-ops when the DB is unavailable.
- **Atomic turn_index:** the session count bump is a single `UPDATE sessions SET turn_count = turn_count + 1, last_activity_at = now(), primary_subject = COALESCE(:subj, …), avg_difficulty = COALESCE(:diff, …) WHERE id = :sid RETURNING turn_count`. Doing it as one row-locking statement prevents the read-then-write race that fire-and-forget concurrent writers (rapid web `/simulate`) could otherwise hit, which would duplicate `turn_index` / lose updates ([turns.py:203-229](Smart-Tutor-Lamp-backend/app/storage/turns.py#L203)).
- If the session row vanished (count returns `None`), the turn is still written **detached** (`session_id=NULL`) rather than lost.
- The row records the full telemetry surface: `transcript` (= `reply.user_input`), `speech`, `display_kind/content`, `latex_equations`, `confidence`, `query_type`, `subject`, `difficulty`, `decay_resistance`, provider/model/token/latency/cost telemetry, `status`, `escalated`, `final_tier`, `escalation_path`, and the JSONB `extra`.
- Caller-supplied `turn_id` is honoured (admin trace row pre-links to it); else a fresh UUID.
- All errors logged + swallowed.

### 5.4 `load_recent_turns(...)` ([turns.py:279-327](Smart-Tutor-Lamp-backend/app/storage/turns.py#L279))

The Redis-free L1 source. Selects up to `limit` (default 3) **status='ok'** turns:
- scoped to `session_id` when present, else to this `device_id` **filtered by user_id** (so a re-paired lamp never sees a prior user's turns — cross-user safety holds without any Redis clear);
- ordered `asked_at DESC LIMIT limit`, then `reversed()` to oldest-first;
- rendered into the same `[Recent turns — oldest first]` block format as `_format`, using `transcript` for the "Student asked:" line.
- Returns `EMPTY_HISTORY_TEXT` on DB-off/empty/error; never raises.

### 5.5 `close_session(session_id)` ([turns.py:139-152](Smart-Tutor-Lamp-backend/app/storage/turns.py#L139))

Sets `sessions.ended_at = now()`. No-op when DB off / id missing.

---

## 6. The Memory Orchestrator (`services/session_memory.py`)

[session_memory.py](Smart-Tutor-Lamp-backend/app/services/session_memory.py) is the single public API both the lamp orchestrator and the web bench call. Its public functions (per the module docstring at [session_memory.py:12-21](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L12)):

- `load_context(device_id, user_id, session_id)` → the ≤~380-token history block.
- `record_turn(...)` → persist + trigger background L2 compaction.
- `finalize_session(device_id, user_id, session_id)` → close session + refresh L3.
- `update_user_memory(device_id, user_id, run_llm)` → refresh L3 only.

### 6.1 Module helpers & tunables

[session_memory.py:43-71](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L43):

```python
_PROXIMITY_WINDOW = 5     # turns within this index-distance group together
_MIN_GROUP_SIZE = 3       # only extract a verbatim keeper from groups this big
_compact_locks: dict[str, asyncio.Lock] = {}   # one lock per session_id
```

- `_factory()` — lazily imports and returns the async DB session factory, or `None` if unavailable (never raises).
- `_ok(result)` — turns an `asyncio.gather` result into `""` if it's an `Exception`, else `result or ""`.
- `_cap_at_word(text, cap)` — truncates to `≤ cap` chars **at a word boundary** (`rsplit(None, 1)[0]`), because a mid-word cut in injected context reads as noise to the model. Falls back to a hard cut when the head has no whitespace.

### 6.2 `load_context` — the assembly (control flow) ([session_memory.py:77-124](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L77))

This is the per-turn hot path (read **before** the LLM call). **As of 2026-07-04 ("added memory leak protection and cpu crash"), L1 + L2 + L3 all run in ONE `asyncio.gather`** — previously L1 (recent verbatim) ran serially AFTER an `asyncio.gather` of L3 (profile) + L2 (summary), costing an extra ~200 ms round-trip on every turn (the code comment cites the cross-region Mumbai↔Ohio latency). L1's own logic moved into a new private helper, `_load_recent(device_id, user_id, session_id)` ([session_memory.py:127-146](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L127)) — Redis hot path → Supabase fallback, swallows its own errors — so it can sit alongside `_load_user_profile`/`_load_session_summary` as just another gather leg. The output format/tag structure is **unchanged** — this is a pure performance refactor, not a behaviour change. Step by step:

1. Resolve `_factory()`. **L2/L3 only run** when `factory is not None AND settings.ENABLE_MEMORY` (`mem_on`).
2. Build `legs = [_load_recent(device_id, user_id, session_id)]` (`[0]`, L1 — ALWAYS present); if `mem_on`, append `_load_user_profile(device_id, user_id)` (`[1]`, L3) and, if `session_id` is set, `_load_session_summary(session_id)` (`[2]`, L2). The legs are ordered deterministically so results can be indexed.
3. `results = await asyncio.gather(*legs, return_exceptions=True)` — **L1 + L2 + L3 reads now all run in parallel**, so there are no sequential Supabase/Redis round-trips before the LLM call. `return_exceptions=True` means one failing read can't sink the others; `results[0]` (L1) is guaranteed a plain string since `_load_recent` swallows its own exceptions.
4. The profile (`results[1]` when `mem_on`), if non-empty, is word-capped to `_L3_CAP` and wrapped: `<learner_profile>…</learner_profile>`.
5. The summary (`results[2]` when present), if non-empty, is word-capped to `_L2_CAP` and wrapped: `<session_summary>…</session_summary>`.
6. **L1** (`results[0]`, via `_load_recent`):
   - If `cache.enabled()` (Redis live), try `memory.load_history(device_id)`; use it only if it's non-empty and not the Redis EMPTY placeholder.
   - If that produced nothing, fall back to `turns.load_recent_turns(device_id, user_id, session_id, limit=settings.MEMORY_TAIL_SIZE)`.
   - On any failure, `recent = EMPTY_HISTORY_TEXT`.
7. Real recent turns get wrapped in `<recent_turns>…</recent_turns>`; the `"[Session start …]"` placeholder is appended **bare** (it's a signal, not data).
8. Return `"\n\n".join(...)` of all non-empty parts.

So even when memory is disabled or the DB is down, the caller always gets *something* (the bare L1 block or its placeholder).

### 6.3 `_load_user_profile` (L3 read) ([session_memory.py:133-178](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L133))

Builds the L3 string by combining **two** sources inside one DB session:

**(a) Declarative onboarding profile** (`user_profiles`, keyed by Clerk `user_id`), via `get_profile`. Builds a human-readable clause list:
- `preparing for {target_exam}`
- `{prep_duration.lower()}`
- from `extra` JSONB: `learns best via {learning_style}`, `likes {explain_depth} explanations`, `focusing on {focus_subject}` (skipped when focus is `"Still deciding"`).
- Joined as `"{full_name or 'The learner'}: clause; clause; … ."`

**(b) Behavioural profile** (`user_memory`, keyed by `device_id`), via `get_user_memory`:
- `row.long_term_summary` appended verbatim if present.
- `row.subject_profile` rendered as `"Recent subjects: math(hard), physics(medium)."`

The combined string is word-capped to `_L3_CAP` (360). Any exception → `""`.

### 6.4 `_load_session_summary` (L2 read) ([session_memory.py:181-195](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L181))

Loads `SessionRecord` by UUID; if it has a non-empty `summary`, returns `"[Turns 1–{summary_as_of} compacted]\n{summary}"`. Empty when the session is fresh / not found / on error.

### 6.5 `record_turn` — persistence entry point ([session_memory.py:201-258](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L201))

The single 3-layer write path used by **both** the lamp orchestrator ([orchestrator.py:1380-1386](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1380)) and the web bench ([frontend_manager.py:854-878](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L854)). Inputs → transforms → outputs:

1. **Guard:** if `telemetry.get("status")` not in `(None, "ok")`, **return immediately** ([session_memory.py:222-223](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L222)) — failed turns never become memory or count toward compaction.
2. **Durable write:** call `turns.write_turn(...)` (self-gates on DB availability, bumps `turn_count`). Passes the persisted media URLs (`image_url`/`audio_url`) and an optional pre-generated `turn_id` (so an admin `turn_traces` row can link to the same id). Errors logged + continue.
3. **Redis L1 write-through:** call `memory.push_turn(...)`, forwarding `speech`, `display.kind`, `display.content`, `user_input`, and the problem-identity signals `same_problem` + `problem_tag` (= `reply.problem_statement`) — both default safely. No-op without Redis.
4. **L2 compaction trigger:** if `session_id AND settings.ENABLE_MEMORY AND settings.ENABLE_MEMORY_COMPACTION`, schedule `asyncio.create_task(_maybe_compact(session_id))` — background, never blocks the turn.

### 6.6 `_maybe_compact` — the cheap gate ([session_memory.py:261-280](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L261))

A fast bail-out path that does **one** `sessions` read and short-circuits the common case:
- `None` session or `turn_count < MEMORY_COMPACT_THRESHOLD` (8) → return.
- `turn_count - MEMORY_TAIL_SIZE <= (summary_as_of or 0)` → already compacted up to date → return.
- If the per-session lock is already locked → return (another compaction is running).
- Otherwise call `_compact_session`.

---

## 7. The Smart-Compaction Algorithm (L2)

`_compact_session(session_id)` ([session_memory.py:283-370](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L283)) is the heart of L2. It runs under the per-session `asyncio.Lock` (so two turns can't kick off concurrent compactions). It implements **decay-resistance-scored, proximity-grouped, keeper-extracting** compaction. The full deep-dive worked example is in [SESSION_MEMORY_GUIDE.md §9](Smart-Tutor-Lamp-backend/SESSION_MEMORY_GUIDE.md). Mechanically:

### Step 0 — determine the compaction window
```python
compact_up_to = sess.turn_count - settings.MEMORY_TAIL_SIZE     # = turn_count - 3
if compact_up_to <= (sess.summary_as_of or 0):
    return
```
So the **last `MEMORY_TAIL_SIZE` (3) turns are NEVER compacted** — they stay verbatim in L1. Everything with `turn_index <= compact_up_to` is fetched, ordered by `turn_index`.

### Step 1 — score each old turn by effective importance
[session_memory.py:314-317](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L314):
```python
def importance(t) -> float:
    dr = float(t.decay_resistance or 0.5)        # stored at write-time
    lam = 0.05 * (1.0 - dr)                       # λ
    return math.exp(-lam * (compact_up_to - t.turn_index))   # e^(-λ·elapsed)
```
This is an **exponential decay** where `elapsed = compact_up_to - turn_index` (how many turns ago). The decay rate `λ = 0.05·(1 - decay_resistance)`:
- A high-resistance turn (`dr=0.95`, a `formula/hard`) has `λ = 0.0025` → decays very slowly → near `1.0` score → likely a **keeper**.
- A low-resistance turn (`dr=0.20`) has `λ = 0.04` → decays fast → low score → summarised away.
- Default `dr` when missing is `0.5` → `λ = 0.025`.

### Step 2 — proximity grouping ([session_memory.py:319-329](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L319))
Walk the turns in order; start a new group whenever the gap to the previous turn's index exceeds `_PROXIMITY_WINDOW` (5):
```python
for t in rows:
    if not cur or t.turn_index - cur[-1].turn_index <= _PROXIMITY_WINDOW:
        cur.append(t)
    else:
        groups.append(cur); cur = [t]
```
Consecutive turns within ±5 index of each other form one group.

### Step 3 — keeper selection ([session_memory.py:331-339](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L331))
For each group **of size ≥ `_MIN_GROUP_SIZE` (3)**, the single highest-importance turn is extracted as a verbatim **keeper** (the precise formula/derivation), and the rest go to `to_summarise`. Groups smaller than 3 contribute all their turns to `to_summarise` (no keeper).

### Step 4 — build LLM blocks ([session_memory.py:341-355](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L341))
`fmt(t, cap, full_eqs)` renders `"T{idx} [{subject}/{difficulty}]: {speech[:cap]}{eqs}"`. LaTeX equations are included because they are the highest-value content for a math tutor (exact formulas vs TTS paraphrases):
- keepers: `cap=200`, `full_eqs=True` → `"\n  LaTeX: e1; e2; …"`.
- to-summarise: `cap=120`, `full_eqs=False` → `" | eqs: e1; e2"` (first 2 only).

### Step 5 — the LLM call ([session_memory.py:357](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L357), `_call_compact_llm` at [494-521](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L494))
- Skips entirely if `settings.GEMINI_API_KEY` is unset (returns `""`).
- Calls `google.genai` with `model=settings.GEMINI_MODEL`, `max_output_tokens=250`, `temperature=0.3`.
- The prompt instructs: summarise **from the tutor's replies only** (learner questions aren't available), 2–3 sentences under 100 words, topics/concepts/difficulty, and **explicitly forbids inferring** what the learner understood or felt.
- **Keepers are NOT sent to the LLM** — they are prepended in code as `KEY_FACTS:` to avoid duplication:
  ```python
  if keeper_block and text:
      return f"KEY_FACTS:\n{keeper_block}\n\nSUMMARY:\n{text}"[:700]
  return text[:500]
  ```

### Step 6 — persist ([session_memory.py:361-368](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L361))
On a non-empty summary, set `row.summary = summary` and `row.summary_as_of = compact_up_to` and commit. `summary_as_of` prevents re-compaction of the same batch. A descriptive `[MEM] compacted session=…` log line records keeper/summary counts.

### Step 7 — lock eviction (leak fix, added 2026-07-04)

After the try/except around the compaction body, `_compact_session` now evicts its own per-session lock ([session_memory.py:387-393](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L387)):

```python
if not lock.locked():
    _compact_locks.pop(session_id, None)
```

Previously every session that ever triggered a compaction left its `asyncio.Lock` in the module-level `_compact_locks: dict[str, asyncio.Lock]` (§6.1) **forever** — a slow leak across many sessions and process instances, since nothing ever removed an entry. The eviction is safe because `_maybe_compact` (§6.6) **bails** rather than awaiting when the lock is already held, so a just-released lock can have no waiters — the `lock.locked()` check-then-`pop` is therefore atomic under asyncio (no `await` between them) and can't race a concurrent acquire.

**Result:** the next turn's context (turn N+1) injects the precise formulas (`KEY_FACTS`) verbatim **plus** the prose summary — a richer prompt than a single-blob summary, while staying inside the ~380-token budget.

> **Note on the two implementations:** the live `_compact_session` in `session_memory.py` uses `settings.GEMINI_MODEL` (default `gemini-3.1-flash-lite`). The reference implementation in [SESSION_MEMORY_GUIDE.md §4](Smart-Tutor-Lamp-backend/SESSION_MEMORY_GUIDE.md) hard-codes `gemini-2.0-flash-lite` and wraps everything in a `SessionMemoryService` class — the production code refactored that into module-level functions but kept the identical algorithm, constants, and math.

---

## 8. Layer 3 — Cross-Session Learner Profile

### 8.1 `finalize_session` ([session_memory.py:376-389](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L376))

Called by the lamp on WS close ([ws_lamp.py:292-293](Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L292)). It:
1. `turns.close_session(session_id)` → set `ended_at`.
2. Schedules `asyncio.create_task(update_user_memory(device_id, user_id, run_llm=True))` — the L3 distillation can make an LLM call, so it runs in the **background** so WS teardown isn't blocked (best-effort; may not finish on app shutdown).

### 8.2 `update_user_memory(device_id, user_id, *, run_llm)` ([session_memory.py:392-475](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L392))

Recomputes the cross-session aggregates and (conditionally) the LLM long-summary. Gated on `_factory() is not None AND settings.ENABLE_MEMORY`.

**Aggregate queries (all `status='ok'`, scoped to `device_id`):**
- `subj_rows`: subject → count, top 8 by count desc.
- `diff_rows`: (subject, difficulty) → count.
- `session_count`: count of `SessionRecord` for device.
- `total_turns`: count of ok turns for device.

**`subject_profile` construction** ([session_memory.py:431-437](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L431)): per subject, build a `{difficulty: count}` map, then take the **mode** (most-common difficulty), defaulting to `{"medium": 1}` when a subject has no difficulty data:
```python
subject_profile = {
    s: max(diff_map.get(s, {"medium": 1}), key=diff_map.get(s, {"medium": 1}).get)
    for s, _ in subj_rows
}
```

**NO-NEW-DATA guard (cost control)** ([session_memory.py:441-457](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L441)): when `run_llm`, it first reads the existing `user_memory` row; if its `total_turns` equals the current count **and** a non-empty `long_term_summary` already exists, it **skips both the LLM call and the upsert** and returns. This was added because the lamp's WS reconnect storms (free-tier cold starts, keepalive deaths) fire `finalize_session → run_llm=True` on every close — the comment records an observed incident of **six identical Gemini profile calls in 3 minutes**, all at the same `sessions=23 turns=86`. Since the distilled summary is a pure function of the turn data, no new turn ⇒ the existing row is already correct.

**Three-tier summary policy** ([session_memory.py:459-464](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L459)):
| Turns (`tt`) | Behaviour |
|---|---|
| `< 3` | No `long_summary` at all (insufficient signal). |
| `3 ≤ tt < 10` (and `subject_profile`) | **Template** summary, numbers only, zero inference: `"Learner: {tt} questions across {n} session(s). Subjects: math(hard), …."` |
| `tt ≥ 10` (and `GEMINI_API_KEY`) | **LLM-generated** via `_call_profile_llm` (only path that runs the LLM). |

Finally it upserts via `upsert_user_memory` (passing `long_summary` which may be `None` → partial update preserves an existing summary).

### 8.3 `_call_profile_llm` ([session_memory.py:524-548](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L524))

Generates a 1–2 sentence **factual** profile with `model=settings.GEMINI_MODEL`, `max_output_tokens=100`, `temperature=0.2`, capped to 300 chars. The prompt is strongly anti-hallucination: report **only the facts in the numbers**, forbid `struggles/tends to/seems/likely/prefers` or any inferred trait, no claims about understanding or attitude.

### 8.4 LLM failure logging ([session_memory.py:481-491](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L481))

`_log_mem_llm_failure(which, e)` — because these are background niceties, a transient API error (`ServerError`/`APIError`/`ClientError`, e.g. a Gemini 503 "high demand") gets **one warning line** (it self-heals next cycle); anything unexpected keeps the full traceback. This stops 60-line tracebacks from burying real errors in prod logs.

### 8.5 Callers of L3 refresh
- Lamp: `finalize_session` on WS close → `run_llm=True`.
- Web bench: after each `/simulate` turn → `update_user_memory(device_id, user_id, run_llm=False)` (cheap aggregates + template only, no per-turn LLM spend), debounced via `asyncio.create_task` ([frontend_manager.py:882-885](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L882)).

---

## 9. Storage CRUD (`user_memory.py`, `user_profiles.py`)

### 9.1 `storage/user_memory.py` — the L3 row

[user_memory.py](Smart-Tutor-Lamp-backend/app/storage/user_memory.py). One row per **device** (the `UserMemory` model). Fields (from the model + the guide schema): `id`, `device_id` (unique), `user_id`, `long_term_summary`, `subject_profile` (JSONB `{"math": "hard", …}`), `session_count`, `total_turns`, `created_at`, `updated_at`.

- `get_user_memory(db, device_id)` ([user_memory.py:24-27](Smart-Tutor-Lamp-backend/app/storage/user_memory.py#L24)) — `SELECT … WHERE device_id=…`, `scalar_one_or_none()`.
- `upsert_user_memory(db, *, device_id, user_id, long_term_summary=None, subject_profile=None, session_count=None, total_turns=None)` ([user_memory.py:30-59](Smart-Tutor-Lamp-backend/app/storage/user_memory.py#L30)) — get-or-create, then **partial update**: only the fields you pass as non-`None` are overwritten. Bumps `updated_at`, commits, returns the row. This is why `update_user_memory` can pass `long_term_summary=None` to preserve an existing summary while still refreshing the aggregates.

### 9.2 `storage/user_profiles.py` — the web onboarding profile

[user_profiles.py](Smart-Tutor-Lamp-backend/app/storage/user_profiles.py). Keyed by Clerk `user_id` (the `UserProfile` model). Durable so the analytics layer can read it and the brain prompt can use it.

- `get_profile(db, user_id)` ([user_profiles.py:23-25](Smart-Tutor-Lamp-backend/app/storage/user_profiles.py#L23)) — `db.get(UserProfile, user_id)`.
- `upsert_profile(...)` ([user_profiles.py:28-93](Smart-Tutor-Lamp-backend/app/storage/user_profiles.py#L28)) — a single atomic PostgreSQL `INSERT … ON CONFLICT (user_id) DO UPDATE` (`pg_insert(...).on_conflict_do_update`). This eliminates the read-modify-write race the previous `get()`-then-`add()` version had (a double-click or onboarding racing a background refresh could otherwise collide on the PK).
  - `created_at` preserved (only set on initial insert); `updated_at` always bumps.
  - The `extra` JSONB is **merged** with the SQL `||` operator (`UserProfile.extra.op("||")(stmt.excluded.extra)`): keys in this call overwrite, absent keys are preserved. `None` values are dropped from the delta first (so a missing field never clobbers a stored one) — `delta = {k: v for k, v in (extra or {}).items() if v is not None}`.
  - Re-SELECTs the committed row with `populate_existing=True` to return DB-truth (avoids a stale identity-map hit).

The `extra` JSONB holds the learning fields (`learning_style`, `explain_depth`, `study_rhythm`, `focus_subject`, `strong_subject`, `weak_subject`, and the user's `email`) — these flow into L3 via `_load_user_profile` (§6.3).

---

## 10. Vector Embeddings & ANN Retrieval (`storage/memory_vec.py`)

[memory_vec.py](Smart-Tutor-Lamp-backend/app/storage/memory_vec.py) is the **pgvector long-term semantic memory** seam (Layer 3.3). **It is a deliberate stub** — both functions raise `NotImplementedError`, and the docstring records the explicit project decision: *"SKIP until a real user asks for continuity. BACKEND_TODO.md §3.3 explicitly says 'skip entirely for now.'"*

So there is **no vector-embedding or similarity search running in the system today.** What the file specifies as the intended design (so the gap is documented, not invented):

### 10.1 Intended schema ([memory_vec.py:15-26](Smart-Tutor-Lamp-backend/app/storage/memory_vec.py#L15))
```sql
CREATE EXTENSION IF NOT EXISTS vector;
CREATE TABLE memories (
  id          uuid PRIMARY KEY,
  user_id     text NOT NULL,
  kind        text,                  -- 'turn' | 'note' | …
  content     text NOT NULL,         -- the natural-language summary
  embedding   vector(1536),          -- text-embedding-3-small (or bge-small)
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX memories_user_idx ON memories(user_id);
CREATE INDEX memories_embedding_idx ON memories USING ivfflat (embedding vector_cosine_ops);
```
The embedding dimension is **1536** (OpenAI `text-embedding-3-small`, ~$0.02/M tok) or local **bge-small** (free, ~50 MB). The ANN index is **IVFFlat with cosine ops** (`vector_cosine_ops`).

### 10.2 Intended API ([memory_vec.py:44-56](Smart-Tutor-Lamp-backend/app/storage/memory_vec.py#L44))
- `insert_memory(*, user_id, content)` — embed `content` and upsert into the user's memory. Would be called from `orchestrator._persist_turn`.
- `fetch_relevant(*, user_id, query, k=3)` — **top-k ANN lookup** (default `k=3`), returning plain-text snippets to inject as *"Things you've discussed before"* in the system prompt. Would be called from `_load_history` and combined with the Redis short-term history (top-3 ANN appended after the recent turns).

### 10.3 The intended ranking / retrieval algorithm
Per the file ([memory_vec.py:5-8](Smart-Tutor-Lamp-backend/app/storage/memory_vec.py#L5)) and [SESSION_MEMORY_GUIDE.md §12](Smart-Tutor-Lamp-backend/SESSION_MEMORY_GUIDE.md): embed the **current question text**, then run `SELECT … ORDER BY embedding <=> $query_embedding LIMIT 3` — the `<=>` is the pgvector **cosine-distance** operator, so the ranking is purely **nearest-neighbour by cosine distance** (smallest distance = most semantically similar), top-3. This would add a **fourth layer** beneath the user profile — "things the learner studied that are RELEVANT TO THIS QUESTION" regardless of when they happened. There is **no re-ranking, recency weighting, or hybrid lexical scoring** specified — only cosine-distance ANN.

> **Relation to the live system:** the only retrieval/ranking that actually runs today is L2's `decay_resistance` importance scoring (§7) and L1's recency ordering — both are non-vector, deterministic. The cosine ANN above is the planned but unbuilt fourth layer.

---

## 11. Background Workers (`workers/`)

[workers/__init__.py](Smart-Tutor-Lamp-backend/app/workers/__init__.py) documents the worker tier as **async background jobs NOT on the hot path**. The three *legacy* workers (`transcribe`, `embed`, `rollup`) remain **stubs today** (each raises `NotImplementedError`); none is scheduled or wired. **Two new workers ARE real, however** — the offline **topic/mistake taggers** (`workers/topic_tag.py`, `workers/mistake_tag.py`, added 2026-07) that populate the `turn_topics` / `turn_mistakes` tables consumed by the new **insights** analytics surface. They are anti-join Postgres polls run by cron/operator (`python -m scripts.tag_topics` / `tag_mistakes`), fully documented in **[12-pilot-insights-ota-and-taggers.md](12-pilot-insights-ota-and-taggers.md) §4**. Note that the per-user dashboard analytics in §13 below reads only the `turns` row's own columns and does **not** join the tag tables — insights is the sole consumer.

The `__init__` lays out the intended deployment + trigger pattern for the still-stubbed three:

```
orchestrator._persist_turn  ──fire-and-forget──►  queue.enqueue("transcribe", turn_id)
worker process              ──pulls from queue──►  transcribe(turn_id)
                                                   embed(turn_id)
                                                   update turns.transcript
```

Three deployment options are listed, all valid, to be picked when jobs actually exist: **Arq** (Redis-backed asyncio-native, recommended for v1, ~5 LoC per job), **Celery** (RabbitMQ/Redis, heavier), or **Temporal** (durable workflows, overkill until multi-step orchestration). The function bodies stay the same regardless of which is chosen — only decorators + the bootstrap script change.

### 11.1 `workers/transcribe.py` — offline STT (Layer 9.3)

[transcribe.py](Smart-Tutor-Lamp-backend/app/workers/transcribe.py). Intended: pull saved WAVs from `app.storage.blobs`, run **Groq Whisper Large v3** (`model "whisper-large-v3"`, ~200 ms for a 3 s clip, ~$0.0001/turn), write the text into `turns.transcript`. Used for analytics search and as the upstream STT for LLM providers that don't take audio (Claude, DeepSeek). Intended steps ([transcribe.py:12-20](Smart-Tutor-Lamp-backend/app/workers/transcribe.py#L12)):
1. fetch the `turns` row → `audio_url`;
2. download bytes from `blobs.py`;
3. call Groq Whisper Large v3;
4. `UPDATE turns SET transcript = ? WHERE id = ?`;
5. enqueue `embed(turn_id)` as the next step.

> **Note:** a *synchronous* STT path already exists elsewhere (`model_solver._maybe_transcribe`, [model_solver.py:383](Smart-Tutor-Lamp-backend/app/services/model_solver.py#L383)) used inline by the brain — this offline worker is the separate, deferred analytics/embedding path.

### 11.2 `workers/embed.py` — embedding worker (Layer 3.3 + 9.3)

[embed.py](Smart-Tutor-Lamp-backend/app/workers/embed.py). `embed_turn(turn_id)` would be triggered **after** `transcribe.py` writes `turns.transcript`, embed the `(transcript, response_text)` pair, and store it in pgvector via `storage/memory_vec.insert_memory`. Embedding model choice mirrors §10: OpenAI `text-embedding-3-small` (1536 d) or local bge-small.

### 11.3 `workers/rollup.py` — daily metrics rollup (Layer 9.4)

[rollup.py](Smart-Tutor-Lamp-backend/app/workers/rollup.py). `rollup_daily()` would refresh a Postgres **materialised view** of per-day stats. Intended schedule: **once per day at 00:05 UTC** (Arq cron / Celery beat / Kubernetes CronJob — any). The view sketched in the docstring ([rollup.py:14-22](Smart-Tutor-Lamp-backend/app/workers/rollup.py#L14)):
```sql
CREATE MATERIALIZED VIEW turns_daily AS
SELECT date_trunc('day', asked_at) AS day,
       COUNT(*) AS n_turns,
       percentile_cont(0.50) WITHIN GROUP (ORDER BY ttft_ms) AS p50_ttft,
       percentile_cont(0.95) WITHIN GROUP (ORDER BY ttft_ms) AS p95_ttft,
       percentile_cont(0.95) WITHIN GROUP (ORDER BY total_ms) AS p95_total,
       SUM(cost_usd) AS cost_usd
FROM turns GROUP BY 1;
```
The implementation would be a single `REFRESH MATERIALIZED VIEW CONCURRENTLY turns_daily`, surfaced via Metabase/Grafana on a read replica.

> **Today, the analytics this rollup would precompute are instead computed on-demand by `services/analytics.py` (§13)** with live aggregate SQL against `turns`/`sessions` — no materialised view, no scheduled job.

---

## 12. The Cache Seam (`services/cache.py`) & the Shared Redis Client

### 12.1 `services/cache.py` — the generic cache seam

[cache.py](Smart-Tutor-Lamp-backend/app/services/cache.py) is *"the single place the hot path talks to Redis"* as a generic key/value cache (distinct from `memory.py`'s history lists). **There is no Redis configured today**, so every function is a clean **NO-OP**: the backend runs entirely on Supabase as the source of truth, and every call site has a Postgres fallback right behind the cache call. Functions:

- `enabled()` ([cache.py:30-32](Smart-Tutor-Lamp-backend/app/services/cache.py#L30)) — `True` only when `revocation.get_client() is not None`. Used by `load_context` (§6.2) to decide whether to try the Redis L1 path.
- `cget(key)` ([cache.py:35-45](Smart-Tutor-Lamp-backend/app/services/cache.py#L35)) — returns `None` on miss, no-Redis, **or any error** (caller falls back to Postgres). Used by `turns.open_session` for the active-session id.
- `cset(key, value, ttl_s)` ([cache.py:48-56](Smart-Tutor-Lamp-backend/app/services/cache.py#L48)) — `SET key value EX ttl_s`. No-op without Redis; swallows errors.
- `cdel(key)` ([cache.py:59-67](Smart-Tutor-Lamp-backend/app/services/cache.py#L59)) — `DEL key`. No-op without Redis; swallows errors.

Turning Redis on later is a **config flip, not a rewrite** ([cache.py:9-15](Smart-Tutor-Lamp-backend/app/services/cache.py#L9)): set `REDIS_URL`, `pip install redis`. `app/main.py` already opens the connection on startup via `revocation.init_redis`, and the existing get→(miss)→Postgres→set call sites become real accelerations with zero code change.

### 12.2 The shared Redis client (`services/revocation.py`)

All three Redis consumers — revocation pub/sub, `memory.py` (L1 history), and `cache.py` (session cache) — share the **one** client created by [revocation.init_redis](Smart-Tutor-Lamp-backend/app/services/revocation.py#L48). Key facts:
- The `redis` import is **optional** ([revocation.py:29-35](Smart-Tutor-Lamp-backend/app/services/revocation.py#L29)) so dev runs without `pip install redis` still import. `get_client()` returns `None` when the SDK is absent — everything degrades gracefully.
- `init_redis` no-ops if `REDIS_URL` is unset (logs a warning). Created with `decode_responses=True` (values come back as `str`).
- **Resilience config** ([revocation.py:77-84](Smart-Tutor-Lamp-backend/app/services/revocation.py#L77)): `socket_keepalive=True`, `socket_connect_timeout=5`, `socket_timeout=5`, `health_check_interval=30`, `retry_on_timeout=True`. The bounded `socket_timeout` means a hung Redis **fails fast** to each call site's try/except (Postgres fallback) instead of stalling a turn. An eager `PING` at boot surfaces misconfig early; a failed ping sets `_client = None`.

---

## 13. Analytics Aggregation (`services/analytics.py`)

[analytics.py](Smart-Tutor-Lamp-backend/app/services/analytics.py) computes **per-user, read-only** rollups for the web dashboard. It is purely on-demand SQL (no caching, no materialised view). Two functions, both scoped `WHERE user_id = :uid` (RLS-equivalent at the application layer):

### 13.1 `user_analytics(db, user_id) -> AnalyticsOut` ([analytics.py:39-96](Smart-Tutor-Lamp-backend/app/services/analytics.py#L39))

Backs `GET /api/frontend/analytics` ([frontend_manager.py:168-176](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L168)). Two data sources with different reliability guarantees:

**(a) Devices — always available (ORM):** selects non-revoked devices ordered by `paired_at DESC`. For each, `online = last_seen_at AND (now - last_seen_at) <= _ONLINE_WINDOW`, where `_ONLINE_WINDOW = timedelta(seconds=60)` ([analytics.py:36](Smart-Tutor-Lamp-backend/app/services/analytics.py#L36)). Fills `device_count`, `online_devices`, and a `DeviceSummary` list.

**(b) Turns/sessions — guarded raw SQL** (may not be migrated yet, [analytics.py:61-94](Smart-Tutor-Lamp-backend/app/services/analytics.py#L61)):
- `total`, `last7` (turns with `asked_at >= now-7d` via a `FILTER` clause), `last_active` = `max(asked_at)` — one query.
- `sessions_count` = `count(*) FROM sessions`.
- `subject_mix` = `subject → count` for `status='ok'`, top 8 by count desc.
- **On ANY exception** (missing table / un-migrated / aborted txn): `log.exception` then `await db.rollback()` so the session is reusable, and return the device data with zeros. The full traceback is printed deliberately so a real query bug isn't hidden behind "zeros".

### 13.2 `user_analytics_detail(db, user_id, *, days=14) -> AnalyticsDetailOut` ([analytics.py:99-227](Smart-Tutor-Lamp-backend/app/services/analytics.py#L99))

Backs `GET /api/frontend/analytics/detail` ([frontend_manager.py:179-190](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L179)). `days` is clamped to `[1, 90]`: `days = max(1, min(int(days or 14), 90))`.

Device block as above (online count only). Then a guarded turns/sessions block that computes:

- **Headline totals + latency percentiles** (one query over `status='ok'` turns): `turns`, `last7`, `avg_ms` (`round(avg(total_ms))`), **`p50`/`p95`** via `percentile_disc(0.5/0.95) WITHIN GROUP (ORDER BY total_ms)`, `conf` (`round(avg(confidence),3)`), `cost` (`sum(cost_usd)`), `esc` (`count FILTER (WHERE escalated)`), `last_active`. `escalated_pct = round(100·esc/turns, 1)` (guarded against div-by-zero).
- **`sessions`** count.
- **Gap-filled daily series** ([analytics.py:158-171](Smart-Tutor-Lamp-backend/app/services/analytics.py#L158)): `generate_series(now()-make_interval(days=>n)::date, now()::date, '1 day')` **LEFT JOIN** turns on `asked_at::date = g.d::date AND user_id AND status='ok'`, grouped/ordered by day. The LEFT JOIN + series means **days with zero activity still appear** (as `turns=0`), so the chart has no gaps. Emits `DailyPoint(label, turns, avg_ms)`.
- **Distributions in ONE round-trip** via a tagged `UNION ALL` ([analytics.py:174-198](Smart-Tutor-Lamp-backend/app/services/analytics.py#L174)): four sub-selects tagged `'subject' | 'difficulty' | 'query_type' | 'status'`, each `coalesce`-defaulting nulls (`'other'`/`'unknown'`). Status is computed over **all** turns (not just ok) so failures are visible. Dispatched into `subject_mix`, `difficulty_mix`, `query_type_mix`, `status_mix`.
- **Recent-questions feed** ([analytics.py:201-222](Smart-Tutor-Lamp-backend/app/services/analytics.py#L201)): last 10 turns (all statuses, ordered `asked_at DESC`) → `RecentTurn(asked_at, subject, difficulty, query_type, question=transcript, answer=speech[:240], total_ms, status)`.
- Same rollback-and-return-partial guard on any exception.

### 13.3 Output schemas ([schemas/frontend.py](Smart-Tutor-Lamp-backend/app/schemas/frontend.py))

`AnalyticsOut` ([frontend.py:137-149](Smart-Tutor-Lamp-backend/app/schemas/frontend.py#L137)) and `AnalyticsDetailOut` ([frontend.py:111-134](Smart-Tutor-Lamp-backend/app/schemas/frontend.py#L111)) plus `DailyPoint`, `RecentTurn`, `DeviceSummary`. Every field defaults to empty/zero so the dashboard renders cleanly before any lamp traffic. `RecentTurn` gained pilot fields `turn_id` and `feedback` ([frontend.py:104-108](Smart-Tutor-Lamp-backend/app/schemas/frontend.py#L104)) so the feed can pre-fill the 👍/👎 widget (pilot feature F1, doc 12 §1).

### 13.4 A second analytics surface: `services/insights.py` (admin, cohort-scoped)

`services/analytics.py` above is the **per-user** dashboard. A separate, **admin-gated, cohort-scoped** learning-analytics service — `services/insights.py` + `routes/insights.py` (`/api/frontend/admin/pilot/insights/*`) — was added 2026-07 to compute per-topic strength, syllabus coverage, engagement (DAU/WAU/MAU, streaks), a mistake-type breakdown, and quality (escalation/drop-off). It joins `turns ⨝ turn_topics ⨝ syllabus_topics ⨝ turn_feedback ⨝ sessions ⨝ turn_mistakes` (the offline tagger output), reusing the savepoint-guarded `_rows`/`_scalar` from `services/admin`. Full coverage in **[12-pilot-insights-ota-and-taggers.md](12-pilot-insights-ota-and-taggers.md) §2**.

---

## 14. Configuration, Environment Variables & Constants

### 14.1 Settings (`app/config.py`)

| Setting | Default | Effect | Location |
|---|---|---|---|
| `ENABLE_MEMORY` | **`True`** | Master toggle for L1+L2+L3. False → Redis-only L1, no DB writes. | [config.py:282](Smart-Tutor-Lamp-backend/app/config.py#L282) |
| `MEMORY_COMPACT_THRESHOLD` | `8` | Turns before older turns are L2-compacted. Must be > tail size. | [config.py:285](Smart-Tutor-Lamp-backend/app/config.py#L285) |
| `MEMORY_TAIL_SIZE` | `3` | Most-recent turns kept verbatim (never compacted) = L1 tail. | [config.py:287](Smart-Tutor-Lamp-backend/app/config.py#L287) |
| `MEMORY_SESSION_IDLE_MIN` | `30` | Idle gap (min) before a reconnect starts a fresh session. | [config.py:289](Smart-Tutor-Lamp-backend/app/config.py#L289) |
| `ENABLE_MEMORY_COMPACTION` | `True` | Run the async L2 compaction LLM call (off = log turns without spend). | [config.py:291](Smart-Tutor-Lamp-backend/app/config.py#L291) |
| `GEMINI_API_KEY` | `""` | Required for L2 compaction + L3 LLM summary; absent → those return `""`. | [config.py:34](Smart-Tutor-Lamp-backend/app/config.py#L34) |
| `GEMINI_MODEL` | `"gemini-3.1-flash-lite"` | Model for both compaction + profile LLM calls. | [config.py:35](Smart-Tutor-Lamp-backend/app/config.py#L35) |
| `REDIS_URL` | `""` | Unset → all Redis (L1 hot cache, session cache, revocation) no-op. | [config.py:228](Smart-Tutor-Lamp-backend/app/config.py#L228) |

### 14.2 Module-level constants

| Constant | Value | File |
|---|---|---|
| `HISTORY_KEY_PREFIX` | `"lamp:hist:"` | [memory.py:32](Smart-Tutor-Lamp-backend/app/services/memory.py#L32) |
| `HISTORY_DEPTH` | `3` | [memory.py:33](Smart-Tutor-Lamp-backend/app/services/memory.py#L33) |
| `HISTORY_TTL_S` | `86400` (24 h) | [memory.py:34](Smart-Tutor-Lamp-backend/app/services/memory.py#L34) |
| `EMPTY_HISTORY_TEXT` | `"[Session start — no prior turns]"` | [memory.py:38](Smart-Tutor-Lamp-backend/app/services/memory.py#L38) |
| `_L3_CAP` / `_L2_CAP` | `360` / `480` | [session_memory.py:40-41](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L40) |
| `_PROXIMITY_WINDOW` | `5` | [session_memory.py:45](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L45) |
| `_MIN_GROUP_SIZE` | `3` | [session_memory.py:46](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L46) |
| compaction `max_output_tokens` / `temperature` | `250` / `0.3` | [session_memory.py:513](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L513) |
| profile `max_output_tokens` / `temperature` | `100` / `0.2` | [session_memory.py:543](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L543) |
| L3 LLM turn threshold | `tt >= 10` (LLM) / `tt >= 3` (template) | [session_memory.py:460-462](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L460) |
| `_ONLINE_WINDOW` | `timedelta(seconds=60)` | [analytics.py:36](Smart-Tutor-Lamp-backend/app/services/analytics.py#L36) |
| `_SESSION_IDLE_MIN` | `30` | [turns.py:34](Smart-Tutor-Lamp-backend/app/storage/turns.py#L34) |
| `_SID_CACHE_TTL_S` | `(30+5)*60 = 2100` | [turns.py:40](Smart-Tutor-Lamp-backend/app/storage/turns.py#L40) |
| decay-resistance `λ` factor | `0.05 * (1 - dr)` | [session_memory.py:316](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L316), [turns.py:157](Smart-Tutor-Lamp-backend/app/storage/turns.py#L157) |
| analytics `days` clamp | `[1, 90]` | [analytics.py:109](Smart-Tutor-Lamp-backend/app/services/analytics.py#L109) |

---

## 15. Edge Cases, Error Handling, Timeouts, Fallbacks

- **Redis absent / down:** `get_client()` returns `None` → `memory.load_history` returns `EMPTY_HISTORY_TEXT`, `push_turn`/`clear_history` no-op, `cache.*` no-op, `cache.enabled()` False. The system runs entirely on Supabase. `socket_timeout=5` means a *hung* Redis fails fast to the Postgres fallback rather than stalling.
- **DB absent / un-migrated:** `_factory()` returns `None` → L2/L3 are skipped; `load_context` still returns L1 (or its placeholder). `turns.write_turn`/`open_session` no-op or degrade (e.g. missing `last_activity_at` column → `session_id=NULL`, turn still written). Analytics catches the missing-relation error, **rolls back**, and returns zeros.
- **History on the hot path is hard-bounded:** the orchestrator wraps `load_context` in `asyncio.wait_for(..., timeout=2.0)` — a slow/unreachable store degrades to `"[Session start — no prior turns]"` rather than hanging the learner ([orchestrator.py:1247-1257](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1247)).
- **Failed turns never pollute memory:** the `status not in (None, "ok")` guard appears in `record_turn` ([session_memory.py:222](Smart-Tutor-Lamp-backend/app/services/session_memory.py#L222)) and `write_turn` ([turns.py:188](Smart-Tutor-Lamp-backend/app/storage/turns.py#L188)). An error fallback ("Sorry, I had trouble") is neither stored nor counted toward the compaction threshold.
- **Corrupted Redis entries:** `_format` skips un-parseable JSON entries individually rather than failing the whole turn ([memory.py:165-170](Smart-Tutor-Lamp-backend/app/services/memory.py#L165)).
- **Concurrent compaction:** one `asyncio.Lock` per `session_id`; `_maybe_compact` returns early if `lock.locked()`, and `_compact_session` re-checks `summary_as_of` under the lock to avoid double work.
- **Concurrent turn_index:** the atomic `UPDATE … RETURNING turn_count` prevents lost updates from fire-and-forget concurrent writers.
- **LLM cost runaway (real incident):** the NO-NEW-DATA guard in `update_user_memory` (§8.2) prevents repeated identical profile LLM calls during WS reconnect storms.
- **Transient LLM errors:** `_log_mem_llm_failure` downgrades `ServerError/APIError/ClientError` to one warning line (self-heals next cycle); compaction/profile return `""` on failure and the turn is unaffected.
- **Cross-user privacy:** device-scoped Redis history is cleared on unlink/deletion (`clear_history`); session resume requires user-id match (`IS NOT DISTINCT FROM`); `load_recent_turns` filters by `user_id` when there's no session.
- **Token-budget overrun:** `_cap_at_word` + `_L2_CAP`/`_L3_CAP` enforce hard char caps even if the DB returns verbose text; word-boundary truncation avoids mid-word noise.
- **All four stubs raise `NotImplementedError`** — calling embeddings/ANN/workers today would throw. Nothing in the live code path invokes them, so this is inert.

---

## 16. Integration Points / Cross-References

**What calls into this subsystem:**

| Caller | Calls | Purpose |
|---|---|---|
| `orchestrator._history_text` ([orchestrator.py:1264-1265](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1264)) | `session_memory.load_context` | Lamp turn — read L3+L2+L1 before LLM |
| `orchestrator._persist_turn` ([orchestrator.py:1380-1386](Smart-Tutor-Lamp-backend/app/services/orchestrator.py#L1380)) | `session_memory.record_turn` | Lamp turn — durable + L1 write + compaction |
| `ws_lamp` finally ([ws_lamp.py:292-293](Smart-Tutor-Lamp-backend/app/routes/ws_lamp.py#L292)) | `session_memory.finalize_session` | WS close — close session + L3 refresh |
| `frontend_manager.simulate` ([frontend_manager.py:765-770](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L765), [854](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L854), [882-885](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L882)) | `load_context`, `record_turn`, `update_user_memory(run_llm=False)` | Web bench — identical memory to the lamp |
| `frontend_manager` analytics routes ([frontend_manager.py:168-190](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L168)) | `user_analytics`, `user_analytics_detail` | Dashboard |
| `device_user` unlink ([device_user.py:197-199](Smart-Tutor-Lamp-backend/app/routes/device_user.py#L197)) / `clerk_webhook` ([clerk_webhook.py:99-104](Smart-Tutor-Lamp-backend/app/routes/clerk_webhook.py#L99)) | `memory.clear_history` | Privacy — purge device history |

**What this subsystem calls out to:**
- `app.services.revocation.get_client()` — the shared Redis client.
- `app.db.session.get_session_factory()` + `app.db.models` (`SessionRecord`, `TurnRecord`, `UserMemory`, `UserProfile`, `Device`) — Postgres.
- `app.storage.turns` (`write_turn`, `load_recent_turns`, `close_session`) — durable L1.
- `app.storage.user_memory` / `app.storage.user_profiles` — L3 CRUD.
- `google.genai` (Gemini, `settings.GEMINI_MODEL`) — L2/L3 LLM summaries.
- `app.schemas.frontend` — analytics response models.

**Cross-layer ties (firmware / frontend / db):**
- **Firmware (ESP32-S3):** the lamp connects over WebSocket; its turns flow through `orchestrator → record_turn`. The lamp's `LlmReply` carries `same_problem` / `problem_statement` which drive the L1 NEW-PROBLEM trimming. The lamp has no browser, so L1 `transcript` is the model's restatement (`user_input`), not a Whisper transcript (the offline Whisper path is the deferred `workers/transcribe.py`).
- **Frontend (Next.js):** the web simulator hits `/api/frontend/simulate` (parity memory), and the dashboard reads `/api/frontend/analytics{,/detail}`. The onboarding form (`lib/onboarding.ts`) writes `user_profiles` (→ L3). Schemas in `schemas/frontend.py` mirror the frontend widgets.
- **Database (Supabase/Postgres + pgvector):** `sessions`, `turns`, `user_memory`, `user_profiles` are live; the `memories` pgvector table + IVFFlat cosine index and the `turns_daily` materialised view are designed but not migrated.

---

## 17. Mermaid Diagrams

### 17.1 Per-turn memory flow (read → LLM → write → background compaction)

```mermaid
flowchart TD
    A[Turn arrives: lamp WS or web /simulate] --> B[load_context device,user,session]
    B --> C{ENABLE_MEMORY and DB up?}
    C -- yes --> D[gather in parallel:<br/>L3 _load_user_profile<br/>L2 _load_session_summary]
    C -- no --> E[skip L2/L3]
    D --> F[L1: cache.enabled?]
    E --> F
    F -- Redis live --> G[memory.load_history Redis LRANGE 0..2]
    F -- no/empty --> H[turns.load_recent_turns Postgres limit=TAIL_SIZE]
    G --> I[assemble L3+L2+L1, XML-tagged, char-capped]
    H --> I
    I --> J[history_text -> LLM call wait_for 2s cap]
    J --> K[LlmReply produced]
    K --> L[record_turn]
    L --> M{status in None,ok?}
    M -- no --> Z[drop: never memory]
    M -- yes --> N[turns.write_turn: durable + atomic turn_count++]
    N --> O[memory.push_turn: Redis LPUSH+LTRIM 0..2+EXPIRE 24h]
    O --> P{session and compaction enabled?}
    P -- yes --> Q[create_task _maybe_compact]
    P -- no --> R[done]
    Q --> S{turn_count >= 8 and not up-to-date?}
    S -- no --> R
    S -- yes --> T[_compact_session under per-session lock]
```

### 17.2 L2 smart-compaction internals

```mermaid
flowchart LR
    A[fetch turns where turn_index <= turn_count - TAIL_SIZE] --> B[score each:<br/>importance = e^-λ·elapsed<br/>λ = 0.05·1-decay_resistance]
    B --> C[proximity-group:<br/>consecutive turns within ±5 index]
    C --> D{group size >= 3?}
    D -- yes --> E[keeper = max importance turn verbatim]
    D -- yes --> F[rest -> to_summarise]
    D -- no --> F
    E --> G[keeper_block full LaTeX]
    F --> H[turns_block speech[:120]+2 eqs]
    H --> I[Gemini summarise<br/>2-3 sentences, no inference<br/>max_tokens 250 temp 0.3]
    I --> J[summary = KEY_FACTS keepers + SUMMARY prose]
    G --> J
    J --> K[sessions.summary = summary<br/>summary_as_of = compact_up_to]
```

### 17.3 Session-end L3 refresh + cost guard

```mermaid
sequenceDiagram
    participant WS as ws_lamp (finally)
    participant SM as session_memory
    participant DB as Postgres
    participant G as Gemini
    WS->>SM: finalize_session(device,user,session)
    SM->>DB: close_session -> ended_at=now()
    SM-->>SM: create_task update_user_memory(run_llm=True)
    SM->>DB: aggregate subjects/difficulty/sessions/total_turns (status=ok)
    SM->>DB: read existing user_memory row
    alt total_turns unchanged AND summary exists
        SM-->>SM: SKIP LLM + upsert (NO-NEW-DATA guard)
    else turns >= 10 AND GEMINI_API_KEY
        SM->>G: _call_profile_llm (factual, anti-hallucination)
        G-->>SM: 1-2 sentence summary
        SM->>DB: upsert_user_memory (partial)
    else 3 <= turns < 10
        SM->>DB: upsert template summary (numbers only)
    end
```

---

*End of reference. This document describes the system exactly as the code stands: L1 (Redis hot + Postgres durable fallback), L2 (on-demand Gemini smart compaction with decay-resistance + proximity grouping), and L3 (cross-session learner profile with a cost guard) are live; pgvector ANN (`memory_vec.py`) and the three background workers (`transcribe.py`, `embed.py`, `rollup.py`) are deliberate `NotImplementedError` stubs with documented intended designs; the generic cache seam (`cache.py`) is a NO-OP until `REDIS_URL` is set; analytics (`analytics.py`) is computed on-demand from `turns`/`sessions`.*
