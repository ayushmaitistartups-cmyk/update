# Backend — TFT Formatting, Track Routing, Schemas & Admin Services

This is the definitive reference for the backend's **output-shaping helpers** (the
tiny-screen TFT formatter and the LaTeX-vs-plain-text track router), the **complete
Pydantic schema layer** (admin, auth, frontend, LLM reply, model-eval), and the
**admin + frontend-manager service/route surfaces** that the Next.js dashboard reads
from and writes to. It explains, line-by-line and function-by-function, how raw LLM
output is turned into wire shapes the lamp and the web app render, how the admin
dashboard's system-wide rollups are computed and cached, and where the prototype
"BAO" formatting modules sit relative to the production `LlmReply`/`SimResponse`
pipeline.

Everything below is grounded in the actual source; legacy/prototype code is flagged
explicitly so it is never confused with the live path.

---

## Table of Contents

1. [Scope & responsibility](#1-scope--responsibility)
2. [Two worlds: prototype "BAO" vs. production pipeline](#2-two-worlds-prototype-bao-vs-production-pipeline)
3. [Architecture overview](#3-architecture-overview)
4. [`formatting/tft_formatter.py` — the 4-line TFT clamp](#4-formattingtft_formatterpy--the-4-line-tft-clamp)
5. [`formatting/track_router.py` — LaTeX-vs-plain-text routing](#5-formattingtrack_routerpy--latex-vs-plain-text-routing)
6. [Prototype context: `turn_handler.py` + `validator.py`](#6-prototype-context-turn_handlerpy--validatorpy)
7. [Schemas — `schemas/llm_response.py` (the live TFT contract)](#7-schemas--schemasllm_responsepy-the-live-tft-contract)
8. [Schemas — `schemas/auth.py`](#8-schemas--schemasauthpy)
9. [Schemas — `schemas/frontend.py`](#9-schemas--schemasfrontendpy)
10. [Schemas — `schemas/model_eval.py`](#10-schemas--schemasmodel_evalpy)
11. [Schemas — `schemas/admin.py`](#11-schemas--schemasadminpy)
12. [`schemas/__init__.py`](#12-schemas__init__py)
13. [`services/admin.py` — system-wide read service](#13-servicesadminpy--system-wide-read-service)
14. [`routes/admin.py` — the admin HTTP surface](#14-routesadminpy--the-admin-http-surface)
15. [`routes/frontend_manager.py` — identity / profile / analytics / bench](#15-routesfrontend_managerpy--identity--profile--analytics--bench)
16. [Configuration, constants & environment variables](#16-configuration-constants--environment-variables)
17. [Edge cases, error handling, fallbacks](#17-edge-cases-error-handling-fallbacks)
18. [Integration points / cross-references](#18-integration-points--cross-references)
19. [Mermaid diagrams](#19-mermaid-diagrams)

---

## 1. Scope & responsibility

This area of the backend owns four things:

1. **Display formatting for the lamp's 320×240 TFT** — taking a string of answer
   content and clamping it to the physical constraints of the tiny screen
   (`tft_formatter.py`).
2. **Two-track display routing** — deciding whether equations may be rendered as
   LaTeX or must be flattened to plain text, based on the student's exam track
   (`track_router.py`).
3. **The Pydantic schema layer** — every request/response wire shape: the LLM JSON
   reply that drives speech/display/equations, the auth+pairing contracts, the
   frontend identity/profile/analytics shapes, the multi-LLM evaluation shapes, and
   the admin-dashboard shapes.
4. **The admin & frontend-manager service/route surfaces** — the read-only,
   system-wide dashboard data (health, cost, users, devices, sessions, turns,
   events, per-model eval stats, per-turn traces, media storage) plus the per-user
   identity/profile/analytics endpoints and the web "brain bench" (`/simulate`,
   `/solve`, `/solve/compare`, `/feedback`, `/ws`).

---

## 2. Two worlds: prototype "BAO" vs. production pipeline

A critical distinction the rest of this document depends on:

| Module | Status | Used by the live lamp/web turn? |
|---|---|---|
| `app/formatting/tft_formatter.py` | **Prototype/legacy (BAO)** | No — only referenced in a *comment* in `turn_handler.py` |
| `app/formatting/track_router.py` | **Prototype/legacy (BAO)** | No — duplicated inline in `validator.py`, itself prototype |
| `app/services/turn_handler.py` | **Prototype/legacy (BAO)** | No — uses a hardcoded mock LLM dict |
| `app/services/validator.py` | **Prototype/legacy (BAO)** | No — called only by `turn_handler.py` |
| `app/schemas/llm_response.py` | **Production** | **Yes** — the real per-turn LLM contract (`LlmReply`) |
| `app/providers/gemini_brain.py` `SimResponse`/`Display` | **Production** | **Yes** — the web bench shape |
| `app/schemas/{admin,auth,frontend,model_eval}.py` | **Production** | **Yes** |
| `app/services/admin.py`, `app/routes/admin.py`, `app/routes/frontend_manager.py` | **Production** | **Yes** |

The grep that confirms this: the only non-definition references to
`enforce_tft_constraint` and `route_track` across the whole backend are
documentation/comment lines — `LAYOUT.md`, `CLAUDE_BRANCH_GUIDE.md`, and a commented
TODO in `turn_handler.py:52`:

```python
# and tft_formatter.enforce_tft_constraint(final_response["tft_display"]["content"])
```

So `tft_formatter`/`track_router` are the *design-intended* formatting layer that
maps onto the repo's "formatting/" design folder ([LAYOUT.md:64-66](app/LAYOUT.md#L64));
the **production** display-shaping contract is actually expressed declaratively in
`LlmReply`/`Display`/`SimResponse` and enforced by the orchestrator and the firmware
renderer, not by these two helper functions. Both are documented here in full
because they are part of the assignment and represent the canonical "formatting"
algorithms.

---

## 3. Architecture overview

```
                          ┌─────────────────────────────────────────────┐
   LLM provider JSON  ───▶ │ schemas/llm_response.py : LlmReply           │
   (Gemini/Claude/…)       │  • _coerce_tolerant (pre-validator)          │
                          │  • Display{kind,content}, latex_equations[]  │
                          └───────────────┬─────────────────────────────┘
                                          │ speech / display / equations
                                          ▼
                          ┌─────────────────────────────────────────────┐
   PROTOTYPE (unused):     │ formatting/track_router.route_track          │
   exam_track → LaTeX|text │ formatting/tft_formatter.enforce_tft_…       │
                          └─────────────────────────────────────────────┘

   WEB BENCH:  providers/gemini_brain.SimResponse  →  schemas/model_eval.* wire shapes

                          ┌─────────────────────────────────────────────┐
   Postgres (turns,        │ services/admin.py  (savepoint-guarded SQL)  │
   devices, sessions,  ───▶│  overview / list_* / turn_trace / model_… ) │──┐
   events, model_*)        └─────────────────────────────────────────────┘  │ dict
                                          ▲ 45s Redis cache                  ▼
                          ┌─────────────────────────────────────────────┐
   Next.js /admin    ◀──── │ routes/admin.py  (require_admin gate)        │  schemas/admin.*
   Next.js dashboard ◀──── │ routes/frontend_manager.py (clerk gate)     │  schemas/frontend.* + model_eval.*
                          └─────────────────────────────────────────────┘
```

Key modules and their roles:

- **`schemas/`** — pure Pydantic v2 declarations. No DB or network. The single
  source of wire truth shared by FastAPI request validation, OpenAPI docs, and the
  Next.js TypeScript mirrors (`lib/admin.ts`, `lib/onboarding.ts`, `lib/models.ts`).
- **`services/admin.py`** — system-wide, read-only aggregation. Talks to Postgres
  via raw SQL inside savepoints, caches to Redis, returns plain dicts.
- **`routes/admin.py`** — thin FastAPI wrappers; gate on `require_admin`, rate-limit,
  validate the service dict into the `schemas/admin.py` response models.
- **`routes/frontend_manager.py`** — the per-user surface plus the multi-LLM bench;
  gates on `current_clerk_user`; uses `schemas/frontend.py` + `schemas/model_eval.py`.
- **`formatting/`** — the prototype clamp + track router (see §2).

---

## 4. `formatting/tft_formatter.py` — the 4-line TFT clamp

Full source ([tft_formatter.py:1-14](app/formatting/tft_formatter.py#L1)):

```python
"""TFT Formatter for maintaining lines constraint"""

def enforce_tft_constraint(content: str, is_latex: bool, max_lines: int = 4) -> str:
    """
    Enforces the 320x240 constraints, making sure content is max 4 lines.
    """
    lines = content.split('\n')
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        if not is_latex:
            lines[-1] = lines[-1][:30] + "..." # basic truncation for text

    return '\n'.join(lines)
```

### Purpose

The lamp's display is a 320×240 pixel TFT. At the chosen font size, roughly **4
lines** of text fit. This function guarantees a content string never exceeds that.

### Signature & parameters

| Parameter | Type | Default | Meaning |
|---|---|---|---|
| `content` | `str` | — | The text/LaTeX block destined for the TFT |
| `is_latex` | `bool` | — | Whether `content` is LaTeX (changes truncation behavior) |
| `max_lines` | `int` | `4` | Hard cap on number of lines (the "320×240 / 4-line" constant) |

### Algorithm (mechanical)

1. **Split into lines.** `content.split('\n')` → list of physical lines.
2. **Check overflow.** If `len(lines) > max_lines` (default 4), the content is too
   tall for the screen.
3. **Truncate to the cap.** Keep only the first `max_lines` lines (`lines[:max_lines]`).
   Lines beyond the cap are dropped entirely (no ellipsis indicating dropped lines).
4. **Text-only mid-line truncation.** If `is_latex` is **False**, the last surviving
   line is additionally hard-cut to **30 characters** and an ellipsis appended:
   `lines[-1] = lines[-1][:30] + "..."`. This is a crude width guard for the final
   visible line of plain prose.
5. **LaTeX is line-clamped only.** When `is_latex` is **True**, step 4 is skipped —
   LaTeX is *not* character-truncated, because cutting a LaTeX string mid-command
   (`\frac{a}{b}` → `\frac{a`) would produce an unrenderable expression. LaTeX
   overflow is handled purely by dropping whole lines.
6. **Re-join** with `\n` and return.

### Constants & their effects

- **`max_lines = 4`** — the physical 4-line budget of the 320×240 TFT.
- **`[:30]`** — magic width constant for the trailing prose line. Note: it is applied
  to the *whole* last line including any characters already present, then `"..."` is
  appended, so the visible last line becomes up to 33 characters.

### Edge cases

- **Content already ≤ `max_lines`** → returned unchanged (the `if` is skipped). No
  per-line width clamping happens in this case — a single very long line that is
  ≤ 4 lines passes through untouched.
- **Empty string** → `"".split('\n')` is `[""]`, length 1 ≤ 4 → returned as `""`.
- **Exactly `max_lines` lines** → not truncated (`>` is strict).
- **LaTeX with > 4 lines** → first 4 kept, no character cut; a `\\`-joined multi-line
  expression could lose later rows. (The production prompt independently forbids `\\`
  line breaks inside a single equation — see `MAX_EQUATIONS` discussion in §7.)

### Where it would be called (live status)

It is **not** wired into the live turn path. The orchestrator's downstream
formatting comment ([turn_handler.py:50-52](app/services/turn_handler.py#L50)) is the
only reference. In production the display contract is enforced declaratively by the
prompt (`display.content` "≤ 100 words", "the lamp truncates longer cards mid-word")
plus the firmware renderer.

---

## 5. `formatting/track_router.py` — LaTeX-vs-plain-text routing

Full source ([track_router.py:1-20](app/formatting/track_router.py#L1)):

```python
"""Formats strings using track routing (LaTeX vs plain text)"""

def route_track(display_content: dict, exam_track: str) -> dict:
    """
    Two-track format logic.
    Technical = LaTeX allowed.
    Conceptual = Plain text only.
    """
    kind = display_content.get("kind", "text")
    content = display_content.get("content", "")

    if exam_track == "conceptual" and kind == "latex":
        kind = "text"
        # simple mock conversion
        content = content.replace("$$", "").replace("$", "").replace("\\", "")

    return {
        "kind": kind,
        "content": content
    }
```

### Purpose

Implements a **two-track display policy**:

- **Technical track** (e.g. JEE/GATE/NEET-style quantitative exams) → LaTeX is
  allowed; the display dict passes through untouched.
- **Conceptual track** (everything else) → no LaTeX rendering; any `kind == "latex"`
  card is **demoted to plain text** and stripped of math delimiters/escapes.

### Signature & parameters

| Parameter | Type | Meaning |
|---|---|---|
| `display_content` | `dict` | `{"kind": "latex"|"text", "content": str}` — the proposed display card |
| `exam_track` | `str` | `"technical"` or `"conceptual"` |

Returns a **new** dict `{"kind", "content"}`.

### Algorithm (mechanical)

1. **Extract with defaults.** `kind = display_content.get("kind", "text")` (default
   `"text"`), `content = display_content.get("content", "")` (default empty).
2. **Track/kind mismatch check.** The single transform fires **only** when
   `exam_track == "conceptual"` **and** `kind == "latex"`.
3. **Demote to text.** Set `kind = "text"`.
4. **Flatten LaTeX → prose.** A naive ("mock") conversion that strips, in order:
   - `"$$"` (display-math delimiters),
   - `"$"` (inline-math delimiters),
   - `"\\"` (single backslash — strips LaTeX command escapes).
   This is **string replacement, not real LaTeX→text rendering**; it leaves command
   names and braces intact (`\frac{a}{b}` → `frac{a}{b}`). The comment itself flags
   it as a "simple mock conversion".
5. **Return** the (possibly modified) `{kind, content}`.

### Behavior matrix

| `exam_track` | input `kind` | output `kind` | content transform |
|---|---|---|---|
| `technical` | `latex` | `latex` | none (pass-through) |
| `technical` | `text` | `text` | none |
| `conceptual` | `latex` | `text` | strip `$$`, `$`, `\` |
| `conceptual` | `text` | `text` | none |
| any other value | any | unchanged | none |

### Edge cases

- **Missing keys** → defaulted (`kind="text"`, `content=""`), so a malformed dict
  never raises.
- **`exam_track` other than `"conceptual"`** (including `"technical"`, `""`, or
  unexpected strings) → pass-through; only `"conceptual"` triggers demotion.
- **Naive strip** can leave broken-looking residue (`\frac` → `frac`). This is
  acceptable for the prototype but is exactly why the production schema (§7) removed
  the `"latex"` display kind entirely and moved equations to a separate
  `latex_equations[]` array.

### Relationship to production

This exact logic is **duplicated inline** in the prototype validator
([validator.py:38-41](app/services/validator.py#L38)) — `route_track` is the
extracted version of validator's "Check 2: Track mismatch". Neither is on the live
path. In production, the LLM reply schema simply *forbids* math notation in
`display.content` ("NO math notation: no $...$, no LaTeX commands, no unicode math";
[llm_response.py:57-68](app/schemas/llm_response.py#L57)) and routes all equations
through `latex_equations[]`, so no post-hoc track demotion is needed.

---

## 6. Prototype context: `turn_handler.py` + `validator.py`

> **UPDATE 2026-07-01, corrected 2026-07-03:** `services/turn_handler.py` and `services/validator.py` have been **moved to `app/legacy/`** (report task 2.1); a CI guard (`tests/test_no_legacy_imports.py`) fails if `app/` re-imports them. **`app/formatting/` (`tft_formatter.py`, `track_router.py`) was NOT moved — it remains a live directory** (§4/§5 below still apply). The **live** display-contract enforcement is now `app/services/output_validator.py` + the firmware renderer. New verifier schema fields (`equation`/`given`/`unknown`/`final_answer`/`answer_units`/`method_tag`/`verification_summary`, gated by `MATH_VERIFY_ENABLED`) were added to `LlmReply`. See [11-output-validator-guardrails-and-verifier.md](11-output-validator-guardrails-and-verifier.md). **File paths below now resolve under `app/legacy/`** (e.g. `app/legacy/turn_handler.py`).

These two files are not in the assigned list but are the *callers* of the two
formatting helpers and establish the "BAO architecture" the formatting modules were
designed for. Summarizing for cross-reference:

### `services/turn_handler.py` — prototype orchestrator

`handle_turn(session_id, student_profile, audio_stream, image_ref)`
([turn_handler.py:8](app/services/turn_handler.py#L8)):

1. Derives `exam_track`: `"technical"` if `student_profile["exam_type"]` ∈
   `["jee", "gate", "neet"]` (lowercased), else `"conceptual"`
   ([turn_handler.py:18-20](app/services/turn_handler.py#L18)).
2. Uses a **hardcoded mock LLM dict** (`is_confident=0.55`, a `tft_display` of
   `{"kind":"latex","content":"x = 2"}`, etc.) — no real model call.
3. Calls `validate_response(llm_response, exam_track)`.
4. If the verdict is `escalate` (confidence < 0.60), it fakes an escalation (bumps
   confidence to 0.9, prepends "I double checked this.") and re-validates.
5. Returns `final_response`. The TFT formatter + TTS are described as "triggered
   downstream" only in comments.

### `services/validator.py` — prototype output validator

`validate_response(response, exam_track)`
([validator.py:31](app/services/validator.py#L31)) runs six checks:

1. **Confidence gate** — `is_confident < 0.60` → `{"action": "escalate"}`.
2. **Track mismatch** — conceptual + `kind=="latex"` → demote to text, strip `$`/`\`
   (the inline `route_track`).
3. **Voice symbol scrub** — `clean_voice()` removes `\`, `$`, `**`, `#`, `_`, `$$`.
4. **Voice length** — `count_sentences() > 4` → `trim_to_sentences(..., 4)`
   (split on `.`).
5. **TFT text length** — text card `content` truncated to **200 chars**.
6. **LaTeX validity** — technical + `kind=="latex"` runs `is_valid_latex()` (a
   brace-balance stack check); if invalid, demote to text and strip `$`/`\`.

These constants (0.60 confidence, 4 sentences, 200 chars, balanced-brace check) are
the prototype's analogues of the production thresholds in §7/§15.

---

## 7. Schemas — `schemas/llm_response.py` (the live TFT contract)

This is the **production** per-turn LLM contract — the single JSON object every
provider must emit, and the schema that actually shapes what the lamp says and shows.
File header: "Layer 5.2 of BACKEND_TODO.md … matches the contract enforced by the
system prompts in `app/prompts/turn{1,2}_system.py`"
([llm_response.py:1-11](app/schemas/llm_response.py#L1)).

> **Updated 2026-07-03:** the reply grew from three lamp channels to **five surfaces**
> (added `graph` and `structures`) plus three new field groups (`is_mcq`; the
> `RICH_ANALYTICS_ENABLED`-gated `topic`/`concepts`/`error_type`; and the seven
> `MATH_VERIFY_ENABLED`-gated hidden verifier fields). `LlmReply` now has **29 fields**
> ([llm_response.py:125-431](app/schemas/llm_response.py#L125)). There is deliberately
> **no "verdict" field** — the closest analytics are `error_type` /
> `verification_summary`.

### Module-level constants

- **`MAX_EQUATIONS = 3`** ([llm_response.py:26](app/schemas/llm_response.py#L26)) —
  hard cap on `latex_equations`. Doubles as Gemini's `response_schema` `maxItems`
  (so the constrained decoder can't overshoot) and the tolerant validator's trim cap.
- **`MAX_STRUCTURES = 4`** ([llm_response.py:27](app/schemas/llm_response.py#L27)) —
  hard cap on the new `structures` chemistry channel.

### Helper sub-models (new channels)

- **`GraphCurve`** ([llm_response.py:73-83](app/schemas/llm_response.py#L73)) — one curve:
  `expr` (required), `y_expr` (parametric only), `label`. The model emits a FORMULA, not data.
- **`GraphSpec`** ([llm_response.py:86-105](app/schemas/llm_response.py#L86)) — a structured plot
  spec: `kind ∈ {function, parametric, implicit}` (default `function`), `curves` (max 4),
  `x_range` (default `[-10,10]`), optional `y_range`/`title`/`xlabel`/`ylabel`. Rendered by
  `graph_renderer` (doc 06 §6.3).
- **`ChemStructure`** ([llm_response.py:108-122](app/schemas/llm_response.py#L108)) — a 2D
  molecular structure: `smiles` (required; reaction SMILES `A.B>>C.D` allowed), `caption`
  (≤30 chars). Rendered by `rdkit_renderer` (doc 06 §6.4).
- **`_QUERY_TYPES`** = `{concept, calc, formula, derivation, definition, check,
  mistake_id, other}` ([llm_response.py:29](app/schemas/llm_response.py#L29)).
- **`_SUBJECTS`** = `{math, physics, chemistry, biology, cs, language, history,
  other}` ([llm_response.py:31](app/schemas/llm_response.py#L31)).
- **`_DIFFICULTIES`** = `{easy, medium, hard}` ([llm_response.py:33](app/schemas/llm_response.py#L33)).

These three sets are used by the tolerant pre-validator to coerce out-of-spec enum
values to defaults instead of rejecting the whole reply.

### `Display` model ([llm_response.py:36-68](app/schemas/llm_response.py#L36))

The **text card** on the TFT.

| Field | Type | Default | Notes |
|---|---|---|---|
| `kind` | `Literal["text","none"]` | (required) | `text` → show prose card; `none` → no card (speech is caption). **There is NO `"latex"` kind** — all equations live in the top-level `latex_equations[]`. |
| `content` | `str` | `""` | Prose for the card. ≤ 100 words (lamp truncates mid-word). **No math notation** — printed verbatim. References equations as `"eq1"/"eq2"/"eq3"` (lowercase, 1-indexed). Must COMPLEMENT speech, never repeat it. |

This is the schema-level replacement for the prototype's track router: instead of
flattening LaTeX in the display card, the card is forbidden to contain math at all.

### `LlmReply` model ([llm_response.py:71-252](app/schemas/llm_response.py#L71))

The single JSON object per turn. `model_config = ConfigDict(extra="ignore")` — extra
keys are dropped rather than raising (Gemini sometimes emits unsolicited keys; a
rogue field must not nuke the whole response).

**Five independent output surfaces** (was three; `graph` + `structures` are new):

| Field | Type | Default | Drives | Notes |
|---|---|---|---|---|
| `speech` | `str` | (required) | TTS | Words only, no LaTeX/symbols/markdown; soft cap 2-3 sentences (~50 words). |
| `display` | `Display` | (required) | TFT text card | Prose, may ref eq1/eq2/eq3, or `kind="none"`. |
| `latex_equations` | `list[str]` | `[]` | TFT LaTeX region | `max_length=MAX_EQUATIONS` (3); each entry = one renderable equation (no `\\` breaks); referenced from `display.content` as `eqN`. |
| `graph` | `GraphSpec \| None` | `None` | TFT graph page (JPEG, interactive) | **NEW** ([:171-178](app/schemas/llm_response.py#L171)). Gated `GRAPH_ENABLED`; rendered by `graph_renderer`. |
| `structures` | `list[ChemStructure]` | `[]` | TFT chemistry page (JPEG, L/R nav) | **NEW** ([:179-192](app/schemas/llm_response.py#L179)). `max_length=MAX_STRUCTURES` (4); gated `CHEM_STRUCTURE_ENABLED`; rendered by `rdkit_renderer`. |

**Analytics fields (stored in Postgres `turns`, do NOT affect lamp UX):**

| Field | Type | Default | Validation |
|---|---|---|---|
| `confidence` | `float` | `0.8` | `ge=0.0, le=1.0`. 0.45-0.7 → state what's sure + one clarifying question; below 0.45 → system escalates. |
| `query_type` | `Literal[...8...]` | `"other"` | enum from `_QUERY_TYPES` |
| `subject` | `Literal[...8...]` | `"other"` | enum from `_SUBJECTS` |
| `difficulty` | `Literal["easy","medium","hard"]` | `"medium"` | |

**Conversation-memory / orchestration fields (never spoken or shown):**

| Field | Type | Default | Purpose |
|---|---|---|---|
| `user_input` | `str` | `""` | ≤ 15-word restatement of the student's ask, fed into next turn's history. |
| `problem_statement` | `str` | `""` | Self-contained transcription of the problem (givens, ask, constraints, LaTeX). Filled on escalation or low confidence so a stronger model can re-take from the text. |
| `image_needed` | `bool` | `True` | `False` only when `problem_statement` fully captures the image; decides whether the raw image is forwarded on escalation. |
| `solution_outline` | `str` | `""` | Terse numbered full solution ≤ 80 words; INTERNAL only; grounds later tier-1 nudges (the "answer key"). |
| `same_problem` | `bool` | `True` | Whether this turn is the same problem as recent turns; drives flushing the stale answer key + marking history (anti context-bleed). A different *part* of the same question stays true. |
| `student_stuck` | `bool` | `False` | True only on frustration / no progress; gates revealing the full solution. |
| `student_disputes_prior` | `bool` | `False` | True only when the student challenges a PRIOR tutor answer; triggers fresh Pro re-derivation. |
| `is_mcq` | `bool` | `False` | **NEW** ([:305-315](app/schemas/llm_response.py#L305)) — this turn is multiple-choice; drives the MCQ option-completeness guard. |

**Rich-analytics fields (gated by `RICH_ANALYTICS_ENABLED`; stored in `turns`, never spoken/shown):** — new group ([:317-349](app/schemas/llm_response.py#L317)). Emitted only when the analytics prompt block + schema slot are on.

| Field | Type | Default | Purpose |
|---|---|---|---|
| `topic` | `str` | `""` | fine-grained syllabus topic (1-4 words) |
| `concepts` | `list[str]` | `[]` | laws/formulas tested (`max_length=4`) |
| `error_type` | `str` | `""` | mistake kind on check/mistake turns |

**Hidden answer-verifier fields (gated by `MATH_VERIFY_ENABLED` + `verify=True`; all INTERNAL):** — consumed by `math_verifier` (doc 11). The `response_schema` twin strips them when off → zero extra tokens. **`MATH_VERIFY_ENABLED` now defaults `True` (2026-07-06)**, so these fields ship on quantitative turns by default. As of 2026-07-06 this group is placed **first** in `LlmReply` (before `speech`/`display`) so Gemini's constrained decoder derives — equation/givens/verification — before it declares `final_answer` and phrases the spoken answer: a zero-token chain-of-thought scaffold (`improvment/08` §10.5, doc 13).

| Field | Type | Default | Purpose |
|---|---|---|---|
| `equation` | `str` | `""` | base relation (numeric or balanced reaction), unknown on the left |
| `given` | `list[GivenItem]` | `[]` | Numeric givens as a **list** of `{name, value}` pairs (angles in radians). **Changed 2026-07-11 from an open `{name: value}` dict** (`GivenItem` is a fixed `{name: str, value: float}` sub-model): an untyped dict compiles to a JSON schema with `additionalProperties`, which the **Gemini Developer API rejects** ("additionalProperties is not supported"), crashing every quantitative lamp turn the moment `MATH_VERIFY_ENABLED` put `given` in the `response_schema` (the "Tutor unavailable" bug, `591ca0b`). The module helper `givens_to_dict()` normalizes the list (or a legacy dict) back to a plain `{name: value}` for `math_verifier` (doc 11); `_coerce_tolerant` coerces each `value` to `float` and drops non-numeric givens. |
| `unknown` | `str` | `""` | symbol solved for |
| `final_answer` | `str` | `""` | exact-form answer value the verifier compares against |
| `answer_units` | `str` | `""` | units of `final_answer` |
| `method_tag` | `str` | `""` | problem-class tag (e.g. projectile, stoichiometry) |
| `verification_summary` | `str` | `""` | one line on how the answer was checked |

**Visual-grounding audit fields (never spoken or shown):**

| Field | Type | Default | Validation |
|---|---|---|---|
| `ocr_text` | `str` | `""` | Short TARGET LABEL (< 5 words) of the region answered (e.g. "Question 8"). |
| `bounding_box` | `list[int] | None` | `None` | `max_length=4`; `[ymin,xmin,ymax,xmax]`, each 0-1000 normalized. |

### `_coerce_tolerant` — the tolerant pre-validator

`@model_validator(mode="before")` ([llm_response.py:254-393](app/schemas/llm_response.py#L254)).
This is the most important algorithm in the schema layer: it **sanitises a
semantically-off-but-structurally-valid reply BEFORE field validation** so a single
bad *analytics* field never discards the user-facing speech/display (which would force
the generic fallback). Every repair logs a WARN — "silent coercion hides prompt
drift".

Step by step (input is the raw provider dict `data`):

1. **Non-dict guard.** If `data` isn't a dict, return it unchanged
   ([:270](app/schemas/llm_response.py#L270)). Copy to `d = dict(data)`.
2. **`confidence` clamp** ([:283-292](app/schemas/llm_response.py#L283)):
   - `float(c_raw)`; on `TypeError/ValueError` → `0.8` + WARN (explicitly noting
     0.8 *suppresses* escalation since `0.8 > GEMINI_ESCALATE_CONFIDENCE`).
   - If outside `[0,1]` → WARN.
   - Final: `d["confidence"] = min(1.0, max(0.0, c))`.
3. **`latex_equations` clean** ([:298-315](app/schemas/llm_response.py#L298)):
   - If a list: keep only non-empty strings (`isinstance(e,str) and e.strip()`).
   - WARN if any dropped; WARN if `> MAX_EQUATIONS` (note: the comment in
     `_coerce_tolerant`'s docstring says "cap at 8" but the **actual code caps at
     `MAX_EQUATIONS` = 3** — `clean[:MAX_EQUATIONS]`). Dropping an eqN dangles any
     `eqN` reference in `display.content`, hence the loud log.
   - If not a list and not `None` → WARN; set `[]`.
4. **Enum coercion** ([:318-327](app/schemas/llm_response.py#L318)): for
   `(query_type→_QUERY_TYPES→"other")`, `(subject→_SUBJECTS→"other")`,
   `(difficulty→_DIFFICULTIES→"medium")`: if the value isn't in the valid set, set
   the default; WARN only if the key was present-but-wrong (missing keys stay silent).
5. **`speech` stringify** ([:330-335](app/schemas/llm_response.py#L330)): coerce to
   `str`; `None` → `""`; WARN if it was a non-None non-str.
6. **`user_input` cap** ([:339-340](app/schemas/llm_response.py#L339)): coerce to str,
   hard-cap **`[:200]`**.
7. **`ocr_text` cap** ([:346-347](app/schemas/llm_response.py#L346)): coerce to str,
   hard-cap **`[:80]`** (it's a label, not a transcription).
8. **`bounding_box` validation** ([:352-363](app/schemas/llm_response.py#L352)):
   must be list/tuple of length 4; each value → `max(0, min(1000, int(round(float(v)))))`;
   require `ymin<ymax` (`vals[0]<vals[2]`) and `xmin<xmax` (`vals[1]<vals[3]`), else
   `None`. WARN if a non-None box was rejected.
9. **`display` re-boxing** ([:371-391](app/schemas/llm_response.py#L371)):
   - If it's a `Display` instance (the canned fallbacks pass these), `model_dump()`
     it to a dict first — **this unwrap fixes a real bug** where canned replies were
     being blanked to `kind="none"`.
   - If still not a dict → `{"kind":"none","content":""}` (WARN: BLANKS the card).
   - Else validate `kind` ∈ `{text,none}` (else `"none"` + WARN); stringify
     `content` (WARN if non-str).
10. Return `d`.

### Canned fallback replies

Pre-built `LlmReply` instances for failure modes — the lamp still SAYS/SHOWS
something so the round-trip is visible:

| Constant / function | `status` keyed | speech / display content |
|---|---|---|
| `FALLBACK_REPLY` ([:399](app/schemas/llm_response.py#L399)) | generic | "Sorry, I had trouble answering that…" / `none` |
| `_UPSTREAM_UNAVAILABLE_REPLY` ([:412](app/schemas/llm_response.py#L412)) | `upstream_unavailable` | "Gemini servers are busy…" / "LLM busy — try again in a moment" |
| `_RATE_LIMITED_REPLY` ([:421](app/schemas/llm_response.py#L421)) | `rate_limited` | "hit my per-minute rate limit…" / "Rate limit — wait ~1 min" |
| `_TIMEOUT_REPLY` ([:430](app/schemas/llm_response.py#L430)) | `timeout` | "model took too long…" / "LLM timeout — try again" |
| `_TRUNCATED_REPLY` ([:439](app/schemas/llm_response.py#L439)) | `truncated` | "longer than I can fit…" / "Reply too long — ask for a shorter answer" |

- **`retake_image_reply(detail=None)`** ([:450-461](app/schemas/llm_response.py#L450)) —
  a no-LLM reply from the deterministic image-quality gate; `status="ok"` (it's helpful
  guidance, not an error), `confidence=1.0`, zero LLM tokens.
- **`fallback_for_status(status)`** ([:694-709](app/schemas/llm_response.py#L694)) —
  maps a provider telemetry `status` string to the matching canned reply (specific
  message > generic), defaulting to `FALLBACK_REPLY`.

### The `response_schema` twin — feature-gated structured output

**`llm_reply_schema(*, graph=True, analytics=True, verify=False, structure=False)`**
([llm_response.py:644-671](app/schemas/llm_response.py#L644), `@lru_cache(maxsize=8)`)
builds the Gemini `response_schema` twin of `LlmReply` for the current feature flags. It
computes a `drop` list — `graph` when graph off, the three `_RICH_ANALYTICS_FIELDS`
(`topic`/`concepts`/`error_type`) when analytics off, the seven `_VERIFIER_FIELDS`
(`equation`/`given`/`unknown`/`final_answer`/`answer_units`/`method_tag`/`verification_summary`)
when verify off, and `structures` when structure off — then `create_model(...)`s a subclass
with those fields popped. **Key invariant:** parsing always uses the full `LlmReply`, so a
stripped field just resolves to its default; nothing downstream changes, and gated fields cost
zero tokens when off. `llm_reply_schema_no_graph()` ([:674-677](app/schemas/llm_response.py#L674))
is a back-compat shim (graph/analytics/verify all off).

---

## 8. Schemas — `schemas/auth.py`

Auth + pairing request/response contracts (IMPLEMENTATION_AUTH_PAIRING.md §6.1),
shared by firmware, frontend, and backend validation
([auth.py:1-10](app/schemas/auth.py#L1)).

### Lamp-facing

**`DeviceRegisterIn`** ([auth.py:21](app/schemas/auth.py#L21))
- `device_id: str` — `Field(min_length=4, max_length=64)`
- `device_secret: str` — `Field(min_length=8, max_length=256)`

**`DeviceRegisterOut`** ([auth.py:26-44](app/schemas/auth.py#L26)) — two shapes
discriminated by `status`:
- `status: Literal["pending","already_paired"] = "pending"` (default keeps older
  firmware on the pending path).
- `pairing_code: str|None`, `pairing_url: str|None`, `expires_in: int|None`,
  `device_jwt: str|None` — QR fields populated on `pending`; `device_jwt` minted on
  `already_paired` (lamp lost its JWT, recovers without re-scanning).

**`DevicePollIn`** ([auth.py:47](app/schemas/auth.py#L47))
- `device_id: str`, `device_secret: str`
- `pairing_code: str` — `Field(min_length=6, max_length=8)`

**`DevicePollOut`** ([auth.py:53-58](app/schemas/auth.py#L53)) — `model_config =
ConfigDict(extra="forbid")` (strict); three discriminated shapes:
- `status: Literal["pending","paired","expired"]`
- `device_jwt: str|None` — present only on `paired`.

### Frontend-facing

| Model | Fields |
|---|---|
| `PairingInfoOut` ([:63](app/schemas/auth.py#L63)) | `device_id: str`, `friendly_name: str`, `expires_at: datetime` |
| `CompletePairingIn` ([:69](app/schemas/auth.py#L69)) | `pairing_code: str` (`min_length=6, max_length=8`) |
| `CompletePairingOut` ([:73](app/schemas/auth.py#L73)) | `device_id`, `friendly_name` |
| `DeviceListItem` ([:78](app/schemas/auth.py#L78)) | `device_id`, `friendly_name`, `paired_at: datetime|None`, `last_seen_at: datetime|None`, `online: bool` |
| `DeviceListOut` ([:86](app/schemas/auth.py#L86)) | `devices: list[DeviceListItem]` |
| `DeviceRenameIn` ([:90](app/schemas/auth.py#L90)) | `friendly_name: str` (`min_length=1, max_length=60`) |
| `DeviceRenameOut` ([:94](app/schemas/auth.py#L94)) | `device_id`, `friendly_name` |

### Error envelope

**`ApiError`** ([auth.py:101-104](app/schemas/auth.py#L101)) — the shape every 4xx/5xx
follows: `error: str`, `code: str`. (Routes emit this as the `detail` dict, e.g.
`{"error":"admin access required","code":"NOT_ADMIN"}`.)

---

## 9. Schemas — `schemas/frontend.py`

The web app's identity + profile + analytics surface. Every consuming route is gated
on a verified Clerk session ([frontend.py:1-8](app/schemas/frontend.py#L1)).

- **`TargetExam = Literal["JEE","NEET","CAT","UPSC"]`**
  ([frontend.py:18](app/schemas/frontend.py#L18)) — kept in lockstep with the
  frontend's `TARGET_EXAMS`.

**`MeOut`** ([frontend.py:21-29](app/schemas/frontend.py#L21)) — identity probe:
`user_id`, `email: str|None`, `has_profile: bool`, `onboarding_complete: bool`,
`is_admin: bool = False` (lets the frontend show the Admin nav without a second
round-trip).

**`ProfileIn`** ([frontend.py:32-57](app/schemas/frontend.py#L32)) — onboarding
upsert body; `model_config = ConfigDict(extra="ignore")`:
- `full_name: str` (`min_length=2, max_length=120`)
- `email: str|None` (`max_length=254`) — persisted into `user_profiles.extra` (Clerk
  session JWTs don't carry email).
- `phone: str|None` (`max_length=32`) — optional.
- `target_exam: TargetExam` (required)
- `prep_duration: str` (`min_length=1, max_length=60`)
- Learning-profile optionals (all `str|None`, go into `extra` JSONB):
  `learning_style`(120), `explain_depth`(60), `study_rhythm`(60), `focus_subject`(60),
  `strong_subject`(80), `weak_subject`(80).

**`ProfileOut`** ([frontend.py:60-77](app/schemas/frontend.py#L60)) — durable
profile read shape (Supabase `user_profiles`): `user_id`, `full_name`, `email|None`,
`phone|None`, `target_exam: TargetExam|None`, `prep_duration|None`, the learning
fields surfaced flat from `extra`, `onboarding_complete: bool`, `updated_at|None`.

**`DeviceSummary`** ([frontend.py:80](app/schemas/frontend.py#L80)) — `device_id`,
`friendly_name`, `online: bool`.

### Rich analytics shapes

**`DailyPoint`** ([frontend.py:87-91](app/schemas/frontend.py#L87)) — `label`
(`YYYY-MM-DD`), `turns: int = 0`, `avg_ms: int = 0`.

**`RecentTurn`** ([frontend.py:94-103](app/schemas/frontend.py#L94)) — `asked_at`,
`subject|None`, `difficulty|None`, `query_type|None`, `question|None`
(turns.transcript), `answer: str = ""` (turns.speech, trimmed), `total_ms|None`,
`status: str = "ok"`.

**`AnalyticsDetailOut`** ([frontend.py:106-129](app/schemas/frontend.py#L106)) —
everything the `/analytics` page renders, all fields degrade to empty/zero:
`range_days=14`, headline totals (`turns`, `sessions`, `devices`, `online_devices`,
`turns_last_7d`, `avg_total_ms`, `p50_ms`, `p95_ms`, `avg_confidence`,
`total_cost_usd`, `escalated_pct`, `last_active_at|None`), series + distributions
(`daily: list[DailyPoint]`, `subject_mix/difficulty_mix/query_type_mix/status_mix:
dict[str,int]`, `recent: list[RecentTurn]`).

**`AnalyticsOut`** ([frontend.py:132-144](app/schemas/frontend.py#L132)) — the
dashboard rollup: `device_count`, `online_devices`, `total_turns`, `turns_last_7d`,
`sessions_count`, `last_active_at|None`, `subject_mix: dict[str,int]`,
`devices: list[DeviceSummary]`. Tolerant of an empty/absent `turns` table (zeros).

---

## 10. Schemas — `schemas/model_eval.py`

Response models for the multi-LLM evaluation surface (`/api/frontend/models`,
`/solve`, `/solve/compare`). Kept separate from `frontend.py` so identity schemas
stay free of provider imports. **The answer body reuses
`app.providers.gemini_brain.SimResponse`** so every model returns one uniform shape
([model_eval.py:1-16](app/schemas/model_eval.py#L1)).

### The reused answer shape: `SimResponse` / `Display`

From `gemini_brain.py` ([gemini_brain.py:311-413](app/providers/gemini_brain.py#L311)):

**`Display`** — `type: Literal["latex","text","none"]` (note: **still has the
`"latex"` kind** here, unlike the lamp's `LlmReply.Display`), `latex: str = ""`
(no surrounding `$`/`\[ \]`), `text: str = ""`.

**`SimResponse`** — `speech: str`, `display: Display`, plus the **identical analytics
+ memo + grounding contract** as `LlmReply` (`confidence` `ge=0,le=1` default 0.8,
`query_type`/`subject`/`difficulty` same enums, `user_input`, `problem_statement`,
`solution_outline`, `same_problem`, `student_stuck`, `student_disputes_prior`,
`image_needed`, `ocr_text`, `bounding_box` `max_length=4`). This parity is what lets a
single `turns` schema/analytics/L3-memory cover both the lamp and the browser bench,
and `confidence` drives the web's tiered escalation in `frontend_manager`.

### Catalog / dropdown shapes

**`ModelInfo`** ([model_eval.py:19-30](app/schemas/model_eval.py#L19)) — one dropdown
row: `id`, `label`, `provider`, `available: bool` (provider key configured),
`vision: bool`, `audio: bool`, `input_per_mtok: float`, `output_per_mtok: float`,
`note: str = ""`, `is_default: bool = False`.

**`ModelsOut`** ([model_eval.py:33](app/schemas/model_eval.py#L33)) —
`models: list[ModelInfo]`, `default_model: str`.

### Per-step / telemetry shapes

**`AutoStep`** ([model_eval.py:38-53](app/schemas/model_eval.py#L38)) — one LLM call
inside AUTO mode; `model_config = ConfigDict(protected_namespaces=())` (so `model`
field doesn't collide with pydantic's protected `model_` namespace):
`tier: int`, `model: str`, `role: str` (`"first-pass"|"escalation"|"keyed-nudge"|
"bleed-guard"|"reveal-guard"|"focus-guard"` — and at runtime also `"dispute-rederive"`,
emitted by `_solve_auto`), `reason: str`, `latency_ms: int`,
`input_tokens|thinking_tokens|output_tokens: int|None`, `estimated_cost: float|None`,
`confidence: float|None`.

**`SolveMeta`** ([model_eval.py:56-82](app/schemas/model_eval.py#L56)) — per-invocation
telemetry; `protected_namespaces=()`: `model_id`, `label`, `provider`, `status`
(`"ok"|"not_configured"|"timeout"|"busy"|"error"`), `latency_ms`,
`input/output/total_tokens: int|None`, `estimated_cost: float|None`, `error: str|None`,
`response_id: str|None` (the `model_responses.response_id` to attach feedback to;
`None` when persistence off). AUTO-only fields: `steps: list[AutoStep]|None`,
`escalated: bool = False`, `final_tier: int = 1`, `memo_active: bool = False`.

### Feedback + result shapes

| Model | Fields |
|---|---|
| `FeedbackIn` ([:84](app/schemas/model_eval.py#L84)) | `response_id: str`, `thumbs: Literal["up","down"]|None`, `rating: int|None` (`ge=1, le=5`), `feedback_text: str|None` (`max_length=2000`) |
| `FeedbackOut` ([:94](app/schemas/model_eval.py#L94)) | `ok: bool` |
| `SolveOut` ([:98](app/schemas/model_eval.py#L98)) | `response: SimResponse`, `meta: SolveMeta` |
| `CompareOut` ([:104](app/schemas/model_eval.py#L104)) | `results: list[SolveOut]` (request order preserved) |

---

## 11. Schemas — `schemas/admin.py`

Response models for the admin surface (`/api/frontend/admin/*`), mirroring
`services/admin.py`'s query outputs and backing the Next.js `/admin` dashboard
(`lib/admin.ts`). **Design contract** ([admin.py:1-10](app/schemas/admin.py#L1)):
every list endpoint wraps rows in a `{rows: [...]}` envelope (so pagination/meta can
be added later without breaking the wire), and **all fields are optional/defaulted**
so a not-yet-migrated table renders empty rather than 500-ing.

> **New admin schemas since 2026-07-03** ([admin.py](app/schemas/admin.py), +77 lines):
> `AdminPerfStage`/`AdminPerfOut` (per-stage latency + time-to-first-audio, for
> `GET /admin/performance`); `AdminOtaRelease`/`AdminOtaReleasesOut`/`AdminOtaReleaseOut`
> (firmware release metadata, for the OTA console — doc 12 §3.3); `TimelineStep` (client/server
> step timings). `AdminUserRow` gained a `cohort` field (pilot batch tag), and `AdminTurnRow` +
> `AdminTurnTraceOut` gained the §13 behavioural/curriculum analytics twins
> (`topic`/`error_type`/`is_mcq`/`student_stuck`/`same_problem`/`student_disputes_prior`/`image_needed`/`concepts`/`problem_statement`)
> plus Claude-fallback fields (`fallback`/`fallback_from`). The multi-LLM eval block
> (`ModelStatRow`/`ModelEvalTotals`/`AdminModelsOut`) backs the now-mounted `GET /admin/models`.
>
> **New Analytics-tab schemas (2026-07-09 → 07-11)** ([admin.py](app/schemas/admin.py), +82 lines) — back the range-aware admin "Analytics" tab (§13, §14):
> **`AdminAnalyticsSummaryOut`** (`range`, `n_questions`, `n_generation`, `avg/p95_generation_ms`, `avg/p95_total_ms`, `stages: list[AdminPerfStage]`, `escalation`) — aggregate over the window; **`AdminEscalationBreakdown`** + **`AdminEscalationTier`** (`{n, avg_ms}`) — the tier funnel where every ok lamp turn lands in exactly one of `tier1` / `tier2_direct` / `tier2_esc` / `tier3_direct` / `tier3_esc`; **`AdminAnalyticsQuestionRow`** + **`AdminAnalyticsQuestionsOut`** — one row per turn (`generation_ms`, `latex_ms`, `graph_ms`, `tts_ms`, `total_ms`, `final_tier`, `difficulty` = question level, `escalated`, `status` + short `reason`, stable `trace_id` since `turn_id` is null on failures); and **`AdminAnalyticsPoint`** + **`AdminAnalyticsTimeseriesOut`** (`bucket: "hour"|"day"`) for the trend chart.

### Overview building blocks

**`HealthSnapshot`** ([admin.py:19-31](app/schemas/admin.py#L19)) — all `int = 0`:
`users_onboarded`, `devices_total`, `devices_paired`, `devices_revoked`,
`online_devices`, `pairing_codes_live`, `sessions_total`, `turns_total`,
`turns_failed`, `memories_total`, `events_total`, `admins_total`.

**`CostSummary`** ([admin.py:34-39](app/schemas/admin.py#L34)) — `total_usd: float`,
`turns_costed: int`, `input_tok`, `output_tok`, `thinking_tok`.

**`DailyPoint`** ([admin.py:42-45](app/schemas/admin.py#L42)) — `label: str`,
`turns: int`, `avg_ms: int`.

**`AdminOverviewOut`** ([admin.py:48-58](app/schemas/admin.py#L48)) — `range_days=14`,
`health: HealthSnapshot`, `cost: CostSummary`, `daily: list[DailyPoint]`,
and five distribution dicts (`subject_mix`, `difficulty_mix`, `query_type_mix`,
`status_mix`, `tier_mix`) + `event_counts: dict[str,int]`.

### List-row models

**`AdminUserRow`** ([admin.py:61-73](app/schemas/admin.py#L61)) — `user_id` (required)
plus `full_name`, `email`, `phone|None`, `target_exam|None`, `prep_duration|None`,
`onboarding_complete: bool`, `created_at|None`, `device_count`, `turn_count`,
`cost_usd: float`, `last_active|None`.

**`AdminDeviceRow`** ([admin.py:76-85](app/schemas/admin.py#L76)) — `device_id`,
`friendly_name`, `user_id|None`, `owner_name`, `paired_at|None`, `last_seen_at|None`,
`revoked_at|None`, `is_paired: bool`, `online: bool`.

**`AdminSessionRow`** ([admin.py:88-98](app/schemas/admin.py#L88)) — `id`, `device_id`,
`user_id|None`, `owner_name`, `started_at|None`, `last_activity_at|None`,
`ended_at|None`, `turn_count`, `primary_subject|None`, `has_summary: bool`.

**`TimelineStep`** ([admin.py:101-107](app/schemas/admin.py#L101)) — one step in the
per-turn "Time journey" waterfall (mirrors `lib/models.ts`): `step: str` (`prepare|
auth|upload|stt|model|parse|render`), `ms: int`, `where: str = "server"`
(`"client"|"server"`; lamp turns are server-only).

**`AdminTurnRow`** ([admin.py:110-142](app/schemas/admin.py#L110)) — `id` (required) +
`asked_at|None`, `user_id|None`, `device_id`, `owner_name`, `status: str = "ok"`,
`subject|None`, `difficulty|None`, `query_type|None`, `confidence: float|None`,
`user_said|None`, `lamp_replied|None`, `total_ms|None`, `llm_provider|None`,
`llm_model|None`, `final_tier|None`, `escalated: bool`, `cost_usd|None`, `source|None`,
plus per-turn cost/usage detail (`input_tokens|None`, `output_tokens|None`,
`api_calls|None` = LLM calls this turn, `timeline: list[TimelineStep]|None`), plus the
Claude timeout-fallback fields (`fallback: bool|None` = True when a Gemini server
failure rerouted to Claude; `fallback_from: str|None` = the tier that failed).

### Trace models

**`TurnTracePhase`** ([admin.py:145-150](app/schemas/admin.py#L145)) — one storyboard
entry: `phase: str`, `ms: int|None`, `status: str = "ok"` (`ok|error|skipped`),
`detail: str`.

**`AdminTurnTraceOut`** ([admin.py:153-211](app/schemas/admin.py#L153)) — full
pipeline audit for ONE turn (`GET /api/frontend/admin/turns/{id}/trace`); everything
optional/defaulted so a partially-recorded trace renders with gaps:
- IDs/meta: `trace_id`, `turn_id|None`, `device_id`, `user_id|None`, `session_id|None`,
  `source: str = "lamp"` (`"lamp"|"simulator"`), `status: str = "ok"`,
  `error_detail|None`, `created_at|None`.
- Phase latencies (all `int|None`; `None` = phase didn't run): `capture_latency_ms`,
  `image_enhance_ms`, `stt_latency_ms`, `tier1/tier2/tier3_latency_ms`,
  `tts_latency_ms`, `latex_latency_ms`, `processing_latency_ms`.
- Media URLs: `raw_audio_url`, `raw_image_url`, `enhanced_image_url` (all `str|None`).
- Text artifacts: `whisper_transcript`, `llm_raw_prompt_brief`, `llm_raw_response`,
  `escalation_reason`, `llm_raw_system_prompt`.
- Visual grounding: `extracted_ocr_text|None`, `bounding_box: list[int]|None`.
- Verdict: `final_tier: int = 1`, `escalated: bool`, `confidence|None`,
  `phases: list[TurnTracePhase]`, `extra: dict[str,Any]`.
- Joined `turns` fields: `turn_transcript|None`, `turn_speech|None`,
  `turn_display_content|None`, `turn_latex_equations: list[str]`, `turn_status|None`,
  `turn_model|None`, `turn_cost_usd|None`, `turn_input_tokens|None`,
  `turn_output_tokens|None`.

### Media models

**`AdminMediaOut`** ([admin.py:214-224](app/schemas/admin.py#L214)) — `backend: str =
"off"`, `bucket|None`, `turns_with_media: int`, `traces_with_media: int`,
`storage_objects: int|None`, `storage_bytes: int|None`, `oldest_media_at|None`.

**`MediaCleanupIn`** ([admin.py:227-230](app/schemas/admin.py#L227)) — `days: int =
Field(default=14, ge=1, le=365)` (the ONLY deletion path; no auto-delete).

**`MediaCleanupOut`** ([admin.py:233-241](app/schemas/admin.py#L233)) — `ok: bool =
True`, `error|None`, `turns_cleared`, `traces_cleared`, `objects_deleted`,
`remaining_turns`, `remaining_traces` (rows still past the cutoff → "click again").

### Event + list-envelope models

**`AdminEventRow`** ([admin.py:244-249](app/schemas/admin.py#L244)) — `occurred_at|None`,
`device_id`, `user_id|None`, `kind`, `payload: dict[str,Any]`.

Envelopes ([admin.py:252-269](app/schemas/admin.py#L252)): `AdminUsersOut`,
`AdminDevicesOut`, `AdminSessionsOut`, `AdminTurnsOut`, `AdminEventsOut` — each
`{rows: list[...]}`.

### Multi-LLM eval models (mirror `lib/admin.ts AdminModels`)

Sourced from the bench tables (`model_requests/model_responses/model_feedback/
model_providers`), NOT the lamp's `turns` ([admin.py:272-329](app/schemas/admin.py#L272)):

**`ModelStatRow`** — `model_name`, `label`, `provider`, `active: bool`, `responses`,
`ok_count`, `fail_count`, `timeout_count`, `error_count`, `not_configured_count`,
`success_rate: float` (0-100), `avg_latency_ms`, `avg_cost`, `total_cost`,
`avg_input_tok`, `avg_output_tok`, `total_tok`, `feedback_count`, `rating_count`,
`avg_rating: float` (1-5, 0 when none), `thumbs_up`, `thumbs_down`.

**`ModelEvalDailyPoint`** — `label`, `responses`, `avg_ms`.
**`ModelEvalTotals`** — `requests`, `compare_groups`, `responses`, `ok`, `fail`,
`total_cost`, `feedback`, `models_used`.
**`ModelOption`** — `model_name`, `label`.
**`AdminModelsOut`** — `range_days=14`, `totals: ModelEvalTotals`,
`models: list[ModelStatRow]`, `daily: list[ModelEvalDailyPoint]`,
`available_models: list[ModelOption]`.

---

## 12. `schemas/__init__.py`

The package init is **empty (0 bytes)**. There are no re-exports; consumers import
from the concrete modules (`from app.schemas.admin import ...`).

---

## 13. `services/admin.py` — system-wide read service

The SYSTEM-WIDE read surface ([admin.py:1-25](app/services/admin.py#L1)). Two
responsibilities: (1) `is_admin()` resolution, (2) read-only system-wide rollups.

### Resilience pattern: savepoint-guarded executors

Every aggregation runs inside a SAVEPOINT (`begin_nested`) so a not-yet-migrated table
or any failing query degrades to empty/zero WITHOUT poisoning the surrounding request
transaction ([admin.py:15-20](app/services/admin.py#L15)).

- **`_rows(db, sql, params)`** ([admin.py:52-62](app/services/admin.py#L52)) — runs a
  SELECT in `async with db.begin_nested()`, returns `[dict(m) for m in
  res.mappings().all()]`, or `[]` on any exception (logs at INFO with the first SQL
  line truncated to 80 chars).
- **`_scalar(db, sql, params, default=0)`** ([admin.py:65-71](app/services/admin.py#L65)) —
  same guard, returns `.scalar()` or `default` (no log on failure).

### Constants

- **`_ONLINE_WINDOW_SEC = 60`** ([admin.py:42](app/services/admin.py#L42)) — a device
  is "online" if `last_seen_at` is within the last 60 seconds.
- **`_ANALYTICS_TTL_S = 45`** ([admin.py:48](app/services/admin.py#L48)) — Redis cache
  TTL for `overview()`/`model_stats()`. Chosen `> 30 s` (the dashboard's poll
  interval) so steady-state polls hit the cache instead of re-scanning Postgres on
  the single free-tier worker.

### `is_admin` resolution chain

The `admins` TABLE is the SOLE source of truth — **no `.env` allowlist**
([admin.py:149-160](app/services/admin.py#L149)).

- **`_clerk_email_cache: dict[str,str]`** ([admin.py:79](app/services/admin.py#L79)) —
  process-local positive-only cache (a `None` is *not* cached, so a later-added email
  still resolves).
- **`_primary_email_of(user)`** ([admin.py:82-97](app/services/admin.py#L82)) — pulls
  the primary email off a clerk-backend User object, tolerating SDK attribute-name
  differences; falls back to `emails[0]`; swallows errors → `None`.
- **`_clerk_email(user_id)`** ([admin.py:100-126](app/services/admin.py#L100)) —
  best-effort Clerk Backend API lookup (the pre-onboarding fallback). Runs the sync
  `users.get` via `run_in_threadpool` (off the event loop); caches positive results;
  swallows all errors.
- **`_email_for(db, user_id, jwt_email)`** ([admin.py:129-146](app/services/admin.py#L129)) —
  resolves email in cheapest order: (1) JWT claim, (2) `user_profiles.extra.email`,
  (3) Clerk Backend API.

**`is_admin(db, user_id, jwt_email=None)`** algorithm
([admin.py:149-206](app/services/admin.py#L149)):
1. Resolve `email` via `_email_for`; `email_l = lower(email) or None`.
2. **Branch on email presence** (deliberately not one SQL with a `:email IS NOT NULL`
   guard — that made asyncpg raise `AmbiguousParameterError` on every call):
   - With email: `SELECT 1 FROM admins WHERE user_id = :uid OR lower(email) = :email
     LIMIT 1`.
   - Without: `SELECT 1 FROM admins WHERE user_id = :uid LIMIT 1`.
3. Run **directly on the request session** (NOT via `_scalar` — silent swallowing once
   hid a real admin being denied). `return found is not None`.
4. On exception: log the real cause, then **retry on a brand-new session**
   (`get_session_factory()`) so a poisoned request txn can't wrongly deny a genuine
   admin.
5. If the fresh session also fails → log + **fail-closed (`False`)** — deny rather
   than grant on error.

### Query functions (un-scoped, system-wide)

| Function | SQL summary | Notes |
|---|---|---|
| `health_snapshot(db)` ([:210](app/services/admin.py#L210)) | 12 independently-guarded `_scalar` counts | online via `last_seen_at > now() - interval '60 seconds'`; `pairing_codes_live` = `status='pending' AND expires_at > now()`; `turns_failed` = `status <> 'ok'`. |
| `cost_summary(db)` ([:235](app/services/admin.py#L235)) | one `_rows` over `turns`: `sum(cost_usd)`, `count FILTER (cost_usd IS NOT NULL)`, sums of `llm_input/output/thinking_tok` | |
| `overview(db, days=14)` ([:256](app/services/admin.py#L256)) | health + cost + daily series + 5 distributions + event counts | See below. |
| `list_users(db, limit=200)` ([:353](app/services/admin.py#L353)) | `user_profiles` + correlated subqueries for device_count/turn_count/cost/last_active | `limit` clamped `[1,1000]`; LEFT-join semantics via subqueries so users with no turns appear; `email` from `extra->>'email'`. |
| `list_devices(db, limit=300)` ([:376](app/services/admin.py#L376)) | `devices` LEFT JOIN `user_profiles` | `limit` `[1,1000]`; `is_paired = user_id IS NOT NULL AND revoked_at IS NULL`; `online` via the 60 s window. |
| `list_sessions(db, limit=100)` ([:395](app/services/admin.py#L395)) | `sessions` LEFT JOIN `user_profiles` | `limit` `[1,500]`; `has_summary = summary IS NOT NULL`. |
| `list_turns(db, limit=50, user_id, status)` ([:411](app/services/admin.py#L411)) | `turns` LEFT JOIN `user_profiles`, dynamic WHERE | See below. |
| `turn_trace(db, turn_id)` ([:463](app/services/admin.py#L463)) | `turn_traces` + joined `turns` | See below. |
| `list_events(db, limit=100)` ([:557](app/services/admin.py#L557)) | `events ORDER BY occurred_at DESC` | `limit` `[1,500]`. |
| `model_stats(db, days=14)` ([:568](app/services/admin.py#L568)) | 5 scans of `model_*` tables, merged in Python | See below. |
| `analytics_summary(db, rng="7d")` ([:544](app/services/admin.py#L544)) | avg/p95 generation (Σ tier latencies) + avg/p95 total + `_range_stages` + `_escalation_breakdown` | Lamp-only, IST window; cached 60 s. See §13.x. |
| `analytics_questions(db, rng, limit=100)` ([:637](app/services/admin.py#L637)) | per-turn rows from `turn_traces` LEFT JOIN `turns`/`devices`, newest first | Sourced from `turn_traces` so failed/cancelled turns appear; `_short_reason` fills the Reason column. |
| `analytics_timeseries(db, rng="7d")` ([:723](app/services/admin.py#L723)) | `date_trunc(bucket, created_at AT TIME ZONE 'Asia/Kolkata')` avg gen + total | hourly for today/yesterday, daily for 7d/30d; cached 60 s. |

#### `overview()` mechanics ([admin.py:256-350](app/services/admin.py#L256))

1. **Clamp** `days = max(1, min(int(days or 14), 90))`.
2. **Redis cache** key `admin:overview:{days}`; on hit, `json.loads` (corrupt value →
   fall through and recompute).
3. Compute `health` + `cost`.
4. `win = {"n": days - 1}` so the window is `[today-(days-1) .. today]` = `days`
   calendar days.
5. **Daily series**: `generate_series(... ::date, now()::date, interval '1 day')`
   LEFT JOIN `turns` on a **sargable range predicate** (`t.asked_at >= g.d AND
   t.asked_at < g.d + interval '1 day' AND t.status='ok'`) — deliberately NOT
   `asked_at::date = g.d`, whose cast defeats the index → seq scan.
6. **Distributions** (single `UNION ALL` query, all bounded to the same window):
   `subject` (`coalesce(subject,'other')`), `difficulty`
   (`coalesce(difficulty,'unknown')`), `query_type` (`coalesce(...,'other')`),
   `status` (all statuses, not just ok), `tier` (`'tier'||coalesce(final_tier,1)`).
   Rows are bucketed into five dicts via a `bucket` dispatch dict.
7. **Event counts**: `SELECT kind, count(*) FROM events GROUP BY kind ORDER BY n
   DESC`.
8. Assemble `result`, **cache best-effort** (`json.dumps(result, default=str)` so
   Decimal/datetime serialise), return.

#### `list_turns()` extras ([admin.py:411-460](app/services/admin.py#L411))

`limit` clamped `[1,200]`. Dynamic WHERE built from a `["1=1"]` base plus optional
`t.user_id = :uid` / `t.status = :st`. Selects trimmed text (`left(transcript,160)`
as `user_said`, `left(speech,240)` as `lamp_replied`), tokens, `final_tier`,
`escalated`, and four `extra->>` projections (`api_calls`, `timeline`, `source`,
`fallback`, `fallback_from`). Post-processing: if `timeline` came back as a JSON
string (driver-dependent), `json.loads` it (or `None`) so `list[TimelineStep]`
validates.

#### `turn_trace()` mechanics ([admin.py:463-554](app/services/admin.py#L463))

1. **UUID guard**: `uuid.UUID(str(turn_id))`; non-UUID → `None`.
2. **Trace lookup**: one `turn_traces` row WHERE `turn_id = CAST(:tid AS uuid) OR
   id = CAST(:tid AS uuid)` (accepts a `turns.id` *or* a `turn_traces.id` directly,
   for failed/retake turns that never wrote a `turns` row), `ORDER BY created_at DESC
   LIMIT 1`.
3. **JSON-string normalisation** for `phases`/`extra`/`bounding_box` (driver may
   return strings); malformed `bounding_box` → `None`, malformed `phases` → `[]`,
   `extra` → `{}`.
4. **Join the turns row** for human-readable Q/A using `out.turn_id or turn_id`.
   `latex_equations` JSON-string normalised + stringified non-empty.
5. If neither trace nor turn found → `None`. If only the turn exists (trace
   disabled/old), derive a minimal payload (`device_id=""`, `source` mapped
   `simulation→simulator` else `lamp`, raw image/audio URLs from the turn,
   `trace_id=""`) so the drawer still renders.

#### `model_stats()` mechanics ([admin.py:568-721](app/services/admin.py#L568))

Aggregates the BENCH tables into `AdminModelsOut`. Per-model response stats and
per-model feedback stats are computed in **separate scans and merged in Python** —
joining feedback into the response aggregate would fan-out rows and inflate counts.

1. Clamp `days [1,90]`; cache key `admin:models:{days}` (45 s).
2. `win = {"n": days-1}`; `cut = "(now() - make_interval(days => :n))::date"`.
3. **Response stats** (`model_responses` GROUP BY `model_name`): `count`, `FILTER`
   counts by status (ok/fail/timeout/error/not_configured), `avg(latency_ms) FILTER
   (status='ok')`, `avg/sum(estimated_cost)`, `avg(input/output_tokens)`,
   `sum(total_tokens)`.
4. **Feedback stats** (`model_feedback f JOIN model_responses r ON r.response_id =
   f.response_id` GROUP BY `r.model_name`): `feedback_count`,
   `count(f.user_rating)`, `avg(f.user_rating)` rounded to 2, `FILTER` thumbs_up/down.
5. **Catalog** (`model_providers`): `label/provider_name/active_status` →
   `available` picker.
6. **Merge**: `names = sorted(set(prov_by) | set(resp_by))` (every catalog model +
   any model with responses but no catalog row, defensive). `success_rate = round(ok
   / responses * 100, 1) if responses else 0.0`.
7. **Daily series** over `model_responses` (same generate_series pattern).
8. **Totals**: a single multi-subquery SELECT over `model_requests`/
   `model_responses`/`model_feedback` (requests, compare_groups via `is_compare`,
   responses, ok, total_cost, feedback, distinct `models_used`); `fail = responses -
   ok` computed in Python.
9. Assemble + cache + return.

---

### The Analytics tab (range-aware latency) — added 2026-07-09 → 07-11

Three cache-backed reads (`services/admin.py` +312 lines) power the admin **Analytics** tab. They answer *"how long does it take to generate the output?"* per question and in aggregate, over a chosen window. All three are **lamp-only** — every query carries `source='lamp'`, so web-simulator turns are excluded — and use **IST (`Asia/Kolkata`)** day/hour boundaries, because the pilot is India-based (JEE) and a UTC "today" would start at 05:30 IST and mix in the previous evening.

- **Windowing.** `_norm_range(rng)` clamps to `today | yesterday | 7d | 30d`; `_range_where(col, rng)` builds the SQL `WHERE` fragment — `today`/`yesterday` are **IST calendar days** (`date_trunc('day', now() AT TIME ZONE 'Asia/Kolkata')`), `7d`/`30d` are rolling `now() - interval` windows. `rng` is validated first, so the fragment never interpolates user input.
- **`analytics_summary`** — `avg_generation_ms`/`p95` where generation = `Σ(tier1+tier2+tier3)_latency_ms > 0`; `avg_total_ms`/`p95` from `turns.total_ms` (JOIN on ok lamp turns); the per-stage breakdown via `_range_stages` (the same `_PERF_STAGES` list as `GET /performance`); and the escalation funnel via `_escalation_breakdown`.
- **`_escalation_breakdown`** — a single `count(*) FILTER (…)` scan over ok lamp turns that classifies each into exactly one bucket by *which* `tierN_latency_ms` columns actually ran (the deterministic pre-router starts **at** a tier with no tier-1 call, whereas escalation always runs tier-1 first): `tier1` (t1 only), `tier2_direct` (t2, no t1/t3), `tier2_esc` (t1+t2, no t3), `tier3_direct` (t3 only), `tier3_esc` (t3 with t1 or t2, incl. skip-tier 1→3). `avg_ms` = average latency of that tier's call for the bucket.
- **`analytics_questions`** — reads from **`turn_traces`** (not `turns`) so **failed / cancelled turns appear** (they never persist a `turns` row); `final_tier` prefers `tt.final_tier` (the lamp orchestrator never writes `turns.final_tier`); the **Reason** column is `_short_reason(status, error_detail, escalation_reason)` — the specific provider/escalation string trimmed to ≤10 words (via `_clean_detail`/`_trim_words`), falling back to a friendly `_REASON_LABELS` label (Timed out / Cancelled / Bad reply / Cut off / Blocked / …) when no detail was captured; `""` for ok turns.
- **`analytics_timeseries`** — buckets by `date_trunc(bucket, created_at AT TIME ZONE 'Asia/Kolkata')` (hourly for today/yesterday, daily otherwise) for the trend chart.

`_PERF_STAGES` itself changed in this pass: `"Upload from lamp"` → **`"Lamp response loading"`**, and two new stages were inserted — **`model_select` ("Model selection", `model_select_ms`)** and **`graph_render` ("Graph render", `graph_render_ms`)** — mirroring the two new `turn_traces` latency columns (see [03-orchestrator-and-turn-pipeline.md](03-orchestrator-and-turn-pipeline.md) §12.3). Both `analytics_summary` and `analytics_timeseries` cache results for 60 s per range (`admin:analytics:*:istlamp:{r}`).

## 14. `routes/admin.py` — the admin HTTP surface

The system-wide read dashboard (`/api/frontend/admin/*`). Read-only by design —
nothing mutates except the manual media cleanup **and the OTA publish/delete**
(new). **No `from __future__ import annotations`** because the slowapi
`@limiter.limit` decorator + FastAPI's stringized annotation resolution don't mix
([admin.py:13-15](app/routes/admin.py#L13)). Mounted only when `ENABLE_AUTH=True`.

> **New admin endpoints since 2026-07-03** (`routes/admin.py` +72, `services/admin.py` +172):
> `GET /performance` (`latency_breakdown` — per-stage avg+p95 + time-to-first-audio,
> [admin.py:67-79](app/routes/admin.py#L67)); `GET /models` (`model_stats` — the multi-LLM
> eval dashboard, previously 404/unmounted, [:134-148](app/routes/admin.py#L134)); and the OTA
> console `POST /ota/release` (raw `.bin`, size 1000 B–4 MB), `GET /ota/releases`,
> `DELETE /ota/release/{id}` ([:82-131](app/routes/admin.py#L82), → `ota_release.*`, doc 12 §3.3).
> `health_snapshot` was batched into ONE round-trip ([services/admin.py:217-273](app/services/admin.py#L217)),
> and `list_users` now reads the pilot `cohort` tag via `to_jsonb(p)->>'cohort'` so it survives an
> un-run `ALTER`. The **pilot/insights** admin surfaces live in their own routers (doc 12), not here.
>
> **Analytics tab (2026-07-09 → 07-11)** — three more reads under `_ANALYTICS_RANGE` (`today|yesterday|7d|30d`), all 60/min + `require_admin`: `GET /analytics/summary`, `GET /analytics/questions` (`limit` 1–500), `GET /analytics/timeseries` ([admin.py:85-131](app/routes/admin.py#L85)). They back the new frontend **Analytics** tab (`03-frontend`); the service logic (lamp-only, IST windows, escalation funnel) is in §13.

`router = APIRouter(prefix="/api/frontend/admin", tags=["admin"])`. Every route
depends on **`require_admin`** ([deps/admin.py:27-43](app/deps/admin.py#L27)), which
verifies the Clerk session, extracts `jwt_email` from `request.state.clerk_payload`,
calls `is_admin(db, clerk_user_id, jwt_email)`, and raises **403 `NOT_ADMIN`** for
non-admins.

| Method + path | Rate limit | Service call | Response model |
|---|---|---|---|
| `GET /overview` ([:48](app/routes/admin.py#L48)) | 60/min | `admin_svc.overview(db, days=days)` (`days` `Query ge=1,le=90` default 14) | `AdminOverviewOut(**data)` |
| `GET /models` ([:62](app/routes/admin.py#L62)) | 60/min | `admin_svc.model_stats(db, days=days)` | `AdminModelsOut(**data)` |
| `GET /users` ([:79](app/routes/admin.py#L79)) | 60/min | `list_users(db, limit)` (`limit ge=1,le=1000` default 200) | `AdminUsersOut(rows=...)` |
| `GET /devices` ([:92](app/routes/admin.py#L92)) | 60/min | `list_devices(db, limit)` (default 300) | `AdminDevicesOut(rows=...)` |
| `GET /sessions` ([:104](app/routes/admin.py#L104)) | 60/min | `list_sessions(db, limit)` (`le=500` default 100) | `AdminSessionsOut(rows=...)` |
| `GET /turns` ([:116](app/routes/admin.py#L116)) | 60/min | `list_turns(db, limit, user_id, status)` (`limit le=200`; `status` aliased from `status` query) | `AdminTurnsOut(rows=...)` |
| `GET /turns/{turn_id}/trace` ([:148](app/routes/admin.py#L148)) | 120/min | `turn_trace(db, turn_id)` → 404 `TRACE_NOT_FOUND` if `None`; rewrites media URLs via `_browser_url` | `AdminTurnTraceOut(**data)` |
| `GET /media` ([:173](app/routes/admin.py#L173)) | 60/min | `media_svc.media_stats(db)` | `AdminMediaOut(**...)` |
| `POST /media/cleanup` ([:186](app/routes/admin.py#L186)) | 10/min | `media_svc.cleanup_media(db, days=body.days)`; on error returns `MediaCleanupOut(ok=False, error=...)` | `MediaCleanupOut` |
| `GET /events` ([:208](app/routes/admin.py#L208)) | 60/min | `list_events(db, limit)` (`le=500` default 100) | `AdminEventsOut(rows=...)` |
| `GET /analytics/summary` ([:88](app/routes/admin.py#L88)) | 60/min | `analytics_summary(db, rng=range)` (`range` pattern `today\|yesterday\|7d\|30d`) | `AdminAnalyticsSummaryOut(**data)` |
| `GET /analytics/questions` ([:104](app/routes/admin.py#L104)) | 60/min | `analytics_questions(db, rng=range, limit)` (`limit ge=1,le=500` default 100) | `AdminAnalyticsQuestionsOut(range=..., questions=...)` |
| `GET /analytics/timeseries` ([:122](app/routes/admin.py#L122)) | 60/min | `analytics_timeseries(db, rng=range)` | `AdminAnalyticsTimeseriesOut(**data)` |

**`_browser_url(url, request)`** ([admin.py:134-145](app/routes/admin.py#L134)) —
makes a stored blob URL playable in the admin browser: `file://` URIs (local backend)
→ rewritten to `{base_url}/blobs/{filename}` (the `/blobs` static mount);
http(s)/relative URLs (S3/R2/`STORAGE_PUBLIC_BASE_URL`) pass through.

---

## 15. `routes/frontend_manager.py` — identity / profile / analytics / bench

The web app's identity + profile + analytics surface plus the multi-LLM "brain bench"
([frontend_manager.py:1-16](app/routes/frontend_manager.py#L1)). Same
no-`from __future__` constraint, for the same slowapi reason. `router =
APIRouter(prefix="/api/frontend", ...)`. Every HTTP route gates on
`current_clerk_user`; the WS route gates on `verify_ws_token` (token via query string,
since browsers can't set a WS auth header).

### Identity / profile / analytics endpoints

- **`GET /me`** ([:96-121](app/routes/frontend_manager.py#L96)) — 120/min. Loads the
  profile, resolves `email` (JWT `email`/`primary_email` → profile `extra.email`),
  computes `is_admin` (so the frontend conditionally shows the Admin nav), returns
  `MeOut`.
- **`GET /profile`** ([:124-135](app/routes/frontend_manager.py#L124)) — 120/min.
  Returns `ProfileOut | None`; **200 + null body** for "not onboarded yet" (so the
  frontend redirects without catching a 404). Built by `_profile_out(row)`
  ([:78-93](app/routes/frontend_manager.py#L78)), which flattens `extra` JSONB
  (`email`/`learning_style`/`explain_depth`/`study_rhythm`/`focus_subject`) into the
  flat `ProfileOut`.
- **`PUT /profile`** ([:138-165](app/routes/frontend_manager.py#L138)) — 30/min.
  `upsert_profile(...)` with `onboarding_complete=True` and the learning fields packed
  into `extra` (`email`, `learning_style`, `explain_depth`, `study_rhythm`,
  `focus_subject`, `strong_subject`, `weak_subject`). Returns `ProfileOut`.
- **`GET /analytics`** ([:168-176](app/routes/frontend_manager.py#L168)) — 60/min →
  `user_analytics(db, user_id)` → `AnalyticsOut`.
- **`GET /analytics/detail`** ([:179-190](app/routes/frontend_manager.py#L179)) —
  60/min, `days Query ge=1,le=90` → `user_analytics_detail` → `AnalyticsDetailOut`.

### Multi-LLM bench endpoints

- **`GET /models`** ([:900-919](app/routes/frontend_manager.py#L900)) — 120/min.
  Builds `ModelInfo` rows from `model_catalog.list_models()` (each `available` only
  when its provider key is configured), returns `ModelsOut` with `default_model =
  model_catalog.DEFAULT_MODEL_ID`.
- **`POST /simulate`** ([:195-640](app/routes/frontend_manager.py#L195)) — 30/min. The
  **legacy** tiered-Gemini path, returning `gemini_brain.SimResponse` directly. Reads
  text/audio/`image`+`images`, dedupes blobs, caps at `MAX_IMAGES_PER_TURN`, runs
  CLAHE/unsharp enhancement at `max_dim=2048`, loads context in parallel
  (`_load_turn_context`), then runs the full deterministic pre-route + problem-memo +
  tiered escalation + guard flow (see below), persists fire-and-forget via
  `_persist_simulation`.
- **`POST /solve`** ([:1464-1703](app/routes/frontend_manager.py#L1464)) — 30/min. The
  **additive** provider-agnostic path. Returns `SolveOut` (answer + telemetry). If
  `model == "auto"` it runs `_solve_auto` under `asyncio.wait_for(SOLVE_TIMEOUT_S)`;
  else a direct `generate_solution(model, ...)` with a direct-pick solution-bleed
  guard. Writes a passive `TurnTracer` storyboard (`source="simulator"`) and persists
  model-eval rows via `_persist_solve_eval`.
- **`POST /solve/compare`** ([:1706-1775](app/routes/frontend_manager.py#L1706)) —
  15/min. Runs N models concurrently (`asyncio.gather`), de-dupes/caps model ids to
  the catalog size, **excludes `"auto"`** (it doesn't fit a one-result-per-model
  grid), returns `CompareOut` (order preserved).
- **`POST /feedback`** ([:1778-1793](app/routes/frontend_manager.py#L1778)) — 60/min.
  UPSERTs a learner's thumbs/rating/note keyed on `(response_id, user)`, returns
  `FeedbackOut(ok=...)`.
- **`WS /ws`** ([:1920-1996](app/routes/frontend_manager.py#L1920)) — the streaming
  binary gateway using the same `app/protocol.py` frame protocol as the lamp.

### The web tiered-escalation algorithm (shared by `/simulate` and `/solve` AUTO)

This is the backend's most complex control flow. Key helpers:

- **`_sim_pick_next_tier(sim, current_tier)`** ([:647-679](app/routes/frontend_manager.py#L647)) —
  the smart-skip router. Thresholds (quoted from code):
  - `confidence >= 0.75 and difficulty in {easy,medium}` → `None` (ship).
  - `difficulty == "hard" and (confidence < 0.7 or query_type in {derivation,calc,
    mistake_id})` → **tier 3** (HARD goes to Pro directly; flash-with-thinking is not
    a useful middle hop on hard problems).
  - `confidence <= 0.30` → tier 3 (inclusive — 0.30 exactly was slipping to t2).
  - `confidence < GEMINI_ESCALATE_CONFIDENCE` → tier 2.
  - else `None`.
  - **Semantic check floor** (if `SEMANTIC_CHECK_ESCALATION` and `query_type in
    {check, mistake_id}`): `floor = 3 if difficulty=="hard" else 2`; `target =
    floor if target is None else max(target, floor)` (never downgrades; not gated on
    difficulty because the model's self-rating is unreliable for checks).
- **`_sim_resolve_tier(target)`** ([:682-691](app/routes/frontend_manager.py#L682)) —
  clamps: `>=4 → 3`; `>=3 and not GEMINI_TIER3_ENABLED → 2`; `None` stays `None`.
- **`_sim_call_tier(tier, ...)`** ([:714-751](app/routes/frontend_manager.py#L714)) /
  **`_auto_call(...)`** ([:1002-1026](app/routes/frontend_manager.py#L1002)) — map
  tier→model/budget: tier 3 → `GEMINI_TIER3_MODEL` with tier-3 thinking/output
  budgets; tier 2 → default `GEMINI_MODEL` with tier-2 budgets; tier 1 → default with
  tier-1 budgets. `tier >= 2` appends `problem_memo.SOLVE_SUFFIX` so escalated calls
  also write the internal solution. `_auto_call` additionally returns usage telemetry
  for the `AutoStep` breakdown.

The flow in both paths (full mechanics in `/simulate` lines 283-606 and `_solve_auto`
1029-1462): deterministic pre-route (image-quality gate + keyword tiering →
`start_tier`, `retake`, `focus_label`, `prompt_suffix`) → problem-memo load (answer
key / dispute guard / question context) → nudge gate (`solve_authorized`) → first-pass
call → semantic dispute backstop (model flag → fresh Pro re-derivation) → focus guard
(asked-vs-answered mismatch → one corrective re-call) → memo verdict (flush on new
problem / touch on match / record nudge) → escalation loop (gate + skip-tier +
flash→Pro handoff brief) → solution-bleed guard → reveal-completeness guard → memo
write. `_solve_auto` records each LLM call as an `AutoStep` and is wall-clock guarded
by `_low_budget()` ([:1042-1052](app/routes/frontend_manager.py#L1042)), which skips
guard re-calls when within `reserve_s=20.0` of `SOLVE_TIMEOUT_S`.

### Persistence: mapping the web shape onto `LlmReply`

Both `_persist_simulation` ([:813-889](app/routes/frontend_manager.py#L813)) and
`_persist_solve` ([:1845-1900](app/routes/frontend_manager.py#L1845)) map the web
`SimResponse.display{type,latex,text}` onto the lamp's `LlmReply` so one `turns`
schema covers both:

```
display.type == "latex" (non-empty)  → Display(kind="none", content=""), eqs=[latex]
display.type == "text"               → Display(kind="text", content=text),  eqs=[]
otherwise                            → Display(kind="none", content=""),    eqs=[]
```

This is the closest the production web path comes to the prototype `track_router` /
`tft_formatter`: a deterministic display-channel remap, plus carry-through of the
problem-identity signals (`same_problem`, `problem_statement`) for the L1 NEW-PROBLEM
boundary. Turns are tagged `source="simulation"`, `channel="web"`,
`device_id="websim-{user}"`. `_persist_solve_eval`
([:1796-1842](app/routes/frontend_manager.py#L1796)) writes one `model_requests` + one
`model_responses` per model, and mirrors **successful single-model** answers into
`turns` (compare mode is intentionally NOT mirrored — N answers would inflate history).

### WS streaming details

- **`_drive_turn`** ([:2030-2082](app/routes/frontend_manager.py#L2030)) — drives a
  `BrainEvent` stream, emitting `STATE`/`TEXT_OUT`/`TEXT_OUT_END`/`AUDIO_OUT*` frames.
  Splits text into sentences via `_SENTENCE_END_RE = re.compile(r"([.!?])(\s|$)")`
  ([:2000](app/routes/frontend_manager.py#L2000)) so first audio lands ~700 ms after
  end-of-speech. **Frontend isolation**: uses `FRONTEND_TTS_PROVIDER` (whose type
  excludes `"gemini"`), so the browser surface can never spend Gemini audio tokens —
  flipping `TTS_PROVIDER=gemini` affects the ESP32 lamp only.
- `_pcm_to_wav(pcm, sample_rate)` wraps raw PCM into a WAV (1 channel, 16-bit) at
  `BRAIN_AUDIO_SAMPLE_RATE`.

---

## 16. Configuration, constants & environment variables

| Name | Location | Value / effect |
|---|---|---|
| `max_lines` | `tft_formatter.py:3` | 4-line TFT cap |
| `[:30]` | `tft_formatter.py:11` | last prose line width before ellipsis (text only) |
| `MAX_EQUATIONS` | `llm_response.py:25` | 3 — `latex_equations` cap + Gemini `maxItems` |
| `_QUERY_TYPES/_SUBJECTS/_DIFFICULTIES` | `llm_response.py:29-33` | valid enum sets for tolerant coercion |
| `confidence` default `0.8` | `llm_response.py:115`, `_coerce_tolerant` | absent/null confidence → schema default 0.8; present-but-**garbage** → **0.3** since 2026-07-06, so a broken reply routes TO escalation instead of suppressing it (see doc 13) |
| `_ONLINE_WINDOW_SEC` | `services/admin.py:42` | 60 s online window |
| `_ANALYTICS_TTL_S` | `services/admin.py:48` | 45 s Redis TTL for overview/models |
| `days` clamp `[1,90]` | `services/admin.py:261,580` + routes | overview/models range |
| `limit` clamps | `services/admin.py:357/379/397/421/559` | users 1000, devices 1000, sessions 500, turns 200, events 500 |
| `_MAX_ROWS_PER_RUN` | `services/media_cleanup.py:33` | 400 rows/cleanup click |
| `MediaCleanupIn.days` | `schemas/admin.py:230` | `ge=1, le=365`, default 14 |
| Rate limits | `routes/admin.py`, `routes/frontend_manager.py` | per-endpoint `@limiter.limit` (see §14/§15) |
| `GEMINI_ESCALATE_CONFIDENCE` | settings (read in `_sim_pick_next_tier`, `_coerce_tolerant`) | tier-2 escalation threshold |
| `GEMINI_TIER3_ENABLED`, `GEMINI_TIER3_MODEL` | settings | gate + model for tier-3 (Pro) |
| `GEMINI_TIER1/2/3_THINKING_BUDGET`, `..._MAX_OUTPUT_TOK` | settings | per-tier budgets |
| `GEMINI_DYNAMIC_THINKING` | settings | enables the escalation loop |
| `SEMANTIC_CHECK_ESCALATION`, `DISPUTE_GUARD`, `SOLVE_DIRECT_BLEED_GUARD` | settings | guard toggles |
| `PREROUTE_ENABLED`, `PREROUTE_STT_ENABLED`, `PREROUTE_IMAGE_QUALITY_GATE` | settings | deterministic pre-router toggles |
| `MEMO_CAPTURE_QUESTION` | settings | question-context memo path |
| `SOLVE_TIMEOUT_S`, `SOLVE_REVEAL_MAX_OUTPUT_TOK` | settings | AUTO wall-clock budget + reveal cap |
| `ENABLE_IMAGE_ENHANCEMENT` | settings | CLAHE/unsharp on bench uploads |
| `MAX_IMAGES_PER_TURN` | `app/session.py` | per-turn image cap |
| `FRONTEND_TTS_PROVIDER`, `BRAIN_AUDIO_SAMPLE_RATE` | settings | WS bench TTS + PCM rate |
| `ENABLE_AUTH` | settings (`app/main.py`) | mounts the admin + frontend routers |
| `STORAGE_PUBLIC_BASE_URL` | settings (storage) | passed through by `_browser_url` |

The admins allowlist is **table-only** (no `ADMIN_USER_IDS`/`ADMIN_EMAILS` env vars —
explicitly removed; `services/admin.py:155-157`).

---

## 17. Edge cases, error handling, fallbacks

- **Tolerant LLM parsing** — `_coerce_tolerant` repairs bad analytics fields rather
  than rejecting the whole reply; every repair WARN-logs to surface prompt drift.
  `extra="ignore"` on `LlmReply` drops unsolicited keys; `DevicePollOut` uses
  `extra="forbid"` (strict).
- **Provider-failure replies** — `fallback_for_status()` returns a status-specific
  canned `LlmReply`; the orchestrator independently flips the LED to ERROR.
- **Image too poor** — `retake_image_reply()` / pre-route `retake` short-circuit with
  zero LLM spend, `status="ok"` (helpful guidance, not an error).
- **Savepoint isolation** — every admin query is `begin_nested`-guarded; a missing
  table degrades to `[]`/`0`/`None` and the rest of the dashboard still renders.
- **`is_admin` fail-closed + fresh-session retry** — a poisoned request txn can't
  wrongly deny a real admin; a true error denies (security default).
- **Cache corruption** — corrupt/legacy Redis values fall through to recompute; failed
  `cset` just means the next poll recomputes.
- **Driver JSON quirks** — `timeline`/`phases`/`extra`/`bounding_box`/`latex_equations`
  are JSON-string-normalised in `list_turns`/`turn_trace`.
- **Empty bench input** — `/simulate`, `/solve`, `/solve/compare` return 422
  `EMPTY_INPUT` if no text/audio/image, after cancelling the context task.
- **Provider overload** — `/simulate` maps `503/UNAVAILABLE/429/RESOURCE_EXHAUSTED` to
  503 `BRAIN_BUSY`, else 502 `BRAIN_ERROR`; `/solve` AUTO returns a `status="busy"`/
  `"error"` `SolveResult` and `status="timeout"` on `asyncio.TimeoutError`.
- **Persistence is fire-and-forget** — `asyncio.create_task` + `try/except` everywhere;
  a failed DB write never breaks the response.
- **Bench fan-out cap** — `/solve/compare` de-dupes + caps model ids to the catalog
  size; `"auto"` excluded.
- **Trace not found** — `turn_trace` route raises 404 `TRACE_NOT_FOUND`.
- **Media cleanup** — bounded per click; URLs nulled only AFTER the storage delete
  succeeds; failures return `MediaCleanupOut(ok=False, error=...)` rather than raising.
- **Prototype helpers** — `tft_formatter`/`track_router`/`validator` never raise on
  malformed input (defaulted `.get`, strict `>` comparisons), but are not on the live
  path.

---

## 18. Integration points / cross-references

**Upstream (produce the data these consume):**
- LLM providers (`app/providers/gemini_brain.py`, `llm_claude.py`) → `LlmReply`
  (lamp) / `SimResponse` (web).
- The lamp orchestrator persists `turns`/`turn_traces`/`sessions`/`events`;
  `services/admin.py` reads them.
- The bench (`/solve`) writes `model_requests`/`model_responses`/`model_feedback`;
  `model_catalog`/`model_providers` supply the catalog.

**Downstream (consume these outputs):**
- **Firmware** — renders `LlmReply.display` (text card) + `latex_equations[]` on the
  320×240 TFT and speaks `speech`; the lamp is the physical embodiment of what
  `tft_formatter`/`track_router` were designed to shape.
- **Next.js frontend** — `lib/admin.ts` (mirrors `schemas/admin.py`),
  `lib/onboarding.ts` (`schemas/frontend.py`), `lib/models.ts` (`TimelineStep`),
  the `/admin` dashboard, `/analytics` page, and the `/simulator` bench (KaTeX renders
  `SimResponse.display`).
- **Supabase/Postgres+pgvector** — `services/admin.py` and `media_cleanup.py` query
  `user_profiles`, `devices`, `pairing_codes`, `sessions`, `turns`, `turn_traces`,
  `events`, `memories`, `admins`, `model_*`, and `storage.objects`.

**Lateral:**
- `deps/admin.py:require_admin` ← `services/admin.py:is_admin`.
- `routes/frontend_manager.py:/me` ← `services/admin.py:is_admin` (for the `is_admin`
  flag).
- `routes/admin.py` ← `services/admin.py` + `services/media_cleanup.py` + the admin
  schemas.
- `model_eval.py` ← `providers.gemini_brain.SimResponse` (shared answer body).
- Prototype: `turn_handler.py` → `validator.py`; `tft_formatter`/`track_router` are
  the design-folder formatting layer referenced (commented) by `turn_handler.py`.

---

## 19. Mermaid diagrams

### 19.1 Admin overview request (read path, cache + savepoints)

```mermaid
sequenceDiagram
    participant FE as Next.js /admin (polls 30s)
    participant R as routes/admin.py:overview
    participant Gate as deps/admin.require_admin
    participant IsA as services/admin.is_admin
    participant Svc as services/admin.overview
    participant Cache as Redis (45s TTL)
    participant PG as Postgres (savepoints)

    FE->>R: GET /api/frontend/admin/overview?days=14
    R->>Gate: Depends(require_admin)
    Gate->>IsA: is_admin(db, user_id, jwt_email)
    IsA->>PG: SELECT 1 FROM admins WHERE user_id/email
    PG-->>IsA: row? (fail-closed on error)
    IsA-->>Gate: True
    Gate-->>R: clerk_user_id
    R->>Svc: overview(db, days=14)
    Svc->>Cache: cget("admin:overview:14")
    alt cache hit
        Cache-->>Svc: JSON
    else miss
        Svc->>PG: health (12 _scalar, each begin_nested)
        Svc->>PG: cost_summary, daily series, distributions, events
        PG-->>Svc: mapped rows / [] on missing table
        Svc->>Cache: cset(JSON, 45s)
    end
    Svc-->>R: dict
    R-->>FE: AdminOverviewOut (validated)
```

### 19.2 Live display contract vs. prototype formatting

```mermaid
flowchart TD
    A[LLM provider JSON] --> B[LlmReply._coerce_tolerant]
    B -->|clamp confidence, cap eqs=3,\ncoerce enums, re-box display| C[LlmReply]
    C --> S[speech -> TTS]
    C --> D["display{kind: text|none, content}"]
    C --> E["latex_equations[] (max 3)"]
    D --> FW[Firmware TFT text card]
    E --> FW2[Firmware TFT LaTeX region]

    subgraph PROTOTYPE_unused [Prototype BAO formatting - NOT on live path]
      P0["display_content{kind, content}"] --> P1{exam_track == conceptual\nAND kind == latex?}
      P1 -->|yes| P2[demote kind->text,\nstrip $$ $ backslash]
      P1 -->|no| P3[pass-through]
      P2 --> P4[enforce_tft_constraint:\nsplit lines, keep first 4,\ntext-> last line 30 chars + ...]
      P3 --> P4
    end
```

### 19.3 Web bench AUTO escalation (per-step breakdown)

```mermaid
flowchart TD
    Start[/solve model=auto/] --> PR[Deterministic pre-route\nimage gate + keyword tiering]
    PR -->|retake_image| RT[Return guidance, 0 LLM spend]
    PR --> Memo[Load problem memo / dispute / question ctx]
    Memo --> T1[_auto_call start_tier\nAutoStep first-pass/keyed-nudge]
    T1 --> SD{student_disputes_prior\n& current<3 & budget?}
    SD -->|yes| T3[Tier-3 fresh Pro re-derive\nAutoStep dispute-rederive]
    SD -->|no| FG
    T3 --> FG{focus_label mismatch\n& images & budget?}
    FG -->|yes| FGR[Corrective re-call\nAutoStep focus-guard]
    FG -->|no| LOOP
    FGR --> LOOP{GEMINI_DYNAMIC_THINKING\n& gate target>current?}
    LOOP -->|yes| ESC[Flash->Pro handoff brief\nAutoStep escalation]
    ESC --> LOOP
    LOOP -->|no| BG{solution_bleed\n& not authorized & budget?}
    BG -->|yes| BGR[AutoStep bleed-guard]
    BG -->|no| RG
    BGR --> RG{authorized reveal\nincomplete & budget?}
    RG -->|yes| RGR[AutoStep reveal-guard]
    RG -->|no| W[Memo write if tier>=2]
    RGR --> W
    W --> Out[SolveResult -> SolveOut\nmeta.steps = AutoStep list]
```

---

*End of reference.*
