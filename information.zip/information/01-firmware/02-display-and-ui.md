# Firmware — TFT Display, UI, QR, Image Viewer, Text Entry, On-device LaTeX

The Smart Tutor Lamp ("Lumos") drives a 320×240 SPI TFT panel (TFT_eSPI / ILI9341-class) as its sole on-device display. This document is the definitive reference for the firmware that owns that panel: the master UI state machine (`tft_ui`), the Settings page (`tft_settings`), the on-screen keyboard (`text_entry`), the pairing-QR generator (`tft_qr` + vendored `RICqrcode`), the JPEG image viewers (`image_viewer` and `tft_ui`'s integrated preview), and the on-device LaTeX/equation viewer. A key architectural fact established up front: **the lamp does NOT render LaTeX** — the backend renders equations to RGB565 pixel frames and ships them; the ESP32 only pushes finished pixels to the panel. The firmware here therefore covers two pixel pipelines (server-rendered frames vs. on-device JPEG decode) plus a fully self-contained immediate-mode UI toolkit.

---

## Table of Contents

1. [Purpose & Responsibilities](#1-purpose--responsibilities)
2. [High-Level Architecture](#2-high-level-architecture)
3. [The Master UI Module: `tft_ui`](#3-the-master-ui-module-tft_ui)
   - 3.1 [Panel setup, PSRAM caches, configuration constants](#31-panel-setup-psram-caches-configuration-constants)
   - 3.2 [The page/state model](#32-the-pagestate-model)
   - 3.3 [The tick loop & rate limiting](#33-the-tick-loop--rate-limiting)
   - 3.4 [Top status bar](#34-top-status-bar)
   - 3.5 [The sin64 table & float-free animation](#35-the-sin64-table--float-free-animation)
   - 3.6 [Page-by-page breakdown](#36-page-by-page-breakdown)
   - 3.7 [Button handling & navigation](#37-button-handling--navigation)
   - 3.8 [External-drawing handoff](#38-external-drawing-handoff)
4. [On-device Equation / Graph / Chemistry Viewer](#4-on-device-equation--graph--chemistry-viewer)
   - 4.1 [Wire format & inner header](#41-wire-format--inner-header)
   - 4.2 [Chunked accumulator path](#42-chunked-accumulator-path)
   - 4.3 [APPEND splice protocol](#43-append-splice-protocol)
   - 4.4 [Multi-equation grouping](#44-multi-equation-grouping)
   - 4.5 [Painting a frame & the loading skeleton](#45-painting-a-frame--the-loading-skeleton)
   - 4.6 [Compressed (JPEG) equations](#46-compressed-jpeg-equations)
   - 4.7 [Interactive graph page (`PAGE_GRAPH`)](#47-interactive-graph-page-page_graph)
   - 4.8 [Chemistry structures page (`PAGE_CHEM`)](#48-chemistry-structures-page-page_chem)
   - 4.9 [Scroll-document page (`PAGE_DOC` / `TFT_SCROLL_DOC`)](#49-scroll-document-page-page_doc--tft_scroll_doc)
5. [Image Decoding & Preview](#5-image-decoding--preview)
   - 5.1 [`tft_ui` integrated preview + display transform](#51-tft_ui-integrated-preview--display-transform)
   - 5.2 [`image_viewer` (debug viewer)](#52-image_viewer-debug-viewer)
   - 5.3 [`tft_display` (legacy frame painter)](#53-tft_display-legacy-frame-painter)
6. [QR Code Generation & Pairing](#6-qr-code-generation--pairing)
   - 6.1 [`RICqrcode.c` algorithm](#61-ricqrcodec-algorithm)
   - 6.2 [`tft_qr` and `tft_ui` QR rendering](#62-tft_qr-and-tft_ui-qr-rendering)
7. [Settings Page: `tft_settings`](#7-settings-page-tft_settings)
8. [On-screen Keyboard: `text_entry`](#8-on-screen-keyboard-text_entry)
9. [Text Wrapping & Pagination Algorithm](#9-text-wrapping--pagination-algorithm)
10. [Configuration, Constants & Their Effects](#10-configuration-constants--their-effects)
11. [Edge Cases, Error Handling, Fallbacks](#11-edge-cases-error-handling-fallbacks)
12. [Integration Points & Cross-references](#12-integration-points--cross-references)
13. [Mermaid Diagrams](#13-mermaid-diagrams)
14. [File-by-file / Function-by-function Index](#14-file-by-file--function-by-function-index)

---

## 1. Purpose & Responsibilities

The display subsystem is responsible for every pixel on the lamp's 320×240 screen across the device's entire lifecycle: boot splash, WiFi connection, backend pairing (QR + code), the resting "face" (animated eyes), the live conversational states (listening waveform, thinking spinner, image preview, the tutor's text/LaTeX answer), the error screen, the Settings menu, and the on-screen keyboard for WiFi credentials. It also renders two distinct pixel sources:

- **Server-rendered RGB565 frames** for math/LaTeX answers — the backend's `Latex_engine_tft.py` produces matplotlib→PIL→RGB565→byte-swap output and ships the finished pixels; the lamp pushes them via SPI ([tft_display.h:3-8](Smart-Tutor-Lamp/tutor_lamp/tft_display.h#L3-L8)).
- **On-device JPEG decode** for the camera preview — TJpg_Decoder (Bodmer) decodes captured JPEGs block-by-block straight to the panel ([tft_ui.cpp:368-370](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L368-L370)).

A hard performance contract governs the whole module: **all drawing happens in `loop()` context only**, via `tick()`. A FreeRTOS capture task (core 1, priority 8) may pre-empt `loop()` at any moment; SPI writes simply resume where they left off. Setters (`set_wifi`, `set_listening_level`, etc.) only stage volatile state and are safe to call from any task — the SPI work is deferred to the next `tick()` ([tft_ui.h:17-32](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h#L17-L32)).

---

## 2. High-Level Architecture

There are three generations of TFT code in the tree, reflecting an in-progress consolidation:

| Module | Role | TFT_eSPI ownership | Status |
|---|---|---|---|
| `tft_ui` | **Master UI** — owns the one canonical panel, all pages, animations, LaTeX viewer, integrated image preview | Owns `s_tft` singleton ([tft_ui.cpp:127](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L127)) | Current / authoritative |
| `tft_settings` | Settings menu; borrows `tft_ui::tft_handle()` | Borrows | Current |
| `text_entry` | On-screen keyboard; borrows `tft_ui::tft_handle()` | Borrows | Current |
| `tft_display` | Legacy server-frame painter | Owns its **own** `s_tft` ([tft_display.cpp:13](Smart-Tutor-Lamp/tutor_lamp/tft_display.cpp#L13)) | Superseded by `tft_ui::on_tft_frame` |
| `tft_qr` | Standalone QR pairing screen | Owns its **own** `s_tft` ([tft_qr.cpp:26](Smart-Tutor-Lamp/tutor_lamp/tft_qr.cpp#L26)) | Superseded by `tft_ui` QR page |
| `image_viewer` | Debug JPEG viewer | Owns its **own** `s_tft` ([image_viewer.cpp:20](Smart-Tutor-Lamp/tutor_lamp/image_viewer.cpp#L20)) | Debug-only, compile-gated |
| `RICqrcode.c/.h` | Vendored QR-Code generator (Richard Moore) | n/a (pure logic) | Shared dependency |

The headers explicitly call out the duplication: each of `image_viewer`, `tft_qr`, and `tft_display` owns its own `TFT_eSPI` instance even though "TFT_eSPI is designed for one global instance per sketch" — "having two works in practice as long as they are NOT used concurrently" ([tft_qr.h:9-14](Smart-Tutor-Lamp/tutor_lamp/tft_qr.h#L9-L14), [tft_display.h:35-39](Smart-Tutor-Lamp/tutor_lamp/tft_display.h#L35-L39)). The consolidation target is the `tft_ui` singleton ([tft_ui.h:6-8](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h#L6-L8)). The `tutor_lamp.ino` TODO list confirms `tft_qr` / `provisioning` calls are "linked in but never called" in the current flow ([tutor_lamp.ino:127](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L127)).

**Toolkit style.** All UI is immediate-mode: there is no retained scene graph. Each page has an `enter_*()` (one full-screen paint) and a `tick_*()` (per-frame partial update of only the dirty animation areas). Differential redraw — repainting only the pixels that visually changed — is the central anti-flicker technique used everywhere (eyes, waveform, settings rows, keyboard cursor, countdown bar).

---

## 3. The Master UI Module: `tft_ui`

`tft_ui.cpp` is ~2049 lines and contains the bulk of the display logic. Public surface is in [tft_ui.h](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h).

### 3.1 Panel setup, PSRAM caches, configuration constants

`tft_ui::begin()` is the single init entry point ([tft_ui.cpp:353-394](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L353-L394)):

1. `s_tft.init()`, `setRotation(TFT_ROT)`, `fillScreen(COL_BG)`, `setTextWrap(true)`.
   - `TFT_ROT = 1` (landscape, flipped 180° from rotation 3) ([tft_ui.cpp:46](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L46)).
2. Allocates a **top-bar sprite** `s_topbar` of `SCREEN_W × TOPBAR_H` (320×18) at 16-bit depth, for flicker-free partial top-bar paint. If allocation fails, it falls back to direct paint ([tft_ui.cpp:361-366](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L361-L366)).
3. Configures TJpg_Decoder: `setJpgScale(1)`, `setSwapBytes(true)`, and registers `tjpg_block_cb` ([tft_ui.cpp:368-370](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L368-L370)).
4. Allocates two PSRAM buffers via `ps_malloc`:
   - `s_latex` = `LATEX_CACHE_BYTES = 3 MiB` ([tft_ui.cpp:82](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L82)).
   - `s_image` = `IMAGE_CACHE_BYTES = 200 KiB` ([tft_ui.cpp:83](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L83)).
   - If `ps_malloc` returns `nullptr` (no PSRAM), the firmware degrades gracefully: `on_tft_frame`/`on_image_jpeg` check for null and silently drop ([tft_ui.cpp:372-388](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L372-L388)).

The 3 MiB sizing is deliberate and load-bearing: it must be ≥ the chunked accumulator capacity used in `tutor_lamp.ino`, or `on_tft_frame`'s size guard silently drops the LaTeX frame. The comment records the historical bug — "▶ LaTeX TX DONE in backend but nothing on the TFT" ([tft_ui.cpp:69-82](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L69-L82)). 3 MiB holds the "ultimate stress test" formula's ~24-frame scroll animation (24 × 320×240×2 + 6 ≈ 2.76 MB). Note: `tft_ui` shares this exact buffer with the `.ino`'s chunk accumulator (see §4.2) — the `.ino` writes chunks directly into `get_latex_buffer()` to avoid a second 3 MB allocation that previously exhausted PSRAM and caused `esp_camera_init` to fail ([tft_ui.h:129-147](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h#L129-L147)).

**Panel geometry now lives in `display_config.h`** (new in `aa2143c`) — the single source of truth for the TFT size. `tft_ui.h` re-exports `SCREEN_W`/`SCREEN_H` from `LAMP_SCREEN_W`/`LAMP_SCREEN_H`, and `tft_ui.cpp`'s local `sx()/sy()` helpers just forward to `lamp_sx()/lamp_sy()` ([tft_ui.cpp:52-53](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L52-L53), [tft_ui.h:281-286](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h)). Every layout coordinate in `tft_ui.cpp`, `tft_settings.cpp`, and `text_entry.cpp` is derived through these scale helpers, so changing the four PANEL numbers in `display_config.h` reflows the whole UI. The helpers are authored at a **320×240 reference** (`LAMP_REF_W/H`), where `lamp_sx/sy` are the identity — so at the current panel the compiled coordinates are byte-for-byte what they were before the refactor. `LAMP_LATEX_AREA_H` (the combined-view equation slot, `lamp_sy(110)`) is **mirrored server-side in `app/config.py`** so rendered equation/graph pixels line up with the slot the firmware paints ([display_config.h:1-65](Smart-Tutor-Lamp/tutor_lamp/display_config.h)).

**Geometry constants** ([tft_ui.cpp:47-66](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L47-L66)):

| Constant | Value | Meaning |
|---|---|---|
| `SCREEN_W` / `SCREEN_H` | 320 / 240 | panel size (from `display_config.h`) |
| `TOPBAR_H` | 18 | status bar height |
| `CONTENT_Y0` | `TOPBAR_H + 2` = 20 | top of content area |
| `CONTENT_H` | `SCREEN_H - TOPBAR_H - 2` = 220 | content height |
| `TICK_MIN_MS` | 33 | ~30 fps cap |
| `TOPBAR_REFRESH_MS` | 1000 | clock repaint cadence |
| `SIDE_BAR_W` | 5 | speaker-anim side bar width |
| `SIDE_BAR_SEGS` | 28 | side-bar segment count |
| `HINT_STRIP_H` | 18 | bottom hint row height |
| `MAX_LATEX_EQ` | 12 | == backend worst-case `frame_cap` |

**Color palette (RGB565)** ([tft_ui.cpp:89-103](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L89-L103)) — computed as `(r<<11)|(g<<5)|b`. Key values: `COL_BG = 0x1082` (dark navy), `COL_ACCENT = 0x07FF` (cyan), `COL_WARM = 0xFD20` (amber), `COL_OK = 0x07E0` (green), `COL_ERR = 0xF800` (red), `COL_EYE_PUPIL = 0x07FF`.

### 3.2 The page/state model

Pages are an `enum Page : uint8_t` of 15 states ([tft_ui.h:48-69](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h#L48-L69)):

| # | Page | Meaning |
|---|---|---|
| 0 | `PAGE_BOOT` | power-up splash |
| 1 | `PAGE_WIFI_CONNECTING` | "Connecting to \<ssid\>" |
| 2 | `PAGE_QR_PAIRING` | QR + pairing code |
| 3 | `PAGE_GREETING` | one-shot welcome / peripherals loading |
| 4 | `PAGE_IDLE` | animated eyes + clock (at rest) |
| 5 | `PAGE_LISTENING` | mic waveform (MODE_COMMAND) |
| 6 | `PAGE_THINKING` | EOS → first AUDIO_OUT (spinner) |
| 7 | `PAGE_IMAGE_PREVIEW` | captured JPEG after wake |
| 8 | `PAGE_SPEAKING_TEXT` | LLM plain-text answer + side anim |
| 9 | `PAGE_SPEAKING_LATEX` | LLM math answer; manual ◀/▶ scroll |
| 10 | `PAGE_ERROR` | network down / pairing failed |
| 11 | `PAGE_PAIRING` | contacting backend to register (before QR exists) |
| 12 | `PAGE_GRAPH` | full-screen interactive graph (new `e1de15a`); DOWN-long toggles to/from `PAGE_SPEAKING_LATEX`, 4-dir pans x/y, SELECT/UP-long/DOWN-long zoom — see §4.7 |
| 13 | `PAGE_CHEM` | full-screen chemistry structure(s) (new `e1de15a`); LEFT-long toggles from `PAGE_SPEAKING_LATEX`, L/R step through up to 4 cached steps — see §4.8 |
| 14 | `PAGE_DOC` | scroll-document (new `c699e72`, `TFT_SCROLL_DOC`): the whole answer as one vertical scroll (text + equations + graphs + chemistry stacked). UP/DOWN scroll, RIGHT opens the on-screen graph's interactive arena, LEFT toggles answer⇄spoken-transcript, SELECT clears + goes home — see §4.9 |

`PAGE_PAIRING` is deliberately distinct from `PAGE_WIFI_CONNECTING` so a `/register` failure on a cold backend never reads as a WiFi hang ([tft_ui.h:60-63](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L61-L63), [tft_ui.cpp:1056-1062](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1056-L1062)).

Page transitions use a **lazy-enter** pattern. `set_page(p)` only updates `s_page` and resets `s_page_entered = false` if `p != s_page` ([tft_ui.cpp:396-400](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L396-L400)). The actual `enter_*()` runs inside `tick()` when it sees `!s_page_entered` ([tft_ui.cpp:791-792](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L791-L792)). Setting `s_page_entered = false` without changing the page is the universal "force a repaint" idiom (used after new text/LaTeX arrives even when already on that page).

### 3.3 The tick loop & rate limiting

`tick(bool force)` ([tft_ui.cpp:784-820](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L784-L820)) is called every `loop()` iteration and self-throttles:

1. Returns immediately if not initialised, or if `s_external_drawing` (Settings/keyboard owns the screen).
2. Unless `force`, returns if `now - s_last_tick < TICK_MIN_MS (33 ms)`.
3. Lazy page enter (calls `enter_page(s_page)` once).
4. **Top-bar refresh policy**: redraw if `s_topbar_dirty` was set by a setter, OR every `topbar_period`. The period is **120 ms** when a connection indicator is animating (`s_be == BE_CONNECTING` or `s_wifi == WIFI_CONNECTING`) so the pulse/bars stay smooth (~8 fps), else `TOPBAR_REFRESH_MS = 1000` ([tft_ui.cpp:797-803](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L797-L803)).
5. Dispatches to the active page's `tick_*()` via a switch.

### 3.4 Top status bar

`draw_topbar()` ([tft_ui.cpp:927-958](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L927-L958)) renders everything into the `s_topbar` sprite then `pushSprite(0,0)` once (flicker-free). Layout left→right: WiFi icon (x=4), backend dot (x=22), state glyph (x=36), centered "LUMOS" brand, right-aligned clock, and a divider HLine at the bottom.

- **WiFi icon** `draw_wifi_icon` ([tft_ui.cpp:829-847](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L829-L847)) — three ascending bars; `lit` count and color depend on `WiFiStatus`:
  - `WIFI_OFF` → 0 lit, red; `WIFI_CONNECTING` → `(millis()/300) % 4` lit, amber (animated sweep); `WIFI_WEAK` → 1, amber; `WIFI_OK` → 2, green; `WIFI_STRONG` → 3, green.
  - RSSI→status thresholds are applied by the caller in `tutor_lamp.ino`: `> -65` STRONG, `> -75` OK, else WEAK ([tutor_lamp.ino:1287-1289](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1287-L1289)); documented in the enum at [tft_ui.h:70-72](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h#L70-L72).
- **Backend dot** `draw_backend_dot` ([tft_ui.cpp:849-875](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L849-L875)) — `BE_ONLINE` solid green core + ring; `BE_CONNECTING` a "sonar ping" ring whose radius is `2 + (millis()/120) % 4` (expands 2→5 px); `BE_ERROR` red; `BE_OFFLINE` dim hollow ring.
- **State glyph** `draw_state_glyph` ([tft_ui.cpp:877-925](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L877-L925)) — the half-duplex I2S bus indicator, by **true runtime priority** (not page): `REC` (red, `s_recording`) > `SPK` (amber, `s_audio_out` — speaker owns I2S, mic deaf) > thinking dots (on `PAGE_THINKING`) > `LIVE` (green mic, shown on IDLE / SPEAKING_* pages where wake word is active). `s_audio_out` is driven by `spk::is_playing()` — the honest bus state that stays true until the audio ring fully drains ([tft_ui.h:107-113](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h#L107-L113), [tutor_lamp.ino:1475](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1475)).
- **Clock** — `--:--` when `s_hh==0xFF || s_mm==0xFF` (unset), else `%02u:%02u` ([tft_ui.cpp:947-952](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L947-L952)).

Setters (`set_wifi`, `set_backend`, `set_recording`, `set_audio_out`, `set_clock`) all early-return if the value is unchanged and otherwise set `s_topbar_dirty = true` so the bar repaints on the next tick ([tft_ui.cpp:404-439](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L404-L439)).

### 3.5 The sin64 table & float-free animation

To keep float math out of the hot 30 fps path, animations use a 64-entry signed sine table `SIN64[64]`, values `round(sin(2π·i/64)·63)` ranging `[-63, 63]` ([tft_ui.cpp:116-122](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L116-L122)). `sin64(i)` masks the index with `& 63`. Cosine is obtained by `sin64(i + 16)` (a 16-index = 90° phase shift). The comment is emphatic that `sin² + cos² = 1` must hold across the table or orbiting dots drift in/out of their circle — a prior hand-tweaked table had off-by-1..3 errors and a missing comma that shifted indices, producing a "wobbly blob" spinner. Used by: greeting spinner, thinking spinner, error pulse, and the speaking side bars.

### 3.6 Page-by-page breakdown

Each page has a one-time `enter_*` (full paint) and a per-frame `tick_*` (partial). `enter_page()` ([tft_ui.cpp:992-1009](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L992-L1009)) sets `s_topbar_dirty = true`, calls `clear_content()` (fills the content rect with `COL_BG`), then dispatches to the page's enter function.

**BOOT** ([tft_ui.cpp:1014-1025](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1014-L1025)) — draws a stylised lamp (two concentric circles + a base rect) and "L U M O S" / "starting up..."; `tick_boot()` is a no-op.

**WIFI_CONNECTING** ([tft_ui.cpp:1030-1054](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1030-L1054)) — "Connecting to" + the SSID (from `s_wifi_ssid_label`, default "WiFi"). The SSID is truncated to 18 chars + ".." if longer than 20 to avoid 320 px overflow at size 2. `tick` animates three dots via `((millis()/300)+i)%3==0`. `set_wifi_connecting_ssid()` copies the SSID into a 33-byte buffer and forces a repaint if the page is visible ([tft_ui.cpp:428-433](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L428-L433)).

**PAIRING** ([tft_ui.cpp:1063-1076](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1063-L1076)) — "Pairing" / "contacting server" + amber animated dots while POSTing `/api/device/register`.

**QR_PAIRING** ([tft_ui.cpp:1081-1168](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1081-L1168)) — landscape split layout: QR on the left column (x=0..160), instructions on the right. Detailed in §6.2. `tick_qr_pairing()` is a no-op (static screen).

**GREETING** ([tft_ui.cpp:1173-1215](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1173-L1215)) — "Hi! I'm Lumos." + "Loading peripherals..." + "(say 'hey lumos' once ready)". `tick_greeting()` runs an orbiting-comet spinner: 8 fixed dots on a circle of radius 20, with a bright cyan "comet head" + fading tail computed via `trail = (head - i + 8) & 7`. Dots behind the tail are painted in `COL_BG` to self-erase (no full clear) — head advances one dot every 2 ticks (`(s_anim_idle >> 1) & 7`).

**IDLE** — the resting face. `enter_idle()` ([tft_ui.cpp:1241-1289](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1241-L1289)) schedules the next blink (`now + 2500`) and gaze change (`now + 1500`), resets the per-eye differential sentinels to force a first paint, then draws (once, never repainted by tick so it can't flicker):
- A **cheerful upward parabola smile** ∪ — for `i` in `[-24, 24]`, `dip = (i²·depth)/(half_w²)` with `depth=18, half_w=24`, drawn as a 3 px-thick cyan stroke ([tft_ui.cpp:1264-1277](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1264-L1277)).
- Two warm rosy cheek circles ([tft_ui.cpp:1281-1282](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1281-L1282)).
- The connection-aware bottom hint via `draw_idle_hint()` ([tft_ui.cpp:1226-1239](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1226-L1239)): `BE_ONLINE` → "say 'hey lumos'"; `BE_CONNECTING` → "Connecting to server" + `(millis()/400)%4` trailing dots (cyan); else "Offline - reconnecting" (amber).

`tick_idle()` ([tft_ui.cpp:1317-1381](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1317-L1381)) does **per-eye differential redraw** — an eye is repainted only when its blink phase or (while open) the gaze changed. Schedulers:
- **Blink**: when idle and `now >= s_next_blink_ms`, start phase 1; ~1-in-4 blinks become a **wink** (`esp_random()%4==0`, then `esp_random()&1` picks left/right). Next blink in `2500 + esp_random()%2500` ms.
- **Gaze**: every `1100 + esp_random()%1800` ms, pick `s_eye_dir_x/y` in {-1,0,+1}; pupil offset `px = dir_x*5`, `py = dir_y*4`.
`draw_one_eye()` ([tft_ui.cpp:1294-1315](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1294-L1315)) renders by blink phase: 1–4 closing (flat lid), 5–6 closed (happy ∪ curve via `dy=(i²)/36`), 7–9 opening (bare eyeball), else open (eyeball + cyan pupil tracking gaze + a white sparkle). During a wink only the winking eye runs phases; the other holds open and keeps tracking. Blink advances one stage per repaint; at phase >9 it resets to 0 and clears the wink.

**LISTENING** ([tft_ui.cpp:1386-1423](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1386-L1423)) — "Listening" header + "press select to cancel". `tick_listening()` renders `LISTEN_BARS = 24` vertical bars from the RMS ring `s_rms_ring[24]`. Bar `i` reads `(s_rms_head + i) % 24`, height `h = (v·band_h)/255`, color `COL_ACCENT` if `v > 150` else `COL_ACCENT_DIM`. **Per-column in-place redraw**: only the empty span above the bar is cleared, then the bar is drawn — the inter-bar gaps are never touched (they keep `COL_BG` from the enter clear), eliminating the global blank-flash. `set_listening_level(float rms_0_1)` clamps to [0,1], scales ×255, and writes into the ring at `s_rms_head` (safe from the capture task) ([tft_ui.cpp:697-702](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L697-L702)).

**THINKING** ([tft_ui.cpp:1428-1452](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1428-L1452)) — caption `s_thinking_label` (reset to "Thinking" each turn). `tick_thinking()` orbits 8 fading dots on a radius-28 circle using `sin64`; every 30 ticks it does a cheap full-band wipe and redraws the caption. The caption can be **escalated in place** — a `TFT_TEXT` prefixed with `\x02` (STX) during THINKING (e.g. "Thinking harder") updates `s_thinking_label` and redraws only the caption, without ever being shown as an answer card (see §3.7 routing).

**IMAGE_PREVIEW** — detailed in §5.1.

**SPEAKING_TEXT** ([tft_ui.cpp:1634-1709](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1634-L1709)) — a rounded card (`fillRoundRect`, bg `0x18A3`) holding the wrapped, paginated answer in the FreeSansBold body font; a bottom hint strip shows scroll position ("UP/DOWN scroll N-M / total") or "press select to dismiss"; side speaker bars are armed. `tick_speaking_text()` only animates the side bars while `s_speaking_active`. Wrapping/pagination is in §9.

**SPEAKING_LATEX** — detailed in §4.5.

**ERROR** ([tft_ui.cpp:2007-2018](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L2007-L2018)) — "Offline" / "checking connection..." + a pulsing red rounded square whose radius is `12 + (sin64(s_anim_idle++) >> 4)`.

### 3.7 Button handling & navigation

`on_button(Button b)` ([tft_ui.cpp:722-760](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L722-L760)) is per-page:

- **SPEAKING_LATEX**: LEFT/RIGHT change `s_latex_idx` (clamped to `[0, s_latex_n)`) for frame scroll. UP/DOWN scroll the text only in combined view (`s_text[0] != '\0'`), clamped to `max_scroll = total - visible`. SELECT → `PAGE_IDLE`. **New long-press toggles**: DOWN-long opens `PAGE_GRAPH` if `graph_ready()`, LEFT-long opens `PAGE_CHEM` if `chem_ready()` (chem wins if both) — see §§4.7–4.8.
- **SPEAKING_TEXT**: UP/DOWN text scroll; SELECT → `PAGE_IDLE`.
- **GRAPH**: 4-dir pans x/y (deferred to release), SELECT / UP-long / DOWN-long zoom (all re-render via `GRAPH_VIEW`), hold-LEFT backs out **one level** — to `PAGE_DOC` if the graph was opened from the scroll-document (`s_graph_from_doc`), else to the legacy `PAGE_SPEAKING_LATEX`. §4.7.
- **CHEM**: LEFT/RIGHT step through cached structures; LEFT-long toggles back to the equation. §4.8.
- **DOC** (new `c699e72`): UP/DOWN scroll (~40% of the viewport per press); RIGHT (a plain tap) opens the on-screen graph's interactive arena; LEFT toggles answer⇄transcript (only if a transcript view exists); SELECT clears the cached document and goes home. §4.9.
- **IMAGE_PREVIEW**: SELECT or LEFT → `PAGE_IDLE`.
- **ERROR**: SELECT → `PAGE_IDLE`.

The `tft_ui::Button` enum (`BTN_UP/DOWN/LEFT/RIGHT/SELECT`, plus `BTN_DOWN_LONG/UP_LONG/LEFT_LONG` and the new (`c699e72`) `BTN_RIGHT_LONG` for the graph/doc pages) ([tft_ui.h:83-101](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h#L83-L101)) is distinct from the hardware `buttons::Button` enum. `tutor_lamp.ino` maps physical button events (including hardware `buttons::BTN_DOWN_LONG/UP_LONG/LEFT_LONG/RIGHT_LONG`) to `tft_ui::on_button(...)` and routes to `tft_settings`/`text_entry` when those own the screen ([tutor_lamp.ino:1175-1223](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1175-L1223)). The hardware buttons are a 5-way ADC ladder decoded in `buttons.cpp`; note the internal IDs do not renumber with the physical mapping (BTN_DOWN is physical Button 3, BTN_RIGHT is Button 4 after a swap) ([buttons.h:50-60](Smart-Tutor-Lamp/tutor_lamp/buttons.h#L50-L60)). `c699e72` fills in the previously-missing `long_variant(BTN_RIGHT) → BTN_RIGHT_LONG` mapping in `buttons.cpp` ([buttons.cpp:25-34](Smart-Tutor-Lamp/tutor_lamp/buttons.cpp#L25-L34)) — RIGHT used to have no long-press variant at all.

**Text routing — `on_tft_text`** ([tft_ui.cpp:603-641](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L603-L641)) is subtle:
- A `\x02`-prefixed note during `PAGE_THINKING` updates the spinner caption in place and is consumed (never an answer card). A real answer never starts with `\x02`.
- Otherwise the text is copied into `s_text[2048]` (truncated to fit), `s_text_scroll_line` reset to 0, and routing decides the page: if a LaTeX frame is already loaded (or we're already on `PAGE_SPEAKING_LATEX`), show the **combined** view (text below the formula); else full-screen text (`PAGE_SPEAKING_TEXT`). A repaint is forced even on a same-page no-op. The comment warns that a plain `TFT_TEXT` during THINKING legitimately IS the answer card and must fall through, or the spinner starves the WS/audio.

### 3.8 External-drawing handoff

When `tft_settings` or `text_entry` wants the whole screen, `tft_ui::set_external_drawing(true)` makes `tick()` a no-op so the external owner owns every pixel — top bar and clock are also suppressed ([tft_ui.h:221-228](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h#L221-L228), [tft_ui.cpp:762-774](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L762-L774)). On `set_external_drawing(false)` it sets `s_page_entered = false` and `s_topbar_dirty = true` so the active page fully repaints on the next tick. `force_full_redraw()` additionally `fillScreen(COL_BG)` ([tft_ui.cpp:776-780](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L776-L780)). `tft_handle()` returns the singleton `TFT_eSPI&` for the external modules to draw into ([tft_ui.cpp:782](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L782)).

---

## 4. On-device Equation / Graph / Chemistry Viewer

**The lamp does not render LaTeX (or graphs, or chemistry).** The backend's `Latex_engine_tft.py` does matplotlib → PIL → RGB565 → big-endian byte-swap (BGR color order) → optional multi-frame scroll generation, then ships a concatenated frame stream over WebSocket. The ESP32 receives finished pixels and pushes them via SPI ([tft_display.h:3-22](Smart-Tutor-Lamp/tutor_lamp/tft_display.h#L3-L22)). §§4.1–4.5 cover the classic raw-RGB565 equation path; §4.6 covers the newer JPEG-compressed equation path, and §§4.7–4.8 the interactive graph and chemistry pages — all still backend-rendered pixels, just compressed and (for graphs) re-rendered on demand.

### 4.1 Wire format & inner header

A TFT_FRAME payload (after `net_ws` strips its 4-byte outer header) begins with a 6-byte inner header:

```
┌─────────┬─────────┬──────────┬──────┬─────────────────────────┬───────────────┐
│ W (BE)  │ H (BE)  │ nFrames  │ n_eq │ RGB565 pixels × nFrames  │ per-eq trailer│
│  u16    │  u16    │   u8     │  u8  │ (each frame = W*H*2)     │ n_eq bytes    │
└─────────┴─────────┴──────────┴──────┴─────────────────────────┴───────────────┘
  payload[0..1] payload[2..3] payload[4] payload[5]
```

The header is decoded big-endian: `W = (payload[0]<<8)|payload[1]`, `H = (payload[2]<<8)|payload[3]`, `nFrames = payload[4]`, `n_eq = payload[5]` ([tft_ui.cpp:471-474](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L471-L474)). Byte 5 was "reserved" in the legacy `tft_display` ([tft_display.cpp:38-41](Smart-Tutor-Lamp/tutor_lamp/tft_display.cpp#L38-L41)); `tft_ui` repurposes it as the equation count.

- `nFrames == 1` → the equation fits the screen, single static paint.
- `nFrames > 1` → wider equation; the server pre-generated each scroll step. The legacy `tft_display` plays them automatically with a 30 ms inter-frame delay (`SCROLL_FRAME_MS`, ~33 fps) ([tft_display.cpp:11](Smart-Tutor-Lamp/tutor_lamp/tft_display.cpp#L11), [tft_display.cpp:62-71](Smart-Tutor-Lamp/tutor_lamp/tft_display.cpp#L62-L71)). The current `tft_ui` viewer scrolls **manually** via ◀/▶ buttons instead.

`on_tft_frame()` ([tft_ui.cpp:469-494](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L469-L494)) validates: non-null payload, `len >= 6`, allocated `s_latex`, `W/H/n != 0`, and an **exact** size match `expected = 6 + W*H*2*n + n_eq == len`, and `expected <= LATEX_CACHE_BYTES`. On success it `memcpy`s the whole payload into `s_latex`, records `s_latex_W/H/n`, resets `s_latex_idx = 0`, parses the equation table, clears the loading skeleton flag, arms `s_latex_log_draw`, and forces `PAGE_SPEAKING_LATEX`.

Pixels are pushed verbatim with `pushColors(..., swap=false)` because they are already RGB565 big-endian byte-swapped (BGR) per the engine — re-swapping would corrupt color ([tft_display.cpp:66-68](Smart-Tutor-Lamp/tutor_lamp/tft_display.cpp#L66-L68), [tft_ui.cpp:1745-1748](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1745-L1748)).

### 4.2 Chunked accumulator path

A full-frame 320×240 LaTeX image is ~153 KB and a multi-frame pack can be megabytes, far larger than a single WebSocket frame. The backend therefore streams `FRAME_TFT_PART (0x23)` chunks and a final `FRAME_TFT_FRAME (0x20)` terminator. To avoid a second 3 MB PSRAM buffer, the `.ino` writes chunks **directly** into the `tft_ui` cache via `get_latex_buffer()` / `get_latex_buffer_capacity()` ([tft_ui.cpp:497-498](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L497-L498)), tracking `s_chunked_tft_len`, then calls `commit_chunked_latex(total_len)` ([tft_ui.cpp:500-533](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L500-L533)). `commit_chunked_latex` re-parses the inner header from offset 0 (no memcpy — data is already in place), validates the same way as `on_tft_frame`, parses the equation table, and transitions to `PAGE_SPEAKING_LATEX`. The `.ino` dispatch is at [tutor_lamp.ino:584-666](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L584-L666).

The frame-type constants live in `net_ws.h`: `FRAME_TFT_FRAME = 0x20`, `FRAME_TFT_TEXT = 0x21`, `FRAME_TFT_CLEAR = 0x22`, `FRAME_TFT_PART = 0x23`, `FRAME_TFT_LATEX_LOADING = 0x24`, `FRAME_TFT_APPEND = 0x25`, `FRAME_TFT_APPEND_BEGIN = 0x26` ([net_ws.h:66-72](Smart-Tutor-Lamp/tutor_lamp/net_ws.h#L66-L72)). As of `e1de15a` the enum adds the compressed/graph/chem terminators `FRAME_TFT_IMAGE_JPEG = 0x27`, `FRAME_TFT_IMAGE_PART = 0x28`, `FRAME_TFT_GRAPH_JPEG = 0x29`, `FRAME_TFT_CHEM_JPEG = 0x2A` (all share the `TFT_IMAGE_PART` chunk carrier) — see §§4.6–4.8 ([net_ws.h:73-77](Smart-Tutor-Lamp/tutor_lamp/net_ws.h#L73-L77)).

### 4.3 APPEND splice protocol

To avoid re-sending the entire cumulative pack for equation 2+ (~70 KB vs ~140 KB on a capped WAN), the backend can ship only the *new* frames. The cumulative pack has a byte-prefix property: the committed pixels are exactly the prefix of the larger pack, so the new frames splice in cleanly ([tft_ui.h:157-177](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h#L157-L177)).

- `latex_append_base()` ([tft_ui.cpp:535-544](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L535-L544)) returns where appended PARTs must start writing: `6 + W*H*2*n` — the end of the committed PIXEL region (where the old trailer sat, which the append overwrites). Returns 0 if there is no committed pack, signalling the `.ino` to discard the append stream.
- `commit_append(seg_off, seg_len)` ([tft_ui.cpp:546-601](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L546-L601)) — the segment at `seg_off` holds `[6 B header with TOTAL nFrames+nEq][new frames' pixels][full new trailer]`. It validates: matching W/H, `n_tot > s_latex_n`, and exact size `expected = 6 + (n_tot - s_latex_n)*fb + neq_tot == seg_len`. Then it **`memmove`s** the new pixels+trailer 6 bytes left (overlapping regions → memmove not memcpy) so the new pixels butt against the committed pixels, patches header bytes `[4]=n_tot`, `[5]=neq_tot`, and re-commits.
- **View preservation**: an append must not yank the user's view. It captures `page_before` and `keep_idx = s_latex_idx` before the re-commit (which would snap to eq1 and force `PAGE_SPEAKING_LATEX`), then restores both — if the user had moved on (idle/listening), the data commits silently without dragging them back ([tft_ui.cpp:590-599](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L590-L599)). Any validation failure leaves the committed pack untouched and returns false.

### 4.4 Multi-equation grouping

The backend may pack multiple equations' scroll frames into one flat frame list plus a per-equation frame-count trailer (one byte per equation, `n_eq` bytes total). `parse_latex_eq_table(trailer, n_eq, n_frames)` ([tft_ui.cpp:444-460](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L444-L460)) turns this into start-frame offsets `s_latex_eq_start[]`: it accumulates the trailer bytes into prefix sums, and only accepts the table if `2 <= n_eq <= MAX_LATEX_EQ (12)` and the accumulated total equals `n_frames`. Any absence/inconsistency falls back to a single equation spanning all frames (`s_latex_eq_n = 1`), so legacy single-equation payloads and malformed trailers still work.

`latex_cur_eq()` ([tft_ui.cpp:462-467](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L462-L467)) returns the 0-based equation that the current `s_latex_idx` belongs to by linear scan of the start offsets. Navigation stays plain frame-by-frame (one LEFT/RIGHT press crosses an equation boundary in one step), but the UI surfaces "Eq N/M", page-within-eq, and `‹`/`«` `›`/`»` boundary cues (see §4.5).

### 4.5 Painting a frame & the loading skeleton

`draw_latex_frame_area(idx, top_y, max_h)` ([tft_ui.cpp:1718-1749](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1718-L1749)) is the core painter, used by both full-screen and combined views. It computes the frame's byte offset `6 + idx*W*H*2`, clamps paint width to `min(W, SCREEN_W)` and height to `min(H, max_h)`, clears the slot first (so prior pixels/side bars don't peek), then `setAddrWindow(0, top_y, paint_w, paint_h)` + `pushColors(base, paint_w*paint_h, swap=false)`. If a frame is taller than its slot it clips the bottom and logs a throttled warning (once / 2 s) — the comment notes the backend's `EQ_HEIGHT_MAX_PX = 90` should make this impossible (the equation lives in source rows 10–99 of the 240-row frame, inside the 110 px combined slot).

`draw_latex_nav_cues(y0)` ([tft_ui.cpp:1756-1785](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1756-L1785)) draws edge chevrons in the blank top strip (rows 0–9, above the equation): `>`/`<` (dim) = more frames within this equation; `>>`/`<<` (accent) = hop to the next/prev equation. Nothing is drawn on an edge with no destination.

`draw_latex_frame(idx)` ([tft_ui.cpp:1789-1816](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1789-L1816)) is the **full-screen latex-only** view: paints into the whole content area above the hint strip, draws nav cues, and a bottom hint ("< prev | next > | i/n" when `s_latex_n > 1`, else "press select to dismiss").

`draw_combined_latex_and_text()` ([tft_ui.cpp:1821-1936](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1821-L1936)) is the **combined** view. The vertical budget is the single source of truth `LATEX_AREA_H = 110` px, mirrored on the backend as `LAMP_COMBINED_LATEX_AREA_H_PX = 110` and `EQ_HEIGHT_MAX_PX = 90`. Layout math (240 px landscape): 20 px status bar + 110 px latex + 2 px divider + ~86 px text card (4 lines) + 18 px hint = 236 px (4 px slack). It paints the latex into the top slot, a divider HLine, then a rounded text card (`fillRoundRect`, bg `0x18A3`) holding the wrapped/paginated body text (FreeSansBold), and an equation-aware hint strip that prioritizes the actionable boundary cue ("Eq N/M  R: next Eq X") over the generic controls line.

**Loading skeleton.** Because ~75 PART chunks can take 1–3 s to stream, `FRAME_TFT_LATEX_LOADING (0x24)` arms a placeholder. `set_latex_loading(true)` ([tft_ui.cpp:706-720](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L706-L720)) records the start time, forces `PAGE_SPEAKING_LATEX` (reserving the top half), and forces a repaint. The skeleton is split to kill flicker: `enter_speaking_latex()` / `draw_latex_skeleton_base()` ([tft_ui.cpp:1942-1957](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1942-L1957)) paint the static label "rendering equation..." and clear the zone **once**, while `tick_speaking_latex()` ([tft_ui.cpp:1977-2002](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1977-L2002)) animates **only** three pulsing bars in place (widths 70%/90%/50% of `SKEL_W`), color by a travelling-shimmer phase `(millis()-start)/50 & 63` fed through `sin64`. The old code re-filled the whole zone + label every tick (the strobe). `on_tft_frame`/`commit_chunked_latex` clear `s_latex_loading` when the real pixels land, naturally overwriting the skeleton. `on_tft_clear` also drops the flag so a server-side render failure (TFT_CLEAR) doesn't leave the skeleton pulsing forever (a bug found by `backend/tests/test_pipeline_stress.py`'s "forbidden LaTeX" case) ([tft_ui.cpp:643-654](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L643-L654)).

`enter_speaking_latex()` ([tft_ui.cpp:1948-1976](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1948-L1976)) chooses: skeleton (if loading and no pixels yet) → combined view (if `s_text` populated) → full-screen latex. When `s_latex_log_draw` is set it times and logs the draw (`[latex-rx] draw=..ms`), then self-clears so only the post-commit paint is measured (not L/R nav redraws).

### 4.6 Compressed (JPEG) equations

New in `aa2143c` (the "compression optimization"): instead of shipping ~70 KB of raw RGB565 per equation, the backend can send a **grayscale JPEG** of the same frame (~3–15 KB) when `TFT_IMAGE_CODEC=jpeg`. The wire path reuses the same chunk carrier as raw frames but with distinct terminators: `TFT_IMAGE_PART (0x28)` chunks accumulate into a dedicated buffer, and the `TFT_IMAGE_JPEG (0x27)` terminator triggers the decode.

- **Accumulator reuses PSRAM**: `get_eq_jpeg_buffer()` / `get_eq_jpeg_buffer_capacity()` ([tft_ui.cpp:625-626](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L625-L626)) return the **200 KB camera-preview buffer** `s_image` — safe because the camera capture/preview happens during `MODE_COMMAND`, *before* the speaking turn that ships the equation, so the two never overlap in time (no extra PSRAM allocated).
- **Decode**: `on_tft_image_jpeg(payload, len)` ([tft_ui.cpp:574-618](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L574-L618)) reads the 4-byte inner header `[u16 W][u16 H]`, then decodes the JPEG via the existing `TJpg_Decoder` **straight into `s_latex`** — the exact buffer a raw `TFT_FRAME` fills — so the whole combined-view/scroll/append machinery (§§4.2–4.5) renders it unchanged (`nFrames = 1`). A decode failure logs and drops.
- **Backward-compatible**: a firmware built without this case simply drops `0x27`/`0x28` (no equation shows), so the backend must only enable JPEG when the fleet supports it. Dispatch is in the `.ino` frame switch ([tutor_lamp.ino:643-685](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L643-L685)).

### 4.7 Interactive graph page (`PAGE_GRAPH`)

New in `e1de15a`. The backend renders a function graph to a **full-screen color JPEG** and ships it via `TFT_IMAGE_PART` chunks + a `TFT_GRAPH_JPEG (0x29)` terminator whose payload is `[f32 x0][f32 x1][f32 y0][f32 y1][color JPEG]` (the window, all big-endian). `GRAPH_ENABLED` gates it; a non-graph build drops `0x29`.

- **Receive**: `on_tft_graph_jpeg(payload, len)` ([tft_ui.cpp:641-659](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L641-L659)) stores the JPEG in `s_image` (reusing the camera-preview buffer, memmoving off the 16-byte window prefix), remembers the `[x0,x1,y0,y1]` window, and sets `s_graph_ready`. It does **not** switch pages on its own — the next DOWN-long from `PAGE_SPEAKING_LATEX` opens `PAGE_GRAPH` (`graph_ready()` gates the toggle). If already viewing the graph, it forces a repaint with the fresh render.
- **Pan / zoom = server round-trip, no on-device math**: a 4-dir press pans x and y; SELECT (and UP-long/DOWN-long) zoom. Pans are *deferred* — `graph_pan(fx, fy)` accumulates a fractional delta and sets `s_graph_pan_pending`; the `.ino` calls `graph_commit_pan()` only on button **release** (`graph_pan_pending() && buttons::held()==NONE`), so a tap pans on release while a hold cleanly zooms/toggles instead of pan-then-zooming ([tft_ui.cpp:706-719](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L706-L719)). A committed window change sets `s_graph_view_dirty`; `take_graph_view_request(gid, x0,x1,y0,y1)` hands it to the `.ino` **once**, which sends it as `FRAME_GRAPH_VIEW (0x09, now 17 B)` — a new leading `graph_id` byte plus the 16-byte `[x0][x1][y0][y1]` window (both big-endian). The backend re-renders the *cached* graph spec keyed by `graph_id` over the new window and returns a fresh `TFT_GRAPH_JPEG` — exact and low-memory, since the lamp never evaluates the formula.
- **Multiple graphs / opened from the scroll-document (new `c699e72`)**: `graph_id` is the doc block index of the graph being viewed (0 for the legacy single-graph path), so a turn whose scroll-document carries several graphs re-renders the *right* one. `s_graph_from_doc` records whether the arena was entered from `PAGE_DOC` (via `focus_visible_graph()`, §4.9) or from the legacy `PAGE_SPEAKING_LATEX` hold-LEFT path, so hold-LEFT in the arena knows which page to return to. While the crisp full-screen re-render is in flight, `enter_graph()` shows the doc's own inline figure JPEG (`s_focus_jpeg_off/len`, already on-device) as an instant placeholder with a "opening graph..." caption instead of a blank "rendering graph..." screen ([tft_ui.cpp:1002-1030](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1002-L1030)).

### 4.8 Chemistry structures page (`PAGE_CHEM`)

New in `e1de15a`. The backend renders (RDKit) up to **4 chemistry-structure steps** as full-screen color JPEGs, each shipped via `TFT_IMAGE_PART` chunks + a `TFT_CHEM_JPEG (0x2A)` terminator whose payload is `[u8 step_index][u8 step_count][color JPEG]`. `CHEM_STRUCTURE_ENABLED` gates it.

- **Multi-step cache**: `on_tft_chem_jpeg(payload, len)` ([tft_ui.cpp:667-692](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L667-L692)) validates `count ∈ [1, MAX_CHEM=4]`, `idx < count`, and that steps arrive **in order** (`idx == s_chem_n`) — step 0 resets the cache. Each step's JPEG is appended into a dedicated PSRAM buffer (`s_chem`, offsets tracked in `s_chem_off[]`); when the last step lands it sets `s_chem_ready` and shows step 0. Out-of-order/overflow steps are dropped with a log.
- **Navigation is instant (no round-trip)**: LEFT-long from `PAGE_SPEAKING_LATEX` opens `PAGE_CHEM` (chem takes priority over graph if both are ready — [tft_ui.cpp:1042-1043](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1042-L1043)); L/R step through the cached JPEGs on-device. Backward-compatible: a build without this case drops `0x2A`.

Both graph and chem pages are **static** once painted — `tick_graph`/`tick_chem` do no per-frame work ([tft_ui.cpp:1142-1143](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1142-L1143)).

### 4.9 Scroll-document page (`PAGE_DOC` / `TFT_SCROLL_DOC`)

New in `c699e72` ("FIRST ITERATION COMPLETE"). `TFT_SCROLL_DOC` replaces the old "combined view / separate frames" answer model with **one continuous vertical document**: text, equations, graphs, and chemistry structures stacked in reading order and scrolled with UP/DOWN — "like scrolling a social feed," per the design rationale in the new `tutor_lamp/TFT_UX_FINDINGS.md`. It is flag-gated and additive: a firmware/backend pair without it is byte-identical to before, since the two new frame types are simply never sent/parsed.

**Wire format — two new frame types** in `net_ws.h` ([net_ws.h:78-79](Smart-Tutor-Lamp/tutor_lamp/net_ws.h#L78-L79)):
- `FRAME_TFT_DOC_MANIFEST (0x2B)` — terminator of a chunked **manifest**: `[u8 version][u8 kind][u16 n_blocks]` then, per block, `[u8 type]` followed by either a **text** block `[u16 color][u16 len][utf8 bytes]` or an **element** block `[u16 height]` (and, for a graph element, the `[f32 x0][f32 x1][f32 y0][f32 y1]` window right after the height). `kind` 0 = the main answer document, 1 = the spoken transcript.
- `FRAME_TFT_DOC_ELEM (0x2C)` — terminator of a chunked **element JPEG**: `[u16 block_index][color JPEG]`.

Both share the same `TFT_IMAGE_PART (0x28)` chunk carrier as graphs/chemistry. The `.ino`'s frame switch accumulates either terminator into the reused `get_eq_jpeg_buffer()` (the 200 KB camera-preview buffer) exactly like `TFT_DOC_MANIFEST`/`TFT_DOC_ELEM`'s siblings, then dispatches to `tft_ui::on_tft_doc_manifest()` / `on_tft_doc_element()` ([tutor_lamp.ino:732-762](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L732-L762)). Firmware without these cases simply drops `0x2B`/`0x2C`.

**Block model (`tft_ui.cpp`).** Two independent views (`v = 0` main, `v = 1` transcript), each up to `MAX_DOC_BLOCKS = 48` blocks in a `DocBlock { type, y, h, text_off/len, color, jpeg_off/len }` array; text bytes for both views share a 3 KB pool (`DOC_TEXT_CAP`), element JPEGs are cached in **the `s_latex` 3 MiB arena** (`s_doc_pool = s_latex` — repurposed because the LaTeX page is unused in doc mode) ([tft_ui.cpp:419-455](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L419-L455)).

- `on_tft_doc_manifest(p, len)` ([tft_ui.cpp:761-808](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L761-L808)) parses the block list, capping element heights to `2×SCREEN_H` so the `int16_t` stacking math (`y += h`) can't overflow on a malformed/huge value. A `kind 0` manifest **resets** the text/JPEG pools and the focusable-graph list, then shows `PAGE_DOC`; a `kind 1` manifest (transcript) only forces a repaint if the transcript is the view currently on screen. Graph-type elements also register a `DocGraph { block, x0, x1, y0, y1 }` (up to `MAX_DOC_GRAPHS = 4`) so they can later be focused into the interactive arena.
- `on_tft_doc_element(p, len)` ([tft_ui.cpp:810-821](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L810-L821)) appends one element's JPEG into `s_doc_pool` and records its offset/length on the matching block, filling it in as it streams — the still-empty blocks render as a grey skeleton rectangle until their JPEG lands (see `enter_doc()` below).
- `enter_doc()` ([tft_ui.cpp:1044-1120](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1044-L1120)) is a two-pass layout: **pass 1** stacks every block (`doc_wrap()` word-wraps text to the content width using the *current* font, mirroring `wrap_text_px`'s greedy line-break algorithm; element blocks use their given height) to compute `y`/`h` and the document's total height, clamping the scroll offset; **pass 2** draws only the blocks intersecting the visible window — text via `drawString` per wrapped line, ready elements via `TJpgDec.drawJpg` (clipped to the content rect via `s_doc_clip_top/bot`, a new pair of module-level clip bounds `tjpg_block_cb` checks so a scrolled figure can never paint over the top status bar — [tft_ui.cpp:304-311](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L304-L311), [tft_ui.cpp:367-375](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L367-L375)), not-yet-arrived elements as a filled skeleton rect. A right-edge scrollbar is drawn when the document exceeds the viewport. Everything derives from `SCREEN_W/H`, so it reflows for any panel size. The hint strip reads "UP/DN scroll  R: graph  L: text  SEL: home" when the doc has a focusable graph, else "UP/DN scroll   L: spoken   SEL: home".
- **Buttons** (`on_button`, `PAGE_DOC` case, [tft_ui.cpp:1390-1418](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1390-L1418)): UP/DOWN scroll by ~40% of the viewport per press (clamped in `enter_doc`); **RIGHT is a plain tap** (not a hold) that calls `focus_visible_graph()` to open the graph currently in view; LEFT (only if the transcript view has content) toggles `s_doc_view` between main/transcript; SELECT clears the whole cached document (both views, both pools) and returns to `PAGE_IDLE`. The design note in `TFT_UX_FINDINGS.md`/`NAVIGATION.md` is explicit that RIGHT (graph) and LEFT (transcript) are **deliberately different buttons** — a hold always fires a tap first, so binding "open graph" to a tap means it also fires reliably on a hold, and it can never be confused with the transcript toggle.

**Focusing a graph from the document.** `find_visible_graph()` ([tft_ui.cpp:892-908](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L892-L908)) picks whichever registered `DocGraph` is on-screen with its vertical centre nearest the viewport centre (falling back to the sole graph if there's only one, even if scrolled out of view; otherwise it asks the student to scroll one into view rather than guess). `focus_visible_graph()` ([tft_ui.cpp:914-937](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L914-L937)) then sets `s_graph_id`/window from that block, arms the inline-JPEG placeholder, calls `graph_queue()` so the `.ino` sends `FRAME_GRAPH_VIEW` for a crisp re-render, and switches to `PAGE_GRAPH` (§4.7 covers the arena itself and the from-doc back-navigation). If the manifest registered zero graphs (an old backend that hasn't deployed the per-graph-window change), it logs a diagnostic instead of silently no-op'ing.

**Turn boundaries.** `on_tft_clear()` drops the whole document cache (`s_doc_ready = false`, both views' block counts, scroll position) on a new turn or a give-up, exactly like the graph/chem caches ([tft_ui.cpp:1280-1286](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1280-L1286)).

---

## 5. Image Decoding & Preview

### 5.1 `tft_ui` integrated preview + display transform

`on_image_jpeg(jpeg, len)` ([tft_ui.cpp:656-673](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L656-L673)) validates (`jpeg`, `s_image` allocated, `0 < len <= IMAGE_CACHE_BYTES = 200 KB`), `memcpy`s into `s_image`, and forces `PAGE_IMAGE_PREVIEW` (re-entering even if already there, e.g. a second capture).

`enter_image_preview()` ([tft_ui.cpp:1457-1522](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1457-L1522)):
1. Clears the content area first (critical — otherwise the LISTENING waveform leaks around the centered JPEG).
2. Probes size via `TJpgDec.getJpgSize`; on failure draws "bad image".
3. Picks the smallest scale in `{1,2,4,8}` such that `W/s <= SCREEN_W && H/s <= CONTENT_H` ([tft_ui.cpp:1481-1486](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1481-L1486)).
4. Centers the scaled image: `off_x = (SCREEN_W - out_w)/2`, `off_y = CONTENT_Y0 + (CONTENT_H - out_h)/2`.
5. **Arms the display-only transform** `s_jpg_xform = PREVIEW_XFORM`, decodes via `TJpgDec.drawJpg`, then disarms (`PV_NONE`) so no other JPEG draw is affected. A serial line prints the active transform so a stale flash is detectable.
6. For a single-shot turn (`s_cap_total <= 1` and no overlay drawn) shows "Captured image — auto-dismiss in 5 s".

**The display transform** is DISPLAY-ONLY and never touches the bytes shipped to the backend/LLM (those stay upright). `enum PreviewXform { PV_NONE, PV_ROT180, PV_FLIP_V, PV_FLIP_H }`, with `PREVIEW_XFORM = PV_FLIP_H` for this build ([tft_ui.cpp:187-191](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L187-L191)). The OV5640 is configured with `hmirror=1` (`camera.cpp set_hmirror`), so the captured frame is mirrored left↔right; a horizontal flip un-mirrors the preview. The block callback `tjpg_block_cb` ([tft_ui.cpp:312-344](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L312-L344)) reorients each 16×16 MCU block in-place and mirrors it to the matching corner of the on-screen rect:
- `PV_ROT180` — reverse the whole row-major block (both axes).
- `PV_FLIP_V` — reverse the ROW order (top↔bottom).
- `PV_FLIP_H` — reverse within each row (left↔right).
Then `x`/`y` are recomputed to the mirrored corner and `pushImage` clips off-screen. With `PV_NONE` it does a plain `pushImage` with a `y >= SCREEN_H` guard.

**Multi-image capture countdown overlay.** `set_capture_countdown(taken, total, remaining_pct, remaining_secs)` ([tft_ui.cpp:675-689](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L675-L689)) stages state; `total <= 1` or `taken == 0` resets the repaint sentinels. `tick_image_preview()` ([tft_ui.cpp:1523-1578](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1523-L1578)) draws, under the photo, "Photo N/M   next photo in Xs" + a **reverse-depleting** bar (220 px wide). It is flicker-free: the text repaints only when the shot number or whole-second value changes; the bar repaints only its moving edge (`fill = bw*remaining/100`); on the last shot (`total<=1`) it erases the strip once. `.ino` primes it at turn start with `taken=0`, updates between shots, and clears with `(0,0,0,0)` ([tutor_lamp.ino:1087-1123](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1087-L1123)).

### 5.2 `image_viewer` (debug viewer)

A standalone debug JPEG viewer, compile-gated by `ENABLE_IMAGE_VIEWER` (default 1; set 0 → all functions become no-op inline stubs and the `.ino` still compiles) ([image_viewer.h:31-71](Smart-Tutor-Lamp/tutor_lamp/image_viewer.h#L31-L71)). It owns its own `TFT_eSPI` at rotation 3 and reserves a 14 px bottom status bar.

- `begin()` ([image_viewer.cpp:73-86](Smart-Tutor-Lamp/tutor_lamp/image_viewer.cpp#L73-L86)) — init, set `s_status_y = height - STATUS_HEIGHT`, configure TJpgDec (`setSwapBytes(true)`).
- `show_jpeg()` ([image_viewer.cpp:88-130](Smart-Tutor-Lamp/tutor_lamp/image_viewer.cpp#L88-L130)) — probe → `pick_scale` (smallest of {1,2,4,8} that fits the image area excluding the status bar) → center → decode + push via `tjpg_block_cb` (which guards `y >= s_status_y`) → `draw_letterbox` (fills the four black margins) → status line "WxH 1/scale  N B  T ms".
- `pick_scale` ([image_viewer.cpp:59-67](Smart-Tutor-Lamp/tutor_lamp/image_viewer.cpp#L59-L67)) and `draw_letterbox` ([image_viewer.cpp:36-55](Smart-Tutor-Lamp/tutor_lamp/image_viewer.cpp#L36-L55)) are the same idea as the `tft_ui` preview, minus the orientation transform.
- `set_enabled(false)` clears the screen and makes `show_jpeg` a no-op. Decode runs from `loop()` only so the priority-8 capture task is never blocked.

### 5.3 `tft_display` (legacy frame painter)

The original server-frame painter, now superseded by `tft_ui::on_tft_frame`. It owns its own `TFT_eSPI` at rotation 3 ([tft_display.cpp:10-13](Smart-Tutor-Lamp/tutor_lamp/tft_display.cpp#L10-L13)).
- `render_frame(payload, len)` ([tft_display.cpp:30-79](Smart-Tutor-Lamp/tutor_lamp/tft_display.cpp#L30-L79)) — decodes the inner header (treating byte 5 as reserved), validates `len == 6 + W*H*2*nFrames`, and paints each frame with `setAddrWindow` + `pushColors(swap=false)`, sleeping `SCROLL_FRAME_MS = 30` between frames for **automatic** scroll playback.
- `render_text(text, len)` ([tft_display.cpp:81-95](Smart-Tutor-Lamp/tutor_lamp/tft_display.cpp#L81-L95)) — built-in font at size 2, handling `\r`/`\n`.
- `clear()` blacks the screen.

---

## 6. QR Code Generation & Pairing

### 6.1 `RICqrcode.c` algorithm

`RICqrcode.c` is Richard Moore's QR-Code generator (MIT, inspired by Nayuki), vendored into the sketch to bypass an ESP32 core 3.x name collision with ESP-IDF's `esp_qrcode.h` ([tft_qr.cpp:6-11](Smart-Tutor-Lamp/tutor_lamp/tft_qr.cpp#L6-L11)). The public API ([RICqrcode.h:81-87](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.h#L81-L87)): `qrcode_getBufferSize(version)`, `qrcode_initText/Bytes(...)`, `qrcode_getModule(qr,x,y)`. The `QRCode` struct holds `version, size, ecc, mode, mask, *modules` ([RICqrcode.h:65-72](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.h#L65-L72)). ECC levels: `ECC_LOW=0, MEDIUM=1, QUARTILE=2, HIGH=3` ([RICqrcode.h:52-55](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.h#L52-L55)). `size = version*4 + 17` (version 7 → 45×45 modules).

The full pipeline (`qrcode_initBytes`, [RICqrcode.c:775-849](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.c#L775-L849)):

1. **Mode selection & data encoding** (`encodeDataCodewords`, [RICqrcode.c:629-687](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.c#L629-L687)) — picks the most compact of NUMERIC (10 bits/3 digits), ALPHANUMERIC (11 bits/2 chars, 45-char set), or BYTE (8 bits/char). Pairing URLs use the alphanumeric set where possible. The 4-bit mode indicator + a version-dependent character-count field (`getModeBits`, [RICqrcode.c:146-163](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.c#L146-L163)) precede the payload.
2. **Padding** — terminator (≤4 bits), byte-align, then alternate pad bytes `0xEC`/`0x11` to fill `dataCapacity` ([RICqrcode.c:803-812](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.c#L803-L812)).
3. **Reed-Solomon error correction** (`performErrorCorrection`, [RICqrcode.c:689-761](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.c#L689-L761)) over GF(2⁸) with primitive polynomial `0x11D`. `rs_init` builds the generator polynomial; `rs_getRemainder` does polynomial division; data and ECC blocks are interleaved per the spec. Block/codeword counts come from the lookup tables `NUM_ERROR_CORRECTION_CODEWORDS`, `NUM_ERROR_CORRECTION_BLOCKS`, `NUM_RAW_DATA_MODULES` (40 versions × 4 ECC) ([RICqrcode.c:41-65](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.c#L41-L65)).
4. **Function patterns** (`drawFunctionPatterns`, [RICqrcode.c:381-436](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.c#L381-L436)) — timing patterns, three 9×9 finder patterns, alignment patterns (count `version/7 + 2`), format & version bits. Finder uses the Chebyshev norm `dist = max(|i|,|j|)` for the ring pattern.
5. **Data placement** (`drawCodewords`, [RICqrcode.c:441-469](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.c#L441-L469)) — the zig-zag scan up/down two-column pairs, skipping function modules and column 6.
6. **Mask selection** — all 8 masks are tried; for each, `applyMask` XORs non-function modules per the mask formula (e.g. mask 0 = `(x+y)%2==0`), `getPenaltyScore` ([RICqrcode.c:483-570](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.c#L483-L570)) computes the standard penalty (runs of ≥5 N1=3, 2×2 blocks N2=3, finder-like 11-bit patterns `0x05D`/`0x5D0` N3=40, dark/light imbalance N4=10), and the lowest-penalty mask wins. The final format bits are rewritten and the chosen mask applied ([RICqrcode.c:826-848](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.c#L826-L848)).

Modules are stored as a packed bit grid (`BitBucket`); `qrcode_getModule` ([RICqrcode.c:855-862](Smart-Tutor-Lamp/tutor_lamp/RICqrcode.c#L855-L862)) returns one bit at `offset = y*size + x`.

### 6.2 `tft_qr` and `tft_ui` QR rendering

Both renderers use **version 7 / ECC_LOW** (`QR_VERSION = 7` → up to ~154 alphanumeric chars, 45×45 modules).

**`tft_qr::show(url, caption)`** ([tft_qr.cpp:41-134](Smart-Tutor-Lamp/tutor_lamp/tft_qr.cpp#L41-L134)) — portrait (`TFT_ROT=0`) for maximum QR area. Computes `scale = box/qr.size` where `box` fits the narrower dimension minus padding and caption reserve; **returns false if `scale < 2` (unreadable)** and warns at `scale < 3`. Paints a white background, draws each module as a `scale×scale` black/white rect, then the caption at text size 3 (`~18 px/char`) and a "Scan to pair this lamp" hint. If `RICqrcode.h` is absent (`TFT_QR_HAS_LIB == 0`), it falls back to a text-only screen showing the URL so pairing can still be completed by code.

**`tft_ui` QR page** `enter_qr_pairing()` ([tft_ui.cpp:1081-1167](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1081-L1167)) — landscape split: QR in the left 160 px column, instructions on the right. `QR_MAX_PX = 150`; `scale = max(2, QR_MAX_PX / qr.size)`. A white rounded card sits behind the QR; modules are drawn as `scale×scale` rects. The right column shows "Pair Lumos" (size 2), the big cyan `s_qr_code` (size 3), and numbered steps ("1. Scan the QR / 2. Sign in to Lumos / 3. Tap 'Link'"). If `s_qr_url` is empty it shows "Preparing pairing..."; if `qrcode_initText` fails, "QR init failed"; if the library is missing (`TFT_UI_HAS_QRCODE == 0`) it shows a URL/instructions fallback. `set_qr_pairing(url, code)` ([tft_ui.cpp:691-695](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L691-L695)) copies the strings (160 B URL, 16 B code) and switches to `PAGE_QR_PAIRING`.

Library presence is detected at compile time with `__has_include("RICqrcode.h")` → `TFT_UI_HAS_QRCODE` / `TFT_QR_HAS_LIB` ([tft_ui.cpp:34-39](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L34-L39), [tft_qr.cpp:12-17](Smart-Tutor-Lamp/tutor_lamp/tft_qr.cpp#L12-L17)).

---

## 7. Settings Page: `tft_settings`

`tft_settings` ([tft_settings.cpp](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp)) is a sub-screen state machine that borrows `tft_ui::tft_handle()` while `tft_ui::set_external_drawing(true)` is set. It is opened on a long SELECT while idle ([tutor_lamp.ino:1183-1194](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1183-L1194)).

**Menu items** (`enum Item`, display order = enum order, [tft_settings.cpp:36-58](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp#L36-L58)): Volume, Photos/turn, Photo timer, WiFi setup, Forget WiFi, Re-pair lamp, Exit (7 rows; `ROW_H = 28`, `HEADER_H = 28`, sized to fit 240 px).

**Sub-states** (`enum Sub`, [tft_settings.cpp:73-79](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp#L73-L79)): `SUB_LIST`, `SUB_CONFIRM`, `SUB_WIFI_SSID_ENTRY`, `SUB_WIFI_PASS_ENTRY`, `SUB_DONE_REBOOT`.

**List rendering** `draw_list(full)` ([tft_settings.cpp:204-235](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp#L204-L235)) is differential: a full paint only on first entry; otherwise it repaints exactly the two affected rows on a selection move, or only the selected row when an L/R-adjustable value changed (`cur_val != s_last_drawn_val`). This is the anti-flicker fix vs. the old "repaint the selected row every tick". `draw_row` ([tft_settings.cpp:150-202](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp#L150-L202)) draws a rounded row, an amber chevron when selected, a left-aligned size-2 label, a right-aligned size-1 value (accent if adjustable), and a thin progress bar under adjustable rows.

**L/R live adjust** `handle_list_button` ([tft_settings.cpp:363-409](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp#L363-L409)) — UP/DOWN wrap the selection; LEFT/RIGHT adjust the value of the selected adjustable row and **persist + live-apply** instantly (no save button):
- **Volume**: ±10, clamped [0,100] → `settings_store::set_volume` (writes NVS and calls `spk::set_volume` so the user hears the change) ([tft_settings.cpp:375-380](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp#L375-L380)).
- **Photos/turn**: ±1, clamped `[1, MAX_IMAGES_LIMIT=5]` → `set_max_images` ([settings_store.h:51](Smart-Tutor-Lamp/tutor_lamp/settings_store.h#L51)).
- **Photo timer**: ±1, clamped `[CAPTURE_INTERVAL_MIN_S=1, MAX_S=8]` → `set_capture_interval_s` ([settings_store.h:52-53](Smart-Tutor-Lamp/tutor_lamp/settings_store.h#L52-L53)).
SELECT activates the row; `BTN_SELECT_LONG` exits the menu from anywhere.

**Destructive actions** route through a confirm dialog (`draw_confirm`, [tft_settings.cpp:237-284](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp#L237-L284)) defaulting to **NO**. On YES, `handle_confirm_button` ([tft_settings.cpp:411-444](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp#L411-L444)) commits:
- **Re-pair lamp** → `provisioning::clear_jwt()` then reboot (so the QR pairing flow runs again at boot).
- **Forget WiFi** → `settings_store::clear_wifi()` then reboot (falls back to hardcoded creds).

**WiFi reconfigure** opens `text_entry` twice — SSID then password (`enter_wifi_ssid_entry` pre-fills the saved override; `enter_wifi_pass_entry` never pre-fills) ([tft_settings.cpp:312-331](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp#L312-L331)). `tick()` polls `text_entry::is_done()` and, on confirm of both, calls `settings_store::set_wifi(ssid, pass)` and enters the reboot splash ([tft_settings.cpp:477-507](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp#L477-L507)). An empty SSID falls back to the list.

**Reboot rationale**: WiFi/Re-pair both end in `ESP.restart()` (after a 700 ms splash) because swapping a live connection mid-runtime requires tearing down WS + capture task + spk in a specific order that's easier to get right at boot ([tft_settings.h:36-39](Smart-Tutor-Lamp/tutor_lamp/tft_settings.h#L36-L39), [tft_settings.cpp:511-517](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp#L511-L517)).

---

## 8. On-screen Keyboard: `text_entry`

`text_entry` ([text_entry.cpp](Smart-Tutor-Lamp/tutor_lamp/text_entry.cpp)) is a one-shot modal dialog driven by polling (`is_done()`), not callbacks — the caller is already a state machine ([text_entry.h:53-55](Smart-Tutor-Lamp/tutor_lamp/text_entry.h#L53-L55)). It borrows `tft_ui::tft_handle()`.

**Layout** (landscape 320×240): a 24 px header (title + "hold SEL: back" hint), a 30 px edit field, and a 4×10 keyboard grid in the lower ~152 px (`KEY_W = SCREEN_W/10 = 32`, `KEY_H = KB_H/4`) ([text_entry.cpp:23-36](Smart-Tutor-Lamp/tutor_lamp/text_entry.cpp#L23-L36)).

**Three layers** cycled by the ⇧ key, exactly 40 cells each so the cursor position survives a layer switch ([text_entry.cpp:51-72](Smart-Tutor-Lamp/tutor_lamp/text_entry.cpp#L51-L72)): `LAYER_LOWER`, `LAYER_UPPER`, `LAYER_SYMS`. Five cells are special markers (single control chars NOT typed literally): `\x01`=⌫ backspace, `\x02`=⇧ layer, `\x03`=␣ space, `\x04`=OK, `\x05`=CANCEL; labels rendered as "<-", "shft", "space", "OK", "X" ([text_entry.cpp:97-106](Smart-Tutor-Lamp/tutor_lamp/text_entry.cpp#L97-L106)).

**Session** `begin(title, initial, password, max_len)` ([text_entry.cpp:295-322](Smart-Tutor-Lamp/tutor_lamp/text_entry.cpp#L295-L322)) — copies title (24 B), pre-fills the buffer from `initial` (truncated to `max_len`, clamped to `MAX_LEN = 64`), resets layer/cursor/flags, and forces a full repaint. WPA2 password is up to 63 chars, SSID up to 32 ([text_entry.h:64-66](Smart-Tutor-Lamp/tutor_lamp/text_entry.h#L64-L66)).

**Navigation** `on_button` ([text_entry.cpp:332-356](Smart-Tutor-Lamp/tutor_lamp/text_entry.cpp#L332-L356)): UP/DOWN/LEFT/RIGHT move the cursor with wrap-around (`move_cursor`, [text_entry.cpp:278-289](Smart-Tutor-Lamp/tutor_lamp/text_entry.cpp#L278-L289)); SELECT types the highlighted cell; `BTN_SELECT_LONG` is BACK/cancel (drop everything, `was_confirmed()=false`) — matching the Settings hold-SELECT-exit gesture. To submit, the user presses the on-screen OK key.

**Typing** `type_current` ([text_entry.cpp:234-276](Smart-Tutor-Lamp/tutor_lamp/text_entry.cpp#L234-L276)): backspace decrements `s_buffer_len`; ⇧ cycles `s_layer = (s_layer+1)%3` and triggers a full keyboard repaint; space/char append if `s_buffer_len < s_max_len`; OK/CANCEL set `s_done` + `s_confirmed` and `s_active=false`.

**Differential drawing**: `redraw_cursor_neighbours(prev)` ([text_entry.cpp:206-232](Smart-Tutor-Lamp/tutor_lamp/text_entry.cpp#L206-L232)) repaints only the old and new cells on a cursor move (no full keyboard repaint). `draw_field` ([text_entry.cpp:123-169](Smart-Tutor-Lamp/tutor_lamp/text_entry.cpp#L123-L169)) renders the buffer and a 500 ms blinking cursor; in **password mode** it masks chars as `*` except the last typed char, which is revealed for `800 ms` (iPhone convention, `s_password_reveal_until_ms`). Long input is right-truncated to keep the TAIL visible (`max_visible = (FIELD_W - 26)/CHAR_W`, `CHAR_W = 12`).

**Results**: `is_done()`, `was_confirmed()` (OK vs CANCEL), `result()` (the typed string; empty on CANCEL); `reset()` force-closes equivalently to CANCEL ([text_entry.cpp:358-368](Smart-Tutor-Lamp/tutor_lamp/text_entry.cpp#L358-L368)). `tutor_lamp.ino` also drives `text_entry` directly during boot WiFi setup via a synchronous loop ([tutor_lamp.ino:975-998](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L975-L998)).

---

## 9. Text Wrapping & Pagination Algorithm

`wrap_text_px(max_px, line_off, line_len, max_lines)` ([tft_ui.cpp:1593-1632](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1593-L1632)) word-wraps `s_text` into lines no wider than `max_px` **pixels**, measured against the **currently selected font** via `s_tft.textWidth()` — so it is correct for the proportional FreeSansBold body font as well as the GLCD fallback (the caller must call `set_read_font(false)` first so wrap and paint use the same metrics). Mechanics per line:
1. Skip leading spaces.
2. Grow the candidate one char at a time, copying into `tmp[256]` and measuring `textWidth(tmp)`; remember the last space that still fit (`last_space`).
3. Break: at `last_space` if the next char overflows and a space exists (keep the word whole); else at the exact fit / hard `\n` / over-long token (hard-cut). Always make at least 1 char of progress.
4. Store `(line_start, chars)` (length capped at 255), consume a hard newline if present.

Results are cached in static `line_off[]`/`line_len[]` arrays. Pagination clamps `s_text_scroll_line` to `[0, max_scroll]` where `max_scroll = max(0, total - visible)`; the visible window is `[s_text_scroll_line, +max_lines)`. `LINE_H = fontHeight() + 2` (derived from the font, not hardcoded). The combined view floors the text card at FreeSansBold body and `MAX_LINES_COMBINED = 256`; the full-screen text card uses `MAX_LINES = 192` ([tft_ui.cpp:1648](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1648), [tft_ui.cpp:1864](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1864)).

**Font selection** `set_read_font(big)` ([tft_ui.cpp:968-975](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L968-L975)) switches to FreeSansBold (12 pt for titles when `big`, 9 pt for body) when `LOAD_GFXFF` is defined (`TFT_UI_FREEFONT`), else falls back to scaled GLCD. `restore_default_font()` ([tft_ui.cpp:979-982](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L979-L982)) reverts to the stock GLCD font for the top bar / settings / keyboard / waveform, which still use it. The header notes the font symbols must NOT be re-`#include`d (no include guards → double-definition build error) — they are gated on `LOAD_GFXFF` and reused from TFT_eSPI ([tft_ui.cpp:9-27](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L9-L27)).

---

## 10. Configuration, Constants & Their Effects

| Constant | File:Line | Value | Effect |
|---|---|---|---|
| `TFT_ROT` | tft_ui.cpp:46 | 1 | landscape; set 3 if upside-down |
| `TFT_ROT` (display) | tft_display.cpp:10 | 3 | legacy painter rotation |
| `TFT_ROT` (qr) | tft_qr.cpp:22 | 0 | portrait, max QR area |
| `TFT_ROTATION` (viewer) | image_viewer.cpp:14 | 3 | debug viewer rotation |
| `TICK_MIN_MS` | tft_ui.cpp:54 | 33 | ~30 fps UI cap |
| `TOPBAR_REFRESH_MS` | tft_ui.cpp:57 | 1000 | clock cadence (120 ms while connecting) |
| `LATEX_CACHE_BYTES` | tft_ui.cpp:82 | 3 MiB | LaTeX/TFT accumulator; must ≥ accumulator cap |
| `IMAGE_CACHE_BYTES` | tft_ui.cpp:83 | 200 KiB | one big JPEG |
| `LISTEN_BARS` | tft_ui.cpp:238 | 24 | waveform bars / RMS ring size |
| `MAX_LATEX_EQ` | tft_ui.cpp:165 | 12 | max equations per pack |
| `LATEX_AREA_H` | tft_ui.cpp:1843 | 110 | combined-view latex slot (mirror backend) |
| `SCROLL_FRAME_MS` | tft_display.cpp:11 | 30 | legacy auto-scroll inter-frame delay |
| `PREVIEW_XFORM` | tft_ui.cpp:188 | PV_FLIP_H | un-mirrors hmirror=1 camera preview |
| `QR_VERSION` | tft_qr.cpp:21 / tft_ui.cpp:1098 | 7 | 45×45, ~154 alnum chars at ECC_LOW |
| `MAX_IMAGES_LIMIT` | settings_store.h:51 | 5 | photos/turn cap (== backend) |
| `CAPTURE_INTERVAL_MIN/MAX_S` | settings_store.h:52-53 | 1 / 8 | photo timer range |
| `MAX_LEN` (keyboard) | text_entry.h:66 | 64 | input buffer cap |
| `ENABLE_IMAGE_VIEWER` | image_viewer.h:32 | 1 | 0 → compile out debug viewer |
| `LOAD_GFXFF` | (User_Setup.h) | on | enables FreeSansBold; else GLCD fallback |

Build-time feature flags: `TFT_UI_FREEFONT` (from `LOAD_GFXFF`), `TFT_UI_HAS_QRCODE` / `TFT_QR_HAS_LIB` (from `__has_include("RICqrcode.h")`). The backend mirror constants `LAMP_COMBINED_LATEX_AREA_H_PX = 110` and `EQ_HEIGHT_MAX_PX = 90` in `app/providers/latex_engine.py` MUST be kept in sync with `LATEX_AREA_H` ([tft_ui.cpp:1830-1833](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1830-L1833)).

---

## 11. Edge Cases, Error Handling, Fallbacks

- **No PSRAM**: `ps_malloc` returns null; `s_latex`/`s_image` stay null; `on_tft_frame`/`commit_*`/`on_image_jpeg` early-return (drop) and log a warning at boot ([tft_ui.cpp:375-388](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L375-L388)).
- **Top-bar sprite alloc failure**: `draw_topbar` early-returns if `!s_topbar.created()` ([tft_ui.cpp:928](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L928)).
- **Malformed LaTeX header**: any of `W==0/H==0/n==0`, an exact-size mismatch, or `expected > cache` aborts the commit (with serial diagnostics in the chunked path) — the historical "TX DONE but blank screen" bug ([tft_ui.cpp:506-522](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L506-L522)).
- **Frame taller than slot**: clipped and logged once per 2 s ([tft_ui.cpp:1731-1739](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1731-L1739)).
- **APPEND validation**: no committed base / bad offset / geometry mismatch / `n_tot <= committed` / size mismatch all return false and leave the committed pack untouched ([tft_ui.cpp:546-575](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L546-L575)).
- **Server LaTeX render failure**: backend sends `TFT_CLEAR`; `on_tft_clear` wipes text + latex AND drops `s_latex_loading` so the skeleton doesn't pulse forever ([tft_ui.cpp:643-654](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L643-L654)).
- **STX caption vs answer**: a `\x02`-prefixed text only escalates the THINKING caption; a plain text during THINKING IS the answer and must route through (or the spinner starves the pipeline) ([tft_ui.cpp:603-623](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L603-L623)).
- **JPEG decode**: `getJpgSize`/`drawJpg` failures show "bad image"/error-code status and return without leaving residue ([tft_ui.cpp:1475-1480](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1475-L1480), [image_viewer.cpp:93-119](Smart-Tutor-Lamp/tutor_lamp/image_viewer.cpp#L93-L119)).
- **QR unreadable**: `tft_qr::show` returns false at `scale < 2`; warns at `scale < 3`. `tft_ui` floors scale at 2 ([tft_qr.cpp:63-68](Smart-Tutor-Lamp/tutor_lamp/tft_qr.cpp#L63-L68), [tft_ui.cpp:1105-1106](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1105-L1106)).
- **QR library missing**: both QR renderers fall back to a text-only URL screen; the build still succeeds ([tft_qr.cpp:107-133](Smart-Tutor-Lamp/tutor_lamp/tft_qr.cpp#L107-L133), [tft_ui.cpp:1121-1139](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1121-L1139)).
- **Empty SSID** in WiFi reconfigure → fall back to the menu list ([tft_settings.cpp:482-485](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp#L482-L485)).
- **Reboot guard**: while `SUB_DONE_REBOOT`, all input is ignored ([tft_settings.cpp:534-536](Smart-Tutor-Lamp/tutor_lamp/tft_settings.cpp#L534-L536)).
- **Text overflow**: `s_text` is 2048 B; `on_tft_text` truncates to fit; `wrap_text_px` hard-cuts pathologically long tokens (>256 chars) ([tft_ui.cpp:1610](Smart-Tutor-Lamp/tutor_lamp/tft_ui.cpp#L1610)).
- **Concurrency safety**: setters touch only volatile integers / small buffers, deferring SPI to `tick()` in `loop()` context; the capture task can pre-empt mid-SPI without corruption.

---

## 12. Integration Points & Cross-references

**What calls this module** (mostly `tutor_lamp.ino`):
- Boot: `tft_ui::begin()` → `set_page(PAGE_BOOT)` → `tick()` ([tutor_lamp.ino:1156-1158](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1156-L1158)); then GREETING during peripheral init, IDLE when ready ([tutor_lamp.ino:1338-1429](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1338-L1429)).
- WiFi: `set_page(PAGE_WIFI_CONNECTING)`, `set_wifi_connecting_ssid()`, `set_wifi(...)` with RSSI thresholds ([tutor_lamp.ino:955-1029](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L955-L1029), [1287-1289](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1287-L1289)).
- Backend status: `set_backend(BE_ONLINE/CONNECTING/OFFLINE/ERROR)` from the connection-state callback ([tutor_lamp.ino:873-886](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L873-L886)).
- WebSocket frames → display: `FRAME_TFT_PART/FRAME/TEXT/CLEAR/APPEND_BEGIN/APPEND/LATEX_LOADING` dispatch into `get_latex_buffer`/`commit_chunked_latex`/`on_tft_text`/`on_tft_clear`/`latex_append_base`/`commit_append`/`set_latex_loading` ([tutor_lamp.ino:584-776](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L584-L776)).
- Turn lifecycle: STATE messages set THINKING/SPEAKING pages and `set_speaking_active` ([tutor_lamp.ino:799-838](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L799-L838)); mic RMS → `set_listening_level` ([tutor_lamp.ino:402](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L402)); recording/audio-out flags ([tutor_lamp.ino:1468-1475](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1468-L1475)).
- Camera: capture → `on_image_jpeg` + `set_capture_countdown` ([tutor_lamp.ino:1087-1123](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1087-L1123)); `cam::set_busy_hook` and `net::set_image_send_hook` call `tft_ui::tick()` to keep the UI smooth during blocking work ([tutor_lamp.ino:1355](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1355), [1417](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1417)).
- Buttons: `tft_ui::on_button(...)`, with `tft_settings`/`text_entry` taking over while active ([tutor_lamp.ino:1175-1223](Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1175-L1223)).

**What this module calls**: TFT_eSPI (Bodmer), TJpg_Decoder (Bodmer), `RICqrcode` (QR gen), `settings_store` (volume/photos/timer/WiFi NVS + `spk::set_volume`), `provisioning::clear_jwt`, `text_entry`, `ESP.restart()`, `esp_random()`.

**Cross-stack**: the backend `app/providers/latex_engine.py` (`Latex_engine_tft.py`) produces the RGB565/BGR byte-swapped frames + per-equation trailer this code consumes, and mirrors `LATEX_AREA_H`/`EQ_HEIGHT_MAX_PX`/`MAX_IMAGES_PER_TURN`. The wire protocol matches `IMPLEMENTATION_WEBSOCKET.md §4.4 TFT_FRAME` ([tft_display.h:10](Smart-Tutor-Lamp/tutor_lamp/tft_display.h#L10)). The pairing URL/code originate from `/api/device/register` and are surfaced to the frontend/Supabase pairing flow.

---

## 13. Mermaid Diagrams

### 13.1 Page state machine (key transitions)

```mermaid
stateDiagram-v2
    [*] --> PAGE_BOOT
    PAGE_BOOT --> PAGE_WIFI_CONNECTING: setup() WiFi bring-up
    PAGE_WIFI_CONNECTING --> PAGE_PAIRING: WiFi up, POST /register
    PAGE_PAIRING --> PAGE_QR_PAIRING: pairing code received
    PAGE_QR_PAIRING --> PAGE_GREETING: paired
    PAGE_WIFI_CONNECTING --> PAGE_GREETING: already paired
    PAGE_GREETING --> PAGE_IDLE: peripherals ready
    PAGE_IDLE --> PAGE_LISTENING: wake word / push-to-talk
    PAGE_LISTENING --> PAGE_IMAGE_PREVIEW: camera capture
    PAGE_IMAGE_PREVIEW --> PAGE_THINKING: EOS sent
    PAGE_LISTENING --> PAGE_THINKING: EOS (no image)
    PAGE_THINKING --> PAGE_SPEAKING_TEXT: TFT_TEXT (no latex)
    PAGE_THINKING --> PAGE_SPEAKING_LATEX: TFT_FRAME / LATEX_LOADING
    PAGE_SPEAKING_TEXT --> PAGE_SPEAKING_LATEX: text + latex => combined
    PAGE_SPEAKING_TEXT --> PAGE_IDLE: SELECT dismiss / TFT_CLEAR
    PAGE_SPEAKING_LATEX --> PAGE_IDLE: SELECT dismiss / TFT_CLEAR
    PAGE_IDLE --> PAGE_ERROR: backend ERROR / offline
    PAGE_ERROR --> PAGE_IDLE: SELECT / reconnect
    PAGE_IDLE --> [*]: long-SELECT => Settings (external_drawing)
```

### 13.2 Chunked LaTeX receive → render pipeline

```mermaid
sequenceDiagram
    participant BE as Backend (latex_engine_tft)
    participant NET as net_ws / tutor_lamp.ino
    participant UI as tft_ui
    participant TFT as TFT_eSPI panel

    BE->>NET: FRAME_TFT_LATEX_LOADING (0x24, empty)
    NET->>UI: set_latex_loading(true)
    UI->>TFT: draw skeleton base (label + clear, once)
    loop ~75 chunks
        BE->>NET: FRAME_TFT_PART (0x23) chunk
        NET->>UI: memcpy into get_latex_buffer()+len
        UI-->>TFT: tick: animate 3 pulsing bars in place
    end
    BE->>NET: FRAME_TFT_FRAME (0x20) terminator
    NET->>UI: commit_chunked_latex(total_len)
    UI->>UI: parse header [W,H,n,n_eq], validate size, parse eq table
    UI->>UI: s_latex_loading=false, set_page(PAGE_SPEAKING_LATEX)
    UI->>TFT: draw_latex_frame_area: setAddrWindow + pushColors(swap=false)
    Note over UI,TFT: User LEFT/RIGHT => s_latex_idx +/-1 => repaint frame
    BE->>NET: FRAME_TFT_APPEND_BEGIN (0x26) + PARTs + APPEND (0x25)
    NET->>UI: commit_append(seg_off, seg_len)
    UI->>UI: memmove 6B left, patch header counts, preserve view
```

### 13.3 Image preview decode + display transform

```mermaid
flowchart TD
    A[on_image_jpeg: memcpy into s_image 200KB] --> B[set_page PAGE_IMAGE_PREVIEW]
    B --> C[enter_image_preview: clear content]
    C --> D[TJpgDec.getJpgSize -> W,H]
    D -->|fail| E[draw 'bad image']
    D -->|ok| F[pick scale in 1,2,4,8 to fit]
    F --> G[center: off_x, off_y]
    G --> H[arm s_jpg_xform = PV_FLIP_H]
    H --> I[TJpgDec.drawJpg -> tjpg_block_cb per MCU block]
    I --> J[block: reverse within rows, mirror to corner, pushImage]
    J --> K[disarm s_jpg_xform = PV_NONE]
    K --> L{multi-shot turn?}
    L -->|yes| M[tick: Photo N/M + reverse countdown bar]
    L -->|no| N[caption: auto-dismiss in 5 s]
```

---

## 14. File-by-file / Function-by-function Index

### `tft_ui.h` / `tft_ui.cpp` — master UI

| Symbol | Location | Role |
|---|---|---|
| `begin()` | tft_ui.cpp:353 | init panel, sprite, TJpgDec, PSRAM caches |
| `tick(force)` | tft_ui.cpp:784 | 30 fps dispatch loop |
| `set_page`/`get_page` | tft_ui.cpp:396/402 | lazy page nav |
| `set_wifi/backend/recording/audio_out/clock` | tft_ui.cpp:404-439 | top-bar inputs |
| `set_wifi_connecting_ssid` | tft_ui.cpp:428 | SSID label |
| `on_tft_frame` | tft_ui.cpp:469 | single-payload LaTeX commit |
| `get_latex_buffer`/`_capacity` | tft_ui.cpp:497-498 | shared chunk buffer |
| `commit_chunked_latex` | tft_ui.cpp:500 | commit accumulated chunks |
| `latex_append_base`/`commit_append` | tft_ui.cpp:535/546 | APPEND splice |
| `parse_latex_eq_table`/`latex_cur_eq` | tft_ui.cpp:444/462 | multi-eq grouping |
| `on_tft_text` | tft_ui.cpp:603 | text routing (+STX caption) |
| `on_tft_clear` | tft_ui.cpp:643 | wipe + drop skeleton |
| `on_image_jpeg` | tft_ui.cpp:656 | cache + preview |
| `set_capture_countdown` | tft_ui.cpp:675 | multi-shot overlay state |
| `set_qr_pairing` | tft_ui.cpp:691 | QR page content |
| `set_listening_level` | tft_ui.cpp:697 | RMS ring (capture-task safe) |
| `set_speaking_active`/`set_latex_loading` | tft_ui.cpp:704/706 | anim flags |
| `on_button` | tft_ui.cpp:722 | per-page input |
| `set_external_drawing`/`force_full_redraw`/`tft_handle` | tft_ui.cpp:766/776/782 | handoff |
| `tjpg_block_cb` | tft_ui.cpp:312 | MCU block paint + display transform |
| `draw_topbar`/`draw_wifi_icon`/`draw_backend_dot`/`draw_state_glyph` | tft_ui.cpp:927/829/849/877 | top bar |
| `draw_centered_text`/`set_read_font`/`restore_default_font` | tft_ui.cpp:984/968/979 | text helpers |
| `enter_/tick_` boot,wifi,pairing,qr,greeting,idle,listening,thinking,image_preview,speaking_text,speaking_latex,error | tft_ui.cpp:1014-2018 | pages |
| `draw_one_eye`/`draw_idle_hint` | tft_ui.cpp:1294/1226 | idle face |
| `wrap_text_px` | tft_ui.cpp:1593 | pixel word-wrap |
| `draw_latex_frame_area`/`draw_latex_nav_cues`/`draw_latex_frame`/`draw_combined_latex_and_text`/`draw_latex_skeleton_base` | tft_ui.cpp:1718/1756/1789/1821/1942 | latex viewer |
| `draw_side_bars` | tft_ui.cpp:2023 | speaker animation |
| `SIN64`/`sin64` | tft_ui.cpp:116/122 | float-free trig |

### `tft_display.h` / `.cpp` — legacy frame painter
`begin` (tft_display.cpp:20), `render_frame` (30) auto-scrolls at 30 ms/frame, `render_text` (81), `clear` (97).

### `tft_settings.h` / `.cpp` — settings menu
`open` (450), `tick` (462), `on_button` (521), `is_active` (540); helpers `draw_header/value_for_item/draw_row/draw_list/draw_confirm/draw_reboot` (105-297), state transitions `enter_*`/`activate_item`/`handle_list_button`/`handle_confirm_button` (300-444).

### `text_entry.h` / `.cpp` — on-screen keyboard
`begin` (295), `tick` (324), `on_button` (332), `is_done`/`was_confirmed`/`result`/`reset` (358-368); internals `current_char/is_special/label_for_special/draw_header/draw_field/draw_keyboard/draw_all/redraw_cursor_neighbours/type_current/move_cursor` (89-289); layers `LAYER_LOWER/UPPER/SYMS` (51-72).

### `tft_qr.h` / `.cpp` — standalone QR
`begin` (33), `show` (41) version-7/ECC_LOW, scale-gated, text fallback; `clear` (136).

### `image_viewer.h` / `.cpp` — debug JPEG viewer
`begin` (73), `show_jpeg` (88), `clear` (132), `show_status` (136), `set_enabled`/`enabled` (145/151); internals `tjpg_block_cb` (28), `draw_letterbox` (36), `pick_scale` (59); compile-gated by `ENABLE_IMAGE_VIEWER`.

### `RICqrcode.h` / `.c` — QR generator
Public: `qrcode_getBufferSize` (770), `qrcode_initBytes` (775), `qrcode_initText` (851), `qrcode_getModule` (855). Internals: `encodeDataCodewords` (629), `performErrorCorrection` (689), `rs_init`/`rs_getRemainder`/`rs_multiply` (586/606/575), `drawFunctionPatterns`/`drawFinderPattern`/`drawAlignmentPattern`/`drawFormatBits`/`drawVersion` (381/285/300/310/352), `drawCodewords` (441), `applyMask` (256), `getPenaltyScore` (483). Lookup tables at 41-65.
