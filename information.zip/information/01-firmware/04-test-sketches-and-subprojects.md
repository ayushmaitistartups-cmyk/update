# Firmware — Auxiliary Test Sketches & Sub-projects

This document is the definitive reference for the **standalone test sketches and helper sub-projects** that surround the main `tutor_lamp` firmware of the Smart Tutor Lamp. These are single-purpose Arduino sketches plus their companion PC-side Python helpers used to bring up, calibrate, train and locally simulate each subsystem of the lamp in isolation — the OV5640 document camera, the INMP441 microphone (recording + Edge Impulse wake-word data collection), the resistor-ladder push buttons, the LaTeX-rendering TFT panel, the MAX98357A audio playback path, and a complete drop-in WebSocket backend simulator (`dummy_backend.py`). Each sketch deliberately mirrors a piece of DSP, a pin map, or a wire protocol that the production `tutor_lamp` firmware also uses, so that what you measure in the test rig is byte-for-byte what the real device sees. Everything below is grounded entirely in the actual source files.

---

## Table of contents

1. [Purpose and responsibility](#1-purpose-and-responsibility)
2. [Inventory & directory layout](#2-inventory--directory-layout)
3. [`camera_test/` — OV5640 document capture](#3-camera_test--ov5640-document-capture)
   - [3.1 `camera_test.ino` (firmware)](#31-camera_testino-firmware)
   - [3.2 `camera_server.py` (Flask rectifier)](#32-camera_serverpy-flask-rectifier)
   - [3.3 `board_config.h` / `camera_pins.h`](#33-board_configh--camera_pinsh)
   - [3.4 `docs/README.md`](#34-docsreadmemd)
4. [`ei_data_collector/` — Edge Impulse wake-word data collection](#4-ei_data_collector--edge-impulse-wake-word-data-collection)
5. [`mic_recorder/` — dual-mode mic recorder + EI forwarder](#5-mic_recorder--dual-mode-mic-recorder--ei-forwarder)
6. [`push_buttons/` — resistor-ladder ADC button probe](#6-push_buttons--resistor-ladder-adc-button-probe)
7. [`tft_latex_client/` — TFT LaTeX rendering client](#7-tft_latex_client--tft-latex-rendering-client)
8. [`wifi_audio_player/` — WiFi PCM audio player](#8-wifi_audio_player--wifi-pcm-audio-player)
9. [`dummy_backend.py` — full backend simulator](#9-dummy_backendpy--full-backend-simulator)
10. [Cross-reference matrix: test rig → production firmware](#10-cross-reference-matrix-test-rig--production-firmware)
11. [Shared constants, pin maps & magic numbers](#11-shared-constants-pin-maps--magic-numbers)
12. [Edge cases, error handling & fallbacks (consolidated)](#12-edge-cases-error-handling--fallbacks-consolidated)

---

## 1. Purpose and responsibility

The Smart Tutor Lamp's production firmware (`tutor_lamp/`) is a tightly-coupled multi-task application: a microphone capture task, an audio playback path, a camera, a TFT UI state machine, an ADC button reader, a wake-word classifier, and a persistent WebSocket client all run concurrently on one ESP32-S3. Debugging that monolith directly is hard, so the project ships a constellation of **isolation rigs**, each of which exercises exactly one peripheral or one wire protocol with the minimum surrounding code:

| Sub-project | Subsystem isolated | Production counterpart it de-risks |
|---|---|---|
| `camera_test/` | OV5640 capture, autofocus, JPEG → server upload | `tutor_lamp/camera.{h,cpp}` + backend image pipeline |
| `ei_data_collector/` | INMP441 16 kHz capture → Edge Impulse | `tutor_lamp/wake_word.{h,cpp}` training data |
| `mic_recorder/` | INMP441 DSP chain (DC block + gain), WAV capture | `tutor_lamp/mic_i2s.{h,cpp}`, wake-word DSP parity |
| `push_buttons/` | 5-way resistor-ladder ADC button mapping | `tutor_lamp/buttons.{h,cpp}` |
| `tft_latex_client/` | TFT panel + RGB565 frame protocol + HW scroll | `tutor_lamp/tft_ui.{h,cpp}` LaTeX page |
| `wifi_audio_player/` | I2S TX to MAX98357A, ring buffer, TCP/UDP PCM | `tutor_lamp/spk_i2s.{h,cpp}`, AUDIO_OUT path |
| `dummy_backend.py` | Whole backend (WS protocol, TTS, TFT frames, STATE) | The real FastAPI backend |

The common design principle, stated explicitly in several headers, is **DSP/protocol parity**: e.g. `mic_recorder.ino`'s comment "The DSP chain is identical to what `wake_word_hey_lamp.ino` uses for inference, so what `mic_server.py` saves IS what your wake-word model sees" ([mic_recorder.ino:5-7](Smart-Tutor-Lamp/mic_recorder/mic_recorder.ino#L5)), and `dummy_backend.py`'s use of `EQUATIONS[10]` from the TFT client as a "PROVEN-WORKING ultimate stress test" ([dummy_backend.py:64-66](Smart-Tutor-Lamp/dummy_backend.py#L64)).

---

## 2. Inventory & directory layout

```
Smart-Tutor-Lamp/
├── camera_test/
│   ├── camera_test.ino        # ESP32-S3 OV5640 capture sketch (720 LOC)
│   ├── camera_server.py       # Flask + OpenCV document rectifier (766 LOC)
│   ├── board_config.h         # camera model selector (#define CAMERA_MODEL_*)
│   ├── camera_pins.h          # per-board GPIO pin maps (Espressif standard)
│   └── docs/README.md         # full operator manual (420 LOC)
├── ei_data_collector/
│   ├── ei_data_collector.ino  # FINAL simple 16 kHz serial streamer (55 LOC)
│   └── mic_EI.txt             # earlier variant WITH the DC blocker (77 LOC)
├── mic_recorder/
│   └── mic_recorder.ino       # dual-mode (record / EI) mic streamer (269 LOC)
├── push_buttons/
│   └── push_buttons.ino       # ADC resistor-ladder button probe (34 LOC)
├── tft_latex_client/
│   └── tft_latex_client.ino   # TFT RGB565 frame client + HW scroll (183 LOC)
├── wifi_audio_player/
│   └── wifi_audio_player.ino  # TCP/UDP PCM → I2S ring-buffer player (314 LOC)
├── dummy_backend.py           # full WS backend simulator (464 LOC)
└── Wake word/
    └── wake_word_hey_lamp/
        └── wake_word_hey_lamp.ino  # EI inference sketch (cross-ref only)
```

> The PC-side helpers `mic_server.py` and `Latex_engine_tft.py` are *referenced* by these sketches but are not present in this firmware tree (they live with the backend / are user-supplied); their expected behaviour is reconstructed below from the call sites.

---

## 3. `camera_test/` — OV5640 document capture

### Purpose

A lamp-mounted **document-scanning rig**. The ESP32-S3 drives an OV5640 autofocus camera bolted to the lamp head at a fixed ~34° tilt over the desk; on a serial command it captures a sharp UXGA JPEG and POSTs it over WiFi to a Flask server on the PC. The Flask server runs a full OpenCV "mobile-scanner" pipeline (page detection, perspective rectification, deskew, denoise, background bleach, contrast/sharpen) producing an LLM-ready clean PNG. This rig is the de-risking ground for the lamp's production `camera.{h,cpp}` and for the backend's image-cleanup stage.

### 3.1 `camera_test.ino` (firmware)

#### Configuration constants

All configurable knobs are at the top of the file ([camera_test.ino:77-103](Smart-Tutor-Lamp/camera_test/camera_test.ino#L77)):

| Constant | Value | Effect |
|---|---|---|
| `WIFI_SSID` / `WIFI_PASS` | `"ACT_4g"` / `"Samiul2004"` | WiFi join credentials |
| `SERVER_BASE` | `"http://192.168.0.3:5000"` | Flask server URL (must be PC LAN IP, not 127.0.0.1) |
| `MAX_RETRIES_ON_BLUR` | `2` | Extra capture attempts after a server `422` (too blurry) |
| `MAX_RETRIES_ON_OVF` | `3` | Extra attempts after a framebuffer overflow (null `fb`) |
| `AF_TIMEOUT_MS` | `4000` | Max wait for an AF focus-lock before giving up |
| `HTTP_TIMEOUT_MS` | `15000` | HTTP POST timeout |
| `QUALITY_BEST` | `8` | Sharpest JPEG quality allowed (high FIFO-overflow risk) |
| `QUALITY_DEFAULT` | `10` | Quality used on boot |
| `QUALITY_WORST` | `30` | Most compressed; never overflows |
| `QUALITY_STEP` | `2` | Quality delta per `q`/`Q` keypress |
| `FOCUS_MIN`/`FOCUS_MAX` | `0x0000`/`0x01FF` | 9-bit VCM (voice-coil motor) lens-position range |
| `FOCUS_SMALL_STEP` | `0x08` | VCM step for `+`/`-` |
| `FOCUS_BIG_STEP` | `0x40` | VCM step for `]`/`[` |
| `MAINS_HZ` | `50` | Anti-banding mains frequency (change to 60 in NA) |

> Note: the inline constant `SERVER_BASE` is `192.168.0.3`, while `docs/README.md` documents the default as `192.168.0.6` ([docs/README.md:76](Smart-Tutor-Lamp/camera_test/docs/README.md#L76)) — a known drift between code and doc.

#### Key data structures

- `OV5640 ov5640` — the autofocus driver object from the third-party "OV5640 Auto Focus for ESP32 Camera" library (Eric Nam / `0015`) ([camera_test.ino:128](Smart-Tutor-Lamp/camera_test/camera_test.ino#L128)).
- Globals: `bool af_ready` (AF firmware loaded), `bool auto_mode` (AUTO vs MANUAL focus), `int manual_pos = 0x0080` (current VCM position, mid-range), `int current_quality = QUALITY_DEFAULT`.
- **OV5640 AF MCU register map** ([camera_test.ino:143-158](Smart-Tutor-Lamp/camera_test/camera_test.ino#L143)) — these are poked directly via the sensor's SCCB register interface:

| Symbol | Register | Meaning |
|---|---|---|
| `REG_AF_CMD` | `0x3022` | Command register (write command byte) |
| `REG_AF_ACK` | `0x3023` | ACK; sensor's AF MCU clears it when it consumes the command |
| `REG_AF_STAT` | `0x3029` | Firmware status (`0x70` idle, `0x10` focused, `0x00` busy) |
| `REG_VCM_HI` / `REG_VCM_LO` | `0x3602` / `0x3603` | Manual VCM lens position high/low (community-discovered) |
| `AF_CMD_SINGLE` | `0x03` | Trigger single-shot autofocus |
| `AF_CMD_CONT` | `0x04` | Continuous autofocus (unused here) |
| `AF_CMD_RELEASE` | `0x08` | Pause / hand control back |
| `AF_STAT_FOCUSED` | `0x10` | Focus-lock bit |
| `AF_STAT_IDLE` | `0x70` | Firmware running, idle |
| `AF_STAT_FAIL` | `0x40` | Failure (community-observed) |

#### Function-by-function breakdown

- **`af_send_cmd(sensor_t* s, cmd, timeout_ms=500)`** ([:164](Smart-Tutor-Lamp/camera_test/camera_test.ino#L164)) — the core AF handshake: write `cmd` to `REG_AF_CMD`, write `0x01` to `REG_AF_ACK`, then **poll `REG_AF_ACK` every 5 ms until the sensor clears it to `0x00`** (it cleared = command consumed). Returns `true` on ack, `false` on timeout (caller may continue anyway).
- **`af_release(s)`** ([:176](Smart-Tutor-Lamp/camera_test/camera_test.ino#L176)) — sends `AF_CMD_RELEASE` then `delay(30)`.
- **`vcm_write_pos(s, pos)`** ([:181](Smart-Tutor-Lamp/camera_test/camera_test.ino#L181)) — clamps `pos` to `[FOCUS_MIN, FOCUS_MAX]`, writes the high 2 bits to `REG_VCM_HI` (`(pos>>8)&0x03`) and the low byte to `REG_VCM_LO`, then issues `AF_CMD_SINGLE` to **commit** the motor position. This is the manual-focus primitive.
- **`manual_focus_apply(s)`** ([:188](Smart-Tutor-Lamp/camera_test/camera_test.ino#L188)) — release AF, write `manual_pos`, print `[MF] pos = 0x..`.
- **`trigger_autofocus(s)`** ([:197](Smart-Tutor-Lamp/camera_test/camera_test.ino#L197)) — single-shot AF: release, send `AF_CMD_SINGLE`, then **poll `REG_AF_STAT` every 40 ms** for up to `AF_TIMEOUT_MS`. Decoding logic (order matters because `0x70` IDLE shares bit `0x10` with FOCUSED):
  - `st == 0x10` → LOCK, return `true`.
  - `st & 0x40 && (st & 0x0F)==0` (pure `0x40`) → FAIL, return `false`.
  - `st == 0x70` (IDLE) → completed; return `true` only if FOCUSED was seen earlier in the poll (`saw_focused`).
  - timeout → return `false`.
- **`apply_anti_banding(s)`** ([:252](Smart-Tutor-Lamp/camera_test/camera_test.ino#L252)) — fixes mains-flicker horizontal banding caused by the rolling shutter integrating AC ripple. Pokes datasheet registers directly (the `esp32-camera` setters don't expose them): `0x3c01` bit7=1 (manual band selection), `0x3c00` bit2 = (`MAINS_HZ==50 ? 0x04 : 0x00`) (50 vs 60 Hz), `0x3a00` bit5=1 (band-filter enable).
- **`apply_doc_settings(s)`** ([:262](Smart-Tutor-Lamp/camera_test/camera_test.ino#L262)) — the "document mode" sensor tuning applied before every UXGA capture: quality=`current_quality`, brightness 0, contrast +1, saturation −1 (slightly desaturate to preserve marker colour), sharpness 1, denoise 1, auto white-balance on, exposure ctrl + AEC2 on, `ae_level=0` (neutral — a dark desk would otherwise blow the page out), gain ctrl on with **gain ceiling forced to 1 (2× max)** to suppress high-ISO row noise, BPC/WPC on, raw gamma on, **lens shading correction (`set_lenc`) on (commented "very important")**, DCW on, hmirror on, vflip off. Finally re-asserts `apply_anti_banding(s)` last so it can't be clobbered by an intervening API call.
- **`apply_idle_settings(s)`** ([:303](Smart-Tutor-Lamp/camera_test/camera_test.ino#L303)) — the cool idle state: quality 12, neutral brightness/contrast/saturation, hmirror on.
- **`post_jpeg(path, buf, len)`** ([:314](Smart-Tutor-Lamp/camera_test/camera_test.ino#L314)) — HTTP POST with `Content-Type: image/jpeg`, timeout `HTTP_TIMEOUT_MS`; returns the HTTP status code (or a negative error). Prints the response body if `< 256` chars.
- **`grab_after_flush(flush_count, settle_ms)`** ([:343](Smart-Tutor-Lamp/camera_test/camera_test.ino#L343)) — optional `delay(settle_ms)`, then discards `flush_count` stale frames (each `esp_camera_fb_get` + `esp_camera_fb_return` + `delay(60)`) so AE/AWB settle, then returns one fresh `camera_fb_t*` the caller must release.
- **`do_full_capture()`** ([:356](Smart-Tutor-Lamp/camera_test/camera_test.ino#L356)) — the main capture flow (see workflow below).
- **`do_preview()`** ([:463](Smart-Tutor-Lamp/camera_test/camera_test.ino#L463)) — grabs one VGA frame (`grab_after_flush(1, 80)`) and POSTs to `/preview` (no resolution switch, low heat) for manual-focus tuning.
- **`adjust_quality(delta)`** ([:481](Smart-Tutor-Lamp/camera_test/camera_test.ino#L481)) — constrains `current_quality+delta` to `[QUALITY_BEST, QUALITY_WORST]` and labels it ("sharp, OVF risk" ≤10, "balanced" ≤16, else "safe/compressed").
- **`print_status()`** ([:495](Smart-Tutor-Lamp/camera_test/camera_test.ino#L495)) — dumps mode, VCM position, quality range, decoded AF status register, AF firmware state, WiFi RSSI.
- **`setup()`** ([:526](Smart-Tutor-Lamp/camera_test/camera_test.ino#L526)) and **`loop()`** ([:635](Smart-Tutor-Lamp/camera_test/camera_test.ino#L635)) — init & serial command dispatch.

#### `do_full_capture()` — complete control flow

```
1. Get sensor; if AUTO mode → trigger_autofocus(s); else log locked manual pos
2. set_framesize(UXGA); apply_doc_settings(s)
3. Loop:
   a. settle = (first try ? 500ms : 250ms); fb = grab_after_flush(flush=2, settle)
   b. if fb == NULL  → assume FB-OVF:
        ovf_tries++; if > MAX_RETRIES_ON_OVF → give up
        bump current_quality by QUALITY_STEP (capped at QUALITY_WORST), set_quality
        delay(300); continue
   c. POST fb to /upload; release fb
   d. if code 200/201 → "accepted ✓", break
      if code 422     → blur: blur_tries++; if > MAX_RETRIES_ON_BLUR → give up;
                        else if AUTO → re-AF; continue
      else            → non-recoverable, break
4. Restore VGA idle (set_framesize VGA + apply_idle_settings)
```

This is the dual-retry state machine: **FB-OVF recovery** (lower quality, raise compression) is orthogonal to **blur recovery** (re-autofocus). Settle time is 500 ms on the first attempt (sensor stabilisation) and 250 ms on retries.

#### `setup()` — boot sequence

1. Serial @ 115200, `setDebugOutput(false)`.
2. Build a `camera_config_t` with the Freenove ESP32-S3 WROOM pin map (inline `#define`s at [:108-123](Smart-Tutor-Lamp/camera_test/camera_test.ino#L108) — `XCLK=15, SIOD=4, SIOC=5, D0..D7=11/9/8/10/12/18/17/16, VSYNC=6, HREF=7, PCLK=13`), **`xclk_freq_hz = 10_000_000`** (10 MHz — keeps the sensor cool and avoids FB-OVF at UXGA), `PIXFORMAT_JPEG`, `CAMERA_FB_IN_PSRAM`.
3. If PSRAM present: `frame_size = UXGA`, `jpeg_quality = QUALITY_DEFAULT`, `fb_count = 2`, `grab_mode = CAMERA_GRAB_WHEN_EMPTY` (more forgiving for one-shot stills than `GRAB_LATEST`). Else fall back to SVGA in DRAM with `fb_count = 1`.
4. `esp_camera_init` → on failure, abort. Print sensor PID; expect `OV5640_PID` (`0x5640`).
5. Idle in VGA + `apply_idle_settings`.
6. `ov5640.start(s)`; `ov5640.focusInit()` — on success set `af_ready=true`, release AF, park lens at `manual_pos`. On failure, warn "check AF-VCC wiring".
7. WiFi STA, `setSleep(false)`, join with a **30 s connect timeout** (continues anyway on timeout).
8. Print the serial command help.

#### `loop()` — serial command handler

Reads one char, flushes the rest, dispatches via switch ([:647](Smart-Tutor-Lamp/camera_test/camera_test.ino#L647)). Commands (case-insensitive where noted): `C`=full capture, `P`=preview, `A`=AUTO, `M`=MANUAL (release AF + write VCM), `R`=re-AF, `+`/`-`=small focus step, `]`/`[`=big focus step, `0`=reset to 0x080, `q`=lower quality (`+QUALITY_STEP`, safer), `Q`=raise quality (`-QUALITY_STEP`, sharper), `?`=status. Whitespace (`\r`/`\n`/space) is ignored; anything else prints "unknown command".

### 3.2 `camera_server.py` (Flask rectifier)

A Flask + OpenCV + NumPy server that receives raw JPEG bytes and runs a **6-stage adaptive document pipeline**. Unlike the firmware comment that describes a fixed-angle homography, the *actual* server does **per-frame adaptive page rectification** ([camera_server.py:1-47](Smart-Tutor-Lamp/camera_test/camera_server.py#L1)) — it finds the page quad in each frame and warps only that quad, so there is nothing to calibrate.

#### Configuration ([:65-87](Smart-Tutor-Lamp/camera_test/camera_server.py#L65))

| Constant | Value | Effect |
|---|---|---|
| `SAVE_DIR` | `camera_captures/` | Output folder (created on import) |
| `PREVIEW_PATH` | `SAVE_DIR/_latest_preview.jpg` | Latest `/preview` POST target |
| `SAVE_ORIGINAL` | `True` | Keep raw JPEG @ quality 92 |
| `DEBUG_GRID` | `False` | Write a 6-panel debug image |
| `SAVE_SEGMENTS` | `False` | Write content-region overlay |
| `SAVE_BW` | `False` | Write binary OCR variant |
| `MIN_SHARPNESS` | `60.0` | Reject frames below this centre-weighted Laplacian variance → HTTP 422 |
| `PAGE_MIN_AREA_FRAC` | `0.18` | Detected quad must cover ≥18% of frame |
| `PAGE_MAX_AR` | `3.5` | Plausibility cap on width/height ratio |
| `PAGE_DETECT_SCALE` | `700.0` | Downscale long side to this before contouring |
| `PAGE_BINARY_GROW_PX` | `6` | Dilate binary at small scale pre-contour |
| `PAGE_QUAD_PADDING` | `0.04` | Push corners 4% outward from quad centroid |
| `DENOISE_STRENGTH` | `1` | 0=off, 1=light bilateral, 2=medium |

> The defaults here (`DEBUG_GRID/SAVE_SEGMENTS/SAVE_BW = False`) differ from `docs/README.md`'s table which lists them `True`; the code is authoritative.

#### Data structure: `StageOutputs` (dataclass) ([:106-119](Smart-Tutor-Lamp/camera_test/camera_server.py#L106))

Fields: `sharpness: float`, `elapsed: float`, `original: np.ndarray`, `cleaned: np.ndarray` (always populated), `page_found: bool`, `page_corners: Optional[np.ndarray]` (quad in source coords), `bw`, `segments` (optional), `debug_stages: list`, `debug_labels: list`.

Shared mutable server state is `_last_status = {"captures", "last", "sharpness"}` guarded by `_state_lock` (a `threading.Lock`) so `/upload` and `/status` don't race ([:98-100](Smart-Tutor-Lamp/camera_test/camera_server.py#L98)).

#### The 6-stage pipeline — algorithms in detail

**Stage 0 — Sharpness gate** (`centre_weighted_sharpness`, [:128](Smart-Tutor-Lamp/camera_test/camera_server.py#L128)). Crops the central third of the greyscale frame (`gray[cy-h/3:cy+h/3, cx-w/3:cx+w/3]`) and returns `cv2.Laplacian(crop, CV_64F).var()`. Centre-weighting prevents a sharp page in the middle being rejected because the blurred desk edge drags the global variance down. If `sharpness < MIN_SHARPNESS (60.0)`, `process_image` returns `None` → `/upload` responds **HTTP 422** so the ESP32 re-AFs and retries.

**Stage 1 — Page detection** (`detect_page_quad`, [:207](Smart-Tutor-Lamp/camera_test/camera_server.py#L207)). Algorithm:
1. Downscale to `scale = 700 / max(h,w)` (`INTER_AREA`).
2. Greyscale, then `bilateralFilter(gray, 9, 60, 60)` — kills JPEG row noise without softening page edges.
3. **OTSU** threshold (`THRESH_BINARY + THRESH_OTSU`) → paper (bright) vs surround (dark).
4. `MORPH_CLOSE` with a 5×5 rect kernel, **3 iterations** — seals text/ink gaps into one connected blob.
5. If `PAGE_BINARY_GROW_PX > 0`, dilate the binary by a `(2·6+1)=13`px kernel — the OTSU edge sits a few px *inside* the true boundary; this recovers the strip.
6. `findContours(RETR_EXTERNAL)`, sort by area descending, take top 5.
7. For each contour with area ≥ `0.18 × frame_area`: try `approxPolyDP` at epsilon fractions `(0.02, 0.025, 0.03, 0.04, 0.05, 0.07, 0.10) × peri` until a **convex 4-vertex** polygon appears. If none, fall back to `minAreaRect → boxPoints`.
8. Order corners via `_order_corners` (the **x±y trick**: TL=argmin(x+y), TR=argmin(y−x), BR=argmax(x+y), BL=argmax(y−x) — [:160](Smart-Tutor-Lamp/camera_test/camera_server.py#L160)).
9. `_valid_quad` ([:173](Smart-Tutor-Lamp/camera_test/camera_server.py#L173)) rejects if avg width < 25% frame_w or avg height < 25% frame_h, or aspect ratio outside `(1/3.5, 3.5)`.
10. Scale corners back to full res (`/scale`), then `_expand_quad_outward` ([:187](Smart-Tutor-Lamp/camera_test/camera_server.py#L187)) pushes each corner from the centroid by `PAGE_QUAD_PADDING × mean_half_extent`, clamped to frame bounds. Returns the 4×2 float32 quad, or `None`.

**Stage 2 — Perspective warp** (`warp_quad_to_rectangle`, [:274](Smart-Tutor-Lamp/camera_test/camera_server.py#L274)). Output `width = max(‖TR−TL‖, ‖BR−BL‖)`, `height = max(‖BL−TL‖, ‖BR−TR‖)` (the longer of each parallel-edge pair so detail isn't lost on the leaning side). If either < 50 px, bail and return the input. `getPerspectiveTransform(src, dst)` then `warpPerspective` with `INTER_CUBIC` + `BORDER_REPLICATE`.

**Stage 1.5 — Denoise** (`denoise`, [:313](Smart-Tutor-Lamp/camera_test/camera_server.py#L313)). `DENOISE_STRENGTH 1` → `bilateralFilter(d=5, sigmaColor=25, sigmaSpace=25)`; `2` → `(d=7, 45, 45)`. Edge-preserving so the bleach stage (which amplifies 5–10×) doesn't print scratch-like banding.

**Stage 3 — Fine deskew** (`deskew_small`, [:327](Smart-Tutor-Lamp/camera_test/camera_server.py#L327)). Catches residual tilt up to ±6°. `Canny(50,150)` → `HoughLinesP(1, π/180, threshold=100, minLineLength=w//4, maxLineGap=20)`. Needs ≥5 lines; collects line angles within ±max_angle; if the **median** |angle| ≥ 0.3°, rotates by that median via `getRotationMatrix2D` + `warpAffine` (INTER_CUBIC, BORDER_REPLICATE, white fill).

**Stage 4 — Paper-masked bleach** (`bleach_background`, [:376](Smart-Tutor-Lamp/camera_test/camera_server.py#L376)). The core scanner effect, with an off-page-noise fix:
- Kernel `k = max(31, (short//20)|1)` (forced odd), `sigma = k/6`.
- Per channel: `MORPH_CLOSE` (erases text, leaves illumination) then `GaussianBlur(sigma)` → background estimate `bg`.
- Full-strength bleach: `bleached = clip(img / max(bg,1) × 255, 0, 255)`.
- **Paper-likelihood mask**: luminance of `bg`, `paper_white = 95th percentile`, ramp `lo = 0.40·paper_white`, `hi = 0.90·paper_white`, `mask = clip((bg_lum − lo)/span, 0, 1)`.
- Output `out = mask·bleached + (1−mask)·img` — bright (paper) regions get full bleach, dark (desk/hand) regions keep original values, blended with a soft ramp so edges don't band.

**Stage 5 — Contrast + sharpen** (`enhance_for_llm`, [:417](Smart-Tutor-Lamp/camera_test/camera_server.py#L417)). Convert to LAB, apply `CLAHE(clipLimit=1.5, tileGridSize=8×8)` to the L channel only (preserves colour — highlighter/ink), back to BGR. Then unsharp mask: `addWeighted(enhanced, 1.6, GaussianBlur(σ=1.2), −0.6, 0)`.

**Stage 6a — Binary OCR variant** (`to_binary`, [:433](Smart-Tutor-Lamp/camera_test/camera_server.py#L433), only if `SAVE_BW`). `adaptiveThreshold(GAUSSIAN_C, blockSize=25, C=10)` then `MORPH_OPEN` 2×2 to remove pepper noise.

**Stage 6b — Content segmentation** (`segment_content`, [:455](Smart-Tutor-Lamp/camera_test/camera_server.py#L455), only if `SAVE_SEGMENTS`). Invert binary; horizontal dilate (`(max(15,w//60),3)`) merges characters→lines; vertical dilate (`(3,max(8,h//80))`) merges lines→blocks; `findContours`; for each box with area ≥ `0.0005·h·w` and `cw≥20, ch≥10`, colour-code by aspect ratio: `ar>4 or ch<25` → green text line; `0.6<ar<1.4 and ch>60` → blue-orange figure; else orange paragraph. Blend overlay 0.85/0.15 and stamp "N regions detected".

`make_debug_grid` ([:510](Smart-Tutor-Lamp/camera_test/camera_server.py#L510)) tiles stages into a 2×3 panel grid with labels.

#### `process_image()` pipeline orchestration ([:546](Smart-Tutor-Lamp/camera_test/camera_server.py#L546))

`sharpness gate → (page quad? warp : full frame) → denoise → deskew → bleach → enhance → optional bw/segments/debug`. Returns a `StageOutputs` or `None` (blurry).

#### HTTP routes ([:629-742](Smart-Tutor-Lamp/camera_test/camera_server.py#L629))

- **`POST /upload`** — decode JPEG (`_decode_jpeg` via `cv2.imdecode`, 400 on decode fail); run pipeline; **422** `{"status":"rejected","reason":"too_blurry",...}` if `None`; else save files (`{ts}_original.jpg`, `{ts}_cleaned.png`, optional bw/segments/debug), update `_last_status` under the lock, return **200** JSON with `sharpness`, `elapsed_s`, `page_found`, `size_px`, `files`.
- **`POST /preview`** — write raw bytes to `PREVIEW_PATH`, compute a quick centre-weighted sharpness, return `{"sharpness": ...}`.
- **`GET /preview`** — `?raw=1` serves the JPEG; otherwise an HTML page that auto-refreshes every 2 s for live manual-focus tuning.
- **`GET /latest`** — most recent `*_cleaned.png`.
- **`GET /status`** — JSON snapshot of `_last_status` + `save_dir`.

Server binds `0.0.0.0:5000`, `threaded=True` ([:765](Smart-Tutor-Lamp/camera_test/camera_server.py#L765)).

### 3.3 `board_config.h` / `camera_pins.h`

`board_config.h` ([board_config.h:1-34](Smart-Tutor-Lamp/camera_test/board_config.h#L1)) is the standard Espressif camera-model selector: a list of `#define CAMERA_MODEL_*` macros, exactly one uncommented (here `CAMERA_MODEL_ESP32S3_EYE`), then `#include "camera_pins.h"`. `camera_pins.h` ([camera_pins.h:1-339](Smart-Tutor-Lamp/camera_test/camera_pins.h#L1)) is the canonical per-board GPIO pin map (`#if defined(CAMERA_MODEL_*)` blocks). The `ESP32S3_EYE` block ([:297-315](Smart-Tutor-Lamp/camera_test/camera_pins.h#L297)) gives `XCLK=15, SIOD=4, SIOC=5, Y2..Y9=11/9/8/10/12/18/17/16, VSYNC=6, HREF=7, PCLK=13` — **identical to the inline pin `#define`s in `camera_test.ino`**, which is why the sketch compiles without actually `#include`-ing these headers (they document the pinout and support porting to other boards). An unselected model triggers `#error "Camera model not selected"`.

### 3.4 `docs/README.md`

A 420-line operator manual ([docs/README.md](Smart-Tutor-Lamp/camera_test/docs/README.md)): hardware/wiring (notably the **AF-VCC** requirement — solder 3V3 to FPC pin 24 if `focusInit()` fails), Arduino IDE settings (`ESP32S3 Dev Module`, `OPI PSRAM`, `Huge APP 3MB No OTA`, `USB CDC On Boot Enabled`, upload 921600), the OV5640 AF library install, config tables, the full serial-command reference, focus-mode explanations, the quality-vs-overflow tradeoff table, server setup, HTTP endpoint docs with example 200/422 JSON, the processing pipeline diagram, output-file table, four typical workflows (auto-focus, manual focus, overflow troubleshooting, batch capture), and a troubleshooting section.

```mermaid
sequenceDiagram
    participant U as User (Serial)
    participant E as ESP32-S3 (camera_test.ino)
    participant S as Flask (camera_server.py)
    U->>E: 'C' (full capture)
    alt AUTO mode
        E->>E: trigger_autofocus() (poll REG_AF_STAT, ≤4s)
    end
    E->>E: set UXGA + apply_doc_settings
    loop until accepted / retries exhausted
        E->>E: grab_after_flush(flush=2)
        alt fb == NULL (FB-OVF)
            E->>E: bump quality, delay 300ms, retry
        else fb OK
            E->>S: POST /upload (raw JPEG)
            S->>S: sharpness gate (Laplacian var ≥60)
            alt too blurry
                S-->>E: 422
                E->>E: re-AF + retry (≤2)
            else ok
                S->>S: detect quad → warp → denoise → deskew → bleach → CLAHE
                S->>S: save {ts}_cleaned.png
                S-->>E: 200 {sharpness,page_found,size_px,files}
            end
        end
    end
    E->>E: restore VGA idle
```

---

## 4. `ei_data_collector/` — Edge Impulse wake-word data collection

### Purpose

Stream INMP441 microphone audio at 16 kHz mono as one signed-16-bit integer per line over Serial, in the exact format the `edge-impulse-data-forwarder` expects. This captures the **training dataset** for the "hey-lamp" / "hey lumos" wake-word model that the production `tutor_lamp/wake_word.{h,cpp}` later runs. The directory contains two versions:

### `ei_data_collector.ino` (FINAL) ([ei_data_collector.ino:1-55](Smart-Tutor-Lamp/ei_data_collector/ei_data_collector.ino#L1))

The shipped, simplified collector. Config: `I2S_PORT = port 1` ("matches inference" per the comment), `PIN_BCK=40, PIN_WS=39, PIN_DIN=1`, `SAMPLE_RATE=16000`, `sampleBuffer[512]` int16. `setup()`: Serial @ **2_000_000 baud**, I2S MASTER+RX, **16-bit per sample**, `ONLY_LEFT`, standard `I2S_COMM_FORMAT_I2S`, `dma_buf_count=8`, `dma_buf_len=512`, then drains 10 reads (~AGC settle). `loop()`: `i2s_read` 512 samples, **multiply each by 8** ("gain, same as inference") and `snprintf("%d\n")` over Serial.

> Run on PC: `edge-impulse-data-forwarder --baud-rate 2000000 --frequency 16000`.

### `mic_EI.txt` (earlier variant) ([mic_EI.txt:1-77](Smart-Tutor-Lamp/ei_data_collector/mic_EI.txt#L1))

Despite the `.txt` extension this is the *earlier* `.ino` (its header literally says `ei_data_collector.ino`). Crucially it differs from the FINAL: it uses **`I2S_NUM_0`**, **32-bit I2S frames** (`I2S_BITS_PER_SAMPLE_32BIT` — correct for the INMP441 which left-justifies 24-bit audio in a 32-bit frame), `dma_buf_len=256`, `MIC_SHIFT=4` (`+24 dB`), `sat16()` saturation, and a **DC-blocker IIR filter**:

```
s = raw[i] >> 8;                                   // extract 24-bit sample
y = s - dc_x + ((int64)dc_y * 32604) >> 15;        // y[n] = x[n]-x[n-1]+0.995·y[n-1]
dc_x = s; dc_y = y;
pcm[i] = sat16(y >> MIC_SHIFT);
```

The Q15 coefficient `32604 ≈ 0.995 × 32768`. This DSP chain (DC block + `>>4` gain + `sat16`) is the **same chain the wake-word inference uses** ([wake_word_hey_lamp.ino:78-90](Smart-Tutor-Lamp/Wake%20word/wake_word_hey_lamp/wake_word_hey_lamp.ino#L78)). The wake-word sketch's header documents the cautionary tale ([:6-21](Smart-Tutor-Lamp/Wake%20word/wake_word_hey_lamp/wake_word_hey_lamp.ino#L6)): the original ASCII-per-sample collector at 16 kHz (~110 KB/s of CDC traffic) blocked the I2S loop, the DMA buffers overran, EI labelled gappy/time-compressed audio as "continuous", and the model learned features that only exist in compressed audio → at runtime (true continuous audio) it always voted "noise". The fix is to recapture with a binary stream or upload WAV files via EI Studio so training audio is genuinely 16 kHz continuous — hence the 2 Mbaud serial in both collectors and the WAV-saving `mic_recorder` below.

### Relationship to production firmware

The trained model produced from this data is consumed by `wake_word_hey_lamp.ino` (inference rig) and ultimately by `tutor_lamp/wake_word.{h,cpp}`. The pin map (`40/39/1`) and `MIC_SHIFT=4` are shared across the collector, recorder, inference sketch and the production mic path, guaranteeing DSP parity from training through deployment.

---

## 5. `mic_recorder/` — dual-mode mic recorder + EI forwarder

### Purpose

A single 16 kHz audio pipeline with two operating modes, controlled by one keystroke, that **always** streams PCM over WiFi to `mic_server.py` (which saves a WAV in `recordings/`) and *additionally* in EI mode prints one int16/line over Serial @ 2 Mbaud for the Edge Impulse forwarder. The explicit guarantee ([mic_recorder.ino:5-7](Smart-Tutor-Lamp/mic_recorder/mic_recorder.ino#L5)): the saved WAV is byte-for-byte the audio EI Studio receives, and the DSP is identical to the wake-word inference path.

### Configuration ([:36-58](Smart-Tutor-Lamp/mic_recorder/mic_recorder.ino#L36))

`SSID/PASSWORD` = `ACT_4g`/`Samiul2004`; `PC_IP="192.168.0.4"`, `PC_PORT=5055`; `I2S_PORT=I2S_NUM_0`, pins `40/39/1`; `SAMPLE_RATE=16000`; `DMA_BUFS=8`, `DMA_BUF_LEN=256` (~16 ms @ 16 kHz); `BAUD_NORMAL=115200`, `BAUD_EI=2000000` (16 kHz CSV ≈ 96 KB/s needs ≥1.5 Mbaud); `MIC_SHIFT=4` (the gain right-shift: 8=unity, 6=+12 dB, 5=+18 dB, 4=+24 dB, 3=+30 dB).

### Architecture & data structures

- `enum Mode { MODE_IDLE=0, MODE_RECORD=1, MODE_EI=2 }`; `volatile Mode mode`.
- `WiFiClient client`; static `int32_t raw[256]`, `int16_t pcm[256]` capture/output buffers.
- `sat16()` — same int16 saturation helper.
- A dedicated FreeRTOS task **`mic_task` pinned to core 1, priority 2** does capture+DSP+dispatch; `loop()` on core 0 only reads serial commands. This core-split is the same decoupling the production firmware uses.

### Function-by-function

- **`i2s_init()`** ([:70](Smart-Tutor-Lamp/mic_recorder/mic_recorder.ino#L70)) — MASTER+RX, **32-bit frames**, `ONLY_LEFT`, `STAND_I2S`, `intr LEVEL1`, 8×256 DMA, no APLL.
- **`primeCapture()`** ([:107](Smart-Tutor-Lamp/mic_recorder/mic_recorder.ino#L107)) — zero DMA + 10 reads (~150 ms) so the mic AGC and DC blocker settle before the first kept sample.
- **`connectPC()`** ([:117](Smart-Tutor-Lamp/mic_recorder/mic_recorder.ino#L117)) — TCP connect to `PC_IP:PC_PORT`; error if `mic_server.py` isn't running.
- **`startRecord()`/`stopRecord()`** ([:126](Smart-Tutor-Lamp/mic_recorder/mic_recorder.ino#L126)) — IDLE→RECORD (connect+prime) / RECORD→IDLE (flush+stop).
- **`startEI()`/`stopEI()`** ([:142](Smart-Tutor-Lamp/mic_recorder/mic_recorder.ino#L142)) — EI mode raises the serial baud to `BAUD_EI` *after* flushing (so the instructions print at the readable 115200), primes capture; stop drops back to 115200.
- **`abortToIdle()`** ([:168](Smart-Tutor-Lamp/mic_recorder/mic_recorder.ino#L168)) — generic recovery when TCP dies in either mode (restores baud if it was EI).
- **`mic_task()`** ([:181](Smart-Tutor-Lamp/mic_recorder/mic_recorder.ino#L181)) — the heart. While running: if IDLE, reset DC filter state and `vTaskDelay(20ms)`; if `!client.connected()` → `abortToIdle()`. Otherwise `i2s_read` 100 ms-timeout, then per sample apply the **same DC blocker + gain + sat16** as `mic_EI.txt`/inference (`s=raw>>8; y=s-dc_x+((dc_y*32604)>>15); pcm=sat16(y>>MIC_SHIFT)`). **Sink #1**: always `client.write(pcm)` → WiFi → WAV. **Sink #2** (EI mode only): `snprintf("%d\n")` over Serial → forwarder. Because both sinks carry the same samples, the WAV equals what EI Studio sees.
- **`setup()`** ([:232](Smart-Tutor-Lamp/mic_recorder/mic_recorder.ino#L232)) — CPU @ 160 MHz, WiFi join (blocking), `WIFI_PS_MIN_MODEM` power save, `setTxPower(13 dBm)`, `i2s_init`, spawn `mic_task` (4096 stack, prio 2, core 1).
- **`loop()`** ([:258](Smart-Tutor-Lamp/mic_recorder/mic_recorder.ino#L258)) — dispatch `s`/`e`/`d`/`x`; `vTaskDelay(20ms)`.

### Relationship to production firmware

`mic_recorder` is the *bridge* between data collection and inference: it validates the full INMP441 → DSP → network path that `tutor_lamp/mic_i2s.{h,cpp}` implements, and its EI mode feeds the same dataset pipeline as `ei_data_collector`. Its core-1 pinned capture task and `MIC_SHIFT=4` mirror the production mic capture task referenced in [net_ws.h:11-12](Smart-Tutor-Lamp/tutor_lamp/net_ws.h#L11) ("the mic capture task (core 1, prio 8)").

---

## 6. `push_buttons/` — resistor-ladder ADC button probe

### Purpose

The smallest sketch in the set ([push_buttons.ino:1-34](Smart-Tutor-Lamp/push_buttons/push_buttons.ino#L1)): proves the 5-button **resistor-ladder** hardware where all five buttons share a single ADC pin (GPIO 2), each pulling that pin to a distinct voltage. It is the direct ancestor of `tutor_lamp/buttons.{h,cpp}`, whose header explicitly says "Mapping matches `push_buttons/push_buttons.ino`" ([buttons.h:6](Smart-Tutor-Lamp/tutor_lamp/buttons.h#L6)).

### Mechanics

- `ADC_PIN = 2`; `setup()` sets Serial 115200 and `analogSetPinAttenuation(ADC_PIN, ADC_ATTENDB_MAX)` to read up to ~3.1 V linearly.
- **`getPressedButton()`** ([:17](Smart-Tutor-Lamp/push_buttons/push_buttons.ino#L17)) — reads the 12-bit ADC (0–4095) and thresholds bottom-up:

| ADC range | Button | Approx voltage / ADC |
|---|---|---|
| `< 200` | 1 | ~0.00 V → ADC ~0 |
| `< 600` | 2 | ~0.30 V → ~395 |
| `< 1100` | 3 | ~0.59 V → ~780 |
| `< 1700` | 4 | ~1.05 V → ~1380 |
| `< 2800` | 5 | ~1.65 V → ~2180 |
| else | 0 (none) | ~3.30 V → 4095 |

- `loop()` polls every 100 ms and prints "Button N Pressed (ADC: …)" when non-zero.

### Relationship to production firmware

The exact same thresholds and the no-press≈4095 sentinel are inherited by `buttons.{h,cpp}`, which adds **edge detection (one event per press, release-rearm), ~50 ms debounce, rate-limiting, and a 1500 ms long-press for SELECT** ([buttons.h:26-71](Smart-Tutor-Lamp/tutor_lamp/buttons.h#L26)). The header also documents a later **BTN3/BTN4 swap** — physical Button 3 now triggers `BTN_DOWN`, Button 4 triggers `BTN_RIGHT` — and stable internal IDs (`BTN_LEFT=1, BTN_SELECT=2, BTN_RIGHT=3, BTN_DOWN=4, BTN_UP=5, BTN_SELECT_LONG=6`). The comment block in `push_buttons.ino` ([:4-8](Smart-Tutor-Lamp/push_buttons/push_buttons.ino#L4)) records the original mapping (5→Up, 4→Down, 3→Right, 2→Centre, 1→Left). Production also exposes `held()` for hold-to-talk (used by the turn flow).

---

## 7. `tft_latex_client/` — TFT LaTeX rendering client

### Purpose

A TFT-panel bring-up rig for the lamp's LaTeX display path ([tft_latex_client.ino:1-5](Smart-Tutor-Lamp/tft_latex_client/tft_latex_client.ino#L1)). The ESP32 sends a LaTeX string to a PC server, receives a stream of **RGB565** pixel frames, and paints them with **hardware scroll** support (multi-frame payloads for equations too wide for the 320×240 landscape panel). It validates the exact wire protocol that `tutor_lamp/tft_ui.{h,cpp}` consumes from the real backend, and supplies the canonical "stress test" equations.

### Configuration & data ([:11-39](Smart-Tutor-Lamp/tft_latex_client/tft_latex_client.ino#L11))

`SSID/PASSWORD`; `SERVER_HOST="192.168.0.3"`, `SERVER_PORT=5050`; `HEADER_SIZE=8`, `CHUNK_SIZE=2048`. A `const char* EQUATIONS[]` array of LaTeX strings (Euler's identity, the quadratic formula, the Gaussian integral, Maxwell, the Fourier transform, the exp series, the Basel sum, Bayes, Schrödinger, Navier-Stokes, and an "ULTIMATE STRESS TEST" wide integral at index 10). `NUM_EQUATIONS=11`. `TFT_eSPI tft`; `WiFiClient client`; `static uint8_t renderBuf[CHUNK_SIZE+1]` (the +1 holds a carry byte).

> `EQUATIONS[10]` is reused verbatim by `dummy_backend.py` as `LATEX_CRAZY` ([dummy_backend.py:64-73](Smart-Tutor-Lamp/dummy_backend.py#L64)).

### The 8-byte frame header

Sent by the server after the LaTeX request, parsed at [:79-82](Smart-Tutor-Lamp/tft_latex_client/tft_latex_client.ino#L79):

| Bytes | Field | Encoding |
|---|---|---|
| 0–1 | `frameW` | u16 big-endian |
| 2–3 | `frameH` | u16 big-endian |
| 4 | `fmt` | format (0 = RGB565; anything else → error) |
| 5–7 | `payloadLen` | u24 big-endian (total pixel bytes across all frames) |

`frameSize = frameW × frameH × 2`; `numFrames = payloadLen / frameSize` (min 1).

### Function-by-function

- **`showStatus(line1, line2, col)`** ([:41](Smart-Tutor-Lamp/tft_latex_client/tft_latex_client.ino#L41)) — clears the screen and prints up to two status lines at size 2.
- **`renderEquation(eq)`** ([:54](Smart-Tutor-Lamp/tft_latex_client/tft_latex_client.ino#L54)) — the full request/render flow:
  1. `client.stop()`, show "Connecting…", `client.connect(SERVER_HOST, SERVER_PORT)`; on fail show red "Server connect FAILED".
  2. Send the request: a **2-byte big-endian length prefix** `(eqLen>>8, eqLen&0xFF)` followed by the raw LaTeX bytes.
  3. `setTimeout(8000)`, `readBytes(header, 8)`; if `< 8` → "Header timeout".
  4. Parse header; if `fmt != 0` → "Format error / expected rgb565".
  5. **Hardware scroll loop** (one independent frame at a time, [:102](Smart-Tutor-Lamp/tft_latex_client/tft_latex_client.ino#L102)): for each frame, `tft.startWrite(); tft.setAddrWindow(0,0,frameW,frameH)`. Then fill `frameSize` bytes: read up to `min(avail, CHUNK_SIZE-carry, frameSize-frameRead)` into `renderBuf+carry`, compute `pixels = (n+carry)/2`, `tft.pushColors((uint16_t*)renderBuf, pixels, false)` (`swap=false` — bytes are already in panel order), handle the **odd-byte carry** by saving the last byte to `renderBuf[0]` for the next read, and bail if no byte arrives for **3000 ms** (`client.setTimeout(3000)` + `lastByteTime` watchdog). `tft.endWrite()` per frame.
  6. `client.stop()`; return `totalRead >= payloadLen`.
- **`setup()`** ([:148](Smart-Tutor-Lamp/tft_latex_client/tft_latex_client.ino#L148)) — Serial 115200, `tft.begin()`, `setRotation(3)` (landscape 320×240), WiFi join (blocking), prompt "Send 0-10 via Serial monitor".
- **`loop()`** ([:169](Smart-Tutor-Lamp/tft_latex_client/tft_latex_client.ino#L169)) — peeks a digit `0–9`, `parseInt()`, bounds-checks against `NUM_EQUATIONS`, calls `renderEquation(EQUATIONS[choice])`. (Note: only digits `0–9` are reachable through `Serial.peek`, so equation index 10 is not selectable via this loop even though it exists in the array.)

### Relationship to production firmware

The wire format here — `[u16 W][u16 H][u8 nFrames][u8 rsv][RGB565 pixels]`, byte-swapped big-endian BGR, painted `swap=false` — is the **same inner TFT_FRAME layout** the backend sends to the lamp and that `tutor_lamp/tft_ui::on_tft_frame` consumes ([tft_ui.h:125](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h#L125)), as documented in `HARDWARE_CONTEXT.md` §5.3 and `IMPLEMENTATION_WEBSOCKET.md`. The lamp's `PAGE_SPEAKING_LATEX` page ([tft_ui.h:58](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h#L58)) scrolls through the `nFrames` with LEFT/RIGHT — the production analogue of this client's hardware-scroll loop. The PC renderer here is the same role `Latex_engine_tft.py` plays for `dummy_backend.py`.

---

## 8. `wifi_audio_player/` — WiFi PCM audio player

### Purpose

A network audio sink rig ([wifi_audio_player.ino:1-18](Smart-Tutor-Lamp/wifi_audio_player/wifi_audio_player.ino#L1)): the ESP32-S3 + MAX98357A class-D amp receives raw PCM (**16-bit, 44100 Hz, stereo**) over **TCP or UDP** and plays it via I2S, using a ring buffer and two FreeRTOS tasks on separate cores to decouple network ingest from audio output. This is the de-risking ground for the lamp's `spk_i2s.{h,cpp}` and the AUDIO_OUT playback path (the production lamp plays 24 kHz mono int16, not 44.1 kHz stereo — this rig tests the I2S/ring-buffer mechanics).

### Architecture

```
Network Rx (TCP/UDP) ──► Ring Buffer (32 KB) ──► I2S DMA ──► MAX98357A
   net_rx_task (core 0)        FreeRTOS ringbuf      i2s_tx_task (core 1)
```

### Configuration ([:28-58](Smart-Tutor-Lamp/wifi_audio_player/wifi_audio_player.ino#L28))

`STREAM_PORT=5005` (both TCP and UDP); `SAMPLE_RATE=44100`, 16-bit, `CHANNELS=2`, `BYTES_PER_FRAME=4`; I2S pins `BCLK=40, WS=39, DOUT=38`; `DMA_BUF_COUNT=4`, `DMA_BUF_LEN=256` (~23 ms latency); `RING_BUF_SIZE=32 KB` (~180 ms jitter absorption); `TCP_RX_BUF_SIZE=8192`, `UDP_RX_BUF_SIZE=1472` (one MTU), `I2S_WRITE_SIZE=1024`, `DIAG_INTERVAL=5000` ms.

### Data structures & globals ([:60-72](Smart-Tutor-Lamp/wifi_audio_player/wifi_audio_player.ino#L60))

`WiFiServer tcpServer(5005)`, `WiFiUDP udpSock`, `RingbufHandle_t ringBuf`; volatile flags `streamActive`, `isTcpStream`; counters `totalBytesRx`, `underrunCount`, `lastUdpTime`; static buffers `tcpRxBuf[8192]`, `udpRxBuf[1472]`, `i2sTxBuf[1024]`.

### Function-by-function

- **`i2s_init()`** ([:75](Smart-Tutor-Lamp/wifi_audio_player/wifi_audio_player.ino#L75)) — MASTER+TX, 44100/16-bit, `RIGHT_LEFT` channel format (stereo), `STAND_I2S`, `tx_desc_auto_clear=true`; `use_apll=true` only on classic ESP32, false on S3. `ESP_ERROR_CHECK` on install/set_pin/zero. Prints the computed DMA latency `(count·len·1000)/rate`.
- **`wifi_connect()`** ([:110](Smart-Tutor-Lamp/wifi_audio_player/wifi_audio_player.ino#L110)) — blocking join, then `WIFI_PS_MIN_MODEM` (modem sleeps between DTIM beacons; the 32 KB ring absorbs the burst gap) and `setTxPower(13 dBm)` (cuts PA heat).
- **`ring_push(data, len)`** ([:125](Smart-Tutor-Lamp/wifi_audio_player/wifi_audio_player.ino#L125)) — `xRingbufferSend(..., 0)` (non-blocking; returns false if full).
- **`ring_pop(dest, maxLen)`** ([:129](Smart-Tutor-Lamp/wifi_audio_player/wifi_audio_player.ino#L129)) — `xRingbufferReceiveUpTo(..., 10ms, maxLen)`, memcpy + return item; 0 if nothing within 10 ms.
- **`i2s_tx_task()`** (priority 2, core 1, [:142](Smart-Tutor-Lamp/wifi_audio_player/wifi_audio_player.ino#L142)) — when `streamActive`: pop up to 1024 B, **align down to whole frames** (`(got/4)*4`), `i2s_write(..., portMAX_DELAY)`. If nothing popped while active → `underrunCount++` and `vTaskDelay(1ms)`. Every 5 s prints `[DIAG] Ring %% | Rx KB | Underruns`.
- **`handle_tcp(client)`** ([:177](Smart-Tutor-Lamp/wifi_audio_player/wifi_audio_player.ino#L177)) — `setNoDelay(true)`, `setTimeout(5)`, zero DMA, reset counters, `streamActive=isTcpStream=true`; while connected, read available (≤8192) into `tcpRxBuf`, `ring_push`. On disconnect, drain 300 ms then `streamActive=false` + zero DMA.
- **`net_rx_task()`** (priority 1, core 0, [:210](Smart-Tutor-Lamp/wifi_audio_player/wifi_audio_player.ino#L210)) — accept TCP (→ `handle_tcp`); otherwise poll UDP: on first packet start the stream, read frame-aligned into `udpRxBuf`, `ring_push`, then **drain the whole burst** in an inner loop. UDP **end-of-stream = 2 s idle** (`millis()-lastUdpTime > 2000`) → drain 300 ms, stop. `vTaskDelay(5ms)`.
- **`setup()`** ([:267](Smart-Tutor-Lamp/wifi_audio_player/wifi_audio_player.ino#L267)) — CPU 160 MHz, banner, `i2s_init`, `wifi_connect`, `tcpServer.begin()+setNoDelay`, `udpSock.begin(5005)`, `xRingbufferCreate(32 KB, RINGBUF_TYPE_BYTEBUF)` (halts forever on alloc fail), spawn both tasks (net_rx core 0 for WiFi-driver affinity, i2s_tx core 1).
- **`loop()`** ([:304](Smart-Tutor-Lamp/wifi_audio_player/wifi_audio_player.ino#L304)) — **WiFi watchdog only**: every 5 s, if disconnected, stop stream, reconnect, restart servers.

### Relationship to production firmware

This rig validates the I2S TX + ring-buffer + dual-core decoupling pattern that `tutor_lamp/spk_i2s.{h,cpp}` uses for TTS playback. The production lamp receives `FRAME_AUDIO_OUT (0x10)` chunks over the WebSocket at **24 kHz mono int16** (see `net_ws.h` and the dummy backend's `RESPONSE_SAMPLE_RATE=24000`), feeds them into a speaker ring buffer, and the same underrun/ring-fill diagnostics concepts apply. The "32 KB ring absorbs ~100 ms burst gap" comment ([:118](Smart-Tutor-Lamp/wifi_audio_player/wifi_audio_player.ino#L118)) is the same jitter-absorption strategy the dummy backend's pacing (`CHUNK_INTERVAL_S=0.085`) is tuned against.

---

## 9. `dummy_backend.py` — full backend simulator

### Purpose

A **single-file, drop-in simulator** for the entire Tutor Lamp backend ([dummy_backend.py:1-26](Smart-Tutor-Lamp/dummy_backend.py#L1)). It runs a plain (no-auth, no-TLS) WebSocket server at `ws://0.0.0.0:8000/lamp/ws`, accepts a full lamp turn (optional image + audio command), saves the inputs, and streams a complete canned response back: STATE transitions, TTS audio (decoded from a local MP3 via ffmpeg to 24 kHz mono int16), and alternating LaTeX TFT_FRAME / TFT_TEXT display content. It lets you exercise the production `tutor_lamp` firmware end-to-end without the real FastAPI brain, TTS or DB.

### Setup (from the docstring)

1. Edit `RESPONSE_AUDIO_PATH` to a real local MP3/WAV.
2. ffmpeg on PATH (`winget install Gyan.FFmpeg`).
3. `pip install websockets numpy pillow matplotlib`.
4. In `tutor_lamp/net_ws.h` (actually `backend_config.h`) set `NET_WS_URL "ws://<pc-ip>:8000/lamp/ws"`.
5. `python dummy_backend.py`, then flash + boot the lamp.

### Configuration ([:43-50](Smart-Tutor-Lamp/dummy_backend.py#L43))

| Constant | Value | Effect |
|---|---|---|
| `WS_HOST`/`WS_PORT` | `0.0.0.0` / `8000` | Bind address |
| `RESPONSE_AUDIO_PATH` | `"One Direction - Night Changes.mp3"` | TTS source audio |
| `SAVE_DIR` | `./received` | Where received images/audio land |
| `CHUNK_BYTES` | `4096` | ~85 ms of audio at 24 kHz int16 mono |
| `CHUNK_INTERVAL_S` | `0.085` | Paces audio to exactly the lamp's playback rate (`4096 / (24000×2) = 85.3 ms`) — earlier 70 ms over-sent ~22% and overflowed the lamp's speaker ring |
| `RESPONSE_SAMPLE_RATE` | `24000` | Matches HARDWARE_CONTEXT §5.1 |
| `WS_MAX_FRAME_BYTES` | `2048` | Hard per-message cap (see below) |

`WS_MAX_FRAME_BYTES = 2 KB` exists because the ArduinoWebsockets library on the lamp builds a contiguous DRAM `std::string` of the message length on receive; anything larger exceeds the lamp's heap headroom under WiFi+camera+I2S load and crashes the chip (`std::bad_alloc → abort`) ([:102-107](Smart-Tutor-Lamp/dummy_backend.py#L102)). Every outgoing message stays ≤ this.

### Frame protocol constants ([:88-100](Smart-Tutor-Lamp/dummy_backend.py#L88))

These mirror `tutor_lamp/net_ws.h` `enum FrameType` exactly:

| Const | Byte | Direction | Meaning |
|---|---|---|---|
| `F_IMAGE_JPEG` | `0x01` | lamp→ | final/only image chunk (complete on receipt) |
| `F_AUDIO_CHUNK` | `0x02` | lamp→ | command audio chunk |
| `F_AUDIO_END` | `0x03` | lamp→ | end of command (triggers a response) |
| `F_CANCEL` | `0x04` | lamp→ | cancel in-flight turn |
| `F_IMAGE_PART` | `0x05` | lamp→ | intermediate image chunk (accumulate) |
| `F_AUDIO_OUT` | `0x10` | →lamp | TTS audio chunk |
| `F_AUDIO_OUT_END` | `0x11` | →lamp | TTS stream end |
| `F_TFT_FRAME` | `0x20` | →lamp | final/only TFT frame chunk |
| `F_TFT_TEXT` | `0x21` | →lamp | plain-text answer |
| `F_TFT_CLEAR` | `0x22` | →lamp | clear display |
| `F_TFT_PART` | `0x23` | →lamp | intermediate TFT frame chunk |
| `F_STATE` | `0x30` | →lamp | state byte (`0x00` idle, `0x02` thinking, `0x03` speaking) |

The wire frame is `[u8 type][u24 length BE][payload]` — `encode()` ([:109](Smart-Tutor-Lamp/dummy_backend.py#L109)) and `decode()` ([:113](Smart-Tutor-Lamp/dummy_backend.py#L113)) implement exactly this (the same header as `net_ws.h`).

### LaTeX renderer integration ([:122-165](Smart-Tutor-Lamp/dummy_backend.py#L122))

The script inserts its own directory into `sys.path` (so the `Latex_engine_tft` import works regardless of CWD — a documented past bug where running from a different directory silently disabled LaTeX), then imports `LatexRenderer, DisplayConfig, Orientation` from `Latex_engine_tft.py`. It builds `LATEX_CFG = DisplayConfig(orientation=LANDSCAPE)` giving `LATEX_W=320, LATEX_H=240`, pre-renders `LATEX_CRAZY` at startup (so a broken matplotlib expression fails immediately rather than mid-turn), and prints the resulting payload size and scroll-frame count. On any import/render failure it sets `LATEX_OK=False` and every turn falls back to TFT_TEXT only. The docstring warns that matplotlib mathtext supports only a LaTeX subset (no `\tfrac`, `\!`, `\substack`, `\boxed`, no amsmath).

**`build_tft_frame_payload(latex)`** ([:161](Smart-Tutor-Lamp/dummy_backend.py#L161)) — renders pixels, computes `n_frames = max(1, len(pixels)//(320·240·2))`, prepends the 6-byte inner header `struct.pack(">HHBB", W, H, n_frames, 0)`, returns `header + pixels` — the identical layout the TFT client parses.

### Audio loading ([:168](Smart-Tutor-Lamp/dummy_backend.py#L168))

**`load_pcm(path, sample_rate)`** shells out to ffmpeg: `ffmpeg -i path -f s16le -ar 24000 -ac 1 -` and returns the raw PCM stdout. Handles missing file (warn), missing ffmpeg (`FileNotFoundError`), and ffmpeg failure (`CalledProcessError`, prints first 200 chars of stderr), each returning `b""`. Timeout 60 s.

### `Session` class ([:190](Smart-Tutor-Lamp/dummy_backend.py#L190))

Per-connection state: `ws`, `image_bytes`, `image_accum: bytearray` (accumulates `F_IMAGE_PART` chunks), `audio_pcm: bytearray`, `turn_count`, `cancel: asyncio.Event`.

- **`send(type_, payload)`** — `ws.send(encode(...))`, swallows `ConnectionClosed`.
- **`_save_image()`** ([:206](Smart-Tutor-Lamp/dummy_backend.py#L206)) — writes `image_{ts}_t{turn}.jpg`.
- **`_save_audio()`** ([:214](Smart-Tutor-Lamp/dummy_backend.py#L214)) — writes a **16 kHz mono 16-bit WAV** (`command_{ts}_t{turn}.wav`) — note the *command* audio from the lamp is 16 kHz (response TTS is 24 kHz).
- **`on_audio_end()`** ([:227](Smart-Tutor-Lamp/dummy_backend.py#L227)) — increments turn, saves image+audio, resets buffers, clears cancel, calls `_respond()`.

### `_respond()` — the response turn ([:237](Smart-Tutor-Lamp/dummy_backend.py#L237))

The complete control flow that drives the lamp's display + audio + LED:

```
1. send STATE thinking (0x02)
2. wait up to 0.4 s on cancel event:
      cancelled? → send STATE idle (0x00); return
3. send STATE speaking (0x03)
4. send TFT_TEXT (DUMMY_TEXT) — small single message; lamp flips
   PAGE_THINKING → PAGE_SPEAKING_TEXT immediately
5. load_pcm() via ffmpeg (blocks ~0.3 s)
6. build_tft_frame_payload(LATEX_CRAZY) once (synchronous matplotlib)
7. asyncio.gather(_stream_audio_task(), _stream_latex_task()):
     - audio: F_AUDIO_OUT chunks of CHUNK_BYTES, paced CHUNK_INTERVAL_S
              between chunks via wait_for(cancel, timeout=0.085);
              cancel mid-audio breaks the loop
     - latex: _send_tft_frame_chunked(payload) — unpaced, slots into gaps
8. send AUDIO_OUT_END (0x11)
9. sleep 0.2 s; send STATE idle (0x00)
```

The two streams **interleave on the wire** because each `await ws.send` yields the event loop — audio is paced, LaTeX is back-to-back ~2 KB chunks filling the gaps, net wire load ~250–450 KB/s. Audio reaches the speaker immediately; the LaTeX completes a few seconds later, triggering the lamp's combined view (formula top, text bottom).

**`_send_tft_frame_chunked(payload)`** ([:336](Smart-Tutor-Lamp/dummy_backend.py#L336)) — if `len ≤ WS_MAX_FRAME_BYTES`, send one `F_TFT_FRAME`. Else send `F_TFT_PART` × N (each ≤ 2 KB), then a final `F_TFT_FRAME` carrying the remainder as terminator. The lamp reassembles into one buffer with the identical `[u16 W][u16 H][u8 nFrames][u8 rsv][pixels]` layout, so `tft_ui::on_tft_frame` is path-agnostic — mirroring how the lamp chunks IMAGE_JPEG.

`DUMMY_TEXT` ([:74](Smart-Tutor-Lamp/dummy_backend.py#L74)) is a long photosynthesis paragraph (long enough to test UP/DOWN text scrolling on `PAGE_SPEAKING_TEXT`).

### Connection handler & main ([:390-457](Smart-Tutor-Lamp/dummy_backend.py#L390))

**`handler(ws)`** ([:390](Smart-Tutor-Lamp/dummy_backend.py#L390)) — per connection: iterate inbound binary messages, `decode()`, dispatch:
- `F_IMAGE_PART` → `image_accum.extend(payload)`.
- `F_IMAGE_JPEG` → if accum non-empty, extend + finalize (chunked image); else treat payload as a single-frame image.
- `F_AUDIO_CHUNK` → `audio_pcm.extend(payload)`.
- `F_AUDIO_END` → `on_audio_end()` (the turn).
- `F_CANCEL` → `cancel.set()`.
- else → log unknown frame.

**`main()`** ([:434](Smart-Tutor-Lamp/dummy_backend.py#L434)) — prints a build banner + config, then `websockets.serve(handler, host, port, max_size=4 MB, ping_interval=None)` (4 MB headroom for IMAGE_JPEG up to ~200 KB; `ping_interval=None` because the lamp drives its own ping). Runs forever (`await asyncio.Future()`).

```mermaid
flowchart TD
    A[lamp connects ws://pc:8000/lamp/ws] --> B[handler: iterate binary msgs]
    B --> C{frame type}
    C -->|0x05 IMAGE_PART| D[image_accum += payload]
    C -->|0x01 IMAGE_JPEG| E[finalize image_bytes]
    C -->|0x02 AUDIO_CHUNK| F[audio_pcm += payload]
    C -->|0x04 CANCEL| G[cancel.set]
    C -->|0x03 AUDIO_END| H[on_audio_end]
    H --> I[save .jpg + 16kHz .wav]
    I --> J[_respond]
    J --> K[STATE thinking 0x02]
    K --> L{cancel within 0.4s?}
    L -->|yes| M[STATE idle 0x00 → return]
    L -->|no| N[STATE speaking 0x03]
    N --> O[TFT_TEXT 0x21]
    O --> P[ffmpeg → 24kHz PCM]
    P --> Q[render LATEX_CRAZY → TFT_FRAME payload]
    Q --> R[gather: AUDIO_OUT paced 85ms + TFT_PART/TFT_FRAME chunked]
    R --> S[AUDIO_OUT_END 0x11]
    S --> T[STATE idle 0x00]
```

### Relationship to production firmware

`dummy_backend.py` is the firmware developer's primary local test harness. It speaks the exact `net_ws.h` protocol, honours the lamp's `WS_MAX_FRAME_BYTES`/heap constraints, paces audio to the lamp's 24 kHz ring buffer, and drives the lamp's full TFT page state machine (`PAGE_THINKING → PAGE_SPEAKING_TEXT → combined LaTeX view`, [tft_ui.h:55-58](Smart-Tutor-Lamp/tutor_lamp/tft_ui.h#L55)) and LED via STATE bytes. It deliberately exercises *both* display paths (alternating-by-comment LaTeX/text) and the *chunked* IMAGE/TFT reassembly logic. The real backend (FastAPI) implements the same protocol with `FRAME_AUDIO_OUT_ADPCM (0x12)`, `FRAME_AUDIO_OUT_OPUS (0x13)`, `FRAME_TFT_APPEND (0x25/0x26)` and auth (close code 4401) that this simulator omits.

---

## 10. Cross-reference matrix: test rig → production firmware

| Test rig artifact | Production firmware module | What is shared |
|---|---|---|
| `camera_test.ino` capture state machine | `tutor_lamp/camera.{h,cpp}` | OV5640 init, UXGA capture, FB-OVF recovery |
| `camera_test/camera_pins.h` (`ESP32S3_EYE`) | `tutor_lamp/camera_pins.h` | identical camera GPIO map |
| `camera_server.py` pipeline | backend image-cleanup stage | sharpness gate, page warp, bleach |
| `ei_data_collector` / `mic_EI.txt` | `tutor_lamp/wake_word.{h,cpp}` | training data for the wake-word model |
| `mic_recorder.ino` DSP (`s>>8`, DC blocker `*32604>>15`, `>>MIC_SHIFT`, `sat16`) | `tutor_lamp/mic_i2s.{h,cpp}`, `wake_word_hey_lamp.ino` | byte-identical mic DSP chain (parity guarantee) |
| `push_buttons.ino` ADC thresholds | `tutor_lamp/buttons.{h,cpp}` | resistor-ladder mapping (`<200/600/1100/1700/2800`) |
| `tft_latex_client.ino` RGB565 frame + HW scroll | `tutor_lamp/tft_ui.{h,cpp}` | `[W][H][nFrames][rsv][pixels]` layout, `pushColors(swap=false)`, scroll frames; `EQUATIONS[10]` |
| `wifi_audio_player.ino` ring buffer + I2S TX | `tutor_lamp/spk_i2s.{h,cpp}` | dual-core decouple, ring jitter absorption, MAX98357A pins (38/39/40) |
| `dummy_backend.py` frame constants & turn flow | `tutor_lamp/net_ws.{h,cpp}`, `tft_ui`, LED | full WS protocol, STATE machine, chunking, audio pacing |

---

## 11. Shared constants, pin maps & magic numbers

**INMP441 microphone pins** (collector, recorder, inference, production): `BCK=40, WS=39, DIN=1`, L/R→GND (left channel), 16 kHz, 32-bit I2S frames, `ONLY_LEFT`.

**MAX98357A speaker pins** (`wifi_audio_player`): `BCLK=40, WS=39, DOUT=38` — note the speaker shares `BCK/WS` GPIOs with the mic in the *test rigs* (they are not run together there).

**OV5640 camera pins** (`camera_test`, ESP32S3-EYE map): `XCLK=15, SIOD=4, SIOC=5, D0..D7=11/9/8/10/12/18/17/16, VSYNC=6, HREF=7, PCLK=13`, 10 MHz XCLK.

**Button ADC pin**: `GPIO 2`, max attenuation, thresholds `<200/600/1100/1700/2800`.

**Mic DSP magic numbers**: DC-blocker Q15 coefficient `32604 ≈ 0.995×32768`; `MIC_SHIFT=4` (+24 dB); `sat16` clamps to `[-32768, 32767]`; AGC settle = 10× `i2s_read` (~150 ms).

**WiFi**: SSID `ACT_4g`, password `Samiul2004`, `WIFI_PS_MIN_MODEM`, TX power 13 dBm (recorder/player) — recurring across the rigs.

**WS frame header**: `[u8 type][u24 length BE]`; TFT inner header `[u16 W BE][u16 H BE][u8 nFrames][u8 rsv]`; per-message cap 2 KB (lamp heap), server `max_size` 4 MB.

**Audio rates**: command uplink 16 kHz mono int16; TTS downlink 24 kHz mono int16; player rig 44.1 kHz stereo. Pacing `CHUNK_BYTES=4096` @ `0.085 s` = exact 24 kHz playback rate.

---

## 12. Edge cases, error handling & fallbacks (consolidated)

- **Camera FB-OVF** (null `fb` at UXGA): auto-lower quality (`+QUALITY_STEP`, capped at 30), retry up to `MAX_RETRIES_ON_OVF (3)`, 300 ms settle between tries; give up with a hint to press `Q`.
- **Camera blur (server 422)**: re-autofocus (AUTO mode) and retry up to `MAX_RETRIES_ON_BLUR (2)`.
- **Camera AF timeout/fail**: `trigger_autofocus` distinguishes LOCK (`0x10`), FAIL (pure `0x40`), IDLE-but-focused (`0x70` + `saw_focused`), and timeout; capture proceeds regardless (server gate is the safety net).
- **Camera no PSRAM**: fall back to SVGA in DRAM, `fb_count=1`.
- **Camera WiFi timeout (30 s)**: continue anyway (capture will just fail at POST).
- **Server JPEG decode fail**: HTTP 400. **Blurry**: 422. **No page quad**: clean the full frame (`page_found=false`, not an error). **Tiny warp (<50 px)**: skip warp.
- **Server thread safety**: `_state_lock` guards `_last_status`.
- **EI collector serial overrun** (the historical bug): mitigated by 2 Mbaud + binary/WAV capture so training audio stays continuous.
- **mic_recorder TCP drop** mid-stream: `mic_task` detects `!client.connected()` → `abortToIdle()` (restores baud if EI).
- **mic_recorder PC unreachable**: `connectPC()` returns false, mode stays IDLE with an error print.
- **TFT header timeout (8 s)** / **inter-byte timeout (3 s)** / **wrong format byte**: red status, abort, `client.stop()`. Odd trailing byte carried into the next read.
- **Audio player ring full**: `ring_push` drops (non-blocking send). **Underrun**: counted + 1 ms backoff. **TCP disconnect / UDP 2 s idle**: 300 ms drain then zero DMA. **Ring alloc fail**: halt forever. **WiFi lost**: watchdog reconnects and restarts servers. Frame alignment enforced everywhere (`(n/BYTES_PER_FRAME)*BYTES_PER_FRAME`).
- **dummy_backend LaTeX import/render fail**: `LATEX_OK=False`, fall back to TFT_TEXT only (pre-render at startup surfaces the error early). **ffmpeg missing/failed/file-not-found**: return `b""`, warn, no audio sent. **Cancel** during thinking → idle; during audio → break the stream loop. **Oversize message**: always chunked ≤ 2 KB to protect the lamp's heap. **ConnectionClosed**: swallowed in `send()` and the handler.

---

*End of reference. All behaviour above is taken directly from the source files in `Smart-Tutor-Lamp/camera_test/`, `ei_data_collector/`, `mic_recorder/`, `push_buttons/`, `tft_latex_client/`, `wifi_audio_player/`, and `dummy_backend.py`, with cross-references into `tutor_lamp/` headers and `HARDWARE_CONTEXT.md` / `IMPLEMENTATION_WEBSOCKET.md`.*

---

_Re-verified on 2026-07-06: none of the test-sketch/subproject folders (camera_test, mic_recorder, wifi_audio_player, push_buttons, tft_latex_client, ei_data_collector, Wake word) have changed since this doc was written — all firmware commits since 2026-06-16 touched only tutor_lamp/._
