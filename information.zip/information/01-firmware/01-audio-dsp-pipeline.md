# Firmware — Audio Capture & DSP Pipeline (VAD, AGC, NS, ALE, Wake Word, ADPCM)

This is the definitive, line-grounded reference for the ESP32‑S3 "Smart Tutor Lamp" firmware audio subsystem: how raw acoustic energy from an INMP441 I2S microphone is turned into a training‑identical sample stream, fed to an Edge Impulse continuous wake‑word classifier, then cleaned by a four‑stage DSP chain (Noise Suppression → Adaptive Line Enhancer → Automatic Gain Control → Voice Activity Detection), encoded with IMA/DVI ADPCM for the uplink, and how the matching ADPCM decoder + MAX98357A I2S speaker output render the backend's TTS reply. Every constant, threshold, coefficient, and ordering invariant is quoted from the source. The microphone and speaker share one physical I2S controller, so a large part of this document is about the *half‑duplex handoff* and the cross‑core races it creates.

All citations point at files under `tutor_lamp/` in the `Smart-Tutor-Lamp` repository.

---

## Table of Contents

1. [Purpose & Responsibility](#1-purpose--responsibility)
2. [Architecture Overview](#2-architecture-overview)
3. [End-to-End Control Flow](#3-end-to-end-control-flow)
4. [I2S Microphone Capture (`mic_i2s`)](#4-i2s-microphone-capture-mic_i2s)
5. [Training-Identical DSP — `apply_dsp()`](#5-training-identical-dsp--apply_dsp)
6. [Wake-Word Detection (`wake_word`)](#6-wake-word-detection-wake_word)
7. [The Post-Process Chain Orchestrator (`audio_post_process`)](#7-the-post-process-chain-orchestrator-audio_post_process)
8. [Stage A — Noise Suppression (`ns_stage`)](#8-stage-a--noise-suppression-ns_stage)
9. [Stage B — Adaptive Line Enhancer (`ale_stage`)](#9-stage-b--adaptive-line-enhancer-ale_stage)
10. [Stage C — Automatic Gain Control (`agc_stage`)](#10-stage-c--automatic-gain-control-agc_stage)
11. [Stage D — Voice Activity Detection (`vad_stage`)](#11-stage-d--voice-activity-detection-vad_stage)
12. [Command Recording & End-of-Speech (EOS)](#12-command-recording--end-of-speech-eos)
13. [ADPCM Codec (`adpcm_dec`)](#13-adpcm-codec-adpcm_dec)
14. [Speaker Output (`spk_i2s`)](#14-speaker-output-spk_i2s)
15. [The Half-Duplex Handoff & Cross-Core Races](#15-the-half-duplex-handoff--cross-core-races)
16. [Configuration & Constants Reference](#16-configuration--constants-reference)
17. [Edge Cases, Error Handling, Timeouts, Fallbacks](#17-edge-cases-error-handling-timeouts-fallbacks)
18. [Integration Points (Cross-References)](#18-integration-points-cross-references)
19. [Mermaid Diagrams](#19-mermaid-diagrams)

---

## 1. Purpose & Responsibility

The audio subsystem is the lamp's "ears and mouth." It must:

1. **Capture** PCM audio from the INMP441 MEMS microphone over I2S at the **exact** sample rate, framing, and bit‑level DSP that the Edge Impulse (EI) wake‑word model was trained on — any deviation frequency‑shifts or amplitude‑distorts the signal and the classifier misses "hey lumos." The training‑identical chain is `rawBuffer[i] >> 8 → DC-blocker IIR (Q15 coeff 32604) → sat16(y >> 4)` ([mic_i2s.h:5-6](tutor_lamp/mic_i2s.h#L5)).
2. **Detect the wake word** continuously, with a 1‑second EI sliding window plus a debounce, on the *pre*‑post‑process signal ([wake_word.cpp:53-98](tutor_lamp/wake_word.cpp#L53)).
3. **Clean** the audio for the speech‑to‑text uplink with a four‑stage DSP chain `NS → ALE → AGC → VAD` ([audio_post_process.cpp:12-26](tutor_lamp/audio_post_process.cpp#L12)).
4. **Decide when the user has stopped talking** (End‑of‑Speech / EOS) using the VAD plus a near‑field anchor and a leaky silence integrator ([tutor_lamp.ino:406-436](tutor_lamp/tutor_lamp.ino#L406)).
5. **Compress** the uplink with IMA/DVI ADPCM 4:1 so a 32 KB/s raw mic stream fits a 10–20 KB/s capped WAN ([adpcm_dec.h:33-44](tutor_lamp/adpcm_dec.h#L33)).
6. **Play back** the backend's TTS over the MAX98357A I2S amplifier, decoding ADPCM if the backend chose that wire codec, with a jitter buffer sized to ride out remote stalls ([spk_i2s.cpp](tutor_lamp/spk_i2s.cpp)).

A hard physical constraint dominates the design: **pins BCK=40 and WS=39 are shared between the mic and the speaker, and there is only one I2S controller (`I2S_NUM_0`) wired to them.** The system is therefore strictly **half‑duplex**: while the lamp speaks, the mic is off and wake detection is paused ([spk_i2s.h:22-36](tutor_lamp/spk_i2s.h#L22)).

---

## 2. Architecture Overview

### 2.1 Modules / files

| File | Role |
|------|------|
| [mic_i2s.cpp](tutor_lamp/mic_i2s.cpp) / [.h](tutor_lamp/mic_i2s.h) | I2S RX driver, DMA capture FreeRTOS task, training‑identical `apply_dsp()`, frame‑callback dispatch, half‑duplex teardown via semaphore. |
| [wake_word.cpp](tutor_lamp/wake_word.cpp) / [.h](tutor_lamp/wake_word.h) | EI continuous classifier: double‑buffer fill (`feed_frame`), per‑slice inference (`tick`), debounced trigger. |
| [audio_post_process.cpp](tutor_lamp/audio_post_process.cpp) / [.h](tutor_lamp/audio_post_process.h) | Thin orchestrator chaining the four DSP stages in order, passing inter‑stage values. |
| [ns_stage.cpp](tutor_lamp/ns_stage.cpp) / [.h](tutor_lamp/ns_stage.h) | Single‑band time‑domain Wiener noise suppressor (two‑speed noise floor, attack/release). |
| [ale_stage.cpp](tutor_lamp/ale_stage.cpp) / [.h](tutor_lamp/ale_stage.h) | NLMS Adaptive Line Enhancer (cancels tonal/correlated interference). |
| [agc_stage.cpp](tutor_lamp/agc_stage.cpp) / [.h](tutor_lamp/agc_stage.h) | Automatic Gain Control, normalises RMS to a target, holds gain in silence. |
| [vad_stage.cpp](tutor_lamp/vad_stage.cpp) / [.h](tutor_lamp/vad_stage.h) | 3‑feature majority‑vote Voice Activity Detector with hangover and an internal noise‑floor tracker. |
| [adpcm_dec.cpp](tutor_lamp/adpcm_dec.cpp) / [.h](tutor_lamp/adpcm_dec.h) | IMA/DVI ADPCM 4‑bit encoder (uplink mic) + decoder (downlink TTS), bit‑exact with CPython `audioop`. |
| [spk_i2s.cpp](tutor_lamp/spk_i2s.cpp) / [.h](tutor_lamp/spk_i2s.h) | TTS playback: PSRAM ring buffer, playback task, I2S TX acquire/release, mono→stereo, software volume. |

### 2.2 Threading / core map

| Task | Core | Priority | Owner of | Notes |
|------|------|----------|----------|-------|
| `mic_capture` | 1 | 8 | `I2S_NUM_0` RX while listening | Created in [mic_i2s.cpp:207-208](tutor_lamp/mic_i2s.cpp#L207); stack `1024*16`. Pre‑empts `loop()` when DMA is ready. |
| `loop()` (Arduino main) | 1 | — | WS RX dispatch, mode machine | Runs `wake::tick()` in MODE_IDLE; runs EOS/send logic. |
| `spk_play` | 0 | 2 | `I2S_NUM_0` TX while speaking | Created in [spk_i2s.cpp:388-389](tutor_lamp/spk_i2s.cpp#L388); stack `4096`. Below WiFi (prio 23). |
| WiFi/TLS stack | 0 | 23 | network | Decrypts the `wss://` stream; can pre‑empt `spk_play`. |

### 2.3 Key data structures

- **`mic::Pins`** ([mic_i2s.h:30-35](tutor_lamp/mic_i2s.h#L30)): `bck = 40`, `ws = 39`, `din = 1`. L/R wired to GND → left channel only.
- **Capture buffers** ([mic_i2s.cpp:37-38](tutor_lamp/mic_i2s.cpp#L37)): `s_raw[512]` (int32, the I2S DMA target) and `s_samples[512]` (int16, the DSP output). `512 = FRAME_BYTES/sizeof(int32)` where `FRAME_BYTES = 2048`.
- **DC‑blocker state** ([mic_i2s.cpp:39](tutor_lamp/mic_i2s.cpp#L39)): `s_dc_x`, `s_dc_y` — previous input/output of the IIR.
- **`Inference`** ([wake_word.cpp:17-23](tutor_lamp/wake_word.cpp#L17)): two int16 ping‑pong buffers, `buf_select`, `volatile buf_ready`, `buf_count`, `n_samples = EI_CLASSIFIER_SLICE_SIZE`.
- **ADPCM state** ([adpcm_dec.cpp:28-32](tutor_lamp/adpcm_dec.cpp#L28)): decoder `s_valpred`/`s_index`, *separate* encoder `s_enc_valpred`/`s_enc_index` (full duplex).
- **Speaker ring** ([spk_i2s.cpp:63-77](tutor_lamp/spk_i2s.cpp#L63)): `s_ring` (1 MB PSRAM byte‑buf), `s_ring_capacity`, `s_stereo_buf`, `volatile s_volume`, `s_owning_i2s`, `s_end_marked`.

---

## 3. End-to-End Control Flow

The capture task calls user hooks in a **strict, never‑reordered** order every DMA frame ([mic_i2s.h:8-15](tutor_lamp/mic_i2s.h#L8), enforced in [mic_i2s.cpp:96-107](tutor_lamp/mic_i2s.cpp#L96)):

1. **`apply_dsp(n)`** — the training‑identical signal lands in `s_samples[]`.
2. **`on_raw_frame_cb(samples, n)`** — the EI wake word reads this *pre*‑post‑process stream (`on_raw_frame` → `wake::feed_frame`, [tutor_lamp.ino:354-357](tutor_lamp/tutor_lamp.ino#L354)).
3. **`audio_post_process(samples, n)`** — `NS → ALE → AGC → VAD`, **in place**.
4. **`on_cleaned_frame_cb(samples, n)`** — the command recorder reads cleaned audio (`on_cleaned_frame`, [tutor_lamp.ino:367-436](tutor_lamp/tutor_lamp.ino#L367)).

> **Why steps 2 and 3 must never swap:** the EI model was trained on the raw (post‑`apply_dsp`, *pre*‑NS/ALE/AGC) signal. Feeding it post‑processed audio would present a signal distribution it has never seen. This invariant is repeated in three places ([mic_i2s.h:15](tutor_lamp/mic_i2s.h#L15), [mic_i2s.cpp:99-100](tutor_lamp/mic_i2s.cpp#L99), [audio_post_process.h:13-17](tutor_lamp/audio_post_process.h#L13)).

The system runs a three‑state machine ([tutor_lamp.ino:228-229](tutor_lamp/tutor_lamp.ino#L228)): `MODE_IDLE` (listen for wake word) → `MODE_COMMAND` (stream cleaned audio, watch for EOS) → `MODE_SENDING` (flush, send AUDIO_END) → back to `MODE_IDLE`.

---

## 4. I2S Microphone Capture (`mic_i2s`)

### 4.1 Public API ([mic_i2s.h:37-43](tutor_lamp/mic_i2s.h#L37))

```cpp
bool  begin(uint32_t sample_rate, const Pins& pins = Pins());
void  set_on_raw_frame(frame_cb_t cb);
void  set_on_cleaned_frame(frame_cb_t cb);
bool  start_task();
void  stop();
float last_rms();   // RMS of most recent frame, post-DSP, pre-post-process
```

### 4.2 I2S configuration ([mic_i2s.cpp:153-178](tutor_lamp/mic_i2s.cpp#L153))

| Field | Value | Meaning / why |
|-------|-------|---------------|
| `mode` | `I2S_MODE_MASTER \| I2S_MODE_RX` | ESP32 generates BCK/WS; receives from mic. |
| `sample_rate` | argument (`wake::sample_rate()` = `EI_CLASSIFIER_FREQUENCY`, 16 kHz) | MUST match EI model or audio is frequency‑shifted ([wake_word.h:23-25](tutor_lamp/wake_word.h#L23)). |
| `bits_per_sample` | `I2S_BITS_PER_SAMPLE_32BIT` | INMP441 emits 24‑bit data in a 32‑bit slot; the upper bits carry the sample. |
| `channel_format` | `I2S_CHANNEL_FMT_ONLY_LEFT` | L/R pin tied to GND → left channel only. |
| `communication_format` | `I2S_COMM_FORMAT_STAND_I2S` | Standard Philips I2S framing. |
| `intr_alloc_flags` | `ESP_INTR_FLAG_LEVEL1` | Low‑priority shared interrupt. |
| `dma_buf_count` | `8` | Eight DMA descriptors. |
| `dma_buf_len` | `256` | "matches data‑collector → identical DMA timing." 8×256 samples buffered. |
| `use_apll` | `false` | Use the integer fractional divider, not the audio PLL. |
| `tx_desc_auto_clear` | `false` | RX mode, irrelevant. |
| `fixed_mclk` | `0` | No fixed master clock. |

Constants ([mic_i2s.cpp:27-30](tutor_lamp/mic_i2s.cpp#L27)): `I2S_PORT = I2S_NUM_0`, `FRAME_BYTES = 2048` (= 512 × int32), `MIC_SHIFT = 4`, `DC_COEF_Q15 = 32604` (≈ 0.9999 in Q15).

### 4.3 `begin()` lifecycle ([mic_i2s.cpp:133-189](tutor_lamp/mic_i2s.cpp#L133))

1. Logs heap/PSRAM free.
2. Resets DC‑blocker state `s_dc_x = s_dc_y = 0`.
3. **Creates the capture‑done binary semaphore once** (`xSemaphoreCreateBinary`, starts EMPTY) and reuses it for every mic↔speaker switch for the session. Failure is FATAL ([mic_i2s.cpp:144-151](tutor_lamp/mic_i2s.cpp#L144)).
4. `i2s_driver_install` then `i2s_set_pin`; both errors abort `begin()`.
5. `i2s_zero_dma_buffer` clears stale DMA.
6. **Drains ~150 ms of mic startup transient** with 10 reads of `FRAME_BYTES` at 100 ms timeout each — "same as data‑collector, so both see the same INMP441 settle behaviour" ([mic_i2s.cpp:182-186](tutor_lamp/mic_i2s.cpp#L182)).

### 4.4 `start_task()` ([mic_i2s.cpp:194-216](tutor_lamp/mic_i2s.cpp#L194))

- No‑op if already running.
- **Drains any stale semaphore "give"** with `xSemaphoreTake(..., 0)` — a delayed give from the previous `stop()` could otherwise be pending ([mic_i2s.cpp:200-203](tutor_lamp/mic_i2s.cpp#L200)).
- Sets `s_running = true`, then `xTaskCreatePinnedToCore(capture_task, "mic_capture", 1024*16, nullptr, 8, nullptr, 1)` — **core 1, priority 8.**

### 4.5 `capture_task()` main loop ([mic_i2s.cpp:83-127](tutor_lamp/mic_i2s.cpp#L83))

```cpp
while (s_running) {
    esp_err_t r = i2s_read(I2S_PORT, s_raw, FRAME_BYTES, &bytes_read,
                           pdMS_TO_TICKS(100));   // 100 ms timeout, NOT portMAX_DELAY
    if (r != ESP_OK || bytes_read == 0) continue;
    int n = bytes_read / sizeof(int32_t);
    apply_dsp(n);                         // 1
    if (s_on_raw)     s_on_raw(s_samples, n);     // 2  (wake word)
    audio_post_process(s_samples, n);     // 3  (NS→ALE→AGC→VAD)
    if (s_on_cleaned) s_on_cleaned(s_samples, n); // 4  (command recorder)
}
```

The **100 ms `i2s_read` timeout** (instead of `portMAX_DELAY`) means the loop wakes regularly to re‑check `s_running` even if DMA stalls — a safety net for the stop path. In steady state `i2s_read` returns roughly every 16 ms (256 samples ÷ 16 kHz), so the timeout never fires ([mic_i2s.cpp:87-90](tutor_lamp/mic_i2s.cpp#L87)). One frame = 512 samples ≈ **32 ms** of audio, but `dma_buf_len=256` means data is delivered in 256‑sample (~16 ms) DMA chunks and `i2s_read` fills the 2048‑byte buffer across two of them.

On loop exit the task **uninstalls the driver itself** (`i2s_driver_uninstall`) and then `xSemaphoreGive`s — see [§15](#15-the-half-duplex-handoff--cross-core-races).

### 4.6 `stop()` ([mic_i2s.cpp:218-256](tutor_lamp/mic_i2s.cpp#L218))

Sets `s_running = false`, then **blocks on `xSemaphoreTake(s_capture_done_sem, pdMS_TO_TICKS(1000))`** until the capture task acknowledges it has exited its `i2s_read` loop *and* uninstalled the driver. The 1 s budget is generous: the task wakes within ≤100 ms of `s_running` going false, uninstalls in tens of ms, then gives. If the take times out, it logs FATAL and force‑uninstalls as a last‑ditch recovery ([mic_i2s.cpp:241-251](tutor_lamp/mic_i2s.cpp#L241)).

---

## 5. Training-Identical DSP — `apply_dsp()`

`apply_dsp()` ([mic_i2s.cpp:69-81](tutor_lamp/mic_i2s.cpp#L69)) is the **most ordering‑sensitive code in the firmware** — every operation must be bit‑identical to `ei_data_collector.ino`, or the EI model degrades. Marked `IRAM_ATTR` so it runs from instruction RAM (no flash‑cache stalls during I2S interrupts).

Per sample `i` in `0..n-1`:

```cpp
int32_t s = s_raw[i] >> 8;                                          // (A) align 24-bit
int32_t y = s - s_dc_x + ((int64_t)s_dc_y * DC_COEF_Q15 >> 15);    // (B) DC-blocker IIR
s_dc_x = s;  s_dc_y = y;                                            // (C) update state
int16_t out = sat16(y >> MIC_SHIFT);                               // (D) scale + saturate
s_samples[i] = out;
sq += (float)out * (float)out;                                     // (E) accumulate energy
```

**(A) `>> 8`** drops the low 8 bits — the INMP441 packs its 24‑bit sample in the top 24 of the 32‑bit slot, so `>> 8` aligns it to a 24‑bit integer. **Must not change** ([mic_i2s.cpp:67-68](tutor_lamp/mic_i2s.cpp#L67)).

**(B) The DC‑blocker** is a first‑order high‑pass IIR: `y[n] = x[n] − x[n−1] + a·y[n−1]` with `a = 32604/32768 ≈ 0.99500`. Subtracting `x[n−1]` puts a zero at DC; the `a·y[n−1]` recursive term puts a pole just inside the unit circle, giving a very low cutoff (a few Hz). This removes the INMP441's substantial DC offset without touching speech. The recursion uses **64‑bit intermediate math** (`(int64_t)s_dc_y * DC_COEF_Q15 >> 15`) to avoid overflow before the Q15 right‑shift.

**(D) `sat16(y >> MIC_SHIFT)`** divides by 16 (`MIC_SHIFT = 4`) to bring the 24‑bit‑scale value into int16 range, then `sat16()` ([mic_i2s.cpp:61-65](tutor_lamp/mic_i2s.cpp#L61)) hard‑clamps to `[−32768, 32767]`.

**(E)** `s_last_rms = sqrtf(sq / n)` — RMS of this frame, post‑DSP but *pre*‑post‑process, exposed via `mic::last_rms()` ([mic_i2s.cpp:80](tutor_lamp/mic_i2s.cpp#L80)).

The three constants `>> 8`, `32604`, and `MIC_SHIFT = 4` are explicitly flagged as immutable ([mic_i2s.cpp:67-68](tutor_lamp/mic_i2s.cpp#L67)).

---

## 6. Wake-Word Detection (`wake_word`)

The wake word is an **Edge Impulse continuous keyword classifier**, library header `WakeWordTutor_inferencing.h` ([wake_word.cpp:4](tutor_lamp/wake_word.cpp#L4)). It runs the EI "continuous" inference mode, which keeps a 1‑second sliding window and a moving‑average filter (MAF) across slices.

### 6.1 Trigger configuration ([wake_word.cpp:11-13](tutor_lamp/wake_word.cpp#L11))

| Constant | Value | Meaning |
|----------|-------|---------|
| `WAKE_LABEL_INDEX` | `0` | Index of the wake‑word class in the EI category list. |
| `WAKE_THRESHOLD` | `0.70f` | Confidence above which a slice counts as a "hit." |
| `WAKE_DEBOUNCE` | `2` | Consecutive hit slices required to fire — the noise discriminator. |

### 6.2 Double‑buffer fill — `feed_frame()` ([wake_word.cpp:53-66](tutor_lamp/wake_word.cpp#L53))

Called from the capture task (step 2) and marked `IRAM_ATTR`. It copies samples into `s_inf.buffers[buf_select]` until `buf_count` reaches `n_samples = EI_CLASSIFIER_SLICE_SIZE`, then **ping‑pongs** (`buf_select ^= 1`), resets `buf_count`, and sets `buf_ready = 1`. Critically, the stream is fed **unconditionally** — even when the lamp is in MODE_COMMAND or speaking — because the continuous classifier requires an uninterrupted stream; slices computed in non‑IDLE modes are simply discarded by the `loop()`‑side guard, but the buffer keeps marching so there is no discontinuity on return to IDLE ([wake_word.cpp:54-57](tutor_lamp/wake_word.cpp#L54)).

`get_signal_data()` ([wake_word.cpp:29-33](tutor_lamp/wake_word.cpp#L29)) is the EI `signal_t.get_data` callback: it reads the **inactive** buffer (`buf_select ^ 1` — the one just completed) and converts int16→float via `numpy::int16_to_float`.

### 6.3 Inference + debounce — `tick()` ([wake_word.cpp:68-98](tutor_lamp/wake_word.cpp#L68))

Called from `loop()` in MODE_IDLE only ([tutor_lamp.ino:1812](tutor_lamp/tutor_lamp.ino#L1812)):

1. Returns `false` immediately if `buf_ready == 0` (non‑blocking).
2. Clears `buf_ready`, builds a `signal_t` of length `EI_CLASSIFIER_SLICE_SIZE`, runs `run_classifier_continuous(&signal, &result, false)`.
3. Reads `conf = result.classification[WAKE_LABEL_INDEX].value`, stores it in `s_last_conf`.
4. **Debounce:** if `conf > 0.70`, increment `s_hit_streak`; when it reaches `WAKE_DEBOUNCE = 2`, reset the streak and `return true` (fire). Any sub‑threshold slice resets the streak to 0 ([wake_word.cpp:89-97](tutor_lamp/wake_word.cpp#L89)).

> **VAD is deliberately NOT gated into the trigger.** The EI classifier's 1‑second sliding window means that by the time confidence crosses the threshold the utterance is already 300–500 ms in the past and the VAD has returned to 0; gating on VAD would make the trigger always miss. `WAKE_DEBOUNCE` is the noise discriminator instead. VAD is used only for EOS later ([wake_word.cpp:84-88](tutor_lamp/wake_word.cpp#L84)).

### 6.4 `begin()` / `reset_debounce()` / `restart_continuous()`

- **`begin()`** ([wake_word.cpp:41-51](tutor_lamp/wake_word.cpp#L41)): `malloc`s both `n_samples`‑sized int16 buffers (returns `false` on OOM), then `run_classifier_init()`.
- **`reset_debounce()`** ([wake_word.cpp:100-104](tutor_lamp/wake_word.cpp#L100)): clears `s_hit_streak`, `buf_ready`, `buf_count`. Called on returning to MODE_IDLE after a command.
- **`restart_continuous()`** ([wake_word.cpp:106-119](tutor_lamp/wake_word.cpp#L106)): re‑runs `run_classifier_init()` to flush the continuous classifier's sliding window + MAF of the stale audio captured *before* the ~20 s mic gap during TTS playback. Without it, the first post‑playback wake needs loud/repeated speech until the window flushes. Also resets the feed double‑buffer (`buf_select = 0`). Called from the speaker‑release path **while the capture task is stopped** so it can't race `run_classifier_continuous()` ([spk_i2s.cpp:171-178](tutor_lamp/spk_i2s.cpp#L171)).

A compile‑time guard enforces the model is a microphone model ([wake_word.cpp:125-127](tutor_lamp/wake_word.cpp#L125)).

---

## 7. The Post-Process Chain Orchestrator (`audio_post_process`)

`audio_post_process()` ([audio_post_process.cpp:12-26](tutor_lamp/audio_post_process.cpp#L12)) is stateless; all state lives in the four stage files. It runs the stages **in this fixed order**, threading inter‑stage values:

```cpp
ns_process (pcm, n);                                  // A: Wiener NS
ale_process(pcm, n, vad_is_speech());                 // B: NLMS ALE — freeze on vad_is_speech()
agc_process(pcm, n, ns_is_speech());                  // C: AGC — hold during silence
vad_process(pcm, n, ns_noise_floor(), agc_current_gain()); // D: 3-feature VAD
```

Two design subtleties are documented inline:

- **ALE freezes on `vad_is_speech()`, not `ns_is_speech()`** ([audio_post_process.cpp:15-18](tutor_lamp/audio_post_process.cpp#L15)). The VAD's 8‑frame hangover covers unvoiced consonant tails (s/f/t); `ns_is_speech()` has no hangover and drops false mid‑phoneme, which would let the ALE adapt *during* speech and subtract it.
- **VAD receives `agc_current_gain()`** so it can tighten its absolute energy gate in quiet rooms where a high‑gain AGC amplifies distant noise over a fixed post‑gain gate ([audio_post_process.cpp:20-25](tutor_lamp/audio_post_process.cpp#L20)).

`audio_post_process_reset()` ([audio_post_process.cpp:28-34](tutor_lamp/audio_post_process.cpp#L28)) calls `ns_reset(); ale_reset(); agc_reset(); vad_reset();` — used before a fresh recognition session and on the speaker‑release path.

> **Note the ordering paradox:** Stage B (ALE) reads `vad_is_speech()` and Stage C (AGC) reads `ns_is_speech()`, both produced by stages that run *later in this same frame* (VAD is Stage D). This means each stage uses the **previous frame's** speech decisions — a one‑frame (~32 ms) lag that is acceptable because speech state changes slowly relative to frame size.

---

## 8. Stage A — Noise Suppression (`ns_stage`)

### 8.1 Algorithm

Single‑band, time‑domain **Wiener** noise suppression — no FFT. The classic per‑bin Wiener gain `G(f) = 1 − N(f)/S(f)` is collapsed to one band: `G = clamp(1 − E_noise/E_sig, FLOOR, 1.0)` ([ns_stage.cpp:5-7](tutor_lamp/ns_stage.cpp#L5)). The noise floor is a **two‑speed leaky integrator** (Martin 2001 / WebRTC NS style): fast in silence to track new backgrounds, slow in speech so it doesn't absorb speech energy.

### 8.2 Constants ([ns_stage.h:28-37](tutor_lamp/ns_stage.h#L28))

| Constant | Value | Effect |
|----------|-------|--------|
| `NS_SPEECH_THRESH` | `1.5f` | `E_sig/E_noise` ratio above which the frame is "speech." |
| `NS_ALPHA_NOISE_SLOW` | `0.995f` | Noise‑floor leak during speech (very slow — barely tracks). |
| `NS_ALPHA_NOISE_FAST` | `0.85f` | Noise‑floor leak during silence (fast lock‑on). |
| `NS_ALPHA_GAIN_ATTACK` | `0.9f` | Gain smoother when gain **rises**. |
| `NS_ALPHA_GAIN_RELEASE` | `0.92f` | Gain smoother when gain **falls** (≈190 ms). Was 0.5 → clicked per frame. |
| `NS_GAIN_FLOOR` | `0.2f` | Min suppression gain → caps suppression at 80%. Was 0.1 → 90% → musical‑noise warble. |
| `NS_MIN_FLOOR` | `100.0f` | Minimum noise‑floor value (mean‑square units). |
| `NS_WARMUP_FRAMES` | `8` | Frames (8 × 16 ms) before suppression activates. |

### 8.3 `ns_process()` step by step ([ns_stage.cpp:29-75](tutor_lamp/ns_stage.cpp#L29))

1. **Mean‑square energy**: `esig = (Σ pcm[i]²)/n`, stored in `s_esig`.
2. **Warm‑up** (first `NS_WARMUP_FRAMES` frames): seed `s_noise = esig + NS_MIN_FLOOR` on frame 0, otherwise leak with `NS_ALPHA_NOISE_FAST`; clamp to `NS_MIN_FLOOR`; `return` (no suppression yet) ([ns_stage.cpp:41-49](tutor_lamp/ns_stage.cpp#L41)).
3. **Speech classification**: `s_speech = (esig / (s_noise+1e-6) > NS_SPEECH_THRESH)`.
4. **Two‑speed floor update**: `alpha = s_speech ? 0.995 : 0.85`; `s_noise = alpha·s_noise + (1−alpha)·esig`; clamp to `NS_MIN_FLOOR`.
5. **Wiener gain**: `g_raw = 1 − s_noise/(esig+1e-6)`, clamped to `[NS_GAIN_FLOOR, 1.0]`.
6. **Attack/release smoothing**: `a = (g_raw > s_gain) ? 0.9 : 0.92`; `s_gain = a·s_gain + (1−a)·g_raw`.
7. **Apply** `s_gain` to every sample with int16 saturation.

### 8.4 Accessors

`ns_is_speech()`, `ns_noise_floor()` (consumed by VAD's `vad_process` arg and the EOS diagnostics), and `ns_snr_db()` = `10·log10(E_sig/E_noise)` with a `1e-9` floor ([ns_stage.cpp:85-91](tutor_lamp/ns_stage.cpp#L85)).

---

## 9. Stage B — Adaptive Line Enhancer (`ale_stage`)

### 9.1 Algorithm

An **NLMS Adaptive Line Enhancer** removes tonal/correlated interference (mains hum, mic housing resonance, fan whine) **without any loudspeaker reference** — it is *not* an AEC ([ale_stage.h:6-8](tutor_lamp/ale_stage.h#L6)). The principle: speech autocorrelation drops to near zero within ≈1 ms (16 samples @ 16 kHz), but tonal interference stays correlated far beyond that delay. Per sample ([ale_stage.cpp:10-23](tutor_lamp/ale_stage.cpp#L10)):

1. Delay the input by `DELTA` samples → decorrelates speech, not interference.
2. An FIR predictor fits the delayed copy to predict `x[n]` → learns the *correlated* (tonal) component.
3. `e[n] = x[n] − ŷ[n]` → residual = unpredictable = **speech**, which is the output.
4. NLMS weight update: `w[k] += (μ / (ε + ||u(n)||²)) · e[n] · x[n−DELTA−k]`.

The squared tap‑input norm `||u(n)||²` is tracked **exactly** at O(1) via a sliding window: `tap_pow[n] = tap_pow[n−1] + x[n−DELTA]² − x[n−DELTA−L]²` ([ale_stage.cpp:16-23](tutor_lamp/ale_stage.cpp#L16)). The header explains *why* exact tracking matters: using `x[n]²` instead lags by `DELTA` samples on plosive onsets, over‑estimating the denominator and shrinking the step exactly when the filter most needs to adapt.

### 9.2 Constants ([ale_stage.h:34-43](tutor_lamp/ale_stage.h#L34))

| Constant | Value | Effect |
|----------|-------|--------|
| `ALE_DELTA` | `16` | Decorrelation delay (≈1 ms @ 16 kHz). Must exceed speech autocorr length. |
| `ALE_FILTER_LEN` | `32` | FIR predictor taps. More taps = lower‑freq cancellation, slower convergence. |
| `ALE_BUF_LEN` | `64` | Ring buffer size — **must be a power of 2** (enforced by `static_assert`). |
| `ALE_MU` | `0.02f` | NLMS step size μ. 0.1 overfits transients; 1e‑6 (original) never converged. |
| `ALE_EPSILON` | `1e-6f` | Regularisation (prevents div/0). |
| `ALE_WEIGHT_CLIP` | `1.0f` | Hard ±bound on each FIR weight. |
| `ALE_SILENCE_THRESH` | `100.0f` | Frame RMS below this → freeze adaptation (documented; see §9.4). |

Two `static_assert`s enforce `ALE_BUF_LEN` is a power of 2 and `≥ ALE_DELTA + ALE_FILTER_LEN` (64 ≥ 16+32=48) ([ale_stage.cpp:36-39](tutor_lamp/ale_stage.cpp#L36)).

### 9.3 State ([ale_stage.cpp:41-46](tutor_lamp/ale_stage.cpp#L41))

`s_buf[64]` (ring), `s_idx` (write cursor), `s_w[32]` (weights), `s_tap_pow` (exact `||u(n)||²`), `s_in_rms`, `s_err_rms`.

### 9.4 `ale_process()` step by step ([ale_stage.cpp:48-106](tutor_lamp/ale_stage.cpp#L48))

1. Compute `frame_rms` over the frame; set `freeze = is_speech` (the arg, which is `vad_is_speech()`). **The filter adapts during silence and holds its weights during speech** ([ale_stage.cpp:55-58](tutor_lamp/ale_stage.cpp#L55)). The header's older "double gate" (`!is_speech && RMS<thresh`) was *wrong* — it adapted during speech and chased speech energy; the corrected gate is purely `freeze = is_speech`.
2. For each sample:
   - Write `x_n` into `s_buf[s_idx]`.
   - **Sliding tap power**: add `v_in²` (the sample entering the window at `s_idx − DELTA`), subtract `v_out²` (the one leaving at `s_idx − DELTA − L`); clamp `s_tap_pow ≥ 0`. Ring indices use the branchless bitmask `& (ALE_BUF_LEN − 1)`.
   - **Predict**: `y = Σ_{k=0}^{31} w[k]·buf[idx − DELTA − k]`.
   - **Error**: `e = x_n − y`.
   - **Update (only if not frozen)**: `mu_e = (ALE_MU / (ALE_EPSILON + s_tap_pow))·e`; for each tap `w[k] += mu_e·buf[j]`, clamped to `±ALE_WEIGHT_CLIP`.
   - **Output**: clamp `e` to int16 and write back to `pcm[i]`; accumulate `err_sq`.
   - Advance `s_idx = (s_idx+1) & (ALE_BUF_LEN−1)`.
3. `s_err_rms = sqrt(err_sq/n)`.

`ale_prediction_gain_db()` = `10·log10((in_rms+1e-6)/(err_rms+1e-6))` — positive = interference suppressed ([ale_stage.cpp:117-119](tutor_lamp/ale_stage.cpp#L117)).

---

## 10. Stage C — Automatic Gain Control (`agc_stage`)

### 10.1 Algorithm

Normalises output RMS to `AGC_TARGET` so the EI/STT pipeline sees audio near training level regardless of mic distance ([agc_stage.cpp:4-17](tutor_lamp/agc_stage.cpp#L4)). The key trick is **hold during silence**: if the envelope updated on noise‑only frames, AGC would amplify the floor to target and flood the next utterance start with amplified noise ("pumping"). So the envelope/gain only update when `is_speech` is true; in silence the last computed gain is *held but still applied* for level consistency.

### 10.2 Constants ([agc_stage.h:30-36](tutor_lamp/agc_stage.h#L30))

| Constant | Value | Effect |
|----------|-------|--------|
| `AGC_TARGET` | `3000.0f` | Desired output RMS (≈ −21 dBFS). Set to EI training RMS. |
| `AGC_ALPHA` | `0.98f` | Envelope smoother (≈800 ms). 0.94 (old) ≈255 ms → gain swells at word starts. |
| `AGC_GAIN_MIN` | `0.5f` | Minimum gain clamp. |
| `AGC_GAIN_MAX` | `8.0f` | Maximum gain clamp (≈18 dB). 20.0 (old) ≈26 dB → amplified the floor. |
| `AGC_EPS` | `1.0f` | Divide‑by‑zero guard for the envelope. |

### 10.3 `agc_process()` step by step ([agc_stage.cpp:26-50](tutor_lamp/agc_stage.cpp#L26))

State ([agc_stage.cpp:23-24](tutor_lamp/agc_stage.cpp#L23)): `s_envelope = AGC_TARGET` (init to target → no initial jolt), `s_gain = 1.0`.

1. **If `is_speech`** (= `ns_is_speech()` from the orchestrator):
   - `rms = sqrt(Σpcm²/n + 1e-6)`.
   - `s_envelope = AGC_ALPHA·s_envelope + (1−AGC_ALPHA)·rms`.
   - `g = AGC_TARGET/(s_envelope + AGC_EPS)`, clamped to `[0.5, 8.0]`; store as `s_gain`.
2. **Always** apply `s_gain` to every sample with int16 saturation.

`agc_current_gain()` returns `s_gain` and is fed into the VAD to scale its absolute energy gate ([agc_stage.cpp:57](tutor_lamp/agc_stage.cpp#L57)).

---

## 11. Stage D — Voice Activity Detection (`vad_stage`)

### 11.1 Algorithm — 3‑feature majority vote + hangover

A single RMS threshold is fragile (a thump passes, a quiet fricative fails). The VAD runs **three orthogonal features**; a **2‑of‑3 majority** declares raw speech, and a **hangover** counter keeps the output HIGH for `VAD_HANGOVER_FRAMES` after the features drop ([vad_stage.cpp:1-34](tutor_lamp/vad_stage.cpp#L1)).

- **Feature 1 — Energy** ([vad_stage.cpp:52-84](tutor_lamp/vad_stage.cpp#L52)): a **dual gate**. The frame must clear BOTH a *relative* test (`esig/s_nf > VAD_ENERGY_THRESH`) AND an *absolute* test (`esig > abs_gate`). The relative floor `s_nf` is a self‑tracked robust noise floor (below). The absolute gate exists because the relative floor can "latch" onto a transient‑quiet frame, after which ordinary room background sails past the 1.5× ratio and falsely votes speech — which would reload the hangover and stall EOS forever, recording the full 30 s ([vad_stage.h:40-49](tutor_lamp/vad_stage.h#L40)).
- **Feature 2 — Zero‑Crossing Rate** ([vad_stage.cpp:86-91](tutor_lamp/vad_stage.cpp#L86)): count sign changes; vote if `VAD_ZCR_LOW ≤ ZCR ≤ VAD_ZCR_HIGH`. Below the floor = DC/thump/tone; above the ceiling = white noise/hiss.
- **Feature 3 — Spectral Flatness proxy** ([vad_stage.cpp:93-104](tutor_lamp/vad_stage.cpp#L93)): no FFT. `mean_log = exp((1/N)Σ log(|x|+1))` (geometric‑mean proxy), `mean_lin = (1/N)Σ|x|` (arithmetic mean), `sfm = mean_log/(mean_lin+ε)`. Speech is tonal → `sfm << 1`; white noise → `sfm → 1`. Vote if `sfm < VAD_SFM_THRESH`.

### 11.2 Constants ([vad_stage.h:37-86](tutor_lamp/vad_stage.h#L37))

| Constant | Value | Effect |
|----------|-------|--------|
| `VAD_ENERGY_THRESH` | `1.5f` | `E_sig/noise_floor` ratio to vote speech. |
| `VAD_ENERGY_ABS_MIN` | `4.0e6f` | Absolute min frame energy (rms²) for the energy vote. Background tops ≈ 2.0M, speech peaks 6.3M+ → gate at 4.0M (rms≈2000) separates them. |
| `VAD_GAIN_REF` | `3.0f` | No gate change at or below this AGC gain. |
| `VAD_ABS_GATE_SCALE_MAX` | `1.44f` | Max gate scale (rms 2000 → 2400). |
| `VAD_ZCR_LOW` | `10` | Min ZCR per frame for the speech vote. |
| `VAD_ZCR_HIGH` | `80` | Max ZCR per frame for the speech vote. |
| `VAD_SFM_THRESH` | `0.6f` | SFM proxy below this votes speech. |
| `VAD_HANGOVER_FRAMES` | `8` | Frames to hold HIGH after features drop (8 × 16 ms ≈ 128 ms). |
| `VAD_NF_DOWN` | `0.30f` | Step toward a LOWER frame energy (fast — lock to background). |
| `VAD_NF_UP` | `0.006f` | Step toward a HIGHER frame energy (absorb steady noise in ~2–3 s). |
| `VAD_NF_MIN` | `100.0f` | Floor in mean‑square units (matches `NS_MIN_FLOOR`). |

### 11.3 Gain‑aware absolute gate ([vad_stage.cpp:76-82](tutor_lamp/vad_stage.cpp#L76))

Because the VAD runs **post‑AGC**, the absolute gate is in post‑gain units. In a quiet room the AGC rides high (up to gain 8) and amplifies faint distant noise over a fixed gate. When `agc_gain > VAD_GAIN_REF (3.0)`, the gate is scaled by `(gain/3.0)²`, **capped at `VAD_ABS_GATE_SCALE_MAX = 1.44`**. The cap guarantees the gate never climbs into the user's own AGC‑normalised speech level (~3000 rms ⇒ 9e6; cap 1.44 ⇒ gate tops out at rms≈2400). At or below `VAD_GAIN_REF` the gate is bit‑identical to the old behaviour — it only ever **tightens, never loosens** ([vad_stage.h:51-62](tutor_lamp/vad_stage.h#L51)).

### 11.4 VAD‑internal noise‑floor tracker ([vad_stage.cpp:61-66](tutor_lamp/vad_stage.cpp#L61))

The passed‑in `noise_floor` (the NS floor) is intentionally **`(void)`‑ignored for the energy feature** ([vad_stage.cpp:48-50](tutor_lamp/vad_stage.cpp#L48)) because the NS floor can stick at speech level. The VAD tracks its own floor: `s_nf += (esig < s_nf ? VAD_NF_DOWN : VAD_NF_UP)·(esig − s_nf)`, seeded on the first frame, clamped to `VAD_NF_MIN`. It falls **fast** (0.30) toward quiet frames (real background) and rises **slow** (0.006, ~2–3 s) so it can absorb a steady fan/AC without ever rising to peaky speech level. The header gives the tuning curve: 0.001 → ~16 s (too slow, a fan reads as 30 s of speech); 0.006 → ~2–3 s.

### 11.5 Vote, hangover, and output ([vad_stage.cpp:106-121](tutor_lamp/vad_stage.cpp#L106))

`s_votes` is a bitmask: bit0=energy, bit1=zcr, bit2=sfm. `raw = (v_nrg + v_zcr + v_sfm) ≥ 2`. On raw speech, reload `s_hangover = VAD_HANGOVER_FRAMES`; otherwise decrement. `s_speech = (s_hangover > 0)`.

### 11.6 Accessors

`vad_is_speech()` (hangover‑extended), `vad_feature_votes()`, `vad_hangover_remaining()`, `vad_noise_floor()`, and **`vad_frame_energy()`** = `s_esig`, the last frame's mean‑square energy in post‑AGC units, consumed by the speaker‑anchored EOS ([vad_stage.cpp:131-135](tutor_lamp/vad_stage.cpp#L131)).

---

## 12. Command Recording & End-of-Speech (EOS)

While `MODE_COMMAND`, the cleaned‑frame hook `on_cleaned_frame()` ([tutor_lamp.ino:367-436](tutor_lamp/tutor_lamp.ino#L367)) runs on the capture task (core 1, prio 8) and does three things per frame:

1. **Stream to backend.** If `MIC_WIRE_ADPCM = 1` (default, [tutor_lamp.ino:363-365](tutor_lamp/tutor_lamp.ino#L363)), encode with `adpcm::encode` into `s_adpcm_tx[1024]` and send `FRAME_AUDIO_CHUNK_ADPCM (0x06)`; else send raw `FRAME_AUDIO_CHUNK (0x02)`. 512 samples → 256 wire bytes; this quadruples the TX queue's effective depth ([tutor_lamp.ino:371-384](tutor_lamp/tutor_lamp.ino#L371)).
2. **Mirror** into the PSRAM `cmd_buf` (diagnostic copy, capped at `CMD_BUF_SAMPLES`) and drive the listening waveform via `tft_ui::set_listening_level(frame_rms/8000)`.
3. **EOS** with two combined mechanisms.

### 12.1 EOS constants ([tutor_lamp.ino:187-222](tutor_lamp/tutor_lamp.ino#L187))

| Constant | Value | Meaning |
|----------|-------|---------|
| `CMD_DURATION_MS` | `30000` | Hard cap (needs PSRAM). |
| `EOS_SILENCE_MS` | `4000` | Post‑speech silence that ends recording (was 2500 → too aggressive). |
| `CMD_SAMPLE_RATE` | `16000` | Recording rate. |
| `EOS_MIN_SPEECH_SAMPLES` | `16000` (1 s) | Guard before EOS may fire. |
| `EOS_SPEECH_LEAK_FACTOR` | `3` | Speech decays the silence counter 3× faster than it builds. |
| `EOS_NEAR_FRACTION` | `1/16` (−12 dB) | A frame counts as speech for EOS only within this fraction of the turn's near‑field anchor. |

### 12.2 Leaky‑integrator silence + near‑field anchor ([tutor_lamp.ino:406-436](tutor_lamp/tutor_lamp.ino#L406))

- The per‑turn **anchor** `s_cmd_speech_ref` is peak‑held over energy‑voted frames: `if (eos_evote && eos_esig > s_cmd_speech_ref) s_cmd_speech_ref = eos_esig`.
- A frame keeps the turn alive (`near_field`) when the anchor is unseeded (`≤0`), or the frame energy‑voted itself (`eos_evote`), or `eos_esig ≥ s_cmd_speech_ref · EOS_NEAR_FRACTION`.
- If `vad_is_speech() && near_field`: **decay** `silence_samples` by `n·EOS_SPEECH_LEAK_FACTOR` (floored at 0). Else **accumulate** `silence_samples += n`.

This is a *leaky integrator, not a hard reset* ([tutor_lamp.ino:197-206](tutor_lamp/tutor_lamp.ino#L197)): one loud background blip can no longer erase seconds of accumulated silence, but sustained real speech still drives the counter to 0. The near‑field anchor ([tutor_lamp.ino:207-222](tutor_lamp/tutor_lamp.ino#L207)) defeats distant TV/neighbour bleed that wins the ZCR+SFM votes — desk‑distance speech is typically 20–30 dB above neighbourhood bleed, so the −12 dB gate cleanly separates them.

### 12.3 Firing EOS ([tutor_lamp.ino:476-481](tutor_lamp/tutor_lamp.ino#L476))

EOS fires when `(!s_ptt_active && silence_samples ≥ EOS_SILENCE_SAMPLES)` OR the hard cap is hit. In **push‑to‑talk** (hold‑UP) mode, `s_ptt_active = true` **suppresses VAD‑EOS** entirely — the release of the button is the only stop (the 30 s hard cap still applies) ([tutor_lamp.ino:263-273](tutor_lamp/tutor_lamp.ino#L263)). On EOS, `silence_samples = 0` and the mode advances toward sending.

### 12.4 Turn start ([tutor_lamp.ino:1091-1109](tutor_lamp/tutor_lamp.ino#L1091))

`begin_command_turn()` resets `silence_samples = 0`, `s_cmd_speech_ref = 0`, calls **`adpcm::enc_reset()`** for a fresh uplink stream paired with the backend's per‑Turn decoder, snapshots the TX‑drop count, then flips `pipeline_mode = MODE_COMMAND` so the capture task starts recording immediately.

---

## 13. ADPCM Codec (`adpcm_dec`)

### 13.1 Purpose & wire contract

IMA/DVI 4‑bit ADPCM, **bit‑exact** with CPython's `audioop.lin2adpcm`/`adpcm2lin` (`Modules/audioop.c`), verified on the host (`host_tests/test_adpcm_host.cpp`) ([adpcm_dec.h:1-18](tutor_lamp/adpcm_dec.h#L1)). 4:1 compression, **1 byte = 2 samples, high nibble first**.

- **Downlink (decode):** `FRAME_AUDIO_OUT_ADPCM (0x12)` — a 24 kHz mono TTS stream needs 12 KB/s instead of 48 KB/s. Decoder state (`s_valpred`, `s_index`) is **continuous across all chunks of one stream** and reset at `AUDIO_OUT_END` ([net_ws.h:64](tutor_lamp/net_ws.h#L64), [tutor_lamp.ino:571-577](tutor_lamp/tutor_lamp.ino#L571)).
- **Uplink (encode):** `FRAME_AUDIO_CHUNK_ADPCM (0x06)` — the 32 KB/s raw mic stream becomes 8 KB/s. Encoder state is **separate** (full duplex) and continuous **per command turn**, reset in `begin_command_turn()` ([adpcm_dec.h:33-44](tutor_lamp/adpcm_dec.h#L33), [net_ws.h:60-61](tutor_lamp/net_ws.h#L60)).

### 13.2 Lookup tables ([adpcm_dec.cpp:10-26](tutor_lamp/adpcm_dec.cpp#L10))

- `kIndexTable[16]` = `{-1,-1,-1,-1,2,4,6,8, -1,-1,-1,-1,2,4,6,8}` — how the step index moves per code (small codes shrink the step, large codes grow it).
- `kStepTable[89]` — the 89‑entry quantiser step table from 7 up to 32767.

### 13.3 Decode ([adpcm_dec.cpp:43-86](tutor_lamp/adpcm_dec.cpp#L43))

For each of `n_in*2` nibbles (high nibble of byte `i>>1` when `i` even, low when odd):

1. `index += kIndexTable[delta]`, clamped to `[0, 88]` (used for the **next** sample's step).
2. Split `sign = delta & 8`, `mag = delta & 7`.
3. `vpdiff = step>>3; if (mag&4) vpdiff += step; if (mag&2) vpdiff += step>>1; if (mag&1) vpdiff += step>>2;` — reconstructs the magnitude via successive halvings of the **current** step.
4. `valpred ±= vpdiff` (sign), clamped to int16.
5. `step = kStepTable[index]` **after** use — this AFTER‑use ordering is load‑bearing for bit‑exactness with the backend encoder ([adpcm_dec.cpp:76-78](tutor_lamp/adpcm_dec.cpp#L76)).

Returns `2*n_in` samples.

### 13.4 Encode ([adpcm_dec.cpp:93-147](tutor_lamp/adpcm_dec.cpp#L93))

Mirror of the decoder: `diff = in[i] − valpred`; extract sign; quantise by comparing `diff` against `step`, `step>>1`, `step>>2`, building the 4‑bit `delta` and accumulating `vpdiff`; update `valpred` (clamped); advance `index`/`step`; **pack two codes per byte, high nibble = first sample**. Odd trailing sample ships with a zero low nibble so no sample is lost ([adpcm_dec.cpp:140-142](tutor_lamp/adpcm_dec.cpp#L140)). `reset()`/`enc_reset()` zero their respective `valpred`+`index`. Pure integer math, no heap, no locking (called only from the loop task) ([adpcm_dec.h:17-18](tutor_lamp/adpcm_dec.h#L17)).

---

## 14. Speaker Output (`spk_i2s`)

### 14.1 Audio format & pins ([spk_i2s.h:17-58](tutor_lamp/spk_i2s.h#L17))

int16 little‑endian PCM, **24 kHz**, mono. Pins `BCLK=40` (shared with mic BCK), `LRC=39` (shared with mic WS), `DIN=38` (DOUT), GAIN floating (9 dB), SD floating (stereo‑mix mode). MAX98357A duplicates the channel to both pads.

### 14.2 Constants ([spk_i2s.cpp:26-60](tutor_lamp/spk_i2s.cpp#L26))

| Constant | Value | Meaning |
|----------|-------|---------|
| `SPK_SAMPLE_RATE` | `24000` | Matches backend TTS. |
| `DMA_BUF_COUNT` | `4` | DMA descriptors. |
| `DMA_BUF_LEN` | `512` | ~85 ms DMA latency; 2× headroom so WiFi/TLS on core 0 can pre‑empt the playback task without underrun. 4×512×4B = 8 KB DMA RAM. |
| `RING_BYTES` | `1024*1024` | 1 MB PSRAM jitter buffer ≈ 21.8 s @ 24 kHz mono — sized to hold an ENTIRE typical reply (absorbs a TCP burst after a LaTeX transfer). |
| `MONO_POP_BYTES` | `1024` | Mono PCM popped per iteration. |
| `STEREO_BUF_BYTES` | `2048` | mono→stereo expansion scratch (DRAM). |
| `RING_WAIT_MS` | `80` | RX timeout when the ring is empty. |
| `POST_END_DRAIN_MS` | `200` | Safety wait after empty + mark_end. |
| `PUSH_TIMEOUT_MS` | `20` | Back‑pressure when ring full. |
| `IDLE_RELEASE_MS` | `12000` | Release I2S after this much idle even without end‑mark (defensive). Was 3 s → caused audible pops on a slow WAN. |
| `REBUFFER_BYTES` | `32*1024` | Mid‑stream re‑buffer threshold (slow‑WAN hysteresis). |
| `PREROLL_BYTES` | `48*1024` | ~1 s pre‑roll before first playback. |
| `MIC_RESTORE_RATE` | `16000` | Mic's native rate after release. |
| default `s_volume` | `70` | Software volume so a fresh chip sounds reasonable before NVS loads. |

### 14.3 `begin()` ([spk_i2s.cpp:361-400](tutor_lamp/spk_i2s.cpp#L361))

Idempotent. Allocates the ring via `xRingbufferCreateWithCaps(RING_BYTES, RINGBUF_TYPE_BYTEBUF, MALLOC_CAP_SPIRAM)`; on failure falls back to a **64 KB DRAM** ring (`xRingbufferCreate`). It captures `s_ring_capacity = xRingbufferGetCurFreeSize()` (the *real* usable size, which the preroll/empty math must use, not `RING_BYTES`). Then spawns `spk_play` on **core 0, priority 2**.

### 14.4 `push_pcm()` / `mark_end()` / `set_volume()` ([spk_i2s.cpp:402-423](tutor_lamp/spk_i2s.cpp#L402))

`push_pcm` does `xRingbufferSend` with `PUSH_TIMEOUT_MS = 20` back‑pressure; on a full ring it **drops** the chunk and logs. `mark_end` sets `s_end_marked = true`. `set_volume` clamps to 100 and writes the single‑byte `s_volume` (naturally atomic on ESP32).

### 14.5 `playback_task()` ([spk_i2s.cpp:191-354](tutor_lamp/spk_i2s.cpp#L191))

Per iteration:

1. **Pre‑roll gate** ([spk_i2s.cpp:205-212](tutor_lamp/spk_i2s.cpp#L205)): while not owning I2S and not end‑marked, wait until `buffered ≥ PREROLL_BYTES`, sleeping 10 ms — gives a cushion so playback runs gap‑free. Bypassed when end‑marked (short replies play immediately).
2. **Re‑buffer gate** ([spk_i2s.cpp:219-256](tutor_lamp/spk_i2s.cpp#L219)): if the ring starved mid‑stream, feed *clean silence* via `i2s_write` until `REBUFFER_BYTES` re‑accumulate, instead of per‑chunk machine‑gun chop. A genuinely dead stream (idle > `IDLE_RELEASE_MS`) releases I2S defensively here.
3. **Pop** `MONO_POP_BYTES` via `xRingbufferReceiveUpTo` (`RING_WAIT_MS` timeout).
4. **On data**: acquire I2S if not owning; round to even bytes; **expand mono→stereo** into `s_stereo_buf` applying software volume — three paths: `vol≥100` unity (skip multiply), `vol==0` hard‑mute (memset zeros), else `(s·vol)/100` via int32 intermediate to prevent wrap. `i2s_write(..., portMAX_DELAY)` (blocking) paces the loop. Track `s_bytes_out` ([spk_i2s.cpp:262-311](tutor_lamp/spk_i2s.cpp#L262)).
5. **On empty ring** ([spk_i2s.cpp:314-351](tutor_lamp/spk_i2s.cpp#L314)): if end‑marked, wait `POST_END_DRAIN_MS` and, if the ring is now fully free, `release_i2s_tx()`. If not end‑marked but idle > `IDLE_RELEASE_MS`, release defensively. Otherwise enter re‑buffering.

### 14.6 `stop()` ([spk_i2s.cpp:425-453](tutor_lamp/spk_i2s.cpp#L425))

Hard‑abort on FRAME_CANCEL. It **drains the ring synchronously** but deliberately **does NOT call `release_i2s_tx()`** — that runs on the loop task (core 1) while the playback task (core 0) may be inside `i2s_write()`, the same cross‑core teardown race as the mic. Instead it sets `s_end_marked = true` so the playback task releases in its own context (~280 ms latency). This is the FRAME_CANCEL interrupt path (the only way for a user to interrupt mid‑reply, [spk_i2s.h:33-34](tutor_lamp/spk_i2s.h#L33)).

---

## 15. The Half-Duplex Handoff & Cross-Core Races

One controller, two consumers, two cores. The handoff is the firmware's hardest concurrency problem.

### 15.1 Speaker steals I2S — `acquire_i2s_tx()` ([spk_i2s.cpp:80-141](tutor_lamp/spk_i2s.cpp#L80))

Triggered on the first `AUDIO_OUT` chunk of a turn:

1. Clears any stale `s_end_marked` (a leftover would prematurely release this turn's I2S).
2. **`mic::stop()`** — blocks on the capture‑done semaphore until the mic capture task has exited and uninstalled the RX driver.
3. `i2s_driver_install` TX @ 24 kHz, `channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT`, `DOUT=38`. On failure it recovers the mic (`mic::begin(16000)` + `start_task()`).
4. `i2s_set_pin`, `i2s_zero_dma_buffer`; set `s_owning_i2s = true`.

### 15.2 Speaker releases I2S — `release_i2s_tx()` ([spk_i2s.cpp:143-188](tutor_lamp/spk_i2s.cpp#L143))

1. `i2s_zero_dma_buffer` + `i2s_driver_uninstall(TX)`; `s_owning_i2s = false`.
2. `mic::begin(MIC_RESTORE_RATE = 16000)`.
3. **CRITICAL ordering** ([spk_i2s.cpp:161-178](tutor_lamp/spk_i2s.cpp#L161)): `audio_post_process_reset()` + `wake::reset_debounce()` + `wake::restart_continuous()` run **BEFORE** `mic::start_task()`. The capture task (core 1, prio 8) starts mutating DSP/EI state the instant `start_task()` returns; resetting *after* would race the reset (core 0) against the capture task (core 1) and corrupt internals → abort. So reset first, then spawn.
4. `mic::start_task()` resumes RX.

### 15.3 The capture‑done semaphore ([mic_i2s.cpp:43-59](tutor_lamp/mic_i2s.cpp#L43), [109-126](tutor_lamp/mic_i2s.cpp#L109))

A `volatile bool` is **not a memory barrier on Xtensa LX7** — two cores can observe writes in different orders. To tear down the RX driver safely, the capture task itself does `i2s_driver_uninstall()` **then** `xSemaphoreGive()`. The give is a release fence: when `mic::stop()` takes the semaphore it is guaranteed to see the uninstalled‑driver state. Earlier designs that uninstalled from the *caller's* task (core 0) created a race where core 1 was still inside `i2s_read()` when the driver was ripped out → abort ([mic_i2s.cpp:110-118](tutor_lamp/mic_i2s.cpp#L110)).

**Net effect:** while speaking, the mic is OFF and wake detection is PAUSED. Cold‑start latency first‑push→audible ≈ 100 ms; warm‑up gap after `AUDIO_OUT_END` before mic recovers ≈ 300–500 ms ([spk_i2s.h:35-36](tutor_lamp/spk_i2s.h#L35)).

---

## 16. Configuration & Constants Reference

Compile‑time switches:

| Macro | Default | File | Effect |
|-------|---------|------|--------|
| `MIC_VERBOSE` | `1` | [mic_i2s.cpp:17](tutor_lamp/mic_i2s.cpp#L17) | Serial logging of mic lifecycle. |
| `SPK_VERBOSE` | `1` | [spk_i2s.cpp:16](tutor_lamp/spk_i2s.cpp#L16) | Serial logging of speaker lifecycle. |
| `MIC_WIRE_ADPCM` | `1` | [tutor_lamp.ino:363](tutor_lamp/tutor_lamp.ino#L363) | 1 = ADPCM uplink (0x06); 0 = raw PCM (0x02). |
| `EIDSP_QUANTIZE_FILTERBANK` | `0` | [wake_word.cpp:3](tutor_lamp/wake_word.cpp#L3) | EI DSP config (float filterbank). |
| `USE_OPUS_DECODER` | (build) | [tutor_lamp.ino:553](tutor_lamp/tutor_lamp.ino#L553) | Enables `FRAME_AUDIO_OUT_OPUS (0x13)` decode; else dropped. |

The per‑stage DSP constants are catalogued in §8.2 (NS), §9.2 (ALE), §10.2 (AGC), §11.2 (VAD); I2S/framing in §4.2; EOS in §12.1; speaker in §14.2. Notable cross‑stage couplings: `VAD_NF_MIN == NS_MIN_FLOOR == 100.0` (consistent floor units); `AGC_TARGET=3000` rms² ≈ 9e6 sits well above `VAD_ENERGY_ABS_MIN=4.0e6` so the user's own speech always clears the gate even after the 1.44 scale cap.

---

## 17. Edge Cases, Error Handling, Timeouts, Fallbacks

- **DMA stall** → 100 ms `i2s_read` timeout lets the capture loop re‑check `s_running` ([mic_i2s.cpp:91-93](tutor_lamp/mic_i2s.cpp#L91)).
- **`mic::stop()` not acknowledged in 1 s** → FATAL log + force `i2s_driver_uninstall` ([mic_i2s.cpp:247-248](tutor_lamp/mic_i2s.cpp#L247)).
- **`begin()` with no semaphore** → defensive bail without touching the driver ([mic_i2s.cpp:221-228](tutor_lamp/mic_i2s.cpp#L221)).
- **I2S TX install/set_pin failure** → recover the mic (`mic::begin` + `start_task`) ([spk_i2s.cpp:121-136](tutor_lamp/spk_i2s.cpp#L121)).
- **PSRAM ring alloc failure** → 64 KB DRAM fallback; `s_ring_capacity` makes all math correct regardless ([spk_i2s.cpp:371-386](tutor_lamp/spk_i2s.cpp#L371)).
- **Ring full** → `push_pcm` drops the chunk after 20 ms back‑pressure ([spk_i2s.cpp:406-409](tutor_lamp/spk_i2s.cpp#L406)).
- **Dead stream (no `AUDIO_OUT_END`)** → defensive release after `IDLE_RELEASE_MS = 12 s` so the mic always returns ([spk_i2s.cpp:325-339](tutor_lamp/spk_i2s.cpp#L325)).
- **Slow WAN starve** → re‑buffer hysteresis plays phrase‑sized bursts instead of chop ([spk_i2s.cpp:214-256](tutor_lamp/spk_i2s.cpp#L214)).
- **Wake OOM** → `wake::begin()` returns false ([wake_word.cpp:48](tutor_lamp/wake_word.cpp#L48)).
- **Inference error** → `tick()` returns false, no fire ([wake_word.cpp:78](tutor_lamp/wake_word.cpp#L78)).
- **Stale wake window after playback gap** → `restart_continuous()` flushes it ([wake_word.cpp:106-119](tutor_lamp/wake_word.cpp#L106)).
- **VAD floor latches low** → absolute energy gate (`VAD_ENERGY_ABS_MIN`) prevents background false‑voting speech and stalling EOS ([vad_stage.cpp:68-84](tutor_lamp/vad_stage.cpp#L68)).
- **EOS stall in noisy room** → leaky‑integrator silence + near‑field anchor ([tutor_lamp.ino:197-222](tutor_lamp/tutor_lamp.ino#L197)).
- **AUDIO_OUT_ADPCM oversize (>1 KB)** → dropped with a log ([tutor_lamp.ino:535-538](tutor_lamp/tutor_lamp.ino#L535)).
- **OPUS frame without `USE_OPUS_DECODER`** → logged once per turn, dropped ([tutor_lamp.ino:559-567](tutor_lamp/tutor_lamp.ino#L559)).
- **Accidental PTT tap** (< `PTT_MIN_SAMPLES`, 0.4 s) → turn discarded, no billable LLM call ([tutor_lamp.ino:271-273](tutor_lamp/tutor_lamp.ino#L271)).
- **Uplink TX drops during a turn** → at EOS, MODE_SENDING re‑sends the FULL utterance from `cmd_buf` after `adpcm::enc_reset()` ([tutor_lamp.ino:1716-1733](tutor_lamp/tutor_lamp.ino#L1716)).

---

## 18. Integration Points (Cross-References)

**Wiring in `setup()`** ([tutor_lamp.ino:1383-1404](tutor_lamp/tutor_lamp.ino#L1383)): `wake::begin()` → `audio_post_process_reset()` → `mic::set_on_raw_frame(on_raw_frame)` + `mic::set_on_cleaned_frame(on_cleaned_frame)` → `mic::begin(wake::sample_rate())` → `mic::start_task()` → `spk::begin()` (after the mic, since the speaker steals the bus only on first `AUDIO_OUT`).

**Calls OUT of this subsystem:**
- `wake::feed_frame` (from `on_raw_frame`), `wake::tick` (from `loop()` MODE_IDLE).
- `net::send_frame(FRAME_AUDIO_CHUNK_ADPCM | FRAME_AUDIO_CHUNK, …)` from `on_cleaned_frame` — the uplink to the FastAPI backend over WebSocket ([net_ws.h:54-61](tutor_lamp/net_ws.h#L54)).
- `tft_ui::set_listening_level` (waveform UI).
- `spk::push_pcm` / `spk::mark_end` from the WS RX dispatcher.

**Calls IN from the network layer** ([tutor_lamp.ino:496-577](tutor_lamp/tutor_lamp.ino#L496)): `handle_server_frame` decodes `FRAME_AUDIO_OUT (0x10)` → `spk::push_pcm`; `FRAME_AUDIO_OUT_ADPCM (0x12)` → `adpcm::decode` → `spk::push_pcm`; `FRAME_AUDIO_OUT_OPUS (0x13)` → optional Opus; `FRAME_AUDIO_OUT_END (0x11)` → `spk::mark_end` + `adpcm::reset`.

**Backend coupling:** the ADPCM codec is bit‑exact with the backend's CPython `audioop` (`TTS_WIRE_CODEC=adpcm` downlink, `audioop.adpcm2lin` uplink) — encoder/decoder state must reset at the exact same stream boundaries on both ends ([adpcm_dec.h:1-44](tutor_lamp/adpcm_dec.h#L1)). The mic sample rate must equal `EI_CLASSIFIER_FREQUENCY` (16 kHz); the speaker rate must equal the backend TTS rate (24 kHz).

**Database/frontend:** indirect — cleaned uplink audio is transcribed and embedded (pgvector memory) by the backend; the simulator/frontend mirror the same WebSocket frame catalog.

---

## 19. Mermaid Diagrams

### 19.1 Per‑frame capture flow (flowchart)

```mermaid
flowchart TD
    DMA["INMP441 → I2S RX DMA<br/>s_raw[512] int32 @16kHz"] --> READ["i2s_read (100ms timeout)"]
    READ --> DSP["apply_dsp()<br/>>>8 → DC-blocker(32604,Q15) → sat16(>>4)<br/>→ s_samples[512] int16"]
    DSP --> RAW["on_raw_frame → wake::feed_frame<br/>(pre-postprocess, training-identical)"]
    RAW --> WBUF{"buf_count == SLICE_SIZE?"}
    WBUF -- yes --> READY["ping-pong, buf_ready=1<br/>(tick() in MODE_IDLE classifies)"]
    WBUF -- no --> APP
    READY --> APP["audio_post_process()"]
    APP --> NS["NS: Wiener single-band"]
    NS --> ALE["ALE: NLMS, freeze on vad_is_speech()"]
    ALE --> AGC["AGC: normalise to 3000 rms, hold in silence"]
    AGC --> VAD["VAD: 3-feature vote + 8-frame hangover"]
    VAD --> CLEAN["on_cleaned_frame (MODE_COMMAND only)"]
    CLEAN --> ENC["adpcm::encode 4:1 → FRAME_AUDIO_CHUNK_ADPCM 0x06"]
    CLEAN --> EOS["EOS: leaky silence + near-field anchor"]
    ENC --> NET["net::send_frame → WebSocket backend"]
    EOS --> ENDQ{"silence ≥ 4s OR 30s cap?"}
    ENDQ -- yes --> SEND["MODE_SENDING → AUDIO_END"]
```

### 19.2 Half‑duplex turn (sequence)

```mermaid
sequenceDiagram
    participant U as User
    participant CAP as mic_capture (core1 p8)
    participant LOOP as loop() (core1)
    participant NET as WebSocket
    participant SPK as spk_play (core0 p2)
    U->>CAP: "hey lumos"
    CAP->>CAP: apply_dsp + feed_frame + NS/ALE/AGC/VAD
    LOOP->>LOOP: wake::tick() conf>0.70 ×2 → fire
    LOOP->>LOOP: begin_command_turn() (adpcm::enc_reset, MODE_COMMAND)
    U->>CAP: speaks question
    CAP->>NET: FRAME_AUDIO_CHUNK_ADPCM (0x06) per frame
    CAP->>CAP: EOS: silence ≥ 4s
    LOOP->>NET: FRAME_AUDIO_END (0x03)
    NET-->>LOOP: FRAME_AUDIO_OUT_ADPCM (0x12) chunks
    LOOP->>SPK: adpcm::decode → spk::push_pcm (ring)
    SPK->>CAP: acquire_i2s_tx → mic::stop() (semaphore)
    SPK->>U: I2S TX @24kHz → MAX98357A (mono→stereo, volume)
    NET-->>LOOP: FRAME_AUDIO_OUT_END (0x11)
    LOOP->>SPK: spk::mark_end() ; adpcm::reset()
    SPK->>SPK: ring drains → release_i2s_tx()
    SPK->>CAP: reset DSP+wake, mic::begin/start_task (RX @16kHz)
```

---

*End of reference. Every value, threshold, and ordering invariant above is quoted directly from the cited source lines; no behaviour has been inferred beyond what the code expresses.*

---

_Re-verified against firmware tip c699e72 on 2026-07-06: no audio source file (mic_i2s, audio_post_process, adpcm_enc/dec, spk_i2s, VAD) has changed since this doc was written; the June-July firmware commits (aa2143c graphs/compression, e1de15a OTA+chem, c699e72 UX iteration) touched only display, networking, buttons and OTA code — see docs 02 and 03._
