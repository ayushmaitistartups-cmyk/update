# Firmware (ESP32-S3 device)

> **Updated 2026-07-05** — re-synced against firmware tip `c699e72` (2026-07-03); previous sync was `8c13325` (2026-06-16). Firmware development is active (not frozen): +4 commits added over-the-air self-update (`ota`), a `display_config.h` panel-geometry single-source-of-truth, a large `tft_ui` rewrite with interactive graph + chemistry pages, JPEG-compressed equations, optional Opus TTS decode, and — in `c699e72` — a scroll-document reading page (`TFT_SCROLL_DOC`), a filled-in `BTN_RIGHT_LONG` long-press button, and multi-graph support. See each doc's new sections (`02-display-and-ui.md` §4.9) and `folder_details/01-firmware.md` for the file catalog.

This area documents the on-device firmware for the **Smart Tutor Lamp** ("Lumos") — a single Arduino/C++ sketch (`tutor_lamp.ino`) running on an **ESP32-S3** that turns a desk lamp into an always-listening AI tutor. The firmware captures a spoken question (INMP441 mic + on-device DSP + a local "hey lumos" wake word), snaps a photo of the page on the desk (OV5640 camera), streams both to a Python/FastAPI backend over one persistent secure WebSocket, then plays back the spoken answer (MAX98357A speaker) while rendering text/LaTeX/images on a 320×240 TFT panel. A core architectural rule runs through every doc: **no user-facing intelligence lives on the device** — no LLM, transcription, or LaTeX rendering happens on-chip; the lamp is a thin, real-time orchestrator and the backend does all the heavy work.

The documents below decompose that firmware by subsystem: the top-level architecture and state machine, the audio capture/DSP/playback pipeline, the TFT display and immediate-mode UI, the device-side WebSocket/camera/button I/O, and the constellation of standalone test sketches used to bring up each peripheral in isolation. Every doc is line-grounded against the actual source under `Smart-Tutor-Lamp/tutor_lamp/`, quoting concrete constants, thresholds, pin maps, and ordering invariants rather than paraphrasing.

## Documents

| Document | Summary |
|---|---|
| [00-overview-and-architecture.md](00-overview-and-architecture.md) | The definitive top-level reference: the ESP32-S3 hardware platform, the boot/`setup()` sequence, the `loop()` and three-mode pipeline state machine, and the module/threading map. Also covers persistent NVS settings (`settings_store`), Wi-Fi credential resolution, device pairing/provisioning over HTTPS, the RGB status-LED machine, and how the device fits into the larger backend/frontend/db system. Start here. |
| [01-audio-dsp-pipeline.md](01-audio-dsp-pipeline.md) | The audio subsystem — the lamp's "ears and mouth." Documents I2S mic capture (`mic_i2s`), the training-identical `apply_dsp()` chain, the Edge Impulse wake-word classifier, the four-stage post-process chain (Noise Suppression → Adaptive Line Enhancer → AGC → VAD), end-of-speech (EOS) detection, IMA/DVI ADPCM coding, and MAX98357A speaker output. A large focus is the strictly half-duplex handoff and cross-core races caused by the mic and speaker sharing one I2S controller. |
| [02-display-and-ui.md](02-display-and-ui.md) | The TFT display subsystem driving the 320×240 SPI panel (TFT_eSPI / ILI9341-class). Covers the master UI state machine (`tft_ui`), the Settings page, the on-screen keyboard (`text_entry`), the pairing-QR generator (`tft_qr` + vendored `RICqrcode`), JPEG image viewers, and the on-device LaTeX/equation viewer. Establishes that the device does NOT render LaTeX — the backend ships finished RGB565 pixel frames; the ESP32 covers two pixel pipelines (server frames vs. on-device JPEG decode) plus a self-contained immediate-mode toolkit. |
| [03-networking-camera-buttons.md](03-networking-camera-buttons.md) | The three device-facing I/O subsystems: the persistent secure WebSocket transport (`net_ws`), the OV5640 camera capture pipeline (`camera`), and the 5-way ADC resistor-ladder button reader (`buttons`). Details the on-the-wire binary frame protocol (full frame catalog, TLS/JWT auth, the `wss://` library bug + fix, reconnection backoff, TX queue), chunked JPEG capture/streaming with autofocus and standby, and decoding one analog pin into five buttons plus a long-press gesture. |
| [04-test-sketches-and-subprojects.md](04-test-sketches-and-subprojects.md) | The standalone test sketches and helper sub-projects surrounding the main firmware — single-purpose Arduino sketches plus PC-side Python helpers used to bring up, calibrate, train, and locally simulate each subsystem in isolation (`camera_test/`, `ei_data_collector/`, `mic_recorder/`, `push_buttons/`, `tft_latex_client/`, `wifi_audio_player/`, and the drop-in `dummy_backend.py` simulator). Each rig mirrors production DSP, pin maps, or wire protocols so test-rig measurements are byte-for-byte what the real device sees. |

## Where to find X

- **How the device boots / the overall flow** → [00-overview-and-architecture.md](00-overview-and-architecture.md) (`setup()` sequence, `loop()`, three-mode state machine)
- **The three-mode pipeline state machine** → [00-overview-and-architecture.md](00-overview-and-architecture.md) §9
- **Wi-Fi credentials, NVS settings, device pairing/provisioning** → [00-overview-and-architecture.md](00-overview-and-architecture.md) §§5–7
- **Hardware platform, pin map, module/threading model** → [00-overview-and-architecture.md](00-overview-and-architecture.md) §§2–3 (camera pins also in [03](03-networking-camera-buttons.md) §4.1)
- **Wake word ("hey lumos") / Edge Impulse model** → [01-audio-dsp-pipeline.md](01-audio-dsp-pipeline.md) §6 (training-data collection in [04](04-test-sketches-and-subprojects.md) §4)
- **DSP chain (NS, ALE, AGC, VAD) and end-of-speech (EOS)** → [01-audio-dsp-pipeline.md](01-audio-dsp-pipeline.md) §§5, 7–12
- **Microphone / speaker / ADPCM / half-duplex handoff** → [01-audio-dsp-pipeline.md](01-audio-dsp-pipeline.md) §§4, 13–15
- **TFT pages, animated eyes, listening/thinking states, status bar** → [02-display-and-ui.md](02-display-and-ui.md) §3
- **On-device LaTeX / equation rendering (and why it's server-rendered)** → [02-display-and-ui.md](02-display-and-ui.md) §4
- **Pairing QR code generation** → [02-display-and-ui.md](02-display-and-ui.md) §6
- **On-screen keyboard / Settings page** → [02-display-and-ui.md](02-display-and-ui.md) §§7–8
- **Interactive graph page & chemistry-structure page (pan/zoom, L/R steps)** → [02-display-and-ui.md](02-display-and-ui.md) §9
- **JPEG-compressed equations, `display_config.h` panel scaling** → [02-display-and-ui.md](02-display-and-ui.md) §§2, 9
- **Over-the-air (OTA) firmware self-update** → [03-networking-camera-buttons.md](03-networking-camera-buttons.md) §3.13 (boot-window rationale in [00](00-overview-and-architecture.md) §8)
- **Directional long-press buttons (graph zoom / toggle)** → [03-networking-camera-buttons.md](03-networking-camera-buttons.md) §5
- **WebSocket wire protocol, frame catalog, TLS/JWT auth, reconnection** → [03-networking-camera-buttons.md](03-networking-camera-buttons.md) §3
- **Camera capture, autofocus, JPEG streaming, standby** → [03-networking-camera-buttons.md](03-networking-camera-buttons.md) §4
- **Buttons: ADC ladder decode, debounce, long-press, hold-to-talk** → [03-networking-camera-buttons.md](03-networking-camera-buttons.md) §5
- **Bringing up / calibrating a single peripheral in isolation** → [04-test-sketches-and-subprojects.md](04-test-sketches-and-subprojects.md)
- **The local backend simulator (`dummy_backend.py`)** → [04-test-sketches-and-subprojects.md](04-test-sketches-and-subprojects.md) §9
- **Test-rig → production-firmware mapping** → [04-test-sketches-and-subprojects.md](04-test-sketches-and-subprojects.md) §10
