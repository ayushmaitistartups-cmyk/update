# Firmware — System Overview & Architecture

The Smart Tutor Lamp firmware is a single Arduino/C++ sketch (`tutor_lamp.ino`) running on an **ESP32-S3** that turns a desk lamp into an always-listening AI tutor. It captures the user's spoken question (mic + on-device DSP + a local "hey lumos" wake word), snaps a photo of the page on the desk (OV5640 camera), streams both to a Python backend over one persistent WebSocket, and plays back the spoken answer (MAX98357A speaker) while rendering text/LaTeX on a TFT. This document is the definitive reference for the *top-level architecture*: the hardware platform, the boot/`setup()` sequence, the `loop()` and the three-mode pipeline state machine, persistent settings (NVS), Wi-Fi credential resolution, device pairing/provisioning, and how the device fits into the larger system.

> Scope of files covered in depth: [`tutor_lamp.ino`](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino), [`board_config.h`](../../Smart-Tutor-Lamp/tutor_lamp/board_config.h), [`camera_pins.h`](../../Smart-Tutor-Lamp/tutor_lamp/camera_pins.h), [`backend_config.h`](../../Smart-Tutor-Lamp/tutor_lamp/backend_config.h), [`settings_store.h`](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.h)/[`.cpp`](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp), [`provisioning.h`](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.h)/[`.cpp`](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp). Cross-referenced module interfaces: `net_ws.h`, `wake_word.h`, `mic_i2s.h`, `spk_i2s.h`, `camera.h`, `buttons.h`, `vad_stage.h`.

---

## Table of contents

1. [Purpose and responsibility](#1-purpose-and-responsibility)
2. [The hardware platform](#2-the-hardware-platform)
3. [Module map and threading model](#3-module-map-and-threading-model)
4. [Configuration: compile-time switches, constants, env](#4-configuration-compile-time-switches-constants-env)
5. [Persistent settings (`settings_store`)](#5-persistent-settings-settings_store)
6. [Wi-Fi provisioning (credential resolution + connect)](#6-wi-fi-provisioning-credential-resolution--connect)
7. [Device pairing / provisioning over HTTPS (`provisioning`)](#7-device-pairing--provisioning-over-https-provisioning)
8. [Boot / `setup()` sequence, step by step](#8-boot--setup-sequence-step-by-step)
9. [The device state machine and `loop()`](#9-the-device-state-machine-and-loop)
10. [Capture-task hooks and the EOS algorithm](#10-capture-task-hooks-and-the-eos-algorithm)
11. [Inbound WebSocket frame handling](#11-inbound-websocket-frame-handling)
12. [The RGB status LED state machine](#12-the-rgb-status-led-state-machine)
13. [Edge cases, timeouts, retries, fallbacks](#13-edge-cases-timeouts-retries-fallbacks)
14. [Integration points (firmware ↔ backend ↔ frontend ↔ db)](#14-integration-points)
15. [Mermaid diagrams](#15-mermaid-diagrams)
16. [File-by-file / function-by-function breakdown](#16-file-by-file--function-by-function-breakdown)

---

## 1. Purpose and responsibility

This layer of the system is the **device orchestrator**. The lamp deliberately runs **no user-facing intelligence** — no LLM, no transcription, no LaTeX rendering happens on-device. The backend does everything heavy ([HARDWARE_CONTEXT.md §0](../../Smart-Tutor-Lamp/HARDWARE_CONTEXT.md)). The firmware's job is narrowly defined:

- **Always-on local listening** for the wake word **"hey lumos"** via an Edge Impulse model that runs entirely on-device with no network access.
- **Clean the audio on-device** (NS → ALE → AGC → VAD) before streaming, so the backend receives denoised PCM.
- **Detect end-of-speech (EOS)** locally so the backend gets a complete utterance and a single "fire the LLM" signal.
- **Grab visual context** (one or more JPEGs per turn) from the desk-mounted camera.
- **Hold one persistent WebSocket** to the backend, opened at boot and kept open forever, and reconnect with backoff if it drops.
- **Render the response**: play TTS audio (half-duplex with the mic), and paint TFT pages (text, LaTeX, spinner, eyes).
- **Persist a tiny amount of state in NVS**: user preferences (volume, photos-per-turn) and identity (device_id / device_secret / device_jwt) — "stateless from the backend's perspective other than `device_id`" ([HARDWARE_CONTEXT.md:27](../../Smart-Tutor-Lamp/HARDWARE_CONTEXT.md)).

The top-level file [`tutor_lamp.ino`](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino) is where all subsystems are wired together and where the **three-mode pipeline state machine** lives. Every other `.cpp` in the sketch folder is a subsystem driven from here.

---

## 2. The hardware platform

### 2.1 MCU

| Property | Value | Source |
|---|---|---|
| SoC | ESP32-S3, dual-core Xtensa LX7 @ 240 MHz, **single-precision FPU only** | [PROJECT_CONTEXT.md:437](../../Smart-Tutor-Lamp/PROJECT_CONTEXT.md), [§512](../../Smart-Tutor-Lamp/PROJECT_CONTEXT.md) |
| RAM | 512 KB internal SRAM/DRAM | [PROJECT_CONTEXT.md:437](../../Smart-Tutor-Lamp/PROJECT_CONTEXT.md) |
| PSRAM | **OPI PSRAM required** (Arduino IDE → Tools → PSRAM → OPI PSRAM) | [PROJECT_CONTEXT.md:525](../../Smart-Tutor-Lamp/PROJECT_CONTEXT.md) |
| Partition | ≥ 3 MB APP space partition scheme | [board_config.h:9](../../Smart-Tutor-Lamp/tutor_lamp/board_config.h) |
| Flash NVS | ~4 KB key/value partition for `device_id`, `device_secret`, `device_jwt`, Wi-Fi creds, prefs | [HARDWARE_CONTEXT.md:66](../../Smart-Tutor-Lamp/HARDWARE_CONTEXT.md) |
| Network | WiFi 2.4 GHz STA, TLS via mbedTLS | [HARDWARE_CONTEXT.md:65](../../Smart-Tutor-Lamp/HARDWARE_CONTEXT.md) |

**FPU constraint (load-bearing for all DSP):** the LX7 has only a hardware *single*-precision FPU. All DSP accumulators must be `float` + `sqrtf()`; `double` forces software emulation at ~10× cost ([PROJECT_CONTEXT.md:512-515](../../Smart-Tutor-Lamp/PROJECT_CONTEXT.md), [§816](../../Smart-Tutor-Lamp/PROJECT_CONTEXT.md)). The `.ino` honours this — e.g. RMS is computed with `sqrtf` over `float` in [`on_cleaned_frame`](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L401) and the LED breathing uses `sinf` ([tutor_lamp.ino:919](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L919)).

**Core pinning:** the mic capture task runs on **core 1, priority 8** (same core as `loop()`); WiFi runs on core 0. The capture task must NOT be pinned to core 0 or WiFi starves ([PROJECT_CONTEXT.md:818-819](../../Smart-Tutor-Lamp/PROJECT_CONTEXT.md)). The speaker playback task runs on **core 0, priority 2** ([spk_i2s.h:53](../../Smart-Tutor-Lamp/tutor_lamp/spk_i2s.h)). The camera worker also runs on **core 0** ([camera.h:34](../../Smart-Tutor-Lamp/tutor_lamp/camera.h)).

### 2.2 Peripherals and pin map

The board model is selected in [board_config.h:16](../../Smart-Tutor-Lamp/tutor_lamp/board_config.h):

```c
#define CAMERA_MODEL_ESP32S3_EYE // Has PSRAM
#include "camera_pins.h"
```

This selects the `CAMERA_MODEL_ESP32S3_EYE` pin block in [camera_pins.h:297-315](../../Smart-Tutor-Lamp/tutor_lamp/camera_pins.h) (the Freenove ESP32-S3 WROOM layout, per [camera.h:19-24](../../Smart-Tutor-Lamp/tutor_lamp/camera.h)). If no model is `#define`d, `camera_pins.h` `#error`s out ([camera_pins.h:337](../../Smart-Tutor-Lamp/tutor_lamp/camera_pins.h)).

| Peripheral | Part | Bus / pins | Format | Source |
|---|---|---|---|---|
| Microphone | INMP441 | I2S **RX** on `I2S_NUM_0`; BCK=40, WS/LRCK=39, DIN=1, L/R→GND (left only) | 16 kHz mono int16 LE, 32-bit I2S frames | [mic_i2s.h:30-35](../../Smart-Tutor-Lamp/tutor_lamp/mic_i2s.h), [PROJECT_CONTEXT.md:441-449](../../Smart-Tutor-Lamp/PROJECT_CONTEXT.md) |
| Speaker amp | MAX98357A | I2S **TX** on `I2S_NUM_0`; BCLK=40 (shared mic BCK), LRC=39 (shared mic WS), DIN=38 | 24 kHz mono int16 LE wire; expanded to stereo internally | [spk_i2s.h:38-46](../../Smart-Tutor-Lamp/tutor_lamp/spk_i2s.h), [HARDWARE_CONTEXT.md:61](../../Smart-Tutor-Lamp/HARDWARE_CONTEXT.md) |
| Camera | OV5640 + VCM autofocus | `LCD_CAM` peripheral (distinct from I2S); XCLK=15, SIOD=4, SIOC=5, Y2..Y9=11/9/8/10/12/18/17/16, VSYNC=6, HREF=7, PCLK=13, PWDN=-1, RESET=-1 | JPEG; VGA idle, UXGA capture | [camera_pins.h:297-315](../../Smart-Tutor-Lamp/tutor_lamp/camera_pins.h), [camera.h:19-24](../../Smart-Tutor-Lamp/tutor_lamp/camera.h) |
| TFT | ILI9341 / ST7789, 240×320 | SPI (separate pins), **rotation 3 → landscape 320 W × 240 H** | RGB565, big-endian byte-swapped, BGR | [HARDWARE_CONTEXT.md:60](../../Smart-Tutor-Lamp/HARDWARE_CONTEXT.md), [tutor_lamp.ino:47](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino) |
| Status LED | WS2812B (single pixel) | GPIO **48**, driven via `neopixelWrite()` | RGB | [tutor_lamp.ino:225](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L225) |
| Buttons | 5-way resistor ladder | single ADC pin GPIO **2** | analog voltage decoded to L/SEL/R/DOWN/UP | [buttons.h:6-13](../../Smart-Tutor-Lamp/tutor_lamp/buttons.h), [buttons.h:26-28](../../Smart-Tutor-Lamp/tutor_lamp/buttons.h) |

**No GPIO collisions:** camera pins (above) do not clash with mic (1, 39, 40), speaker (38, shared 39/40), buttons (2), or LED (48); TFT is on SPI ([camera.h:25-26](../../Smart-Tutor-Lamp/tutor_lamp/camera.h)).

**Half-duplex audio (critical constraint):** the mic (RX) and speaker (TX) **share the single physical I2S controller** `I2S_NUM_0` on pins BCK=40 / WS=39. Only one can own the bus at a time. `spk_i2s` *steals* the bus from the mic on the first `AUDIO_OUT` chunk and returns it on `AUDIO_OUT_END` ([spk_i2s.h:22-36](../../Smart-Tutor-Lamp/tutor_lamp/spk_i2s.h), [tutor_lamp.ino:44-47](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino)). **While the lamp speaks, the mic is deaf and wake-word detection is paused by design.** Cold-start latency first push→audible ≈ 100 ms; warm-up gap after `AUDIO_OUT_END` before mic recovers ≈ 300–500 ms ([spk_i2s.h:35-36](../../Smart-Tutor-Lamp/tutor_lamp/spk_i2s.h)).

### 2.3 PSRAM budget

UXGA camera with `fb_count=2` reserves ~300 KB; total project PSRAM (cmd_buf + tft_ui latex/image caches + net_ws assemble + camera) ≈ 2.3 MB ([camera.h:42-44](../../Smart-Tutor-Lamp/tutor_lamp/camera.h)). A historically important detail: the TFT chunked-receive accumulator **shares** the `tft_ui` `s_latex` PSRAM buffer instead of allocating a second 3 MB block — the previous double-alloc starved `esp_camera_init` of the ~1 MB it needs for UXGA frame buffers and broke the camera ([tutor_lamp.ino:316-324](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L316), [tutor_lamp.ino:1266-1269](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1266)). The 30 s `cmd_buf` diagnostic copy is `ps_malloc`'d in `setup()` ([tutor_lamp.ino:1252](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1252)).

---

## 3. Module map and threading model

All modules are in the same sketch folder and compiled as one program. The `.ino` includes and wires them together.

| Module | Responsibility | Header |
|---|---|---|
| `mic_i2s` | I2S RX + DMA capture task + training-identical DSP (`raw>>8 → DC-blocker IIR coeff 32604 → sat16(>>4)`) | [mic_i2s.h](../../Smart-Tutor-Lamp/tutor_lamp/mic_i2s.h) |
| `wake_word` | Edge Impulse continuous classifier + debounce | [wake_word.h](../../Smart-Tutor-Lamp/tutor_lamp/wake_word.h) |
| `audio_post_process` + `ns_stage`/`ale_stage`/`agc_stage`/`vad_stage` | NS → ALE → AGC → VAD DSP chain | [vad_stage.h](../../Smart-Tutor-Lamp/tutor_lamp/vad_stage.h) |
| `net_ws` | Persistent (W)SS WebSocket, binary frame protocol (grew to ~20 frame types incl. graph/chem/JPEG-equation/Opus), TX queue + slow-write stall detector, reconnect/backoff, async image send | [net_ws.h](../../Smart-Tutor-Lamp/tutor_lamp/net_ws.h) |
| `ota` | HTTPS-pull firmware self-update at boot (spare OTA partition, streamed + verified); one-shot `ota::check_boot()` in a quiet boot window | [ota.h](../../Smart-Tutor-Lamp/tutor_lamp/ota.h) |
| `spk_i2s` | MAX98357A TTS output, half-duplex bus steal, software volume | [spk_i2s.h](../../Smart-Tutor-Lamp/tutor_lamp/spk_i2s.h) |
| `camera` | OV5640 + AF, async JPEG grab on core 0 | [camera.h](../../Smart-Tutor-Lamp/tutor_lamp/camera.h) |
| `buttons` | 5-way ADC ladder, edge events + hold detection + long-press (SELECT plus new directional DOWN/UP/LEFT long-press for the graph page) | [buttons.h](../../Smart-Tutor-Lamp/tutor_lamp/buttons.h) |
| `tft_ui` | Master TFT UI: pages (now incl. interactive `PAGE_GRAPH` + `PAGE_CHEM`), animations, top bar, LaTeX + JPEG-equation accumulators; geometry from `display_config.h` | `tft_ui.h` |
| `display_config.h` | Panel-geometry single source of truth + `lamp_sx/sy/smin` scale helpers (identity at 320×240) | `display_config.h` |
| `tft_settings` / `text_entry` | Settings page; on-screen keyboard | `tft_settings.h` / `text_entry.h` |
| `provisioning` | Pairing over HTTPS + JWT (active when `ENABLE_AUTH=1`) | [provisioning.h](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.h) |
| `settings_store` | NVS-backed user preferences + saved Wi-Fi creds | [settings_store.h](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.h) |
| `adpcm_dec` | IMA/DVI ADPCM encode/decode (uplink mic + downlink TTS) | `adpcm_dec.h` |
| `tft_qr` / `image_viewer` / `tft_display` | Legacy/back-compat (dead code) | [tutor_lamp.ino:30-31](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino) |

### Threading model (who runs where)

```
core 0                                   core 1
──────                                   ──────
WiFi stack (prio 23)                     loop()  ── the orchestrator
spk_playback_task (prio 2)               mic_capture task (prio 8) ── pre-empts loop()
camera worker (grab_async)
```

- **Only `net::loop()`** (called from `loop()`) ever touches the WS library directly. `net::send_frame()` for AUDIO_CHUNK-sized payloads is safe from the capture task; large one-shot payloads (images) must be sent from `loop()` ([net_ws.h:8-13](../../Smart-Tutor-Lamp/tutor_lamp/net_ws.h)).
- The capture task calls user hooks every DMA frame in a **strict order** ([mic_i2s.h:6-15](../../Smart-Tutor-Lamp/tutor_lamp/mic_i2s.h)):
  1. `apply_dsp()` (internal) — produces the training-identical signal.
  2. `on_raw_frame_cb` → `wake::feed_frame()` — EI reads the *pre-postprocess* signal.
  3. `audio_post_process()` — NS → ALE → AGC → VAD, **in place**.
  4. `on_cleaned_frame_cb` → `on_cleaned_frame()` — command recorder/streamer.
  - **Steps 2 and 3 must never be reordered.** The EI model was trained on the pre-NS/ALE/AGC signal; feeding it post-processed audio makes it always vote "noise" ([PROJECT_CONTEXT.md:493-510](../../Smart-Tutor-Lamp/PROJECT_CONTEXT.md), [tutor_lamp.ino:42-44](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino)).
- **Cross-task safety rule** (the `.ino` calls this out explicitly): never call `audio_post_process_reset()` or `wake::reset_debounce()` from `loop()` while the capture task is live — it would race mid-DMA-frame and corrupt the DSP structs. The legitimate reset point is inside `spk_i2s::release_i2s_tx()` *after* `mic::stop()` has stopped the capture task via a semaphore handshake ([tutor_lamp.ino:1782-1795](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1782)).

---

## 4. Configuration: compile-time switches, constants, env

### 4.1 `backend_config.h` — single source of truth for the backend address

This header is included by `net_ws.h` (runtime socket), `provisioning.h` (pairing HTTPS), and `ota.cpp` (self-update version endpoint), and derives all URLs from one switch ([backend_config.h:4-7](../../Smart-Tutor-Lamp/tutor_lamp/backend_config.h)). As of `e1de15a` it also carries the `USE_OPUS_DECODER` toggle (default `1` there; see §4.2).

| Macro | Default | Effect |
|---|---|---|
| `BACKEND_USE_SERVER` | `1` | `0` = LOCAL PC over plain `ws://`/`http://` (dev); `1` = Render over `wss://`/`https://` (prod). The "one line most people need to touch." | [backend_config.h:33-35](../../Smart-Tutor-Lamp/tutor_lamp/backend_config.h) |
| `BACKEND_HOST_PORT` | `"192.168.0.5:8000"` | LAN host:port used only when `BACKEND_USE_SERVER==0` | [backend_config.h:43-45](../../Smart-Tutor-Lamp/tutor_lamp/backend_config.h) |
| `BACKEND_SERVER_HOST` | `"lumi-smart-lamp.onrender.com"` | Public host (no scheme/port/slash) used only when `==1`. As of `c699e72` the `#define`/`// #define` pair was flipped back to this host, with `"smart-tutor-lamp.onrender.com"` now the commented-out alternate | [backend_config.h:59-61](../../Smart-Tutor-Lamp/tutor_lamp/backend_config.h) |
| `NET_WS_URL` | derived | `wss://HOST/lamp/ws` (server) or `ws://HOST:PORT/lamp/ws` (local) | [backend_config.h:69-85](../../Smart-Tutor-Lamp/tutor_lamp/backend_config.h) |
| `PROVISIONING_BACKEND_URL` | derived | `https://HOST` or `http://HOST:PORT` | [backend_config.h:74-84](../../Smart-Tutor-Lamp/tutor_lamp/backend_config.h) |

**Precedence:** a `-DNET_WS_URL=...` / `-DPROVISIONING_BACKEND_URL=...` build flag wins over everything (the `#ifndef` guards leave it untouched); otherwise the LOCAL/SERVER blocks apply ([backend_config.h:14-18](../../Smart-Tutor-Lamp/tutor_lamp/backend_config.h)). The **"coherence rule"**: this switch must agree with the frontend `NEXT_PUBLIC_BACKEND_URL`, the backend `FRONTEND_BASE_URL`, and the `DEVICE_JWT_SECRET` must match between the signer and verifier, or pairing/WS auth silently fails ([backend_config.h:26-31](../../Smart-Tutor-Lamp/tutor_lamp/backend_config.h)).

**Render cold-start note:** Render's free tier sleeps after ~15 min idle; the first connect after a pause takes ~30–60 s, during which the lamp simply retries via its reconnect backoff ([backend_config.h:55-58](../../Smart-Tutor-Lamp/tutor_lamp/backend_config.h)).

**TLS:** in server mode the socket is `wss://`; `NET_WS_TLS_INSECURE` (default 1) calls `setInsecure()` to skip cert validation — "fine to ship for now; the JWT/device-secret are the actual auth" ([backend_config.h:87-95](../../Smart-Tutor-Lamp/tutor_lamp/backend_config.h), [net_ws.h:32-35](../../Smart-Tutor-Lamp/tutor_lamp/net_ws.h)).

### 4.2 `.ino` compile-time toggles

| Macro | Value | Meaning | Source |
|---|---|---|---|
| `ENABLE_AUTH` | `1` | `1` = full pairing flow (`provisioning::ensure_paired()` runs, QR on first boot); `0` = bypass, hand a placeholder JWT | [tutor_lamp.ino:165](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L165) |
| `DEV_PLACEHOLDER_JWT` | `"dev-mode-no-auth"` | Bearer used when `ENABLE_AUTH=0`; backend `_authenticate_dev` accepts it | [tutor_lamp.ino:166](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L166) |
| `WIFI_SSID` / `WIFI_PASSWORD` | `"ACT_4g"` / `"Samiul2004"` | Hardcoded dev creds (priority 2); set SSID to `""` to force the keyboard path | [tutor_lamp.ino:183-184](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L183) |
| `MIC_WIRE_ADPCM` | `1` | Uplink mic codec: 1 = send IMA-ADPCM `AUDIO_CHUNK_ADPCM` (0x06, 8 KB/s); 0 = raw PCM (0x02, 32 KB/s). Backend MUST support 0x06 first | [tutor_lamp.ino:363-365](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L363) |
| `USE_OPUS_DECODER` | `0` in-`.ino` fallback, `1` in `backend_config.h` | Enable Opus TTS decode (`AUDIO_OUT_OPUS` 0x13, ~4 KB/s vs 12 KB/s ADPCM); needs the `arduino-libopus` library + backend `TTS_WIRE_CODEC=opus`. Decoder state (`OpusDecoder`) is `ps_malloc`'d in PSRAM; a build without it warns once/turn and drops 0x13 frames | [tutor_lamp.ino:73-119](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L73), [backend_config.h:36-53](../../Smart-Tutor-Lamp/tutor_lamp/backend_config.h) |
| `FIRMWARE_VERSION` | `4` | OTA release counter (`ota.h`); the backend must report a version **greater** than this for the lamp to pull an update. Bump monotonically on every release (bumped `1`→`4` in `c699e72`) | [ota.h:26-29](../../Smart-Tutor-Lamp/tutor_lamp/ota.h) |
| `RGB_LED_PIN` | `48` | WS2812B pin | [tutor_lamp.ino:225](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L225) |

### 4.3 Recording / EOS constants (the timing core of the state machine)

| Constant | Value | Effect | Source |
|---|---|---|---|
| `CMD_DURATION_MS` | `30000` | Hard cap on a recording (needs PSRAM at 30 s) | [tutor_lamp.ino:187](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L187) |
| `EOS_SILENCE_MS` | `4000` | Post-speech silence that ends recording (raised from 2500 — too aggressive cut mid-question) | [tutor_lamp.ino:188-191](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L188) |
| `CMD_SAMPLE_RATE` | `16000` | Mic/command sample rate (Hz) | [tutor_lamp.ino:192](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L192) |
| `CMD_BUF_SAMPLES` | `30000*16000/1000 = 480000` | `cmd_buf` length in samples (= 960 KB int16) | [tutor_lamp.ino:193](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L193) |
| `EOS_SILENCE_SAMPLES` | `4000*16000/1000 = 64000` | Silence threshold in samples | [tutor_lamp.ino:194](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L194) |
| `EOS_MIN_SPEECH_SAMPLES` | `16000*1 = 16000` | 1 s guard before EOS may fire | [tutor_lamp.ino:195-196](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L195) |
| `EOS_SPEECH_LEAK_FACTOR` | `3` | Speech decays the silence counter 3× faster than it builds (leaky integrator) | [tutor_lamp.ino:206](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L206) |
| `EOS_NEAR_FRACTION` | `1.0/16.0` (≈ −12 dB) | Near-field gate: a frame counts as speech-for-EOS only if within −12 dB of the turn's speech anchor | [tutor_lamp.ino:222](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L222) |
| `PTT_MIN_SAMPLES` | `16000*2/5 = 6400` (0.4 s) | Below this, a push-to-talk release is treated as an accidental tap and discarded (no billable LLM call) | [tutor_lamp.ino:273](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L273) |

### 4.4 UI / turn-lifecycle timers

| Constant | Value | Effect | Source |
|---|---|---|---|
| `IMAGE_PREVIEW_DURATION_MS` | `5000` | How long a captured JPEG preview stays on the TFT | [tutor_lamp.ino:279](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L279) |
| `CAPTURE_FLUSH_MAX_MS` | `1000` | Max time to defer `AUDIO_END` waiting for an in-flight camera grab | [tutor_lamp.ino:296](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L296) |
| `REPLY_DWELL_MS` | `20000` | Originally how long to hold a text/LaTeX reply; now a "reply is held" marker with no expiry | [tutor_lamp.ino:305](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L305), [tutor_lamp.ino:1644](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1644) |
| `THINKING_TIMEOUT_MS` | `45000` | Watchdog: if no reply lands after STATE(thinking)/AUDIO_END within this window, return to idle | [tutor_lamp.ino:314](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L314) |
| `NET_WS_IMAGE_SEND_MAX_MS` | `15000` | Hard wall-clock cap on one image upload; the `.ino` sizes its `AUDIO_END` deferral to this + 1500 ms slack | [net_ws.h:44-46](../../Smart-Tutor-Lamp/tutor_lamp/net_ws.h), [tutor_lamp.ino:1688-1690](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1688) |

---

## 5. Persistent settings (`settings_store`)

`settings_store` is the single source of truth for user-changeable preferences, persisted in NVS namespace **`"lumos_set"`** via Arduino `Preferences`. It is distinct from `provisioning`'s namespace `"lamp"` (which owns identity/pairing data) ([settings_store.h:2-15](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.h)).

### 5.1 Keys, defaults, clamps

| NVS key | Cache var | Default | Range / clamp | Source |
|---|---|---|---|---|
| `vol` | `s_volume` | `70` | 0..100 (`>100 → default` on load, `>100 → 100` on set) | [settings_store.cpp:17](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L17), [§68](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L68), [§100](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L100) |
| `img_max` | `s_img_max` | `1` | 1..`MAX_IMAGES_LIMIT=5` (== backend `MAX_IMAGES_PER_TURN`) | [settings_store.cpp:18](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L18), [settings_store.h:51](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.h) |
| `img_int` | `s_img_int` | `3` s | `CAPTURE_INTERVAL_MIN_S=1`..`MAX_S=8` | [settings_store.cpp:19](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L19), [settings_store.h:52-53](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.h) |
| `wifi_ssid` | `s_wifi_ssid` | `""` | max 32 chars | [settings_store.cpp:11](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L11) |
| `wifi_pass` | `s_wifi_pass` | `""` | max 63 chars (empty = open network) | [settings_store.cpp:12](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L12) |
| `wifi_cfg` | `s_wifi_configured` | `false` | bool mirror of "SSID non-empty" | [settings_store.cpp:13](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L13) |

The clamp helpers `clamp_img_max()` / `clamp_img_int()` are shared by both the load path and the setters so a corrupt/legacy NVS value or an out-of-range UI call can never produce an illegal config ([settings_store.cpp:30-41](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L30)).

### 5.2 `begin()` — load + heal (algorithm)

`begin()` ([settings_store.cpp:47-95](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L47)) is idempotent (`if (s_loaded) return`). It:

1. Opens `"lumos_set"` read-only. If it opens, reads each key with its default; if it does **not** open (fresh chip), opens read-write and writes `DEFAULT_VOLUME` so subsequent reads work ([settings_store.cpp:52-67](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L52)).
2. **Wi-Fi consistency heal:** the stored SSID is the *single source of truth* — `s_wifi_configured = (s_wifi_ssid.length() > 0)`. If the persisted `wifi_cfg` bool disagrees with that (firmware predating `wifi_cfg`, or a torn write), the flag is reconciled to the SSID and rewritten **once**. The heal **only ever corrects the boolean; it never deletes a saved SSID/password** ([settings_store.cpp:70-89](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L70)).

### 5.3 Setters — write-through + immediate apply

- `set_volume(v)` clamps to ≤100, updates the cache, writes through to NVS (`putUChar` returns 1 on success; `end()` is the `nvs_commit` durability point), and **immediately** calls `spk::set_volume(v)` so the user hears the change as they hold L/R, not only after reboot. A failed NVS write logs a WARN but still applies to the speaker ([settings_store.cpp:99-121](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L99)).
- `set_max_images()` / `set_capture_interval_s()` clamp then persist via the shared `persist_uchar()` helper ([settings_store.cpp:127-146](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L127)).
- `set_wifi(ssid, pass)` writes SSID, password, and the `wifi_cfg` flag, and marks configured **only after the creds themselves landed**, so a partial write can't leave the device "configured" pointing at blank creds ([settings_store.cpp:168-191](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L168)).
- `clear_wifi()` ("Forget WiFi") removes the SSID/pass keys and writes `wifi_cfg=false` **explicitly** (not `remove`) so a stale `true` can never be re-read ([settings_store.cpp:193-212](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L193)).

### 5.4 Wi-Fi credential-resolution contract

`is_wifi_configured()` returns `s_wifi_ssid.length() > 0` ([settings_store.cpp:148-156](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L148)) — gating on the SSID itself (not the mirror) makes a desynced flag impossible to act on. This is the load-bearing signal for the boot priority chain (see [§6](#6-wi-fi-provisioning-credential-resolution--connect)). `has_wifi_override()` is a legacy display alias with the same meaning ([settings_store.cpp:158-163](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L158)).

---

## 6. Wi-Fi provisioning (credential resolution + connect)

The boot credential chain is implemented in `resolve_and_connect_wifi()` ([tutor_lamp.ino:1004-1063](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1004)), with priority order (highest first) defined in [settings_store.h:17-30](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.h) and the `WIFI_SSID` comment block ([tutor_lamp.ino:168-184](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L168)):

1. **Configured creds** — if `is_wifi_configured()`, connect to the user-saved SSID/password and keep retrying them forever. STRICT priority — hardcoded creds are never tried while a configuration exists.
2. **Hardcoded dev creds** (`WIFI_SSID`/`WIFI_PASSWORD`) — used only when not configured AND `sizeof(WIFI_SSID) > 1` (i.e. non-empty).
3. **Neither** — first-boot on-screen keyboard collects creds, then `set_wifi()` persists them so every future boot is priority 1.

### Mechanics

- Sets `WiFi.mode(WIFI_STA)` once, then **disables modem power-save** with `WiFi.setSleep(false)` ([tutor_lamp.ino:1007-1014](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1007)). Rationale: the default `WIFI_PS_MIN_MODEM` parks the radio between DTIM beacons; over `wss://` a burst (camera JPEG layered on live audio) hits a sleeping radio → dropped packets → the TLS socket is torn down mid-upload. The lamp is mains-powered so the extra draw is acceptable.
- `WIFI_TIMEOUT_MS = 15000` per association attempt ([tutor_lamp.ino:1016](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1016)).
- `wifi_try_connect(ssid, pass, timeout)` ([tutor_lamp.ino:952-968](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L952)) drops any prior association (`WiFi.disconnect(false)`), calls `WiFi.begin()`, and **ticks `tft_ui` at ~30 fps with `delay(15)`** while waiting so the connecting page never freezes and the task watchdog is fed. Returns `true` once `WL_CONNECTED`.
- **Priority-3 loop** ([tutor_lamp.ino:1022-1042](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1022)): prompts with `boot_collect_wifi()` until entered creds *actually associate*; on success persists via `set_wifi()`. WiFi is required, so cancel just re-prompts.
- **Priority 1 & 2** ([tutor_lamp.ino:1044-1062](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1044)): pick the source (configured > hardcoded) then `wifi_try_connect` in a forever-loop (`while (!wifi_try_connect(...))`), ticking the UI between attempts. Returns only once `WL_CONNECTED`.

### First-boot keyboard (`boot_collect_wifi`)

[tutor_lamp.ino:974-1000](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L974). Because the main loop isn't running yet, it drives the buttons itself: sets `tft_ui::set_external_drawing(true)` (text_entry owns every pixel) and `s_wifi_entry_active=true` (routes every button press to `text_entry`). Its `run_field` lambda runs `text_entry::begin()` then polls `buttons::poll()` + `text_entry::tick()` + `delay(10)` until done. It collects SSID (max 32, non-empty required) then password (max 63, may be empty for open networks). The `s_wifi_entry_active` flag is file-scope so the (capture-less) buttons lambda registered in `setup()` and `boot_collect_wifi()` can both see it ([tutor_lamp.ino:231-236](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L231)).

---

## 7. Device pairing / provisioning over HTTPS (`provisioning`)

`provisioning` binds a physical lamp to a user account. It owns NVS namespace **`"lamp"`** with three keys ([provisioning.cpp:19-22](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L19)):

| Key | Type | Meaning |
|---|---|---|
| `device_id` | String | `"lamp-XXXXXX"` from the low 24 bits of the eFuse MAC |
| `device_secret` | 32-byte blob | 32 cryptographically random bytes (`esp_random()`) — kept as a 64-char lowercase hex string in RAM |
| `device_jwt` | String | Backend-minted HS256 bearer token for the WS |

### 7.1 Constants

| Constant | Value | Source |
|---|---|---|
| `DEVICE_SECRET_BYTES` | `32` | [provisioning.cpp:24](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L24) |
| `HTTP_TIMEOUT_MS` | `10000` | [provisioning.cpp:25](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L25) |
| `QR_VERSION` | `7` (up to 154 alphanumeric chars at ECC L) | [provisioning.cpp:26](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L26) |
| `PROVISIONING_POLL_INTERVAL_MS` | `3000` | [provisioning.h:54-56](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.h) |
| `PROVISIONING_TLS_INSECURE` | `1` (dev) | [provisioning.h:49-51](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.h) |

### 7.2 `ensure_paired()` — the full flow ([provisioning.cpp:276-373](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L276))

Preconditions: WiFi is `WL_CONNECTED` (else returns `false`), and `tft_ui::begin()` has run. Behaviour:

1. **Guard:** if `WiFi.status() != WL_CONNECTED`, log + return `false` ([provisioning.cpp:279-282](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L279)).
2. **`load_or_generate_credentials()`** ([provisioning.cpp:113-123](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L113)): `nvs_load_all()` reads device_id, jwt, and the 32-byte secret; success requires `device_id` non-empty AND the secret hex == 64 chars. If absent, `generate_credentials()` mints them:
   - `device_id`: `snprintf("lamp-%06X", mac & 0xFFFFFF)` from `ESP.getEfuseMac()` ([provisioning.cpp:94-100](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L94)).
   - `device_secret`: 32 bytes, each `esp_random() & 0xFF`, then hex-encoded via `to_hex()` ([provisioning.cpp:102-106](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L102)). (Note `to_hex` deliberately avoids the name `HEX` because Arduino's `Print.h` `#define HEX 16` would textually replace it — [provisioning.cpp:36-37](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L36).)
   - Persists via `nvs_save_credentials()` (`putString` + `putBytes`) ([provisioning.cpp:74-82](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L74)).
3. **Fast path:** if `device_jwt` is already in NVS (length > 0), log a summary and return `true` immediately — no QR ([provisioning.cpp:286-290](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L286)).
4. **Pairing loop** ([provisioning.cpp:309-372](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L309)) — an *auto-refreshing* `for(;;)`:
   - Shows `PAGE_PAIRING` first so a slow/failed `/register` reads as a server issue, not a WiFi hang.
   - `do_register()` POSTs `{device_id, device_secret}` to `/api/device/register` and parses the response ([provisioning.cpp:191-226](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L191)). Returns one of:
     - **`REG_ALREADY_PAIRED`** — backend re-minted the token (we lost it). Save the recovered JWT via `nvs_save_jwt()` and return `true` — never strand on the QR screen ([provisioning.cpp:322-335](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L322)).
     - **`REG_PENDING`** — response carried `pairing_code` + `pairing_url` + `expires_in`. Render the QR via `tft_ui::set_qr_pairing(url, human)` where `human` formats `ABC123 → "ABC-123"` ([provisioning.cpp:259-267](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L259), [§341-346](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L341)).
     - **`REG_FAIL`** — transient; back off `delay(5000)` and retry; the `PAGE_PAIRING` stays up ([provisioning.cpp:315-320](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L315)).
   - **Poll loop:** while `millis() < deadline` (`ttl_s * 1000`), tick the UI, `delay(PROVISIONING_POLL_INTERVAL_MS=3000)`, then `do_poll()` POSTs `{device_id, device_secret, pairing_code}` to `/api/device/poll-pairing` ([provisioning.cpp:232-255](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L232), [§348-367](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L348)). Status mapping: `pending`→keep polling, `expired`→break (re-register), `paired`→`nvs_save_jwt()` + return `true`. `POLL_ERROR` (transient WiFi blip) also keeps polling.
   - On TTL elapse, the loop re-registers for a **fresh code + QR** — the lamp never dead-ends on an unscanned code. **Only a true NVS-write failure returns `false`** (genuinely unrecoverable).

### 7.3 HTTP helper

`http_post_json()` ([provisioning.cpp:128-176](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L128)) uses `WiFiClientSecure` (with `setInsecure()` when `PROVISIONING_TLS_INSECURE`), `HTTPClient` with `setTimeout(10000)`, sets `Content-Type: application/json`, POSTs the serialized JSON, and parses the response with ArduinoJson. It returns `true` only on a 2xx status with parseable JSON; otherwise logs the status/error and returns `false`. The `do_register` response buffer is `StaticJsonDocument<1280>` and `do_poll`'s is `<2048>` because the `device_jwt` is the largest possible field ([provisioning.cpp:198](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L198), [§239](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L239)).

### 7.4 Recovery helpers

- `clear_jwt()` removes only `device_jwt` (keeps id + secret) — same lamp, new user binding. Wired to STATE(0x05 unpaired) and the auth-giveup callback ([provisioning.cpp:378-386](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L378)).
- `factory_reset()` calls `Preferences::clear()` on `"lamp"` and zeros all RAM copies — fresh creds on the next `ensure_paired()` ([provisioning.cpp:388-399](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L388)).

> The matching endpoints/JWT claims live on the backend (`app/routes/device_lamp.py`, `app/services/device_jwt.py`); see [IMPLEMENTATION_AUTH_PAIRING.md §6](../../Smart-Tutor-Lamp/IMPLEMENTATION_AUTH_PAIRING.md). The lamp **never** talks to Clerk — Clerk is human identity on the frontend only ([IMPLEMENTATION_AUTH_PAIRING.md:30-58](../../Smart-Tutor-Lamp/IMPLEMENTATION_AUTH_PAIRING.md)).

---

## 8. Boot / `setup()` sequence, step by step

`setup()` ([tutor_lamp.ino:1148-1431](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1148)) brings up subsystems in a deliberate order. Inputs at each stage flow into the next.

1. **Serial + LED off** — `Serial.begin(115200)`, wait for Serial, `neopixelWrite(RGB_LED_PIN, 0,0,0)` ([tutor_lamp.ino:1149-1153](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1149)).
2. **TFT first** so the user sees a splash immediately: `tft_ui::begin()`, `set_page(PAGE_BOOT)`, `tick()` ([tutor_lamp.ino:1156-1158](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1156)). `tft_ui::begin()` also allocates the shared latex/image PSRAM cache.
3. **Buttons + the single big event lambda** — `buttons::begin()` then `buttons::on_event(...)` (analysed in [§9.5](#95-button-handling)) ([tutor_lamp.ino:1169-1249](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1169)).
4. **PSRAM `cmd_buf`** — `ps_malloc(CMD_BUF_SAMPLES * 2) = 960 KB`. On failure the lamp shows `PAGE_ERROR` and **halts in an infinite red-blink loop** (still ticking the TFT) ([tutor_lamp.ino:1252-1264](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1252)).
5. **Settings store** — `settings_store::begin()` then `spk::set_volume(settings_store::volume())`. **Must precede WiFi** so the saved override is visible to the connect attempt ([tutor_lamp.ino:1272-1277](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1272)).
6. **WiFi** — `resolve_and_connect_wifi()` blocks until associated, then reads `WiFi.RSSI()` and sets the top-bar signal glyph (`>-65` STRONG, `>-75` OK, else WEAK) ([tutor_lamp.ino:1285-1290](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1285)).
7. **Pairing (gated by `ENABLE_AUTH`)**:
   - `#if ENABLE_AUTH`: `provisioning::ensure_paired()`. On failure → `PAGE_ERROR` + infinite red blink. On success, `ws_jwt = provisioning::device_jwt()` ([tutor_lamp.ino:1293-1311](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1293)).
   - `#else`: `ws_jwt = DEV_PLACEHOLDER_JWT` ("dev-mode-no-auth"); no QR ([tutor_lamp.ino:1312-1319](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1312)).
8. **Auth diagnostics** — prints `ENABLE_AUTH`, `NET_WS_URL`, `PROVISIONING_BACKEND_URL`, device_id, and the full JWT to serial for debugging (your own token on your own serial) ([tutor_lamp.ino:1329-1335](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1329)).
9. **Greeting** — `PAGE_GREETING` animated ~1 s (30 × `tick()` + `delay(33)`) ([tutor_lamp.ino:1338-1342](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1338)).
10. **OTA self-update check** (new in `e1de15a`) — `ota::check_boot()` runs here **deliberately after WiFi but before `net::begin()`** ([tutor_lamp.ino:1516](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1516)). At this exact instant no turn / camera / audio / TTS / TFT stream / upload is in flight and the WSS TLS heap is not yet allocated, so an update cannot disturb the runtime and the OTA TLS is the only large allocation. It fast-probes `…/lamp/ota/version`; only when a newer `FIRMWARE_VERSION` is published does it stream-flash the spare OTA partition and reboot — otherwise it returns immediately and boot continues. Guarded by a free-heap floor and a short probe timeout so an asleep backend never freezes boot. See [03 §3.13](03-networking-camera-buttons.md#313-ota-firmware-self-update-ota).
11. **WebSocket** — `net::begin(NET_WS_URL, ws_jwt)` (allocates TX queue + assemble buffer, does NOT open the socket). Registers callbacks: `on_frame(handle_server_frame)`, `on_state(on_net_state)`, `set_image_send_hook([]{ tft_ui::tick(); })` (keeps the TFT alive during a blocking image upload), and `on_auth_giveup(...)` → `clear_jwt()` + `ESP.restart()`. Then `net::connect()` ([tutor_lamp.ino:1345-1376](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1345)).
12. **Wake word + DSP** — `wake::begin()` (allocates EI buffers; failure returns from setup), `audio_post_process_reset()` ([tutor_lamp.ino:1379-1383](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1379)).
13. **Mic** — register `set_on_raw_frame(on_raw_frame)` (→ wake) and `set_on_cleaned_frame(on_cleaned_frame)` (→ recorder), then `mic::begin(wake::sample_rate())` and `mic::start_task()`. The raw hook is wired *before* `start_task()` so the wake word sees the training-identical signal from frame 0 ([tutor_lamp.ino:1386-1395](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1386)).
14. **Speaker** — `spk::begin()` **after the mic** (the mic owns the I2S bus at boot; the speaker steals it only on first `AUDIO_OUT`). Just allocates the ring + spawns the playback task ([tutor_lamp.ino:1397-1404](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1397)).
15. **Camera** — installs a busy hook (`tft_ui::tick()`) so the boot greeting keeps animating during `cam::begin()`'s ~1.5 s blocking AF lock, then `cam::begin()` (**non-fatal** on failure — the lamp runs audio-only), then *clears* the hook so no later camera call on core 0 can repaint the UI ([tutor_lamp.ino:1417-1422](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1417)).
16. **Ready** — green blink ~350 ms (11 × `tick()` + `delay(33)`), LED off, `set_page(PAGE_IDLE)`, log "Listening for wake word..." ([tutor_lamp.ino:1426-1430](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1426)).

---

## 9. The device state machine and `loop()`

### 9.1 The three modes

```c
typedef enum { MODE_IDLE, MODE_COMMAND, MODE_SENDING } pipeline_mode_t;
static volatile pipeline_mode_t pipeline_mode = MODE_IDLE;
```
([tutor_lamp.ino:228-229](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L228))

| Mode | What happens | Exit condition |
|---|---|---|
| `MODE_IDLE` | `wake::tick()` runs the EI classifier per ready slice; LED cyan-breathing | wake event OR UP push-to-talk → `MODE_COMMAND` |
| `MODE_COMMAND` | capture task streams cleaned PCM as `AUDIO_CHUNK[_ADPCM]` + fills `cmd_buf`; camera captures; LED red-breathing | VAD silence-EOS ≥ 4 s (non-PTT), 30 s hard cap, PTT release, or SELECT cancel → `MODE_SENDING`/`MODE_IDLE` |
| `MODE_SENDING` | `loop()` flushes in-flight images, optionally resends the full utterance, sends `AUDIO_END`, resets, returns to idle; LED orange strobe | always → `MODE_IDLE` |

`pipeline_mode` is `volatile` because it is written by `loop()` (core 1) and read by the capture task (core 1, higher prio). The capture task begins recording the instant the mode flips to `MODE_COMMAND` ([tutor_lamp.ino:1096-1109](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1096)).

### 9.2 `loop()` overview ([tutor_lamp.ino:1433-1815](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1433))

Each iteration runs, in order:

1. `led_update()` — LED animation by mode ([§12](#12-the-rgb-status-led-state-machine)).
2. `net::loop()` — pump the WS: RX dispatch (calls `handle_server_frame`), TX drain, heartbeat, reconnect timer.
3. `buttons::poll()` — dispatches edge events to the lambda.
4. **PTT release check** ([tutor_lamp.ino:1445-1464](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1445)): if `s_ptt_active` and the UP button is no longer held, end the turn. If `cmd_buf_pos >= PTT_MIN_SAMPLES` → `MODE_SENDING`; else discard (send `CANCEL`, abort image, back to idle).
5. **Top-bar sync** — `set_recording(mode==COMMAND)`, `set_audio_out(spk::is_playing())`.
6. **Settings short-circuit** ([tutor_lamp.ino:1482-1499](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1482)): while the menu is open, `tft_settings::tick()` and `return` (wake-word + camera processing suppressed). On menu close, hand the screen back to `tft_ui`, `set_page(PAGE_IDLE)`, force redraw.
7. `tft_ui::tick()` — repaint (self-rate-limits to 33 ms).
8. **Async camera result poll** ([§9.3](#93-camera-poll-and-multi-image-capture)).
9. **Multi-image scheduler + countdown bar**.
10. **Image preview auto-expiry** ([tutor_lamp.ino:1621-1631](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1621)).
11. **THINKING watchdog** ([tutor_lamp.ino:1651-1664](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1651)).
12. **Graph interactivity (new in `e1de15a`)** ([tutor_lamp.ino:1616-1636](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1616)): on `PAGE_GRAPH`, when a deferred pan is pending and all buttons are released, `tft_ui::graph_commit_pan()`; then if `tft_ui::take_graph_view_request(...)` returns a new `[x0,x1,y0,y1]` window it is sent as `FRAME_GRAPH_VIEW` (16 B) so the backend re-renders the cached formula over the new range and ships a fresh `TFT_GRAPH_JPEG`. The lamp itself does no math — pan/zoom is a server round-trip.
13. **Mode dispatch:** `MODE_SENDING` ([§9.4](#94-mode_sending-flush-resend-audio_end)), `MODE_COMMAND` (just `return` — capture task is busy), or `MODE_IDLE` → `if (wake::tick()) begin_command_turn("hey lumos")`.

### 9.3 Camera poll and multi-image capture

The async camera path keeps `loop()` non-blocking. A capture runs on the core-0 worker; `loop()` polls `cam::get_state()`:

- **Completion of an in-flight send** ([tutor_lamp.ino:1514-1537](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1514)): when `s_cam_tx_buf != nullptr && !net::image_send_active()`, `ack_image_send()`, then **one automatic retry** if it `IMG_FAILED` and `s_img_send_tries < 2` and still connected and not idle; otherwise `cam::release()` the frame buffer and `cam_schedule_next_shot()`. The fb release is **deferred** until the async send leaves `IMG_SENDING` because the pump reads the JPEG bytes in place (no copy) ([tutor_lamp.ino:253-260](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L253)).
- **A finished grab** (`GRAB_READY`) ([tutor_lamp.ino:1539-1574](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1539)): `cam::get_result()` returns the JPEG. **Safety net:** if `pipeline_mode == MODE_IDLE` (turn already ended), discard the image so it isn't mis-attributed to the next turn. Otherwise paint a local preview (`on_image_jpeg`, forced tick), set `s_image_preview_until_ms`, and `net::begin_image_send()` (async). If the send won't start, release + schedule next.
- **`GRAB_FAILED`** ([tutor_lamp.ino:1575-1579](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1575)): release + schedule next (audio-only turn).

**Multi-image scheduler** ([tutor_lamp.ino:1586-1613](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1586)): if the turn ended, clear `s_next_capture_ms` + countdown. Otherwise, when the timer elapses and `s_turn_images_taken < s_turn_max_images`, fire `cam::grab_async()`; a busy camera retries in 150 ms (a shot is never silently dropped). The reverse countdown bar (`set_capture_countdown`) shows `pct = rem*100/interval` and `secs = ceil(rem/1000)`. `cam_schedule_next_shot()` ([tutor_lamp.ino:1078-1089](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1078)) schedules the next shot only while still in `MODE_COMMAND` and under the cap.

Per-turn capture settings are snapshotted in `begin_command_turn()` so changing a setting mid-turn can't corrupt the in-flight sequence ([tutor_lamp.ino:281-296](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L281), [§1112-1124](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1112)).

### 9.4 `MODE_SENDING`: flush, resend, AUDIO_END

This block ([tutor_lamp.ino:1666-1801](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1666)) is the single most intricate part of the turn lifecycle:

1. **Defer `AUDIO_END` while a capture/upload is in flight** ([tutor_lamp.ino:1684-1698](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1684)): the backend snapshots a turn's images and resets on `AUDIO_END`, so an image landing after it would orphan into the next turn. While `cam::get_state()==GRAB_BUSY` or `net::image_send_active()`, `return` (retry next loop) up to a cap: `NET_WS_IMAGE_SEND_MAX_MS + 1500` for an upload, else `CAPTURE_FLUSH_MAX_MS=1000`. On timeout, `net::abort_image_send()` and proceed audio-only.
2. **Full resend on uplink loss** (`#if MIC_WIRE_ADPCM`) ([tutor_lamp.ino:1706-1753](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1706)): `cmd_buf` holds the *entire* utterance locally. If `net::tx_drop_count() - s_turn_tx_drops_base > 0` (any drop this turn) and connected, send `FRAME_AUDIO_RESET` (tells the backend to discard the streamed copy + decoder state), `adpcm::enc_reset()`, then re-encode and re-send `cmd_buf` in ≤512-sample (even count) chunks as `AUDIO_CHUNK_ADPCM`, pumping `net::loop()` whenever the TX queue is full. Bounded by a **20 s** budget; aborts if the link drops.
3. **`AUDIO_END` is NOT fire-and-forget** ([tutor_lamp.ino:1754-1774](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1754)): after a queue-saturating resend the TX queue is often still full and a single send would be dropped silently (the backend then never starts the turn). It retries `send_frame(FRAME_AUDIO_END)` while pumping the drain, giving up after **10 s** on a dead link (the THINKING watchdog still recovers the UI).
4. **Transition** ([tutor_lamp.ino:1775-1800](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1775)): `set_page(PAGE_THINKING)`, arm the watchdog (`s_thinking_until_ms = millis() + 45000`) — armed here too because if `AUDIO_END` is lost the backend never sends STATE(thinking). Then reset `cmd_buf_pos = 0`, `silence_samples = 0`, `pipeline_mode = MODE_IDLE`. It deliberately does **not** reset the DSP here (cross-task race — see [§3](#3-module-map-and-threading-model)).

### 9.5 Button handling

The `on_event` lambda ([tutor_lamp.ino:1170-1249](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1170)) prioritizes input owners:

1. **First-boot keyboard** (`s_wifi_entry_active`) → `text_entry::on_button(b)` and return.
2. **Settings open** (`tft_settings::is_active()`) → `tft_settings::on_button(b)` and return.
3. **`BTN_SELECT_LONG`** (centre held ≥ `BUTTONS_LONG_PRESS_MS=1500`) → only from `MODE_IDLE` & not playing → `tft_settings::open()`.
4. **`BTN_UP`** = push-to-talk, but **only on `PAGE_IDLE`**: `begin_command_turn("UP button")` + `s_ptt_active=true` (hold-to-talk; release ends it). On any other page UP routes to `tft_ui::on_button`.
5. `BTN_DOWN/LEFT/RIGHT/SELECT` → `tft_ui::on_button(...)`.
6. **`BTN_SELECT` during an active turn or playback acts as CANCEL** ([tutor_lamp.ino:1231-1248](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1231)): sends `FRAME_CANCEL`, `net::abort_image_send()`, `spk::stop()` if playing, resets to `MODE_IDLE` + `PAGE_IDLE`.
7. **Directional long-presses (new in `e1de15a`)** — `buttons` now emits `BTN_DOWN_LONG`/`BTN_UP_LONG`/`BTN_LEFT_LONG` (any long-capable button held ≥ `BUTTONS_LONG_PRESS_MS`, generalised from the old SELECT-only long-press). The `.ino` translates these into `tft_ui`'s own `BTN_DOWN_LONG`/`UP_LONG`/`LEFT_LONG` for the graph page: DOWN-long zoom out / opens the graph, UP-long zoom in, LEFT-long toggles equation⇄graph ([tutor_lamp.ino:1381-1389](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1381)).

Button decode (resistor ladder on GPIO 2) thresholds: LEFT `<200`, SELECT `<600`, DOWN `<1100`, RIGHT `<1700`, UP `<2800`, none `>2800` ([buttons.h:8-13](../../Smart-Tutor-Lamp/tutor_lamp/buttons.h)). Edge-detected, ~50 ms debounce; `held()` reports the currently-held button for hold-to-talk ([buttons.h:66-71](../../Smart-Tutor-Lamp/tutor_lamp/buttons.h)).

### 9.6 `begin_command_turn()` ([tutor_lamp.ino:1091-1142](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1091))

Shared by the wake word and the UP push-to-talk so both are byte-for-byte identical. It:
1. Flips the LED flash (200 ms white), zeros `cmd_buf_pos`, `silence_samples`, `s_cmd_speech_ref` (fresh near-field anchor), `adpcm::enc_reset()` (fresh uplink stream, paired with the backend's per-turn decoder), captures `s_turn_tx_drops_base`, clears the reply-dwell + thinking watchdog, then sets `pipeline_mode = MODE_COMMAND` and `set_page(PAGE_LISTENING)`.
2. Snapshots multi-image settings (`s_turn_max_images`, `s_capture_interval_ms`) and arms the countdown overlay.
3. **Fires camera shot 1/N asynchronously** via `cam::grab_async()` (if `cam::is_ready()`); the mic keeps recording on core 1. A not-ready/refused camera is non-fatal (audio-only).

---

## 10. Capture-task hooks and the EOS algorithm

### 10.1 `on_raw_frame()` ([tutor_lamp.ino:354-357](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L354))

`IRAM_ATTR`. Forwards the training-identical signal to `wake::feed_frame()` (step 2 in the strict order). Nothing else.

### 10.2 `on_cleaned_frame()` ([tutor_lamp.ino:367-484](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L367))

`IRAM_ATTR`, runs in the capture task during `MODE_COMMAND` only. Inputs: the post-NS/ALE/AGC cleaned PCM frame. Stages:

1. **Stream to backend** ([tutor_lamp.ino:371-384](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L371)): if `MIC_WIRE_ADPCM`, encode 4:1 with `adpcm::encode()` into `s_adpcm_tx[1024]` (512 samples → 256 B) and `net::send_frame(FRAME_AUDIO_CHUNK_ADPCM, ...)` — this quadruples the effective TX-queue depth (~5 s of audio in 40 slots) so brief link stalls stop dropping speech. Otherwise send raw PCM (`FRAME_AUDIO_CHUNK`).
2. **Mirror into `cmd_buf`** ([tutor_lamp.ino:386-389](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L386)): up to `CMD_BUF_SAMPLES` — the local diagnostic copy used for the full resend.
3. **Drive the waveform** ([tutor_lamp.ino:391-404](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L391)): compute `frame_rms = sqrtf(Σx²/n)` and feed `tft_ui::set_listening_level(rms/8000)` (typical speech 1500–6000).
4. **EOS — leaky integrator + near-field gate** ([tutor_lamp.ino:406-484](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L406)), the core algorithm:

#### The EOS algorithm, mechanically

- A 1 s guard: EOS logic only runs once `cmd_buf_pos >= EOS_MIN_SPEECH_SAMPLES (16000)`.
- **Near-field anchor** (`s_cmd_speech_ref`): each *energy-voted* frame's energy peak-holds the anchor:
  `if (eos_evote && eos_esig > s_cmd_speech_ref) s_cmd_speech_ref = eos_esig;` where `eos_esig = vad_frame_energy()` (post-AGC mean-square / rms²) and `eos_evote = (vad_feature_votes() & 0x01)` (bit0 = the energy feature) ([tutor_lamp.ino:413-415](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L413)).
- A frame is **near-field** if `(s_cmd_speech_ref <= 0)` (unseeded → legacy behaviour) OR it energy-voted OR `eos_esig >= s_cmd_speech_ref * EOS_NEAR_FRACTION` (i.e. within −12 dB of the anchor) ([tutor_lamp.ino:426-429](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L426)).
- A frame keeps the turn alive only when `vad_is_speech() && near_field`. If so, the silence counter **leaks** (decays) by `n * EOS_SPEECH_LEAK_FACTOR (3)`: `silence_samples = (silence_samples > leak) ? silence_samples - leak : 0`. Otherwise it **builds**: `silence_samples += n` ([tutor_lamp.ino:430-435](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L430)).
  - *Why leaky, not hard-reset:* the old `speech → silence=0` let one loud background blip (a thump, a fan cycle at rms 2000–4000) erase seconds of accumulated silence, so in a noisy room EOS never fired and recording ran the full 30 s. With the 3× leak, *sustained* real speech still drives the counter to 0 (no premature cut), but isolated/periodic noise can no longer prevent EOS ([tutor_lamp.ino:197-206](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L197)).
  - *Why near-field:* the VAD measures "speech-LIKE", not "CLOSE" — a TV/neighbour (which IS speech) used to keep resetting the counter. The anchor gives a guaranteed near-field reference from the user's first words; distant bleed (typically 20–30 dB down) now *accumulates* silence ([tutor_lamp.ino:207-222](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L207)).
- **Diagnostic** ~2 Hz: prints `t / rms / vad / near / aref / hang / votes / sil / EOS / vnf / nf` so you can see exactly why EOS fires or fails ([tutor_lamp.ino:438-474](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L438)).
- **Transition** ([tutor_lamp.ino:476-483](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L476)): `if ((!s_ptt_active && silence_samples >= EOS_SILENCE_SAMPLES) || cmd_buf_pos >= CMD_BUF_SAMPLES) { silence_samples = 0; pipeline_mode = MODE_SENDING; }`. Push-to-talk **suppresses** VAD-EOS (only UP release stops it); the 30 s hard cap always applies.

The VAD itself (in `vad_stage`) is a **3-feature majority vote** (energy ratio, ZCR window, spectral-flatness proxy) with a `VAD_HANGOVER_FRAMES=8` counter; 2-of-3 declares speech ([vad_stage.h:1-22](../../Smart-Tutor-Lamp/tutor_lamp/vad_stage.h)). Key parameters: `VAD_ENERGY_THRESH=1.5`, `VAD_ENERGY_ABS_MIN=4.0e6` (dual relative+absolute gate), `VAD_ZCR_LOW/HIGH=10/80`, `VAD_SFM_THRESH=0.6`, with a self-tracked noise floor (`VAD_NF_DOWN=0.30`, `VAD_NF_UP=0.006`) ([vad_stage.h:37-86](../../Smart-Tutor-Lamp/tutor_lamp/vad_stage.h)). The `.ino` consumes `vad_is_speech()`, `vad_feature_votes()`, and `vad_frame_energy()` for the near-field EOS.

---

## 11. Inbound WebSocket frame handling

`handle_server_frame(type, payload, len)` ([tutor_lamp.ino:496-865](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L496)) runs in the `loop()` thread (dispatched by `net::loop()`). The wire protocol is `[u8 type][u24 length BE][payload]`, one application frame per WS binary message ([net_ws.h:4-6](../../Smart-Tutor-Lamp/tutor_lamp/net_ws.h), [HARDWARE_CONTEXT.md:134-142](../../Smart-Tutor-Lamp/HARDWARE_CONTEXT.md)).

**Liveness re-arm:** at the top, if the THINKING watchdog is armed, *any* server frame proves the backend is alive, so it re-arms `s_thinking_until_ms = millis() + THINKING_TIMEOUT_MS`. This stops a legitimately slow turn (tier-2 escalation + Gemini 503 retries can exceed 45 s) from flashing the lost-turn card moments before the real answer ([tutor_lamp.ino:497-509](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L497)).

| Frame (value) | Handler behaviour | Source |
|---|---|---|
| `AUDIO_OUT` (0x10) | `spk::push_pcm()` into the ring; `set_speaking_active(true)`; logs first 3 + every 20th chunk | [tutor_lamp.ino:511-526](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L511) |
| `AUDIO_OUT_ADPCM` (0x12) | `adpcm::decode()` (1 KB→2048 samples) → `push_pcm`; drops oversize >1 KB | [tutor_lamp.ino:527-551](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L527) |
| `AUDIO_OUT_OPUS` (0x13) | decode if `USE_OPUS_DECODER`; else warn once + drop | [tutor_lamp.ino:552-570](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L552) |
| `AUDIO_OUT_END` (0x11) | `spk::mark_end()`, `adpcm::reset()`, `set_speaking_active(false)`, reset chunk counter | [tutor_lamp.ino:571-583](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L571) |
| `TFT_PART` (0x23) | append to the shared `tft_ui` latex PSRAM buffer at `s_chunked_tft_len`; overflow → discard rest of stream | [tutor_lamp.ino:607-642](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L607) |
| `TFT_IMAGE_PART` (0x28) | chunk of a compressed equation/graph/chem JPEG → append into `tft_ui::get_eq_jpeg_buffer()` (reuses the camera-preview buffer) | [tutor_lamp.ino:643](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L643) |
| `TFT_IMAGE_JPEG` (0x27) | terminator of a JPEG-compressed equation (`[u16 W][u16 H][grayscale JPEG]`) → `tft_ui::on_tft_image_jpeg()` decodes via `TJpg_Decoder` straight into `s_latex` (~3–15 KB vs ~70 KB raw) | [tutor_lamp.ino:662](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L662) |
| `TFT_GRAPH_JPEG` (0x29) | terminator of a chunked graph (`[f32 x0,x1,y0,y1][color JPEG]`) → `on_tft_graph_jpeg()`; stores JPEG + window, arms `PAGE_GRAPH` | [tutor_lamp.ino:686](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L686) |
| `TFT_CHEM_JPEG` (0x2A) | terminator of a chemistry-structure step (`[u8 idx][u8 count][color JPEG]`, up to 4 steps cached) → `on_tft_chem_jpeg()`; arms `PAGE_CHEM` | [tutor_lamp.ino:710](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L710) |
| `TFT_FRAME` (0x20) | terminator: if accumulator non-empty, `commit_chunked_latex()` → `PAGE_SPEAKING_LATEX` + log `[latex-rx]` timing; else single-shot `on_tft_frame()` | [tutor_lamp.ino:620-669](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L620) |
| `TFT_TEXT` (0x21) | `on_tft_text()` (≤200 char plain text) | [tutor_lamp.ino:670-676](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L670) |
| `TFT_CLEAR` (0x22) | reset chunked-TFT pointer + append flags, `on_tft_clear()` (prevents corrupt frame after a mid-stream abort) | [tutor_lamp.ino:677-691](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L677) |
| `TFT_APPEND_BEGIN` (0x26) | arm the accumulator to write *after* the committed pack (`latex_append_base()`); reject (discard) if no committed pack | [tutor_lamp.ino:692-718](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L692) |
| `TFT_APPEND` (0x25) | terminator of an append segment → `commit_append()` (splices new pixels after the pack) | [tutor_lamp.ino:719-767](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L719) |
| `TFT_LATEX_LOADING` (0x24) | `set_latex_loading(true)` — skeleton while ~75 TFT_PARTs stream | [tutor_lamp.ino:768-777](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L768) |
| `STATE` (0x30) | one-byte enum (below) | [tutor_lamp.ino:778-845](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L778) |
| default | log `unknown frame` | [tutor_lamp.ino:846-852](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L846) |

**STATE byte handling** ([tutor_lamp.ino:782-843](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L782)):
- `0x02 thinking`: reset per-turn counters, clear in-flight TFT stream + held reply, `on_tft_clear()`, `set_page(PAGE_THINKING)`, arm the watchdog.
- `0x03 speaking`: `set_speaking_active(true)`.
- `0x00 idle`: `set_speaking_active(false)`; if on a reply page (`PAGE_SPEAKING_TEXT/LATEX`) set `s_reply_dwell_until_ms` (hold the answer); else `set_page(PAGE_IDLE)`. This deferral stops a no-audio reply from being wiped by the idle that arrives in the same `poll()` burst.
- `0x05 unpaired`: `provisioning::clear_jwt()` + `ESP.restart()` — backend revoked our JWT.

At the end, `handle_server_frame` calls `tft_ui::tick()` once per dispatched frame so the UI stays alive even when `loop()` is captive inside `net::loop()` on a slow trickling link ([tutor_lamp.ino:854-864](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L854)).

`on_net_state()` ([tutor_lamp.ino:867-889](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L867)) maps the WS connection state to the top-bar backend glyph: CONNECTED→ONLINE, CONNECTING→CONNECTING, BACKOFF/DISCONNECTED→OFFLINE, FATAL→ERROR + `PAGE_ERROR`.

---

## 12. The RGB status LED state machine

`led_update()` ([tutor_lamp.ino:903-942](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L903)) rate-limits to 30 ms. A white flash overrides everything while `now < s_led_flash_ms` (the wake/turn-start cue). Otherwise it animates by `pipeline_mode`:

- **`MODE_IDLE`** — cyan breathing on a 4000 ms sine: `b = sinf(t·2π)·0.5+0.5`, then `b = 0.03 + b·0.32`; RGB = `(b·18, b·80, b·255)` ([tutor_lamp.ino:917-924](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L917)).
- **`MODE_COMMAND`** — red breathing on a 500 ms sine: `b = 0.07 + b·0.73`; RGB = `(b·255, b·12, 0)` ([tutor_lamp.ino:925-932](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L925)).
- **`MODE_SENDING`** — orange strobe alternating every 120 ms: `(255,80,0)` ↔ `(18,5,0)` ([tutor_lamp.ino:933-940](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L933)).

The backend STATE byte drives a top-bar glyph in `tft_ui` but does **not** override this LED — the two layers co-exist ([tutor_lamp.ino:891-901](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L891)).

---

## 13. Edge cases, timeouts, retries, fallbacks

| Condition | Behaviour | Source |
|---|---|---|
| PSRAM `cmd_buf` alloc fails | `PAGE_ERROR` + infinite red-blink halt | [tutor_lamp.ino:1253-1264](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1253) |
| Pairing fails (`ENABLE_AUTH=1`) | `PAGE_ERROR` + infinite red-blink halt; reboot to retry | [tutor_lamp.ino:1299-1309](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1299) |
| `wake::begin` / `mic::begin` / `spk::begin` / `net::begin` fail | log + `return` from setup (lamp non-functional) | [tutor_lamp.ino:1345-1404](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1345) |
| `cam::begin` fails | non-fatal WARN — audio-only lamp | [tutor_lamp.ino:1418-1421](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1418) |
| WiFi never associates | retry forever (configured/hardcoded) or re-prompt (first-boot) | [tutor_lamp.ino:1024-1062](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1024) |
| WS drops / backend asleep | `net_ws` reconnects with exp backoff 2→30 s; `NET_BACKOFF` shows OFFLINE | [HARDWARE_CONTEXT.md:65](../../Smart-Tutor-Lamp/HARDWARE_CONTEXT.md), [tutor_lamp.ino:878-880](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L878) |
| TX drops during a turn | full ADPCM resend from `cmd_buf` (20 s budget) after `AUDIO_RESET` | [tutor_lamp.ino:1715-1752](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1715) |
| `AUDIO_END` dropped (queue full) | retry while pumping, 10 s give-up; watchdog recovers UI | [tutor_lamp.ino:1762-1774](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1762) |
| Reply never arrives | THINKING watchdog (45 s) → lost-turn card | [tutor_lamp.ino:1651-1664](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1651) |
| Camera grab finishes after turn end | image discarded (would orphan into next turn) | [tutor_lamp.ino:1547-1551](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1547) |
| Image upload fails | one automatic retry; bounded by `NET_WS_IMAGE_SEND_MAX_MS`; else audio-only | [tutor_lamp.ino:1523-1530](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1523) |
| Accidental UP tap (< 0.4 s) | turn discarded, `CANCEL` sent (no billable LLM call) | [tutor_lamp.ino:1454-1462](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1454) |
| TFT_PART overflow / mid-stream abort | discard rest of stream; `TFT_CLEAR` resets offset to avoid corrupt next frame | [tutor_lamp.ino:597-610](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L597), [§677-691](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L677) |
| N empty WS disconnects | `net::on_auth_giveup` (threshold 8) → `clear_jwt()` + reboot (heuristic for close 4401) | [net_ws.h:92-108](../../Smart-Tutor-Lamp/tutor_lamp/net_ws.h), [tutor_lamp.ino:1369-1374](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1369) |
| NVS partial/torn write | clamps + Wi-Fi heal + "mark configured only after creds land" | [settings_store.cpp:70-89](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L70), [§179-182](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L179) |

---

## 14. Integration points

### What this firmware *calls* (cross-references)

- **Backend (WSS `{HOST}/lamp/ws`)** — uplink frames: `AUDIO_CHUNK`/`AUDIO_CHUNK_ADPCM`, `AUDIO_RESET`, `AUDIO_END`, `IMAGE_PART`/`IMAGE_JPEG`, `CANCEL`. Downlink: `AUDIO_OUT[_ADPCM/_OPUS]`, `AUDIO_OUT_END`, `TFT_*`, `STATE`. Full catalog in [net_ws.h:54-74](../../Smart-Tutor-Lamp/tutor_lamp/net_ws.h) and [IMPLEMENTATION_WEBSOCKET.md](../../Smart-Tutor-Lamp/IMPLEMENTATION_WEBSOCKET.md) §4.3. Backend handlers: `app/routes/ws_lamp.py`; dev reference `dummy_backend.py`.
- **Backend (HTTPS pairing)** — `POST /api/device/register`, `POST /api/device/poll-pairing` ([provisioning.cpp](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp); backend `app/routes/device_lamp.py`). Bearer `device_jwt` minted by `app/services/device_jwt.py`.
- **On-device modules** — `wake`, `mic`, `audio_post_process`/`vad`, `spk`, `cam`, `buttons`, `tft_ui`, `tft_settings`, `text_entry`, `adpcm`, `settings_store`, `provisioning`.

### What *calls* this firmware

- **The backend** drives the lamp's UI/audio/LED through downlink frames; the **frontend** (Next.js + Clerk) completes pairing by scanning the QR the lamp renders, calling `POST /api/device/complete-pairing` which writes `devices.user_id` and lets the lamp's next poll receive `status:"paired"` ([IMPLEMENTATION_AUTH_PAIRING.md:296-367](../../Smart-Tutor-Lamp/IMPLEMENTATION_AUTH_PAIRING.md), [PROJECT_CONTEXT.md:79-82](../../Smart-Tutor-Lamp/PROJECT_CONTEXT.md)).
- **The database (Supabase/Postgres + pgvector)** stores `devices`/`pairing_codes` rows that gate pairing, plus `sessions`/`turns`/`user_memory` populated per turn — the lamp itself only stores `device_id`/`secret`/`jwt` + prefs in NVS ([IMPLEMENTATION_AUTH_PAIRING.md:79](../../Smart-Tutor-Lamp/IMPLEMENTATION_AUTH_PAIRING.md), [PROJECT_CONTEXT.md:55-67](../../Smart-Tutor-Lamp/PROJECT_CONTEXT.md)).
- **The web simulator** mirrors the lamp's turn shape over a separate `/simulate` path so the same backend brain + analytics cover both surfaces ([PROJECT_CONTEXT.md:90-114](../../Smart-Tutor-Lamp/PROJECT_CONTEXT.md)).

### Display/audio contracts the backend MUST honour

- TFT is **landscape 320 W × 240 H** (rotation 3) → render LaTeX with `DisplayConfig(orientation=LANDSCAPE)`, RGB565 BGR byte-swapped ([HARDWARE_CONTEXT.md:60](../../Smart-Tutor-Lamp/HARDWARE_CONTEXT.md), [§263](../../Smart-Tutor-Lamp/HARDWARE_CONTEXT.md)).
- TTS is **24 kHz mono int16 LE**, paced **4 KB / 85 ms** (the lamp drains its ring at exactly that rate; faster over-sends and drops) ([HARDWARE_CONTEXT.md:206-212](../../Smart-Tutor-Lamp/HARDWARE_CONTEXT.md)).
- Backend MUST send `AUDIO_OUT_END` (releases I2S to the mic) and `STATE(0x00 idle)` to end a turn ([HARDWARE_CONTEXT.md:323-358](../../Smart-Tutor-Lamp/HARDWARE_CONTEXT.md)).

---

## 15. Mermaid diagrams

### 15.1 Boot → first-idle flowchart

```mermaid
flowchart TD
  A[Power on] --> B[Serial + LED off]
  B --> C[tft_ui::begin → PAGE_BOOT]
  C --> D[buttons::begin + on_event lambda]
  D --> E[ps_malloc cmd_buf 960KB]
  E -->|fail| EX[PAGE_ERROR + halt red blink]
  E -->|ok| F[settings_store::begin + spk volume]
  F --> G[resolve_and_connect_wifi]
  G -->|configured| G1[saved SSID, retry forever]
  G -->|hardcoded| G2[WIFI_SSID, retry forever]
  G -->|neither| G3[on-screen keyboard, persist]
  G1 --> H{ENABLE_AUTH?}
  G2 --> H
  G3 --> H
  H -->|1| I[provisioning::ensure_paired]
  I -->|jwt in NVS| K[use stored jwt]
  I -->|no jwt| J[register → QR → poll 3s → save jwt]
  I -->|fail| EX
  H -->|0| L[ws_jwt = dev-mode-no-auth]
  J --> M[PAGE_GREETING ~1s]
  K --> M
  L --> M
  M --> N[net::begin + callbacks + connect]
  N --> O[wake::begin + DSP reset]
  O --> P[mic::begin + start_task]
  P --> Q[spk::begin]
  Q --> R[cam::begin non-fatal]
  R --> S[PAGE_IDLE — listening]
```

### 15.2 Per-turn sequence (wake → answer)

```mermaid
sequenceDiagram
  participant U as User
  participant CAP as Capture task (core1 p8)
  participant L as loop() (core1)
  participant CAM as Camera (core0)
  participant WS as net_ws
  participant BE as Backend
  participant SPK as Speaker task (core0)

  U->>CAP: "hey lumos"
  CAP->>L: wake::tick() true
  L->>L: begin_command_turn() → MODE_COMMAND, PAGE_LISTENING
  L->>CAM: grab_async() shot 1/N
  loop while MODE_COMMAND
    CAP->>WS: AUDIO_CHUNK_ADPCM (every ~20ms)
    CAP->>CAP: leaky EOS + near-field gate
    CAM-->>L: GRAB_READY → begin_image_send (async)
    L->>WS: IMAGE_PART... IMAGE_JPEG
  end
  CAP->>L: silence ≥ 4s → MODE_SENDING
  L->>L: defer AUDIO_END until image flushed
  alt TX drops occurred
    L->>WS: AUDIO_RESET + full cmd_buf resend
  end
  L->>WS: AUDIO_END (retry-until-queued)
  L->>L: PAGE_THINKING + arm 45s watchdog
  WS->>BE: forward audio + image
  BE-->>WS: STATE(thinking) / TFT_TEXT / TFT_PART... / TFT_FRAME
  BE-->>WS: STATE(speaking) + AUDIO_OUT chunks
  WS->>SPK: push_pcm (steals I2S from mic)
  SPK-->>U: TTS playback
  BE-->>WS: AUDIO_OUT_END + STATE(idle)
  SPK->>L: ring drains → release I2S → mic resumes
  L->>L: hold reply / PAGE_IDLE
```

### 15.3 Pipeline state machine

```mermaid
stateDiagram-v2
  [*] --> MODE_IDLE
  MODE_IDLE --> MODE_COMMAND: wake::tick() OR UP push-to-talk
  MODE_COMMAND --> MODE_SENDING: VAD silence ≥ 4s\nOR 30s hard cap\nOR UP release (≥0.4s)
  MODE_COMMAND --> MODE_IDLE: SELECT cancel\nOR UP tap < 0.4s (discard)
  MODE_SENDING --> MODE_IDLE: AUDIO_END sent\n(reset, PAGE_THINKING)
```

---

## 16. File-by-file / function-by-function breakdown

### 16.1 `board_config.h` ([file](../../Smart-Tutor-Lamp/tutor_lamp/board_config.h))
Single `#define CAMERA_MODEL_ESP32S3_EYE` then `#include "camera_pins.h"`. Selects the camera pin block; PSRAM + ≥3 MB APP partition warnings in comments.

### 16.2 `camera_pins.h` ([file](../../Smart-Tutor-Lamp/tutor_lamp/camera_pins.h))
A large `#if defined(CAMERA_MODEL_*)` ladder mapping every supported board's camera GPIOs. The active `CAMERA_MODEL_ESP32S3_EYE` block ([§297-315](../../Smart-Tutor-Lamp/tutor_lamp/camera_pins.h#L297)) defines XCLK=15, SIOD=4, SIOC=5, Y2..Y9, VSYNC=6, HREF=7, PCLK=13, PWDN/RESET=-1. `#error "Camera model not selected"` if none set.

### 16.3 `backend_config.h` ([file](../../Smart-Tutor-Lamp/tutor_lamp/backend_config.h))
No functions — pure preprocessor. `BACKEND_USE_SERVER` switch derives `NET_WS_URL` + `PROVISIONING_BACKEND_URL` (see [§4.1](#41-backend_configh--single-source-of-truth-for-the-backend-address)).

### 16.4 `settings_store.{h,cpp}` ([h](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.h) / [cpp](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp))
| Function | Role |
|---|---|
| `begin()` | Idempotent NVS load into cache + Wi-Fi consistency heal ([cpp:47](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L47)) |
| `volume()` / `set_volume(v)` | Read cache / clamp ≤100, write-through NVS, immediate `spk::set_volume` ([cpp:97-121](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L97)) |
| `max_images()` / `set_max_images(n)` | Clamp 1..5 + persist ([cpp:124-141](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L124)) |
| `capture_interval_s()` / `set_capture_interval_s(s)` | Clamp 1..8 + persist ([cpp:125-146](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L125)) |
| `is_wifi_configured()` / `has_wifi_override()` | SSID-non-empty test (load-bearing for boot chain) ([cpp:148-163](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L148)) |
| `wifi_ssid()` / `wifi_password()` | Cache reads ([cpp:165-166](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L165)) |
| `set_wifi(ssid,pass)` / `clear_wifi()` | Persist creds + flag / forget creds ([cpp:168-212](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L168)) |
| `clamp_img_max/int`, `persist_uchar` | internal helpers ([cpp:30-41](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L30), [§127](../../Smart-Tutor-Lamp/tutor_lamp/settings_store.cpp#L127)) |

### 16.5 `provisioning.{h,cpp}` ([h](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.h) / [cpp](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp))
| Function | Role |
|---|---|
| `ensure_paired()` | Full pairing flow; returns true once a valid jwt exists ([cpp:276](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L276)) |
| `device_id()` / `device_jwt()` | C-string accessors ([cpp:375-376](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L375)) |
| `clear_jwt()` | Wipe only the jwt (re-pair, keep id/secret) ([cpp:378](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L378)) |
| `factory_reset()` | Wipe all "lamp" NVS keys ([cpp:388](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L388)) |
| internal: `to_hex`, `nvs_load_all`, `nvs_save_credentials`, `nvs_save_jwt`, `generate_credentials`, `load_or_generate_credentials`, `http_post_json`, `do_register`, `do_poll`, `format_human_code` | helpers driving the flow above ([cpp:35-267](../../Smart-Tutor-Lamp/tutor_lamp/provisioning.cpp#L35)) |

### 16.6 `tutor_lamp.ino` ([file](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino))
| Function | Role |
|---|---|
| `opus_rx_*` (cond.) | Lazy PSRAM Opus decoder ([§85-114](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L85)) |
| `on_raw_frame()` | Capture-task hook → `wake::feed_frame` ([§354](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L354)) |
| `on_cleaned_frame()` | Stream PCM/ADPCM + mirror `cmd_buf` + leaky/near-field EOS ([§367](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L367)) |
| `handle_server_frame()` | Inbound WS frame dispatcher ([§496](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L496)) |
| `on_net_state()` | WS connection-state → top-bar glyph ([§867](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L867)) |
| `led_update()` | Mode-driven LED animation ([§903](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L903)) |
| `wifi_try_connect()` | One association attempt with UI-tick timeout ([§952](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L952)) |
| `boot_collect_wifi()` | First-boot keyboard credential entry ([§974](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L974)) |
| `resolve_and_connect_wifi()` | Credential resolution + blocking connect ([§1004](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1004)) |
| `cam_schedule_next_shot()` | Multi-image scheduler ([§1078](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1078)) |
| `begin_command_turn()` | Shared turn-start (wake + PTT) ([§1091](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1091)) |
| `setup()` | Subsystem bring-up ([§1148](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1148)) |
| `loop()` | Orchestrator + state-machine driver ([§1433](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L1433)) |

#### Key global state (file-scope) in `tutor_lamp.ino`
- `pipeline_mode` (volatile) — the state machine ([§229](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L229)).
- `cmd_buf` / `cmd_buf_pos` / `silence_samples` — recording + EOS state ([§239-241](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L239)).
- `s_cmd_speech_ref` — per-turn near-field anchor ([§246](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L246)).
- `s_turn_tx_drops_base` — TX-drop baseline for the resend trigger ([§251](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L251)).
- `s_cam_tx_buf/len/tries` — async image-send bookkeeping ([§257-259](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L257)).
- `s_ptt_active` (volatile) — push-to-talk turn flag ([§270](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L270)).
- `s_turn_max_images/images_taken`, `s_capture_interval_ms`, `s_next_capture_ms`, `s_audio_end_defer_since_ms` — multi-image lifecycle ([§287-296](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L287)).
- `s_reply_dwell_until_ms`, `s_thinking_until_ms`, `s_image_preview_until_ms` — UI/turn timers ([§278-314](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L278)).
- `s_chunked_tft_len`, `s_tft_append_active/discard_stream/append_base`, `s_latex_rx_start_ms/chunks` — chunked-TFT receive state ([§324-343](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L324)).
- `s_wifi_entry_active` — routes buttons to the boot keyboard ([§236](../../Smart-Tutor-Lamp/tutor_lamp/tutor_lamp.ino#L236)).

---

*This document was generated by reading the firmware source on the `firmware` branch of `Smart-Tutor-Lamp`. All quoted constants, thresholds, and control flow are taken directly from the cited lines.*
