# Firmware — WebSocket Networking, Camera, Buttons (Device-side Protocol)

This is the definitive, code-grounded reference for the ESP32-S3 lamp's three device-facing I/O subsystems: the persistent secure **WebSocket transport** (`net_ws`), the **OV5640 camera capture pipeline** (`camera`), and the **5-way ADC button reader** (`buttons`). It documents the on-the-wire binary frame protocol the lamp speaks to the Python/FastAPI backend, how a JPEG is captured and streamed in 1 KB chunks, and how a single analog pin is decoded into five buttons plus a long-press gesture. Every constant, threshold, algorithm, and edge case below is quoted from the actual firmware in `tutor_lamp/`; nothing is invented. Where these modules touch the rest of the system (the `.ino` orchestrator, the backend, provisioning/JWT), the integration is cross-referenced inline.

> Repo root for all links: `Smart-Tutor-Lamp/`. Module sources live under `tutor_lamp/`.

---

## Table of contents

1. [Scope and responsibilities](#1-scope-and-responsibilities)
2. [System context and data flow](#2-system-context-and-data-flow)
3. [The device-side WebSocket protocol](#3-the-device-side-websocket-protocol)
   - 3.1 [Frame format on the wire](#31-frame-format-on-the-wire)
   - 3.2 [Frame catalog (every type)](#32-frame-catalog-every-type)
   - 3.3 [Connection, URL parsing, TLS, JWT auth](#33-connection-url-parsing-tls-jwt-auth)
   - 3.4 [The wss:// library bug and the in-repo fix](#34-the-wss-library-bug-and-the-in-repo-fix)
   - 3.5 [Connection lifecycle and state machine](#35-connection-lifecycle-and-state-machine)
   - 3.6 [Reconnection: exponential backoff with jitter](#36-reconnection-exponential-backoff-with-jitter)
   - 3.7 [Auth-giveup defence (no close-code visibility)](#37-auth-giveup-defence-no-close-code-visibility)
   - 3.8 [Transmit path: FreeRTOS queue + drain](#38-transmit-path-freertos-queue--drain)
   - 3.9 [Audio streaming (uplink) and TX-drop accounting](#39-audio-streaming-uplink-and-tx-drop-accounting)
   - 3.10 [Image streaming: chunked sender (blocking and async)](#310-image-streaming-chunked-sender-blocking-and-async)
   - 3.11 [Receive path and dispatch](#311-receive-path-and-dispatch)
   - 3.12 [Heartbeat](#312-heartbeat)
   - 3.13 [OTA firmware self-update (`ota`)](#313-ota-firmware-self-update-ota)
4. [Camera capture pipeline](#4-camera-capture-pipeline)
   - 4.1 [Hardware and pin map](#41-hardware-and-pin-map)
   - 4.2 [Init: resolution, format, JPEG, PSRAM](#42-init-resolution-format-jpeg-psram)
   - 4.3 [The "smart algo": idle/capture/standby cycle](#43-the-smart-algo-idlecapturestandby-cycle)
   - 4.4 [Autofocus + VCM algorithm](#44-autofocus--vcm-algorithm)
   - 4.5 [Software standby (power/heat)](#45-software-standby-powerheat)
   - 4.6 [Capture pipeline + FB-OVF recovery](#46-capture-pipeline--fb-ovf-recovery)
   - 4.7 [Async worker, cross-core handoff & memory fences](#47-async-worker-cross-core-handoff--memory-fences)
   - 4.8 [Sensor tunings (document mode)](#48-sensor-tunings-document-mode)
5. [Button input model](#5-button-input-model)
   - 5.1 [ADC resistor-ladder decode](#51-adc-resistor-ladder-decode)
   - 5.2 [Debounce algorithm](#52-debounce-algorithm)
   - 5.3 [Long-press gesture (SELECT + directional)](#53-long-press-gesture-select--directional)
   - 5.4 [held() and hold-to-talk](#54-held-and-hold-to-talk)
   - 5.5 [Action mapping in the orchestrator](#55-action-mapping-in-the-orchestrator)
6. [File-by-file, function-by-function](#6-file-by-file-function-by-function)
7. [Configuration & constants reference](#7-configuration--constants-reference)
8. [Edge cases, errors, timeouts, fallbacks](#8-edge-cases-errors-timeouts-fallbacks)
9. [Integration points](#9-integration-points)
10. [Diagrams](#10-diagrams)

---

## 1. Scope and responsibilities

| Module | Files | Responsibility |
|---|---|---|
| **net_ws** | [net_ws.h](tutor_lamp/net_ws.h), [net_ws.cpp](tutor_lamp/net_ws.cpp) | One persistent `wss://`/`ws://` connection to the backend. Encodes/decodes the project's 4-byte-header binary frame protocol. Multiplexes uplink audio + JPEG + control and downlink TTS audio + TFT frames + STATE over a single socket. Owns reconnection, heartbeat, the cross-task TX queue, and the chunked image sender. |
| **camera** | [camera.h](tutor_lamp/camera.h), [camera.cpp](tutor_lamp/camera.cpp), [camera_pins.h](tutor_lamp/camera_pins.h) | Drives the OV5640 + autofocus. Captures a JPEG of the desk on demand, in a background task on core 0, and hands the PSRAM-resident bytes to `net_ws` for upload. Manages power via software standby. |
| **buttons** | [buttons.h](tutor_lamp/buttons.h), [buttons.cpp](tutor_lamp/buttons.cpp) | Reads five physical buttons from one ADC pin (resistor ladder), debounces them, detects a SELECT long-press, and dispatches edge events to a callback. Exposes `held()` so the orchestrator can do hold-to-talk. |

The transport's stated design intent ([IMPLEMENTATION_WEBSOCKET.md §0–1](IMPLEMENTATION_WEBSOCKET.md)): there is **no REST, no polling, no second TCP connection** — one socket per device, opened at boot, reconnected on drop, saving ~300 ms per voice turn by amortising the TLS handshake and letting the server push TTS/TFT frames unsolicited.

These three modules are deliberately decoupled: the mic/DSP and TTS/speaker subsystems "don't know WebSocket exists" — they call `net::send_frame()` and register a `net::on_frame()` callback ([net_ws.h:117–120](tutor_lamp/net_ws.h#L117)).

---

## 2. System context and data flow

The orchestrator [tutor_lamp.ino](tutor_lamp/tutor_lamp.ino) wires the three modules together. Threading model:

- **`loop()` task — core 1.** Calls `net::loop()`, `buttons::poll()`, `tft_ui::tick()`, polls the camera worker result, and is the **only** caller of the ArduinoWebsockets library object `s_client` ([net_ws.h:8–13](tutor_lamp/net_ws.h#L8)).
- **Mic capture task — core 1, priority 8.** Pre-empts `loop()`. Calls `net::send_frame(FRAME_AUDIO_CHUNK_ADPCM, …)` for ≤1 KB payloads, which are queued (not sent directly) — the FreeRTOS queue is the lock-free bridge so the loop task remains the sole socket writer ([net_ws.cpp:176–202](tutor_lamp/net_ws.cpp#L176)).
- **Camera worker task — core 0, priority 5.** Runs `do_capture_pipeline()` off the main core so animations/audio stay responsive ([camera.cpp:441–456](tutor_lamp/camera.cpp#L441)).

One turn (grounded in [IMPLEMENTATION_WEBSOCKET.md §3](IMPLEMENTATION_WEBSOCKET.md) and the `.ino`):

```
boot ──► net::begin(url, jwt) ──► net::connect() ──► wss handshake (Bearer JWT)
         ◄── 101 Switching Protocols ─ ConnectionOpened ─► NET_CONNECTED

wake word "hey lumos" OR UP push-to-talk ──► begin_command_turn():
    cam::grab_async()  (core 0)                     mic streams AUDIO_CHUNK_ADPCM (core 1, queued)
    ◄── camera GRAB_READY ─► net::begin_image_send(jpg) ─► IMAGE_PART×N + IMAGE_JPEG terminator
    VAD EOS / UP release ─► (resend audio if drops) ─► AUDIO_END

         ◄── STATE(thinking) / AUDIO_OUT_* / TFT_* / AUDIO_OUT_END / STATE(idle) ──
```

---

## 3. The device-side WebSocket protocol

### 3.1 Frame format on the wire

Every WebSocket **binary** message carries exactly one application frame. The header is 4 bytes: a 1-byte type and a 3-byte big-endian length, followed by the payload ([net_ws.h:5–6](tutor_lamp/net_ws.h#L5), [IMPLEMENTATION_WEBSOCKET.md §4.2](IMPLEMENTATION_WEBSOCKET.md)):

```
 0       1               4                         4 + N
 ├───────┼───────────────┼─────────────────────────┤
 │ type  │ length (u24 BE)│ payload (N bytes)       │
 │ u8    │ network order  │                         │
 └───────┴───────────────┴─────────────────────────┘
```

Encoding is one helper ([net_ws.cpp:264–269](tutor_lamp/net_ws.cpp#L264)):

```cpp
inline void encode_header(uint8_t* dst, uint8_t type, size_t len) {
    dst[0] = type;
    dst[1] = (uint8_t)((len >> 16) & 0xFF);   // u24 big-endian
    dst[2] = (uint8_t)((len >>  8) & 0xFF);
    dst[3] = (uint8_t)((len      ) & 0xFF);
}
```

Decoding on receive reverses it and validates length ([net_ws.cpp:271–287](tutor_lamp/net_ws.cpp#L271)):

```cpp
if (!m.isBinary()) return;        // text frames ignored
const size_t len = m.length();
if (len < 4) return;              // runt frame: dropped silently
const uint8_t  type = d[0];
const uint32_t plen = ((uint32_t)d[1] << 16) | ((uint32_t)d[2] << 8) | d[3];
if (4 + plen > len) return;       // header claims more than was delivered: dropped
```

Max representable length is 16,777,215 bytes (u24). In practice the spec caps a single frame at ~96 KB ([IMPLEMENTATION_WEBSOCKET.md A6](IMPLEMENTATION_WEBSOCKET.md)), but the firmware never sends a whole image as one frame — it chunks (see §3.10).

### 3.2 Frame catalog (every type)

The authoritative enum lives in [net_ws.h:54–77](tutor_lamp/net_ws.h#L54). It is a **superset** of the original spec (the spec listed 11 types; the firmware adds ADPCM/Opus codec variants, chunked-image/TFT part types, an audio-reset type, and — as of `e1de15a` — a graph pan/zoom uplink (`0x09`) plus compressed-equation / graph / chemistry terminators (`0x27`–`0x2A`)). `c699e72` adds two more terminators for the scroll-document feature, `FRAME_TFT_DOC_MANIFEST = 0x2B` and `FRAME_TFT_DOC_ELEM = 0x2C` (see [02-display-and-ui.md §4.9](02-display-and-ui.md) for the full protocol). Direction: ESP→BE = device-to-backend, BE→ESP = backend-to-device.

| Hex | Name | Dir | Payload | Purpose / notes |
|---|---|---|---|---|
| `0x01` | `FRAME_IMAGE_JPEG` | ESP→BE | final/only image chunk | Backend treats the accumulated buffer + this payload as a complete JPEG. Sent as the **last** image chunk. ([net_ws.h:55](tutor_lamp/net_ws.h#L55)) |
| `0x02` | `FRAME_AUDIO_CHUNK` | ESP→BE | int16 PCM LE, 16 kHz mono | Legacy raw uplink audio (used when `MIC_WIRE_ADPCM=0`). ([net_ws.h:56](tutor_lamp/net_ws.h#L56)) |
| `0x03` | `FRAME_AUDIO_END` | ESP→BE | empty | EOS — last uplink frame of a turn. ([net_ws.h:57](tutor_lamp/net_ws.h#L57)) |
| `0x04` | `FRAME_CANCEL` | ESP→BE | empty | User cancelled (SELECT during active turn). ([net_ws.h:57](tutor_lamp/net_ws.h#L57)) |
| `0x05` | `FRAME_IMAGE_PART` | ESP→BE | intermediate image chunk | Backend appends to a per-session accumulation buffer. ([net_ws.h:59](tutor_lamp/net_ws.h#L59)) |
| `0x06` | `FRAME_AUDIO_CHUNK_ADPCM` | ESP→BE | IMA/DVI ADPCM 4:1 | **Default** uplink codec (8 KB/s vs raw 32 KB/s — survives a capped WAN and frees the uplink for the image). Encoder state per command turn, reset in `begin_command_turn`; decoded per-Turn server-side. Backend MUST support 0x06 before this firmware is flashed. ([net_ws.h:60–61](tutor_lamp/net_ws.h#L60)) |
| `0x07` | `FRAME_AUDIO_RESET` | ESP→BE | empty | "Discard streamed audio + decoder state — full utterance follows from `cmd_buf`." Sent at EOS when TX drops occurred this turn. ([net_ws.h:61](tutor_lamp/net_ws.h#L61)) |
| `0x09` | `FRAME_GRAPH_VIEW` | ESP→BE | `[u8 graph_id][f32 x0][f32 x1][f32 y0][f32 y1]` (17 B; window fields BE) | Graph pan/zoom request from `PAGE_GRAPH`/the graph arena — the new display window. **`c699e72`** grew the payload from 16 to 17 bytes, prepending a `graph_id` (u8) so a scroll-document with several graphs can address which one to re-render; the backend re-renders the corresponding cached graph spec over the window → fresh `TFT_GRAPH_JPEG`. Sent only by graph-capable firmware. Cross-reference: [02-display-and-ui.md §4.7](02-display-and-ui.md). ([net_ws.h:62](tutor_lamp/net_ws.h#L62)) |
| `0x10` | `FRAME_AUDIO_OUT` | BE→ESP | int16 PCM LE, 24 kHz mono | Raw TTS audio. ([net_ws.h:62](tutor_lamp/net_ws.h#L62)) |
| `0x11` | `FRAME_AUDIO_OUT_END` | BE→ESP | empty | Last TTS frame of a turn. ([net_ws.h:63](tutor_lamp/net_ws.h#L63)) |
| `0x12` | `FRAME_AUDIO_OUT_ADPCM` | BE→ESP | IMA/DVI ADPCM TTS | 4:1 (1 KB = 85.3 ms @ 24 kHz mono). Decoder state continuous per stream, reset at `AUDIO_OUT_END`. Sent when backend `TTS_WIRE_CODEC=adpcm`. ([net_ws.h:64](tutor_lamp/net_ws.h#L64)) |
| `0x13` | `FRAME_AUDIO_OUT_OPUS` | BE→ESP | one Opus packet | 20 ms @ 24 kHz mono, ~80–120 B at 32 kbps. Decoded only if built with `USE_OPUS_DECODER=1`; otherwise dropped. Sent when backend `TTS_WIRE_CODEC=opus`. ([net_ws.h:65](tutor_lamp/net_ws.h#L65)) |
| `0x20` | `FRAME_TFT_FRAME` | BE→ESP | RGB565 pixel pack | Final/only chunk; concatenated to the per-session accumulator = complete TFT frame. ([net_ws.h:66](tutor_lamp/net_ws.h#L66)) |
| `0x21` | `FRAME_TFT_TEXT` | BE→ESP | UTF-8 | Short plain-text display. ([net_ws.h:67](tutor_lamp/net_ws.h#L67)) |
| `0x22` | `FRAME_TFT_CLEAR` | BE→ESP | empty | Blank the display. ([net_ws.h:68](tutor_lamp/net_ws.h#L68)) |
| `0x23` | `FRAME_TFT_PART` | BE→ESP | intermediate TFT chunk | Appended to a per-session PSRAM accumulator awaiting the `TFT_FRAME` terminator. ([net_ws.h:69](tutor_lamp/net_ws.h#L69)) |
| `0x24` | `FRAME_TFT_LATEX_LOADING` | BE→ESP | empty | Show a "rendering equation…" skeleton in the top half while a chunked `TFT_FRAME` is in transit. ([net_ws.h:70](tutor_lamp/net_ws.h#L70)) |
| `0x25` | `FRAME_TFT_APPEND` | BE→ESP | append-segment terminator | Splices new pixels after the committed pack (incremental equation render). ([net_ws.h:71](tutor_lamp/net_ws.h#L71)) |
| `0x26` | `FRAME_TFT_APPEND_BEGIN` | BE→ESP | empty | Arms the accumulator so following `TFT_PART`s write after the committed pack. ([net_ws.h:72](tutor_lamp/net_ws.h#L72)) |
| `0x27` | `FRAME_TFT_IMAGE_JPEG` | BE→ESP | `[u16 W][u16 H][grayscale JPEG]` | **New (`aa2143c`)** terminator of a compressed equation — decoded via `TJpg_Decoder` straight into `s_latex` (~3–15 KB vs ~70 KB raw). Sent when backend `TFT_IMAGE_CODEC=jpeg`; a build without the case drops it. ([net_ws.h:73](tutor_lamp/net_ws.h#L73)) |
| `0x28` | `FRAME_TFT_IMAGE_PART` | BE→ESP | intermediate chunk | Chunk carrier for `0x27`/`0x29`/`0x2A`; appended to the equation-JPEG accumulator (reuses the camera-preview buffer). ([net_ws.h:74](tutor_lamp/net_ws.h#L74)) |
| `0x29` | `FRAME_TFT_GRAPH_JPEG` | BE→ESP | `[f32 x0,x1,y0,y1][color JPEG, full screen]` | **New (`e1de15a`)** terminator of a chunked graph → `PAGE_GRAPH`; remembers the window for pan/zoom via `GRAPH_VIEW`. Gated by `GRAPH_ENABLED`. ([net_ws.h:75](tutor_lamp/net_ws.h#L75)) |
| `0x2A` | `FRAME_TFT_CHEM_JPEG` | BE→ESP | `[u8 idx][u8 count][color JPEG, full screen]` | **New (`e1de15a`)** terminator of one chemistry-structure step (≤4 steps cached) → `PAGE_CHEM` with L/R navigation. Gated by `CHEM_STRUCTURE_ENABLED`. ([net_ws.h:76](tutor_lamp/net_ws.h#L76)) |
| `0x2B` | `FRAME_TFT_DOC_MANIFEST` | BE→ESP | block-list manifest | **New (`c699e72`)** terminator of a chunked scroll-document manifest (`TFT_SCROLL_DOC`) — block list with inline text, element blocks filled in by `TFT_DOC_ELEM`. Full protocol: [02-display-and-ui.md §4.9](02-display-and-ui.md). ([net_ws.h:78](tutor_lamp/net_ws.h#L78)) |
| `0x2C` | `FRAME_TFT_DOC_ELEM` | BE→ESP | `[u16 block_index][color JPEG]` | **New (`c699e72`)** terminator of a chunked scroll-document element, blitted at its manifest block's y-offset as the student scrolls `PAGE_DOC`. Full protocol: [02-display-and-ui.md §4.9](02-display-and-ui.md). ([net_ws.h:79](tutor_lamp/net_ws.h#L79)) |
| `0x30` | `FRAME_STATE` | BE→ESP | 1-byte enum | Drives LED/UI state (idle/listening/thinking/speaking/error). ([net_ws.h:80](tutor_lamp/net_ws.h#L80)) |

PING/PONG (`0xF0`/`0xF1` in the spec) are handled transparently by the library and never generated by application code ([IMPLEMENTATION_WEBSOCKET.md §15](IMPLEMENTATION_WEBSOCKET.md)). Unknown types are dropped silently on both sides.

### 3.3 Connection, URL parsing, TLS, JWT auth

**URL source.** `NET_WS_URL` is owned by [backend_config.h](tutor_lamp/backend_config.h), not net_ws. A single switch `BACKEND_USE_SERVER` selects target ([backend_config.h:33–35](tutor_lamp/backend_config.h#L33)):

- `1` (default) → `wss://lumi-smart-lamp.onrender.com/lamp/ws` (TLS on 443) — `c699e72` flipped the `#define`/`// #define` pair back to this host, with `smart-tutor-lamp.onrender.com` now the commented-out alternate ([backend_config.h:60, 69–73](tutor_lamp/backend_config.h#L60)).
- `0` → `ws://192.168.0.5:8000/lamp/ws` (plain, LAN dev) ([backend_config.h:44, 79–81](tutor_lamp/backend_config.h#L79)).

A `-DNET_WS_URL=…` build flag overrides everything (the `#ifndef` guards leave it untouched). If `backend_config.h` is somehow absent, net_ws.h falls back to `ws://localhost:8000/lamp/ws` so it "fails loud rather than silently connect to a stale dev IP" ([net_ws.h:22–30](tutor_lamp/net_ws.h#L22)).

**URL parsing.** `parse_ws_url()` splits the URL into `s_secure / s_host / s_port / s_path` ([net_ws.cpp:247–262](tutor_lamp/net_ws.cpp#L247)):

1. `s_secure = url.startsWith("wss://")`. Scheme length is 6 for `wss://`, 5 for `ws://`, else 0.
2. The remainder after the scheme is split at the first `/`: everything before is `host[:port]`, the rest (or `"/"`) is the path.
3. If a `:` is present, host and port are split; otherwise the port defaults to **443** for wss, **80** for ws.

This split is required because the firmware uses the **3-argument** `connect(host, port, path)` overload (see §3.4), which needs the components separately.

**JWT auth.** The Authorization header is added **exactly once** in `begin()` ([net_ws.cpp:491–493](tutor_lamp/net_ws.cpp#L491)):

```cpp
s_client.addHeader("Authorization", String("Bearer ") + s_jwt);
```

Adding it per-connect attempt previously accumulated duplicate headers across reconnects — that bug is fixed by doing it once at init ([net_ws.cpp:382–383](tutor_lamp/net_ws.cpp#L382)). The JWT string comes from the orchestrator: with `ENABLE_AUTH=1` it is `provisioning::device_jwt()` (issued during pairing, stored in NVS); with `ENABLE_AUTH=0` it is the placeholder `DEV_PLACEHOLDER_JWT` which the backend's `_authenticate_dev` accepts unconditionally ([tutor_lamp.ino:1311–1314, 1345](tutor_lamp/tutor_lamp.ino#L1311)). `do_connect()` treats a missing host or JWT as **FATAL** ([net_ws.cpp:362–366](tutor_lamp/net_ws.cpp#L362)).

### 3.4 The wss:// library bug and the in-repo fix

`net_ws.cpp` carries an extensive, load-bearing workaround for a genuine ArduinoWebsockets ESP32 bug. The detail matters because it is the difference between "works on LAN, dies on Render" and a working remote connection.

**Bug 1 — TLS handshake rejected.** `WebsocketsClient::setInsecure()` only NULLs the CA pointers; the wss upgrade path on ESP32 creates a fresh `WiFiClientSecure` but, unlike the ESP8266 branch, **never** calls `setInsecure()` on it. Modern arduino-esp32 cores reject that handshake (no CA + no insecure flag) → `connect()` returns false and the request never reaches the server ([net_ws.cpp:18–36](tutor_lamp/net_ws.cpp#L18)).

**Fix.** Subclass the library's secured TCP client (`InsecureWssTcpClient : WSDefaultSecuredTcpClient`) and call `setInsecure()` on the underlying client in the constructor ([net_ws.cpp:69–73](tutor_lamp/net_ws.cpp#L69)). This client is handed to `WebsocketsClient` in `begin()` ([net_ws.cpp:478–487](tutor_lamp/net_ws.cpp#L478)), and the firmware connects via the **3-arg** `connect(host,port,path)` overload, which does **not** call `upgradeToSecuredConnection()`, so the pre-configured insecure client is used as-is ([net_ws.cpp:379–384](tutor_lamp/net_ws.cpp#L379)). For `ws://` the default plain client is kept. The choice is governed by `NET_WS_TLS_INSECURE` (default `1`) ([net_ws.h:32–35](tutor_lamp/net_ws.h#L32)).

**Bug 2 — handshake read times out over the WAN.** The stock `readLine()` bails after `_CONNECTION_TIMEOUT` = 1000 ms. On the LAN the `HTTP/1.1 101` reply is already in the buffer; over wss:// the reply takes a real round-trip, and the mic capture task (core 1, prio 8) starves the loop-context read, so the 1 s wall-clock budget trips before the (already-sent) 101 is consumed. The library then closes with `CloseReason_ProtocolError` — the server logs `disconnect code=1002` *after* `auth=True`, while the lamp prints "no 101" even though the JWT was fine ([net_ws.cpp:75–97](tutor_lamp/net_ws.cpp#L75)).

**Fix.** Override `readLine()` to read byte-by-byte until `'\n'` with a generous wall-clock budget `NET_WS_HANDSHAKE_READ_MS` (default **10000 ms**, vs the stock 1000) and `delay(2)` between empty reads so it yields and feeds the task WDT ([net_ws.cpp:41–43, 98–115](tutor_lamp/net_ws.cpp#L98)).

**Diagnostic instrumentation.** The subclass also overrides `available()` and `send()` to dump errno, mbedTLS last error, RSSI/WiFi status, and DMA/PSRAM heap stats at the moment a link drops mid-upload — because `connected=0` with ample free heap means the TLS/TCP link dropped for a reason `getFreeHeap()` cannot show ([net_ws.cpp:117–173](tutor_lamp/net_ws.cpp#L117)).

### 3.5 Connection lifecycle and state machine

States ([net_ws.h:76–82](tutor_lamp/net_ws.h#L76)): `NET_DISCONNECTED`, `NET_CONNECTING`, `NET_CONNECTED`, `NET_BACKOFF`, `NET_FATAL`. The current state is `volatile net::ConnState s_state` ([net_ws.cpp:219](tutor_lamp/net_ws.cpp#L219)); transitions go through `set_state()`, which fires the optional `on_state` observer only on a real change ([net_ws.cpp:239–243](tutor_lamp/net_ws.cpp#L239)).

- `begin(url, jwt)` — one-time init: stores URL+JWT, parses URL, creates the TX queue, allocates the PSRAM assemble buffer, swaps in the insecure client (wss), registers callbacks, adds the Bearer header. **Does not open the socket.** ([net_ws.cpp:461–501](tutor_lamp/net_ws.cpp#L461))
- `connect()` — idempotent guard: returns immediately if already `CONNECTED`/`CONNECTING`/`FATAL`; otherwise calls `do_connect()` ([net_ws.cpp:503–507](tutor_lamp/net_ws.cpp#L503)).
- `do_connect()` — sets `NET_CONNECTING`, logs attempt number + JWT tail + free heap, then calls `s_client.connect(host,port,path)`. `false` ⇒ no 101 ⇒ `schedule_backoff()`. `CONNECTED` is set only when the `ConnectionOpened` event fires ([net_ws.cpp:361–402](tutor_lamp/net_ws.cpp#L361)).
- `loop()` — if `FATAL`, return. If `BACKOFF` and the timer elapsed, `do_connect()`. Otherwise `s_client.poll()` (drives RX + lifecycle events), then if `CONNECTED`: pump image send, drain TX queue, heartbeat ([net_ws.cpp:511–543](tutor_lamp/net_ws.cpp#L511)).

`on_ws_event()` handles library events ([net_ws.cpp:314–359](tutor_lamp/net_ws.cpp#L314)):

- **ConnectionOpened** → `NET_CONNECTED`, reset backoff to `BACKOFF_INIT_MS`, re-arm `s_last_ping`, clear the auth-giveup watcher.
- **ConnectionClosed** → log, run the auth-giveup heuristic (§3.7), then `schedule_backoff()`.
- **GotPong** → refresh `s_last_ping`.

### 3.6 Reconnection: exponential backoff with jitter

`schedule_backoff()` implements jittered exponential backoff ([net_ws.cpp:289–312](tutor_lamp/net_ws.cpp#L289)):

```cpp
s_backoff_until = millis() + s_backoff_ms;     // schedule THIS wait
uint32_t next = s_backoff_ms * 2;              // double for NEXT time
if (next > BACKOFF_MAX_MS) next = BACKOFF_MAX_MS;
int32_t jitter = (int32_t)(next / 4);          // ±25%
if (jitter > 0) next = next + (esp_random() % (jitter * 2)) - jitter;
s_backoff_ms = next;
```

Constants: `BACKOFF_INIT_MS = 2000`, `BACKOFF_MAX_MS = 30000` ([net_ws.cpp:196–197](tutor_lamp/net_ws.cpp#L196)). So the schedule is **2 s, 4 s, 8 s, 16 s, 30 s, 30 s, …** each with ±25 % random jitter, reset to 2 s on every successful open. This is exactly the schedule documented in [IMPLEMENTATION_WEBSOCKET.md §5.1](IMPLEMENTATION_WEBSOCKET.md). The backoff log line also surfaces the running attempt count, how close the auth-giveup self-heal is, and the JWT tail so a stale token vs a server outage can be told apart at a glance.

This backoff is what tolerates Render's free-tier cold start (~30–60 s sleep wake) — the lamp just retries until the server wakes ([backend_config.h:56–58](tutor_lamp/backend_config.h#L56)).

### 3.7 Auth-giveup defence (no close-code visibility)

The ArduinoWebsockets library on this chip **does not surface the WS close code** to user space — `ConnectionClosed` gives only a `String` ([net_ws.h:92–108](tutor_lamp/net_ws.h#L92)). So the lamp cannot directly see "backend closed me with 4401". Instead net_ws uses a heuristic over three flags ([net_ws.cpp:233–235](tutor_lamp/net_ws.cpp#L233)):

- `s_recv_since_open` — set true the moment any application frame arrives ([net_ws.cpp:283](tutor_lamp/net_ws.cpp#L283)). Receiving a frame proves the backend **accepted** the JWT, so the counter resets.
- `s_consecutive_empty_disconnects` — incremented each time `ConnectionClosed` fires **without** a frame having been received since open ([net_ws.cpp:333–339](tutor_lamp/net_ws.cpp#L333)).
- `s_auth_giveup_fired` — ensures the callback fires at most once.

When the counter reaches `NET_WS_AUTH_GIVEUP_THRESHOLD` (default **8**, [net_ws.cpp:230–232](tutor_lamp/net_ws.cpp#L230)) and a callback is registered, `s_on_auth_giveup()` fires ([net_ws.cpp:340–348](tutor_lamp/net_ws.cpp#L340)). The orchestrator wires this to wipe the JWT and reboot into pairing ([tutor_lamp.ino:1369–1374](tutor_lamp/tutor_lamp.ino#L1369)):

```cpp
net::on_auth_giveup([]() {
    provisioning::clear_jwt();
    delay(100);
    ESP.restart();
});
```

**Crucial asymmetry:** a `connect()==false` (no 101) is deliberately **not** counted toward auth-giveup, because that failure is ambiguous (usually TLS/TCP/network, only sometimes a pre-accept 403). Counting it once wiped a valid JWT and reboot-looped when the real cause was TLS. Auth-giveup is kept on the post-OPEN path only (a `ConnectionClosed` with no frame received is a far stronger auth signal) ([net_ws.cpp:384–400](tutor_lamp/net_ws.cpp#L384)).

### 3.8 Transmit path: FreeRTOS queue + drain

`send_frame(type, payload, len)` is the single public send API ([net_ws.cpp:547–573](tutor_lamp/net_ws.cpp#L547)). It branches on size:

**Small frames (`len ≤ TX_PAYLOAD_MAX_Q` = 1024):** assembled into a `TxItem` and pushed onto a FreeRTOS queue with zero block time. Safe from any task. On queue-full it records a drop and returns false ([net_ws.cpp:553–562](tutor_lamp/net_ws.cpp#L553)).

```cpp
struct TxItem {                       // net_ws.cpp:199–202
    uint16_t total_len;               // header + payload, ≤ TX_ITEM_BYTES
    uint8_t  data[TX_ITEM_BYTES];     // TX_ITEM_BYTES = 4 + 1024 = 1028
};
```

Queue sizing ([net_ws.cpp:190–197](tutor_lamp/net_ws.cpp#L190)): `TX_Q_DEPTH = 40` slots × ~1030 B ≈ 41 KB DRAM, holding ~1.3 s of raw 512-sample mic chunks (40 × 32 ms) while loop() is blocked by a camera capture — and **~5 s** once ADPCM quarters each chunk to 256 B ([tutor_lamp.ino:373–375](tutor_lamp/tutor_lamp.ino#L373)).

**Why a queue at all (the 640 → 1024 threshold story):** the threshold *must* cover the real audio chunk. At a 640 B threshold the 1024 B raw audio frame fell to the direct-send path and was written to `s_client` straight from the core-1 capture task, concurrently with the loop task's image/poll sends. The ArduinoWebsockets client is **not reentrant**; on wss:// the long TLS encrypt widened the preemption window until the two writers interleaved inside one TLS record → garbage WS frame → uvicorn closed 1002. Raising the threshold routes audio back through the thread-safe queue so the loop task is the only caller of `s_client` ([net_ws.cpp:176–190](tutor_lamp/net_ws.cpp#L176)).

**Large frames (`> 1024`):** assembled into the 256 KB PSRAM `s_assemble` buffer and sent directly — **loop() context only**. This path is explicitly marked KNOWN-BROKEN for payloads above ~8 KB on this library; images must go through the chunked sender instead ([net_ws.cpp:564–573](tutor_lamp/net_ws.cpp#L564)).

**Draining** ([net_ws.cpp:436–454](tutor_lamp/net_ws.cpp#L436)): `drain_tx_queue(max_items)` pops up to `max_items` items and `sendBinary()`s each. `TX_DRAIN_PER_LOOP = 8` bounds work per iteration so other work isn't starved. If `sendBinary` fails (dying socket) it logs and stops draining — previously the return was ignored, so a dying wss socket dumped the whole audio queue into the void with no trace.

**Slow-write stall detector (new in `e1de15a`)** ([net_ws.cpp:437-462](tutor_lamp/net_ws.cpp#L437)): the drain now times the whole batch and, if `>500 ms` was spent handing frames to TLS, logs a `[net] SLOW WRITE … (congested link; RSSI … dBm)` line. It is diagnostic only (no behaviour change) — it makes a congested link visible in a serial capture rather than presenting only as a frozen UI. The per-image-chunk counterpart lives in `pump_image_send()` (§3.10).

### 3.9 Audio streaming (uplink) and TX-drop accounting

The mic capture task calls `on_cleaned_frame()` per DSP frame ([tutor_lamp.ino:367–384](tutor_lamp/tutor_lamp.ino#L367)). With `MIC_WIRE_ADPCM=1` (default) it encodes the int16 frame to IMA-ADPCM (4:1) and sends `FRAME_AUDIO_CHUNK_ADPCM`; otherwise it sends raw `FRAME_AUDIO_CHUNK`. A 512-sample frame is 1024 B raw → 256 B ADPCM. The ADPCM encoder state is reset per turn in `begin_command_turn` via `adpcm::enc_reset()` to pair with the backend's per-Turn decoder ([tutor_lamp.ino:1102](tutor_lamp/tutor_lamp.ino#L1102)).

**TX-drop accounting** ([net_ws.cpp:412–434](tutor_lamp/net_ws.cpp#L412)): `send_frame()` drops a frame silently when the queue is full or the socket is down. Because the audio path ignores the return value, a congested link could eat most of an utterance with zero log evidence (observed: backend received 57 of ~242 chunks — 76 % lost — during a Render cold start). `note_tx_drop()` increments a cumulative `volatile uint32_t s_tx_drops` and logs at most one line per second, flagging "AUDIO IS BEING LOST" for type `0x02`. The counter is exposed via `tx_drop_count()` ([net_ws.cpp:545](tutor_lamp/net_ws.cpp#L545)).

The orchestrator uses this counter for a **full-resend at EOS**: it snapshots `net::tx_drop_count()` at turn start ([tutor_lamp.ino:1106](tutor_lamp/tutor_lamp.ino#L1106)); if drops occurred during the turn, at EOS it sends `FRAME_AUDIO_RESET`, resets the ADPCM encoder, and re-streams the whole utterance from `cmd_buf` as ADPCM chunks (a 100 % recovery path), then `FRAME_AUDIO_END` ([tutor_lamp.ino:1706–1764](tutor_lamp/tutor_lamp.ino#L1706)). This is the reason live audio drops are tolerable — they are repaired wholesale at EOS, which is exactly why the loop prioritises the image over audio bandwidth ([net_ws.cpp:524–530](tutor_lamp/net_ws.cpp#L524)).

### 3.10 Image streaming: chunked sender (blocking and async)

A whole JPEG is **never** sent as one frame. Both senders split it into **1024 B** chunks: every chunk except the last is `FRAME_IMAGE_PART` (`0x05`); the last is `FRAME_IMAGE_JPEG` (`0x01`), which tells the backend the image is complete ([net_ws.cpp:631–635](tutor_lamp/net_ws.cpp#L631), [net_ws.h:123–129](tutor_lamp/net_ws.h#L123)).

**Why chunk?** ArduinoWebsockets internally copies the payload through a temporary `std::string` (`message_data += std::string(data, len)`). For a 20–100 KB image that is ~40–200 KB of contiguous DRAM. With WiFi + camera + I2S live, free DRAM hovers near 128 KB and is fragmented — the alloc fails *silently* (the library returns true regardless — `// TODO dont assume success`), leaving a partial WS frame on the wire, and the server closes with no reason code. 1 KB chunks keep every internal allocation tiny, so it never fails. The library's streaming/continuation API is **not** usable either: it takes Arduino `String`, whose `c_str()` truncates at the first `0x00` — and JPEGs are full of zero bytes, so the data corrupts. Independent binary messages avoid that path entirely ([net_ws.cpp:582–600](tutor_lamp/net_ws.cpp#L582)).

There are **two** senders with identical wire behaviour:

#### Blocking — `send_image_chunked(jpg, len)` ([net_ws.cpp:582–682](tutor_lamp/net_ws.cpp#L582))

Loops over 1 KB chunks. Per chunk it: builds the header+payload on a 1028 B stack buffer, `sendBinary()`s, then runs three steps ([net_ws.cpp:658–676](tutor_lamp/net_ws.cpp#L658)):

1. **`s_client.poll()`** — drain inbound. On wss:// the mbedTLS write path stalls if its RX buffer isn't serviced, silently dropping the socket mid-image.
2. **`drain_tx_queue(8)`** — keep the mic stream flowing during the upload.
3. **`vTaskDelay(NET_WS_IMAGE_CHUNK_GAP_MS)`** — pace gap (default **20 ms**). This is the dominant fix: pushing ~1 KB every few ms is ~9× the WAN drain rate, so the ~5.7 KB lwIP TCP send buffer overflowed after ~4 KB and the socket dropped. ~20 ms/chunk matches the link's drain rate so the buffer stays stable. Plain ws:// (LAN) drains in <1 ms so the gap is harmless there ([net_ws.cpp:45–54, 668–672](tutor_lamp/net_ws.cpp#L45)).

A **hard wall-clock cap** `NET_WS_IMAGE_SEND_MAX_MS` (8000 ms in net_ws.cpp's local default; 15000 ms in the net_ws.h default that the .ino uses) abandons the upload if exceeded — audio matters more than the photo ([net_ws.cpp:56–67, 615–630](tutor_lamp/net_ws.cpp#L56), [net_ws.h:44–46](tutor_lamp/net_ws.h#L44)). On abort or chunk-send failure it sends a **bare `FRAME_IMAGE_JPEG` terminator** to flush the backend's partial accumulator: the half image then fails the server's JPEG EOI magic check and is dropped cleanly — without it, a later image in the same multi-image turn would append onto the partial bytes and the hybrid would falsely pass the magic check ([net_ws.cpp:620–630](tutor_lamp/net_ws.cpp#L620)). An optional `s_image_send_hook` (pointed at `tft_ui::tick()`) is called per chunk so the multi-second blocking upload doesn't freeze the screen ([net_ws.cpp:575–580, 676](tutor_lamp/net_ws.cpp#L575)).

#### Async — `begin_image_send` / `pump_image_send` (preferred) ([net_ws.cpp:684–774](tutor_lamp/net_ws.cpp#L684))

Same wire behaviour but **never blocks loop()**: the pace gap is a timestamp check (`s_img_next_ms`) instead of `vTaskDelay`, so page transitions, the LISTENING waveform and the audio TX drain stay live during the upload ([net_ws.h:131–148](tutor_lamp/net_ws.h#L131)). The blocking sender used to freeze loop() for up to 8 s on a slow WAN, making the UI appear stuck on the preview then jump straight to THINKING.

**Per-chunk stall detector (new in `e1de15a`)** ([net_ws.cpp:762-777](tutor_lamp/net_ws.cpp#L762)): `pump_image_send()` times each blocking `sendBinary()` and, if a single image chunk blocked `loop()` for `>250 ms`, logs `[net] SLOW WRITE: image chunk #N blocked loop() …ms (TLS send buffer full — congested link; RSSI … dBm)`. The comment records the diagnosis: on a collapsed link the ~5.7 KB TLS send buffer fills, so a single 1 KB write waits seconds for ACKed space (~400 B/s) — that blocking write **is** the "screen freeze", since UI/audio-drain then run at ~0.3 Hz. The log turns the next serial capture into direct evidence of where the seconds go.

State machine `ImgSendState`: `IMG_IDLE → IMG_SENDING → IMG_DONE/IMG_FAILED → (ack) → IMG_IDLE` ([net_ws.h:143](tutor_lamp/net_ws.h#L143)):

- `begin_image_send(jpg, len)` — registers the buffer, returns immediately; rejects if a send is already active ([net_ws.cpp:697–709](tutor_lamp/net_ws.cpp#L697)).
- `pump_image_send()` — called once per `net::loop()` pass *before* audio drain ([net_ws.cpp:530](tutor_lamp/net_ws.cpp#L530)). Sends **one** chunk per pass, honouring the pace gap and the time budget; on socket death mid-send it goes `IMG_FAILED` without flushing (pointless — the server session dies with the connection) ([net_ws.cpp:732–774](tutor_lamp/net_ws.cpp#L732)).
- `abort_image_send()` — flush terminator + mark `IMG_FAILED` (used by SELECT/CANCEL) ([net_ws.cpp:714–723](tutor_lamp/net_ws.cpp#L714)).
- `ack_image_send()` — consume DONE/FAILED → IDLE; the caller must keep `jpg` alive until then ([net_ws.cpp:725–730](tutor_lamp/net_ws.cpp#L725)).

The caller (`.ino`) keeps the camera frame buffer alive across the whole async send and only calls `cam::release()` when `image_send_active()` goes false, with one automatic retry per turn on failure ([tutor_lamp.ino:1510–1537, 1561–1564](tutor_lamp/tutor_lamp.ino#L1510)).

**Image-before-audio priority:** `net::loop()` calls `pump_image_send()` *before* `drain_tx_queue()` because the image has no recovery path once the turn ends, whereas audio has the EOS full-resend ([net_ws.cpp:524–531](tutor_lamp/net_ws.cpp#L524)).

### 3.11 Receive path and dispatch

Inbound messages land in `on_ws_message()` (registered via `s_client.onMessage`) which runs inside `s_client.poll()` on the loop task ([net_ws.cpp:271–287, 489](tutor_lamp/net_ws.cpp#L271)). After validating binary + length (§3.1), it sets the auth-giveup flags and calls the registered `s_on_frame(type, payload, len)` ([net_ws.cpp:286](tutor_lamp/net_ws.cpp#L286)). The orchestrator registers `handle_server_frame` ([tutor_lamp.ino:1350](tutor_lamp/tutor_lamp.ino#L1350)), which switches on type: `AUDIO_OUT*` → decode (ADPCM/Opus) → `spk::push_pcm`; `AUDIO_OUT_END` → `adpcm::reset()` and drain; `STATE` → drive LED/UI; the TFT_* family → `tft_ui`; `STATE(0x05)` → wipe JWT + reboot ([tutor_lamp.ino:511–577, 838](tutor_lamp/tutor_lamp.ino#L511)).

### 3.12 Heartbeat

In `loop()`, when `CONNECTED`, if `millis() - s_last_ping > HEARTBEAT_MS` (10000 ms) the firmware sends `s_client.ping()` and resets the timer ([net_ws.cpp:537–542, 195](tutor_lamp/net_ws.cpp#L537)). `GotPong` events refresh `s_last_ping` ([net_ws.cpp:353–354](tutor_lamp/net_ws.cpp#L353)). The library auto-replies to inbound pings.

### 3.13 OTA firmware self-update (`ota`)

New in `e1de15a`: the lamp can flash **itself** over the air — no cable, no server push. It is a separate HTTPS pull (not over the WebSocket), on the **same backend host** as pairing/WS (both derive from `BACKEND_SERVER_HOST` → `PROVISIONING_BACKEND_URL`). `ota::check_boot()` ([ota.cpp:78-152](tutor_lamp/ota.cpp#L78)) is called **once** in `setup()`, deliberately after WiFi associates but **before** `net::begin()` — a guaranteed-quiet window where no turn/camera/audio/TTS/TFT-stream/upload is in flight and the WSS TLS heap isn't allocated yet, so an update cannot disturb the runtime ([ota.h:11-26](tutor_lamp/ota.h#L11)).

Flow:

1. **Fast probe** — `GET …/lamp/ota/version` (plain text: line 1 = version int, line 2 = `.bin` URL) with a short `OTA_PROBE_TIMEOUT_MS = 5000` so a slow/asleep/unreachable backend never freezes boot; any non-200/garbage just returns and boot continues ([ota.cpp:96-110](tutor_lamp/ota.cpp#L96)).
2. **Version gate** — proceeds only if the reported version `> FIRMWARE_VERSION` (in `ota.h`, default `4` as of `c699e72`, bumped per release) and the URL looks valid.
3. **Anti-loop** — an NVS key `tried_ver` (namespace `ota`) remembers the last version attempted; if the same version is offered again while the firmware still reports the old number (a mismatched published `.bin`), it skips with a loud log instead of re-downloading forever ([ota.cpp:113-129](tutor_lamp/ota.cpp#L113)).
4. **Download + flash + reboot** — `HTTPUpdate` **streams** the `.bin` straight into the spare OTA partition (never buffers the whole image in RAM), **verifies** it before switching, and reboots into it; a truncated/corrupt download is rejected (never a half-flashed brick). A full-screen "Updating… NN%" progress bar is painted via `tft_ui::tft_handle()` (`set_external_drawing(true)` stops the UI repainting over it); on failure it restores the UI and boots normally ([ota.cpp:131-152](tutor_lamp/ota.cpp#L131)).

**Safety guards:** refuses to run if WiFi is down or free heap `< OTA_MIN_FREE_HEAP = 60000` (no OOM crash on a tight boot); TLS uses `setInsecure()` (matching the WS — the device JWT is the real auth, Render's chain isn't pinned); a stalled download aborts after `OTA_DOWNLOAD_TIMEOUT_MS = 20000`. **Bootstrap once via USB** with an OTA partition scheme (e.g. N16R8 → 16 MB flash, `default_8MB` 3 MB×2 APP); every future update is then over-the-air. See boot placement in [00 §8 step 10](00-overview-and-architecture.md#8-boot--setup-sequence-step-by-step).

---

## 4. Camera capture pipeline

### 4.1 Hardware and pin map

The board is selected in [board_config.h:16](tutor_lamp/board_config.h#L16) as `CAMERA_MODEL_ESP32S3_EYE`, which pulls in the matching pin block from [camera_pins.h:297–315](tutor_lamp/camera_pins.h#L297):

```
XCLK=15  SIOD(SDA)=4  SIOC(SCL)=5
Y2=11 Y3=9 Y4=8 Y5=10 Y6=12 Y7=18 Y8=17 Y9=16
VSYNC=6  HREF=7  PCLK=13   PWDN=-1  RESET=-1
```

`PWDN_GPIO_NUM = -1` means there is **no hardware power-down pin** on this board — that is why software standby (§4.5) is the only power-saving option ([camera.cpp:48–49](tutor_lamp/camera.cpp#L48)). The camera_pins.h file is the upstream Espressif multi-board table; only the `ESP32S3_EYE` branch is compiled. No pins collide with mic (1, 39, 40), speaker (38), buttons (2), or LED (48) ([camera.h:24–26](tutor_lamp/camera.h#L24)).

### 4.2 Init: resolution, format, JPEG, PSRAM

`cam::begin()` builds a `camera_config_t` ([camera.cpp:339–384](tutor_lamp/camera.cpp#L339)):

- `pixel_format = PIXFORMAT_JPEG` — the sensor emits JPEG directly ([camera.cpp:364](tutor_lamp/camera.cpp#L364)).
- `xclk_freq_hz = 10_000_000` (10 MHz) — "cool sensor, no FB-OVF at UXGA" ([camera.cpp:362–363](tutor_lamp/camera.cpp#L362)).
- `fb_location = CAMERA_FB_IN_PSRAM`.
- **With PSRAM:** `frame_size = FRAMESIZE_UXGA` (1600×1200), `jpeg_quality = 10`, `fb_count = 2`, `grab_mode = CAMERA_GRAB_WHEN_EMPTY` ([camera.cpp:367–372](tutor_lamp/camera.cpp#L367)). UXGA buffers are reserved up front so a later resize is cheap.
- **Without PSRAM (fallback):** `FRAMESIZE_SVGA`, DRAM, `fb_count = 1` ([camera.cpp:373–379](tutor_lamp/camera.cpp#L373)).

After `esp_camera_init`, it reads the sensor PID and logs whether it matches `OV5640_PID` ([camera.cpp:386–392](tutor_lamp/camera.cpp#L386)).

**Why capture at SVGA, not UXGA** ([camera.cpp:233–245](tutor_lamp/camera.cpp#L233)): net_ws ultimately pushes the JPEG over the socket, and the WS/LwIP stack needs ~payload-sized contiguous DRAM (PSRAM is not usable by WiFi). With everything live there's only ~128 KB free DRAM — a UXGA q=10 JPEG (100–180 KB) starves LwIP and the socket dies mid-send. SVGA (800×600) q=10 yields **25–40 KB** JPEGs — plenty for any multimodal LLM (which downsample to ~768²–1024² internally anyway), and small enough to send. The reserved UXGA buffers are wasted PSRAM but harmless given 5+ MB free.

### 4.3 The "smart algo": idle/capture/standby cycle

The sensor is kept cool by cycling resolution + power. Three steps ([camera.cpp:394–408, 246–310](tutor_lamp/camera.cpp#L394)):

- **STEP 1 (post-init):** drop to `FRAMESIZE_VGA` + idle tunings (`apply_idle_settings`, §4.8) and enter software standby ([camera.cpp:406–407, 438](tutor_lamp/camera.cpp#L406)).
- **STEP 2 (capture moment):** wake, bump to `FRAMESIZE_SVGA` + document tunings (`apply_doc_settings`), grab ([camera.cpp:259–264](tutor_lamp/camera.cpp#L259)).
- **STEP 3 (after grab):** immediately drop back to VGA idle + standby. The fb is PSRAM-resident and remains valid until `esp_camera_fb_return`, so the sensor needn't stay active while the main loop ships it ([camera.cpp:300–308](tutor_lamp/camera.cpp#L300)).

### 4.4 Autofocus + VCM algorithm

The OV5640 AF runs as a firmware blob in the sensor's MCU SRAM, talked to over SCCB registers. Constants ([camera.cpp:28–38](tutor_lamp/camera.cpp#L28)): `REG_AF_CMD=0x3022`, `REG_AF_ACK=0x3023`, `REG_AF_STAT=0x3029`, `REG_VCM_HI=0x3602`, `REG_VCM_LO=0x3603`; commands `AF_CMD_SINGLE=0x03`, `AF_CMD_RELEASE=0x08`; status `AF_STAT_FOCUSED=0x10`, `AF_STAT_IDLE=0x70`, `AF_STAT_FAIL=0x40`.

`af_send_cmd()` writes the command + ACK byte and polls `REG_AF_ACK` until it reads back `0x00` (command consumed), up to a 500 ms timeout, calling `pump_busy()` + `delay(5)` between reads ([camera.cpp:120–130](tutor_lamp/camera.cpp#L120)).

`trigger_autofocus()` ([camera.cpp:145–179](tutor_lamp/camera.cpp#L145)): releases, sends single-shot AF, then polls `REG_AF_STAT` for up to `AF_TIMEOUT_MS = 4000`. `0x10` ⇒ lock (returns true); `(st & 0x40) && (st & 0x0F)==0` ⇒ fail; `0x70` ⇒ idle (returns whether a focus was seen). Poll interval is `delay(40)` ([camera.cpp:174–176](tutor_lamp/camera.cpp#L174)).

`vcm_write_pos()` clamps a lens position into `[FOCUS_MIN=0x0000, FOCUS_MAX=0x01FF]`, writes the 10-bit value across the two VCM registers, and issues a single AF command ([camera.cpp:137–143](tutor_lamp/camera.cpp#L137)).

**Boot-time AF lock strategy:** because the lamp is a fixed desk fixture, AF is run **once** at startup and the VCM motor is then left at that position for the whole session — `s_first_capture_done` is set and subsequent captures skip AF, saving ~1.5 s per shot ([camera.cpp:412–429](tutor_lamp/camera.cpp#L412)). The lens is parked at `FOCUS_PARK = 0x0080` if AF firmware loads ([camera.cpp:416](tutor_lamp/camera.cpp#L416)). AF-load failure is non-fatal — capture continues in manual focus at the parked position ([camera.cpp:426–429](tutor_lamp/camera.cpp#L426)).

### 4.5 Software standby (power/heat)

`REG_SYS_CTRL = 0x3008` bit 6 (`SYS_CTRL_STANDBY = 0x40`) puts the analog/digital signal-path blocks into low-power idle while keeping the MCU SRAM (AF firmware) and register file (VCM position + settings) alive ([camera.cpp:40–52](tutor_lamp/camera.cpp#L40)). So on wake there's no need to reload AF firmware or re-focus. `sensor_enter_standby()` is idempotent ([camera.cpp:95–99](tutor_lamp/camera.cpp#L95)); `sensor_wake_from_standby()` clears the bit and waits `STANDBY_WAKE_MS = 40` ms for the analog blocks to settle (skipping the delay caused garbled first frames) ([camera.cpp:104–110](tutor_lamp/camera.cpp#L104)).

### 4.6 Capture pipeline + FB-OVF recovery

`do_capture_pipeline()` is shared by the sync and async paths ([camera.cpp:246–310](tutor_lamp/camera.cpp#L246)):

1. Wake from standby; `set_framesize(SVGA)` (bail to standby on failure); `apply_doc_settings`.
2. **Grab with FB-OVF retry.** `grab_after_flush(2, settle)` discards 2 stale frames (60 ms apart) then grabs ([camera.cpp:223–231](tutor_lamp/camera.cpp#L223)). First settle is **500 ms**, retries **250 ms**.
3. On grab failure (FB-OVF = JPEG FIFO overflow), bump quality up by `QUALITY_STEP = 2` toward `QUALITY_WORST = 30` (a higher number = lower quality = smaller frame, less likely to overflow), `delay(300)`, retry. After `MAX_OVF_RETRIES = 3` it gives up, drops to VGA idle + standby, returns false ([camera.cpp:266–292](tutor_lamp/camera.cpp#L266)).
4. On success, log `WxH len q ms`, store `s_held_fb`, drop to VGA idle + standby, return true.

Quality tunables: `QUALITY_BEST=8`, `QUALITY_DEFAULT=10`, `QUALITY_WORST=30`, `QUALITY_STEP=2` ([camera.cpp:17–20](tutor_lamp/camera.cpp#L17)). `MAINS_HZ = 50` drives the anti-banding filter ([camera.cpp:25, 181–186](tutor_lamp/camera.cpp#L181)).

### 4.7 Async worker, cross-core handoff & memory fences

The worker task runs on **core 0** at priority 5 (below WiFi ~22–23, above idle), 8 KB stack ([camera.cpp:441–456](tutor_lamp/camera.cpp#L441)). It sleeps on a binary semaphore `s_worker_kick` until `grab_async()` gives it, runs the pipeline, publishes `(s_async_buf, s_async_len)`, then sets `s_async_state` ([camera.cpp:313–332](tutor_lamp/camera.cpp#L313)).

The state machine `GrabState` is `GRAB_IDLE → GRAB_BUSY → GRAB_READY/GRAB_FAILED → (release) → GRAB_IDLE` ([camera.h:122–127](tutor_lamp/camera.h#L122)). The cross-core handoff uses **C11 atomics with explicit memory ordering**, not plain volatile, because on Xtensa LX7 a volatile bool gives no inter-core ordering — the reader could see `state=READY` before the buf/len stores propagate, picking up stale pointers ([camera.cpp:75–88](tutor_lamp/camera.cpp#L75)):

- Worker: `__atomic_store_n(&s_async_state, GRAB_READY, __ATOMIC_RELEASE)` — a release fence (MEMW) flushes the buf/len stores before the state becomes visible ([camera.cpp:325, 329](tutor_lamp/camera.cpp#L325)).
- Main: `get_state()` / `get_result()` use `__ATOMIC_ACQUIRE` so once READY is observed, the buf/len reads see the worker's writes ([camera.cpp:526–541](tutor_lamp/camera.cpp#L526)).

`grab_async()` accepts only from `GRAB_IDLE`, transitions to `GRAB_BUSY` (release), and kicks the semaphore — non-blocking, returns within microseconds ([camera.cpp:514–524](tutor_lamp/camera.cpp#L514)). `release()` returns the fb to the pool, re-asserts VGA idle + standby (idempotent), and resets state to IDLE; it defensively ignores a call made during `GRAB_BUSY` ([camera.cpp:482–511](tutor_lamp/camera.cpp#L482)).

### 4.8 Sensor tunings (document mode)

`apply_doc_settings()` ([camera.cpp:189–213](tutor_lamp/camera.cpp#L189)) sets a document-friendly profile: quality `s_quality`, brightness 0, contrast +1, saturation −1, sharpness +1, denoise on, full AWB + AEC2 + AGC, BPC/WPC/raw-gamma/LENC/DCW on, `hmirror` on, `vflip` off, plus anti-banding. `apply_anti_banding()` programs the 50 Hz mains filter via regs `0x3c01/0x3c00/0x3a00` ([camera.cpp:181–186](tutor_lamp/camera.cpp#L181)). `apply_idle_settings()` is the low-power profile (quality 12, neutral contrast/saturation/sharpness, hmirror only) used between captures ([camera.cpp:215–221](tutor_lamp/camera.cpp#L215)).

---

## 5. Button input model

### 5.1 ADC resistor-ladder decode

Five physical buttons share **one ADC pin** (`BUTTONS_ADC_PIN = 2`) via a resistor ladder, so each button produces a distinct voltage ([buttons.h:6–13, 26–28](tutor_lamp/buttons.h#L6)). `begin()` sets max attenuation so the full 0–3.3 V range is readable ([buttons.cpp:37–40](tutor_lamp/buttons.cpp#L37)):

```cpp
analogSetPinAttenuation(BUTTONS_ADC_PIN, ADC_ATTENDB_MAX);
```

`decode(adc)` maps the 12-bit reading to a button by ascending thresholds ([buttons.cpp:6–31](tutor_lamp/buttons.cpp#L6)):

| ADC reading | Threshold const | Logical button | Physical |
|---|---|---|---|
| `< 200` | `THRESH_1` | `BTN_LEFT` | Button 1 |
| `< 600` | `THRESH_2` | `BTN_SELECT` | Button 2 (centre) |
| `< 1100` | `THRESH_3` | `BTN_DOWN` | Button 3 |
| `< 1700` | `THRESH_4` | `BTN_RIGHT` | Button 4 |
| `< 2800` | `THRESH_5` | `BTN_UP` | Button 5 |
| `≥ 2800` | — | `BTN_NONE` | no press (~3.3 V → 4095) |

Note the BTN3/BTN4 swap: the logical `Button` enum IDs are stable and do **not** renumber with the physical→direction mapping — physical Button 3 yields `BTN_DOWN`, Button 4 yields `BTN_RIGHT` ([buttons.h:47–60](tutor_lamp/buttons.h#L47), [buttons.cpp:26–28](tutor_lamp/buttons.cpp#L26)). The `Button` enum: `BTN_NONE=0, BTN_LEFT=1, BTN_SELECT=2, BTN_RIGHT=3, BTN_DOWN=4, BTN_UP=5, BTN_SELECT_LONG=6`, plus the directional long-presses `BTN_DOWN_LONG=7, BTN_UP_LONG=8, BTN_LEFT_LONG=9` (all `e1de15a`) used to drive the graph page, and — new in `c699e72` — `BTN_RIGHT_LONG=10`: Right held ≥ hold-threshold (fires once), used by the scroll-doc to open the graph arena ([buttons.h:57–61](tutor_lamp/buttons.h#L57)).

### 5.2 Debounce algorithm

`poll()` is rate-limited to once per `BUTTONS_POLL_MS = 30` ms ([buttons.cpp:47–50, buttons.h:29–31](tutor_lamp/buttons.cpp#L47)). A reading must stay steady for `BUTTONS_DEBOUNCE_MS = 50` ms before it is accepted as the new stable state ([buttons.h:32–34](tutor_lamp/buttons.h#L32)). The candidate-timestamp algorithm ([buttons.cpp:70–91](tutor_lamp/buttons.cpp#L70)):

```cpp
if (raw != s_candidate) {                 // reading changed → restart timer
    s_candidate = raw; s_candidate_since = now; return;
}
if (now - s_candidate_since < BUTTONS_DEBOUNCE_MS) return;  // not steady long enough
if (raw == s_last_stable) return;         // already the stable state → no edge
s_last_stable = raw;                       // commit new stable state
...
if (raw != BTN_NONE && s_cb) s_cb(raw);   // EDGE: fire only on a fresh press
```

The event fires **only on the rising edge** (NONE → button), never on release, so a long hold doesn't spam events ([buttons.cpp:89–91](tutor_lamp/buttons.cpp#L89), [buttons.h:15–17](tutor_lamp/buttons.h#L15)).

### 5.3 Long-press gesture (SELECT + directional)

Long-press runs independently of the edge detection above. As of `e1de15a` it is **generalized** from SELECT-only to any button that has a long variant: a `long_variant(b)` map returned `BTN_SELECT_LONG`/`BTN_UP_LONG`/`BTN_DOWN_LONG`/`BTN_LEFT_LONG` (RIGHT had none). **`c699e72`** closes that gap, adding `case BTN_RIGHT: return BTN_RIGHT_LONG;` so RIGHT now has a long variant too ([buttons.cpp:26–33](tutor_lamp/buttons.cpp#L26)). When a long-capable button becomes the stable state, the hold timer arms (`s_hold_press_ms = now`, `s_hold_long_fired = false`). On each poll, if the same button is still the stable state and `(now - s_hold_press_ms) >= BUTTONS_LONG_PRESS_MS` (default **1500 ms**), it fires the corresponding `*_LONG` event **exactly once** and sets `s_hold_long_fired`. Any other stable transition (release to NONE or a different button) tears down the in-flight hold. The short-press event still fires immediately on press, so cancel-in-flight (SELECT) and the graph zoom/toggle long-presses (UP/DOWN/LEFT/RIGHT) coexist. See [tft_ui §3.7](02-display-and-ui.md) / [§4.7](02-display-and-ui.md) for how the directional long-presses drive the graph page, and [§4.9](02-display-and-ui.md) for `BTN_RIGHT_LONG` opening the graph arena from the scroll document.

### 5.4 held() and hold-to-talk

`held()` returns the currently debounced button (`s_last_stable`, `BTN_NONE` on release) ([buttons.cpp:44–45](tutor_lamp/buttons.cpp#L44)). Because `on_event()` is edge-only, `held()` is what enables **hold-to-talk**: the orchestrator starts a turn on the `BTN_UP` *event*, then ends it the instant `held() != BTN_UP` ([buttons.h:66–72](tutor_lamp/buttons.h#L66), [tutor_lamp.ino:1448](tutor_lamp/tutor_lamp.ino#L1448)). `held()` reflects a release after ~one debounce window.

### 5.5 Action mapping in the orchestrator

`buttons::on_event` is registered with a lambda ([tutor_lamp.ino:1170–1244](tutor_lamp/tutor_lamp.ino#L1170)). Events route by current UI page/mode:

- **`BTN_SELECT_LONG`** → open Settings, but only on the idle face when not speaking ([tutor_lamp.ino:1191–1197](tutor_lamp/tutor_lamp.ino#L1191)).
- **`BTN_UP`** on `PAGE_IDLE` while idle → `begin_command_turn("UP button")` and set `s_ptt_active` (push-to-talk); on other pages → `tft_ui::on_button(BTN_UP)` ([tutor_lamp.ino:1200–1212](tutor_lamp/tutor_lamp.ino#L1200)).
- **`BTN_DOWN/LEFT/RIGHT/SELECT`** → `tft_ui::on_button(...)` for list/menu navigation ([tutor_lamp.ino:1213–1224](tutor_lamp/tutor_lamp.ino#L1213)).
- **`BTN_SELECT` during an active turn** (MODE_COMMAND/MODE_SENDING or speaker playing) → **cancel**: `net::send_frame(FRAME_CANCEL)`, `net::abort_image_send()`, stop the speaker, reset to MODE_IDLE ([tutor_lamp.ino:1231–1244](tutor_lamp/tutor_lamp.ino#L1231)).

Text-entry and settings screens intercept buttons first via their own `on_button` handlers ([tutor_lamp.ino:1175, 1184](tutor_lamp/tutor_lamp.ino#L1175)). The callback runs synchronously in loop() context, so it must return quickly ([buttons.h:18–21](tutor_lamp/buttons.h#L18)).

---

## 6. File-by-file, function-by-function

### net_ws.h / net_ws.cpp

| Symbol | Location | Role |
|---|---|---|
| `FrameType` enum | [net_ws.h:54](tutor_lamp/net_ws.h#L54) | All 20 frame types (§3.2). |
| `ConnState` enum | [net_ws.h:76](tutor_lamp/net_ws.h#L76) | 5 connection states. |
| `InsecureWssTcpClient` | [net_ws.cpp:69](tutor_lamp/net_ws.cpp#L69) | Subclass that fixes setInsecure + handshake-read + diag dumps (§3.4). |
| `parse_ws_url()` | [net_ws.cpp:247](tutor_lamp/net_ws.cpp#L247) | Split URL → secure/host/port/path. |
| `encode_header()` | [net_ws.cpp:264](tutor_lamp/net_ws.cpp#L264) | Pack 4-byte frame header. |
| `on_ws_message()` | [net_ws.cpp:271](tutor_lamp/net_ws.cpp#L271) | RX validate + dispatch + auth-reset. |
| `schedule_backoff()` | [net_ws.cpp:289](tutor_lamp/net_ws.cpp#L289) | Jittered exponential backoff. |
| `on_ws_event()` | [net_ws.cpp:314](tutor_lamp/net_ws.cpp#L314) | Open/Close/Pong handling + auth-giveup count. |
| `do_connect()` | [net_ws.cpp:361](tutor_lamp/net_ws.cpp#L361) | 3-arg connect; FATAL on missing host/JWT. |
| `note_tx_drop()` | [net_ws.cpp:423](tutor_lamp/net_ws.cpp#L423) | Rate-limited TX-drop logging. |
| `drain_tx_queue()` | [net_ws.cpp:436](tutor_lamp/net_ws.cpp#L436) | Pop ≤N queued frames → sendBinary. |
| `begin()` | [net_ws.cpp:461](tutor_lamp/net_ws.cpp#L461) | One-time init (queue, PSRAM buf, client swap, header). |
| `connect()` | [net_ws.cpp:503](tutor_lamp/net_ws.cpp#L503) | Idempotent open. |
| `loop()` | [net_ws.cpp:511](tutor_lamp/net_ws.cpp#L511) | poll + image pump + drain + heartbeat. |
| `send_frame()` | [net_ws.cpp:547](tutor_lamp/net_ws.cpp#L547) | Queue (small) / PSRAM-direct (large). |
| `send_image_chunked()` | [net_ws.cpp:582](tutor_lamp/net_ws.cpp#L582) | Blocking chunked image sender. |
| `begin_image_send()` / `pump_image_send()` / `abort_image_send()` / `ack_image_send()` | [net_ws.cpp:697–774](tutor_lamp/net_ws.cpp#L697) | Async non-blocking chunked image sender. |
| `on_frame/on_state/on_auth_giveup/state` | [net_ws.cpp:776–779](tutor_lamp/net_ws.cpp#L776) | Callback registration + state getter. |

### camera.h / camera.cpp / camera_pins.h

| Symbol | Location | Role |
|---|---|---|
| `GrabState` enum | [camera.h:122](tutor_lamp/camera.h#L122) | Async capture states. |
| AF/VCM/standby constants | [camera.cpp:17–54](tutor_lamp/camera.cpp#L17) | Quality, focus, registers, mains. |
| `sensor_enter/wake_from_standby()` | [camera.cpp:95, 104](tutor_lamp/camera.cpp#L95) | Software standby (§4.5). |
| `af_send_cmd/af_release/vcm_write_pos/trigger_autofocus()` | [camera.cpp:120–179](tutor_lamp/camera.cpp#L120) | AF/VCM (§4.4). |
| `apply_anti_banding/doc_settings/idle_settings()` | [camera.cpp:181–221](tutor_lamp/camera.cpp#L181) | Sensor tunings (§4.8). |
| `grab_after_flush()` | [camera.cpp:223](tutor_lamp/camera.cpp#L223) | Flush stale frames + grab. |
| `do_capture_pipeline()` | [camera.cpp:246](tutor_lamp/camera.cpp#L246) | Smart algo + FB-OVF recovery. |
| `worker_task()` | [camera.cpp:313](tutor_lamp/camera.cpp#L313) | Core-0 capture worker. |
| `begin()` | [camera.cpp:339](tutor_lamp/camera.cpp#L339) | Init, AF lock, spawn worker. |
| `grab_jpeg/release/grab_async/get_state/get_result()` | [camera.cpp:464–541](tutor_lamp/camera.cpp#L464) | Sync + async public API. |
| Pin tables | [camera_pins.h](tutor_lamp/camera_pins.h) | Multi-board GPIO map (ESP32S3_EYE used). |

### buttons.h / buttons.cpp

| Symbol | Location | Role |
|---|---|---|
| `Button` enum | [buttons.h:50](tutor_lamp/buttons.h#L50) | Stable logical IDs incl. `BTN_SELECT_LONG`. |
| Thresholds | [buttons.cpp:6–11](tutor_lamp/buttons.cpp#L6) | ADC ladder boundaries. |
| `decode()` | [buttons.cpp:24](tutor_lamp/buttons.cpp#L24) | ADC → Button. |
| `begin()` | [buttons.cpp:37](tutor_lamp/buttons.cpp#L37) | ADC attenuation. |
| `on_event/held()` | [buttons.cpp:42, 44](tutor_lamp/buttons.cpp#L42) | Callback registration / current hold. |
| `poll()` | [buttons.cpp:47](tutor_lamp/buttons.cpp#L47) | Rate-limit, decode, long-press, debounce, edge. |

---

## 7. Configuration & constants reference

| Constant / macro | Value | Defined in | Effect |
|---|---|---|---|
| `NET_WS_URL` | `wss://…/lamp/ws` or `ws://…` | [backend_config.h](tutor_lamp/backend_config.h#L69) | Backend socket endpoint. |
| `BACKEND_USE_SERVER` | `1` | [backend_config.h:34](tutor_lamp/backend_config.h#L34) | 1=Render wss, 0=LAN ws. |
| `NET_WS_TLS_INSECURE` | `1` | [net_ws.h:33](tutor_lamp/net_ws.h#L33) | `setInsecure()` vs bundled CA. |
| `NET_WS_HANDSHAKE_READ_MS` | `10000` | [net_ws.cpp:42](tutor_lamp/net_ws.cpp#L42) | wss handshake read budget. |
| `NET_WS_IMAGE_CHUNK_GAP_MS` | `20` | [net_ws.cpp:53](tutor_lamp/net_ws.cpp#L53) | Per-chunk pace gap. |
| `NET_WS_IMAGE_SEND_MAX_MS` | `8000` (cpp) / `15000` (h) | [net_ws.cpp:66](tutor_lamp/net_ws.cpp#L66), [net_ws.h:45](tutor_lamp/net_ws.h#L45) | Hard image-upload cap. |
| `NET_WS_AUTH_GIVEUP_THRESHOLD` | `8` | [net_ws.cpp:231](tutor_lamp/net_ws.cpp#L231) | Empty disconnects → wipe JWT. |
| `TX_PAYLOAD_MAX_Q` | `1024` | [net_ws.cpp:190](tutor_lamp/net_ws.cpp#L190) | Queue vs direct-send threshold. |
| `TX_Q_DEPTH` | `40` | [net_ws.cpp:192](tutor_lamp/net_ws.cpp#L192) | TX queue slots (~41 KB). |
| `TX_ASSEMBLE_BYTES` | `262144` | [net_ws.cpp:193](tutor_lamp/net_ws.cpp#L193) | PSRAM large-frame buffer. |
| `TX_DRAIN_PER_LOOP` | `8` | [net_ws.cpp:194](tutor_lamp/net_ws.cpp#L194) | Frames drained per pass. |
| `HEARTBEAT_MS` | `10000` | [net_ws.cpp:195](tutor_lamp/net_ws.cpp#L195) | Ping interval. |
| `BACKOFF_INIT_MS / MAX_MS` | `2000` / `30000` | [net_ws.cpp:196](tutor_lamp/net_ws.cpp#L196) | Reconnect schedule. |
| `IMAGE_CHUNK_BYTES` | `1024` | [net_ws.cpp:604, 746](tutor_lamp/net_ws.cpp#L604) | Image chunk size. |
| `MIC_WIRE_ADPCM` | `1` | [tutor_lamp.ino:364](tutor_lamp/tutor_lamp.ino#L364) | Uplink codec selector. |
| `xclk_freq_hz` | `10 MHz` | [camera.cpp:363](tutor_lamp/camera.cpp#L363) | Cool sensor clock. |
| capture frame size | `SVGA` (capture), `VGA` (idle), `UXGA` (reserve) | [camera.cpp:259, 306, 369](tutor_lamp/camera.cpp#L259) | Resolution policy. |
| `QUALITY_DEFAULT/STEP/WORST` | `10/2/30` | [camera.cpp:18–19](tutor_lamp/camera.cpp#L18) | JPEG quality + FB-OVF backoff. |
| `AF_TIMEOUT_MS` | `4000` | [camera.cpp:21](tutor_lamp/camera.cpp#L21) | AF poll timeout. |
| `FOCUS_PARK` | `0x0080` | [camera.cpp:23](tutor_lamp/camera.cpp#L23) | Parked lens position. |
| `MAX_OVF_RETRIES` | `3` | [camera.cpp:26](tutor_lamp/camera.cpp#L26) | FB-OVF retry cap. |
| `STANDBY_WAKE_MS` | `40` | [camera.cpp:52](tutor_lamp/camera.cpp#L52) | Analog settle after wake. |
| `BUTTONS_ADC_PIN` | `2` | [buttons.h:27](tutor_lamp/buttons.h#L27) | Resistor-ladder pin. |
| `BUTTONS_POLL_MS` | `30` | [buttons.h:30](tutor_lamp/buttons.h#L30) | Poll rate limit. |
| `BUTTONS_DEBOUNCE_MS` | `50` | [buttons.h:33](tutor_lamp/buttons.h#L33) | Debounce steady time. |
| `BUTTONS_LONG_PRESS_MS` | `1500` | [buttons.h:42](tutor_lamp/buttons.h#L42) | SELECT long-press threshold. |
| `THRESH_1..5` | `200/600/1100/1700/2800` | [buttons.cpp:6–10](tutor_lamp/buttons.cpp#L6) | ADC decode boundaries. |

---

## 8. Edge cases, errors, timeouts, fallbacks

- **`connect()` returns false (no 101):** ambiguous (TLS/network/heap or pre-accept 403). Logs free-heap + guidance ("no /lamp/ws hit ⇒ TLS/network, not JWT"), schedules backoff, **does not** count toward auth-giveup ([net_ws.cpp:384–400](tutor_lamp/net_ws.cpp#L384)).
- **Repeated empty disconnects (8×):** assumed stale JWT → fire `on_auth_giveup` → wipe + reboot into pairing ([net_ws.cpp:340–348](tutor_lamp/net_ws.cpp#L340)).
- **TX queue full / socket down:** `send_frame` drops silently, counts via `note_tx_drop` (one log/sec) ([net_ws.cpp:548–562](tutor_lamp/net_ws.cpp#L548)). Audio drops repaired by EOS full-resend ([tutor_lamp.ino:1706–1764](tutor_lamp/tutor_lamp.ino#L1706)).
- **Image upload too slow:** abandoned past `NET_WS_IMAGE_SEND_MAX_MS`; partial accumulator flushed with bare terminator; turn continues audio-only ([net_ws.cpp:615–630, 740–743](tutor_lamp/net_ws.cpp#L615)).
- **Socket dies mid image-send:** async sender → `IMG_FAILED`, no flush (server session dies anyway) ([net_ws.cpp:734–738](tutor_lamp/net_ws.cpp#L734)).
- **Runt / over-length RX frame:** dropped silently (`len < 4` or header > delivered) ([net_ws.cpp:273–279](tutor_lamp/net_ws.cpp#L273)).
- **Camera FB-OVF:** auto-lower quality (×3) then give up gracefully; caller proceeds audio-only ([camera.cpp:269–292](tutor_lamp/camera.cpp#L269), [tutor_lamp.ino:1575–1578](tutor_lamp/tutor_lamp.ino#L1575)).
- **AF firmware load fails:** non-fatal, manual focus at parked lens ([camera.cpp:426–429](tutor_lamp/camera.cpp#L426)).
- **No PSRAM:** camera falls back to SVGA/DRAM/fb_count=1; net_ws warns "large frames disabled" if the PSRAM assemble alloc fails ([camera.cpp:373–379](tutor_lamp/camera.cpp#L373), [net_ws.cpp:471–475](tutor_lamp/net_ws.cpp#L471)).
- **Late camera capture (turn already ended):** discarded so it can't attach to the next turn ([tutor_lamp.ino:1544–1551](tutor_lamp/tutor_lamp.ino#L1544)).
- **`release()` during BUSY:** ignored to avoid leaking the fb ([camera.cpp:488–492](tutor_lamp/camera.cpp#L488)).
- **Button ghost flicker:** absorbed by the 50 ms debounce; long-press uses stable state so flicker doesn't break a hold ([buttons.cpp:55–75](tutor_lamp/buttons.cpp#L55)).

---

## 9. Integration points

**net_ws calls:**
- ArduinoWebsockets `WebsocketsClient` (connect/poll/sendBinary/ping/onMessage/onEvent).
- `WiFiClientSecure::setInsecure()` via the subclass.
- The registered `on_frame_cb` (→ `handle_server_frame` in the .ino), `on_state_cb` (→ `on_net_state`), `on_auth_giveup_cb` (→ wipe JWT + reboot).

**net_ws is called by:**
- `tutor_lamp.ino` setup: `net::begin(NET_WS_URL, ws_jwt)`, `on_frame/on_state/on_auth_giveup`, `set_image_send_hook(tft_ui::tick)`, `connect()` ([tutor_lamp.ino:1345–1376](tutor_lamp/tutor_lamp.ino#L1345)).
- The mic capture task → `send_frame(FRAME_AUDIO_CHUNK_ADPCM/CHUNK, …)` ([tutor_lamp.ino:379, 382](tutor_lamp/tutor_lamp.ino#L379)).
- loop(): `net::loop()`, image `begin_image_send/ack_image_send/abort_image_send/image_send_state`, `send_frame(FRAME_AUDIO_END/RESET/CANCEL)`, `tx_drop_count()`.

**camera ↔ net_ws / .ino:** `begin_command_turn` fires `cam::grab_async()`; loop() polls `get_state/get_result`, previews locally (`tft_ui::on_image_jpeg`), then `net::begin_image_send(jpg,len)`, keeping the fb alive until completion then `cam::release()` ([tutor_lamp.ino:1130–1141, 1510–1571](tutor_lamp/tutor_lamp.ino#L1130)).

**buttons ↔ .ino:** `buttons::begin/on_event/poll/held` drive push-to-talk, cancel, settings, and UI navigation ([tutor_lamp.ino:1169–1244, 1436–1448](tutor_lamp/tutor_lamp.ino#L1169)).

**Backend (cross-system):** the server accepts `wss://<host>/lamp/ws` with `Authorization: Bearer <jwt>`, validates signature/expiry/device_id, accumulates `IMAGE_PART`→`IMAGE_JPEG` (JPEG magic check drops corrupt assemblies), decodes per-turn ADPCM, and streams TTS/TFT/STATE downlink ([IMPLEMENTATION_WEBSOCKET.md §10](IMPLEMENTATION_WEBSOCKET.md), [net_ws.h:60–61](tutor_lamp/net_ws.h#L60)). Provisioning/NVS supplies the JWT and is the recovery target on auth-giveup ([tutor_lamp.ino:1311, 1371](tutor_lamp/tutor_lamp.ino#L1311)).

---

## 10. Diagrams

### 10.1 Connection lifecycle (state machine)

```mermaid
stateDiagram-v2
    [*] --> NET_DISCONNECTED
    NET_DISCONNECTED --> NET_CONNECTING: connect() / do_connect()
    NET_CONNECTING --> NET_FATAL: missing host or JWT
    NET_CONNECTING --> NET_CONNECTED: ConnectionOpened (101)
    NET_CONNECTING --> NET_BACKOFF: connect()==false (no 101)
    NET_CONNECTED --> NET_BACKOFF: ConnectionClosed
    NET_BACKOFF --> NET_CONNECTING: backoff timer elapsed
    NET_BACKOFF --> NET_BACKOFF: 8 empty disconnects -> on_auth_giveup -> wipe JWT + reboot
    note right of NET_BACKOFF
      2s,4s,8s,16s,30s,30s... +-25% jitter
      reset to 2s on each open
    end note
```

### 10.2 One multimodal turn (sequence)

```mermaid
sequenceDiagram
    participant BTN as buttons (poll, core1)
    participant INO as tutor_lamp.ino loop (core1)
    participant MIC as mic task (core1 p8)
    participant CAM as cam worker (core0 p5)
    participant NET as net_ws (s_client, core1)
    participant BE as Backend (FastAPI)

    BTN->>INO: BTN_UP event (PAGE_IDLE)
    INO->>INO: begin_command_turn()
    INO->>CAM: cam::grab_async()
    INO->>MIC: pipeline_mode = MODE_COMMAND
    loop per DSP frame
        MIC->>NET: send_frame(AUDIO_CHUNK_ADPCM)  [queued]
    end
    CAM-->>INO: GRAB_READY (acquire fence)
    INO->>NET: begin_image_send(jpg,len)
    loop net::loop() each pass
        NET->>BE: IMAGE_PART (1KB, 20ms gap)
        NET->>BE: drain queued AUDIO_CHUNK_ADPCM
    end
    NET->>BE: IMAGE_JPEG (terminator)
    BTN-->>INO: held() != BTN_UP (release)
    INO->>NET: [if drops] AUDIO_RESET + full resend
    INO->>NET: send_frame(AUDIO_END)
    BE-->>NET: STATE(thinking)
    BE-->>NET: AUDIO_OUT_ADPCM x M
    NET-->>INO: on_frame -> spk::push_pcm
    BE-->>NET: AUDIO_OUT_END + STATE(idle)
```

### 10.3 Camera smart-algo + async handoff (flowchart)

```mermaid
flowchart TD
    A[grab_async: state==IDLE?] -->|no| Z[reject]
    A -->|yes| B[state=BUSY release-store; give semaphore]
    B --> C[worker core0: wake from standby]
    C --> D[set_framesize SVGA + apply_doc_settings]
    D --> E[grab_after_flush 2 frames, settle 500/250ms]
    E -->|fb null| F{tries > MAX_OVF_RETRIES=3?}
    F -->|no| G[quality += 2 toward 30; delay 300; retry]
    G --> E
    F -->|yes| H[VGA idle + standby; state=FAILED]
    E -->|fb ok| I[store s_held_fb; VGA idle + standby]
    I --> J[publish buf/len; state=READY release-store]
    J --> K[main core1 get_state acquire-load == READY]
    K --> L[net::begin_image_send; release fb on completion]
```

---

*End of reference. All behaviour above is taken verbatim from the firmware in `Smart-Tutor-Lamp/tutor_lamp/` and the protocol spec in `IMPLEMENTATION_WEBSOCKET.md`; nothing is inferred beyond what the code states.*
