# Smart Tutor Lamp ("Lumos") — Knowledge Base

This is the master index for the **Smart Tutor Lamp** (codename **Lumos**) — an **ESP32-S3 AI tutoring lamp** that turns a desk lamp into an always-listening tutor for a student working through homework on paper. A child presses a button (or says "hey lumos"), asks a question out loud, and the lamp snaps a photo of the page on the desk; the answer comes back as spoken audio through the lamp's speaker and as text / equations / images on a small TFT screen.

The lamp itself is deliberately "dumb": **no LLM, transcription, or LaTeX rendering runs on-chip**. Instead the device is a thin real-time orchestrator that streams audio + images over a single persistent secure WebSocket to a **FastAPI backend** — the "brain." That backend is a multi-LLM engine with **tiered escalation** (a fast default model that climbs to stronger/thinking/Pro models only when a problem warrants it), **text-to-speech**, and **conversation memory + vector recall**. A **Next.js dashboard** is the human-facing surface (sign-in, onboarding, analytics, device pairing), a **web simulator** lets anyone exercise the brain in a browser without hardware, and a **Supabase/Postgres + pgvector** database is the durable source of truth.

The system is engineered around one non-negotiable goal: **sub-2-second perceived latency** from end-of-speech to first audio / first pixels on the lamp.

---

## System Architecture

```mermaid
graph TB
    subgraph Device["🛋️ Smart Tutor Lamp (ESP32-S3 firmware)"]
        MIC["INMP441 mic + on-device DSP<br/>(wake word, VAD, AGC, NS, ALE)"]
        CAM["OV5640 camera<br/>(JPEG snapshot of page)"]
        BTN["5-way buttons<br/>(push-to-talk)"]
        SPK["MAX98357A speaker"]
        TFT["320×240 TFT<br/>(text / LaTeX / images)"]
        FW["Firmware orchestrator<br/>(state machine, ADPCM codec)"]
        MIC --> FW
        CAM --> FW
        BTN --> FW
        FW --> SPK
        FW --> TFT
    end

    subgraph Backend["🧠 FastAPI Backend (the brain)"]
        WS["Binary WebSocket endpoint<br/>(/ws, per-lamp)"]
        PRE["Pre-router<br/>(deterministic escalation)"]
        ORCH["Turn orchestrator<br/>(guard stack, problem memo)"]
        TIER["Tiered model selection<br/>Flash → Flash-thinking → Pro"]
        TTS["TTS engine<br/>(Gemini / Piper / Cartesia, 24 kHz)"]
        LATEX["Renderers → RGB565<br/>(LaTeX · graphs · RDKit chemistry)"]
        MEM["Memory<br/>(L1 Redis / L2 compaction / L3 profile)"]
        AUTHS["Auth + pairing<br/>(device_jwt / device_secret)"]
        WS --> PRE --> ORCH --> TIER
        ORCH --> TTS
        ORCH --> LATEX
        ORCH --> MEM
        WS -.-> AUTHS
    end

    subgraph Providers["🤖 LLM Providers (swappable)"]
        GEM["Gemini 2.5 Flash / Pro"]
        CLA["Claude"]
        OAI["OpenAI"]
        DS["DeepSeek"]
    end

    subgraph Data["🗄️ Supabase / Postgres + pgvector"]
        DB[("devices · sessions · turns<br/>turn_traces · user_memory<br/>cost_log · model-bench · pgvector")]
    end

    subgraph Web["🌐 Human-facing web (Next.js)"]
        DASH["Dashboard<br/>(analytics, admin, devices)"]
        ONB["Onboarding<br/>(7-question profile)"]
        PAIR["QR pairing<br/>(in-browser scanner)"]
        SIM["Web simulator<br/>(browser stand-in for the lamp)"]
    end

    CLERK["🔐 Clerk<br/>(human identity / sessions)"]

    %% device <-> backend
    FW <-->|"WSS: audio uplink (PCM/ADPCM) + JPEG<br/>audio downlink (paced 24 kHz) + TFT frames"| WS

    %% backend <-> providers
    TIER -->|"multimodal LLM calls"| GEM
    TIER --> CLA
    TIER --> OAI
    TIER --> DS

    %% backend <-> db
    ORCH -->|"reads / writes (fire-and-forget)"| DB
    MEM --> DB

    %% web <-> backend
    DASH -->|"Clerk JWT on every call<br/>(Frontend Manager API)"| Backend
    ONB --> Backend
    PAIR -->|"pairing code → device_jwt"| AUTHS
    SIM -->|"/solve HTTP + /ws binary<br/>(same brain, same protocol)"| Backend
    SIM -.->|"turns tagged source=simulation"| DB

    %% auth
    DASH <--> CLERK
    ONB <--> CLERK
    CLERK -.->|"Svix-signed webhook"| AUTHS

    classDef device fill:#1f2937,stroke:#60a5fa,color:#e5e7eb
    classDef backend fill:#312e2e,stroke:#f59e0b,color:#fde68a
    classDef data fill:#1e293b,stroke:#34d399,color:#d1fae5
    classDef web fill:#2e1065,stroke:#a78bfa,color:#ede9fe
```

**Reading the diagram:** the lamp firmware holds exactly one secure WebSocket open to the backend, carrying audio in/out and JPEG snapshots in both directions (paced audio + chunked TFT pixel frames come back). The backend pre-routes and orchestrates each turn, calls one of four swappable LLM providers (climbing tiers only when needed), synthesizes speech, renders any equations to RGB565 frames, and persists everything to Postgres without ever blocking the live turn. Humans authenticate through **Clerk** on the Next.js dashboard — the lamp itself **never talks to Clerk**; it carries a backend-issued `device_jwt`. The **web simulator** is a browser stand-in for the lamp that drives the very same brain and wire protocol.

---

## Areas

### [00-project-overview](00-project-overview/README.md) — general project overview

Start here when you want the whole product in one place before diving into the detailed subsystem docs. This overview explains what Lumos is, the user and device workflows, the high-level architecture, the student question lifecycle, identity/data boundaries, AI/model architecture, operating principles, and the recommended reading path through the rest of the knowledge base. → **[00-project-overview/README.md](00-project-overview/README.md)**

### [01-firmware](01-firmware/README.md) — ESP32-S3 device

The on-device firmware is a single Arduino/C++ sketch (`tutor_lamp.ino`) running on an ESP32-S3 that turns a desk lamp into an always-listening tutor. It captures a spoken question (INMP441 mic + on-device DSP + a local "hey lumos" wake word), snaps a photo of the page (OV5640 camera), streams both to the backend over one persistent secure WebSocket, then plays the spoken answer (MAX98357A speaker) while rendering text/LaTeX/images on a 320×240 TFT. The architectural rule throughout: no user-facing intelligence lives on the device — it is a thin, real-time, half-duplex orchestrator. Since the 2026-06-16 sync the firmware is no longer frozen: it gained **OTA self-update**, a **TFT UI/UX rewrite**, on-device rendering of backend-drawn **graphs and chemistry structures**, and — as of the 2026-07-03 "first iteration complete" commit — a **scroll-document reading page** (`TFT_SCROLL_DOC`) that stacks a whole answer (text, equations, graphs, chemistry) into one continuous scroll instead of separate frame pages. The docs decompose it into top-level architecture/state machine, the audio capture/DSP/playback pipeline, the TFT display + immediate-mode UI, device-side WebSocket/camera/button I/O, and the standalone bring-up/test sketches. → **[01-firmware/README.md](01-firmware/README.md)**

### [02-backend](02-backend/README.md) — FastAPI brain

The backend is an async FastAPI + uvicorn application that is the brain of the system. It terminates one persistent binary WebSocket per lamp, accepts a multimodal "turn" (camera JPEG(s) + microphone PCM), and runs it through a deterministic pre-router → tiered multimodal LLM (Gemini 3.1 Flash-Lite by default, with Claude/OpenAI/DeepSeek swappable and a Pro tier) → reply schema → TTS (Gemini, Piper, or **Cartesia Sonic**) + LaTeX/TFT rendering, then streams paced audio and chunked screen frames back. Everything is shaped by the sub-2-second latency goal. Recent additions: a code-enforced **output validator + input guardrails + child-safety prompt boundary** and an **expanded math verifier** around the LLM; server-side **graph rendering** and **RDKit molecular-structure rendering** alongside LaTeX for the TFT; **OTA firmware-update** endpoints (the `firmware_releases` image lives in-DB and the backend serves it); pilot-program instrumentation — **insights** analytics, admin **pilot** surfaces, and offline **topic/mistake tagging** workers; as of 2026-07-03/04, a **memory-leak/OOM hardening pass** — a process-wide graph-render concurrency gate, closed matplotlib/HTTP client handles, hard per-turn buffer ceilings, and a parallelized (rather than serial) conversational-memory load; and, as of 2026-07-06, a **brain-optimization pass** — the math verifier ON by default, MCQ option-match verification, sampling temperature lowered to 0.4 (since reverted to the `1.0` production default), prompt versioning (`PROMPT_VERSION`), and an offline **`evals/` golden-set harness** (doc 13; its short-lived CI workflow was removed 2026-07-08); and, as of **2026-07-11**, an **admin "Analytics" tab** — range-aware (today/yesterday/7d/30d) output-generation + total-latency analytics with a tier **escalation funnel**, two new latency stages (model-selection, graph-render), IST bucketing and lamp-only filtering (three `/admin/analytics/*` endpoints, docs 03/10), plus a Gemini "Tutor unavailable" fix (`given` → typed `list[GivenItem]`) and GZip on the JSON API. The docs are organized by layer: architecture overview, the HTTP/REST + WebSocket surfaces, the turn orchestrator, escalation/model-selection, the swappable LLM providers, the media plane (TTS/preprocessing/LaTeX), memory/workers/analytics, auth/pairing/security, and output formatting/schemas/admin. → **[02-backend/README.md](02-backend/README.md)**

### [03-frontend](03-frontend/README.md) — Next.js dashboard

The frontend is a Next.js 14 App-Router application that is the human-facing surface. Users sign in via Clerk, complete a 7-question onboarding profile, view dashboards and analytics, pair their physical lamp with an in-browser QR scanner, and exercise the AI brain through a web simulator. Styling uses Tailwind with a dark "luminous nocturne" theme, and all backend data flows through a single authenticated TanStack React Query layer that attaches the Clerk JWT to every call to the FastAPI "Frontend Manager." A hard boundary runs through it: the frontend only ever handles **human** sessions — never device secrets or device JWTs. Newer surfaces added for the pilot: a **survey** flow, a **personalization** profile, **report-a-problem**, loading **skeletons**, an **OTA** management UI, a large **admin / analytics (insights)** expansion, and — as of **2026-07-11** — an eleventh admin **"Analytics" tab** (range-aware output-generation + total latency, a tier escalation funnel, and a per-question table with equation/graph/voice render times, question level, and failure reasons; lamp-only). *(Note, 2026-07-06: the local `Smart-Tutor-frontend/` working copy was briefly removed from disk and restored the same day by re-cloning the remote; it has since advanced to tip `2a09869`, 2026-07-11 — the 16-commit Analytics-tab build-out these docs now describe.)* The docs cover the architecture/global wiring, the page/route inventory + onboarding journey, the React component layer (app + landing), and the `lib/` data/API layer. → **[03-frontend/README.md](03-frontend/README.md)**

### [04-web-simulator](04-web-simulator/README.md) — browser stand-in for the lamp

The Web Simulator is the browser-based stand-in for the physical lamp. It lets anyone build, demo, and regression-test the AI brain — multimodal capture (webcam image + spoken question + typed text), the multi-LLM solve pipeline, TTS, the KaTeX "screen," and conversational memory — entirely in a browser tab, with no ESP32 hardware. It mirrors exactly what the lamp sends over the wire (16 kHz mono WAV uplink, JPEG snapshots, optional text), exercises the same backend brain and binary WebSocket frame protocol, and persists turns to the same Postgres `turns` table (tagged `source="simulation"`). The docs cover both halves: the frontend `/simulator` page + media-capture hook, and the backend `web_simulator.py` deterministic brain fallback (which also defines the shared `BrainEvent` streaming contract). → **[04-web-simulator/README.md](04-web-simulator/README.md)**

### [05-database](05-database/README.md) — Supabase / Postgres + pgvector

The database is the durable data layer: a single PostgreSQL database on Supabase, accessed asynchronously via SQLAlchemy 2.x + asyncpg, and extended with pgvector (long-term ANN memory), pgcrypto, and pg_stat_statements. It is the source of truth for everything that must survive a restart — devices and QR pairing, conversation sessions and turns, per-turn pipeline traces, the cross-session learner profile, lifecycle events, the per-API-call cost ledger, the admin allowlist, a separate multi-LLM evaluation bench, and (added in the 2026-07-03 refresh) the pilot-program tables — turn/answer feedback, surveys, problem reports, consent log, personalization, syllabus/topic/mistake tagging, and the in-DB OTA firmware image store (**24 ORM tables** total). A defining choice: Clerk owns human identity, so there is intentionally **no `users` table** — every row carries the Clerk `user_id` string denormalized. The DB is optional at boot (the app degrades to stateless when unset). The docs move from schema → repositories → operations (Supabase setup, RLS, the Clerk↔Supabase JWT bridge, migrations, and a SQL cookbook). → **[05-database/README.md](05-database/README.md)**

### [06-git-history](06-git-history/README.md) — version-control history

This area documents the project's source-control topology and timeline, reconstructed directly from raw `git log` exports rather than inferred from behavior. The project spans **two GitHub repositories** and **three logical code histories** totalling **216 commits** (2026-05-25 → 2026-07-11). The `Smart-Tutor-Lamp` repo has an unusual layout: firmware (21 commits, ESP32-S3 C++/Arduino) and backend (136 commits, Python FastAPI) live as two *orphan* branches sharing no common ancestor, so each branch shows a completely different file tree — plus a newer **`information`** docs branch (forked from `firmware`, holding this knowledge base). The `Smart-Tutor-frontend` repo holds a conventional `main` branch (59 commits, Next.js + TypeScript + Tailwind + Clerk); its local clone was briefly removed from disk on 2026-07-06 and restored the same day, and has since advanced with the 2026-07-11 Analytics-tab wave. Four contributors total (firmware/backend/frontend split), with `Hellinferno` joining on 2026-07-09. The docs cover the big-picture topology + contributor breakdown, then per-branch chapters with full commit tables and thematic narratives. → **[06-git-history/README.md](06-git-history/README.md)**

---

## Supplementary references

Two cross-cutting reference sets sit alongside the six areas above:

- **[folder_details/](folder_details/README.md)** — a scan-based **directory catalog** of every folder and every file across all three repos, each with its type and purpose. Split into six parts: firmware, backend, frontend, web simulator, database, and system prompt. Use it as the "what is this file?" lookup; use the six area folders for "how does it work?".
- **[system-prompt-web-and-lamp/](system-prompt-web-and-lamp/README.md)** — a deep dive into the **AI brain's instructions and models**: how the system prompts work for the web vs the lamp path (they use *different* prompt text), and a master inventory of **every LLM/model used, where, and how** (reasoning tiers, STT, TTS, embeddings, and the bench catalog).

---

## How it works end-to-end

A single student question, traced from a button press on the lamp to spoken audio coming back out:

1. **Wake / capture (lamp).** The student presses the push-to-talk button (or says "hey lumos," detected on-device by the Edge Impulse wake-word classifier). The firmware enters its listening state and captures audio from the INMP441 mic, running the training-identical on-device DSP chain (Noise Suppression → Adaptive Line Enhancer → AGC → VAD). End-of-speech (EOS) detection decides when the student has stopped talking. In parallel, the OV5640 camera snaps a JPEG of the page on the desk.

2. **Uplink (WebSocket).** Over the one persistent secure WebSocket (`wss://`, authenticated with the backend-issued `device_jwt`), the firmware streams the captured audio (PCM, optionally IMA/DVI ADPCM-compressed) plus the JPEG snapshot(s) to the backend using the 4-byte binary frame protocol. The lamp shows a "thinking" state on the TFT.

3. **Pre-route (backend orchestrator).** The backend's WebSocket endpoint assembles the multimodal turn (audio + image(s) + any context) and hands it to the turn orchestrator. The deterministic pre-router (`escalation_router.py`) inspects the turn and picks a starting tier — by default **Gemini 3.1 Flash-Lite** — consulting the model catalog (the single source of truth for every model's price and capabilities). Conversation memory (L1 Redis hot cache → L2 compaction → L3 learner profile) and the per-user learner profile are pulled in to personalize the prompt.

4. **Solve + escalate (LLM).** The provider-agnostic solver calls the selected LLM with the assembled prompt (the Lumos persona + input-handling rules + the student's question + image). The model returns a structured `LlmReply` with three independent channels: `speech` (what to say), `display` (text for the screen), and `latex_equations` (any math). Post-answer escalation gates decide whether the answer is good enough or whether to climb a tier — to **Flash-thinking** or ultimately **Pro** — re-solving with a stronger model when the problem warrants it. A "solve-once / tutor-many" problem memo and a guard stack (echo/focus/bleed/reveal/dispute) keep the tutoring coherent across follow-ups.

5. **Render media (backend).** The `speech` field is synthesized into paced 24 kHz audio by the TTS engine (Gemini, Piper, or Cartesia Sonic), and any `latex_equations` — plus optional graphs and RDKit chemistry structures — are rendered server-side into RGB565 TFT pixel frames (the device never renders them). The whole media plane is fail-open: if TTS or rendering degrades, the system still returns something visual.

6. **Stream back (downlink).** The backend streams the audio back to the lamp **sentence-chunked and paced** so the speaker can start playing within the latency budget, while chunked TFT frames (text + rendered equations + any images) are pushed for the screen. Audio playback and display run as the lamp's strictly half-duplex mic/speaker handoff allows.

7. **Speak + display (lamp).** The firmware plays the answer through the MAX98357A speaker and renders the text/LaTeX/image frames on the 320×240 TFT — the student hears and sees the tutored answer. Meanwhile the backend has persisted the turn, its pipeline trace, cost, and any updated memory to Postgres (fire-and-forget, off the hot path), feeding the dashboard's analytics.

The **web simulator** reproduces this exact loop in a browser tab — same `/ws` binary protocol (or the `/solve` HTTP path), same brain, same `turns` table — so the pipeline can be built and regression-tested without any ESP32 hardware.

---

## Provenance

These docs were originally generated from the synced GitHub repositories on **2026-06-16**, refreshed **2026-07-03** to cover commits through that date (grand total 136 → 177 commits; firmware 17 → 20, backend 81 → 114, frontend 38 → 43; range 2026-05-25 → 2026-07-03), refreshed **2026-07-05** after pulling 3 further commits (1 firmware, 2 backend) to cover commits through 2026-07-04 (grand total 177 → 180 commits; firmware 20 → 21, backend 114 → 116, frontend unchanged at 43), refreshed again **2026-07-06** after the backend brain-optimization commit landed (grand total 180 → 181 commits; backend 116 → 117), and refreshed **2026-07-11** after the **admin "Analytics" tab** wave (backend 117 → **136**, frontend 43 → **59**; grand total 181 → **216** commits; range now 2026-05-25 → **2026-07-11**). The 2026-07-11 wave is a single coherent feature — a range-aware output-generation + total-latency analytics tab (frontend `AnalyticsTab` + three `/admin/analytics/*` backend endpoints, a tier escalation funnel, two new latency stages, IST bucketing, lamp-only filtering) — plus a config-defaults-to-production alignment (which the docs already described), a Gemini "Tutor unavailable" fix (`given` → typed `list[GivenItem]`), GZip on the JSON API, and the removal of the short-lived backend CI workflow:

- **Firmware** — `Smart-Tutor-Lamp` repo, `firmware` branch (tip `c699e72`, 2026-07-03 — unchanged since the 2026-07-05 refresh)
- **Backend** — `Smart-Tutor-Lamp` repo, `backend` branch (tip `5ea5815`, 2026-07-11 "Admin Analytics: add question Level + per-question escalation")
- **Frontend** — `Smart-Tutor-frontend` repo, `main` branch (tip `2a09869`, 2026-07-11 "Admin Analytics: remove Lamp column" — the local clone was briefly removed from disk on 2026-07-06 and restored the same day by re-cloning; it has since advanced by 16 commits, all the Analytics-tab build-out). New contributor this wave: **Hellinferno** (1 frontend commit, created the Analytics tab)

(Firmware and backend are two *orphan* branches of the same `Smart-Tutor-Lamp` repository and share no common ancestor — see [06-git-history](06-git-history/README.md). A third **`information`** branch, forked from `firmware`, carries this knowledge base and the `improvment/` plans; it is currently checked out at the `Smart-Tutor-Lamp` repo root.)
