# LLM & Model Usage — What We Use, Where, and How

This is the definitive, code-grounded inventory of **every AI model the Smart Tutor Lamp project invokes** — the reasoning LLMs (Gemini 2.x/3.x, GPT‑5 / GPT‑5‑mini, Claude, DeepSeek), the speech models (Groq Whisper for STT; Gemini TTS, Piper, Cartesia for TTS), and the (currently stubbed) embedding model for vector memory. For each model it names the exact vendor id, where in the backend it is called, how it is invoked, and which env var pins it.

The project runs **two reasoning surfaces over the same model catalog**: the **lamp** (ESP32 hardware → `orchestrator.py` → `llm_gemini.GeminiProvider`, schema = `LlmReply`) and the **web bench / simulator** (browser → `gemini_brain.simulate*` and `model_solver.generate_solution`, schema = `SimResponse`). Both share one system prompt and the same `model_catalog.py` source of truth.

> All file:line citations point into `D:/clartiy/Smart-Tutor-Lamp-backend/`.

> **Updated 2026-07-03:** the inventory was re-verified against the backend at branch tip `80f04b6`. The one model-inventory change since the 2026-06-16 sync is **Cartesia Sonic** (`sonic-3.5`, `app/providers/tts_cartesia.py`) — now a **live** lamp TTS provider (`TTS_PROVIDER=cartesia`) alongside Gemini TTS and Piper, reflected throughout the tables below. STT (Groq-hosted Whisper `whisper-large-v3` / `-turbo`), the reasoning tiers (Gemini 2.5 Flash → 2.5 Pro, Claude timeout fallback, the GPT-5 / DeepSeek / Gemini 3.x bench catalog), and the embeddings stub are unchanged.

> **Updated 2026-07-06:** re-verified against backend tip `db470f6` ("Brain optimization pass" — canonical record: [02-backend/13-brain-optimization-eval-harness-and-ci.md](../02-backend/13-brain-optimization-eval-harness-and-ci.md)). The model **inventory** is unchanged; what moved are defaults and observability: `GEMINI_TEMPERATURE` default lowered `1.0 → 0.4` (prod already ran 0.4); `MATH_VERIFY_ENABLED` flipped `False → True`, so the hidden verifier fields — now including an MCQ option-match check (`math_verifier.verify_option_match`) — are requested by default (~30-80 extra output tokens on quantitative turns); the lamp prompt is versioned (`PROMPT_VERSION = "1.0.0"` in `turn1_system.py`, stamped into turn traces and eval results); and Gemini implicit-cache hits are now observable (`usage_metadata.cached_content_token_count` → `telemetry["llm_cached_tok"]`, mirrored as `cached_tokens` on the web path). A new `evals/` harness + `.github/workflows/backend-ci.yml` back the two quality-coupled default flips with a paired golden-set eval.

---

## Table of contents

1. [Master table — every model](#1-master-table--every-model)
2. [Reasoning LLMs](#2-reasoning-llms)
3. [The tiered brain & escalation](#3-the-tiered-brain--escalation)
4. [Grounding / web search](#4-grounding--web-search)
5. [Speech: STT + TTS](#5-speech-stt--tts)
6. [Embeddings & vector memory](#6-embeddings--vector-memory)
7. [Configuration reference](#7-configuration-reference)
8. [Per-turn model flow (Mermaid)](#8-per-turn-model-flow-mermaid)

---

## 1. Master table — every model

Legend for **Role**: *brain* = reasoning LLM, *STT* = speech‑to‑text, *TTS* = text‑to‑speech, *embed* = vector embedding.

| Model / ID | Provider | Role | Where used (file) | How invoked | Config / env var | Notes (cost $/1M in→out · vision/audio · default tier) |
|---|---|---|---|---|---|---|
| **`auto`** (routing alias) | gemini | brain (router) | `model_catalog.py:60`; web `_solve_auto` (frontend_manager) | Runs the whole tiered escalation flow; never a raw model call (`model_solver._solve_gemini` 404‑guards it, `model_solver.py:222`) | n/a | 0.10→0.40 (tier‑1 pricing only; steps carry real cost) · vision+audio · the web mirror of the lamp plan |
| **`gemini-2.5-flash`** | gemini | brain (bench default) | catalog `:68`; bench `generate_solution` → `_solve_gemini` | `client.aio.models.generate_content(response_schema=...)` | `DEFAULT_MODEL_ID` (`model_catalog.py:166`) | 0.30→2.50 · vision+audio · **DEFAULT_MODEL_ID** — bench dropdown default (no longer the lamp `GEMINI_MODEL` brain) |
| **`gemini-2.5-flash-lite`** | gemini | brain | catalog `:74` | bench `generate_solution` → `_solve_gemini` | catalog pin | 0.10→0.40 · vision+audio · bench only |
| **`gemini-2.0-flash`** | gemini | brain | catalog `:80` | bench | catalog pin | 0.10→0.40 · vision+audio · bench only |
| **`gemini-2.0-flash-lite`** | gemini | brain | catalog `:86` | bench | catalog pin | 0.075→0.30 · vision+audio · bench only |
| **`gemini-2.5-pro`** | gemini | brain | catalog `:92` | bench | catalog pin | 1.25→10.00 · vision+audio · former tier‑3 ceiling (no longer the `GEMINI_TIER3_MODEL` default) |
| **`gemini-3.5-flash`** | gemini | brain | catalog `:104` (`gemini-3.5-flash`) | bench | catalog pin | 0.40→3.00 · vision+audio · bench before lamp adoption |
| **`gemini-3-flash`** | gemini | brain | catalog `:111` (vendor `gemini-3-flash-preview`) | bench | catalog pin | 0.40→3.00 · vision+audio · preview |
| **`gemini-3.1-flash-lite`** | gemini | brain (tier‑1 default) | `llm_gemini.GeminiProvider` (`:142`); `gemini_brain` (`:285`,`:633`); catalog `:117` (`gemini-3.1-flash-lite`) | `client.aio.models.generate_content(response_schema=...)` | `GEMINI_MODEL` (default `gemini-3.1-flash-lite`, `config.py:35`) | 0.10→0.40 · vision+audio · **GEMINI_MODEL** default — lamp tier‑1/2 brain |
| **`gemini-3.1-pro`** | gemini | brain (tier‑3) | catalog `:123` (vendor `gemini-3.1-pro-preview`); lamp `self._llm_pro` (`orchestrator.py:59`) | tier‑3 `_call_tier` Pro instance | `GEMINI_TIER3_MODEL` (default `gemini-3.1-pro-preview`, `config.py:475`) | 2.00→12.00 · vision+audio · **default tier‑3 ceiling** when `GEMINI_TIER3_ENABLED` — the lamp's tier‑3 ceiling for JEE‑Advanced depth |
| **`gemini-3-pro`** | gemini | brain | catalog `:130` (vendor `gemini-3-pro-preview`) | bench | catalog pin | 2.00→12.00 · vision+audio · preview |
| **`gpt-5`** | openai | brain | catalog `:136`; `model_solver._solve_openai` (`:239`) | `chat.completions.create(response_format=json_object)` | `OPENAI_MODEL_GPT5` (default `gpt-5`, `model_catalog.py:138`) | 1.25→10.00 · vision, **no native audio** (Whisper upstream) · bench |
| **`gpt-5-mini`** | openai | brain | catalog `:142`; `_solve_openai` | same as GPT‑5 | `OPENAI_MODEL_GPT5_MINI` (default `gpt-5-mini`, `:144`) | 0.25→2.00 · vision, no audio (Whisper) · bench |
| **`claude` → `claude-sonnet-4-6`** | claude | brain + lamp **timeout fallback** | catalog `:155`; `llm_claude.ClaudeProvider` (`:47`); `_solve_claude` (`:276`) | `client.messages.stream(...)` (lamp) / `messages.create(...)` (bench) | `ANTHROPIC_MODEL` (default `claude-sonnet-4-6`, `config.py:41`) | 3.00→15.00 · vision, no audio (Whisper) · bench + `CLAUDE_TIMEOUT_FALLBACK` brain |
| **`deepseek` → `deepseek-chat`** | deepseek | brain (text‑only) | catalog `:148`; `llm_deepseek.DeepSeekProvider` (`:47`); `_solve_deepseek` (`:317`) | OpenAI‑compatible `chat.completions.create` at `DEEPSEEK_BASE_URL` | `DEEPSEEK_MODEL` (default `deepseek-chat`, `config.py:54`) | 0.27→1.10 · **no vision, no audio** · bench |
| **`deepseek-reasoner`** | deepseek | brain (tier‑4, deferred) | `config.py:711` (`HEAVY_REASONER_MODEL`) | not wired — tier‑4 clamps to tier‑3 | `HEAVY_REASONER_MODEL` / `HEAVY_REASONER_PROVIDER` | tier‑4 bridge is **config stub only** (`GEMINI_TIER4_ENABLED=False`) |
| **`whisper-large-v3`** | Groq | STT | `model_solver._stt_via_groq` (`:400`); `transcribe.py` (planned, `:18`) | `client.audio.transcriptions.create(model="whisper-large-v3")` | `GROQ_API_KEY` (`config.py:58`) | web bench voice STT for non‑audio providers; ~$0.0001/turn |
| **`whisper-large-v3-turbo`** | Groq | STT | `llm_claude._stt_via_groq` (`:216`) | `transcriptions.create(model="whisper-large-v3-turbo")` | `GROQ_API_KEY` | lamp pre‑router STT + Claude/DeepSeek upstream STT (~150‑200 ms) |
| **`gemini-2.5-flash-preview-tts`** | gemini | TTS | `tts_gemini.GeminiTtsProvider` (`:98`) | `generate_content_stream(response_modalities=["AUDIO"], speech_config=...)` | `GEMINI_TTS_MODEL` (default `gemini-2.5-flash-preview-tts`, `config.py:113`) · voice `GEMINI_TTS_VOICE`=`Aoede` | Gemini lamp voice when `TTS_PROVIDER=gemini` (paid, billed per audio token); 24 kHz PCM |
| **Piper voice** (`*.onnx`, e.g. `en_US-amy-medium.onnx`) | Piper (local ONNX) | TTS | `tts_piper.TTSService` / `PiperTtsProvider` (`:80`,`:382`) | in‑proc `PiperVoice.synthesize` (library) or `piper` CLI (subprocess) | `PIPER_MODEL` (path, `config.py:197`), `PIPER_*` tuning | $0, offline, ~0.2 s TTFB; **default web‑bench voice** (`FRONTEND_TTS_PROVIDER=piper`) |
| **Cartesia Sonic** (`sonic-3.5`) | Cartesia | TTS | `tts_cartesia.CartesiaTtsProvider` (`:40`) | **LIVE** — `POST /tts/bytes` (`container="raw"`), httpx streaming, 24 kHz int16 PCM (no resample) | `CARTESIA_API_KEY` + `CARTESIA_*` | **~170 ms first byte, NO daily cap, CONTINUOUS audio** → bypasses `TTS_CHUNK_MODE`; lamp voice when `TTS_PROVIDER=cartesia` |
| **embedding** (`text-embedding-3-small` 1536‑d, *or* local `bge-small`) | OpenAI / local | embed | `embed.py` (`:14`), `memory_vec.py` (`:23`) | **not implemented** — `NotImplementedError` stubs | TODO (layer‑3.3) | pgvector long‑term memory deferred per `BACKEND_TODO.md §3.3` |

**Provider availability:** a model is usable only when its key is set — `is_available(spec)` checks `GEMINI_API_KEY` / `OPENAI_API_KEY` / `ANTHROPIC_API_KEY` / `DEEPSEEK_API_KEY` (`model_catalog.py:239-250`). Non‑audio providers (OpenAI/Claude/DeepSeek) additionally need `GROQ_API_KEY` to answer a *voice* question (`needs_groq_for_audio`, `:253`).

---

## 2. Reasoning LLMs

### 2.1 The abstraction (`llm_base.py`)

Every lamp provider implements one contract — `LlmProvider.call(system_prompt, history_text, images, audio_bytes, *, thinking_budget, max_output_tokens, hard_timeout_s) -> (LlmReply, telemetry)` (`llm_base.py:142-177`). The orchestrator never imports an SDK; it picks the provider by `LLM_PROVIDER` env (`gemini`|`openai`|`claude`|`deepseek`, default `gemini`) via the self‑registering factory `get_llm_provider()` (`:222-249`). Shared constants: `LLM_HARD_TIMEOUT_S = 20.0` (`:38`) and `LLM_MAX_OUTPUT_TOKENS = 900` (`:66`).

Two Gemini‑version shims live here:
- **`gemini_thinking_config(model, budget)`** (`:69-102`) — Gemini 2.5 takes a numeric `thinkingBudget`; Gemini 3.x takes a string `thinking_level` (`minimal`/`low`/`medium`/`high`). Setting both is a 400, so this emits exactly one per family. Budget→level map: `≤0→minimal`, `<512→low`, `<1024→medium`, `≥1024→high`.
- **`gemini_code_execution_tool(model)`** (`:105-139`) — attaches Google's server‑side Python sandbox so the model computes numerics instead of hallucinating them. **Only Gemini‑3.x Pro** (rejected on 2.5 + JSON mode; loops on flash‑lite); **never with audio parts** (400). Gated by `GEMINI_TIER3_CODE_EXECUTION` (default True).

### 2.2 Gemini (`llm_gemini.py`) — reference provider

`GeminiProvider` (`:127`), `name="gemini"`, `model=GEMINI_MODEL` (default `gemini-3.1-flash-lite`, `:143`). It is the only **natively multimodal** provider — accepts N image `Part`s + raw audio (PCM auto‑wrapped to WAV, `:368`) in one `generate_content` call with `response_schema=LlmReply` for schema‑constrained JSON (`:402-415`). Streaming is **off by default** (`GEMINI_USE_STREAM=False`, `config.py:389`) due to a google‑genai 2.6.0/aiohttp readline bug — the unary path `_drain_unary` is used (`:421`). The client is a cached singleton forcing an httpx transport to bypass that bug (`_client_singleton`, `:100-124`), shared with Gemini TTS. Extras: `preupload_image` pushes JPEGs to the Gemini Files API during the user's speech to cut ~250‑400 ms (`:148-184`); transient 5xx/429/network/timeout retries (`:38-58`, `:224-302`); temperature from `GEMINI_TEMPERATURE` (default `1.0`; a temporary `0.4` default was later reverted to `1.0`; `:420`); and since 2026-07-06 `usage_metadata.cached_content_token_count` is captured into `telemetry["llm_cached_tok"]` (`:471-475`) so the Gemini implicit-cache discount on the static prompt prefix is verified rather than assumed.

### 2.3 Web brain (`gemini_brain.py`) — the simulator/bench Gemini path

Separate from the lamp because the web renders **KaTeX** while the lamp renders matplotlib mathtext (`:1-12`). Holds the shared **system prompt** (`_system_prompt`, `:61`) and the `SimResponse` schema (`:319`) that *every* provider on both surfaces answers in. `simulate_with_usage(...)` (`:526`) calls `client.aio.models.generate_content(response_schema=SimResponse, ...)` against `model or settings.GEMINI_MODEL`, supports per‑call `thinking_budget`/`max_output_tokens` (so the web runs the same two‑tier dispatch as the lamp), and attaches the code‑execution tool on audio‑free 3.x calls. `respond(...)` (`:260`) is the streaming token timeline used by the live WS bench.

### 2.4 OpenAI (`llm_openai.py`)

`OpenAIProvider` (`:37`), `name="openai"`, `model=OPENAI_MODEL` (default `gpt-4o` at the lamp‑provider level, `:42`) — but the **bench catalog** pins `gpt-5` / `gpt-5-mini` via `OPENAI_MODEL_GPT5*`. Native vision via base64 data‑URL; audio via `input_audio`/`pcm16` (lamp provider) or Whisper upstream (bench solver). JSON via `response_format={"type":"json_object"}`, streaming completions (`:124-134`). Note: the lamp `call()` signature here is the **older 4‑arg form** (no thinking/timeout kwargs) — it is a bench‑oriented stub.

### 2.5 Claude (`llm_claude.py`)

`ClaudeProvider` (`:42`), `name="claude"`, `model=ANTHROPIC_MODEL` (default **`claude-sonnet-4-6`**, `:47`). Vision native; **no raw audio** → transcribes via Groq Whisper (`_stt_via_groq`, reuses the pre‑router transcript when supplied, `:112-119`). `client.messages.stream(...)` with `temperature=CLAUDE_TEMPERATURE` (default 0.3, 0‑1 scale, `:169`) and the schema instruction appended to the system prompt. It is the **lamp's timeout‑fallback brain**: when `CLAUDE_TIMEOUT_FALLBACK=True` and Gemini hits a server failure at any tier, `_call_tier` re‑runs the identical turn on Claude (`orchestrator.py:1171-1196`).

### 2.6 DeepSeek (`llm_deepseek.py`)

`DeepSeekProvider` (`:42`), `name="deepseek"`, `model=DEEPSEEK_MODEL` (default `deepseek-chat`, `:47`). **Text‑only** — OpenAI‑compatible API at `DEEPSEEK_BASE_URL` (default `https://api.deepseek.com`); audio via Groq Whisper, images **not seen** (a note tells the model so). JSON mode + streaming. `deepseek-reasoner` is named only for the deferred tier‑4 bridge.

All three non‑Gemini providers reuse Gemini's `_parse_or_fallback` / `_strip_json_noise` JSON repair (`llm_gemini.py:549-618`).

---

## 3. The tiered brain & escalation

The lamp answers cheap‑first and climbs only on signal ("speculative escalation"). Two gates bracket the LLM call.

**Tier → model mapping** (lamp, `orchestrator._call_tier`, `:1078-1203`; `_tier_model_name`, `:1198`):

| Tier | Model | Thinking budget | Output cap | Timeout |
|---|---|---|---|---|
| **Tier 1** (default) | `self._llm` = Gemini 3.1 Flash‑Lite (`GEMINI_MODEL`) | `GEMINI_TIER1_THINKING_BUDGET=0` | `GEMINI_TIER1_MAX_OUTPUT_TOK=1200` | `LLM_HARD_TIMEOUT_S=20s` |
| **Tier 2** (escalation) | same Flash‑Lite, with thinking | `GEMINI_TIER2_THINKING_BUDGET=1024` | `GEMINI_TIER2_MAX_OUTPUT_TOK=4000` | 20s |
| **Tier 3** (Pro) | `self._llm_pro` = `GEMINI_TIER3_MODEL` (`gemini-3.1-pro-preview`) | `GEMINI_TIER3_THINKING_BUDGET=512` | `GEMINI_TIER3_MAX_OUTPUT_TOK=10000` | `GEMINI_TIER3_TIMEOUT_S=38s` |
| Tier 4 | `deepseek-reasoner` (deferred) | — | — | clamps to tier‑3 |

Tier‑3 exists only when `GEMINI_TIER3_ENABLED=True` **and** the base provider is Gemini — the orchestrator builds a second Gemini instance pinned to the Pro model (`orchestrator.py:56-62`). Otherwise tier‑3 requests clamp to tier‑2.

**Gate 1 — deterministic pre‑router** (`escalation_router.preroute`): before any LLM call, picks `start_tier` from image quality + question keywords (a blurry/dark/thin‑text photo short‑circuits to "retake" with **zero LLM spend**; `prove/derive` → tier‑2; `JEE Advanced/olympiad` → tier‑3; MCQ/"check my work" → tier‑2 + answer‑shaping suffix). Ceiling = `3 if GEMINI_TIER3_ENABLED else 2`. (Full algorithm in `02-backend/04-escalation-and-model-selection.md`.)

**Gate 2 — post‑answer escalation** reads the model's self‑reported `confidence`/`difficulty`/`query_type`:
- Lamp `_should_escalate` (`orchestrator.py:1522`): escalate on `status=truncated`, `confidence < GEMINI_ESCALATE_CONFIDENCE` (0.45), `difficulty=hard` + query in `{derivation,calc,mistake_id}`, or any `{check,mistake_id}` turn when `SEMANTIC_CHECK_ESCALATION=True`. A tier‑1 answer can **skip‑tier straight to Pro** on truncation / hard / `confidence ≤ 0.30` / dispute.
- Web `_sim_pick_next_tier` mirrors this with no truncation branch (the bench has no per‑call status).

The **Flash→Pro handoff** drops the (already transcribed) audio and only forwards the image if `image_needed`, so the Pro call keeps the code‑execution tool. An escalation that comes back failed is **reverted** to the good lower‑tier answer (escalation must never downgrade).

**Lamp vs web brain usage:** the lamp drives `orchestrator.py` → `GeminiProvider.call()` (schema `LlmReply`). The web `auto` model runs the same plan in `frontend_manager._solve_auto`, calling `gemini_brain.simulate*` (schema `SimResponse`) per tier; a *direct* model pick on the bench bypasses tiering and calls `model_solver.generate_solution` once.

---

## 4. Grounding / web search

`grounding.py` defines `GoogleSearchGrounder.get_grounding_context(query)` (`:7-13`) intended to call Vertex AI Search / Google Search for recent UPSC/SSC context — but it is a **mock stub** that returns the literal string `"MOCK_GROUNDING: Data based on recent search results up to 2026."`. No search‑augmented model is wired into either surface today. (Note: Gemini's *own* code‑execution tool is attached on tier‑3/3.x calls, but that is a Python sandbox, not web search.)

---

## 5. Speech: STT + TTS

### 5.1 STT — Groq Whisper (the only transcription engine)

There is **no OpenAI Whisper or local Whisper** — all STT is **Groq‑hosted Whisper**, used wherever a model can't take raw audio or a fast transcript is needed before tier‑1:

| Caller | Model id | Purpose |
|---|---|---|
| `model_solver._stt_via_groq` (`:400-412`) | `whisper-large-v3` | Web bench voice for OpenAI/Claude/DeepSeek picks |
| `llm_claude._stt_via_groq` (`:191-221`) | `whisper-large-v3-turbo` | Lamp Claude/DeepSeek upstream STT **and** the pre‑router's fast routing transcript (`PREROUTE_STT_ENABLED`) |
| `transcribe.py` (`:18`, planned) | `whisper-large-v3` | Offline analytics transcription — **`NotImplementedError` stub** |

Gemini is the exception: it transcribes audio **inside** the one multimodal reasoning call (no separate STT step). All STT requires `GROQ_API_KEY`.

### 5.2 TTS engines

Selected by `TTS_PROVIDER` for the **lamp** (`gemini`|`piper`|`cartesia`|`kokoro_local`, default `cartesia`, `config.py:72`) and a separate `FRONTEND_TTS_PROVIDER` for the **web bench** (`piper`|`none`, default `piper` — deliberately excludes `gemini` so the browser can never spend Gemini audio tokens, `config.py:82`). The factory `get_tts_provider` lazily imports only the chosen engine (`tts_base.py:149-188`). Wire contract every engine honours: mono int16 LE PCM @ `TTS_TARGET_SAMPLE_RATE=24000`, ≤ `TTS_CHUNK_BYTES=4096`.

| Engine | Provider id | File | Model / voice | Notes |
|---|---|---|---|---|
| **Gemini TTS** | `gemini` | `tts_gemini.py:98` | model `GEMINI_TTS_MODEL` (default `gemini-2.5-flash-preview-tts`), voice `GEMINI_TTS_VOICE` (default **`Kore`**; others: Puck, Charon, Zephyr, Aoede, Fenrir…) | API‑based, reuses the warm LLM genai client; `response_modalities=["AUDIO"]` + `PrebuiltVoiceConfig`; unary by default (`GEMINI_TTS_STREAM=False`, streaming opt‑in); optional `GEMINI_TTS_STYLE` delivery prompt; 24 kHz native (no resample). **Paid per audio token** — `TTS_MAX_INPUT_CHARS=800` cost guard. |
| **Piper** | `piper` | `tts_piper.py:382` | `.onnx` voice at `PIPER_MODEL` (e.g. `en_US-amy-medium.onnx` = en/amy/medium) | Self‑hosted CPU ONNX, **$0**, offline. `PIPER_MODE=library` (warm in‑proc, ~0.2 s TTFB) or `subprocess` (CLI). Resamples voice's 16/22.05 kHz → 24 kHz via `audioop`. Tuning: `PIPER_SPEED/NOISE_SCALE/NOISE_W/SENTENCE_SILENCE/SPEAKER`. **Default web‑bench voice.** |
| **Cartesia Sonic** | `cartesia` | `tts_cartesia.py:40` | model `CARTESIA_MODEL` (default **`sonic-3.5`**), voice `CARTESIA_VOICE_ID` (default "Skylar"), tutor style via `CARTESIA_SPEED` (0.9, clamped 0.6–1.5) / `CARTESIA_VOLUME` / `CARTESIA_EMOTION` | **LIVE** — `@register_tts_provider("cartesia")`, `POST https://api.cartesia.ai/tts/bytes` with `output_format.container="raw"` read progressively via httpx, requested **AS** 24 kHz mono int16 LE PCM (no resample). `incremental=True` → streamed straight to the lamp, so `TTS_CHUNK_MODE` is bypassed (no mid-speech gap). ~170 ms first byte, **no daily request cap**. Needs `httpx` (pinned in `requirements.txt`). |
| `kokoro_local` | — | — | — | Reserved placeholder, not implemented. |

**Codec for lamp vs web:** the lamp AUDIO_OUT wire codec is `TTS_WIRE_CODEC` (`pcm`|`adpcm`|`opus`, default `pcm`, `config.py:656`) — ADPCM (4:1) / Opus (`TTS_OPUS_BITRATE=32000`) fit a window/RTT‑capped WAN; the web bench sends each PCM chunk straight as a WS frame. Chunking (`TTS_CHUNK_MODE`, default `single`) only applies when Gemini streaming is off.

---

## 6. Embeddings & vector memory

Long‑term pgvector memory is **designed but not implemented** — both entry points raise `NotImplementedError`:
- `app/workers/embed.py:embed_turn` (`:22`) — would embed each turn's `(transcript, response_text)`.
- `app/storage/memory_vec.py:insert_memory` / `fetch_relevant` (`:44`,`:51`) — per‑user vector store; before each turn, top‑3 ANN lookup on the question embedding injected as "Things you've discussed before."

The intended **embedding model** is documented in both files as **OpenAI `text-embedding-3-small` (1536‑d, $0.02/M tok)** *or* a local **`bge-small`** (`embed.py:13-16`, `memory_vec.py:21-24`); the `memories` table schema pins `vector(1536)`. Deferred per `BACKEND_TODO.md §3.3` ("skip until a real user asks for continuity"). The live "memory" today is the Redis short‑term history + the per‑session problem memo, neither of which uses embeddings.

---

## 7. Configuration reference

Every model‑related env var and its default (from `app/config.py` unless noted).

| Env var | Default | Used for |
|---|---|---|
| `LLM_PROVIDER` | `gemini` | Which lamp brain (`gemini`/`openai`/`claude`/`deepseek`) |
| `GEMINI_API_KEY` | — | Gemini brain + Gemini TTS availability |
| `GEMINI_MODEL` | `gemini-3.1-flash-lite` | Lamp tier‑1/2 brain + web `gemini_brain` |
| `OPENAI_API_KEY` | — | OpenAI availability |
| `OPENAI_MODEL` | `gpt-4o` | Lamp OpenAI provider default (bench uses GPT‑5 pins) |
| `OPENAI_MODEL_GPT5` | `gpt-5` | Catalog `gpt-5` vendor pin (`model_catalog.py:138`) |
| `OPENAI_MODEL_GPT5_MINI` | `gpt-5-mini` | Catalog `gpt-5-mini` vendor pin (`:144`) |
| `ANTHROPIC_API_KEY` | — | Claude availability + timeout fallback |
| `ANTHROPIC_MODEL` | `claude-sonnet-4-6` | Catalog `claude` + lamp Claude provider |
| `CLAUDE_TIMEOUT_FALLBACK` | `True` | Arm Claude as the lamp's Gemini‑failure fallback brain |
| `CLAUDE_TEMPERATURE` | `0.3` | Claude sampling (0‑1 scale) |
| `DEEPSEEK_API_KEY` | — | DeepSeek availability |
| `DEEPSEEK_MODEL` | `deepseek-chat` | Catalog `deepseek` + lamp DeepSeek provider |
| `DEEPSEEK_BASE_URL` | `https://api.deepseek.com` | OpenAI‑compatible endpoint |
| `GROQ_API_KEY` | — | All STT (Whisper) + pre‑router STT |
| `MODEL_PRICING_JSON` (env) | unset | Runtime per‑model price overrides (malformed → ignored) |
| `GEMINI_TEMPERATURE` | `1.0` | Lamp Gemini sampling (a temporary `0.4` default was reverted to `1.0`) |
| `GEMINI_USE_STREAM` | `False` | Gemini reasoning streaming (off — SDK bug) |
| `GEMINI_DYNAMIC_THINKING` | `True` | Master switch for multi‑tier dispatch |
| `GEMINI_THINKING_BUDGET` | `0` | Legacy single‑tier budget |
| `GEMINI_TIER1_THINKING_BUDGET` | `0` | Tier‑1 (no thinking) |
| `GEMINI_TIER1_MAX_OUTPUT_TOK` | `1200` | Tier‑1 output cap |
| `GEMINI_TIER2_THINKING_BUDGET` | `1024` | Tier‑2 reasoning |
| `GEMINI_TIER2_MAX_OUTPUT_TOK` | `4000` | Tier‑2 output cap |
| `GEMINI_ESCALATE_CONFIDENCE` | `0.45` | Confidence floor → escalate |
| `GEMINI_TIER3_ENABLED` | `True` | Wire the Pro tier |
| `GEMINI_TIER3_MODEL` | `gemini-3.1-pro-preview` | Tier‑3 Pro model |
| `GEMINI_TIER3_THINKING_BUDGET` | `512` | Tier‑3 reasoning |
| `GEMINI_TIER3_MAX_OUTPUT_TOK` | `10000` | Tier‑3 output cap (ceiling) |
| `GEMINI_TIER3_CODE_EXECUTION` | `True` | Gemini‑3.x Python sandbox |
| `GEMINI_TIER3_TIMEOUT_S` | `38.0` | Pro per‑call timeout (≤ firmware 45 s) |
| `GEMINI_TIER4_ENABLED` | `False` | Deferred bridge tier |
| `HEAVY_REASONER_PROVIDER` / `_MODEL` | `deepseek` / `deepseek-reasoner` | Tier‑4 target (stub) |
| `GEMINI_FILES_PREUPLOAD` / `IMAGE_PREP_EARLY` | `True` | Pre‑upload JPEGs to Gemini Files API |
| `SOLVE_TIMEOUT_S` | `30.0` | Per‑model wall clock in `model_solver` / `_solve_auto` |
| `TTS_PROVIDER` | `cartesia` | Lamp TTS engine |
| `FRONTEND_TTS_PROVIDER` | `piper` | Web‑bench TTS engine (no `gemini`) |
| `GEMINI_TTS_MODEL` | `gemini-2.5-flash-preview-tts` | Gemini TTS model |
| `GEMINI_TTS_VOICE` | `Aoede` | Gemini TTS prebuilt voice |
| `GEMINI_TTS_STREAM` | `False` | Stream Gemini audio chunks (unary by default) |
| `GEMINI_TTS_STYLE` | `"calm, clear, and matter-of-fact…"` | Delivery/tone prompt (steady tutor voice) |
| `TTS_MAX_INPUT_CHARS` | `800` | TTS cost/length cap |
| `TTS_CHUNK_MODE` | `balanced` | Chunking (unary Gemini only) |
| `PIPER_MODEL` | `""` | Path to `.onnx` Piper voice (empty disables) |
| `PIPER_MODE` | `library` | Warm in‑proc vs subprocess |
| `PIPER_SPEED` / `NOISE_SCALE` / `NOISE_W` / `SENTENCE_SILENCE` / `SPEAKER` | `1.0` / `0.667` / `0.8` / `0.2` / `-1` | Piper delivery tuning |
| `CARTESIA_API_KEY` | — | Cartesia TTS availability (**live** provider) |
| `CARTESIA_MODEL` / `CARTESIA_VOICE_ID` | `sonic-3.5` / "Skylar" | Cartesia model + voice |
| `CARTESIA_VERSION` / `CARTESIA_LANGUAGE` / `CARTESIA_TIMEOUT_S` | `2025-04-16` / `en` / `20.0` | Cartesia API version, language, per-call timeout (lowered `30 → 20` s on 2026-07-04, `a5533e5` — aligned with the 20 s LLM/TTS critical-path bound) |
| `CARTESIA_SPEED` / `CARTESIA_VOLUME` / `CARTESIA_EMOTION` | `0.9` / `1.0` / `""` | Tutor voice style (speed clamped 0.6–1.5, volume 0.5–2.0) |
| `TTS_WIRE_CODEC` / `TTS_OPUS_BITRATE` | `pcm` / `32000` | Lamp AUDIO_OUT codec |
| `TTS_TARGET_SAMPLE_RATE` / `TTS_CHUNK_BYTES` | `24000` / `4096` | Wire PCM contract |

---

## 8. Per-turn model flow (Mermaid)

```mermaid
flowchart TD
    Q["Turn: image(s) + audio + text"] --> PR{"Pre-router\nescalation_router.preroute\n(image quality + keywords)"}
    PR -- "blurry/dark + thin text" --> RETAKE["Retake request\n0 LLM spend"]
    PR -- "voice, no text\n(GROQ_API_KEY)" --> STT["Groq Whisper\nwhisper-large-v3(-turbo)\nrouting transcript"]
    STT --> T1
    PR -- "start_tier" --> T1{"Tier dispatch\n_call_tier / _solve_auto"}

    T1 -- "tier 1" --> FLASH["Gemini 3.1 Flash-Lite\nGEMINI_MODEL\nthinkingBudget=0, cap=1200"]
    FLASH --> GATE{"_should_escalate?\nconf<0.45 / hard / truncated / check"}
    GATE -- no --> SPEAK
    GATE -- "tier 2" --> FLASH2["Gemini Flash-Lite + thinking\nbudget=1024, cap=4000"]
    GATE -- "skip to Pro" --> PRO
    FLASH2 --> GATE2{"still shaky?"}
    GATE2 -- "tier 3" --> PRO["Gemini 3.1 Pro\nGEMINI_TIER3_MODEL\n+ code-execution sandbox"]
    GATE2 -- no --> SPEAK
    PRO --> SPEAK["reply (LlmReply / SimResponse)"]

    FLASH -. "Gemini server failure\n+ CLAUDE_TIMEOUT_FALLBACK" .-> CLAUDE["Claude\nclaude-sonnet-4-6\n(Whisper for audio)"]
    CLAUDE --> SPEAK

    SPEAK --> TTS{"TTS_PROVIDER\n(lamp) / FRONTEND_TTS_PROVIDER (web)"}
    TTS -- "gemini" --> GTTS["Gemini TTS\ngemini-2.5-flash-preview-tts\nvoice=Kore → 24kHz PCM"]
    TTS -- "piper" --> PIPER["Piper local ONNX\nen_US-amy-medium.onnx → 24kHz PCM"]
    GTTS --> WIRE["AUDIO_OUT\npcm/adpcm/opus"]
    PIPER --> WIRE

    subgraph BENCH["Direct bench pick (no tiering)"]
      DP["model_solver.generate_solution"] --> GPT["GPT-5 / GPT-5-mini\n(Whisper)"]
      DP --> DS["DeepSeek deepseek-chat\n(text-only, Whisper)"]
      DP --> CL2["Claude / any Gemini id"]
    end
```

---

### Two‑sentence summary

The Smart Tutor Lamp drives a Gemini‑centred tiered brain — **Gemini 3.1 Flash‑Lite** (`GEMINI_MODEL`) for tiers 1–2 escalating to **Gemini 3.1 Pro** (`GEMINI_TIER3_MODEL`) for hard/low‑confidence questions, with **Claude `claude-sonnet-4-6`** as a timeout fallback and a web bench that additionally compares GPT‑5/GPT‑5‑mini, DeepSeek `deepseek-chat`, and the full Gemini 2.x/3.x catalog through one provider‑agnostic solver. Speech uses **Groq Whisper** (`whisper-large-v3` / `-turbo`) for STT on non‑native‑audio providers and either **Gemini TTS** (`gemini-2.5-flash-preview-tts`, voice Kore) or local **Piper ONNX** voices for TTS — with **Cartesia Sonic** (`sonic-3.5`, `POST /tts/bytes`, ~170 ms first byte, no daily cap) now the default, continuous-audio lamp voice (`TTS_PROVIDER=cartesia`) — while embeddings/vector memory (`text-embedding-3-small` or `bge-small`) and Google‑search grounding remain stubbed/deferred.
