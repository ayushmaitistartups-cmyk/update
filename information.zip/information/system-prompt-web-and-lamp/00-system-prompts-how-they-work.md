# System Prompts (Web + Lamp) — How They Work

> The definitive deep-dive on the **Smart Tutor Lamp** system prompts across **both** delivery paths — the physical ESP32 lamp and the browser-based web simulator. Grounded entirely in the backend repo `D:/clartiy/Smart-Tutor-Lamp-backend`.

> **Updated 2026-07-03:** a third live shared prompt module — **`app/prompts/_guardrails.py`** (`GUARDRAILS`) — is now injected into *both* surface prompts (child-safety SAFETY/SCOPE/instruction-hierarchy/PRIVACY boundary, gated by `SAFETY_GUARD_ENABLED`, default ON). The lamp's `turn1` also grew four feature-gated rule fragments (graph / molecular-structure / rich-analytics / math-verifier capture), each zero-token unless its flag is on. STT/TTS/tier facts are unchanged except that **Cartesia Sonic TTS is now live** (see `01-llm-usage-and-models.md`).

> **Updated 2026-07-06 (backend `db470f6` — canonical record: [02-backend/13-brain-optimization-eval-harness-and-ci.md](../02-backend/13-brain-optimization-eval-harness-and-ci.md)):** the lamp prompt is now **versioned** — `PROMPT_VERSION = "1.0.0"` in `turn1_system.py` (semver, bump-on-edit changelog in the file header), stamped into turn traces (`llm_raw_prompt_brief`) and every eval result; `tests/test_prompt_version_budget.py` enforces semver, per-process byte-stability of `get_turn1_prompt()` (an implicit-cache prerequisite), and a prompt char/token budget. And the **math-verifier capture fragment is no longer zero-token by default**: `MATH_VERIFY_ENABLED` flipped `False → True`, so the hidden `VERIFY` block (+ its ~30-80 output tokens on quantitative turns) is injected into both surface prompts by default; the graph / molecular-structure / rich-analytics fragments still default OFF.

## Summary

The Smart Tutor Lamp project runs **two separate, deliberately non-shared system prompts** for one and the same tutor persona ("Lumos"). The **LAMP path** is driven by `app/prompts/turn1_system.py` (`get_turn1_prompt()`), whose math output is constrained to a **matplotlib-mathtext LaTeX subset** because it is painted on a small on-device TFT screen by `Latex_engine_tft.py`. The **WEB path** is driven by a completely **separate KaTeX-based prompt** built inside `app/providers/gemini_brain.py` (`_system_prompt()` + `_STRUCTURED_SUFFIX`), because the browser renders math with KaTeX (full LaTeX, aligned environments). The two prompts are *mirrors* of the same pedagogy and share two pieces of text — the LaTeX-subset rules (`app/prompts/_latex_rules.py`, lamp only) and `PERCEIVED_QUESTION_SUFFIX` (`turn1_system.py`, imported by both) — but they are **different strings with different display contracts**. A third path, `app/providers/web_simulator.py`, is a **deterministic, no-LLM, no-prompt fallback** used only when `GEMINI_API_KEY` is unset.

---

## Table of Contents

1. [Two paths, two prompts — the ground truth](#1-two-paths-two-prompts--the-ground-truth)
2. [The overall prompt architecture](#2-the-overall-prompt-architecture)
3. [The LAMP system prompt (`turn1_system.py`)](#3-the-lamp-system-prompt-turn1_systempy)
4. [The shared LaTeX rules (`_latex_rules.py`) and WHY (the TFT renderer)](#4-the-shared-latex-rules-_latex_rulespy-and-why-the-tft-renderer)
5. [The WEB system prompt (`gemini_brain.py`)](#5-the-web-system-prompt-gemini_brainpy)
6. [Lamp vs Web — side-by-side comparison](#6-lamp-vs-web--side-by-side-comparison)
7. [The deterministic `web_simulator` fallback (no-prompt path)](#7-the-deterministic-web_simulator-fallback-no-prompt-path)
8. [Runtime assembly — how a prompt is built and sent for a turn](#8-runtime-assembly--how-a-prompt-is-built-and-sent-for-a-turn)
9. [The dead prompts (`turn2`, `classifier`, modules, `escalation`)](#9-the-dead-prompts-turn2-classifier-modules-escalation)
10. [Mermaid diagrams — prompt selection & assembly per path](#10-mermaid-diagrams--prompt-selection--assembly-per-path)
11. [File:line index](#11-fileline-index)

---

## 1. Two paths, two prompts — the ground truth

There is **no single system-prompt text** shared by the two surfaces. The `gemini_brain.py` module docstring states this explicitly:

> *"Web brain — Gemini multimodal for the browser bench ... SEPARATE from the lamp's orchestrator/llm_gemini on purpose: the web renders LaTeX with **KaTeX** (full LaTeX, aligned envs), while the lamp renders a matplotlib mathtext subset — so the two surfaces have different display contracts and prompts."* — [`gemini_brain.py:1-7`](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py)

| Path | Prompt source | Selected when | Renderer |
|---|---|---|---|
| **Lamp** (physical device) | `app/prompts/turn1_system.py` → `get_turn1_prompt()` | always, for the ESP32 lamp via `orchestrator.py` | on-device TFT via `Latex_engine_tft.py` (matplotlib mathtext) |
| **Web** (simulator, LLM) | `app/providers/gemini_brain.py` → `_system_prompt()` + `_STRUCTURED_SUFFIX` | web bench when `GEMINI_API_KEY` is set | browser KaTeX (`react-katex`) |
| **Web** (deterministic fallback) | `app/providers/web_simulator.py` → **no prompt at all** | web bench when `GEMINI_API_KEY` is **unset** | browser (plain text only) |

**What they share (now three pieces of literal text):**

1. **`PERCEIVED_QUESTION_SUFFIX`** — defined in `turn1_system.py:21` and *imported by the web brain* (`gemini_brain.py:480`). The "capture the problem" transcription block, appended on both surfaces when `DEBUG_PERCEIVED_QUESTION` or `MEMO_CAPTURE_QUESTION` is on.
2. **`GUARDRAILS`** *(new 2026-07-03)* — defined in `app/prompts/_guardrails.py` and imported by **both** `turn1_system.py` (line 14) and `gemini_brain.py` (line 509). A single, surface-neutral child-safety boundary block (SCOPE / SAFETY / INSTRUCTIONS-ARE-FIXED / PRIVACY) that overrides every other instruction and anything the student says; prepended right after the persona line on each surface, gated by `SAFETY_GUARD_ENABLED` (default ON).
3. **Mirrored pedagogy** — the Socratic gate, FOCUS rules, verify-before-accuse, current-turn primacy, state isolation. These are *re-authored* in each prompt with surface-appropriate wording, not literally shared.

The lamp's `_latex_rules.LATEX_RULES` is shared **between the lamp's `turn1` and the (dead) `turn2`** — it is **not** used by the web brain, which has its own KaTeX display contract.

---

## 2. The overall prompt architecture

### 2.1 What is live vs. what is dead

The `app/prompts/` package contains ten prompt-producing items, but **only three are wired into production** (was two before the 2026-07-03 `_guardrails.py` addition):

| File | Live? | Role |
|---|---|---|
| `turn1_system.py` (`get_turn1_prompt`, `PERCEIVED_QUESTION_SUFFIX`) | **LIVE** | The single fresh-question prompt for **every lamp tier** (1, 2, and 3) |
| `_latex_rules.py` (`LATEX_RULES`) | **LIVE** | The mathtext subset, injected into `turn1` |
| `_guardrails.py` (`GUARDRAILS`) *(new 2026-07-03)* | **LIVE** (shared) | The child-safety boundary block, injected into **both** `turn1` and the web `gemini_brain` prompt; gated by `SAFETY_GUARD_ENABLED` |
| `turn2_system.py` (`get_turn2_prompt`) | **dead** | Never imported in production |
| `classifier.py` (`get_classifier_prompt`) | **dead** | Pre-classifier taxonomy that no longer matches `LlmReply` |
| `conceptual_module.py` (`get_conceptual_module_prompt`) | **dead** | Orphaned "conceptual track" rules |
| `technical_module.py` (`get_technical_module_prompt`) | **dead** | Orphaned "technical track" rules (uses `$…$`, the *opposite* of the live rule) |
| `escalation.py` (`get_escalation_prompt`) | **dead** | References `voice_output`/`is_confident` — fields that no longer exist |
| `_unused/` directory | **dead** | Older copies of the five dead files + a `README.md` |

This was verified by searching every importer (only `turn1_system` and `_latex_rules` are imported by `orchestrator.py`, `gemini_brain.py`, `model_solver.py`, and the test/probe scripts). The `_unused/README.md` confirms the simplification:

> *"...simplified to '`turn1_system.get_turn1_prompt()` for BOTH the tier-1 and the tier-2/escalation calls'... The web frontend uses a SEPARATE prompt in `app/providers/gemini_brain.py`."* — [`_unused/README.md:6-23`](D:/clartiy/Smart-Tutor-Lamp-backend/app/prompts/_unused/README.md)

### 2.2 "turn1 vs turn2" — there is no live turn-2 split

The original design (per `BACKEND_TODO.md`/`ESCALATION_PLAN.md`) had a **turn-1** fresh-question prompt and a separate **turn-2** follow-up prompt, plus a **classifier** prompt that routed to **conceptual** vs **technical** module prompts, plus an **escalation** prompt for the fallback model. **That entire two-tier-with-modules pipeline was retired.** Today:

- **One prompt drives every tier.** `system_prompt_arch.md:188-189` states: *"One prompt drives every tier (Pro replies to the student in the same dialect flash does — there is NO re-rendering step)."* The orchestrator instantiates it once: `self._turn1_prompt = get_turn1_prompt()` ([`orchestrator.py:45`](D:/clartiy/Smart-Tutor-Lamp-backend/app/services/orchestrator.py)).
- **Follow-ups are handled by context injection, not by a separate prompt.** The same `turn1` prompt carries CURRENT-TURN PRIMACY + CONTINUATION rules, and the orchestrator appends a `CONTINUATION_HINT` fragment when a reply-like message arrives mid-conversation ([`orchestrator.py:360-374`](D:/clartiy/Smart-Tutor-Lamp-backend/app/services/orchestrator.py)).
- **Classification happens inside the one call.** The model fills `query_type`/`subject`/`difficulty`/`confidence` as fields of its structured reply — these double as routing/analytics signals; there is no separate classifier LLM call.
- **Escalation reuses the same prompt** on a stronger model (Gemini Pro) rather than swapping in an escalation-specific prompt; the only difference is a key-free snapshot and an appended brief (see §8).

So the live "architecture" is: **one tutor prompt per surface + dynamically appended suffix fragments + a tiered model dispatcher**, not a tree of distinct prompts.

### 2.3 The conceptual/technical/escalation modules — when they fire

**They do not fire.** They are dead code retained for reference. The `_unused/README.md` and the existing doc `02-backend/07-prompts-and-llm-instructions.md` both flag that wiring them back would *contradict* the current contract (wrong field names, `$…$` inline LaTeX, mismatched `query_type` taxonomy). The live conceptual-vs-technical distinction is now expressed inside `turn1_system.py` and the web prompt as inline rules and the model's own `subject`/`query_type` self-classification, not as separate prompt modules.

---

## 3. The LAMP system prompt (`turn1_system.py`)

**Where it lives:** `app/prompts/turn1_system.py`, returned by `get_turn1_prompt()` ([line 47](D:/clartiy/Smart-Tutor-Lamp-backend/app/prompts/turn1_system.py#L47)). It is built once at orchestrator construction and cached for the process lifetime. Since 2026-07-06 the module also exports **`PROMPT_VERSION`** (`"1.0.0"`, [line 24](D:/clartiy/Smart-Tutor-Lamp-backend/app/prompts/turn1_system.py#L24)) — stamped as a `[prompt v…]` prefix into the turn trace's `llm_raw_prompt_brief` and into every eval result, so a quality regression is attributable to a specific prompt revision; `tests/test_prompt_version_budget.py` enforces semver + byte-stable assembly + the prompt's char/token budget (see 02-backend doc 13).

**Persona (line 48):**

```text
You are Lumos, a warm Socratic desk-lamp tutor.
```

### 3.1 What it instructs (section by section)

The prompt is large (~22 KB) and is structured into eight logical sections:

1. **INPUTS** (`turn1_system.py:50-113`) — three input kinds:
   - `audio` — the student's spoken question.
   - `images` — *0..5 JPEGs from the lamp's downward camera, in TIME ORDER*, treated as ONE continuous scene. The model must silently classify each image's **role**: `problem` / `detail` / `attempt` / `pointer` / `environment` (line 55-64). A `pointer` (finger/pen/stylus tip) is *a signal, not noise* — it tells the lamp **which** item to answer.
   - **FOCUS** (line 75-94) — a page often holds several questions; answer ONLY the one targeted by (a) **pointing** or (b) a spoken **reference** ("question 3", "part b"). Handles OCCLUSION (the pointing hand covers text) and CONFLICT (spoken "5" vs finger on "4" → ask one question).
   - **NEW DEVELOPMENTS** (line 95-107) — re-read each fresh image; the student may have advanced the working or moved the pointer.
   - **CONTEXT block** (line 108-113) — XML-tagged injected data: `<learner_profile>`, `<session_summary>`, `<recent_turns>` — *"read them, but NEVER read them aloud."*

2. **CURRENT-TURN PRIMACY + TWO-SIDED CONTEXT RULE** (`turn1_system.py:115-146`) — the most-guarded failure mode: *this turn's audio+images ARE the question; CONTEXT is background only.* Defines when a turn is **FRESH** (`same_problem=false`, carry nothing from history) vs a **CONTINUATION** (answer in context, never restart).

3. **OUTPUT contract + THREE INDEPENDENT OUTPUT CHANNELS** (`turn1_system.py:148-184`):
   - `speech` → *what the lamp SAYS out loud. Words only, no symbols.*
   - `display` → *TEXT card. Plain prose, ≤ 100 words. NO MATH NOTATION AT ALL.* Formulas are referenced by the lowercase token `eq1`/`eq2`/… that line up with the equation frames.
   - `latex_equations` → *ARRAY of LaTeX expressions. Each is ONE single-line equation, NO `$` delimiters, NO `\\` line breaks.*

   A worked example (line 182-184) drives home the rule that each formula is its **own** array entry, never a `\\`-chained string.

4. **STATE ISOLATION boundary** (`turn1_system.py:186-216`) — `problem_statement` and `solution_outline` are *background telemetry the student never sees*. The model is **forbidden** from copying their contents into the user channels, and on a first pass with an engaged student it must **never** deliver the final answer — exactly ONE Socratic nudge. The only exception is **SOLVE mode** (`[SOLVE AUTHORIZED]` note present, or explicit surrender after ≥1 hint).

5. **LATEX_RULES** (`turn1_system.py:218`) — the shared mathtext-subset block is interpolated here: `{LATEX_RULES}`. (Full detail in §4.)

6. **RULES 1-10** — speech brevity (2-3 sentences), equation separation, FOCUS, **VERIFY BEFORE YOU ACCUSE** (rule 4 — the false-alarm guard, now also carrying the **CHECK→VERDICT**, **CONSISTENCY anti-loop**, and **OBJECTIVE-QUESTION DIRECT VERDICT** carve-outs for answer-verification requests), confidence honesty (0.45-0.7 → say what you know + ask one question; below 0.45 the system silently re-runs on a stronger model), language matching, personalization, **READ THE ROOM** (nudge vs SOLVE — surrender requires a prior hint; "idk" is a nudge cue, not surrender; + the MULTIPLE-CHOICE name-the-option rule), **MATCH THE NUDGE TO WHERE THE STUDENT IS** (rule 9 — open-start orientation), and `user_input` (≤15-word memory line). The objective-verdict and open-start rules each have a deterministic pre-router half (see [02-backend/04-escalation-and-model-selection.md](../02-backend/04-escalation-and-model-selection.md)).

7. **Audit & analytics fields** (`turn1_system.py:275-307`) — `ocr_text`/`bounding_box` (visual-grounding audit), `confidence`/`difficulty` (these **drive escalation**), and the `problem_statement` **escalation HANDOFF package** in labeled `GIVEN/FIND/VISIBLE` sections.

8. **Memo fields** (`turn1_system.py:309-316`) — `solution_outline` (empty unless instructed to solve internally) and `same_problem` (true by default; flushes the problem memo when false).

### 3.2 Output schema expected (LAMP)

The lamp prompt tells the model the API constrains output to a **fixed structured shape** — the model fills fields, never writes JSON braces (line 148-153). The field set matches `app/schemas/llm_response.py` (`LlmReply`):

- **User-facing channels:** `speech`, `display{kind, content}`, `latex_equations[]`
- **Routing/analytics:** `confidence`, `query_type`, `subject`, `difficulty`, `user_input`
- **Escalation handoff:** `problem_statement`, `image_needed`
- **Memo/telemetry:** `solution_outline`, `same_problem`
- **Audit:** `ocr_text`, `bounding_box`
- **Semantic backstops:** `student_stuck`, `student_disputes_prior`
- **Hidden verifier group** (`equation`, `given`, `unknown`, `verification_summary`, `final_answer`, `answer_units`, `method_tag`) — emitted **by default** since `MATH_VERIFY_ENABLED` flipped ON (2026-07-06); the group sits FIRST in `LlmReply` so the constrained decoder derives before it declares/phrases (see 02-backend doc 13)

Internal fields ride only in the DEBUG_JSON channel (0x40), which the firmware drops (`system_prompt_arch.md:454-462`).

---

## 4. The shared LaTeX rules (`_latex_rules.py`) and WHY (the TFT renderer)

**Where it lives:** `app/prompts/_latex_rules.py`, the `LATEX_RULES` string, interpolated into `turn1_system.py` (and into the dead `turn2_system.py`). It is **not** used by the web brain.

**Why it exists — the on-device TFT renderer:** the lamp draws math with `Latex_engine_tft.py`, which uses **matplotlib mathtext** — a *strict subset* of LaTeX, not full LaTeX. The module docstring is unambiguous:

> *"matplotlib mathtext (Latex_engine_tft.py) is a STRICT SUBSET of LaTeX, not full LaTeX. The FORBIDDEN list below has all been observed to crash the on-device render in prior turns."* — [`_latex_rules.py:1-4`](D:/clartiy/Smart-Tutor-Lamp-backend/app/prompts/_latex_rules.py)

The rule string enumerates:

- **USE** (allowed): `\frac \dfrac \sqrt \sum \prod \int \oint \limits \infty \partial \nabla`, Greek letters, trig/log, accents (`\vec \hat \bar`), `\mathcal \mathbb \mathbf \mathrm`, relations, `\left(\right)`, spacing. ([`_latex_rules.py:11-16`](D:/clartiy/Smart-Tutor-Lamp-backend/app/prompts/_latex_rules.py))
- **NEVER** (crashes the render): `\tfrac \substack \boxed \text \xrightarrow \overset \underset \!`, `\\` line-breaks, `\color{}`, `\begin{aligned|cases|array}`, and **raw Unicode math** (∫√Σ). ([`_latex_rules.py:18-21`](D:/clartiy/Smart-Tutor-Lamp-backend/app/prompts/_latex_rules.py))
- **WIDTH constraint:** *"keep each equation ≤ ~40 characters of rendered math so it fits the lamp's 320 px screen in ONE frame."* Long relations must be split into two short equations. ([`_latex_rules.py:29-32`](D:/clartiy/Smart-Tutor-Lamp-backend/app/prompts/_latex_rules.py))
- **CAP:** hard cap of **3** equations (each extra makes the lamp's L/R scroll coarser). ([`_latex_rules.py:22-27`](D:/clartiy/Smart-Tutor-Lamp-backend/app/prompts/_latex_rules.py))
- **PROVEN-ON-THE-LAMP examples** (line 34-41) — e.g. `x=\dfrac{-b\pm\sqrt{b^2-4ac}}{2a}` and the Schrödinger equation — single line, no `$` delimiters.

This is the core reason the lamp and web prompts cannot share one text: the lamp's renderer would **crash** on the aligned/`\boxed`/`\text` constructs the web's KaTeX happily draws.

---

## 5. The WEB system prompt (`gemini_brain.py`)

**Where it lives:** `app/providers/gemini_brain.py`. It is assembled at runtime by `build_system_prompt()` ([line 471](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L471)) from three parts:

```python
def build_system_prompt(profile, extra_instruction=""):
    base = _system_prompt(profile) + _STRUCTURED_SUFFIX + (extra_instruction or "")
    if settings.DEBUG_PERCEIVED_QUESTION or settings.MEMO_CAPTURE_QUESTION:
        from app.prompts.turn1_system import PERCEIVED_QUESTION_SUFFIX
        base += PERCEIVED_QUESTION_SUFFIX
    return base
```
— [`gemini_brain.py:471-482`](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py)

### 5.1 `_system_prompt()` — the tutor body

`_system_prompt(profile)` ([line 61](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L61)) builds the Markdown-headed tutor contract. The same persona, restated for the browser:

```text
# WHO YOU ARE
You are Lumos, a warm, sharp study-tutor. Your students are mainly JEE
(Main/Advanced) and NEET aspirants. ...
```
— [`gemini_brain.py:62-68`](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py)

Sections (all in `_system_prompt`):

- `# WHO YOU ARE` (line 62)
- `# HOW YOU TALK` (line 70) — `speech` is spoken-only, no LaTeX/symbols/markdown; detail goes to the `display` channel.
- `# FOCUS (multi-question pages — answer ONLY the target)` (line 78) — the same priority order as the lamp: explicit number > pointer > single question > ask one question; plus OCCLUSION, CONFLICT, NEW DEVELOPMENTS.
- `# WHAT TO ANSWER (driven by query_type)` (line 104) — per-`query_type` templates (`mistake_id`, `check`, `formula`, `definition`, `calc`, `derivation`, `concept`, `other`) with hard voice word-caps.
- `# SOCRATIC GATE (which mode are you in?)` (line 146) — GUIDANCE default; SOLVE only via `[SOLVE AUTHORIZED]` or explicit surrender after ≥1 hint. Same state-isolation note as the lamp.
- `# HOW DEEP` (line 168), `# VERIFY YOUR OWN MATH` (line 176), `# CHECKING THE STUDENT'S WORK` (line 184 — the verify-before-accuse / false-alarm rule).

Then a **profile block** is appended if a `UserProfile` row is present (line 196-230): name, target exam, learning style, explain depth, study rhythm, focus/strong/weak subjects, ending with *"adapt to it; NEVER read it aloud."*

### 5.2 `_STRUCTURED_SUFFIX` — the KaTeX display contract

`_STRUCTURED_SUFFIX` ([line 415](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L415)) is where the web prompt **diverges hardest from the lamp** — it describes a KaTeX screen, not a mathtext frame array:

> *"# display — what appears on the screen ... It is rendered with KaTeX (full LaTeX; use an `aligned` environment to show multi-step working, every step on its own line)."* — [`gemini_brain.py:425-428`](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py)

Key differences encoded in the suffix:

- The display is **one `latex` string** (not an array of single-line frames). `type='latex'` → render `latex` with KaTeX; `type='text'`; `type='none'`.
- **Aligned multi-step environments are ALLOWED** in SOLVE mode — the exact opposite of the lamp's `\begin{aligned}`-forbidden rule.
- *"GRAPHS / PLOTS / DIAGRAMS / GEOMETRY FIGURES: KaTeX typesets equations, it does NOT draw graphs"* — describe in `speech`, equation in `latex` (line 440-443).
- `ocr_text`/`bounding_box` audit fields described identically to the lamp (line 457-467).

### 5.3 The structured output schema (WEB)

The web schema is the Pydantic `SimResponse` ([line 319](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L319)), with a nested `Display{type, latex, text}` ([line 311](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L311)). It is sent as Gemini's `response_schema` (line 601-603). Crucially the comments note the analytics + memo + audit fields are an **identical contract to the lamp's `LlmReply`**, so one dashboard covers both surfaces:

- **Channels:** `speech`, `display{type, latex, text}`
- **Analytics:** `confidence`, `query_type`, `subject`, `difficulty`, `user_input`
- **Memo:** `problem_statement`, `solution_outline`, `same_problem`
- **Semantic:** `student_stuck`, `student_disputes_prior`, `image_needed`
- **Audit:** `ocr_text`, `bounding_box`

### 5.4 How the WEB request is built

Two entry points:

1. **Streaming** `respond()` ([line 260](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L260)) — text-only timeline for the WS bench: `gen_config = types.GenerateContentConfig(system_instruction=_system_prompt(profile))` (line 279). Uses *only* the base tutor body (no structured suffix).
2. **Structured** `simulate_with_usage()` ([line 526](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L526)) — the `/simulate` path: builds multimodal `parts` (images first, then audio, then text — `_build_parts`, line 233), optionally prepends a history/continuation `Part` (line 553-593), and sends:

```python
cfg_kwargs = dict(
    system_instruction=build_system_prompt(profile, extra_instruction),
    response_mime_type="application/json",
    response_schema=SimResponse,
)
```
— [`gemini_brain.py:594-603`](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py)

The `model_solver._solve_system_prompt()` ([line 353](D:/clartiy/Smart-Tutor-Lamp-backend/app/services/model_solver.py#L353)) **reuses the exact same web body+suffix** (`_system_prompt(profile) + _STRUCTURED_SUFFIX + extra_instruction`) so all four providers (Gemini/OpenAI/Claude/DeepSeek) on the `/solve` bench get the identical tutor contract.

---

## 6. Lamp vs Web — side-by-side comparison

| Dimension | **LAMP path** | **WEB path (LLM)** |
|---|---|---|
| **Prompt source** | `app/prompts/turn1_system.py` → `get_turn1_prompt()` | `app/providers/gemini_brain.py` → `build_system_prompt()` (`_system_prompt` + `_STRUCTURED_SUFFIX`) |
| **Prompt format** | One long plain-text instruction string | Markdown-headed body + structured-format suffix |
| **LaTeX flavor** | matplotlib **mathtext** subset (strict) | **KaTeX** (full LaTeX) |
| **Renderer** | On-device TFT via `Latex_engine_tft.py` | Browser `react-katex` |
| **Math output target** | `latex_equations[]` — **array** of single-line frames, ≤40 chars each, **no `\\`, no `\boxed`, no `aligned`**, hard cap 3 | `display.latex` — **one** KaTeX string; `aligned` multi-step **allowed** in SOLVE mode |
| **Display channel** | `display{kind, content}` — plain prose ≤100 words, refs `eq1`/`eq2` | `display{type, latex, text}` — `latex`/`text`/`none` |
| **Output schema** | `LlmReply` (`app/schemas/llm_response.py`) | `SimResponse` (`gemini_brain.py:319`) |
| **Inputs** | audio + 0..5 camera JPEGs (capture order) | audio + images list + typed text |
| **Persona** | "Lumos, a warm Socratic desk-lamp tutor" | "Lumos, a warm, sharp study-tutor" |
| **Shared pieces** | `_latex_rules.LATEX_RULES` (interpolated); `PERCEIVED_QUESTION_SUFFIX` (imported); mirrored pedagogy (FOCUS, Socratic gate, verify-before-accuse, current-turn primacy, state isolation) | `PERCEIVED_QUESTION_SUFFIX` (imported from `turn1_system`); same mirrored pedagogy + same analytics/memo/audit field contract |
| **Escalation** | Same prompt re-run on Gemini Pro (key-free snapshot + brief) | Same prompt; `/solve` AUTO mode tiers; direct picks bypass routing but keep the contract |
| **Assembled by** | `orchestrator.py` | `gemini_brain.py` + `frontend_manager.py` (+ `model_solver.py` for `/solve`) |

**The deliberate asymmetry:** the lamp prompt forbids exactly the LaTeX constructs the web prompt *requires* for multi-step working (`aligned` environments, `\\` line breaks). They diverge because the renderers diverge — this is why they are kept as two prompts, not one.

---

## 7. The deterministic `web_simulator` fallback (no-prompt path)

**Where it lives:** `app/providers/web_simulator.py`. It is a **deterministic, no-LLM, no-system-prompt** brain.

**When it triggers:** only when `GEMINI_API_KEY` is unset. `gemini_brain.available()` returns `bool(settings.GEMINI_API_KEY)` ([line 49-50](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L49)); when that is false the web bench falls back to `web_simulator.respond()` so the frontend `/simulator` + `/api/frontend/ws` still exercise the full stack (framing, auth, TTS) without a live LLM. The module docstring:

> *"Deterministic brain fallback for the web bench — used when GEMINI_API_KEY is unset so the frontend `/simulator` + `/api/frontend/ws` still exercise the full stack (framing, auth, TTS) without a live LLM."* — [`web_simulator.py:1-11`](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/web_simulator.py)

**How it answers — there is no prompt and no model.** `respond()` ([line 37](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L37)) emits a fixed `thinking → speaking → idle` `BrainEvent` timeline and a **hard-coded templated string** that echoes the question and a generic Socratic nudge:

```python
answer = (
    f'You asked: "{user_text.strip()}". '
    f"Speaking to {_persona(profile)}, here's how I'd start: break the "
    "problem into the smallest assumption you're making, then verify just "
    "that one. What's the most uncertain part for you right now?"
)
```
— [`web_simulator.py:43-48`](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/web_simulator.py)

The only personalization is `_persona(profile)` (line 29-34), which reads `target_exam`/`prep_duration` directly off the profile row — no LLM, no system prompt, no LaTeX, no structured schema. It also defines the shared `BrainEvent` dataclass (line 21-27) that both this fallback and the real `gemini_brain.respond()` emit, so the WS gateway's `_drive_turn` is brain-agnostic.

---

## 8. Runtime assembly — how a prompt is built and sent for a turn

### 8.1 LAMP — `orchestrator.py`

The lamp builds the prompt by starting from the static base and **appending suffix fragments in a fixed order**.

**Step 1 — base + pre-route suffix** ([`orchestrator.py:342-343`](D:/clartiy/Smart-Tutor-Lamp-backend/app/services/orchestrator.py)):

```python
start_tier = decision.start_tier
system_prompt = self._turn1_prompt + decision.prompt_suffix
```

(`self._turn1_prompt` = `get_turn1_prompt()`, cached at init, line 45. `decision.prompt_suffix` carries the deterministic pre-router's answer-shaping note — FOCUS-target directive, mistake localization — or `""`.)

**Step 2 — perceived-question capture** ([`orchestrator.py:356-358`](D:/clartiy/Smart-Tutor-Lamp-backend/app/services/orchestrator.py)):

```python
if settings.DEBUG_PERCEIVED_QUESTION or settings.MEMO_CAPTURE_QUESTION:
    from app.prompts.turn1_system import PERCEIVED_QUESTION_SUFFIX
    system_prompt += PERCEIVED_QUESTION_SUFFIX
```

**Step 3 — continuation hint** (only with a Groq STT transcript + history) ([`orchestrator.py:368-374`](D:/clartiy/Smart-Tutor-Lamp-backend/app/services/orchestrator.py)):

```python
if _hist_has_turns and preroute_text:
    from app.services.escalation_router import (CONTINUATION_HINT, is_followup_text)
    if is_followup_text(preroute_text):
        system_prompt += CONTINUATION_HINT
```

**Step 4 — nudge-gate SOLVE authorization** ([`orchestrator.py:396-400`](D:/clartiy/Smart-Tutor-Lamp-backend/app/services/orchestrator.py)):

```python
solve_auth_reason = problem_memo.solve_authorized(memo, preroute_text, history_present=_hist_present)
if solve_auth_reason:
    system_prompt += problem_memo.solve_authorized_note(solve_auth_reason, int((memo or {}).get("nudges", 0) or 0))
```

**Step 5 — snapshot the key-free prompt** (the escalation re-call must NOT see the answer key) ([`orchestrator.py:409`](D:/clartiy/Smart-Tutor-Lamp-backend/app/services/orchestrator.py)):

```python
sans_key_prompt = system_prompt
```

**Step 6 — dispute note OR answer-key block OR question context** ([`orchestrator.py:416-445`](D:/clartiy/Smart-Tutor-Lamp-backend/app/services/orchestrator.py)):

```python
if dispute:                       # student says a prior answer is WRONG
    system_prompt += problem_memo.dispute_note(_dstmt)
    if self._llm_pro is not None:
        start_tier = 3            # force Pro; bypass key-suppression
elif memo:                        # cached verified answer key for this problem
    system_prompt += problem_memo.answer_key_block(memo)
    if start_tier > 1:
        start_tier = 1            # clamp: flash + key beats a cold Pro start
elif settings.MEMO_CAPTURE_QUESTION:
    qmemo = await problem_memo.load_question(...)
    if qmemo and (qmemo.get("statement") or "").strip():
        system_prompt += problem_memo.question_context_block(qmemo)
```

**Step 7 — send.** The assembled `system_prompt` (plus the separately-injected `history_text`, images, audio) is handed to `_call_tier()` ([`orchestrator.py:468-474`](D:/clartiy/Smart-Tutor-Lamp-backend/app/services/orchestrator.py)), and the verbatim string is persisted to the audit trace as `llm_raw_system_prompt` (line 466). On escalation, the `sans_key_prompt` snapshot is used so Pro never inherits a stale key.

**Assembly order (lamp):**

```
get_turn1_prompt()
  + decision.prompt_suffix        (FOCUS / mistake directive, or "")
  + PERCEIVED_QUESTION_SUFFIX     (if DEBUG_PERCEIVED_QUESTION | MEMO_CAPTURE_QUESTION)
  + CONTINUATION_HINT             (if follow-up transcript + history)
  + solve_authorized_note(...)    (if nudge gate authorizes a reveal)
  + [ dispute_note | answer_key_block | question_context_block ]   (mutually exclusive)
  + check_verdict_note()          (if is_check_request & not surrender/dispute/re-affirm)
```

### 8.2 WEB — `gemini_brain.py` + `frontend_manager.py`

The web base prompt is assembled by `build_system_prompt()` (§5, [line 471](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L471)): `_system_prompt(profile) + _STRUCTURED_SUFFIX + extra_instruction (+ PERCEIVED_QUESTION_SUFFIX)`.

The **history + continuation framing is injected as a user `Part`**, not into the system prompt — `simulate_with_usage()` prepends it ([`gemini_brain.py:566-593`](D:/clartiy/Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py)):

```python
parts.insert(0, types.Part.from_text(text=(
    "[Conversation so far this session — your earlier replies. BACKGROUND ONLY. ...]\n"
    f"{history_text}{_cont}\n\n"
    "[The message below is AUTHORITATIVE. FRESH applies when it states a NEW "
    "COMPLETE problem ... then set same_problem=false ... EVERYTHING ELSE is a "
    "CONTINUATION ...]"
)))
```

`_cont` is the `CONTINUATION_HINT` (same `escalation_router` helper as the lamp), added when `is_followup_text(user_text)` (line 559-563). The final config (line 594-603) sets `system_instruction`, `response_mime_type="application/json"`, and `response_schema=SimResponse`. `extra_instruction` (the deterministic pre-router's option-verification / mistake-localization suffix, parity with the lamp's `decision.prompt_suffix`) is appended *after* the structured suffix so it cannot break the JSON contract (line 596-599). The exact assembled string is persisted to the trace via `frontend_manager.py:1170` calling `gemini_brain.build_system_prompt(...)`.

---

## 9. The dead prompts (`turn2`, `classifier`, modules, `escalation`)

For completeness — these files exist but are **never imported in production**:

- **`turn2_system.py`** (`get_turn2_prompt`) — a follow-up prompt that hand-spells the JSON object and declares `latex_equations` as "0..8" (line 20), fighting the live `cap 3` in `_latex_rules.py`. It still imports `LATEX_RULES` but nothing imports *it*. The live system handles follow-ups via context injection on `turn1`, not a separate prompt.
- **`classifier.py`** (`get_classifier_prompt`) — a standalone query-classifier prompt with a `query_type` taxonomy (`conceptual_doubt`, `solving_support_*`, etc.) that does **not** match `LlmReply.query_type`. Classification now happens as a field inside the single tutor call.
- **`conceptual_module.py`** / **`technical_module.py`** — the retired conceptual-vs-technical track rules. `technical_module.py` instructs `$…$`/`$$…$$` inline LaTeX — the **opposite** of the live "no `$`, separate `latex_equations[]`" rule.
- **`escalation.py`** (`get_escalation_prompt`) — references `voice_output`/`is_confident`, fields that **do not exist** in the current `LlmReply` schema (it's `speech`/`confidence`). Escalation now reuses the `turn1` prompt on Pro.
- **`turn_handler.py`** (`app/services/`) — a mock BAO turn handler with a hard-coded `llm_response` dict using the same dead `voice_output`/`tft_display`/`is_confident` field names. Not on the live path; the live entry point is `orchestrator.TurnOrchestrator`.

The `_unused/README.md` documents the deprecation and explicitly warns: *"do not wire them back in without fixing them first, because they contradict the current contract."*

---

## 10. Mermaid diagrams — prompt selection & assembly per path

### 10.1 Prompt selection across both paths

```mermaid
flowchart TD
    A[Student turn] --> B{Which surface?}
    B -->|Physical lamp| C[orchestrator.py]
    B -->|Web bench| D{GEMINI_API_KEY set?}

    C --> E["get_turn1_prompt()<br/>(turn1_system.py)<br/>+ LATEX_RULES (mathtext subset)"]
    E --> F[Append suffix fragments<br/>see 10.2]
    F --> G[Send to Gemini tier 1/2/3<br/>same prompt every tier]
    G --> H[LlmReply schema<br/>latex_equations[] -> TFT mathtext frames]

    D -->|Yes| I["build_system_prompt()<br/>_system_prompt + _STRUCTURED_SUFFIX<br/>(gemini_brain.py, KaTeX contract)"]
    I --> J[Inject history/continuation as user Part]
    J --> K[Send to Gemini, response_schema=SimResponse]
    K --> L[SimResponse<br/>display.latex -> KaTeX]

    D -->|No| M["web_simulator.respond()<br/>NO PROMPT, NO LLM"]
    M --> N[Deterministic templated string<br/>BrainEvent timeline]
```

### 10.2 LAMP prompt assembly order (`orchestrator.py`)

```mermaid
flowchart TD
    A["self._turn1_prompt = get_turn1_prompt()  (cached at init)"] --> B["+ decision.prompt_suffix<br/>(FOCUS / mistake directive, or '')"]
    B --> C{"DEBUG_PERCEIVED_QUESTION<br/>or MEMO_CAPTURE_QUESTION?"}
    C -->|yes| D["+ PERCEIVED_QUESTION_SUFFIX"]
    C -->|no| E[skip]
    D --> F
    E --> F{"follow-up transcript<br/>+ history?"}
    F -->|yes| G["+ CONTINUATION_HINT"]
    F -->|no| H[skip]
    G --> I
    H --> I{"nudge gate authorizes<br/>a reveal?"}
    I -->|yes| J["+ solve_authorized_note(...)"]
    I -->|no| K[skip]
    J --> L
    K --> L["sans_key_prompt = snapshot<br/>(escalation uses this, key-free)"]
    L --> M{"dispute? / memo? / captured Q?"}
    M -->|dispute| N["+ dispute_note  -> force tier 3"]
    M -->|memo key| O["+ answer_key_block  -> clamp tier 1"]
    M -->|captured Q| P["+ question_context_block"]
    N --> Q[_call_tier]
    O --> Q
    P --> Q
```

### 10.3 WEB structured-call assembly (`gemini_brain.simulate_with_usage`)

```mermaid
flowchart TD
    A["_build_parts(text, audio, images)<br/>images first, then audio, then text"] --> B{"history present<br/>+ not 'no prior turns'?"}
    B -->|yes| C["parts.insert(0, history + continuation framing Part)<br/>+ CONTINUATION_HINT if is_followup_text"]
    B -->|no| D[parts unchanged]
    C --> E
    D --> E["system_instruction = build_system_prompt(profile, extra_instruction)<br/>= _system_prompt + _STRUCTURED_SUFFIX (+ PERCEIVED_QUESTION_SUFFIX)"]
    E --> F["GenerateContentConfig(<br/>system_instruction, response_mime_type=json, response_schema=SimResponse)"]
    F --> G["client.aio.models.generate_content(...)"]
    G --> H["SimResponse (parsed) or _salvage_sim fallback"]
```

---

## 11. File:line index

| What | Location |
|---|---|
| Lamp prompt builder | `app/prompts/turn1_system.py:47` (`get_turn1_prompt`) |
| Lamp persona | `app/prompts/turn1_system.py:48` |
| Lamp three channels | `app/prompts/turn1_system.py:155-184` |
| Lamp state isolation | `app/prompts/turn1_system.py:186-216` |
| Lamp RULES 1-9 | `app/prompts/turn1_system.py:220-273` |
| `PERCEIVED_QUESTION_SUFFIX` (shared) | `app/prompts/turn1_system.py:21-44` |
| Shared LaTeX rules | `app/prompts/_latex_rules.py:9-41` |
| LaTeX FORBIDDEN list | `app/prompts/_latex_rules.py:18-21` |
| LaTeX width/cap rules | `app/prompts/_latex_rules.py:22-32` |
| Web tutor body | `app/providers/gemini_brain.py:61-230` (`_system_prompt`) |
| Web KaTeX suffix | `app/providers/gemini_brain.py:415-468` (`_STRUCTURED_SUFFIX`) |
| Web prompt assembler | `app/providers/gemini_brain.py:471-482` (`build_system_prompt`) |
| Web structured schema | `app/providers/gemini_brain.py:311-412` (`Display`, `SimResponse`) |
| Web request build | `app/providers/gemini_brain.py:526-603` (`simulate_with_usage`) |
| Web history/continuation Part | `app/providers/gemini_brain.py:566-593` |
| Web availability gate | `app/providers/gemini_brain.py:49-50` (`available`) |
| Deterministic fallback | `app/providers/web_simulator.py:37-56` (`respond`) |
| Fallback templated answer | `app/providers/web_simulator.py:43-48` |
| Lamp prompt caching | `app/services/orchestrator.py:45` |
| Lamp base + pre-route suffix | `app/services/orchestrator.py:342-343` |
| Lamp suffix appends | `app/services/orchestrator.py:356-445` |
| Lamp key-free snapshot | `app/services/orchestrator.py:409` |
| Lamp send + trace | `app/services/orchestrator.py:459-474` |
| `/solve` shared web prompt | `app/services/model_solver.py:353-358` (`_solve_system_prompt`) |
| Web trace persist | `app/routes/frontend_manager.py:1170` |
| Dead prompts README | `app/prompts/_unused/README.md` |
| Architecture reference | `system_prompt_arch.md` |
| Existing prompts doc | `D:/clartiy/information/02-backend/07-prompts-and-llm-instructions.md` |
| `PROMPT_VERSION` + changelog | `app/prompts/turn1_system.py:19-24` |

_Re-verified against backend db470f6 on 2026-07-06._
