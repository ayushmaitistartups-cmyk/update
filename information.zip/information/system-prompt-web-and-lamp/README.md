# System Prompt (Web + Lamp) & LLM Usage

This folder documents **how the Smart Tutor Lamp's AI brain is instructed** — the system prompts that drive the LLMs — and **which models the project uses, where, and how**. It covers both delivery paths: the **web** path (the `/simulator` browser experience) and the **lamp** path (the physical ESP32-S3 device). Both flow through the same FastAPI backend brain but, importantly, **do not share the same system-prompt text**.

## Key fact up front

| | Lamp path | Web path |
|---|-----------|----------|
| System prompt lives in | [`app/prompts/turn1_system.py`](../../Smart-Tutor-Lamp-backend/app/prompts/turn1_system.py) | inside [`app/providers/gemini_brain.py`](../../Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py) |
| LaTeX flavor | matplotlib-mathtext **subset** (TFT-safe, capped) | **KaTeX** (richer, requires `aligned`) |
| Renders on | 320×240 on-device TFT | browser KaTeX |
| Shared pieces | `PERCEIVED_QUESTION_SUFFIX` + mirrored tutoring pedagogy | same |

When `GEMINI_API_KEY` is unset, the web path falls back to [`web_simulator.py`](../../Smart-Tutor-Lamp-backend/app/providers/web_simulator.py) — a **deterministic, no-LLM, no-prompt** brain used purely for offline demos/tests.

> **Updated 2026-07-03** (backend tip `80f04b6`): a third live shared prompt module, `app/prompts/_guardrails.py` (`GUARDRAILS`, gated by `SAFETY_GUARD_ENABLED`), is now injected into both surface prompts; and **Cartesia Sonic TTS is live** alongside Gemini TTS / Piper. Details in the two docs below.

## Documents

| Document | Covers |
|----------|--------|
| [00-system-prompts-how-they-work.md](00-system-prompts-how-they-work.md) | The full prompt architecture (turn1 vs turn2, classifier, conceptual/technical modules, escalation, LaTeX rules); the lamp prompt and *why* its LaTeX is constrained; the web KaTeX prompt and how it differs; a side-by-side comparison; the deterministic fallback; the runtime assembly of a prompt for one turn; representative quoted prompt text; and Mermaid diagrams of prompt selection/assembly. Also flags which prompt files are dead/legacy. |
| [01-llm-usage-and-models.md](01-llm-usage-and-models.md) | A master table of **every** model used — reasoning LLMs (Gemini 2.5 Flash → 2.5 Pro tiers, Claude fallback, plus the GPT-5 / DeepSeek / Gemini 3.x **bench** catalog), STT (Groq-hosted Whisper), TTS (Gemini TTS / local Piper ONNX / **Cartesia Sonic — now live**), and embeddings — with where and how each is invoked, the exact model ids, config/env vars, and the tiered escalation logic. |

## Where to find X

- **"How is the model told what to do?"** → `00-system-prompts-how-they-work.md`.
- **"Why is the lamp's math output so restricted?"** → the lamp-prompt section in doc 00 (matplotlib-mathtext / TFT renderer constraints).
- **"Which exact models/voices do we call, and what env var sets them?"** → the master table + Configuration reference in `01-llm-usage-and-models.md`.
- **"When does it escalate to a stronger model?"** → the tiered-brain section in doc 01 (and the deeper [`../02-backend/04-escalation-and-model-selection.md`](../02-backend/04-escalation-and-model-selection.md)).
- **"What's stubbed vs live?"** → doc 01 flags embeddings and grounding as not-yet-implemented; **Cartesia TTS is now live** (Gemini TTS / Piper / Cartesia all usable).
