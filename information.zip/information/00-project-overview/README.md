# Project Overview

This folder is the general, non-subsystem-specific overview for the **Smart Tutor Lamp** project, codename **Lumos**. Use it when you want to understand the complete product, architecture, workflows, data boundaries, and operating model before opening the detailed firmware, backend, frontend, database, simulator, and prompt documentation.

The rest of the `information/` folder is intentionally specific. This overview is the orientation layer.

## 1. Product Summary

Smart Tutor Lamp is an AI tutoring device built around a physical desk lamp. A student asks a question while working on paper; the lamp captures speech and a page image, sends both to the backend, and returns a spoken and visual answer.

The product is designed for paper-first study sessions:

- The student stays at the desk instead of moving to a laptop or phone.
- The lamp captures the page context with its camera.
- The student receives an answer through the speaker and a small TFT display.
- The system remembers learning context and powers parent/admin analytics through the web dashboard.

The key architectural rule is that the ESP32-S3 device is a thin real-time client. It captures, streams, plays, and displays; it does not run the LLM, speech-to-text, or server-side rendering.

## 2. System Goals

| Goal | Meaning |
| --- | --- |
| Low perceived latency | Target sub-2-second response perception from end-of-speech to first audio or first pixels. |
| Paper-native tutoring | Use microphone and camera input so the student can keep working on physical homework. |
| Safe, structured tutoring | Use guardrails, validation, escalation, and constrained output channels to keep answers useful and appropriate. |
| Hardware-light intelligence | Keep expensive intelligence in the backend, not on the ESP32-S3. |
| Multi-surface product | Support the physical lamp, a web dashboard, an admin console, and a browser simulator. |
| Durable learning memory | Persist sessions, turns, traces, feedback, costs, and learner profile data for personalization and analytics. |

## 3. High-Level Architecture

```mermaid
graph TB
    Student[Student at desk]
    Lamp[ESP32-S3 Smart Tutor Lamp]
    Backend[FastAPI Backend Brain]
    Models[LLM and Media Providers]
    Database[Supabase Postgres + pgvector]
    Frontend[Next.js Dashboard]
    Simulator[Web Simulator]
    Clerk[Clerk Identity]

    Student -->|speaks question, shows paper| Lamp
    Lamp -->|audio + JPEG over secure WebSocket| Backend
    Backend -->|multimodal solve, escalation, TTS, rendering| Models
    Models --> Backend
    Backend -->|paced audio + TFT frames| Lamp
    Backend -->|sessions, turns, memory, analytics, costs| Database
    Frontend -->|authenticated API calls| Backend
    Simulator -->|browser capture, same brain path| Backend
    Frontend <--> Clerk
```

The system has five major runtime surfaces:

- **Lamp firmware:** ESP32-S3 Arduino/C++ firmware for capture, transport, playback, display, pairing, settings, OTA, and hardware control.
- **Backend brain:** FastAPI service that owns the turn pipeline, model routing, media rendering, guardrails, persistence, analytics, admin, and OTA.
- **Frontend dashboard:** Next.js app for sign-in, onboarding, analytics, device pairing, admin tools, and pilot surfaces.
- **Web simulator:** Browser version of the lamp loop for demos, regression testing, and model comparison without hardware.
- **Database:** Supabase/Postgres durable store for devices, sessions, turns, traces, memory, costs, pilot data, insights, and firmware releases.

## 4. Core Workflow: One Student Question

1. **Wake and capture.** The student presses push-to-talk or says the wake phrase. The lamp records microphone audio, applies the DSP chain, detects end-of-speech, and captures one or more camera images.
2. **Stream to backend.** The lamp sends audio and JPEG data over a persistent secure binary WebSocket. The connection is authenticated with a backend-issued `device_jwt`.
3. **Assemble the turn.** The backend receives the multimodal payload, loads relevant memory and profile context, and builds the model request.
4. **Route the model.** A deterministic pre-router chooses the starting model tier. The backend can escalate to stronger models when the problem requires it.
5. **Generate the answer.** The selected LLM returns structured output for speech, screen text, and rendered math/media.
6. **Validate and guard.** Input guardrails, output validation, math/render checks, and post-answer gates keep the answer inside the expected teaching and safety boundaries.
7. **Render media.** The backend synthesizes speech and renders LaTeX, graph, or chemistry content into device-ready media.
8. **Stream response.** The backend sends sentence-chunked audio and chunked TFT frames back to the lamp.
9. **Persist off the hot path.** Turns, traces, costs, memory updates, feedback, and analytics signals are written to Postgres without blocking the live answer path.

## 5. Product Workflows

### Student Lamp Workflow

```mermaid
sequenceDiagram
    participant Student
    participant Lamp
    participant Backend
    participant LLM
    participant DB

    Student->>Lamp: Ask question and show page
    Lamp->>Backend: Audio frames + JPEG snapshot
    Backend->>DB: Read profile and memory context
    Backend->>LLM: Multimodal tutoring request
    LLM-->>Backend: Structured answer
    Backend->>Backend: Validate, render, synthesize
    Backend-->>Lamp: Audio chunks + TFT frames
    Lamp-->>Student: Spoken and visual tutoring answer
    Backend->>DB: Persist turn, trace, cost, memory
```

### Device Pairing Workflow

1. The lamp registers or requests a pairing code from the backend.
2. The lamp displays a QR code on the TFT.
3. The user signs in through the Next.js dashboard with Clerk.
4. The browser scans or opens the pairing code.
5. The backend links the Clerk user to the physical device.
6. The lamp receives or refreshes backend-owned device credentials.

The important boundary is that the lamp never talks to Clerk. Clerk owns human identity; the backend owns device identity.

### Web Simulator Workflow

The simulator reproduces the lamp loop in a browser:

- Browser microphone becomes the audio capture path.
- Browser camera becomes the page image path.
- The Next.js simulator page calls the same backend brain through HTTP or WebSocket routes.
- KaTeX/browser UI stands in for the lamp TFT.
- The same turn and analytics storage can be used, with simulator turns tagged separately.

This makes it possible to demo and test the AI brain without the ESP32 hardware.

### Admin and Pilot Workflow

The admin and pilot surfaces use the same backend and database to support:

- Pilot cohort monitoring.
- Turn feedback and surveys.
- Problem reports.
- Insights by topic, syllabus coverage, mistakes, engagement, and answer quality.
- Firmware OTA management.
- Model comparison and performance inspection.

These workflows sit around the live tutoring path rather than inside it, so operational visibility does not slow down the student response.

## 6. Data and Identity Model

The system deliberately separates human identity, device identity, and durable learning data.

| Boundary | Owner | Notes |
| --- | --- | --- |
| Human identity | Clerk | Used by the web dashboard and admin console. |
| Device identity | Backend | Uses `device_jwt` and hashed `device_secret`; the lamp never authenticates with Clerk. |
| Durable data | Supabase/Postgres | Stores devices, sessions, turns, traces, memory, costs, feedback, pilot data, insights tags, and OTA releases. |
| Hot memory/cache | Redis where configured | Used as an accelerator, not the durable source of truth. |
| Long-term learner memory | Postgres + pgvector path | Supports recall, personalization, and analytics. |

There is intentionally no internal `users` table. Rows store the Clerk `user_id` string directly.

## 7. AI and Model Architecture

The backend is provider-agnostic. It can call Gemini, Claude, OpenAI, or DeepSeek through a shared provider interface, while the model catalog tracks capabilities, prices, and routing behavior.

The tutoring response is structured into separate channels:

- **Speech:** what the student hears.
- **Display:** text and concise visual content for the TFT or web screen.
- **Rendered media:** LaTeX equations, graphs, chemistry structures, or images prepared for the target surface.

The lamp and web paths share the same backend but use different prompt constraints:

- The **lamp path** targets a small 320x240 TFT and constrained server-rendered math/media.
- The **web path** can use richer browser rendering such as KaTeX.

Guardrails and validators sit around the LLM so the raw model response is not blindly sent to the student or device.

## 8. Repository and Documentation Map

| Area | Purpose | Detailed docs |
| --- | --- | --- |
| Firmware | Physical ESP32-S3 lamp runtime | `../01-firmware/` |
| Backend | FastAPI brain and operational services | `../02-backend/` |
| Frontend | Next.js user/admin dashboard | `../03-frontend/` |
| Web Simulator | Browser stand-in for the lamp | `../04-web-simulator/` |
| Database | Supabase/Postgres schema and operations | `../05-database/` |
| Git History | Repo topology and commit timeline | `../06-git-history/` |
| Folder Details | File-by-file catalog | `../folder_details/` |
| System Prompt | Prompt and model inventory | `../system-prompt-web-and-lamp/` |

## 9. Operating Principles

- Keep the live turn path fast; persistence and analytics should not block the student-facing response.
- Keep hardware responsibilities narrow and deterministic.
- Keep human auth and device auth separate.
- Prefer structured outputs and explicit schemas over free-form model text.
- Keep the simulator aligned with the real lamp path so demos and tests are meaningful.
- Treat the database as optional at boot where possible, but authoritative when configured.
- Escalate model strength only when the problem warrants it.
- Preserve source-grounded documentation: architectural statements should trace back to code, docs, or git history.

## 10. Recommended Reading Path

For a new reader:

1. Read this overview.
2. Read `../README.md` for the master index.
3. Read `../02-backend/README.md` to understand the brain.
4. Read `../01-firmware/README.md` to understand the physical device.
5. Read `../03-frontend/README.md` for the human-facing product.
6. Read `../05-database/README.md` for durability, analytics, and memory.
7. Use `../folder_details/README.md` only when you need a file-level lookup.

## 11. Current State Summary

As of the 2026-07-06 documentation refresh:

- Firmware includes OTA, expanded TFT UI, graph and chemistry display support, a scroll-document reading page, and hardware-specific test rigs (tip `c699e72`, 2026-07-03).
- Backend includes model escalation, guardrails, validation, TTS, LaTeX/graph/chemistry rendering, pilot/insights/OTA/tagging subsystems, admin surfaces, the 2026-07-04 memory-leak/OOM hardening, and the 2026-07-06 brain-optimization pass (math verifier ON by default, MCQ option-match, prompt versioning, offline `evals/` harness, backend CI) — tip `db470f6`.
- Frontend includes dashboard, analytics, pairing, simulator, pilot survey/personalization, report-a-problem, admin insights, OTA controls, and loading skeletons. (The local `Smart-Tutor-frontend/` working copy was briefly removed from disk on 2026-07-06 and restored the same day by re-cloning; the tip is unchanged at `ef07d7f`, 2026-07-02.)
- Database documentation covers 24 ORM tables, including pilot instrumentation, insights tagging, and firmware release storage.
- Git history documents 181 commits across two repositories and three logical code histories, plus the `information` docs branch that carries this knowledge base.
