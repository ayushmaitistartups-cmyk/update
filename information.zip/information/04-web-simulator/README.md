# Web Simulator

The **Web Simulator** is the browser-based stand-in for the physical Smart Tutor Lamp. It lets anyone build, demo, and regression-test the AI tutor "brain" — multimodal capture (webcam image + spoken question + typed text), the multi-LLM solve pipeline, TTS, the KaTeX "screen", and conversational memory — entirely in a browser tab, **without ESP32 hardware**. It mirrors exactly what the lamp sends over the wire: a 16 kHz mono WAV uplink, JPEG snapshots, and optional text. It exercises the same backend brain and the same binary WebSocket frame protocol the firmware uses, and persists its turns to the same Postgres `turns` table (tagged `source="simulation"` / `source="simulator"`).

This area documents both halves of that bench. The **frontend** is a single client-rendered Next.js page (`/simulator`) plus a low-level media-capture hook that owns the `MediaStream`, Web Audio graph, WAV encoder, and JPEG snapshotter. The **backend** centers on `web_simulator.py`, a deterministic, dependency-free brain fallback that keeps the full streaming stack (framing, Clerk auth, state animation, sentence-chunked TTS) alive when no `GEMINI_API_KEY` is configured — and which also defines the shared `BrainEvent` streaming contract that both it and the real Gemini brain emit. Start with the overview, then dive into whichever side you are working on.

> **Updated 2026-07-06** (re-verified against backend `db470f6`; docs previously written 2026-06-16). `web_simulator.py` itself is byte-identical, but the surrounding web brain moved: the shared Gemini system prompt gained **objective-question direct verdicts** (dc9a936), **recheck-confirm consistency** and **open-start nudge** fixes (2026-06-18 commits), and a **prompt-side GUARDRAILS block** gated by `SAFETY_GUARD_ENABLED` (default on). Important scope clarification now stated in both docs: the code-enforced **output validator / input guard / math verifier are lamp-only** — the wiring briefly added to the web `_solve_auto` in `4d79344` was removed the same day in `1ed9d99`, and the web `SimResponse` never carried the hidden verifier fields (see `02-backend/13-brain-optimization-eval-harness-and-ci.md`).
>
> **Status note (2026-07-06).** The local `Smart-Tutor-frontend/` working copy was briefly removed from disk earlier today and has been restored by re-cloning the remote (tip unchanged at `ef07d7f`, 2026-07-02), so the frontend-side doc (02) is verifiable locally again.

## Documents

| Document | Summary |
| --- | --- |
| [00-overview.md](00-overview.md) | High-level overview of the Web Simulator's purpose: a browser stand-in that reproduces the lamp's wake → capture → solve → speak/display loop without hardware. Maps where the simulator plugs into the system, contrasts the two backends behind it (`/solve` HTTP vs `/ws` binary WebSocket), and gives a file-by-file breakdown of the capture hook, page, data layer, deterministic brain, and the `frontend_manager.py` gateway. |
| [01-backend-web-simulator.md](01-backend-web-simulator.md) | Inch-by-inch reference for `app/providers/web_simulator.py`, the deterministic brain fallback used when `GEMINI_API_KEY` is unset. Explains how it defines the shared `BrainEvent` dataclass (the source of truth for the streaming timeline), emulates the lamp's brain server-side with a scripted `THINKING → SPEAKING → text tokens → IDLE` sequence, and feeds the WS gateway's `_drive_turn` consumer. Covers the sibling `gemini_brain.respond`, constants, edge cases, and the full annotated source. |
| [02-frontend-simulator-ui.md](02-frontend-simulator-ui.md) | Inch-by-inch reference for the frontend Brain Simulator: `app/simulator/page.tsx` and `lib/useSimulatorCapture.ts`, plus the `lib/models.ts` / `lib/api.ts` data-layer glue. Details in-browser PCM-to-WAV audio encoding, hands-free multi-page auto-capture with sharpness and frame-diff gating, the multipart POST to the FastAPI Frontend Manager, and rendering of the split speech/display answer with KaTeX, per-call telemetry, a journey waterfall, and a feedback bar. |

## Where to find X

- **What the simulator is and why it exists** → [00-overview.md](00-overview.md) (Purpose & responsibility, System map)
- **`/solve` HTTP path vs `/ws` WebSocket path** → [00-overview.md](00-overview.md), section 3
- **How the simulator maps onto the real lamp** → [00-overview.md](00-overview.md), section 7
- **The deterministic fallback brain (no API key)** → [01-backend-web-simulator.md](01-backend-web-simulator.md)
- **The `BrainEvent` streaming contract / timeline format** → [01-backend-web-simulator.md](01-backend-web-simulator.md), sections 3-4
- **The WS gateway consumer `_drive_turn`** → [01-backend-web-simulator.md](01-backend-web-simulator.md), section 8
- **The real Gemini brain (`gemini_brain.respond`)** → [01-backend-web-simulator.md](01-backend-web-simulator.md), section 9
- **Browser audio capture / PCM → 16 kHz WAV encoding** → [02-frontend-simulator-ui.md](02-frontend-simulator-ui.md) (`useSimulatorCapture.ts`, section 5)
- **Webcam snapshot / hands-free multi-page auto-capture (sharpness + frame-diff gating)** → [02-frontend-simulator-ui.md](02-frontend-simulator-ui.md), section 7
- **The `/simulator` page UI, Compare mode, telemetry & feedback** → [02-frontend-simulator-ui.md](02-frontend-simulator-ui.md), sections 6 & 12
- **KaTeX / math-rich answer rendering** → [02-frontend-simulator-ui.md](02-frontend-simulator-ui.md), section 11
- **Data layer & wire protocol (`lib/models.ts`, `lib/api.ts`)** → [02-frontend-simulator-ui.md](02-frontend-simulator-ui.md), section 8
- **End-to-end control flow / sequence diagrams** → [00-overview.md](00-overview.md) (section 11) and [02-frontend-simulator-ui.md](02-frontend-simulator-ui.md) (sections 9-10)
- **Edge cases, errors, timeouts & fallbacks** → each doc's dedicated edge-cases section ([backend](01-backend-web-simulator.md) §11, [frontend](02-frontend-simulator-ui.md) §13)
