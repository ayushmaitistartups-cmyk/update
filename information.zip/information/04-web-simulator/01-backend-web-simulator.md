# Web Simulator — Backend (web_simulator.py)

`app/providers/web_simulator.py` is the **deterministic brain fallback** for the Smart Tutor Lamp's web bench. When no live LLM key (`GEMINI_API_KEY`) is configured, the frontend `/simulator` page and the `/api/frontend/ws` WebSocket gateway still need *something* to drive the full streaming stack — framing, Clerk auth, state animation, sentence-chunked TTS. This module supplies a tiny, dependency-free, fully scripted "tutor" that emits the exact same `BrainEvent` timeline the real Gemini brain emits, so the WS gateway (`_drive_turn`) never has to know which brain produced the stream. It also **defines the `BrainEvent` dataclass** that is the shared streaming contract for both brains.

This document is the inch-by-inch reference for that 68-line file and everything it touches on the server side.

---

## Table of Contents

1. [Purpose & Responsibility](#1-purpose--responsibility)
2. [Where It Sits in the System](#2-where-it-sits-in-the-system)
3. [Architecture & Data Structures](#3-architecture--data-structures)
4. [Function-by-Function Breakdown](#4-function-by-function-breakdown)
5. [The Complete Control Flow](#5-the-complete-control-flow)
6. [Algorithms, Math, Constants & Thresholds](#6-algorithms-math-constants--thresholds)
7. [Data Processing: Inputs → Transforms → Outputs](#7-data-processing-inputs--transforms--outputs)
8. [Integration: The WS Gateway Consumer (`_drive_turn`)](#8-integration-the-ws-gateway-consumer-_drive_turn)
9. [The Sibling Brain: `gemini_brain.respond`](#9-the-sibling-brain-gemini_brainrespond)
10. [Configuration, Environment Variables & Constants](#10-configuration-environment-variables--constants)
11. [Edge Cases, Error Handling, Timeouts, Fallbacks](#11-edge-cases-error-handling-timeouts-fallbacks)
12. [Cross-References (firmware / backend / frontend / db)](#12-cross-references-firmware--backend--frontend--db)
13. [Mermaid Diagrams](#13-mermaid-diagrams)
14. [Appendix: Full Annotated Source](#14-appendix-full-annotated-source)

---

## 1. Purpose & Responsibility

The module docstring states its mission precisely ([web_simulator.py:1-11](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L1)):

> Deterministic brain fallback for the web bench — used when `GEMINI_API_KEY` is unset so the frontend `/simulator` + `/api/frontend/ws` still exercise the full stack (framing, auth, TTS) without a live LLM.
> Defines `BrainEvent` (the streaming timeline both this and `gemini_brain` emit) so the WS gateway's `_drive_turn` doesn't care which brain produced it.
> Ported from the prototype backend (`brain/simulator.py`), adapted to the main backend's `app.protocol.StateByte` and the `UserProfile` row.

So it carries **three distinct responsibilities**:

1. **Define the shared streaming contract** — the `BrainEvent` dataclass. Both `web_simulator.respond` *and* `gemini_brain.respond` yield `BrainEvent` objects, and `gemini_brain` imports `BrainEvent` *from this module* ([gemini_brain.py:25](Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L25)). This file is therefore the *source of truth* for the timeline format, not merely a fallback.
2. **Emulate the lamp's brain server-side, deterministically** — produce a `THINKING → SPEAKING → text tokens → text_end → IDLE` timeline with no external calls, no API key, no network, and no randomness.
3. **Drive the full UI animation pipeline** — by emitting the same `STATE` transitions and word-by-word text tokens the real brain emits, the browser UI shows the identical typing/state animation whether or not a real LLM is wired up.

What it deliberately does **not** do: it never touches audio (no STT), never reads the image, never calls TTS, never persists anything, and never reasons. It only consumes `user_text` (typed text) and an optional `profile`, and it always answers with the *same template* regardless of the question's content. It is a stage prop, not a tutor.

---

## 2. Where It Sits in the System

The lamp's brain has **two web-facing implementations** that share the `BrainEvent` contract:

| Brain | File | Used when | Capabilities |
|---|---|---|---|
| Gemini multimodal | `app/providers/gemini_brain.py` | `GEMINI_API_KEY` is set (`gemini_brain.available()` → `True`) | Real STT + reasoning + vision (audio, image, text) |
| Deterministic simulator | `app/providers/web_simulator.py` | `GEMINI_API_KEY` unset (`available()` → `False`) | Scripted text-only echo, no audio/image use |

The choice between them is made in **one place** — the WS gateway's `_build_stream` closure ([frontend_manager.py:1937-1940](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1937)):

```python
def _build_stream(user_text, audio_wav, image_jpeg) -> AsyncIterator[BrainEvent]:
    if gemini_brain.available():
        return gemini_brain.respond(user_text, profile, audio_wav=audio_wav, image_jpeg=image_jpeg)
    return web_simulator.respond(user_text or "", profile)
```

Note the asymmetry: `gemini_brain.respond` is handed `audio_wav` and `image_jpeg`; `web_simulator.respond` receives **only** `user_text or ""` and `profile`. Audio and image are silently discarded for the simulator path — it can't process them. (This is the only call site of `web_simulator.respond` in the entire repo — confirmed by grep: the only references are the import in `frontend_manager.py`, the import of `BrainEvent` in `gemini_brain.py`, and the definitions inside `web_simulator.py` itself.)

`web_simulator` lives in `app/providers/`, alongside the other pluggable provider modules (`gemini_brain`, `llm_*`, `tts_*`). The web bench is intentionally **isolated from the lamp's orchestrator** (`app/services/orchestrator.py`) — it has its own brains (`gemini_brain` / `web_simulator`), its own TTS knob (`FRONTEND_TTS_PROVIDER`, not `TTS_PROVIDER`), and its own WS route (`/api/frontend/ws`, not the lamp's `/ws/lamp`).

---

## 3. Architecture & Data Structures

The whole module is one dataclass + three functions. The imports are minimal ([web_simulator.py:12-18](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L12)):

```python
from __future__ import annotations
import asyncio
from dataclasses import dataclass
from typing import Any, AsyncIterator
from app.protocol import StateByte
```

The only first-party dependency is `StateByte` from `app/protocol.py` — the single-byte STATE enum the lamp's wire protocol uses ([protocol.py:89-96](Smart-Tutor-Lamp-backend/app/protocol.py#L89)).

### 3.1 `BrainEvent` (dataclass)

The central data structure ([web_simulator.py:21-26](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L21)):

```python
@dataclass
class BrainEvent:
    """One piece of work the WS gateway should send to the client."""
    kind: str            # "state" | "text" | "text_end"
    payload: str = ""
    state_byte: int = 0
```

| Field | Type | Default | Meaning |
|---|---|---|---|
| `kind` | `str` | *(required)* | Discriminator. One of `"state"`, `"text"`, `"text_end"`. |
| `payload` | `str` | `""` | UTF-8 text token. Only meaningful for `kind="text"`. |
| `state_byte` | `int` | `0` | A `StateByte` value (`0`–`5`). Only meaningful for `kind="state"`. |

`BrainEvent` is a **tagged union** expressed via the `kind` field. The consumer (`_drive_turn`) switches on `kind`:

- `kind == "state"` → send a `STATE` frame carrying `state_byte` (the UI's lamp-state animation).
- `kind == "text"` → send a `TEXT_OUT` frame carrying `payload.encode("utf-8")`, *and* feed `payload` into the sentence-chunking buffer for TTS.
- `kind == "text_end"` → flush any remaining sentence to TTS, then send `TEXT_OUT_END`.

This three-value contract is exactly the set both brains produce — `gemini_brain.respond` uses the same three kinds ([gemini_brain.py:281-304](Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L281)). The default values (`payload=""`, `state_byte=0`) let `state` events omit `payload` and `text`/`text_end` events omit `state_byte`.

### 3.2 The `profile` object (duck-typed)

`respond` and `_persona` accept `profile: Any | None`. In practice this is a `UserProfile` SQLAlchemy row ([db/models.py:109](Smart-Tutor-Lamp-backend/app/db/models.py#L109)) fetched by `_load_profile_ws` ([frontend_manager.py:1908-1917](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1908)). Only two columns are read, and both are nullable strings:

| Column | Type | Read by | Used as |
|---|---|---|---|
| `target_exam` | `str \| None` ([db/models.py:130](Smart-Tutor-Lamp-backend/app/db/models.py#L130)) | `_persona` | the exam name in the persona string |
| `prep_duration` | `str \| None` ([db/models.py:131](Smart-Tutor-Lamp-backend/app/db/models.py#L131)) | `_persona` | the prep window in the persona string |

The module uses `getattr(...)` with defaults rather than attribute access, so it is robust to *any* object (or `None`) being passed — it never assumes a real `UserProfile`. This duck-typing is why the type hint is `Any | None`.

> A DB check constraint restricts `target_exam` to `('JEE','NEET','CAT','UPSC')` or NULL ([db/models.py:147](Smart-Tutor-Lamp-backend/app/db/models.py#L147)), so in practice `_persona` will substitute one of those four exam codes.

---

## 4. Function-by-Function Breakdown

### 4.1 `_persona(profile) -> str`

[web_simulator.py:29-34](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L29)

```python
def _persona(profile: Any | None) -> str:
    if profile is None:
        return "a learner"
    exam = getattr(profile, "target_exam", None) or "their exam"
    prep = getattr(profile, "prep_duration", None) or "ongoing prep"
    return f"a {exam} aspirant ({prep})"
```

Builds the addressee phrase folded into the canned answer. Mechanics:

- **No profile** → returns the literal string `"a learner"`.
- **Profile present** →
  - `exam = profile.target_exam or "their exam"` — note the `or` short-circuit also catches the empty-string and `None` cases, not just a missing attribute. So a `UserProfile` with `target_exam=None` yields `"their exam"`.
  - `prep = profile.prep_duration or "ongoing prep"` — same fallback logic.
  - Returns `f"a {exam} aspirant ({prep})"`, e.g. `"a JEE aspirant (6 months)"` or `"a their exam aspirant (ongoing prep)"` if both are blank.

This function is **pure** (no I/O, no side effects, deterministic). It is the only place `profile` influences output.

### 4.2 `respond(user_text, profile) -> AsyncIterator[BrainEvent]`

[web_simulator.py:37-56](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L37)

The heart of the module — an **async generator** that streams the scripted timeline:

```python
async def respond(user_text: str, profile: Any | None) -> AsyncIterator[BrainEvent]:
    """Stream a tiny thinking → speaking → idle timeline + a few text tokens
    so the UI shows the typing/STATE animation exactly like the real brain."""
    yield BrainEvent(kind="state", state_byte=int(StateByte.THINKING))
    await asyncio.sleep(0.15)

    answer = (
        f'You asked: "{user_text.strip()}". '
        f"Speaking to {_persona(profile)}, here's how I'd start: break the "
        "problem into the smallest assumption you're making, then verify just "
        "that one. What's the most uncertain part for you right now?"
    )

    yield BrainEvent(kind="state", state_byte=int(StateByte.SPEAKING))
    for chunk in _word_chunks(answer):
        await asyncio.sleep(0.04)
        yield BrainEvent(kind="text", payload=chunk)

    yield BrainEvent(kind="text_end")
    yield BrainEvent(kind="state", state_byte=int(StateByte.IDLE))
```

Step-by-step:

1. **Emit `THINKING` state** — `yield BrainEvent(kind="state", state_byte=int(StateByte.THINKING))`. `StateByte.THINKING == 0x02` ([protocol.py:92](Smart-Tutor-Lamp-backend/app/protocol.py#L92)). The `int(...)` cast turns the `IntEnum` into a plain `int` for the dataclass field.
2. **Sleep 0.15 s** — `await asyncio.sleep(0.15)`. A cosmetic "thinking" delay so the UI shows the spinner state momentarily, mimicking real LLM latency.
3. **Compose the canned answer** — a fixed template string that (a) echoes the user's question verbatim via `user_text.strip()` (whitespace trimmed), (b) addresses the persona via `_persona(profile)`, and (c) gives generic tutoring advice ("break the problem into the smallest assumption you're making, then verify just that one. What's the most uncertain part for you right now?"). The answer's *content* is constant; only the echoed question and persona vary.
4. **Emit `SPEAKING` state** — `StateByte.SPEAKING == 0x03` ([protocol.py:93](Smart-Tutor-Lamp-backend/app/protocol.py#L93)).
5. **Stream text in word-chunks** — `for chunk in _word_chunks(answer)`: each iteration sleeps **0.04 s** then yields a `text` event with that chunk as `payload`. The sleep simulates token-by-token streaming (≈ the typing animation).
6. **Emit `text_end`** — signals end of the assistant message. `_drive_turn` uses this to flush the last sentence to TTS and send `TEXT_OUT_END`.
7. **Emit `IDLE` state** — `StateByte.IDLE == 0x00` ([protocol.py:91](Smart-Tutor-Lamp-backend/app/protocol.py#L91)). Returns the UI to rest.

The function `return`s implicitly after the last `yield`, ending the async iterator.

Because it is an async generator, **cancellation propagates cleanly**: if the caller cancels the task mid-stream (e.g. the user sends a new `TEXT_IN` or `CANCEL`), the `await asyncio.sleep(...)` raises `asyncio.CancelledError` at the next suspension point and the generator unwinds — no cleanup needed since it holds no resources.

### 4.3 `_word_chunks(text, size=3) -> list[str]`

[web_simulator.py:59-67](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L59)

```python
def _word_chunks(text: str, size: int = 3) -> list[str]:
    words = text.split(" ")
    out: list[str] = []
    for i in range(0, len(words), size):
        chunk = " ".join(words[i : i + size])
        if i + size < len(words):
            chunk += " "
        out.append(chunk)
    return out
```

Splits `text` into groups of **`size=3` words** for "streaming". Mechanics:

1. `words = text.split(" ")` — split on a single literal space. (Not `.split()` — so a run of multiple spaces would yield empty-string "words"; the template has only single spaces, so this is fine in practice.)
2. Iterate `i` over `0, 3, 6, …` (`range(0, len(words), 3)`).
3. `chunk = " ".join(words[i:i+3])` — join up to 3 words with a single space.
4. **Trailing-space rule**: `if i + size < len(words): chunk += " "`. A trailing space is appended to every chunk *except the last one*. This is the load-bearing detail — it re-inserts the inter-chunk spaces that the `" ".join` would otherwise lose at chunk boundaries. The condition `i + size < len(words)` is false precisely on the final iteration (when the window reaches or passes the end), so the last chunk has **no** trailing space. Concatenating all chunks reproduces the original text exactly (modulo the trailing space).
5. Returns the list of chunks.

**Why this matters for downstream:** `_drive_turn` concatenates each `text` payload into a `sentence_buf` for sentence detection ([frontend_manager.py:2049](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2049)). If the chunker dropped the spaces between chunks, words would fuse (`"break theproblem into"`) and the TTS would mispronounce. The trailing-space rule preserves word boundaries across the streamed pieces.

**Worked example.** For `answer` (≈ 50 words), `_word_chunks` produces ⌈50/3⌉ ≈ 17 chunks. Each is emitted 0.04 s apart, so the streaming portion lasts ≈ 17 × 0.04 ≈ **0.68 s**, plus the 0.15 s thinking delay → a full turn is ≈ **0.83 s** of scripted latency before `IDLE`.

---

## 5. The Complete Control Flow

From entry to exit, a single simulator turn:

```
respond("what is entropy?", <UserProfile JEE/6mo>)
  │
  ├─ yield STATE(THINKING=2)            ──► _drive_turn sends FrameType.STATE [0x02]
  ├─ await sleep(0.15)
  │
  ├─ answer = 'You asked: "what is entropy?". Speaking to a JEE aspirant
  │            (6 months), here\'s how I\'d start: break the problem into ...'
  │
  ├─ yield STATE(SPEAKING=3)            ──► _drive_turn sends FrameType.STATE [0x03]
  │
  ├─ for chunk in _word_chunks(answer): # ~17 chunks of ≤3 words each
  │     await sleep(0.04)
  │     yield TEXT(chunk)               ──► _drive_turn sends FrameType.TEXT_OUT(chunk)
  │                                          + buffers chunk, splits on .!?,
  │                                          + _speak_sentence(...) → AUDIO_OUT frames (Piper)
  │
  ├─ yield TEXT_END                     ──► _drive_turn flushes tail sentence to TTS,
  │                                          sends FrameType.TEXT_OUT_END
  └─ yield STATE(IDLE=0)               ──► _drive_turn sends FrameType.STATE [0x00]
                                            (after loop: if audio_sent → AUDIO_OUT_END)
```

The generator yields **`2 (states) + N (text chunks) + 1 (text_end) + 1 (idle)`** events. For the canonical answer that is ≈ `2 + 17 + 1 + 1 = 21` events.

The **lifecycle** is owned by `_drive_turn`, which wraps the whole iteration in a task (`inflight`). The generator never sends frames itself — it only produces `BrainEvent`s; the gateway translates them to wire frames. This separation is the entire point of the `BrainEvent` contract.

---

## 6. Algorithms, Math, Constants & Thresholds

Every numeric constant and rule in the module, quoted from the code:

| Constant / rule | Value | Location | Effect |
|---|---|---|---|
| Thinking delay | `0.15` s | [web_simulator.py:41](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L41) | Cosmetic pause showing the THINKING state before SPEAKING. |
| Per-chunk delay | `0.04` s | [web_simulator.py:52](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L52) | Inter-token pacing → the typing animation. 25 chunks/s. |
| Words per chunk | `size = 3` | [web_simulator.py:59](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L59) | Granularity of the streamed text. |
| THINKING state byte | `0x02` | [protocol.py:92](Smart-Tutor-Lamp-backend/app/protocol.py#L92) | First state emitted. |
| SPEAKING state byte | `0x03` | [protocol.py:93](Smart-Tutor-Lamp-backend/app/protocol.py#L93) | Emitted before text streaming. |
| IDLE state byte | `0x00` | [protocol.py:91](Smart-Tutor-Lamp-backend/app/protocol.py#L91) | Final state, returns UI to rest. |
| Persona fallbacks | `"a learner"`, `"their exam"`, `"ongoing prep"` | [web_simulator.py:31-33](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L31) | Defaults when profile/fields are missing. |

There is **no real math, no randomness, no thresholds, no retries** inside this module — it is purely deterministic. The only "algorithm" of substance is the chunking trailing-space reconstruction in `_word_chunks` (§4.3). The total scripted turn latency is `0.15 + 0.04 × ⌈W/3⌉` seconds where `W` is the answer's word count.

The downstream algorithms that *act on* this module's output (sentence-splitting regex, TTS chunking) live in the consumer and are documented in §8.

---

## 7. Data Processing: Inputs → Transforms → Outputs

| Stage | Input | Transform | Output |
|---|---|---|---|
| Entry | `user_text: str`, `profile: Any\|None` | — | — |
| Persona | `profile` | `_persona`: read `target_exam`/`prep_duration` via `getattr` with `or`-defaults | persona phrase |
| Compose | `user_text`, persona | f-string template; `user_text.strip()` | fixed `answer` string |
| Chunk | `answer` | `_word_chunks`: split on `" "`, regroup ×3, re-append spaces except last | `list[str]` of word-chunks |
| Stream | chunks, states | async-yield with `asyncio.sleep` pacing | `AsyncIterator[BrainEvent]` |

**Inputs the simulator ignores:** `audio_wav` and `image_jpeg` are never passed to `respond` (the WS gateway only forwards them to `gemini_brain`). So even if a `/simulator` user uploads a webcam JPEG and records audio, the simulator-fallback path discards both and answers from the typed text alone (`user_text or ""`). If the user sent *only* audio (no text), the simulator receives `""` and the answer becomes `You asked: "". Speaking to ...` — an empty echo. This is a known limitation of the fallback, not a bug.

---

## 8. Integration: The WS Gateway Consumer (`_drive_turn`)

The module's output only becomes wire traffic through `frontend_manager.py`. This section documents that consumer so the integration is complete.

### 8.1 The WS route: `brain_ws`

[frontend_manager.py:1920-1996](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1920)

The `/api/frontend/ws` endpoint:

1. **Auth** — `verify_ws_token(token)` ([frontend_manager.py:1923](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1923)) verifies a Clerk session JWT passed in the `?token=` query (browsers can't set an `Authorization` header on a WS handshake — [clerk_ws.py:73-103](Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py#L73)). On failure it closes with code **4401**.
2. **Accept + initial state** — accepts the socket and immediately sends `STATE[IDLE]` ([frontend_manager.py:1930](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1930)).
3. **Load profile** — `_load_profile_ws(user_id)` ([frontend_manager.py:1908](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1908)) opens a short-lived DB session and best-effort fetches the `UserProfile`; on any exception it logs and returns `None`. This `profile` is the one handed to `web_simulator.respond`.
4. **Per-connection state** — `inflight` (the current turn `Task`), `audio_chunks` (accumulated `AUDIO_CHUNK` payloads), `latest_image` (last `IMAGE_JPEG` payload).
5. **Receive loop** — decodes each binary frame via `app.protocol.decode` and dispatches by `FrameType`:
   - `CANCEL (0x04)` → cancel `inflight`, clear `audio_chunks`, send `STATE[IDLE]`.
   - `IMAGE_JPEG (0x01)` → stash as `latest_image`.
   - `AUDIO_CHUNK (0x02)` → append to `audio_chunks`.
   - `TEXT_IN (0x50)` → cancel any in-flight turn, decode UTF-8, build stream, start `_drive_turn` task.
   - `AUDIO_END (0x03)` → cancel in-flight, join `audio_chunks`, wrap PCM → WAV (`_pcm_to_wav` at `BRAIN_AUDIO_SAMPLE_RATE`), build stream, start `_drive_turn` task.
   - `IMAGE_PART` and any other frame → accepted and silently dropped ([frontend_manager.py:1986](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1986)).
6. **Frame validation** — a malformed frame (`decode` raises `ValueError`) closes the socket with code **1002** ("bad frame").
7. **Teardown** — in `finally`, any `inflight` task is cancelled and awaited with a 3 s timeout, swallowing `CancelledError`/`TimeoutError`/`Exception` ([frontend_manager.py:1990-1995](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1990)).

For the **simulator path specifically**, `_build_stream` returns `web_simulator.respond(user_text or "", profile)` ([frontend_manager.py:1940](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1940)) — so a `TEXT_IN` frame is what actually exercises the simulator; `AUDIO_END` produces `respond(None or "", profile)` → an empty-question echo (see §7).

### 8.2 `_drive_turn` — translating `BrainEvent`s to wire frames

[frontend_manager.py:2030-2081](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2030)

This coroutine consumes the `AsyncIterator[BrainEvent]` and is brain-agnostic — it works identically for `web_simulator` and `gemini_brain`. Per event:

- `kind == "state"` → `_send_frame(ws, FrameType.STATE, bytes([event.state_byte]))` ([frontend_manager.py:2046](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2046)).
- `kind == "text"` → send `FrameType.TEXT_OUT` with `payload.encode("utf-8")`, append `payload` to `sentence_buf`, then loop `_split_sentence` to pull out completed sentences and `_speak_sentence` each ([frontend_manager.py:2047-2055](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2047)).
- `kind == "text_end"` → flush the trailing buffer to TTS, then send `FrameType.TEXT_OUT_END` ([frontend_manager.py:2056-2061](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2056)).
- After the loop: if any audio was sent, send `FrameType.AUDIO_OUT_END` (releases I2S on the lamp; harmless flush marker on the browser) ([frontend_manager.py:2062-2063](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2062)).

**TTS selection** ([frontend_manager.py:2039](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2039)): `tts = get_tts_provider(settings.FRONTEND_TTS_PROVIDER)`. Crucially, the web bench uses `FRONTEND_TTS_PROVIDER` (`piper`/`none`), **not** `TTS_PROVIDER`. The comment is emphatic: this guarantees the browser surface can *never* call Gemini TTS or spend Gemini audio tokens, and `get_tts_provider("piper")` lazily imports *only* `tts_piper` so the Gemini TTS module isn't even loaded on this path ([frontend_manager.py:2032-2038](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2032); enforced by `_import_provider` in [tts_base.py:233-244](Smart-Tutor-Lamp-backend/app/providers/tts_base.py#L233)). When `FRONTEND_TTS_PROVIDER="none"`, `get_tts_provider` returns `None` and the bench is silent — the `/simulator` page speaks via the browser's own Web Speech API regardless.

### 8.3 Sentence-splitting algorithm

[frontend_manager.py:1998-2008](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1998)

```python
_SENTENCE_END_RE = re.compile(r"([.!?])(\s|$)")

def _split_sentence(buf: str) -> tuple[str | None, str]:
    m = _SENTENCE_END_RE.search(buf)
    if not m:
        return None, buf
    end = m.end()
    return buf[:end].strip(), buf[end:]
```

A sentence boundary is a `.`, `!`, or `?` followed by whitespace **or** end-of-string. The simulator's word-chunks accumulate in `sentence_buf` until a boundary appears, at which point the completed sentence is handed to TTS so the first audio lands quickly rather than after the whole reply. The canned `answer` has three sentence terminators (the echoed `."`, the period after "verify just that one.", and the final `?`), so the simulator turn produces up to **three** TTS sentences.

### 8.4 `_speak_sentence` — TTS leg

[frontend_manager.py:2084-2101](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2084)

Returns early (`False`) if `tts is None`, `not tts.available`, or empty sentence. Otherwise iterates `tts.synthesize(sentence, turn_id=...)` and sends each non-empty chunk as a `FrameType.AUDIO_OUT` frame. `TTSError` and unexpected exceptions are logged and **swallowed** (text already went out); `asyncio.CancelledError` is re-raised. So a TTS failure never breaks a simulator turn.

---

## 9. The Sibling Brain: `gemini_brain.respond`

For contrast (and because it imports `BrainEvent` from this module), here is the real brain's timeline ([gemini_brain.py:260-304](Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L260)):

1. `available()` returns `bool(settings.GEMINI_API_KEY)` ([gemini_brain.py:49-50](Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L49)) — this is the switch that decides simulator-vs-real.
2. Builds multimodal `parts` from `user_text`, `audio_wav`, and `images` (folding the legacy single `image_jpeg` into `[image_jpeg]`).
3. Yields `STATE(THINKING)`, then opens `client.aio.models.generate_content_stream(...)` against `settings.GEMINI_MODEL`.
4. On the first chunk with text it yields `STATE(SPEAKING)` (lazy, `spoke` flag), then yields a `text` event per streamed chunk.
5. If the stream produced no text (`not spoke`), it yields `SPEAKING` + a fallback `text`: `"I couldn't make that out — try again, or hold the page steadier."`
6. Yields `text_end`, then `STATE(IDLE)`.

The structural parallel to `web_simulator.respond` is exact: same five-phase timeline (`THINKING → SPEAKING → text* → text_end → IDLE`), same `BrainEvent` kinds. The difference is `gemini_brain` derives the text from a live model and consumes audio+image, while `web_simulator` scripts it. This is precisely what lets `_drive_turn` stay brain-agnostic.

`gemini_brain` adds transient-retry plumbing the simulator doesn't need: `_TRANSIENT_STATUS = {429, 500, 502, 503, 504}`, `_SIM_RETRIES = 2`, `_SIM_BACKOFF_S = 0.8` ([gemini_brain.py:33-35](Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L33)) — there are no such retries in `web_simulator` because there is nothing to fail.

> **Update (2026-07-06):** the sibling brain's shared `_system_prompt` — the system instruction this streamed `respond()` primes with — was retuned since this doc was written: objective questions (MCQ / true-false / fill-in-the-blank) with a committed student answer now get a DIRECT verdict instead of a Socratic nudge (dc9a936, 2026-06-19); repeat rechecks confirm the SAME verdict instead of inventing a new objection each time, and open-ended requests start from the genuine first step (74c3e2f / b235d4e / 6cc7423, 2026-06-18). The one-shot `simulate()` path additionally prepends the child-safety `GUARDRAILS` block via `build_system_prompt`, gated by `SAFETY_GUARD_ENABLED` (default `True`, 2026-07-01) — the streamed `respond()` does NOT carry it. None of this touches `web_simulator.py` — the fallback module and its timeline are byte-identical to what is documented here. See doc 13 for the full change record.

---

## 10. Configuration, Environment Variables & Constants

The simulator module reads **no settings directly**; its behavior is governed indirectly by the WS gateway's configuration:

| Setting | Type / default | Where read | Effect on the simulator path |
|---|---|---|---|
| `GEMINI_API_KEY` | `str` | `gemini_brain.available()` ([gemini_brain.py:50](Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L50)) | **The switch.** Unset → `_build_stream` falls back to `web_simulator.respond`. Set → simulator never runs. |
| `FRONTEND_TTS_PROVIDER` | `Literal["piper","none"]` = `"piper"` ([config.py:82](Smart-Tutor-Lamp-backend/app/config.py#L82)) | `_drive_turn` ([frontend_manager.py:2039](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2039)) | Which engine voices the simulator's streamed sentences. `"none"` → silent bench. *Excludes* `"gemini"` by type so the bench can never spend Gemini audio tokens. |
| `BRAIN_AUDIO_SAMPLE_RATE` | `int` = `16000` ([config.py:166](Smart-Tutor-Lamp-backend/app/config.py#L166)) | `_pcm_to_wav` for the `AUDIO_END` path | Sample rate for WAV-wrapping uplink mic PCM. Irrelevant to the simulator since it ignores audio, but shapes the `AUDIO_END` branch that *calls* the simulator. |
| `TTS_MAX_INPUT_CHARS` | `int` = `800` ([config.py:134](Smart-Tutor-Lamp-backend/app/config.py#L134)) | `clamp_tts_text` in providers | Caps TTS input; the simulator's ≈50-word answer is well under this. |
| Clerk JWKS config (`CLERK_JWKS_URL` / `CLERK_PUBLISHABLE_KEY` / `CLERK_ISSUER`) | — | `verify_ws_token` ([clerk_ws.py](Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py)) | Gates the WS handshake before any brain runs. |

Constants *internal* to the module (the only true config it owns) are the three numeric literals (`0.15`, `0.04`, `size=3`) and three fallback strings, all documented in §6. None are environment-overridable — they are hardcoded animation parameters.

---

## 11. Edge Cases, Error Handling, Timeouts, Fallbacks

The module itself is almost unbreakable because it has no I/O. Behaviors at the boundaries:

- **`profile is None`** → `_persona` returns `"a learner"`; the answer still composes. Handled explicitly ([web_simulator.py:30](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L30)).
- **Profile with blank/None `target_exam` or `prep_duration`** → `or`-fallbacks substitute `"their exam"` / `"ongoing prep"` ([web_simulator.py:32-33](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L32)).
- **Profile is some other object** → `getattr(profile, ..., None)` never raises `AttributeError`; missing attributes fall back. Robust to any `Any`.
- **Empty `user_text`** (e.g. the `AUDIO_END` path passing `None or ""`) → `user_text.strip()` yields `""`, producing `You asked: "". ...`. No crash; just a degenerate echo.
- **Cancellation mid-stream** → `_drive_turn`'s task is cancelled on a new `TEXT_IN`/`AUDIO_END`/`CANCEL` or on disconnect; the generator's `await asyncio.sleep(...)` raises `CancelledError` and the generator unwinds cleanly (no open resources). `_drive_turn` catches `CancelledError`, best-effort sends `AUDIO_OUT_END` if audio was already sent, and re-raises ([frontend_manager.py:2065-2071](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2065)).
- **Any exception in the brain stream** → `_drive_turn`'s generic `except` logs, then best-effort sends `STATE[ERROR]` + a `TFT_TEXT` apology ("Sorry, the brain stumbled. Try again.") + `AUDIO_OUT_END` (if needed) + `STATE[IDLE]` ([frontend_manager.py:2072-2081](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2072)). The simulator effectively never reaches this path since it cannot fail.
- **TTS failure** → swallowed in `_speak_sentence`; text still delivered. No timeout in the simulator path; the only "timeout" in scope is the 3 s `wait_for` on the in-flight task during WS teardown ([frontend_manager.py:1993](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1993)).
- **No retries / no fallbacks inside the module** — by design. The simulator *is* the fallback (for an absent Gemini key), so it has nothing to fall back to.

---

## 12. Cross-References (firmware / backend / frontend / db)

**Backend (this module's direct neighbors):**

- `app/protocol.py` — `StateByte` enum it emits ([protocol.py:89](Smart-Tutor-Lamp-backend/app/protocol.py#L89)); `FrameType` + `encode`/`decode` the gateway uses to put those states on the wire.
- `app/providers/gemini_brain.py` — the real brain; **imports `BrainEvent` from this module** ([gemini_brain.py:25](Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L25)) and emits the same timeline.
- `app/routes/frontend_manager.py` — the **only consumer**: `_build_stream` selects it ([L1940](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1940)), `_drive_turn` runs it ([L2030](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2030)).
- `app/providers/tts_base.py` — `get_tts_provider` / `TTSError` used to voice the streamed text ([tts_base.py:149](Smart-Tutor-Lamp-backend/app/providers/tts_base.py#L149)).
- `app/deps/clerk_ws.py` — `verify_ws_token` gating the WS handshake ([clerk_ws.py:73](Smart-Tutor-Lamp-backend/app/deps/clerk_ws.py#L73)).
- `app/db/models.py` — `UserProfile` row whose `target_exam`/`prep_duration` feed `_persona` ([db/models.py:109](Smart-Tutor-Lamp-backend/app/db/models.py#L109)).
- `app/config.py` — `GEMINI_API_KEY`, `FRONTEND_TTS_PROVIDER`, `BRAIN_AUDIO_SAMPLE_RATE`.

**Frontend:** The `/simulator` page and `lib/useSimulatorCapture.ts` capture mic PCM at `BRAIN_AUDIO_SAMPLE_RATE` (16 kHz) and connect to `/api/frontend/ws` with `?token=<Clerk JWT>` ([config.py:160-166](Smart-Tutor-Lamp-backend/app/config.py#L160)). The browser sends `TEXT_IN`/`AUDIO_CHUNK`/`AUDIO_END`/`IMAGE_JPEG`/`CANCEL` frames and renders `STATE`/`TEXT_OUT`/`TEXT_OUT_END`/`AUDIO_OUT` it receives.

**Firmware (the device this emulates):** The simulator stands in for the ESP32-S3 lamp's brain. It reuses the lamp's **binary frame protocol** (`app/protocol.py`) — the web frame types `TEXT_IN`/`TEXT_OUT`/`TEXT_OUT_END` (`0x50`/`0x51`/`0x52`) are a *superset* above the lamp's range; a physical lamp silently drops unknown types ([protocol.py:79-86](Smart-Tutor-Lamp-backend/app/protocol.py#L79)). The `STATE`/`AUDIO_OUT` frames it emits are the *same* ones the real firmware consumes, which is why the bench "exercises the full stack." Per the docstring it was ported from the prototype's `brain/simulator.py`.

**Database:** The simulator path itself persists nothing. (The separate web `/solve` HTTP path writes `turn_traces` tagged `source=simulation`/`simulator` — [frontend_manager.py:1500-1506](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1500) — but that path uses `model_solver`, not this module.) The only DB read is `_load_profile_ws` fetching the `UserProfile` row.

---

## 13. Mermaid Diagrams

### 13.1 Brain selection & event flow (flowchart)

```mermaid
flowchart TD
    A["Browser /simulator → WS /api/frontend/ws<br/>(TEXT_IN / AUDIO_END frame)"] --> B{"gemini_brain.available()?<br/>(GEMINI_API_KEY set)"}
    B -- "yes" --> C["gemini_brain.respond<br/>(audio_wav, image_jpeg, user_text)"]
    B -- "no" --> D["web_simulator.respond(user_text or '', profile)"]
    D --> E["yield STATE(THINKING=0x02)"]
    E --> F["await sleep 0.15s"]
    F --> G["answer = template(user_text.strip(), _persona(profile))"]
    G --> H["yield STATE(SPEAKING=0x03)"]
    H --> I["_word_chunks(answer, size=3)"]
    I --> J["for each chunk: sleep 0.04s → yield TEXT(chunk)"]
    J --> K["yield TEXT_END"]
    K --> L["yield STATE(IDLE=0x00)"]
    C --> M["_drive_turn (brain-agnostic)"]
    L --> M
    M --> N["STATE/TEXT_OUT/TEXT_OUT_END frames → browser"]
    M --> O["sentence-split → Piper TTS → AUDIO_OUT frames"]
```

### 13.2 One simulator turn (sequence)

```mermaid
sequenceDiagram
    participant B as Browser (/simulator)
    participant WS as brain_ws (/api/frontend/ws)
    participant DT as _drive_turn
    participant SIM as web_simulator.respond
    participant TTS as Piper (FRONTEND_TTS_PROVIDER)

    B->>WS: connect ?token=<Clerk JWT>
    WS->>WS: verify_ws_token() → user_id
    WS-->>B: STATE[IDLE]
    WS->>WS: _load_profile_ws(user_id) → profile
    B->>WS: TEXT_IN "what is entropy?"
    WS->>DT: create_task(_drive_turn(respond("what is entropy?", profile)))
    DT->>SIM: async for event
    SIM-->>DT: STATE(THINKING)
    DT-->>B: STATE[0x02]
    Note over SIM: await sleep 0.15s
    SIM-->>DT: STATE(SPEAKING)
    DT-->>B: STATE[0x03]
    loop ~17 word-chunks (sleep 0.04s each)
        SIM-->>DT: TEXT(chunk)
        DT-->>B: TEXT_OUT(chunk)
        DT->>DT: buffer + _split_sentence
        opt sentence complete
            DT->>TTS: synthesize(sentence)
            TTS-->>DT: PCM chunks
            DT-->>B: AUDIO_OUT(chunk)*
        end
    end
    SIM-->>DT: TEXT_END
    DT->>TTS: synthesize(tail sentence)
    DT-->>B: TEXT_OUT_END
    SIM-->>DT: STATE(IDLE)
    DT-->>B: STATE[0x00]
    DT-->>B: AUDIO_OUT_END (if audio sent)
```

---

## 14. Appendix: Full Annotated Source

```python
# app/providers/web_simulator.py  (entire file, 68 lines)

from __future__ import annotations
import asyncio
from dataclasses import dataclass
from typing import Any, AsyncIterator
from app.protocol import StateByte                       # only first-party dep

@dataclass
class BrainEvent:                                        # the SHARED streaming contract
    kind: str            # "state" | "text" | "text_end"
    payload: str = ""    # text token (kind=="text")
    state_byte: int = 0  # StateByte value (kind=="state")

def _persona(profile):                                   # pure; builds addressee phrase
    if profile is None:
        return "a learner"
    exam = getattr(profile, "target_exam", None) or "their exam"
    prep = getattr(profile, "prep_duration", None) or "ongoing prep"
    return f"a {exam} aspirant ({prep})"

async def respond(user_text, profile):                   # async generator: the timeline
    yield BrainEvent(kind="state", state_byte=int(StateByte.THINKING))  # 0x02
    await asyncio.sleep(0.15)                             # cosmetic think delay
    answer = (f'You asked: "{user_text.strip()}". '      # echo + generic tutoring advice
              f"Speaking to {_persona(profile)}, here's how I'd start: break the "
              "problem into the smallest assumption you're making, then verify just "
              "that one. What's the most uncertain part for you right now?")
    yield BrainEvent(kind="state", state_byte=int(StateByte.SPEAKING))  # 0x03
    for chunk in _word_chunks(answer):                   # stream ≤3-word pieces
        await asyncio.sleep(0.04)                         # 25 chunks/s typing pace
        yield BrainEvent(kind="text", payload=chunk)
    yield BrainEvent(kind="text_end")                    # end of message
    yield BrainEvent(kind="state", state_byte=int(StateByte.IDLE))      # 0x00

def _word_chunks(text, size=3):                           # split into 3-word chunks,
    words = text.split(" ")                               #   re-appending spaces except
    out = []                                              #   on the final chunk so the
    for i in range(0, len(words), size):                  #   concatenation reproduces text
        chunk = " ".join(words[i:i+size])
        if i + size < len(words):
            chunk += " "
        out.append(chunk)
    return out
```

---

### Summary of mechanics

- **Contract owner:** defines `BrainEvent` — the `(kind, payload, state_byte)` tagged-union both brains emit.
- **Activation:** runs *only* when `GEMINI_API_KEY` is unset (`gemini_brain.available()` is `False`).
- **Output:** a deterministic `THINKING(0.15s) → SPEAKING → ~17 word-chunks(0.04s each) → text_end → IDLE` timeline, ≈0.83 s total.
- **Inputs honored:** typed `user_text` (echoed, stripped) and `UserProfile.target_exam`/`prep_duration` (persona). Audio and image are not passed and are ignored.
- **Consumer:** `frontend_manager.py:_drive_turn` translates each `BrainEvent` into `STATE`/`TEXT_OUT`/`TEXT_OUT_END` wire frames and sentence-chunks the text into Piper TTS `AUDIO_OUT` frames — identical handling to the real Gemini brain.

_Re-verified against backend db470f6 on 2026-07-06._
