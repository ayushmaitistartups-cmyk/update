# Web Simulator — Frontend UI & Capture Hook

The browser-based **Brain Simulator** (`/simulator`) is a developer/QA test bench that mimics exactly what the physical Smart Tutor Lamp sends to the backend: a spoken question (16 kHz mono WAV) plus 0–5 webcam/uploaded images, optionally plus typed text. It captures audio as raw PCM through the Web Audio graph, encodes it to WAV in-browser, performs hands-free multi-page auto-capture from the live webcam (with sharpness + frame-diff gating), POSTs a multipart form to the FastAPI "Frontend Manager", and renders the model's split "speech / display" answer with KaTeX, per-call telemetry, an input→output journey waterfall, and a feedback bar. This document is the inch-by-inch reference for the two assigned files — [`app/simulator/page.tsx`](Smart-Tutor-frontend/app/simulator/page.tsx) and [`lib/useSimulatorCapture.ts`](Smart-Tutor-frontend/lib/useSimulatorCapture.ts) — plus the data-layer glue that wires them to the backend.

> **Updated 2026-07-03** (frontend tip `ef07d7f`). The simulator gained three resource/correctness fixes from the 2026-07-02 optimization pass: `useSimulatorCapture` now releases the camera/mic/`AudioContext` on unmount (§5.5), the preview-URL unmount cleanup revokes the *live* list via a ref (§6.2), and `endTalk` has a synchronous double-send guard (§6.4). The route also added a `loading.tsx` skeleton (`<PageSkeleton active="/simulator">`). See the repo-root `OPTIMIZATION.md`.
>
> **Status note (2026-07-06).** The local `Smart-Tutor-frontend/` working copy was briefly removed from disk earlier today and has been **restored** by re-cloning the remote (tip unchanged at `ef07d7f`, 2026-07-02 — exactly the code this document describes). The file links below resolve locally again.

---

## Table of contents

1. [Purpose & responsibility](#1-purpose--responsibility)
2. [Architecture overview](#2-architecture-overview)
3. [Constants, configuration & environment](#3-constants-configuration--environment)
4. [Key data structures](#4-key-data-structures)
5. [The capture hook — `useSimulatorCapture.ts`](#5-the-capture-hook--usesimulatorcapturets)
6. [The page — `app/simulator/page.tsx`](#6-the-page--appsimulatorpagetsx)
7. [Algorithms in detail](#7-algorithms-in-detail)
8. [Data layer & wire protocol (`lib/models.ts`, `lib/api.ts`)](#8-data-layer--wire-protocol-libmodelsts-libapits)
9. [Complete end-to-end control flow](#9-complete-end-to-end-control-flow)
10. [Sequence diagram: simulator → backend → LLM → back](#10-sequence-diagram-simulator--backend--llm--back)
11. [Rendering pipeline (KaTeX, math-rich text)](#11-rendering-pipeline-katex-math-rich-text)
12. [Telemetry, journey & feedback](#12-telemetry-journey--feedback)
13. [Edge cases, errors, timeouts & fallbacks](#13-edge-cases-errors-timeouts--fallbacks)
14. [Integration points / cross-references](#14-integration-points--cross-references)
15. [Function-by-function index](#15-function-by-function-index)

---

## 1. Purpose & responsibility

The simulator is a **single client-rendered Next.js page** (`"use client"`). Its job is to be a faithful, in-browser stand-in for the lamp's capture + upload path so a developer can:

- Test the multi-LLM "brain" without flashing firmware or owning hardware.
- Speak a question (push-to-talk) while pointing a webcam at a worksheet — *"exactly what the lamp sends"* ([page.tsx:419-423](Smart-Tutor-frontend/app/simulator/page.tsx#L419)).
- Type a question, or upload/snap image(s), with any combination of audio/images/text.
- Pick a **single model** or turn on **Compare mode** to run several models side-by-side.
- Inspect per-call telemetry (status, latency, tokens, cost), the full input→output **journey** waterfall, the **AUTO** tiered-escalation breakdown, the raw LLM JSON, and submit **feedback** (thumbs/stars/note).

It owns **only the browser side**: capture, encode, snapshot, form-build, render. All inference, STT, persistence, escalation, and pricing happen on the backend; the page never talks to an LLM directly.

The hook ([`useSimulatorCapture.ts`](Smart-Tutor-frontend/lib/useSimulatorCapture.ts)) is the lower-level media engine: it owns the `MediaStream`, the Web Audio graph, the WAV encoder, and the JPEG snapshotter. The page composes the hook with the data layer ([`lib/models.ts`](Smart-Tutor-frontend/lib/models.ts)) and the UI.

---

## 2. Architecture overview

```mermaid
flowchart TB
  subgraph Browser["Browser (/simulator)"]
    PG["SimulatorPage<br/>(page.tsx)"]
    HOOK["useSimulatorCapture()<br/>MediaStream + WebAudio + WAV/JPEG"]
    DL["useSolve / useModels / useFeedback<br/>(lib/models.ts)"]
    API["useApi() + BACKEND_URL<br/>(lib/api.ts)"]
    AUDIO["WebAudio graph<br/>ScriptProcessor → downsample → Int16"]
    SS["SpeechSynthesis (browser TTS)"]
    KX["KaTeX (react-katex)"]
  end
  subgraph BE["FastAPI Frontend Manager"]
    M["GET /api/frontend/models"]
    S["POST /api/frontend/solve"]
    SC["POST /api/frontend/solve/compare"]
    FB["POST /api/frontend/feedback"]
  end
  LLM["Multi-LLM brain<br/>(Gemini / tiered AUTO)"]
  Clerk["Clerk (JWT)"]

  PG --> HOOK
  HOOK --> AUDIO
  PG --> DL --> API
  API -->|Bearer JWT| Clerk
  DL -->|multipart FormData| S
  DL -->|multipart FormData| SC
  DL --> M
  DL --> FB
  S --> LLM
  SC --> LLM
  PG --> SS
  PG --> KX
```

**Module map:**

| Module | Role |
|---|---|
| [`app/simulator/page.tsx`](Smart-Tutor-frontend/app/simulator/page.tsx) | The page + all sub-components (model controls, capture column, response column, compare grid, journey, feedback). Owns auto-capture orchestration and image-queue state. |
| [`lib/useSimulatorCapture.ts`](Smart-Tutor-frontend/lib/useSimulatorCapture.ts) | `getUserMedia`, WebAudio capture, PCM downsample, WAV encode, JPEG snapshot. |
| [`lib/models.ts`](Smart-Tutor-frontend/lib/models.ts) | Wire types, `useModels`, `useSolve` (`solveOne`/`solveCompare`), `useFeedback`, multipart form builder, timed POST, formatting helpers. |
| [`lib/api.ts`](Smart-Tutor-frontend/lib/api.ts) | `BACKEND_URL`, `useApi()` (Clerk token + JSON fetch + error shaping), single-flight token dedup. |
| [`components/app/JourneyBreakdown.tsx`](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx) | The timeline waterfall renderer (client+server steps, tokens, cost). |
| [`lib/log.ts`](Smart-Tutor-frontend/lib/log.ts) | Latency budgets, stopwatch, RACE detection used by the timed POST. |

---

## 3. Constants, configuration & environment

### 3.1 Page-level constants ([page.tsx:60-86](Smart-Tutor-frontend/app/simulator/page.tsx#L60))

| Constant | Value | Effect |
|---|---|---|
| `EXAMPLES` | 3 strings | One-tap prompt chips: `"Differentiate sin(x²)…"`, `"Balance the combustion of propane C₃H₈."`, `"Derive the period of a simple pendulum."` ([L60-64](Smart-Tutor-frontend/app/simulator/page.tsx#L60)). |
| `MAX_IMAGES` | `5` | Hard cap on images per turn. **Must match** backend `MAX_IMAGES_PER_TURN` ([`app/session.py:152`](Smart-Tutor-Lamp-backend/app/session.py#L152) = `5`) and the DB `turns_image_count_check` constraint. The backend silently truncates anything over the cap; the client never *sends* more so the user gets immediate feedback ([L66-71](Smart-Tutor-frontend/app/simulator/page.tsx#L66)). |
| `MAX_IMAGE_BYTES` | `8 * 1024 * 1024` (8 MB) | Per-file client guard. The backend's own drop guard is `_MAX_IMAGE_BYTES = 256 * 1024` (256 KB, [`app/session.py:147`](Smart-Tutor-Lamp-backend/app/session.py#L147)); the 8 MB client limit stops the *upload* early with a clear message before the backend rejects ([L73-76](Smart-Tutor-frontend/app/simulator/page.tsx#L73)). |
| `AUTO_CAPTURE_INTERVAL_MS` | `1400` | How often the auto-capture timer samples a webcam frame while the mic is held ([L82](Smart-Tutor-frontend/app/simulator/page.tsx#L82)). |
| `SIG_SIZE` | `160` | The downscaled (160×160) canvas size used to compute the grayscale signature + sharpness ([L83](Smart-Tutor-frontend/app/simulator/page.tsx#L83)). |
| `FRAME_DIFF_THRESHOLD` | `9` | Mean grey delta (0–255 scale) above which the current frame is considered a *new page* (keep it) ([L84](Smart-Tutor-frontend/app/simulator/page.tsx#L84)). |
| `SHARPNESS_MIN` | `12` | Laplacian-variance floor; frames below this are *too blurry* (mid-flip) and skipped ([L85](Smart-Tutor-frontend/app/simulator/page.tsx#L85)). |

### 3.2 Hook-level constant ([useSimulatorCapture.ts:10](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L10))

| Constant | Value | Effect |
|---|---|---|
| `SAMPLE_RATE` | `16000` | Target audio sample rate — 16 kHz mono, mirroring the lamp. Used both as the downsample destination rate and the WAV header rate. |

### 3.3 Persisted preference (localStorage)

| Key | Values | Effect |
|---|---|---|
| `lumos.autospeak` | `"1"` / `"0"` | Auto-speak preference; restored on mount, written on toggle ([L160-171](Smart-Tutor-frontend/app/simulator/page.tsx#L160)). Defaults ON. |

### 3.4 Environment variable

| Var | Default | Source |
|---|---|---|
| `NEXT_PUBLIC_BACKEND_URL` | `http://localhost:8000` | The FastAPI base URL all calls target ([`lib/api.ts:61-62`](Smart-Tutor-frontend/lib/api.ts#L61)). Matches `uvicorn app.main:app` on port 8000. |
| `NEXT_PUBLIC_VERBOSE` / `localStorage.LUMOS_VERBOSE` | dev=on | Toggles console diagnostics (the timed-POST LAG/RACE logs) ([`lib/log.ts:45-66`](Smart-Tutor-frontend/lib/log.ts#L45)). |

### 3.5 Authentication

Every backend call carries `Authorization: Bearer <Clerk JWT>`, fetched fresh per request via Clerk's `getToken()` ([`lib/api.ts:97`](Smart-Tutor-frontend/lib/api.ts#L97), [`lib/models.ts:181`](Smart-Tutor-frontend/lib/models.ts#L181)). The simulator's solve POSTs use a single-flight-aware token through `getToken()` passed into `postFormTimed`.

---

## 4. Key data structures

### 4.1 Page-local interfaces ([page.tsx:50-58](Smart-Tutor-frontend/app/simulator/page.tsx#L50))

```ts
interface Display { type: "latex" | "text" | "none"; latex: string; text: string; }
interface SimResponse { speech: string; display: Display; }
```

`Display` is the lamp's split-screen model: `latex` is bare LaTeX for the TFT, `text` is prose, `none` means "nothing to show". `SimResponse` = the spoken half (`speech`) + the visual half (`display`).

### 4.2 Wire types ([lib/models.ts](Smart-Tutor-frontend/lib/models.ts))

- **`ModelInfo`** ([L16-27](Smart-Tutor-frontend/lib/models.ts#L16)): `id, label, provider, available, vision, audio, input_per_mtok, output_per_mtok, note, is_default`. Drives the model dropdown / compare chips. `available` is true only when the provider's API key is configured server-side.
- **`ModelsOut`** ([L29-32](Smart-Tutor-frontend/lib/models.ts#L29)): `{ models: ModelInfo[], default_model: string }`.
- **`SimDisplay`** / **`SimResponse`** ([L34-47](Smart-Tutor-frontend/lib/models.ts#L34)): same `display` shape plus optional `confidence, query_type, subject, difficulty`.
- **`TimelineStep`** ([L52-56](Smart-Tutor-frontend/lib/models.ts#L52)): `{ step: string, ms: number, where: "client" | "server" }`. One bar in the journey waterfall.
- **`AutoStep`** ([L60-71](Smart-Tutor-frontend/lib/models.ts#L60)): one LLM call inside AUTO mode — `tier, model, role, reason, latency_ms, input_tokens, thinking_tokens, output_tokens, estimated_cost, confidence`.
- **`SolveMeta`** ([L73-97](Smart-Tutor-frontend/lib/models.ts#L73)): per-call telemetry — `model_id, label, provider, status, latency_ms, input_tokens, output_tokens, total_tokens, estimated_cost, error, response_id, timeline?, server_ms?, steps?, escalated?, final_tier?, memo_active?`. `status` ∈ `"ok" | "not_configured" | "timeout" | "busy" | "error"`.
- **`SolveOut`** ([L106-109](Smart-Tutor-frontend/lib/models.ts#L106)): `{ response: SimResponse, meta: SolveMeta }`.
- **`CompareOut`** ([L111-113](Smart-Tutor-frontend/lib/models.ts#L111)): `{ results: SolveOut[] }`.
- **`SolveInput`** ([L127-131](Smart-Tutor-frontend/lib/models.ts#L127)): `{ audio: Blob | null, images: Blob[], text?: string }` — the browser's capture bundle.
- **`FeedbackInput`** ([L99-104](Smart-Tutor-frontend/lib/models.ts#L99)): `{ response_id, thumbs?, rating?, feedback_text? }`.

### 4.3 Hook state & refs ([useSimulatorCapture.ts:14-29](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L14))

State: `state: MediaState` (`"idle" | "requesting" | "ready" | "denied" | "error"`), `error: string|null`, `recording: boolean`, `hasVideo: boolean`.

Refs (no re-render): `streamRef` (the `MediaStream`), `videoRef` (the `<video>` element), `ctxRef` (`AudioContext`), `procRef` (`ScriptProcessorNode`), `srcRef` (`MediaStreamAudioSourceNode`), `sinkRef` (muted `GainNode`), `chunksRef` (`Int16Array[]` — accumulated PCM chunks).

---

## 5. The capture hook — `useSimulatorCapture.ts`

The hook (header comment [L3-6](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L3)) "mirrors the lamp's multimodal payload: a webcam JPEG snapshot + a 16 kHz mono WAV of the spoken question. The mic is captured as raw PCM via the Web Audio graph and encoded to WAV on release (Gemini accepts audio/wav directly)."

### 5.1 `enable()` — device acquisition ([L31-70](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L31))

1. Sets `state = "requesting"`, clears `error`.
2. Audio constraints: `{ channelCount: 1, echoCancellation: true, noiseSuppression: true }` ([L34](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L34)).
3. **Prefers camera + mic** with portrait-biased video constraints: `facingMode: { ideal: "environment" }, width: { ideal: 720 }, height: { ideal: 1280 }` ([L44](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L44)). The `ideal` keys nudge phones toward a portrait rear-camera stream (a worksheet is taller than wide) **without** hard-failing on desktop webcams that stay landscape.
4. **Graceful video fallback** ([L46-54](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L46)): if `getUserMedia({audio, video})` throws:
   - If the error is `NotAllowedError` or `SecurityError`, the **user said no** → re-throw (handled below → `state = "denied"`).
   - Otherwise (no camera, constraints unmet) → retry `getUserMedia({ audio })` (mic-only) so the user can still speak + upload an image.
5. Stores `streamRef`, detects `hasVideo = stream.getVideoTracks().length > 0` ([L56-57](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L56)). If video present and `videoRef` is mounted, sets `srcObject` and calls `.play()` (errors swallowed) ([L58-61](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L58)).
6. Sets `state = "ready"`.
7. **Catch** ([L63-69](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L63)): `NotAllowedError`/`SecurityError` → `state = "denied"`; anything else → `state = "error"` + `error = e.message`.

### 5.2 `snapshotJpeg(quality = 0.85)` — frame → JPEG Blob ([L72-82](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L72))

- Returns `null` if no video or `videoWidth === 0` (camera not yet streaming).
- Creates an off-DOM `<canvas>` sized to the **full** `video.videoWidth × videoHeight` (native resolution — *not* downscaled; downscaling happens server-side via `enhance_for_llm(max_dim=2048)`).
- `ctx.drawImage(video, 0, 0)`, then `canvas.toBlob(res, "image/jpeg", 0.85)` wrapped in a Promise → an `image/jpeg` Blob at quality 0.85.

### 5.3 `startRecording()` — open the WebAudio capture graph ([L84-114](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L84))

Returns `false` (no-op) if there is no stream or a processor already exists. Otherwise:

1. Resets `chunksRef.current = []`.
2. Creates `AudioContext` (with `webkitAudioContext` fallback) ([L89-92](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L89)).
3. `source = ctx.createMediaStreamSource(stream)`.
4. `processor = ctx.createScriptProcessor(4096, 1, 1)` — **4096-sample** buffer, 1 in / 1 out channel ([L95](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L95)).
5. Reads the hardware sample rate `srcRate = ctx.sampleRate` (typically 44100/48000).
6. **`onaudioprocess`** ([L99-102](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L99)): on each 4096-frame block, takes channel-0 `Float32Array`, runs `downsampleToInt16(input, srcRate, 16000)`, pushes the resulting `Int16Array` to `chunksRef`.
7. **Muted sink** ([L104-110](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L104)): a `GainNode` at `gain = 0` connected to `ctx.destination` keeps the audio graph *pulling* (browsers may not fire `onaudioprocess` for an unconnected processor) **without** echoing the mic to the speakers. Wiring: `source → processor → sink → destination`.
8. `setRecording(true)`, returns `true`.

### 5.4 `stopRecording()` — close the graph & encode WAV ([L116-138](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L116))

- Returns `null` if no processor.
- Disconnects `processor`, `sink`, `source`; `await ctx.close()` (errors swallowed); nulls all four refs; `setRecording(false)`.
- **Merge**: sums all chunk lengths; if `total === 0` returns `null` (no audio). Otherwise allocates one `Int16Array(total)` and copies each chunk in order ([L128-135](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L128)).
- Clears `chunksRef`, returns `encodeWav(merged, 16000)` → an `audio/wav` Blob.

### 5.5 `disable()` — teardown ([L140-147](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L140))

Stops recording if active; stops all `MediaStream` tracks; nulls `streamRef`; clears `video.srcObject`; `hasVideo = false`; `state = "idle"`. *(Note: the page never calls `disable()` directly — the stream lives for the page's lifetime; only `stopAutoCapture` and the WebAudio graph are torn down per turn.)*

**Updated 2026-07-03 (leak fix).** Because `disable()` is user-triggered and effectively never called, the hook now also registers a **mount-scoped `useEffect` whose cleanup releases everything on unmount** ([useSimulatorCapture.ts:149-167](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L149)): it disconnects `procRef`/`sinkRef`/`srcRef`, `close()`s the `AudioContext`, stops every `MediaStream` track, and nulls all refs. Without this, navigating away from `/simulator` left the webcam LED on and the mic live (see `OPTIMIZATION.md §4.1`).

### 5.6 Hook return surface ([L149-160](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L149))

`{ state, error, recording, hasVideo, videoRef, enable, disable, snapshotJpeg, startRecording, stopRecording }`.

---

## 6. The page — `app/simulator/page.tsx`

### 6.1 State held by `SimulatorPage` ([L130-160](Smart-Tutor-frontend/app/simulator/page.tsx#L130))

| State | Type | Purpose |
|---|---|---|
| `cam` | hook result | The capture engine. |
| `loading` | boolean | A solve is in flight. Disables inputs, shows `ThinkingCard`. |
| `results` | `SolveOut[] \| null` | The answers (length 1 in single mode, N in compare). |
| `err` | `string \| null` | User-facing error string. |
| `text` | string | The typed question input. |
| `renderMs` | `number \| null` | Browser paint time (response received → painted), for the journey. |
| `models` | derived | `modelsData.models` filtered to `available` only ([L145](Smart-Tutor-frontend/app/simulator/page.tsx#L145)). |
| `defaultModel` | derived | `modelsData.default_model` if present in catalog, else first model, else fallback string `"gemini-2.5-flash"` ([L146-149](Smart-Tutor-frontend/app/simulator/page.tsx#L146)). |
| `compareMode` | boolean | Single vs side-by-side. |
| `selectedModel` | `string \| null` | Single-mode selection; `activeModel = selectedModel ?? defaultModel` ([L155](Smart-Tutor-frontend/app/simulator/page.tsx#L155)). |
| `compareModels` | `string[]` | Multi-selection for compare mode. |
| `autoSpeak` | boolean | Persisted TTS preference. |
| `images` | `Blob[]` | The curated send queue. |
| `previews` | `string[]` | Object-URLs for thumbnails (1:1 with `images`). |

Refs for push-to-talk auto-capture ([L303-306](Smart-Tutor-frontend/app/simulator/page.tsx#L303)): `pendingImages` (`Blob[]`), `autoTimerRef` (interval id), `lastSigRef` (`Float32Array` — previous frame signature), and state `autoShots` (count for the live `📄 n/5` badge).

### 6.2 Image-queue management

- **`addImages(files)`** ([L191-221](Smart-Tutor-frontend/app/simulator/page.tsx#L191)): computes `remaining = MAX_IMAGES - images.length`; if `≤ 0` sets the at-most-5 error. Iterates files, **stops** when `accepted.length >= remaining`. Per file: rejects non-`image/*` *File*s (webcam Blobs always pass since they're `image/jpeg`); rejects files `> MAX_IMAGE_BYTES`. If more files than slots, warns "Only the first N were added". Appends accepted Blobs + their `URL.createObjectURL` previews.
- **`removeAt(idx)`** ([L223-230](Smart-Tutor-frontend/app/simulator/page.tsx#L223)): drops index `idx` from both arrays and **revokes** that preview URL.
- **`clearImages()`** ([L232-237](Smart-Tutor-frontend/app/simulator/page.tsx#L232)): revokes all preview URLs, empties both arrays.
- **Unmount cleanup** ([page.tsx](Smart-Tutor-frontend/app/simulator/page.tsx)): a `useEffect` with `[]` deps revokes every remaining preview URL only on unmount (per-item revokes already happen in `removeAt`/`clearImages`). **Updated 2026-07-03 (leak fix):** the effect runs once, so a plain `previews` closure captured the *initial empty array* and leaked every blob URL queued after mount. It now mirrors the live list into a `previewsRef` (updated each render) and revokes `previewsRef.current` (see `OPTIMIZATION.md §4.5`).
- **`snapFromCamera()`** ([L239-247](Smart-Tutor-frontend/app/simulator/page.tsx#L239)): guards on `cam.state === "ready" && cam.hasVideo` and `images.length < MAX_IMAGES`; calls `cam.snapshotJpeg()` and `addImages([blob])`.

### 6.3 `send()` — the unified dispatch ([L249-300](Smart-Tutor-frontend/app/simulator/page.tsx#L249))

Signature: `send(audio, imageList, textVal?, startedAt?)`.

1. **Empty-input guard**: if no audio AND no images AND no trimmed text → error "Nothing captured…" and return.
2. **Compare guard**: if `compareMode && compareModels.length === 0` → error "Pick at least one model…".
3. Sets `loading=true`, clears `err`/`results`/`renderMs`.
4. Builds `input = { audio, images: imageList, text: textVal }`.
5. Dispatches:
   - Compare: `(await solveCompare(compareModels, input, startedAt)).results`.
   - Single: `[await solveOne(activeModel, input, startedAt)]`.
6. **Render timing** ([L275-281](Smart-Tutor-frontend/app/simulator/page.tsx#L275)): records `tResp = performance.now()` the instant the answer is in hand, `setResults(newResults)`, then a **double `requestAnimationFrame`** measures elapsed → `setRenderMs(now - tResp)`. (Two rAFs ensure the new DOM is actually painted before measuring.)
7. **`clearImages()`** on success — next question starts fresh (matches the lamp's per-turn reset).
8. **Catch** ([L285-296](Smart-Tutor-frontend/app/simulator/page.tsx#L285)): maps tagged backend codes/messages to friendly strings:
   - `code === "EMPTY_INPUT"` → "Nothing captured — try again."
   - `code === "BRAIN_BUSY"` → "The AI is busy right now — please try again in a few seconds."
   - message includes `"fetch"` / `=== "Failed to fetch"` → "Couldn't reach the backend. Is it running?"
   - else → the raw message or "The request failed. Try again."
9. **Finally**: `loading=false`.

### 6.4 Push-to-talk with hands-free auto multi-capture

- **`stopAutoCapture()`** ([L308-313](Smart-Tutor-frontend/app/simulator/page.tsx#L308)): clears the interval if set.
- **`autoTick(force)`** ([L318-338](Smart-Tutor-frontend/app/simulator/page.tsx#L318)) — one capture attempt:
  1. If `pendingImages.length >= MAX_IMAGES` → `stopAutoCapture()` and return.
  2. `stats = frameStats(cam.videoRef.current)`; if `null` (no video) return.
  3. If **not** `force`: skip if `stats.sharp < SHARPNESS_MIN` (blurry mid-flip); skip if `meanAbsDiff(stats.gray, lastSigRef.current) < FRAME_DIFF_THRESHOLD` (same page).
  4. Snap a JPEG; if it returns, push to `pendingImages`, update `lastSigRef = stats.gray`, set `autoShots`; if at cap, `stopAutoCapture()`.
- **`startTalk()`** ([L340-360](Smart-Tutor-frontend/app/simulator/page.tsx#L340)) — `onPointerDown`:
  - Guards: `cam.state === "ready" && !loading && !cam.recording`.
  - Resets `lastSigRef = null`.
  - **If `images.length > 0`** (user curated a queue): copy it to `pendingImages` as-is — **no auto-capture**.
  - **Else** if `cam.hasVideo`: clear `pendingImages`, reset `autoShots`, take the **first frame immediately** via `autoTick(true)` (force bypasses the gates), then `setInterval(() => autoTick(false), 1400)`.
  - Finally `cam.startRecording()`.
- **`endTalk()`** ([page.tsx](Smart-Tutor-frontend/app/simulator/page.tsx)) — `onPointerUp` / `onPointerLeave`:
  - No-op if not recording. **Updated 2026-07-03 (double-send fix):** a **synchronous `endingRef` guard** is now flipped `true` on entry (and reset in `startTalk`). Because `endTalk` is wired to *both* `onPointerUp` and `onPointerLeave`, and `cam.recording` only flips inside the awaited `stopRecording()`, a drag-off-then-release could otherwise fire **two** `/solve` calls (a paid LLM call) for one question; the ref blocks the second pointer event synchronously (see `OPTIMIZATION.md §4.3`).
  - **Starts the journey clock** `startedAt = performance.now()` *at mic release* so WAV encode + final snapshot count toward `prepare`.
  - `stopAutoCapture()`, then `wav = await cam.stopRecording()`.
  - **Safety net**: if auto-capture kept nothing AND no curated queue AND `hasVideo`, grab one final frame so we never send zero images ([L370-373](Smart-Tutor-frontend/app/simulator/page.tsx#L370)).
  - `await send(wav, pendingImages.current, undefined, startedAt)`, then reset refs/`autoShots`/`lastSigRef`.
- **Unmount guard** ([L381](Smart-Tutor-frontend/app/simulator/page.tsx#L381)): `useEffect` returns `stopAutoCapture` so a mid-hold unmount kills the timer.

> The PTT button binds `onPointerDown={startTalk}`, `onPointerUp={endTalk}`, `onPointerLeave={endTalk}` ([L530-532](Smart-Tutor-frontend/app/simulator/page.tsx#L530)) — pointer-leave guarantees the recording ends even if the cursor slides off the button while held.

### 6.5 `submitText()` — typed / image-only path ([L383-404](Smart-Tutor-frontend/app/simulator/page.tsx#L383))

1. `preventDefault`; no-op if `loading`.
2. `hasText = !!text.trim()`. If no text and no images → return (allows text-only, image-only, or both).
3. Start journey clock at submit.
4. **Image precedence** (same as PTT): queued images win; else, **only when there IS text** and the camera is ready/has video, snap once ([L396-400](Smart-Tutor-frontend/app/simulator/page.tsx#L396)). It deliberately does **not** auto-snap for an images-only send (the user already curated what to send).
5. Captures `q = text`, clears the input, `await send(null, toSend, q || undefined, startedAt)`.

### 6.6 UI layout & conditional states

- **Header + hero** ([L411-423](Smart-Tutor-frontend/app/simulator/page.tsx#L411)): `AppHeader` (active `/simulator`) + copy.
- **`ModelControls`** ([L425-441](Smart-Tutor-frontend/app/simulator/page.tsx#L425)): compare toggle + dropdown/chips (see §6.7).
- **Two-column grid** ([L443](Smart-Tutor-frontend/app/simulator/page.tsx#L443)): capture column (left), response column (right); compare results render full-width below.
- **Capture column** ([L445-667](Smart-Tutor-frontend/app/simulator/page.tsx#L445)): `<video ref={cam.videoRef} muted playsInline>` in a 3/4 aspect frame (hidden via `opacity-0` until ready+video). Overlays: top-right **Snap** shutter (when ready+video+slots left+not recording); a not-ready prompt with an "Enable camera & mic" button (`cam.enable`); a mic-only fallback message; a **REC** badge while recording; a live `📄 autoShots/MAX_IMAGES` badge while recording in auto mode (no curated queue). Below: the PTT button; the **image queue** card (thumbnails with `#index`, remove `×`, Clear); **Upload image(s)** label (`<input type="file" accept="image/*" multiple>`) + **Snap from camera** button; the text form; and the example chips.
- **Response column (single)** ([L670-705](Smart-Tutor-frontend/app/simulator/page.tsx#L670)): branches `compareMode ? compare-hint : loading ? ThinkingCard : err ? ErrorCard : single ? [MetaStrip, SpokenResponse, ScreenDisplay, FeedbackBar, RawJson] : EmptyCard`. `single` is computed as the lone result only when not in compare mode ([L407](Smart-Tutor-frontend/app/simulator/page.tsx#L407)).
- **Compare results** ([L708-726](Smart-Tutor-frontend/app/simulator/page.tsx#L708)): full-width grid of `CompareCard`s (1/2/3 cols responsive), with its own loading/error states.

### 6.7 `ModelControls` + `ModelDropdown` ([L920-1041](Smart-Tutor-frontend/app/simulator/page.tsx#L920))

- The compare toggle button flips `compareMode` and clears `results`.
- If `models.length === 0` → "Loading models…".
- **Compare mode**: a row of toggle chips, one per model; disabled when `!m.available` (label shows `· no key`), selected chips highlighted, `Check` icon.
- **Single mode**: a `<select>` dropdown listing all models (disabled `<option>` for unavailable ones, suffix `(no key)`), plus a status line showing `● ready` / `● not configured`, the `$in/$out per 1M tok` price, and the model `note`.

---

## 7. Algorithms in detail

### 7.1 `downsampleToInt16(input, srcRate, dstRate)` — PCM resample + quantize ([useSimulatorCapture.ts:163-188](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L163))

Converts a Float32 PCM block at the hardware rate (e.g. 48000 Hz) to a 16-bit signed integer block at 16000 Hz.

- **Clamp + quantize** ([L164-167](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L164)): `c = clamp(s, -1, 1)`; then map to int16 with **asymmetric scaling**: negative samples ×`0x8000` (32768), non-negative ×`0x7fff` (32767). This uses the full int16 range correctly (`-1.0 → -32768`, `+1.0 → +32767`).
- **No-downsample case** ([L168-172](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L168)): if `dstRate >= srcRate`, just clamp each sample 1:1 (no rate change).
- **Downsample (box average)** ([L173-187](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L173)):
  - `ratio = srcRate / dstRate` (e.g. 48000/16000 = 3).
  - `outLen = floor(input.length / ratio)`.
  - For each output sample `i`: average the input samples in `[floor(i*ratio), floor((i+1)*ratio))` (a simple **box/mean filter**, a cheap low-pass that reduces aliasing), then clamp+quantize. This is *averaging decimation*, not sinc resampling — adequate for 16 kHz speech destined for STT.

### 7.2 `encodeWav(samples, sampleRate)` — WAV container ([useSimulatorCapture.ts:190-212](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L190))

Builds a canonical 44-byte **WAV/PCM** header + the interleaved little-endian int16 sample data into an `ArrayBuffer`, returned as a `Blob({type:"audio/wav"})`. Header fields written via `DataView` ([L196-208](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L196)):

| Offset | Field | Value |
|---|---|---|
| 0 | `"RIFF"` | chunk id |
| 4 | file size | `36 + samples.length*2` |
| 8 | `"WAVE"` | format |
| 12 | `"fmt "` | subchunk id |
| 16 | subchunk size | `16` (PCM) |
| 20 | audio format | `1` (PCM) |
| 22 | channels | `1` (mono) |
| 24 | sample rate | `16000` |
| 28 | byte rate | `sampleRate*2` = 32000 |
| 32 | block align | `2` |
| 34 | bits/sample | `16` |
| 36 | `"data"` | data subchunk |
| 40 | data size | `samples.length*2` |
| 44… | PCM samples | int16 LE |

### 7.3 `frameStats(video)` — grayscale signature + sharpness ([page.tsx:90-121](Smart-Tutor-frontend/app/simulator/page.tsx#L90))

Cheap (160×160) in-browser analysis used by auto-capture:

1. Returns `null` if no video / `videoWidth === 0`.
2. Draws the live video into a 160×160 canvas (`willReadFrequently: true` for fast repeated reads).
3. **Grayscale** ([L101-104](Smart-Tutor-frontend/app/simulator/page.tsx#L101)): per pixel `gray = 0.299·R + 0.587·G + 0.114·B` (Rec. 601 luma) into a `Float32Array(160*160)`.
4. **Laplacian variance ≈ sharpness** ([L106-119](Smart-Tutor-frontend/app/simulator/page.tsx#L106)): for each interior pixel apply the 4-neighbour Laplacian kernel `lap = 4·c − left − right − up − down`; accumulate `sum` and `sum2` over `n` pixels; `sharp = sum2/n − (sum/n)²` (the **variance** of the Laplacian response). Blurry frames carry little high-frequency energy → low variance.
5. Returns `{ gray, sharp }`.

### 7.4 `meanAbsDiff(a, b)` — frame difference ([page.tsx:123-128](Smart-Tutor-frontend/app/simulator/page.tsx#L123))

Returns the mean absolute per-pixel difference between two grayscale signatures. If either is `null` or lengths mismatch → `Infinity` (so the first frame, with no prior, is *always* "different" and kept). Otherwise `sum(|a[i]-b[i]|) / a.length`.

### 7.5 Auto-capture gating logic (combining 7.3 + 7.4)

For each non-forced tick: **keep** the frame iff `sharp >= 12` **AND** `meanAbsDiff(gray, lastSig) >= 9`. The first frame is forced (gates bypassed). This lets a student flip question + working pages and get up to 5 distinct, non-blurry shots without tapping the shutter, while rejecting near-duplicates and mid-flip blur.

---

## 8. Data layer & wire protocol (`lib/models.ts`, `lib/api.ts`)

### 8.1 `useModels()` ([lib/models.ts:116-124](Smart-Tutor-frontend/lib/models.ts#L116))

React Query `["models"]` → `GET /api/frontend/models` (via `useApi().get`), `enabled: api.ready` (Clerk loaded + signed-in), `staleTime: 5 min` (catalog only changes on backend restart). Backend handler: [`frontend_manager.py:900-919`](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L900) — returns `ModelsOut` with `available` per provider key.

### 8.2 `buildForm(input)` — multipart construction ([lib/models.ts:133-145](Smart-Tutor-frontend/lib/models.ts#L133))

```
fd.append("audio",  audioBlob, "question.wav")     // if audio present
fd.append("images", blob, `snap-${i+1}.jpg`)       // one per image, in order
fd.append("text",   text.trim())                   // if non-empty
```

**Critical note** ([L137-142](Smart-Tutor-frontend/lib/models.ts#L137)): the legacy single `image` field is deliberately **not** sent — double-appending the first frame uploaded it twice (2× upload, and until the backend grew a dedup it was enhanced + billed twice by Gemini; implicated in free-tier OOM crashes 2026-06-12). The backend still *reads* a legacy `image` field for compatibility ([`frontend_manager.py:938-941`](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L938)) and SHA-256-dedupes all blobs ([`_dedupe_blobs`, L779-790](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L779)).

### 8.3 `postFormTimed()` — timed multipart POST ([lib/models.ts:161-232](Smart-Tutor-frontend/lib/models.ts#L161))

The browser-side journey instrumentation. Phases:

1. **prepare** = `now − startedAt` — capture/encode/snapshot/form-build time (`startedAt` is mic-release / send-press from the page).
2. **auth** = `getToken()` duration (Clerk JWT). Warns if no token.
3. Appends `client_timeline` = `JSON.stringify([{step:"prepare",…,client}, {step:"auth",…,client}])` to the form — so the **persisted** journey on the backend spans the whole path, not just the server half ([L186-191](Smart-Tutor-frontend/lib/models.ts#L186)).
4. **upload** = the whole `fetch` round trip (request upload + server work + response download). It is returned for the live view but **not persisted** (a request can't carry its own round-trip time) ([L205, L219-222](Smart-Tutor-frontend/lib/models.ts#L205)).
5. On `!r.ok`: parses the body, extracts `code = detail.code ?? code`, throws an `Error` tagged with `.code` (this is what `send()`'s catch maps to friendly text).
6. Returns `{ data, clientSteps }`.

Network error (fetch rejects, backend down) is logged and re-thrown — `send()` matches `"Failed to fetch"` → "Couldn't reach the backend." All timing uses `performance.now()` with a `Date.now()` fallback; LAG thresholds come from [`lib/log.ts` BUDGET](Smart-Tutor-frontend/lib/log.ts#L35) (token 500 ms; upload warns at 8000 ms, severe at 20000 ms).

### 8.4 `useSolve()` — `solveOne` / `solveCompare` ([lib/models.ts:256-283](Smart-Tutor-frontend/lib/models.ts#L256))

- **`solveOne(model, input, startedAt)`** ([L262-269](Smart-Tutor-frontend/lib/models.ts#L262)): builds the form, appends `model`, POSTs `/api/frontend/solve`, then `withClientJourney(data, clientSteps)` prepends the browser steps in front of the server timeline.
- **`solveCompare(models, input, startedAt)`** ([L271-280](Smart-Tutor-frontend/lib/models.ts#L271)): builds the form, appends each `models` value, POSTs `/api/frontend/solve/compare`, and prepends the *same* client steps to **every** result's server timeline (one batch round trip feeds all models).
- **`withClientJourney`** ([L235-238](Smart-Tutor-frontend/lib/models.ts#L235)): `{...out, meta:{...meta, timeline:[...clientSteps, ...serverTimeline]}}`.

### 8.5 `useFeedback()` ([lib/models.ts:286-290](Smart-Tutor-frontend/lib/models.ts#L286))

Returns `(input) => api.post("/api/frontend/feedback", input)` — JSON POST of `FeedbackInput`. Best-effort; the UI never blocks on it.

### 8.6 Formatting helpers ([lib/models.ts:293-308](Smart-Tutor-frontend/lib/models.ts#L293))

- `formatCost(usd)`: `null → "—"`, `0 → "$0"`, `< 0.01 → 5dp`, else 4dp.
- `formatLatency(ms)`: `null → "—"`, `< 1000 → "N ms"`, else `"N.NN s"`.
- `formatTokens(n)`: `null → "—"`, else `toLocaleString()`.

### 8.7 `useApi()` & token single-flight ([lib/api.ts](Smart-Tutor-frontend/lib/api.ts))

`useApi()` ([L76-184](Smart-Tutor-frontend/lib/api.ts#L76)) builds an authenticated JSON `call<T>` used for `get/post/put/del`. The solve calls don't use `call` (they need multipart) but reuse `getToken` from the same hook. **Single-flight token dedup** ([L29-55](Smart-Tutor-frontend/lib/api.ts#L29)): concurrent callers await one in-flight `getToken()` — preventing the "token-refresh race" 401 flaps; a `tokenInFlight` counter logs a `RACE` warning if dedup ever breaks.

---

## 9. Complete end-to-end control flow

**A. Boot / device enable**
1. Page mounts (`"use client"`). `useModels()` fires `GET /models` (if signed-in). `autoSpeak` restored from `localStorage`.
2. The webcam frame shows a not-ready prompt; user clicks **Enable camera & mic** → `cam.enable()` requests `getUserMedia` (camera+mic, falling back to mic-only). On success `state = "ready"`, the `<video>` becomes visible if `hasVideo`.

**B1. Push-to-talk (hands-free) path**
3. User presses & holds the PTT button → `startTalk()`. If the queue is empty and the camera is live, it force-captures the first frame and starts a 1400 ms auto-capture interval; it begins WebAudio recording.
4. While held, `onaudioprocess` accumulates downsampled int16 PCM; every 1400 ms `autoTick(false)` may keep a new sharp, distinct page (up to 5). The REC badge + `📄 n/5` counter update live.
5. User releases (or pointer leaves) → `endTalk()`: clock starts, timer stops, `stopRecording()` encodes the WAV. Safety net snaps one frame if nothing was kept. `send(wav, pendingImages, …)` fires.

**B2. Typed / image-only path**
3'. User types and/or queues images, presses **Send** → `submitText()`: starts the clock; if text-present and queue empty, snaps one frame; calls `send(null, toSend, text, …)`.

**C. Dispatch & upload** (`send` → `solveOne`/`solveCompare` → `postFormTimed`)
6. Empty/compare guards pass; `loading=true`. `buildForm` assembles multipart (audio WAV + images in order + text). `prepare`/`auth` measured; `client_timeline` appended; Clerk JWT attached; `fetch` POST to `${BACKEND_URL}/api/frontend/solve[/compare]`.

**D. Backend** (cross-reference, not in scope but where the data goes)
7. The Frontend Manager reads inputs, caps images to `MAX_IMAGES_PER_TURN`, SHA-256-dedupes, optionally enhances images, runs STT on the WAV, calls the model(s) / AUTO tiered flow, persists `model_responses`, and returns `SolveOut`/`CompareOut` with `meta.timeline` (server steps), tokens, cost, and `response_id`.

**E. Render & telemetry**
8. Response in hand → `tResp` recorded; `withClientJourney` prepends `prepare/auth/upload` to the server timeline; `setResults`; double-rAF measures `renderMs`. `clearImages()` resets the queue.
9. Single mode renders `MetaStrip` (status/latency/tokens/cost + journey toggle + AUTO steps), `SpokenResponse` (auto-speaks if enabled), `ScreenDisplay` (KaTeX), `FeedbackBar`, `RawJson`. Compare mode renders the grid of `CompareCard`s.

**F. Feedback (optional)**
10. User clicks thumbs/star/note → `FeedbackBar.submit` → `POST /feedback` keyed by `response_id`; "Saved" flashes for 1.5 s.

---

## 10. Sequence diagram: simulator → backend → LLM → back

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant Page as SimulatorPage
    participant Hook as useSimulatorCapture
    participant DL as useSolve / postFormTimed
    participant Clerk
    participant BE as FastAPI Frontend Manager
    participant STT as Speech-to-Text
    participant LLM as Multi-LLM brain
    participant DB as Postgres (model_responses)

    User->>Page: press & hold PTT (startTalk)
    Page->>Hook: startRecording() + autoTick(force=true)
    loop every 1400 ms while held
        Hook-->>Hook: onaudioprocess → downsampleToInt16 → chunks
        Page->>Hook: autoTick(false) → frameStats + meanAbsDiff
        Hook-->>Page: snapshotJpeg() if sharp & distinct (≤5)
    end
    User->>Page: release (endTalk) — startedAt = now
    Page->>Hook: stopRecording() → encodeWav(16k mono)
    Page->>DL: send(wav, images[], startedAt)
    DL->>DL: buildForm (audio + images + text), measure prepare
    DL->>Clerk: getToken() (single-flight)
    Clerk-->>DL: JWT (measure auth)
    DL->>BE: POST /api/frontend/solve (multipart + client_timeline)
    BE->>BE: read inputs, cap @ MAX_IMAGES_PER_TURN, dedupe, enhance
    BE->>STT: transcribe WAV
    STT-->>BE: transcript
    BE->>LLM: prompt (transcript + images + history)
    Note over BE,LLM: AUTO mode may run tiered escalation (multiple steps)
    LLM-->>BE: { speech, display, tokens, confidence }
    BE->>DB: persist → response_id
    DB-->>BE: response_id
    BE-->>DL: SolveOut { response, meta(timeline, tokens, cost, response_id) }
    DL->>DL: withClientJourney(prepend prepare/auth/upload)
    DL-->>Page: SolveOut
    Page->>Page: setResults; double-rAF → renderMs; clearImages
    Page->>User: SpokenResponse (auto-speak) + KaTeX display + telemetry
    opt rating
        User->>Page: thumbs / star / note
        Page->>BE: POST /api/frontend/feedback {response_id,...}
        BE->>DB: store feedback
    end
```

---

## 11. Rendering pipeline (KaTeX, math-rich text)

The display half is rendered by **`ScreenDisplay`** ([page.tsx:888-917](Smart-Tutor-frontend/app/simulator/page.tsx#L888)) — *"the lamp's TFT view"*:

- **`display.type === "latex"`** with non-empty `latex`: render `<BlockMath math={stripMathDelims(display.latex)}>`. `renderError` falls back to the raw source in red.
- **`display.type === "text"`** with non-empty `text`: render `<MathRichText text={display.text}>` inside a `whitespace-pre-wrap` paragraph.
- Else: "Nothing to show on screen for this answer."

### 11.1 `stripMathDelims(s)` ([page.tsx:877-886](Smart-Tutor-frontend/app/simulator/page.tsx#L877))

`display.latex` should be *bare* LaTeX, but models sometimes wrap it. Strips **one** outer delimiter pair, trying `$$…$$`, `\[…\]`, `\(…\)`, `$…$` in order, only if the string both starts and ends with that pair (and is longer than the two delimiters).

### 11.2 `MathRichText(text)` ([page.tsx:845-872](Smart-Tutor-frontend/app/simulator/page.tsx#L845))

The LLM routinely mixes math spans into prose even when it should use the latex channel (observed: a full integral printed as raw LaTeX). Rather than trust channel purity, this splits prose and renders the math spans with KaTeX:

- A fresh stateful global regex per call ([L847-848](Smart-Tutor-frontend/app/simulator/page.tsx#L847)):
  `/\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]|\\\(([\s\S]+?)\\\)|\$(\S(?:[^$\n]*?\S)?)\$/g`
  matching `$$…$$` / `\[…\]` (→ **block** math, groups 1/2) and `\(…\)` / `$…$` (→ **inline** math, groups 3/4). The `$…$` alternative requires non-space at both ends to avoid matching stray dollar signs.
- Walks matches: plain text between matches becomes `<span>`s; each math span renders via `BlockMath` (block) or `InlineMath` (inline). A span that fails to parse falls back via `renderError` to its raw source as red `<code>` — *nothing is ever lost*.

---

## 12. Telemetry, journey & feedback

### 12.1 `MetaStrip` ([page.tsx:1078-1136](Smart-Tutor-frontend/app/simulator/page.tsx#L1078))

Shows the model label, a `StatusBadge`, latency, tokens, and est. cost. Token label logic: prefer `total_tokens`; else `"in / out"`; else `—`. A "Show/Hide journey" button appears when `meta.timeline?.length > 0 || renderMs != null`. For `status === "busy"` it shows the Gemini-busy note; for other non-ok statuses it shows `meta.error`. Renders `AutoStepsPanel` and, when toggled, `JourneyBreakdown`.

### 12.2 `StatusBadge` ([page.tsx:1044-1058](Smart-Tutor-frontend/app/simulator/page.tsx#L1044))

Maps `status` → label/color: `ok`→"ok" (cyan), `not_configured`→"no key" (amber), `timeout`→"timeout" (rose), `busy`→"model busy" (amber), `error`→"error" (rose); unknown → raw status (neutral).

### 12.3 `AutoStepsPanel` ([page.tsx:1142-1194](Smart-Tutor-frontend/app/simulator/page.tsx#L1142))

Rendered only when `meta.steps` exists (AUTO / `model_id === "auto"`). Shows the escalation header (`escalated → tier N` vs "no escalation needed", plus an "answer-key memo active" badge when `memo_active`), then one card per `AutoStep`: `T{tier}`, model, role, latency, `in/think/out` tokens, cost, and `conf` (2 dp), plus the step's `reason`.

### 12.4 `JourneyBreakdown` ([JourneyBreakdown.tsx](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx))

- Appends a `render` step from `renderMs` when ≥ 0 ([L87-90](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L87)).
- `STEP_META` labels: `prepare→"Capture & encode"`, `auth→"Auth token"`, `upload→"Upload + round trip"`, `stt→"Speech-to-text"`, `model→"Model inference"`, `parse→"Parse output"`, `render→"Render to screen"`. Unknown keys still render with the raw key.
- **Total math** ([L100-109](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L100)): if an `upload` bar exists (live view), server steps happened *inside* it, so total = sum(client steps). Otherwise (persisted/admin view) total = sum(client) + sum(server). Bars are tinted amber (client) / cyan (server); width = `max(2, round(ms/max*100))%`.

### 12.5 `SpokenResponse` & TTS ([page.tsx:732-823](Smart-Tutor-frontend/app/simulator/page.tsx#L732))

Uses the browser **Web Speech API** (`SpeechSynthesisUtterance`, `rate=1.0`, `pitch=1.0`). On each *new* answer (`speech` change), auto-speaks if `autoSpeak` is on; cancels any in-flight utterance on new answer / unmount. Manual Play/Stop always available; gracefully reports if `speechSynthesis` is unsupported. The note clarifies the *physical lamp uses Piper TTS* — the browser voice is a sim stand-in. `CompareSpeech` ([L1445-1473](Smart-Tutor-frontend/app/simulator/page.tsx#L1445)) is a lighter Play-only variant for the compare grid.

### 12.6 `FeedbackBar` ([page.tsx:1319-1443](Smart-Tutor-frontend/app/simulator/page.tsx#L1319))

Keyed by `response_id` (returns `null` if absent). Thumbs up/down (toggle to clear), 1–5 stars, and an optional note. Each interaction calls `submit(patch)` → `useFeedback()` → `POST /feedback`; failures are swallowed (best-effort); a "Saved" check flashes for 1500 ms.

### 12.7 Status / empty cards

- **`ThinkingCard`** ([page.tsx:1197-1231](Smart-Tutor-frontend/app/simulator/page.tsx#L1197)): a per-second counter escalates the message because `/solve` doesn't stream and a long wait reads as "hung". Phases: `< 8 s` base label; `≥ 8 s` "Still thinking…"; `≥ 25 s` "Thinking hard, or retrying a busy server… up to a minute"; `≥ 45 s` "Gemini's servers are busy — automatically retrying…". The comment references `SOLVE_TIMEOUT_S (85 s)` as the per-model cap.
- **`ErrorCard`** ([L1233-1242](Smart-Tutor-frontend/app/simulator/page.tsx#L1233)) and **`EmptyCard`** ([L1244-1256](Smart-Tutor-frontend/app/simulator/page.tsx#L1244)) are static.

---

## 13. Edge cases, error handling, timeouts & fallbacks

| Scenario | Handling | Location |
|---|---|---|
| Camera denied (user says no) | `state = "denied"` → "Camera & mic blocked…" prompt | [hook L50-51,64](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L50) / [page L477-478](Smart-Tutor-frontend/app/simulator/page.tsx#L477) |
| No camera / constraints unmet | Retry **mic-only**; `hasVideo=false`; UI shows mic-only fallback + upload | [hook L46-53](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L46) / [page L499-508](Smart-Tutor-frontend/app/simulator/page.tsx#L499) |
| Other device error | `state="error"` + `error` message surfaced | [hook L65-68](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L65) |
| Snapshot before stream ready | `snapshotJpeg` returns `null` (guards on `videoWidth`) | [hook L73-74](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L73) |
| Recording produced no audio | `stopRecording` returns `null` (total samples = 0) | [hook L128-129](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L128) |
| All auto-frames dup/blurry | Safety-net snaps one final frame so ≥1 image ships | [page L370-373](Smart-Tutor-frontend/app/simulator/page.tsx#L370) |
| Nothing captured at all | "Nothing captured — hold the button and speak, or type." | [page L257-260](Smart-Tutor-frontend/app/simulator/page.tsx#L257) |
| Compare mode, no models picked | "Pick at least one model to compare." | [page L261-264](Smart-Tutor-frontend/app/simulator/page.tsx#L261) |
| > 5 images attempted | Stops at cap; clear "at most 5"/"only first N" message | [page L193-216](Smart-Tutor-frontend/app/simulator/page.tsx#L193) |
| Non-image file uploaded | "That file isn't an image — pick a JPG or PNG." | [page L203-205](Smart-Tutor-frontend/app/simulator/page.tsx#L203) |
| File > 8 MB | "One image is too large (>8 MB)…" | [page L207-209](Smart-Tutor-frontend/app/simulator/page.tsx#L207) |
| Backend `EMPTY_INPUT` | "Nothing captured — try again." | [page L289-290](Smart-Tutor-frontend/app/simulator/page.tsx#L289) |
| Backend `BRAIN_BUSY` | "The AI is busy right now…" | [page L291-292](Smart-Tutor-frontend/app/simulator/page.tsx#L291) |
| Network / backend down | "Couldn't reach the backend. Is it running?" (matches `Failed to fetch`) | [page L293-294](Smart-Tutor-frontend/app/simulator/page.tsx#L293) |
| Per-model `timeout`/`busy`/`error` status | `StatusBadge` + inline note; compare cards keep other results | [page L1114-1122](Smart-Tutor-frontend/app/simulator/page.tsx#L1114) |
| Missing Clerk token | Request sent unauthenticated; `WARN AUTH` logged | [models L184](Smart-Tutor-frontend/lib/models.ts#L184) |
| KaTeX parse failure | Falls back to raw source as red `<code>` | [page L865, L899-901](Smart-Tutor-frontend/app/simulator/page.tsx#L865) |
| No `speechSynthesis` support | Play/Stop hidden; note explains | [page L817-819](Smart-Tutor-frontend/app/simulator/page.tsx#L817) |
| Feedback POST fails | Swallowed (best-effort), UI never blocks | [page L1345-1347](Smart-Tutor-frontend/app/simulator/page.tsx#L1345) |
| Object-URL leaks | Per-item revoke on remove/clear + unmount sweep | [page L183-237](Smart-Tutor-frontend/app/simulator/page.tsx#L183) |
| Mid-hold unmount | `useEffect` cleanup kills the auto-capture timer | [page L381](Smart-Tutor-frontend/app/simulator/page.tsx#L381) |

**Timeouts:** there is **no client-side fetch timeout** — the page relies on the backend's `SOLVE_TIMEOUT_S` per-model cap (config default `30.0` s in [`config.py:178`](Smart-Tutor-Lamp-backend/app/config.py#L178), referenced as `85 s` in the frontend `ThinkingCard` comment and `model_solver.py:50`). The `ThinkingCard` escalating copy is the UX compensation for the lack of streaming.

---

## 14. Integration points / cross-references

**Calls out to (backend FastAPI Frontend Manager, base `NEXT_PUBLIC_BACKEND_URL`):**

| Endpoint | Method | Caller | Backend handler |
|---|---|---|---|
| `/api/frontend/models` | GET | `useModels` | [`frontend_manager.py:900`](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L900) |
| `/api/frontend/solve` | POST (multipart) | `solveOne` | `frontend_manager.py` (`_read_solve_inputs` [L922](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L922), AUTO `_solve_auto` [L1029](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1029)) |
| `/api/frontend/solve/compare` | POST (multipart) | `solveCompare` | `frontend_manager.py` |
| `/api/frontend/feedback` | POST (JSON) | `useFeedback` | `frontend_manager.py` |

**Shared contracts with the backend:**
- `MAX_IMAGES = 5` ⇄ `MAX_IMAGES_PER_TURN = 5` ([`session.py:152`](Smart-Tutor-Lamp-backend/app/session.py#L152)) ⇄ DB `turns_image_count_check`.
- Per-image byte cap: client 8 MB UX guard ⇄ backend hard drop `_MAX_IMAGE_BYTES = 256 KB` ([`session.py:147`](Smart-Tutor-Lamp-backend/app/session.py#L147)).
- The 16 kHz mono WAV + JPEG-snapshot payload **mirrors the lamp's** WS multimodal turn ([`session.py:145-164`](Smart-Tutor-Lamp-backend/app/session.py#L145)).
- Wire types (`SolveOut`, `SolveMeta`, `ModelInfo`, `AutoStep`, `TimelineStep`) mirror `app/schemas/model_eval.py`.
- Error codes `EMPTY_INPUT` / `BRAIN_BUSY` are produced by the backend ([`frontend_manager.py:269`](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L269), [L617](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L617)) and mapped to friendly text in `send()`.

**Called by:** `AppHeader` links to `/simulator`; the Next.js App Router renders `SimulatorPage` as the `/simulator` route. The `JourneyBreakdown` component is shared with the admin Turns log (persisted journeys).

**Auth:** Clerk (`@clerk/nextjs` `useAuth`) → `getToken()` → `Authorization: Bearer`.

**Firmware parity:** the simulator is the browser analog of the ESP32-S3 lamp's capture/upload path; both produce the same multimodal turn and the same split `speech`/`display` answer. The lamp uses Piper TTS on-device; the simulator uses the browser's `speechSynthesis`.

---

## 15. Function-by-function index

### `lib/useSimulatorCapture.ts`
| Symbol | Lines | Summary |
|---|---|---|
| `SAMPLE_RATE` | [L10](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L10) | 16000 target rate. |
| `MediaState` | [L12](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L12) | Device lifecycle union. |
| `useSimulatorCapture` | [L14-161](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L14) | The capture hook (state, refs, methods). |
| `enable` | [L31-70](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L31) | Acquire camera+mic (fallback mic-only). |
| `snapshotJpeg` | [L72-82](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L72) | Native-res JPEG Blob (q=0.85). |
| `startRecording` | [L84-114](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L84) | Open WebAudio capture graph. |
| `stopRecording` | [L116-138](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L116) | Close graph, merge, encode WAV. |
| `disable` | [L140-147](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L140) | Full teardown. |
| `downsampleToInt16` | [L163-188](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L163) | Box-average resample + int16 quantize. |
| `encodeWav` | [L190-212](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L190) | 44-byte WAV/PCM container. |

### `app/simulator/page.tsx`
| Symbol | Lines | Summary |
|---|---|---|
| `frameStats` | [L90-121](Smart-Tutor-frontend/app/simulator/page.tsx#L90) | 160×160 grayscale signature + Laplacian-variance sharpness. |
| `meanAbsDiff` | [L123-128](Smart-Tutor-frontend/app/simulator/page.tsx#L123) | Mean abs per-pixel diff (Infinity if no prior). |
| `SimulatorPage` | [L130-730](Smart-Tutor-frontend/app/simulator/page.tsx#L130) | Top-level page + orchestration. |
| `addImages`/`removeAt`/`clearImages`/`snapFromCamera` | [L191-247](Smart-Tutor-frontend/app/simulator/page.tsx#L191) | Image-queue management. |
| `send` | [L249-300](Smart-Tutor-frontend/app/simulator/page.tsx#L249) | Unified dispatch + render timing + error mapping. |
| `stopAutoCapture`/`autoTick`/`startTalk`/`endTalk` | [L308-378](Smart-Tutor-frontend/app/simulator/page.tsx#L308) | Push-to-talk + hands-free auto-capture. |
| `submitText` | [L383-404](Smart-Tutor-frontend/app/simulator/page.tsx#L383) | Typed/image-only submit. |
| `SpokenResponse` / `CompareSpeech` | [L732-823](Smart-Tutor-frontend/app/simulator/page.tsx#L732) / [L1445-1473](Smart-Tutor-frontend/app/simulator/page.tsx#L1445) | Browser TTS. |
| `RawJson` | [L825-836](Smart-Tutor-frontend/app/simulator/page.tsx#L825) | `<details>` JSON dump. |
| `MathRichText` / `stripMathDelims` / `ScreenDisplay` | [L845-917](Smart-Tutor-frontend/app/simulator/page.tsx#L845) | KaTeX rendering pipeline. |
| `ModelControls` / `ModelDropdown` | [L920-1041](Smart-Tutor-frontend/app/simulator/page.tsx#L920) | Model selection UI. |
| `StatusBadge` / `MetaStat` / `MetaStrip` | [L1044-1136](Smart-Tutor-frontend/app/simulator/page.tsx#L1044) | Telemetry strip. |
| `AutoStepsPanel` | [L1142-1194](Smart-Tutor-frontend/app/simulator/page.tsx#L1142) | AUTO escalation breakdown. |
| `ThinkingCard` / `ErrorCard` / `EmptyCard` | [L1197-1256](Smart-Tutor-frontend/app/simulator/page.tsx#L1197) | Status cards. |
| `CompareCard` | [L1259-1316](Smart-Tutor-frontend/app/simulator/page.tsx#L1259) | One model column in compare mode. |
| `FeedbackBar` | [L1319-1443](Smart-Tutor-frontend/app/simulator/page.tsx#L1319) | Thumbs/stars/note feedback. |

---

*All behavior above is grounded in the cited source. The frontend `ThinkingCard` comment cites `SOLVE_TIMEOUT_S` as 85 s while the backend `config.py` default is `30.0` s — the actual cap is whatever the deployed backend config sets; the simulator imposes no client timeout.*
