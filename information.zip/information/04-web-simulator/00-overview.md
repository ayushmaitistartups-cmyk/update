# Web Simulator — Overview & Purpose

The **Web Simulator** is the browser stand-in for the physical Smart Tutor Lamp. It lets anyone test or demo the AI tutor "brain" — multimodal capture (webcam image + spoken question + typed text), the multi‑LLM solve pipeline, TTS, the KaTeX "screen", and conversational memory — **without ESP32 hardware**. It mirrors exactly what the lamp sends over the wire (a 16 kHz mono WAV + JPEG snapshots + text), exercises the same backend brain and the same binary WebSocket frame protocol, and even persists its turns to the same Postgres `turns` table (tagged `source="simulation"`). When no `GEMINI_API_KEY` is configured, a deterministic Python fallback (`web_simulator.py`) keeps the entire stack — framing, auth, streaming, TTS — alive so the UI still animates and speaks.

---

## Table of Contents

1. [Purpose & responsibility](#1-purpose--responsibility)
2. [System map: where the simulator plugs in](#2-system-map-where-the-simulator-plugs-in)
3. [The two backends behind the simulator: `/solve` vs `/ws`](#3-the-two-backends-behind-the-simulator-solve-vs-ws)
4. [File-by-file breakdown](#4-file-by-file-breakdown)
   - [4.1 `lib/useSimulatorCapture.ts` — audio/camera capture](#41-libusesimulatorcapturets--audiocamera-capture)
   - [4.2 `app/simulator/page.tsx` — the page & control flow](#42-appsimulatorpagetsx--the-page--control-flow)
   - [4.3 `lib/models.ts` — the solve data layer & journey timing](#43-libmodelsts--the-solve-data-layer--journey-timing)
   - [4.4 `app/providers/web_simulator.py` — deterministic brain fallback](#44-appproviderswebsimulatorpy--deterministic-brain-fallback)
   - [4.5 `frontend_manager.py` — the backend gateway](#45-frontendmanagerpy--the-backend-gateway)
5. [Algorithms, math, thresholds & constants](#5-algorithms-math-thresholds--constants)
6. [Data processing pipeline (inputs → transforms → outputs)](#6-data-processing-pipeline-inputs--transforms--outputs)
7. [How the simulator maps onto the real lamp](#7-how-the-simulator-maps-onto-the-real-lamp)
8. [Configuration, environment variables & constants](#8-configuration-environment-variables--constants)
9. [Edge cases, error handling, timeouts, fallbacks](#9-edge-cases-error-handling-timeouts-fallbacks)
10. [Integration points (cross-references)](#10-integration-points-cross-references)
11. [Diagrams](#11-diagrams)

---

## 1. Purpose & responsibility

The simulator exists to answer a single engineering need: **how do you build, demo, and regression‑test an AI tutoring appliance when the appliance is firmware on a microcontroller you may not have on your desk?**

The lamp's "loop" is: wake → capture a webcam frame of a worksheet + a spoken question → ship them to the backend brain → receive a spoken answer (TTS) + a rendered "screen" (TFT). The simulator reproduces each of those legs in a browser tab:

- **Camera** → `getUserMedia` video, snapshotted to a JPEG (`useSimulatorCapture.snapshotJpeg`).
- **Microphone** → raw Web‑Audio PCM, downsampled to **16 kHz mono** and WAV‑encoded on mic release (the lamp's exact uplink audio contract).
- **Spoken answer** → spoken by the **browser's Web Speech API** (`SpeechSynthesisUtterance`) on the `/solve` path, OR streamed back as binary `AUDIO_OUT` frames from Piper TTS on the `/ws` path.
- **TFT screen** → the `display.{type,latex,text}` object rendered with **KaTeX** (`react-katex`), standing in for the lamp's TFT view.

Its responsibilities, concretely:

1. Capture a lamp‑shaped multimodal payload entirely in the browser.
2. POST it (multipart) to the same brain that the lamp's WebSocket orchestrator uses — `gemini_brain.simulate*` — through `/api/frontend/solve` (single model) and `/api/frontend/solve/compare` (many models side‑by‑side).
3. Surface **per‑invocation telemetry**: latency, token counts, estimated cost, the tiered‑escalation "AUTO" breakdown, and a full input→output **journey** waterfall.
4. Provide a binary‑WebSocket variant (`/api/frontend/ws`) that hits the **identical frame protocol** the lamp uses, so the framing/streaming/TTS path itself is tested, not just the HTTP brain.
5. Degrade gracefully: if `GEMINI_API_KEY` is unset, the deterministic `web_simulator.respond()` keeps the WS path producing a thinking → speaking → idle timeline + text tokens.
6. Persist its turns (fire‑and‑forget) so the same dashboard/analytics/admin trace surfaces cover both the lamp and the bench (tagged `source="simulation"` / `source="simulator"`).

> Quote: the simulator's `<h1>` is literally *"Test the brain from your browser."* and the page label is *"Brain simulator"* — see [page.tsx:414-417](Smart-Tutor-frontend/app/simulator/page.tsx#L414).

---

## 2. System map: where the simulator plugs in

```
┌──────────────────────── BROWSER (Next.js /simulator) ────────────────────────┐
│  app/simulator/page.tsx        ── UI, push-to-talk, image queue, telemetry    │
│     ├─ lib/useSimulatorCapture.ts  ── getUserMedia → JPEG + 16kHz WAV         │
│     ├─ lib/models.ts               ── useSolve()/useModels()/useFeedback()    │
│     │       buildForm() → multipart (audio.wav + images[] + text)             │
│     └─ Web Speech API (SpeechSynthesisUtterance)  ── speaks the answer        │
└───────────────┬───────────────────────────────────────────────┬─────────────┘
                │ HTTPS multipart (Clerk Bearer)                  │ WS ?token=
                ▼                                                 ▼
┌──────────────────────── BACKEND (FastAPI /api/frontend) ─────────────────────┐
│  routes/frontend_manager.py                                                   │
│     POST /simulate   ── legacy tiered Gemini dispatch (untouched)             │
│     POST /solve      ── provider-agnostic single-model solve + telemetry      │
│     POST /solve/compare ── many models concurrently                           │
│     GET  /models     ── model catalog (only key-configured providers)         │
│     POST /feedback   ── thumbs/star/note on one answer                        │
│     WS   /ws         ── binary frame protocol (same as the lamp)              │
│           └─ _build_stream(): gemini_brain.respond()  OR                      │
│                              web_simulator.respond()  ◀── fallback brain      │
│           └─ _drive_turn(): STATE / TEXT_OUT / AUDIO_OUT(Piper) frames        │
│     providers/web_simulator.py ── deterministic BrainEvent timeline           │
│     providers/gemini_brain.py  ── simulate()/simulate_with_usage()/respond()  │
│     services/model_solver.py   ── generate_solution() (any provider)          │
└───────────────┬───────────────────────────────────────────────┬─────────────┘
                │ fire-and-forget persist                          │ analytics/admin
                ▼                                                   ▼
        Postgres `turns` (extra.source="simulation") + `turn_traces` (source="simulator")
```

The same physical device protocol lives in [protocol.py](Smart-Tutor-Lamp-backend/app/protocol.py); the lamp simulator script `dummy_client.py` drives that same protocol from Python (a *separate* test tool — see §7).

---

## 3. The two backends behind the simulator: `/solve` vs `/ws`

The `/simulator` page (`page.tsx`) talks to **`/solve` + `/solve/compare`** (HTTP multipart). The WebSocket gateway `/ws` is the *other* simulator surface — it reuses the lamp's binary framing and is where `app/providers/web_simulator.py` is actually invoked. Understanding the split is essential:

| | `/api/frontend/solve` (+ `/solve/compare`) | `/api/frontend/ws` |
|---|---|---|
| Transport | HTTPS multipart `FormData` | Binary WebSocket, lamp frame protocol |
| Driven by | `app/simulator/page.tsx` via `lib/models.ts` | A WS client (browser bench / parity tests) |
| Brain | `model_solver.generate_solution()` → `gemini_brain.simulate_with_usage()` | `gemini_brain.respond()` **or** `web_simulator.respond()` |
| Answer voice | Browser **Web Speech API** | Backend **Piper** TTS (`FRONTEND_TTS_PROVIDER`) streamed as `AUDIO_OUT` |
| Output shape | `{response:{speech,display}, meta:{…telemetry}}` | Streamed `STATE` / `TEXT_OUT` / `AUDIO_OUT` frames |
| Fallback when no Gemini key | model is hidden / `not_configured` | `web_simulator.respond()` keeps it alive |

`web_simulator.py` is the deterministic fallback brain for the **`/ws`** path. The page's primary path (`/solve`) speaks via the browser, so `FRONTEND_TTS_PROVIDER="none"` only silences the WS voice bench — the page still speaks (see [config.py:80-82](Smart-Tutor-Lamp-backend/app/config.py#L80)).

---

## 4. File-by-file breakdown

### 4.1 `lib/useSimulatorCapture.ts` — audio/camera capture

The capture hook. Its header states intent precisely: *"Camera + mic capture for the /simulator test bench. Mirrors the lamp's multimodal payload: a webcam JPEG snapshot + a 16 kHz mono WAV of the spoken question. The mic is captured as raw PCM via the Web Audio graph and encoded to WAV on release (Gemini accepts audio/wav directly)."* — [useSimulatorCapture.ts:3-6](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L3).

**Module constant**

- `SAMPLE_RATE = 16000` — [useSimulatorCapture.ts:10](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L10). This is the lamp's uplink rate (`AUDIO_CHUNK` = "int16 LE 16 kHz mono" — [protocol.py:19](Smart-Tutor-Lamp-backend/app/protocol.py#L19)) and the backend's `BRAIN_AUDIO_SAMPLE_RATE = 16000` — [config.py:166](Smart-Tutor-Lamp-backend/app/config.py#L166).

**Type:** `MediaState = "idle" | "requesting" | "ready" | "denied" | "error"` — [useSimulatorCapture.ts:12](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L12). This drives every UI branch in `page.tsx`.

**Hook state & refs** ([useSimulatorCapture.ts:14-29](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L14)):

| Field | Type | Role |
|---|---|---|
| `state` | `MediaState` | overall capture lifecycle |
| `error` | `string \| null` | last device error message |
| `recording` | `boolean` | mic actively capturing |
| `hasVideo` | `boolean` | true only when the granted stream has a video track |
| `streamRef` | `MediaStream` | the live getUserMedia stream |
| `videoRef` | `HTMLVideoElement` | the `<video>` preview |
| `ctxRef` | `AudioContext` | Web Audio graph |
| `procRef` | `ScriptProcessorNode` | pulls PCM frames (4096 samples) |
| `srcRef` | `MediaStreamAudioSourceNode` | mic → graph |
| `sinkRef` | `GainNode` | muted sink keeping the graph pulling |
| `chunksRef` | `Int16Array[]` | accumulated downsampled PCM |

**Functions:**

- **`enable()`** — [useSimulatorCapture.ts:31-70](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L31). Requests `getUserMedia`. Audio constraints: `{ channelCount: 1, echoCancellation: true, noiseSuppression: true }`. Video constraints prefer the rear/environment camera at a **portrait** "ideal" of `720×1280` (a worksheet is taller than wide) — `{ facingMode:{ideal:"environment"}, width:{ideal:720}, height:{ideal:1280} }`. **Two-tier fallback:** if camera+mic fails with `NotAllowedError`/`SecurityError` (the user explicitly said no), it rethrows → `state="denied"`. Any other failure (no camera, constraints unmet) retries **mic‑only** so the user can still speak and upload an image. Sets `hasVideo` from `stream.getVideoTracks().length > 0`, binds the stream to `videoRef`, plays it (errors swallowed), then `state="ready"`.
- **`snapshotJpeg(quality = 0.85)`** — [useSimulatorCapture.ts:72-82](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L72). Draws the live `<video>` onto an off‑screen canvas at the video's native resolution and `canvas.toBlob(…, "image/jpeg", 0.85)`. Returns `null` if no video / zero width.
- **`startRecording()`** — [useSimulatorCapture.ts:84-114](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L84). Builds the Web Audio graph: `AudioContext` (with `webkitAudioContext` fallback) → `MediaStreamSource` → `ScriptProcessorNode(4096, 1, 1)` → muted `GainNode` (gain `0`) → `destination`. The muted sink keeps the processor pulling without echoing the mic to the speakers. On every `onaudioprocess`, it reads channel 0 and pushes `downsampleToInt16(input, ctx.sampleRate, 16000)` into `chunksRef`.
- **`stopRecording()`** — [useSimulatorCapture.ts:116-138](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L116). Disconnects + closes the graph, concatenates all `Int16Array` chunks into one buffer, returns `encodeWav(merged, 16000)`. Returns `null` if zero samples captured.
- **`disable()`** — [useSimulatorCapture.ts:140-147](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L140). Stops recording, stops all tracks, clears the video, resets to `idle`.

**Pure helpers:**

- **`downsampleToInt16(input, srcRate, dstRate)`** — [useSimulatorCapture.ts:163-188](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L163). See §5.
- **`encodeWav(samples, sampleRate)`** — [useSimulatorCapture.ts:190-212](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L190). Writes a 44‑byte canonical PCM WAV header (`RIFF`/`WAVE`/`fmt `/`data`), PCM format `1`, mono, 16 bits/sample, byte rate `sampleRate*2`, block align `2`, then the little‑endian int16 samples; returns a `Blob` of type `audio/wav`.

### 4.2 `app/simulator/page.tsx` — the page & control flow

The whole `/simulator` screen — the default export `SimulatorPage` plus ~15 presentational sub‑components. Imports `useSimulatorCapture`, `useModels/useSolve/useFeedback`, and KaTeX.

**Local interfaces:**

- `Display { type: "latex"|"text"|"none"; latex: string; text: string }` — [page.tsx:50-54](Smart-Tutor-frontend/app/simulator/page.tsx#L50).
- `SimResponse { speech: string; display: Display }` — [page.tsx:55-58](Smart-Tutor-frontend/app/simulator/page.tsx#L55). (The richer wire `SimResponse` with `confidence/query_type/…` lives in `lib/models.ts`.)

**Module constants** (these are the simulator's tunables — see §5):

| Constant | Value | Purpose | Ref |
|---|---|---|---|
| `EXAMPLES` | 3 sample prompts | quick‑fill chips | [page.tsx:60](Smart-Tutor-frontend/app/simulator/page.tsx#L60) |
| `MAX_IMAGES` | `5` | per‑turn image cap; MUST match backend `MAX_IMAGES_PER_TURN` + DB `turns_image_count_check` | [page.tsx:71](Smart-Tutor-frontend/app/simulator/page.tsx#L71) |
| `MAX_IMAGE_BYTES` | `8*1024*1024` (8 MB) | per‑file UX cap before the backend's 256 KB drop guard | [page.tsx:76](Smart-Tutor-frontend/app/simulator/page.tsx#L76) |
| `AUTO_CAPTURE_INTERVAL_MS` | `1400` | hands‑free auto‑capture cadence | [page.tsx:82](Smart-Tutor-frontend/app/simulator/page.tsx#L82) |
| `SIG_SIZE` | `160` | downscaled frame for diff + sharpness | [page.tsx:83](Smart-Tutor-frontend/app/simulator/page.tsx#L83) |
| `FRAME_DIFF_THRESHOLD` | `9` | mean grey delta above which it's a "new page" | [page.tsx:84](Smart-Tutor-frontend/app/simulator/page.tsx#L84) |
| `SHARPNESS_MIN` | `12` | Laplacian variance below = too blurry to keep | [page.tsx:85](Smart-Tutor-frontend/app/simulator/page.tsx#L85) |

**Top‑level pure functions:**

- **`frameStats(video)`** — [page.tsx:90-121](Smart-Tutor-frontend/app/simulator/page.tsx#L90). Computes a `{ gray: Float32Array, sharp: number }` signature from the live video (see §5).
- **`meanAbsDiff(a, b)`** — [page.tsx:123-128](Smart-Tutor-frontend/app/simulator/page.tsx#L123). Mean absolute difference between two grey signatures; returns `Infinity` if either is null (so the first frame is always "different").

**`SimulatorPage` state** ([page.tsx:130-179](Smart-Tutor-frontend/app/simulator/page.tsx#L130)): `cam` (the capture hook), `loading`, `results: SolveOut[] | null`, `err`, `text`, `renderMs` (browser paint time), model selection (`compareMode`, `selectedModel`, `compareModels`, derived `activeModel`), `autoSpeak` (persisted in `localStorage["lumos.autospeak"]`, default ON), and the multi‑image queue `images: Blob[]` + `previews: string[]` (object URLs).

**Key handlers:**

- **Image queue management** — `addImages` ([page.tsx:191-221](Smart-Tutor-frontend/app/simulator/page.tsx#L191)) enforces `MAX_IMAGES`, rejects non‑image MIME and files over `MAX_IMAGE_BYTES`, appends accepted blobs + creates object URLs. `removeAt` ([page.tsx:223-230](Smart-Tutor-frontend/app/simulator/page.tsx#L223)) and `clearImages` ([page.tsx:232-237](Smart-Tutor-frontend/app/simulator/page.tsx#L232)) revoke object URLs to avoid leaks. `snapFromCamera` ([page.tsx:239-247](Smart-Tutor-frontend/app/simulator/page.tsx#L239)) appends a webcam snapshot.
- **`send(audio, imageList, textVal?, startedAt?)`** — [page.tsx:249-300](Smart-Tutor-frontend/app/simulator/page.tsx#L249). The unified submit. Validates "something captured", validates compare‑mode selection, sets loading, calls `solveCompare(compareModels, …)` or `[await solveOne(activeModel, …)]`, times the final render leg with double‑`requestAnimationFrame`, clears images on success, and maps backend error codes (`EMPTY_INPUT`, `BRAIN_BUSY`, fetch failures) to friendly messages.
- **Push‑to‑talk + hands‑free auto‑capture** — `stopAutoCapture`, `autoTick(force)`, `startTalk`, `endTalk` ([page.tsx:302-381](Smart-Tutor-frontend/app/simulator/page.tsx#L302)). `startTalk` either respects a user‑curated image queue *or* begins auto‑capture (first frame forced, then every `AUTO_CAPTURE_INTERVAL_MS`). `endTalk` starts the journey clock at mic‑release, stops auto‑capture, gets the WAV, and includes a **safety net** — if nothing was captured it grabs one final frame so a turn never sends zero images.
- **`submitText(e)`** — [page.tsx:383-404](Smart-Tutor-frontend/app/simulator/page.tsx#L383). Text/image submit. Allows text‑only, image(s)‑only, or both; if there's text and no queued image, it snaps one frame for context.

**Presentational sub‑components** (all in the same file):

| Component | Responsibility | Ref |
|---|---|---|
| `SpokenResponse` | renders `speech`, drives **Web Speech API** auto‑speak (`SpeechSynthesisUtterance`, `rate 1.0`, `pitch 1.0`) | [page.tsx:732-823](Smart-Tutor-frontend/app/simulator/page.tsx#L732) |
| `RawJson` | collapsible raw LLM JSON | [page.tsx:825](Smart-Tutor-frontend/app/simulator/page.tsx#L825) |
| `MathRichText` | splits prose into segments and KaTeX‑renders inline/block math spans | [page.tsx:845-872](Smart-Tutor-frontend/app/simulator/page.tsx#L845) |
| `stripMathDelims` | strips one outer math delimiter layer before KaTeX | [page.tsx:877-886](Smart-Tutor-frontend/app/simulator/page.tsx#L877) |
| `ScreenDisplay` | the "TFT" — KaTeX `BlockMath` for `latex`, `MathRichText` for `text`, placeholder for `none` | [page.tsx:888-917](Smart-Tutor-frontend/app/simulator/page.tsx#L888) |
| `ModelControls` / `ModelDropdown` | the model picker + compare toggle | [page.tsx:920-1041](Smart-Tutor-frontend/app/simulator/page.tsx#L920) |
| `StatusBadge` | maps `status` → coloured badge (`ok`/`not_configured`/`timeout`/`busy`/`error`) | [page.tsx:1044](Smart-Tutor-frontend/app/simulator/page.tsx#L1044) |
| `MetaStrip` / `MetaStat` | latency/tokens/cost strip + the **journey** toggle (`JourneyBreakdown`) | [page.tsx:1060-1136](Smart-Tutor-frontend/app/simulator/page.tsx#L1060) |
| `AutoStepsPanel` | the AUTO tiered‑escalation per‑step breakdown | [page.tsx:1142-1194](Smart-Tutor-frontend/app/simulator/page.tsx#L1142) |
| `ThinkingCard` | elapsed‑time spinner; escalates copy at 8 s / 25 s / 45 s | [page.tsx:1197-1231](Smart-Tutor-frontend/app/simulator/page.tsx#L1197) |
| `ErrorCard` / `EmptyCard` | error and empty states | [page.tsx:1233-1256](Smart-Tutor-frontend/app/simulator/page.tsx#L1233) |
| `CompareCard` / `CompareSpeech` | one model's column in Compare mode | [page.tsx:1259-1473](Smart-Tutor-frontend/app/simulator/page.tsx#L1259) |
| `FeedbackBar` | thumbs / 1‑5 star / note → `useFeedback()` (best‑effort, never blocks UI) | [page.tsx:1319-1443](Smart-Tutor-frontend/app/simulator/page.tsx#L1319) |

### 4.3 `lib/models.ts` — the solve data layer & journey timing

The multi‑LLM evaluation data layer. *"The solve calls send multipart FormData (audio WAV + image blobs + text), so they use a token‑aware fetch directly rather than the JSON useApi() helpers — same pattern the simulator already uses for /simulate."* — [models.ts:6-9](Smart-Tutor-frontend/lib/models.ts#L6).

**Wire types** mirror `app/schemas/model_eval.py`: `ModelInfo`, `ModelsOut`, `SimDisplay`, `SimResponse`, `TimelineStep` (`where: "client"|"server"`), `AutoStep` (the AUTO breakdown rows), `SolveMeta` (status/latency/tokens/cost/`response_id`/`timeline`/AUTO fields), `FeedbackInput`, `SolveOut { response, meta }`, `CompareOut { results }` — [models.ts:16-113](Smart-Tutor-frontend/lib/models.ts#L16).

> **Update (2026-07-06):** the backend half of this mirror has drifted — the current `SolveMeta` no longer defines `timeline`/`server_ms` (dropped in the graphs-cleanup commit 6b16c38, 2026-06-08) and `/solve` never reads the `client_timeline` form field, so the journey field the page appends is ignored server-side; the persisted server-side step breakdown now lives in the AUTO `steps` array plus the `turn_traces` storyboard (`TurnTracer`) — see [model_eval.py:56-82](Smart-Tutor-Lamp-backend/app/schemas/model_eval.py#L56).

**Functions:**

- **`useModels()`** — [models.ts:116-124](Smart-Tutor-frontend/lib/models.ts#L116). React‑Query hook → `GET /api/frontend/models`; `staleTime = 5 min`.
- **`buildForm(input)`** — [models.ts:133-145](Smart-Tutor-frontend/lib/models.ts#L133). Builds the multipart body: `audio → "question.wav"`, each image → `images` field as `snap-N.jpg`, `text` trimmed. **The legacy single `image` field is deliberately not sent** — double‑appending caused 2× upload + 2× Gemini billing (observed prod 2026‑06‑12).
- **`postFormTimed(path, fd, getToken, startedAt?)`** — [models.ts:161-232](Smart-Tutor-frontend/lib/models.ts#L161). The instrumented POST. Measures **prepare** (input given → just before auth), **auth** (Clerk `getToken()`), **upload** (full round trip). Appends `client_timeline = JSON([prepare, auth])` to the form so the *persisted* journey spans the whole path; attaches `Authorization: Bearer <token>`; on `!r.ok` extracts `detail.code`/`detail.error` into a tagged `Error`.
- **`withClientJourney(out, clientSteps)`** — [models.ts:235-238](Smart-Tutor-frontend/lib/models.ts#L235). Prepends the browser steps in front of the server timeline.
- **`useSolve()`** → `solveOne(model, input, startedAt?)` / `solveCompare(models, input, startedAt?)` — [models.ts:256-283](Smart-Tutor-frontend/lib/models.ts#L256). `solveOne` POSTs `/api/frontend/solve` with `model`; `solveCompare` POSTs `/api/frontend/solve/compare` with repeated `models` fields and applies the one client journey prefix to every result.
- **`useFeedback()`** — [models.ts:286-290](Smart-Tutor-frontend/lib/models.ts#L286). `POST /api/frontend/feedback`.
- **Formatters** `formatCost` / `formatLatency` / `formatTokens` — [models.ts:293-308](Smart-Tutor-frontend/lib/models.ts#L293).

### 4.4 `app/providers/web_simulator.py` — deterministic brain fallback

The whole module is 68 lines. Its docstring is the canonical statement of purpose: *"Deterministic brain fallback for the web bench — used when GEMINI_API_KEY is unset so the frontend `/simulator` + `/api/frontend/ws` still exercise the full stack (framing, auth, TTS) without a live LLM."* — [web_simulator.py:1-11](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L1). It was *"Ported from the prototype backend (`brain/simulator.py`)"* and adapted to the main backend's `StateByte` and `UserProfile` row.

**`BrainEvent` dataclass** — [web_simulator.py:21-26](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L21). The streaming "timeline" unit that **both** this fallback and the real `gemini_brain` emit, so the WS gateway's `_drive_turn` is brain‑agnostic:

| Field | Type | Default | Meaning |
|---|---|---|---|
| `kind` | `str` | — | `"state"` \| `"text"` \| `"text_end"` |
| `payload` | `str` | `""` | text token (for `kind="text"`) |
| `state_byte` | `int` | `0` | a `StateByte` value (for `kind="state"`) |

**`_persona(profile)`** — [web_simulator.py:29-34](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L29). Builds a short persona string from the profile's `target_exam` / `prep_duration` (defaults `"a learner"` / `"their exam"` / `"ongoing prep"`).

**`respond(user_text, profile)` (async generator)** — [web_simulator.py:37-56](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L37). The deterministic timeline:

1. `yield BrainEvent("state", state_byte=StateByte.THINKING)` then `await asyncio.sleep(0.15)`.
2. Build a fixed `answer` string that echoes the user's question and a generic Socratic prompt addressed to the persona.
3. `yield BrainEvent("state", state_byte=StateByte.SPEAKING)`.
4. For each chunk from `_word_chunks(answer)`: `await asyncio.sleep(0.04)` then `yield BrainEvent("text", payload=chunk)` — this paces text tokens so the UI shows the typing/STATE animation exactly like the real brain.
5. `yield BrainEvent("text_end")` then `yield BrainEvent("state", state_byte=StateByte.IDLE)`.

**`_word_chunks(text, size=3)`** — [web_simulator.py:59-67](Smart-Tutor-Lamp-backend/app/providers/web_simulator.py#L59). Splits on spaces and re‑groups into 3‑word chunks, re‑appending a trailing space to all but the last chunk.

### 4.5 `frontend_manager.py` — the backend gateway

The router that mounts every simulator endpoint under `/api/frontend` ([frontend_manager.py:75](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L75)). It imports both brains: `from app.providers import gemini_brain, web_simulator` and `from app.providers.web_simulator import BrainEvent` — [frontend_manager.py:53-55](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L53). Relevant pieces:

- **`POST /simulate`** ([frontend_manager.py:195-636](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L195)) — the legacy tiered Gemini dispatch (dedup, image enhancement, pre‑router, nudge/dispute/focus/bleed/reveal guards, two‑tier escalation, fire‑and‑forget persist via `_persist_simulation` tagged `source="simulation"`).
- **`GET /models`** ([frontend_manager.py:900-919](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L900)) — the catalog; each model flagged `available` only when its provider key is configured.
- **`POST /solve`** ([frontend_manager.py:1464-…](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1464)) — the page's primary path: reads inputs (`_read_solve_inputs`), dedups + enhances images, runs AUTO (tiered) or a direct model via `generate_solution()`, instruments a `TurnTracer(source="simulator")`, persists `source="simulation", channel="web"`.
- **WS `/ws`** ([frontend_manager.py:1920-1996](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1920)) — verifies the Clerk token from `?token=`, sends an initial `STATE=IDLE`, loops over binary frames, and `_build_stream()` ([frontend_manager.py:1937-1940](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1937)) chooses `gemini_brain.respond(...)` when `gemini_brain.available()`, else **`web_simulator.respond(...)`**.
- **`_drive_turn(ws, event_stream)`** ([frontend_manager.py:2030-2081](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2030)) — consumes `BrainEvent`s, emits `STATE`/`TEXT_OUT` frames, sentence‑buffers text and hands each complete sentence to Piper TTS (`_speak_sentence`) for `AUDIO_OUT` frames, and on error emits `STATE=ERROR` + a `TFT_TEXT` apology.

> **Update (2026-07-06):** the brain behind `/simulate` + `/solve` (`gemini_brain._system_prompt`, shared by the one‑shot `simulate*()` AND the streamed `respond()`) was retuned since this doc was written — see doc 13 for the full change record:
>
> - **Objective questions → direct verdict** (dc9a936, 2026-06-19): when the question is MCQ / multiple‑select / true‑false / fill‑in‑the‑blank and the student asks whether THEIR chosen answer is right, the `check` template now verifies and answers DIRECTLY — correct → say so plainly; wrong → the correct answer + a one‑line why — instead of a Socratic nudge. A chosen option is a committed answer, not a fishing guess; open‑ended / multi‑step problems keep the nudge flow ([gemini_brain.py:129-136](Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L129)).
> - **Recheck‑confirm, no flip‑flop** (b235d4e / 74c3e2f, 2026-06-18): a correct answer is confirmed plainly and the turn STOPS (no manufactured nudge), and a REPEAT recheck ("are you sure?") must give the SAME verdict instead of re‑deriving and inventing a new objection each time.
> - **Open‑start nudges** (6cc7423 / c44f5cb, 2026-06-18): an open‑ended request with no prior progress starts at the genuine FIRST step (problem type + strategy), never a mid‑solution equation handed over as "solve this"; and whenever a final answer is stated on an MCQ, it must name the option, letter + value.
> - **Guardrails** (4d79344 / 1ed9d99, 2026-07-01): `build_system_prompt` now prepends the shared child‑safety / scope / prompt‑injection `GUARDRAILS` block ([_guardrails.py](Smart-Tutor-Lamp-backend/app/prompts/_guardrails.py)), gated by `SAFETY_GUARD_ENABLED` (default `True`) — every one‑shot web solve carries the boundary; the streamed WS `respond()` primes with the bare `_system_prompt` only.
> - **NOT on the web path:** the code‑enforced output validator + input guard from the same pass were wired into `_solve_auto` by 4d79344 and removed again by 1ed9d99 the same day — the validator, math verifier and MCQ option‑match (`MATH_VERIFY_ENABLED`, default flipped to `True` on 2026-07-06) run on the LAMP path only, and the web `SimResponse` carries **no** hidden verifier fields (those live in the lamp's `LlmReply`). The web usage dict did gain `cached_tokens` (implicit‑cache hit tokens) on 2026-07-06 ([gemini_brain.py:766](Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L766)).

---

## 5. Algorithms, math, thresholds & constants

### 5.1 Mic downsample to 16 kHz int16 (`downsampleToInt16`)

[useSimulatorCapture.ts:163-188](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L163). The browser's `AudioContext.sampleRate` is hardware‑dependent (commonly 44.1 kHz or 48 kHz); the lamp/backend want **16 kHz mono int16**.

- **Clamp/scale:** each float sample `s ∈ [-1, 1]` is clamped then scaled asymmetrically — negatives `× 0x8000` (32768), positives `× 0x7fff` (32767):
  ```
  c = max(-1, min(1, s));  out = c < 0 ? c*0x8000 : c*0x7fff
  ```
  (Asymmetric because int16 range is `[-32768, 32767]`.)
- **No upsampling:** if `dstRate >= srcRate`, samples are clamped 1:1 (no interpolation) — defensive, since browsers practically always run ≥ 16 kHz.
- **Box‑average decimation:** otherwise `ratio = srcRate / dstRate`, output length `floor(input.length / ratio)`. Each output sample is the **mean** of input samples in `[floor(i*ratio), floor((i+1)*ratio))` — a simple anti‑alias box filter, then clamped. Empty windows produce `0`.

### 5.2 WAV container (`encodeWav`)

[useSimulatorCapture.ts:190-212](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L190). Allocates `44 + samples.length*2` bytes, writes the canonical little‑endian PCM header (`fmt ` chunk size `16`, format `1`=PCM, channels `1`, sampleRate, byteRate `sampleRate*2`, blockAlign `2`, bitsPerSample `16`), then the int16 sample payload. Output `Blob` MIME `audio/wav` — directly accepted by Gemini and persisted as‑is by the backend ([blobs.py:67](Smart-Tutor-Lamp-backend/app/storage/blobs.py#L67)).

### 5.3 Frame signature & sharpness (`frameStats`)

[page.tsx:90-121](Smart-Tutor-frontend/app/simulator/page.tsx#L90). Used to skip near‑duplicate and blurry frames during hands‑free capture, entirely in‑browser at `160×160`:

- **Downscale & greyscale:** draw the video into a `160×160` canvas; per pixel compute luminance with the standard ITU‑R BT.601 weights:
  ```
  gray = 0.299*R + 0.587*G + 0.114*B
  ```
  → a `Float32Array(160*160 = 25600)`.
- **Sharpness via Laplacian variance:** for each interior pixel apply the 4‑neighbour Laplacian kernel
  ```
  lap = 4*g[i] − g[left] − g[right] − g[up] − g[down]
  ```
  Accumulate `Σlap` and `Σlap²` over `n` interior pixels, then **variance** `sharp = Σlap²/n − (Σlap/n)²`. Blurry frames carry little high‑frequency energy → low variance.

### 5.4 New‑page detection (`meanAbsDiff`)

[page.tsx:123-128](Smart-Tutor-frontend/app/simulator/page.tsx#L123). Mean absolute per‑pixel grey difference between two `25600`‑element signatures: `Σ|a[i]−b[i]| / a.length`. Returns `Infinity` when there's no prior frame, so the **first** auto‑capture always passes the "different page" gate.

### 5.5 Hands‑free auto multi‑capture gate (`autoTick`)

[page.tsx:318-338](Smart-Tutor-frontend/app/simulator/page.tsx#L318). While the mic is held, on each tick:

1. If `pendingImages.length >= MAX_IMAGES (5)` → stop the timer.
2. Compute `frameStats`. If none yet, return.
3. If **not** the forced first shot:
   - reject if `sharp < SHARPNESS_MIN (12)` (mid‑flip blur);
   - reject if `meanAbsDiff(gray, lastSig) < FRAME_DIFF_THRESHOLD (9)` (same page).
4. Snapshot the JPEG, push to `pendingImages`, store `gray` as the new `lastSig`, update the on‑screen counter, and stop if the cap is reached.

The cadence is `AUTO_CAPTURE_INTERVAL_MS = 1400` ms ([page.tsx:354](Smart-Tutor-frontend/app/simulator/page.tsx#L354)). Net effect: a student can flip question + working pages and collect up to 5 distinct, sharp shots without tapping the shutter.

### 5.6 KaTeX delimiter handling (`MathRichText` / `stripMathDelims`)

[page.tsx:845-886](Smart-Tutor-frontend/app/simulator/page.tsx#L845). Because the LLM sometimes embeds math *inside* the `text` channel or wraps bare `latex` in delimiters, `MathRichText` scans with a stateful regex covering `$$…$$`, `\[…\]`, `\(…\)`, and `$…$`, rendering block vs inline math accordingly and **falling back to the raw source on parse error** so nothing is lost. `stripMathDelims` removes one matching outer delimiter pair before `BlockMath`.

### 5.7 Deterministic brain pacing (`web_simulator.respond` / `_word_chunks`)

§4.4. The sleeps (`0.15` s before speaking, `0.04` s per 3‑word chunk) and the `THINKING → SPEAKING → IDLE` `StateByte` sequence reproduce the real brain's streaming cadence so the WS UI's typing/STATE animation looks identical with no LLM.

### 5.8 Sentence boundary for streamed TTS (`_split_sentence`)

[frontend_manager.py:1998-2008](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1998). The WS gateway buffers `TEXT_OUT` tokens and splits on `([.!?])(\s|$)` so each completed sentence is handed to Piper TTS as it forms — first audio lands ~700 ms after end of speech.

---

## 6. Data processing pipeline (inputs → transforms → outputs)

**Push‑to‑talk turn (the page's `/solve` path):**

| Stage | Input | Transform | Output |
|---|---|---|---|
| Capture | live `<video>` + mic | `getUserMedia`, ScriptProcessor PCM | float PCM @ device rate + video frames |
| Auto‑capture | video frames | `frameStats` + `meanAbsDiff` gates (§5.3–5.5) | 0..5 distinct sharp JPEGs (`quality 0.85`) |
| Encode | float PCM | `downsampleToInt16` → `encodeWav` (§5.1–5.2) | 16 kHz mono WAV `Blob` |
| Form build | WAV + JPEGs + text | `buildForm` (`question.wav`, `snap-N.jpg`, `text`) | multipart `FormData` |
| Timing | `startedAt` | `postFormTimed` measures prepare/auth/upload | `client_timeline` JSON + steps |
| Backend solve | multipart | `_read_solve_inputs` (dedup, ≤5 cap, OpenCV enhance) → `generate_solution`/`_solve_auto` → `gemini_brain.simulate_with_usage` | `SimResponse` + usage |
| Persist | result | `TurnTracer(source="simulator")` + fire‑and‑forget `turns` write (`source="simulation"`) | DB rows |
| Render | `SolveOut` | `ScreenDisplay` (KaTeX) + `SpokenResponse` (Web Speech) + `MetaStrip`/`JourneyBreakdown` | spoken + on‑screen answer + telemetry |

**WS turn (the `/ws` path, deterministic fallback):** binary `TEXT_IN`/`AUDIO_END`/`IMAGE_JPEG` frames → `_build_stream` → `web_simulator.respond` (or `gemini_brain.respond`) yielding `BrainEvent`s → `_drive_turn` emits `STATE`/`TEXT_OUT`/`AUDIO_OUT` frames back.

---

## 7. How the simulator maps onto the real lamp

The simulator is deliberately wire‑isomorphic to the lamp wherever it matters, and deliberately *different* where browser realities require it:

| Real lamp | Web simulator | Notes |
|---|---|---|
| OV5640 camera frame (mirrored, `hmirror=1`) | webcam `snapshotJpeg` (not mirrored) | `unmirror=True` is **lamp‑only**; sim uploads keep default `False` — [image_preprocessor.py:142-146](Smart-Tutor-Lamp-backend/app/providers/image_preprocessor.py#L142) |
| Mic → `AUDIO_CHUNK` int16 LE 16 kHz mono | `downsampleToInt16` @ 16 kHz → WAV | same rate; sim ships one WAV instead of streamed chunks |
| Up to 5 images/turn (`MAX_IMAGES_PER_TURN`) | `MAX_IMAGES = 5` | constants kept in lockstep with DB CHECK — [page.tsx:66-71](Smart-Tutor-frontend/app/simulator/page.tsx#L66) |
| TTS `AUDIO_OUT` 24 kHz int16 PCM → speaker | Web Speech API (page) / Piper `AUDIO_OUT` (WS) | sim's page uses the browser voice; the lamp uses Piper/Gemini — [page.tsx:817-819](Smart-Tutor-frontend/app/simulator/page.tsx#L817) |
| TFT screen (`TFT_FRAME`/`TFT_TEXT`) | KaTeX `ScreenDisplay` | "the lamp's TFT view" — [page.tsx:914](Smart-Tutor-frontend/app/simulator/page.tsx#L914) |
| Binary frame protocol over WS | identical protocol on `/ws` (+ web‑only `TEXT_IN/OUT` 0x50‑0x52) | a real lamp silently drops the web‑only types — [protocol.py:79-86](Smart-Tutor-Lamp-backend/app/protocol.py#L79) |
| `STATE` byte animation | same `StateByte` enum via `BrainEvent` | THINKING/SPEAKING/IDLE reproduced by `web_simulator.respond` |
| Tiered escalation in the lamp orchestrator | AUTO mode (`model=auto`) with per‑step panel | same plan, surfaced to the user — [page.tsx:1142](Smart-Tutor-frontend/app/simulator/page.tsx#L1142) |

> **Not the same thing:** `dummy_client.py` ([dummy_client.py:2](Smart-Tutor-Lamp-backend/dummy_client.py#L2)) is a *separate Python* "full lamp simulator" that drives the protocol from the command line (simulating wake word, streaming a built‑in JPEG, a `CANCEL` on Select, etc.). The **web** simulator is the browser surface documented here. Both exist so the brain can be exercised hardware‑free; this doc is about the web one.

---

## 8. Configuration, environment variables & constants

| Setting / constant | Where | Default | Effect on the simulator |
|---|---|---|---|
| `GEMINI_API_KEY` | env | unset | When unset, `gemini_brain.available()` is false and `/ws` falls back to `web_simulator.respond`; `/solve` models show `not_configured` |
| `FRONTEND_TTS_PROVIDER` | [config.py:82](Smart-Tutor-Lamp-backend/app/config.py#L82) | `"piper"` | The WS bench's voice. Type **excludes `"gemini"`** so the browser surface can never spend Gemini audio tokens; `"none"` silences the WS voice only (the page still speaks via Web Speech) |
| `BRAIN_AUDIO_SAMPLE_RATE` | [config.py:166](Smart-Tutor-Lamp-backend/app/config.py#L166) | `16000` | Rate used to wrap streamed WS PCM into WAV; matches the page's `SAMPLE_RATE` |
| `SOLVE_TIMEOUT_S` | [config.py:178](Smart-Tutor-Lamp-backend/app/config.py#L178) | `30.0` (comment cites 85 s tuning) | Per‑model wall‑clock cap for `/solve` + AUTO; on expiry the result is `status="timeout"` |
| `TTS_MAX_INPUT_CHARS` | [config.py:134](Smart-Tutor-Lamp-backend/app/config.py#L134) | `800` | Caps chars sent to TTS (defense in depth, applies to the WS Piper path too) |
| `ENABLE_IMAGE_ENHANCEMENT` | config | — | When on, simulator uploads are OpenCV/PIL‑cleaned at `max_dim=2048` before the LLM |
| `SAFETY_GUARD_ENABLED` | [config.py:946](Smart-Tutor-Lamp-backend/app/config.py#L946) | `True` | Prepends the shared child‑safety/scope/injection `GUARDRAILS` block to the web brain's one‑shot system prompt (added 2026-07-01 — see doc 13) |
| `MAX_IMAGES` | [page.tsx:71](Smart-Tutor-frontend/app/simulator/page.tsx#L71) | `5` | UI cap; must equal backend `MAX_IMAGES_PER_TURN` + DB CHECK |
| `MAX_IMAGE_BYTES` | [page.tsx:76](Smart-Tutor-frontend/app/simulator/page.tsx#L76) | `8 MB` | Per‑file early reject (backend hard‑drops > 256 KB after enhancement) |
| `AUTO_CAPTURE_INTERVAL_MS` / `SIG_SIZE` / `FRAME_DIFF_THRESHOLD` / `SHARPNESS_MIN` | [page.tsx:82-85](Smart-Tutor-frontend/app/simulator/page.tsx#L82) | `1400 / 160 / 9 / 12` | Hands‑free auto‑capture cadence + gates (§5) |
| `localStorage["lumos.autospeak"]` | [page.tsx:161-171](Smart-Tutor-frontend/app/simulator/page.tsx#L161) | `"1"` (ON) | Persisted auto‑speak preference |
| `snapshotJpeg` quality | [useSimulatorCapture.ts:72](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L72) | `0.85` | JPEG encode quality |
| Route protection | [middleware.ts:14](Smart-Tutor-frontend/middleware.ts#L14) | — | `/simulator(.*)` requires a signed‑in Clerk session |
| Rate limits | [frontend_manager.py:1465](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1465) | `30/minute` on `/solve`; `120/minute` on `/models` | slowapi limiter |

---

## 9. Edge cases, error handling, timeouts, fallbacks

**Capture (`useSimulatorCapture.ts`):**
- Camera denied vs unavailable: `NotAllowedError`/`SecurityError` → `state="denied"`; any other video error → silent retry **mic‑only** (`hasVideo=false`) — [useSimulatorCapture.ts:46-53](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L46).
- `snapshotJpeg` returns `null` if no video / zero width; `stopRecording` returns `null` if zero samples captured.
- `webkitAudioContext` fallback for Safari — [useSimulatorCapture.ts:89-90](Smart-Tutor-frontend/lib/useSimulatorCapture.ts#L89).

**Page (`page.tsx`):**
- **Zero‑image safety net:** if auto‑capture kept nothing (all dupes/blurry) and the queue is empty, `endTalk` grabs one final frame so a turn never sends zero images — [page.tsx:370-373](Smart-Tutor-frontend/app/simulator/page.tsx#L370).
- **Nothing captured:** `send` early‑returns with an error if there's no audio, no images, and no text — [page.tsx:257-260](Smart-Tutor-frontend/app/simulator/page.tsx#L257).
- **Backend error mapping:** `EMPTY_INPUT` → "Nothing captured", `BRAIN_BUSY` → "AI is busy", `Failed to fetch` → "Couldn't reach the backend. Is it running?" — [page.tsx:285-296](Smart-Tutor-frontend/app/simulator/page.tsx#L285).
- **Long waits:** `ThinkingCard` escalates copy at 8 s / 25 s / 45 s to reassure the user the page isn't frozen (matches `SOLVE_TIMEOUT_S` headroom) — [page.tsx:1197-1231](Smart-Tutor-frontend/app/simulator/page.tsx#L1197).
- **Object‑URL hygiene:** previews are revoked on remove/clear and on unmount to avoid memory leaks — [page.tsx:183-189](Smart-Tutor-frontend/app/simulator/page.tsx#L183).
- **Feedback is best‑effort:** `FeedbackBar.submit` swallows errors and never blocks the UI — [page.tsx:1345-1348](Smart-Tutor-frontend/app/simulator/page.tsx#L1345).
- **KaTeX parse failures:** both `ScreenDisplay` and `MathRichText` render the raw source via `renderError` rather than crashing — [page.tsx:864-865](Smart-Tutor-frontend/app/simulator/page.tsx#L864).
- **No Web Speech support:** `SpokenResponse` hides Play/Stop and shows a "doesn't support speech synthesis" note — [page.tsx:817-819](Smart-Tutor-frontend/app/simulator/page.tsx#L817).

**Backend (`/ws`, `web_simulator.py`):**
- **No Gemini key:** `_build_stream` falls back to `web_simulator.respond` so framing/auth/TTS still run — [frontend_manager.py:1937-1940](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1937).
- **Bad WS auth:** `verify_ws_token` failure → `close(code=4401)` — [frontend_manager.py:1922-1926](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1922).
- **Malformed frame:** `decode` `ValueError` → `close(code=1002, reason="bad frame")` — [frontend_manager.py:1949-1954](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1949).
- **CANCEL frame:** cancels the in‑flight turn, clears audio buffers, returns to `IDLE` — [frontend_manager.py:1956-1961](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1956).
- **New input mid‑turn:** any new `TEXT_IN`/`AUDIO_END` cancels the prior in‑flight task first.
- **Turn failure in `_drive_turn`:** emits `STATE=ERROR` + `TFT_TEXT` apology + `STATE=IDLE`; on cancellation it still closes any open audio stream with `AUDIO_OUT_END` — [frontend_manager.py:2062-2081](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2062).
- **TTS errors:** `_speak_sentence` swallows `TTSError` (text already went out) — [frontend_manager.py:2097-2098](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L2097).
- **Disconnect cleanup:** in‑flight task cancelled with a 3 s `wait_for` on shutdown — [frontend_manager.py:1990-1995](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1990).

**Backend (`/solve`):**
- **Empty input:** `422 {code:"EMPTY_INPUT"}` — [frontend_manager.py:1491-1496](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1491).
- **AUTO timeout:** `asyncio.wait_for(..., SOLVE_TIMEOUT_S)` → synthetic `status="timeout"` result — [frontend_manager.py:1528-1541](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1528).
- **Provider overload (busy):** `is_busy_error` → `status="busy"` with a friendly speech string — [frontend_manager.py:1446-1455](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L1446).
- **Image dedup:** `_dedupe_blobs` drops duplicate uploads (prevents the double‑enhance/double‑bill bug) before the ≤5 cap.

---

## 10. Integration points (cross-references)

**The simulator (page) calls:**
- `lib/useSimulatorCapture.ts` (capture) and `lib/models.ts` (`useModels`, `useSolve`, `useFeedback`).
- Backend `POST /api/frontend/solve`, `POST /api/frontend/solve/compare`, `GET /api/frontend/models`, `POST /api/frontend/feedback`.
- Browser **Web Speech API** for the spoken answer; **KaTeX** for the screen.

**The `/ws` gateway calls:**
- `gemini_brain.respond()` (real brain) **or** `web_simulator.respond()` (fallback) via `_build_stream`.
- `get_tts_provider(FRONTEND_TTS_PROVIDER)` → Piper for `AUDIO_OUT`.
- `app/protocol.py` `encode`/`decode`, `FrameType`, `StateByte`.

**What calls the simulator's code:**
- `web_simulator.BrainEvent` is imported by both `frontend_manager.py` and `gemini_brain.py` ([gemini_brain.py:25](Smart-Tutor-Lamp-backend/app/providers/gemini_brain.py#L25)) as the shared streaming contract.
- `JourneyBreakdown` consumes the same `timeline` shape for *both* the simulator (live) and the admin Turns log (persisted) — [JourneyBreakdown.tsx:3-7](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L3).
- `TraceView` renders a `SOURCE: LAMP / SIMULATOR` badge from `source !== "simulator"` — [TraceView.tsx:5,99-109](Smart-Tutor-frontend/components/app/TraceView.tsx#L99).
- `AdminView` / `AnalyticsView` reference the simulator as the way to generate model runs / questions — [AdminView.tsx:529](Smart-Tutor-frontend/components/app/AdminView.tsx#L529), [AnalyticsView.tsx:203](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L203).
- `AppHeader` exposes the `/simulator` nav link; `Hero`/`CTA` landing components link to it.

**Persistence & DB:**
- `/solve` + `/simulate` turns are written fire‑and‑forget to the **same `turns` table** tagged `extra.source="simulation"` with a synthetic `websim-<user>` session, so analytics/L3 subject profile cover both surfaces — [turns.py:183](Smart-Tutor-Lamp-backend/app/storage/turns.py#L183), [frontend_manager.py:864-866](Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py#L864).
- `turn_traces` rows are written with `source="simulator"` for the admin visual‑pipeline audit — [turn_trace.py:7,146](Smart-Tutor-Lamp-backend/app/services/turn_trace.py#L146).
- `db/models.py` documents the `source` discriminator: `"lamp" (WebSocket frame protocol) | "simulator" (HTTP /solve payload)` — [models.py:253,270](Smart-Tutor-Lamp-backend/app/db/models.py#L270).

**Firmware:**
- The lamp speaks the identical binary protocol in [protocol.py](Smart-Tutor-Lamp-backend/app/protocol.py); the web simulator adds only the web‑only superset frames `TEXT_IN/TEXT_OUT/TEXT_OUT_END` (0x50‑0x52) which a real lamp silently drops.

---

## 11. Diagrams

### 11.1 `/solve` turn — flowchart (the page's primary path)

```mermaid
flowchart TD
    A[User holds the talk button] --> B[useSimulatorCapture.startRecording<br/>ScriptProcessor PCM]
    A --> C[Auto-capture timer every 1400 ms]
    C --> D{frameStats:<br/>sharp >= 12 AND<br/>meanAbsDiff >= 9?}
    D -- no --> C
    D -- yes --> E[snapshotJpeg quality 0.85<br/>push to pendingImages, max 5]
    E --> C
    A2[User releases] --> F[endTalk: startedAt = now]
    F --> G[stopRecording: downsampleToInt16<br/>-> encodeWav 16 kHz mono]
    G --> H{0 images kept?}
    H -- yes --> I[Safety net: snap 1 final frame]
    H -- no --> J
    I --> J[send audio + images]
    J --> K[buildForm: question.wav + snap-N.jpg + text]
    K --> L[postFormTimed: measure prepare/auth/upload<br/>attach client_timeline + Clerk Bearer]
    L --> M{compareMode?}
    M -- single --> N[POST /api/frontend/solve model=X]
    M -- compare --> O[POST /api/frontend/solve/compare models=...]
    N --> P[generate_solution / _solve_auto<br/>-> gemini_brain.simulate_with_usage]
    O --> P
    P --> Q[Persist turns source=simulation<br/>TurnTracer source=simulator]
    P --> R[SolveOut: response.speech/display + meta]
    R --> S[ScreenDisplay: KaTeX 'TFT']
    R --> T[SpokenResponse: Web Speech API]
    R --> U[MetaStrip + JourneyBreakdown: latency/tokens/cost]
```

### 11.2 `/ws` turn with deterministic fallback — sequence

```mermaid
sequenceDiagram
    participant B as Browser WS client
    participant G as brain_ws (/ws)
    participant S as _build_stream
    participant W as web_simulator.respond
    participant D as _drive_turn
    participant P as Piper TTS

    B->>G: WS connect ?token=<clerk>
    G->>G: verify_ws_token (else close 4401)
    G-->>B: STATE = IDLE
    B->>G: TEXT_IN "differentiate sin(x^2)"
    G->>S: _build_stream(user_text, ...)
    alt gemini_brain.available()
        S-->>D: gemini_brain.respond() events
    else no GEMINI_API_KEY
        S->>W: web_simulator.respond(user_text, profile)
        W-->>D: BrainEvent state=THINKING
        W-->>D: BrainEvent state=SPEAKING
        loop 3-word chunks (sleep 0.04s)
            W-->>D: BrainEvent text=chunk
        end
        W-->>D: BrainEvent text_end + state=IDLE
    end
    D-->>B: STATE THINKING / SPEAKING
    loop each text token
        D-->>B: TEXT_OUT chunk
        D->>D: buffer + _split_sentence
        D->>P: synthesize(sentence)
        P-->>D: PCM chunks
        D-->>B: AUDIO_OUT frames
    end
    D-->>B: TEXT_OUT_END + AUDIO_OUT_END + STATE IDLE
```

---

*This document was generated by reading the actual source: `lib/useSimulatorCapture.ts`, `app/simulator/page.tsx`, `lib/models.ts` (frontend); `app/providers/web_simulator.py`, `app/routes/frontend_manager.py`, `app/protocol.py`, `app/config.py` (backend); plus every `simulat*` touchpoint across both repos.*

_Re-verified against backend db470f6 on 2026-07-06._
