# Frontend — Components (App & Landing)

This is the definitive reference for the React component layer of the **Lumos / Smart Tutor Lamp** Next.js frontend, covering the two component families under `components/`: the **app/dashboard components** (`components/app/*`) that render the authenticated product surface (admin console, per-user analytics, header, QR pairing, confirm dialogs, trace/journey storyboards, hand-built SVG charts, and a boot-timing probe) and the **landing-page components** (`components/landing/*`) that render the marketing site (nav, hero, feature/exam grids, CTA, footer, an SVG lamp, and reusable Framer Motion primitives). Every behavior, prop, algorithm, threshold, and integration point documented below is taken directly from the source files read for this report.

These are all **client components** ("use client") except the two pure-presentational ones (`Footer.tsx`, `Lamp.tsx`), and they consume data exclusively through the typed React-Query hooks in `lib/*` (which attach Clerk auth and hit the backend's `/api/frontend/*` surface). The components never call `fetch` directly except `QrScanner` (camera) and `BootDiagnostics` (browser Performance APIs); the AdminView OTA uploader is a special case — it does a manual token-authenticated `fetch` to stream a raw `.bin` body (via `useUploadOtaRelease()` in `lib/admin.ts`), which `useApi().post` can't express.

---

## Table of Contents

1. [Purpose & Responsibility](#1-purpose--responsibility)
2. [Architecture Overview](#2-architecture-overview)
3. [Shared Data Structures (wire types)](#3-shared-data-structures-wire-types)
4. [App / Dashboard Components](#4-app--dashboard-components)
   - [4.1 AppHeader.tsx](#41-appheadertsx)
   - [4.2 AnalyticsCards.tsx](#42-analyticscardstsx)
   - [4.3 AnalyticsView.tsx](#43-analyticsviewtsx)
   - [4.4 AdminView.tsx](#44-adminviewtsx)
   - [4.5 charts.tsx](#45-chartstsx)
   - [4.6 JourneyBreakdown.tsx](#46-journeybreakdowntsx)
   - [4.7 TraceView.tsx](#47-traceviewtsx)
   - [4.8 QrScanner.tsx](#48-qrscannertsx)
   - [4.9 ConfirmDialog.tsx](#49-confirmdialogtsx)
   - [4.10 ErrorPanel.tsx](#410-errorpaneltsx)
   - [4.11 BootDiagnostics.tsx](#411-bootdiagnosticstsx)
   - [4.12 Pilot & UX components (SurveyView, PersonalizationView, PersonalizeCard, ReportProblem, PageSkeleton)](#412-pilot--ux-components-added-2026-07-03)
5. [Landing-Page Components](#5-landing-page-components)
   - [5.1 motion.tsx](#51-motiontsx)
   - [5.2 Lamp.tsx](#52-lamptsx)
   - [5.3 Nav.tsx](#53-navtsx)
   - [5.4 Hero.tsx](#54-herotsx)
   - [5.5 Features.tsx](#55-featurestsx)
   - [5.6 Exams.tsx](#56-examstsx)
   - [5.7 CTA.tsx](#57-ctatsx)
   - [5.8 Footer.tsx](#58-footertsx)
6. [Algorithms Reference](#6-algorithms-reference)
7. [Configuration, Constants & Environment](#7-configuration-constants--environment)
8. [Edge Cases, Errors, Timeouts & Fallbacks](#8-edge-cases-errors-timeouts--fallbacks)
9. [Integration Points & Cross-References](#9-integration-points--cross-references)
10. [Mermaid Diagrams](#10-mermaid-diagrams)

---

## 1. Purpose & Responsibility

The `components/` directory holds the **reusable view layer** of the Lumos frontend. Page files under `app/*` are thin: they handle routing, server-side auth/onboarding gating, and the page shell, then mount one or more of these components for the actual UI. There are two clearly separated families:

- **`components/app/*` — the authenticated product surface.** These render the signed-in dashboard experience: a top nav with admin gating ([AppHeader](#41-appheadertsx)), per-user activity cards ([AnalyticsCards](#42-analyticscardstsx)), the full analytics page body ([AnalyticsView](#43-analyticsviewtsx)), the system-wide admin console with tabs and a multi-LLM comparison bench ([AdminView](#44-adminviewtsx)), a no-dependency SVG charting kit ([charts](#45-chartstsx)), two "where did the time go" storyboards ([JourneyBreakdown](#46-journeybreakdowntsx) and [TraceView](#47-traceviewtsx)), an in-browser QR scanner for lamp pairing ([QrScanner](#48-qrscannertsx)), a generic accessible confirm modal ([ConfirmDialog](#49-confirmdialogtsx)), a shared pairing error surface ([ErrorPanel](#410-errorpaneltsx)), and a passive page-load/runtime timing probe ([BootDiagnostics](#411-bootdiagnosticstsx)).

- **`components/landing/*` — the marketing site.** Pure presentation with motion: the sticky nav ([Nav](#53-navtsx)), the hero with a floating SVG lamp and drifting "doubt" formulas ([Hero](#54-herotsx)), the three-up feature grid ([Features](#55-featurestsx)), the four-up exam grid ([Exams](#56-examstsx)), the closing call-to-action ([CTA](#57-ctatsx)), the footer ([Footer](#58-footertsx)), the SVG lamp illustration ([Lamp](#52-lamptsx)), and the shared Framer-Motion reveal/float/stagger primitives ([motion](#51-motiontsx)).

The brand throughout is **"Lumos"** — the smart tutor lamp. The visual language is a dark "glass" aesthetic with amber/cyan/violet/rose glow accents driven by CSS custom properties (`--amber`, `--cyan`, `--violet`, `--rose`, `--edge`, `--muted`, `--faint`, `--paper`) and utility classes (`glass`, `glass-lift`, `tile`, `btn-primary`, `btn-cyan`, `btn-ghost`, `glow-text`, `label`, `rise`) defined in `globals.css` (referenced but outside this scope).

---

## 2. Architecture Overview

### Component graph (who renders whom)

```
app/page.tsx (Home, server)         app/layout.tsx → app/providers.tsx
├─ landing/Nav                      └─ app/BootDiagnostics (mounted once, app-wide)
├─ landing/Hero
│   ├─ landing/Lamp                 app/dashboard/page.tsx
│   └─ landing/motion (Float,       ├─ app/AppHeader → lib/profile useMe()
│        stagger, riseItem)         └─ app/AnalyticsCards → lib/profile useAnalytics()
├─ landing/Features
│   └─ landing/motion (Reveal,Float) app/analytics/page.tsx
├─ landing/Exams                    ├─ app/AppHeader
│   └─ landing/motion (Reveal,Float) └─ app/AnalyticsView → lib/profile useAnalyticsDetail()
├─ landing/CTA                          └─ app/charts (AreaTimeline, Donut, BarRows, SegmentedBar)
│   ├─ landing/Lamp
│   └─ landing/motion (Reveal,Float) app/admin/page.tsx
└─ landing/Footer                   ├─ app/AppHeader
                                    └─ app/AdminView → lib/admin (~25 hooks: admin/pilot/insights/ota)
app/connect/page.tsx                    ├─ app/charts (all 6 exports)
├─ app/AppHeader                        ├─ app/ConfirmDialog
└─ app/QrScanner → lib/pairing-code     ├─ app/JourneyBreakdown
                                        └─ app/TraceView → lib/admin useTurnTrace()
app/devices/page.tsx
├─ app/AppHeader                    app/simulator/page.tsx
└─ app/ConfirmDialog (Unlink)       ├─ app/AppHeader
                                    └─ app/JourneyBreakdown (live path)
app/pair/[code]/page.tsx
└─ app/ErrorPanel → lib/devices FriendlyError
```

### Cross-cutting design rules observed in the code

- **Data via hooks only.** App components import hooks from `lib/admin.ts`, `lib/profile.ts`, `lib/devices.ts` and never embed URLs. All hooks are TanStack Query (`@tanstack/react-query`) `useQuery`/`useMutation`, with auth attached by `useApi()` in `lib/api.ts`.
- **Graceful degradation.** Every data-driven view distinguishes `isLoading` (skeleton), `isError` (quiet inline notice, never a crash), and success. 403 is treated specially in admin (access notice); 404 specially in traces (predates tracing).
- **Motion is opt-out.** `landing/motion.tsx` honors `useReducedMotion()` — `Reveal` skips its initial offset and `Float` becomes a static `<div>`.
- **SVG-only charts.** `charts.tsx` has no external chart dependency; every visual is hand-built SVG/`framer-motion`, responsive via `viewBox`.
- **`memo()` for hot lists.** `TurnRow` (AdminView) and `StepRow` (JourneyBreakdown) are memoized to keep large lists cheap, relying on TanStack Query's structural sharing for stable object identity.

---

## 3. Shared Data Structures (wire types)

These interfaces are defined in `lib/*` and consumed by the components. They mirror the backend `app/schemas/*.py`.

### From `lib/profile.ts`

- **`Me`** [profile.ts:13](Smart-Tutor-frontend/lib/profile.ts#L13): `{ user_id, email|null, has_profile, onboarding_complete, is_admin }`. Drives the admin nav gate in `AppHeader`.
- **`Analytics`** [profile.ts:49](Smart-Tutor-frontend/lib/profile.ts#L49): `{ device_count, online_devices, total_turns, turns_last_7d, sessions_count, last_active_at|null, subject_mix: Record<string,number>, devices: DeviceSummary[] }`. Drives `AnalyticsCards`.
- **`AnalyticsDetail`** [profile.ts:129](Smart-Tutor-frontend/lib/profile.ts#L129): the rich per-user rollup for `AnalyticsView` — `range_days, turns, sessions, devices, online_devices, turns_last_7d, avg_total_ms, p50_ms, p95_ms, avg_confidence, total_cost_usd, escalated_pct, last_active_at, daily: DailyPoint[], subject_mix, difficulty_mix, query_type_mix, status_mix, recent: RecentTurn[]`.
- **`DailyPoint`** [profile.ts:112](Smart-Tutor-frontend/lib/profile.ts#L112): `{ label: "YYYY-MM-DD", turns, avg_ms }`.
- **`RecentTurn`** [profile.ts:118](Smart-Tutor-frontend/lib/profile.ts#L118): `{ asked_at, subject|null, difficulty|null, query_type|null, question|null, answer, total_ms|null, status }`.

### From `lib/admin.ts`

- **`AdminOverview`** [admin.ts:43](Smart-Tutor-frontend/lib/admin.ts#L43): `{ range_days, health: HealthSnapshot, cost: CostSummary, daily: AdminDailyPoint[], subject_mix, difficulty_mix, query_type_mix, status_mix, tier_mix, event_counts }`.
- **`HealthSnapshot`** [admin.ts:14](Smart-Tutor-frontend/lib/admin.ts#L14): `{ users_onboarded, devices_total, devices_paired, devices_revoked, online_devices, pairing_codes_live, sessions_total, turns_total, turns_failed, memories_total, events_total, admins_total }`.
- **`CostSummary`** [admin.ts:29](Smart-Tutor-frontend/lib/admin.ts#L29): `{ total_usd, turns_costed, input_tok, output_tok, thinking_tok }`.
- **`AdminTurnRow`** [admin.ts:96](Smart-Tutor-frontend/lib/admin.ts#L96): one turn in the admin feed, including `timeline: TimelineStep[]|null` and the Claude-fallback fields `fallback?`, `fallback_from?`.
- **`AdminTurnTrace`** [admin.ts:138](Smart-Tutor-frontend/lib/admin.ts#L138): the full pipeline audit for one turn — per-phase latencies, media URLs (`raw_audio_url`, `raw_image_url`, `enhanced_image_url`), transcripts, raw LLM prompt/response, `extracted_ocr_text`, `bounding_box: number[]|null`, `phases: TurnTracePhase[]`, and turn output (`turn_speech`, `turn_display_content`, `turn_latex_equations: string[]`).
- **`TurnTracePhase`** [admin.ts:129](Smart-Tutor-frontend/lib/admin.ts#L129): `{ phase: string, ms: number|null, status: "ok"|"error"|"skipped", detail: string }`.
- **`AdminModels`** [admin.ts:277](Smart-Tutor-frontend/lib/admin.ts#L277): `{ range_days, totals: ModelEvalTotals, models: ModelStatRow[], daily: ModelEvalDailyPoint[], available_models: ModelOption[] }`.
- **`ModelStatRow`** [admin.ts:230](Smart-Tutor-frontend/lib/admin.ts#L230): per-model bench row — `success_rate (0–100)`, `avg_latency_ms`, `avg_cost`, `avg_input_tok`, `avg_output_tok`, `avg_rating (1–5, 0 when none)`, `thumbs_up`, `thumbs_down`, `active`, `provider`, etc.
- **`AdminMedia`** [admin.ts:195](Smart-Tutor-frontend/lib/admin.ts#L195) and **`MediaCleanupResult`** [admin.ts:207](Smart-Tutor-frontend/lib/admin.ts#L207): storage snapshot and per-pass deletion result for the Media card.

### From `lib/models.ts`

- **`TimelineStep`** [models.ts:52](Smart-Tutor-frontend/lib/models.ts#L52): `{ step: string, ms: number, where: "client"|"server" }`. The unit consumed by `JourneyBreakdown`.

### From `lib/devices.ts`

- **`FriendlyError`** [devices.ts:41](Smart-Tutor-frontend/lib/devices.ts#L41): `{ code: ErrorCode, message: string, action?: string }`. Consumed by `ErrorPanel`. `ErrorCode` is one of `CODE_NOT_FOUND | CODE_EXPIRED | ALREADY_PAIRED | USER_AUTH_FAIL | NOT_OWNER | NOT_FOUND | RATE_LIMIT | NETWORK | UNKNOWN` [devices.ts:30](Smart-Tutor-frontend/lib/devices.ts#L30).

### From `lib/api.ts`

- **`ApiError`** [api.ts:69](Smart-Tutor-frontend/lib/api.ts#L69): `extends Error` with `status: number` and `body: ApiErrorBody`. The app components key behavior off `err instanceof ApiError && err.status === 403` (admin access) and `=== 404` (trace).

### From `lib/log.ts`

- **`BUDGET`** [log.ts:35](Smart-Tutor-frontend/lib/log.ts#L35): latency budgets (ms) used by `BootDiagnostics` — `token: 500, network: 1000, networkSevere: 3000, parse: 50, query: 1500, longTask: 120, route: 800`.

---

## 4. App / Dashboard Components

### 4.1 AppHeader.tsx

**File:** `components/app/AppHeader.tsx` — [AppHeader.tsx:15](Smart-Tutor-frontend/components/app/AppHeader.tsx#L15)

**Purpose.** Sticky top navigation for every authenticated page. Renders the Lumos wordmark, a desktop nav row, an admin-only link, and the Clerk `<UserButton>` avatar menu.

**Props.** `{ active?: string }` — the current route path string used to highlight the matching nav item.

**State / hooks.** `const { data: me } = useMe()` [AppHeader.tsx:19](Smart-Tutor-frontend/components/app/AppHeader.tsx#L19) from `lib/profile.ts`; derives `const isAdmin = !!me?.is_admin` [AppHeader.tsx:20](Smart-Tutor-frontend/components/app/AppHeader.tsx#L20). No local React state.

**What it renders.**
- A `<header>` with `sticky top-0 z-40`, a translucent backdrop-blur background.
- A constant nav array `NAV` [AppHeader.tsx:8](Smart-Tutor-frontend/components/app/AppHeader.tsx#L8): `Dashboard (/dashboard)`, `Analytics (/analytics)`, `Devices (/devices)`, `Simulator (/simulator)`. Each renders a `next/link` `<Link>`; the active item (`active === n.href`) gets an amber underline glow.
- **Admin gate** [AppHeader.tsx:48-61](Smart-Tutor-frontend/components/app/AppHeader.tsx#L48): the `/admin` link with a `ShieldCheck` icon renders **only when `isAdmin`** is true (cyan accent + cyan underline when active). The code comment notes this is "purely cosmetic" because the `/admin` route is also gated server-side; while `me` is loading or for non-admins it stays hidden.
- **Updated 2026-07-03.** The Clerk `<UserButton>` menu now includes a **Personalize** link (`Sparkles` icon → `/personalize`) alongside My lamps / Connect a lamp / Admin console. And the whole component now returns a **fragment** wrapping `<header>` + a globally-mounted `<ReportProblem />` (§4.12.4) — so the fixed bottom-right "Report a problem" widget is present on every page that renders the header, with no per-page wiring.
- A Clerk `<UserButton afterSignOutUrl="/">` whose menu is customized via `UserButton.MenuItems` with quick-nav links (Dashboard, Analytics, My lamps `/devices`, Connect a lamp `/connect`, and conditionally Admin console), and the default `manageAccount` + `signOut` actions reordered to the bottom.

**Used by.** `app/dashboard/page.tsx`, `app/analytics/page.tsx`, `app/admin/page.tsx`, `app/connect/page.tsx`, `app/devices/page.tsx`, `app/simulator/page.tsx` (every authenticated page).

---

### 4.2 AnalyticsCards.tsx

**File:** `components/app/AnalyticsCards.tsx` — [AnalyticsCards.tsx:11](Smart-Tutor-frontend/components/app/AnalyticsCards.tsx#L11)

**Purpose.** The compact "Your activity" summary block on the dashboard home: three stat cards plus a subjects-asked chip row.

**Props.** None.

**State / hooks.** `const { data, isLoading, isError } = useAnalytics()` [AnalyticsCards.tsx:12](Smart-Tutor-frontend/components/app/AnalyticsCards.tsx#L12) — returns the `Analytics` type. No local state.

**Control flow (three branches):**
1. **`isLoading`** [AnalyticsCards.tsx:14](Smart-Tutor-frontend/components/app/AnalyticsCards.tsx#L14) → a glass card with a pulsing cyan dot and "Reading your activity…".
2. **`isError || !data`** [AnalyticsCards.tsx:23](Smart-Tutor-frontend/components/app/AnalyticsCards.tsx#L23) → a quiet "Couldn't reach the Lumos backend…" card (no crash).
3. **Success** → builds `cards` [AnalyticsCards.tsx:32](Smart-Tutor-frontend/components/app/AnalyticsCards.tsx#L32):
   - **Lamps linked** = `data.device_count`, sub `${data.online_devices} online`.
   - **Questions asked** = `data.total_turns`, sub `${data.turns_last_7d} in the last 7 days`.
   - **Sessions** = `data.sessions_count`, sub `last active <localeDate>` or "no activity yet".

**Data processing.** `const subjects = Object.entries(data.subject_mix)` [AnalyticsCards.tsx:55](Smart-Tutor-frontend/components/app/AnalyticsCards.tsx#L55). When non-empty, a "Subjects asked about" card renders one amber chip per `[subject, n]` pair. Cards are staggered with inline `animationDelay: ${i*80}ms` (80 ms per card; the subjects card uses a fixed `240ms`).

**Used by.** `app/dashboard/page.tsx`.

---

### 4.3 AnalyticsView.tsx

**File:** `components/app/AnalyticsView.tsx` — [AnalyticsView.tsx:48](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L48)

**Purpose.** The full client body of the `/analytics` page — a rich per-user rollup rendered as glass cards plus the SVG charts. The server page does the auth/onboarding gating and mounts this.

**Props.** None (top-level `AnalyticsView`). Internal subcomponents take `{ data: AnalyticsDetail }`.

**State / hooks.**
- `const [days, setDays] = useState<7|14|30>(14)` [AnalyticsView.tsx:49](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L49) — the range toggle, default **14**, options from `const RANGES = [7,14,30]` [AnalyticsView.tsx:23](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L23).
- `const { data, isLoading, isError } = useAnalyticsDetail(days)` [AnalyticsView.tsx:50](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L50) — refetches whenever `days` changes (the day value is part of the query key in `lib/profile.ts`).

**What it renders / control flow.**
1. **Header** with title "Your learning analytics" and the 7d/14d/30d amber range toggle.
2. **`isError`** [AnalyticsView.tsx:83](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L83) → quiet inline notice.
3. **`isLoading && !data`** → `<SkeletonGrid />` [AnalyticsView.tsx:279](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L279) (4 stat skeletons + a tall timeline skeleton + two card skeletons).
4. **`data`** → `<StatRow>`, `<TimelineCard>`, `<SubjectsCard>` + (`<DifficultyCard>` + `<QueryTypeCard>`), `<RecentCard>`.

**Subcomponent breakdown:**

- **`StatRow`** [AnalyticsView.tsx:111](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L111) — four motion-animated cards (stagger `delay: i*0.06`):
  - **Questions asked** = `data.turns`, sub `${data.turns_last_7d} in last 7 days`.
  - **Study sessions** = `data.sessions`, sub `${data.devices} lamp(s) linked`.
  - **Median response** = `fmtMs(data.p50_ms)`, sub `p95 ${fmtMs(data.p95_ms)}`.
  - **Avg confidence** = `data.avg_confidence ? Math.round(data.avg_confidence*100)+"%" : "—"`, sub `${data.escalated_pct}% escalated` or "single-pass".
- **`TimelineCard`** [AnalyticsView.tsx:141](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L141) — maps `data.daily` to `{label, value: turns}`, computes `peak = Math.max(0, ...values)`, feeds `<AreaTimeline color="#ffb84d">`.
- **`SubjectsCard`** [AnalyticsView.tsx:156](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L156) — `<Donut data={toSorted(data.subject_mix)}>`.
- **`DifficultyCard`** [AnalyticsView.tsx:168](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L168) — orders `["easy","medium","hard","unknown"]`, filters to present keys, maps to `{label, value, color: DIFFICULTY_COLORS[k]}`, feeds `<SegmentedBar>`.
- **`QueryTypeCard`** [AnalyticsView.tsx:184](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L184) — `<BarRows data={toSorted(data.query_type_mix)} accent="#b9a3ff">`.
- **`RecentCard`** [AnalyticsView.tsx:196](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L196) — feed of `data.recent`; per row shows subject/difficulty chips, truncated question, line-clamped answer, `fmtMs(t.total_ms ?? 0)`, `relTime(t.asked_at)`, and a status pill styled by `STATUS_STYLE` (ok=cyan, cancelled=muted, else rose). Empty state: "No questions yet — ask your lamp or try the simulator." **Updated 2026-07-03:** for `status === "ok"` rows that carry a `turn_id`, the row now renders an inline `<TurnFeedbackControl>` beneath the answer.
- **`TurnFeedbackControl`** (Updated 2026-07-03, pilot F1) — a compact per-answer feedback strip on one real turn: 👍/👎 thumbs, a set of down-vote diagnosis chips shown only when thumbs-down (`wrong`, `too_long`, `didnt_understand`, `wrong_level`, `off_topic`), and a "did you get it?" resolution row (`got_it | still_stuck | explain_differently`). It seeds from the learner's prior verdict (`RecentTurn.feedback`, see `lib/profile.ts`) so re-visits show past answers, and fires `useTurnFeedback()` → `POST /api/frontend/pilot/turn-feedback` on **every** change (best-effort — errors are swallowed so they never disrupt the analytics feed; a transient "Saved" check flashes). Data layer: `lib/pilot.ts`.

**Local helpers / constants.**
- `RANGES = [7,14,30]`; `DIFFICULTY_COLORS` [AnalyticsView.tsx:25](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L25): `easy=#5fe3d2, medium=#ffb84d, hard=#ff9bb0, unknown=#5c5c72`; `STATUS_STYLE` [AnalyticsView.tsx:32](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L32).
- `toSorted(mix)` [AnalyticsView.tsx:37](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L37): `Object.entries → {label,value} → sort desc by value`.
- `fmtMs(ms)` [AnalyticsView.tsx:43](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L43): `<1000`→`{ms}ms`, else `{(ms/1000).toFixed(ms>=10000?0:1)}s`; `0`→`—`.
- `relTime(iso)` [AnalyticsView.tsx:296](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L296): "just now" (<1m), `Xm ago` (<60m), `Xh ago` (<24h), `Xd ago` (<7d), else short locale date. (Note: this 7-day rollover differs from AdminView's 30-day version.)

**Used by.** `app/analytics/page.tsx`.

---

### 4.4 AdminView.tsx

**File:** `components/app/AdminView.tsx` — [AdminView.tsx:116](Smart-Tutor-frontend/components/app/AdminView.tsx#L116)

**Purpose.** The system-wide admin console body. Surfaces every user's profile/devices/sessions/turns/cost/events — plus (2026-07-03) pilot instrumentation, learning insights, and firmware OTA — to an allowlisted admin, reusing the glass + SVG-chart aesthetic. The route is gated server-side (`requireOnboardedAndAdmin`) and the endpoints return 403 to non-admins; a 403 here surfaces as a quiet access notice rather than a crash.

**Props.** None at the top level. Internal tab components take `{ days }` or no props.

> **Updated 2026-07-03.** `AdminView` roughly doubled in size (≈981 → ≈1842 lines, +893). It added three new tabs — **Pilot**, **Insights**, and **OTA** — plus a **PerformanceCard** on the Overview tab and analytics-tag columns in the Turns feed. It now imports ~25 hooks from `lib/admin.ts` (was 8).
>
> **Updated 2026-07-09 → 07-11.** Added an **eleventh tab, "Analytics"** (`Timer` icon, +374 lines, `AnalyticsTab` [AdminView.tsx:1530](Smart-Tutor-frontend/components/app/AdminView.tsx#L1530)) — a range-aware output-generation + total-latency view built on three new `lib/admin.ts` hooks (`useAnalyticsSummary` / `useAnalyticsQuestions` / `useAnalyticsTimeseries`). See its subsection below. Sections reflect the current **11-tab** layout.

**Top-level state.** `const [tab, setTab] = useState<TabKey>("overview")` and `const [days, setDays] = useState(14)` [AdminView.tsx:161-162](Smart-Tutor-frontend/components/app/AdminView.tsx#L161). `TabKey` ∈ `overview | pilot | insights | analytics | models | users | devices | sessions | turns | events | ota`; the `TABS` array [AdminView.tsx:105](Smart-Tutor-frontend/components/app/AdminView.tsx#L105) drives the tab bar with per-tab Lucide icons (Pilot=`FlaskConical`, Insights=`LineChart`, Analytics=`Timer`, OTA=`Radio`). The 7d/14d/30d range toggle (`RANGES = [7,14,30]`) is shown only on the Overview and Models tabs [AdminView.tsx:179](Smart-Tutor-frontend/components/app/AdminView.tsx#L179); the Analytics tab carries its **own** `today | yesterday | 7d | 30d` selector.

**Tab dispatch.** [AdminView.tsx:217-226](Smart-Tutor-frontend/components/app/AdminView.tsx#L217) mounts exactly one tab component for the active `tab`. Because non-active tabs are unmounted, **their hooks don't fire** until selected (lazy fetch).

**Tab-by-tab breakdown:**

#### OverviewTab [AdminView.tsx:186](Smart-Tutor-frontend/components/app/AdminView.tsx#L186)
- Hook: `useAdminOverview(days)` → `AdminOverview`. Branches `isError`→`<ErrorState>`, `isLoading||!data`→`<SkeletonGrid>`, else renders:
  - **`HealthRow`** [AdminView.tsx:384](Smart-Tutor-frontend/components/app/AdminView.tsx#L384): four glass tiles — Users onboarded (sub `N admins`), Lamps (`devices_paired`, sub `online · revoked`), Turns (`turns_total`, sub `turns_failed failed`), Sessions (`sessions_total`, sub `pairing_codes_live live pair codes`).
  - **`TimelineCard`** [AdminView.tsx:414](Smart-Tutor-frontend/components/app/AdminView.tsx#L414): `data.daily` → `<AreaTimeline color="#5fe3d2">`, header shows `peak N/day`.
  - **Subjects** `<Donut data={toSorted(data.subject_mix)}>`.
  - **Difficulty** `<SegmentedBar>` over `["easy","medium","hard","unknown"]` filtered to present keys, colored by `DIFFICULTY_COLORS` [AdminView.tsx:55](Smart-Tutor-frontend/components/app/AdminView.tsx#L55).
  - **Tier mix** `<BarRows accent="#b9a3ff">`, **Question types** `<BarRows accent="#5fe3d2">`, **Events** `<BarRows accent="#ffd89b">`.
  - **`CostCard`** [AdminView.tsx:544](Smart-Tutor-frontend/components/app/AdminView.tsx#L544): Total spend (`fmtUsd`), Costed turns, Input/Output/Thinking tokens (`fmtTok`).
  - **`PerformanceCard`** (Updated 2026-07-03) [AdminView.tsx:478](Smart-Tutor-frontend/components/app/AdminView.tsx#L478): an aggregate per-stage latency report from `useAdminPerformance(days)` → `GET /api/frontend/admin/performance?days=N`. Renders avg total / avg TTFT and — front and centre — the **avg & p95 time-to-first-audio** (`first_audio_ms`, the perceived latency: turn received → first voice on the wire), plus a bar per pipeline `stage` (`avg_ms`, `p95_ms`, sample `n`).
  - **`MediaCard`** (see below).

#### MediaCard [AdminView.tsx:256](Smart-Tutor-frontend/components/app/AdminView.tsx#L256)
- The **single deletion path in the whole system** — manual only; there is no scheduled/automatic purge anywhere.
- Hooks: `useAdminMedia()` (snapshot) + `useMediaCleanup()` (mutation). Local state: `days` (default 14), `confirmOpen`, `result`.
- **If `isError` → returns `null`** (old backend / endpoint unavailable → hide quietly).
- Range options `MEDIA_RANGES = [7,14,30,60]` [AdminView.tsx:246](Smart-Tutor-frontend/components/app/AdminView.tsx#L246).
- Stats grid: Storage used (`fmtBytes` [AdminView.tsx:248](Smart-Tutor-frontend/components/app/AdminView.tsx#L248) — GB ≥ 1,073,741,824; MB ≥ 1,048,576; KB ≥ 1024; else B), Files stored, Turns/Traces with media, Oldest media (`relTime`).
- **`runCleanup`** [AdminView.tsx:266](Smart-Tutor-frontend/components/app/AdminView.tsx#L266): clears prior `result`, calls `cleanup.mutate(days, {onSuccess, onError})`. On success stores the `MediaCleanupResult` and closes the confirm dialog; on error synthesizes a failure `result` ("request failed — backend unreachable or not deployed with the cleanup endpoint") with all counts 0.
- `remaining = (remaining_turns ?? 0) + (remaining_traces ?? 0)` [AdminView.tsx:285](Smart-Tutor-frontend/components/app/AdminView.tsx#L285) — when > 0 the success banner says "run it again to continue" (server deletion is batched/bounded per pass).
- A `<ConfirmDialog destructive>` guards the delete with explicit "older than {days} days" copy and "This cannot be undone."

#### ModelsTab [AdminView.tsx:453](Smart-Tutor-frontend/components/app/AdminView.tsx#L453) — the multi-LLM comparison bench
- Local state `model` (selected model filter, "" = all). Hook `useAdminModelEval({days, model})` → `AdminModels`.
- **Stable per-model color**: `models.forEach((m,i) => colorOf[m.model_name] = colorFor(i))` [AdminView.tsx:462](Smart-Tutor-frontend/components/app/AdminView.tsx#L462) so a model reads as the same hue across every chart + the table.
- Builds metric arrays for `<MetricBars>` (each carries its own `color` + preformatted `display`):
  - **latency** (filtered `avg_latency_ms > 0`, `display = fmtMs`).
  - **cost** (filtered `avg_cost > 0`, `display = fmtUsd`).
  - **success** (`value = success_rate`, `display = "X%"`).
  - **rating** (filtered `rating_count > 0`, `display = "X.XX★"`).
  - **usage** → `<Donut>`; **daily responses** → `<AreaTimeline>`.
- **Headline cards**: Requests (sub `compare_groups compare`), Responses (sub `models_used models used`), Success rate `okRate = totals.responses ? round(totals.ok/totals.responses*100) : 0` [AdminView.tsx:479](Smart-Tutor-frontend/components/app/AdminView.tsx#L479), Total spend.
- **Empty path**: `models.length === 0` → a card prompting to use the simulator's model picker / Compare mode.
- **Model breakdown table** [AdminView.tsx:566](Smart-Tutor-frontend/components/app/AdminView.tsx#L566): columns Model (color dot + label + provider/"key off"), Runs, Success (`%` + `(N fail)`), Avg latency, Avg cost, Tokens (in/out), Rating (`★` or `—`), 👍/👎.

#### UsersTab / DevicesTab / SessionsTab / EventsTab
- Each is a `useQuery` → branch (`<ErrorState>` / `<SkeletonRows>`) → `<Table>` of rows.
- **UsersTab** [AdminView.tsx:601](Smart-Tutor-frontend/components/app/AdminView.tsx#L601): User (name/email/id), Exam, Lamps, Turns, Spend (`fmtUsd`), Last active (`relTime`). Empty → "No onboarded users yet."
- **DevicesTab** [AdminView.tsx:629](Smart-Tutor-frontend/components/app/AdminView.tsx#L629): Device (id/friendly_name), Owner, **Status** — `revoked_at` → rose pill; `online` → pulsing cyan dot + "online"; `is_paired` → "offline"; else "unpaired". Paired (locale date), Last seen (`relTime`).
- **SessionsTab** [AdminView.tsx:669](Smart-Tutor-frontend/components/app/AdminView.tsx#L669): Owner, Device, Turns, Subject (capitalized), Started, Last activity.
- **EventsTab** [AdminView.tsx:842](Smart-Tutor-frontend/components/app/AdminView.tsx#L842): When (`relTime`), Kind (cyan pill), Device, User, Payload (`JSON.stringify(e.payload)` if any keys else "—").

#### TurnsTab + TurnRow
- **TurnsTab** [AdminView.tsx:696](Smart-Tutor-frontend/components/app/AdminView.tsx#L696): local `status` filter from `STATUSES = ["", "ok","error","timeout","cancelled","bad_json","truncated","safety_block"]` [AdminView.tsx:694](Smart-Tutor-frontend/components/app/AdminView.tsx#L694). Hook `useAdminTurns({limit:80, status})`. Renders a `<ul>` of `<TurnRow>`.
- **`TurnRow`** [AdminView.tsx:740](Smart-Tutor-frontend/components/app/AdminView.tsx#L740) is `memo()`-wrapped — a `TurnsTab` re-render (filter/refetch) only repaints rows whose data changed, relying on TanStack Query structural sharing keeping unchanged row objects referentially identical across refetches. Local state: `open` (journey), `traceOpen` (trace). `hasJourney = (t.timeline?.length ?? 0) > 0`.
  - Left column: subject chip, difficulty (colored by `DIFFICULTY_COLORS`), owner.
  - Center: user_said (truncate), lamp_replied (line-clamp-2), metadata row — `llm_model`, `· tier N{escalated?" ↑"}`, `· source`, a cost badge (`fmtUsd`, shown whenever `cost_usd != null`), and a **backup-brain badge** when `t.fallback` (Gemini server-failed → Claude answered; tooltip uses `fallbackTierLabel(t.fallback_from)`).
  - The **Journey** toggle (only if `hasJourney`) and the **Trace** toggle.
  - Right column: `fmtMs(t.total_ms)`, `relTime(t.asked_at)`, and a rose status pill when `status !== "ok"`.
  - Expanding **Journey** mounts `<JourneyBreakdown timeline={t.timeline} tokens={{input,output,total:null}} cost={t.cost_usd}>`.
  - Expanding **Trace** mounts `<TraceView turnId={t.id}>` — **the trace fetch only happens when the drawer is opened**, so the 80-row feed costs zero extra requests.
  - **Updated 2026-07-03:** `AdminTurnRow` now also carries the behavioural + curriculum analytics fields the model tags on each turn (`topic`, `error_type`, `is_mcq`, `student_stuck`, `same_problem`, `student_disputes_prior`, `image_needed`, `concepts[]`, `problem_statement`) — all nullable ("—" on turns predating the columns). The full set is surfaced in the Trace drawer (§4.7).

#### PilotTab (Updated 2026-07-03) [AdminView.tsx:1187](Smart-Tutor-frontend/components/app/AdminView.tsx#L1187)

The pilot-program instrumentation dashboard. A cohort `<select>` (from `useAdminCohorts()` → `/api/frontend/admin/pilot/cohorts`) filters every card by pilot batch (`""` = all users). Cards:
- **`FunnelCard`** — the activation funnel (`signed_up → onboarded → paired → asked → succeeded`) from `useAdminPilotFunnel(cohort)`.
- **`FeedbackCard`** + **`RecentFeedbackCard`** — 👍/👎 counts, avg rating, reason/resolution mixes, and a recent-feedback table from `useAdminPilotFeedback(days, cohort)`.
- **`SurveyCard`** — baseline/exit/weekly counts, NPS, and the per-subject **confidence delta** (baseline avg → exit avg) from `useAdminPilotSurveys(cohort)`.
- **`ReportsCard`** — problem reports from `useAdminPilotReports(status, cohort)` with open/triaged/resolved counts; each `ReportRow` can advance a report's triage state via `useSetReportStatus()` → `POST /api/frontend/admin/pilot/reports/{id}/status` (the one mutating admin-pilot action).

#### InsightsTab (Updated 2026-07-03) [AdminView.tsx:1484](Smart-Tutor-frontend/components/app/AdminView.tsx#L1484)

Learning insights built on the tagged turns, filtered by an exam `<select>` and a cohort `<select>`. Cards: **`EngagementCard`** (DAU/WAU/MAU, streaks, study hours — `useInsightEngagement`), **`CoverageCard`** (syllabus coverage % by subject for the chosen exam — `useInsightCoverage`), **`QualityCard`** (escalation/drop-off %, thumbs, got-it/stuck — `useInsightQuality`), **`MistakesCard`** (mistake-type distribution overall + top type per topic — `useInsightMistakes`), and **`TopicStrengthCard`** (per-topic questions/latency/escalation/confidence/got-it/struggle-score — `useInsightTopics`). All hit `/api/frontend/admin/pilot/insights/*`.

#### AnalyticsTab (Added 2026-07-09 → 07-11) [AdminView.tsx:1530](Smart-Tutor-frontend/components/app/AdminView.tsx#L1530) — output-generation & total latency

Answers *"how long does it take to generate the output?"* per question and in aggregate, over a window. **Physical-lamp turns only** (the copy states web-simulator turns are excluded — the backend filters `source='lamp'`). Local state `const [range, setRange] = useState<AnalyticsRange>("today")` drives a pill selector `ANALYTICS_RANGES = today | yesterday | 7d | 30d`; hooks `useAnalyticsSummary(range)` + `useAnalyticsQuestions(range)` (both 60 s `refetchInterval`, `retry: false`). Sections:

- **Co-headline `StatTile`s** (4): Avg generation time (`fmtMs(avg_generation_ms)`, sub `over n_generation questions`), Avg total turn time (`avg_total_ms`, sub `over n_questions`), Questions (`n_questions`, sub range label), and Model selection (`stages.find(model_select)?.avg_ms`, sub "avg pre-router time").
- **Escalation breakdown card** — renders `summary.escalation` as five rows in T1 → T2 → T3 order: *resolved at tier 1*, *escalated from T1* / *started directly* (tier 2), *escalated* / *started directly* (tier 3); each shows count, share of `escTotal`, and avg tier time, colored by `TIER_COLORS = {1:#5fe3d2, 2:#ffb84d, 3:#c9a3ff}`. (Replaced the earlier per-day latency chart on 2026-07-11.)
- **Per-stage card** — the `_PERF_STAGES` breakdown filtered to `n > 0 && avg_ms != null`, each bar scaled to `maxStage`. Stages are grouped and numbered 1..5 by `STEP_META` — step 1 upload, step 2 image+STT (parallel), step 3 model_select, step 4 the escalating LLM tiers, step 5 the parallel output legs (equation/graph/voice) — so concurrent stages share a step number.
- **Questions table** — one row per turn from `questions.data`, newest first: When (`fmtWhen`), device, question text, and per-turn timings `generation_ms` (bar scaled to `maxGen`), `latex_ms` (Equation render), `graph_ms` (Graph render), `tts_ms` (Voice), `total_ms`, plus question **Level** (`difficulty`) and per-question **escalation** (`final_tier` + `escalated`). Failed/cancelled turns appear with a **Reason** (the backend `_short_reason`) in place of timings; a `—` means "not applicable to this turn." Shows averages only (p95 was hidden on 2026-07-11).

`fmtWhen(iso)` [AdminView.tsx] renders a stored ISO time as `MMM d, HH:MM` (or `—`). `StatTile` and the `Timer` icon are local to this tab.

#### OtaTab (Updated 2026-07-03) [AdminView.tsx:815](Smart-Tutor-frontend/components/app/AdminView.tsx#L815) — firmware over-the-air

The admin surface for publishing lamp firmware. A drag-and-drop `.bin` uploader with a version number field (auto-bumped past the current published version) and optional notes; **Publish** calls `useUploadOtaRelease()` — which does a **manual `fetch` with the Clerk token and `Content-Type: application/octet-stream`** (the raw `.bin` is the request body, so it bypasses `useApi().post`'s JSON-stringify) → `POST /api/frontend/admin/ota/release?version=N&notes=…`. A "Release history" table (`useAdminOtaReleases()` → `/api/frontend/admin/ota/releases`) lists version/size/notes/status (current)/uploader/when, each deletable via `useDeleteOtaRelease()`. Lamps self-update on their next boot; the copy points admins at bumping `FIRMWARE_VERSION` in the firmware's `ota.h`.

**Shared local helpers (AdminView):**
- `toSorted` [AdminView.tsx:75](Smart-Tutor-frontend/components/app/AdminView.tsx#L75), `fmtMs` [AdminView.tsx:80](Smart-Tutor-frontend/components/app/AdminView.tsx#L80), `fmtUsd` [AdminView.tsx:84](Smart-Tutor-frontend/components/app/AdminView.tsx#L84) (`<0.01`→4 decimals, else 2; `0`→`$0`), `fmtTok` [AdminView.tsx:94](Smart-Tutor-frontend/components/app/AdminView.tsx#L94) (≥1M→`X.XM`, ≥1k→`X.Xk`), `relTime` [AdminView.tsx:100](Smart-Tutor-frontend/components/app/AdminView.tsx#L100) (30-day rollover), `fallbackTierLabel` [AdminView.tsx:89](Smart-Tutor-frontend/components/app/AdminView.tsx#L89) ("gemini-tier1" → "tier 1"), `isForbidden(err)` [AdminView.tsx:112](Smart-Tutor-frontend/components/app/AdminView.tsx#L112) (`err instanceof ApiError && err.status === 403`).
- Presentational: `Card`, `CardHead`, `Table`, `Td`, `EmptyRow`, `Pill`, `SkeletonGrid`, `SkeletonRows`.
- **`ErrorState`** [AdminView.tsx:935](Smart-Tutor-frontend/components/app/AdminView.tsx#L935): if `isForbidden` → "Admin access required / Your account isn't on the admin allowlist" with an `AlertTriangle`; otherwise the generic "Couldn't reach the Lumos backend" notice.

**Used by.** `app/admin/page.tsx`.

---

### 4.5 charts.tsx

**File:** `components/app/charts.tsx` — self-contained SVG chart primitives, "no external chart dependency" [charts.tsx:4](Smart-Tutor-frontend/components/app/charts.tsx#L4). All are responsive via `viewBox` and animated with `framer-motion`.

**Exports & shared palette.**
- `PALETTE = ["#ffb84d","#5fe3d2","#b9a3ff","#ff9bb0","#ffd89b","#7cc7ff"]` [charts.tsx:11](Smart-Tutor-frontend/components/app/charts.tsx#L11).
- `colorFor(i)` [charts.tsx:13](Smart-Tutor-frontend/components/app/charts.tsx#L13): `PALETTE[i % PALETTE.length]` — cyclic so any index maps to a stable hue.

**`smoothPath(pts)`** [charts.tsx:19](Smart-Tutor-frontend/components/app/charts.tsx#L19) — Catmull-Rom → cubic Bézier converter. For each segment it computes control points `c1 = p1 + (p2 - p0)/6`, `c2 = p2 - (p3 - p1)/6` (clamping `p0`/`p3` to the endpoints), emitting `C` commands. Produces a smooth organic curve from raw points. Edge cases: empty → `""`; single point → `M x y`.

**`AreaTimeline({ data, color="#ffb84d", height=200 })`** [charts.tsx:38](Smart-Tutor-frontend/components/app/charts.tsx#L38):
- Constants: `W=720`, `padX=14`, `padTop=18`, `padBottom=26`. `max = Math.max(1, ...values)` (the `1` prevents divide-by-zero on all-zero data).
- Point math: `x = padX + (n<=1 ? innerW/2 : (i/(n-1))*innerW)`, `y = padTop + innerH - (value/max)*innerH`.
- Draws: a vertical gradient fill (38% → 0% opacity), four baseline gridlines at `f ∈ {0.25,0.5,0.75,1}`, the animated area (`opacity 0→1`), the animated stroke line (`pathLength 0→1`, `drop-shadow` glow), point circles (radius 3 only where `value > 0`), and sparse x-labels at indices `[0, floor((n-1)/2), n-1]` via `fmtDay` [charts.tsx:131](Smart-Tutor-frontend/components/app/charts.tsx#L131) (parses `label+"T00:00:00"` → "Mon D").
- Uses `useId()` (sanitized) to namespace the gradient `id` so multiple timelines on one page don't collide.

**`Donut({ data, size=188 })`** [charts.tsx:138](Smart-Tutor-frontend/components/app/charts.tsx#L138):
- `total = Σ value`, `r = size/2 - 16`, circumference `C = 2πr`. SVG is rotated `-90°` so segments start at 12 o'clock.
- Each slice: `frac = value/total`, `len = frac*C`, drawn as a `stroke-dasharray="${len} ${C-len}"` with `stroke-dashoffset=-acc`; `acc` accumulates `len`. `strokeWidth=14`, `strokeLinecap="round"`, glow `drop-shadow`. Staggered `delay: i*0.08`.
- Center text (counter-rotated `+90°`) shows the `total` and "QUESTIONS".
- A legend `<ul>` lists each slice with color dot, capitalized label, value, and percent `Math.round(value/total*100)`. Empty data → "No data yet."

**`BarRows({ data, accent="#5fe3d2" })`** [charts.tsx:208](Smart-Tutor-frontend/components/app/charts.tsx#L208): horizontal bars; `max = Math.max(1, ...values)`; each bar `width = (value/max)*100%` animated `0→width` with `delay: i*0.05`. Label has `_` replaced with spaces and is capitalized.

**`MetricBars({ data })`** [charts.tsx:244](Smart-Tutor-frontend/components/app/charts.tsx#L244): like `BarRows` but each datum carries its own `color` (so a model keeps one hue across charts) and a preformatted `display` string for the right label (e.g. "1.2 s", "$0.0031", "92%", "4.5★"). Used only by ModelsTab.

**`SegmentedBar({ data })`** [charts.tsx:277](Smart-Tutor-frontend/components/app/charts.tsx#L277): single horizontal bar split into colored segments; each segment `width = (value/total)*100%` (skipped when `value === 0`), with a legend below. Used for difficulty mix.

**Used by.** `AnalyticsView` (`AreaTimeline, BarRows, Donut, SegmentedBar`) and `AdminView` (all six: `AreaTimeline, BarRows, colorFor, Donut, MetricBars, SegmentedBar`).

---

### 4.6 JourneyBreakdown.tsx

**File:** `components/app/JourneyBreakdown.tsx` — [JourneyBreakdown.tsx:74](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L74)

**Purpose.** A shared "journey" waterfall — the input→output path of one answer broken into timed steps with tokens + cost. Rendered identically in two places: the **simulator** (live, full path including upload + render) and the admin **Turns** log (persisted browser + server steps).

**Props.** `{ timeline?: TimelineStep[]|null, renderMs?: number|null, tokens?: {input:number|null, output:number|null, total:number|null}, cost?: number|null }`.

**Constants.** `STEP_META` [JourneyBreakdown.tsx:15](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L15) maps known step keys to human labels: `prepare="Capture & encode", auth="Auth token", upload="Upload + round trip", stt="Speech-to-text", model="Model inference", parse="Parse output", render="Render to screen"`. Unknown keys render with the raw key (so a new backend step never silently vanishes). `CLIENT_TINT="#ffb84d"` (amber, browser), `SERVER_TINT="#5fe3d2"` (cyan, backend). `BAR_STYLE` [JourneyBreakdown.tsx:47](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L47) pre-builds one style object per tint so re-renders reuse it (only `width` varies).

**`StepRow`** [JourneyBreakdown.tsx:52](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L52) (`memo()`): label + a bar whose `pct = max>0 ? Math.max(2, Math.round((s.ms/max)*100)) : 0` (the `Math.max(2, …)` keeps tiny steps visible) + a right-aligned `fmtMs(s.ms)`.

**Control flow / the key timing algorithm:**
1. `steps = [...(timeline ?? [])]`; if `renderMs != null && renderMs >= 0`, append a client `render` step [JourneyBreakdown.tsx:88](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L88).
2. Empty → "No step timing was recorded for this answer."
3. Split into `clientSteps` (`where==="client"`) and `serverSteps` (`where==="server"`); `hasUpload = clientSteps.some(s=>s.step==="upload")`.
4. **Total computation** [JourneyBreakdown.tsx:108](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L108): when an `upload` bar is present (live view), the server steps happened **inside** it, so `totalMs = Σ clientSteps`. Otherwise (admin/persisted, no upload bar) client + server are sequential, so `totalMs = Σ clientSteps + Σ serverSteps`. `max = Math.max(1, ...all step ms)` for bar scaling.
5. Renders the "Total journey" header (`fmtMs(totalMs)`), a **Browser** group of client steps, a **Server** group labeled "Server (within upload)" or "Server processing" depending on `hasUpload`, and a token/cost footer when `tokens || cost != null`.

**Formatters.** `fmtMs` [JourneyBreakdown.tsx:28](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L28) (`<1000`→`X ms`, else `X.XX s`); `fmtTok` [JourneyBreakdown.tsx:32](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L32) (`null`→`—`, else `toLocaleString()`); `fmtCost` [JourneyBreakdown.tsx:36](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L36) (`null`→`—`, `0`→`$0`, `<0.01`→5 decimals, else 4 decimals).

**Used by.** `AdminView` TurnRow (persisted path, `renderMs` omitted) and `app/simulator/page.tsx` (live path with `renderMs`).

---

### 4.7 TraceView.tsx

**File:** `components/app/TraceView.tsx` — [TraceView.tsx:259](Smart-Tutor-frontend/components/app/TraceView.tsx#L259)

**Purpose.** The admin "visual audit" drawer for one turn — a phase-by-phase storyboard: a SOURCE badge (lamp vs simulator), the question audio the backend received, raw-vs-enhanced camera frames with a target-region overlay, a latency waterfall, transcript in / tutor output out (equations via KaTeX), the escalation reason, and the raw LLM JSON/prompt.

**Props.** `{ turnId: string }`.

**State / hooks.** `useTurnTrace(turnId)` [TraceView.tsx:260](Smart-Tutor-frontend/components/app/TraceView.tsx#L260) → `AdminTurnTrace`; in `useTurnTrace` the query is `staleTime: 5*60_000` and `retry:false` because a finished turn's trace never changes. `RawBlock` holds its own `open` state.

**Top-level control flow.**
1. `isLoading` → three pulsing skeleton rows.
2. `isError` → distinguishes `error instanceof ApiError && error.status === 404` ("No trace was recorded for this turn (it predates pipeline tracing, or tracing is disabled).") from a generic load failure [TraceView.tsx:271](Smart-Tutor-frontend/components/app/TraceView.tsx#L271).
3. `!data` → `null`.
4. Success → computes `studentSaid = whisper_transcript || turn_transcript || null` and `failed = status !== "ok" && status !== "retake"` [TraceView.tsx:284](Smart-Tutor-frontend/components/app/TraceView.tsx#L286), then renders the storyboard.

**Sections rendered (each conditional on its data):**
- **Header strip**: `<SourceBadge>` ([TraceView.tsx:98](Smart-Tutor-frontend/components/app/TraceView.tsx#L98) — `source !== "simulator"` → Lamp/cyan, else Simulator/amber), status pill ("completed ok" or the raw status), escalation pill (`escalated → tier N`), confidence pill (`(confidence*100).toFixed(0)%`), a token→words size pill, and the `device_id`.
- **Hard-failure callout** when `failed && error_detail` — rose box with the error detail.
- **Audio** `<audio controls preload="none" src={raw_audio_url}>` when present.
- **Image comparison** [TraceView.tsx:362](Smart-Tutor-frontend/components/app/TraceView.tsx#L362): raw frame vs the frame the AI was shown; an "Auto-Corrected" sky badge when `enhanced_image_url` exists, else an "Image Quality Optimal (Pass-through Mode)" emerald badge. The enhanced figure uses `<AiInputImage>`.
- **`AiInputImage`** [TraceView.tsx:191](Smart-Tutor-frontend/components/app/TraceView.tsx#L191): renders the image; if a valid `bbox` exists it overlays a yellow target rectangle positioned by `top=ymin/10%, left=xmin/10%, width=(xmax-xmin)/10%, height=(ymax-ymin)/10%` (dividing by 10 maps the 0–1000 coordinate space to 0–100 %). A `w-fit` wrapper hugs the rendered image so percentages map 1:1 onto image coordinates. The tag shows `🎯 {label}`.
- **Target Lock Verification** box when `extracted_ocr_text` exists.
- **`PhaseTimeline`** [TraceView.tsx:123](Smart-Tutor-frontend/components/app/TraceView.tsx#L123): per-phase bars; total = `Math.max(processing_latency_ms ?? 0, max phase ms, 1)`; each `pct = clamp(p.ms/total*100, 1.5, 100)`; colored by `phaseColor`; shows label (`PHASE_LABELS`), `failed`/`skipped` tags, `fmtMs(p.ms)`, and optional `detail`. Empty → "No phase timings were recorded for this turn." **Updated 2026-07-03:** when `trace.first_audio_ms != null` it draws a cyan **"First audio · student hears the voice"** milestone bar on the same scale as the phase bars, so the perceived-latency moment is visible relative to upload/STT/LLM/TTS.
- **Analytics tags block** (Updated 2026-07-03) [TraceView.tsx:526](Smart-Tutor-frontend/components/app/TraceView.tsx#L526): a "what the AI recorded about this turn" grid surfacing the behavioural/curriculum fields on `AdminTurnTrace` — `turn_topic`, `turn_error_type`, `turn_is_mcq`, `turn_student_stuck`, `turn_student_disputes_prior`, `turn_same_problem`, `turn_image_needed`, `turn_ocr_text` (target label), `turn_concepts[]` — each rendering "—" when null; plus the full **problem statement** as the AI read it and, when present, the internal **solution outline**.
- **Escalation reason** amber box when present.
- **Text in / text out** [TraceView.tsx:460](Smart-Tutor-frontend/components/app/TraceView.tsx#L460): `studentSaid` (speech→text) and `turn_speech` (final tutor output), plus `turn_display_content` and, when `turn_latex_equations.length > 0`, KaTeX `<BlockMath>` per equation with a `renderError` fallback that shows the raw LaTeX in rose.
- **Raw artifacts** via three collapsible `<RawBlock>`s [TraceView.tsx:237](Smart-Tutor-frontend/components/app/TraceView.tsx#L237): prompt context, full system prompt, and the exact JSON response.

**Algorithms / constants.**
- `validBbox(b)` [TraceView.tsx:49](Smart-Tutor-frontend/components/app/TraceView.tsx#L49): returns `[ymin,xmin,ymax,xmax]` only if `b` is a 4-element numeric array, each finite and in `[0,1000]`, with `ymin<ymax && xmin<xmax`; else `null` (overlay hidden, layout untouched). Belt-and-braces with backend validation.
- `tokWords(tok)` [TraceView.tsx:42](Smart-Tutor-frontend/components/app/TraceView.tsx#L42): `Math.round((tok ?? 0) * 0.75)` (1 token ≈ 0.75 English words).
- `PHASE_LABELS` [TraceView.tsx:59](Smart-Tutor-frontend/components/app/TraceView.tsx#L59) — plain-English names for backend phase keys (`capture, upload, memory_load, image_enhance, stt_whisper, preroute, retake_short_circuit, llm_tier1/2/3, llm_model, echo_guard_recall, dispatch, tts_stream, latex_render`).
- `SLOW_MS` [TraceView.tsx:78](Smart-Tutor-frontend/components/app/TraceView.tsx#L78) — per-phase "slow" budgets (e.g. `image_enhance:1500, stt_whisper:800, llm_tier1:5000, llm_tier2:12000, llm_tier3:25000, llm_model:8000, tts_stream:12000, latex_render:8000, dispatch:15000`).
- `phaseColor(p)` [TraceView.tsx:90](Smart-Tutor-frontend/components/app/TraceView.tsx#L90): rose `#ff9bb0` on error; muted `#5c5c72` on skipped; amber `#ffb84d` for tier2/tier3 (escalated) or when `ms > (SLOW_MS[phase] ?? 3000)`; else green/cyan `#5fe3d2`.
- `fmtMs(ms)` [TraceView.tsx:34](Smart-Tutor-frontend/components/app/TraceView.tsx#L34): `null`→`—`, `0`→`<1ms`, else `Xs`/`Xms`.

**External deps.** `katex/dist/katex.min.css` import [TraceView.tsx:17](Smart-Tutor-frontend/components/app/TraceView.tsx#L17) and `react-katex` `BlockMath`. Note the `<img>` tags use raw HTML (with eslint-disable comments) because the backend blob host isn't in `next.config` images.

**Used by.** `AdminView` TurnRow's Trace drawer (lazy-mounted).

---

### 4.8 QrScanner.tsx

**File:** `components/app/QrScanner.tsx` — [QrScanner.tsx:20](Smart-Tutor-frontend/components/app/QrScanner.tsx#L20)

**Purpose.** In-app QR scanner for lamp pairing, with three input paths in order of convenience: (1) live camera scan via `getUserMedia` + `jsQR` per frame; (2) upload a photo of the QR; (3) type the printed code. On a successful decode it extracts the pairing code (`extractPairingCode`) and calls `onCode(code)`; the parent navigates to `/pair/[code]`.

**Props.** `{ onCode: (code: string) => void }`.

**State / refs.** `videoRef`, `canvasRef`, `streamRef` (MediaStream), `rafRef` (requestAnimationFrame id), `firedRef` (one-shot guard) — all `useRef`. State: `state: CamState` (`idle | requesting | scanning | denied | error`) [QrScanner.tsx:18](Smart-Tutor-frontend/components/app/QrScanner.tsx#L18), `error: string|null`, `manual: string`.

**Functions:**
- **`fire(raw)`** [QrScanner.tsx:30](Smart-Tutor-frontend/components/app/QrScanner.tsx#L30): `code = extractPairingCode(raw)`; if no code or `firedRef.current` already set → returns `false`; otherwise sets `firedRef`, calls `stop()`, fires `onCode(code)`, returns `true`. The one-shot guard prevents double navigation if multiple frames decode.
- **`stop()`** [QrScanner.tsx:42](Smart-Tutor-frontend/components/app/QrScanner.tsx#L42): cancels the RAF loop, stops all media tracks, nulls `srcObject`.
- **`scanLoop()`** [QrScanner.tsx:50](Smart-Tutor-frontend/components/app/QrScanner.tsx#L50): the per-frame decode. Waits for `video.videoWidth`; `ctx.drawImage` → `getImageData` → `jsQR(img.data, w, h, {inversionAttempts:"dontInvert"})`. On a hit that `fire()` accepts → stops; otherwise re-schedules via `requestAnimationFrame`. Uses `getContext("2d", {willReadFrequently:true})` for fast repeated reads. **Updated 2026-07-03 (perf):** the rAF keeps ticking at ~60 fps but the expensive full-frame `jsQR` decode is now **throttled to ~10 fps** (`SCAN_INTERVAL_MS = 100`, gated on `performance.now()`) and the frame is **downscaled to ≤640 px on the long side** (`SCAN_MAX_DIM`, ~4× fewer pixels than 720p) before `getImageData`. The `!ctx` branch now **reschedules the loop** instead of killing it forever (previously a one-off `getContext` failure permanently stopped scanning). See `OPTIMIZATION.md §2.3`.
- **`enable()`** [QrScanner.tsx:68](Smart-Tutor-frontend/components/app/QrScanner.tsx#L68): sets `requesting`, requests `getUserMedia({video:{facingMode:"environment", width:{ideal:1280}, height:{ideal:720}}})` (rear camera at 720p ideal), attaches to the video, plays, sets `scanning`, starts the loop. Errors: `NotAllowedError`/`SecurityError` → `denied`; anything else → `error` with the message. **Updated 2026-07-03 (leak fix):** a `mountedRef` guard means that if the user navigates away **while the permission prompt is still open**, the resolved `getUserMedia` stream is immediately stopped rather than left running with nothing to release it (`OPTIMIZATION.md §4.2`).
- **`onFile(file)`** [QrScanner.tsx:94](Smart-Tutor-frontend/components/app/QrScanner.tsx#L94): `URL.createObjectURL` → `Image.decode()` → draw to an offscreen canvas → `jsQR` (default inversion attempts, since photos can be inverted). On no decode → "No pairing QR found in that image…". Always `URL.revokeObjectURL` in `finally`.
- **`submitManual(e)`** [QrScanner.tsx:120](Smart-Tutor-frontend/components/app/QrScanner.tsx#L120): `preventDefault`; `fire(manual)`; on failure → "That doesn't look like a valid pairing code."
- **Cleanup**: `useEffect` on mount sets `mountedRef.current = true` and returns a cleanup that flips it `false` and calls `stop()` on unmount (Updated 2026-07-03 — the `mountedRef` lets `enable()`'s async `getUserMedia` resolution detect an unmount that happened mid-prompt).

**Render.** A square video stage (hidden until `scanning`) with an amber framing reticle when scanning; an overlay panel for non-scanning states (denied/error/requesting/idle) with a "Scan with camera" button; an inline error during scanning; an "Upload a QR photo" file label (`accept="image/*"`); and a manual-entry form with a "Link" submit (disabled when `manual.trim()` empty).

**Decoding algorithm (delegated):** `extractPairingCode(raw)` in `lib/pairing-code.ts` [pairing-code.ts:6](Smart-Tutor-frontend/lib/pairing-code.ts#L6) — tries to parse `raw` as a URL and take the `/pair/CODE` segment or `?code=` param; falls back to a `/pair/CODE` path match, a `code=CODE` fragment, or a bare 6–8 alphanumeric code; `normalize()` strips whitespace/hyphens and uppercases.

**Used by.** `app/connect/page.tsx` (`onCode` → `router.push("/pair/<code>")`).

---

### 4.9 ConfirmDialog.tsx

**File:** `components/app/ConfirmDialog.tsx` — [ConfirmDialog.tsx:9](Smart-Tutor-frontend/components/app/ConfirmDialog.tsx#L9)

**Purpose.** A generic, accessible confirm modal: Escape to cancel, click-outside to cancel, animated entry/exit. Used for destructive actions (device Unlink, admin media delete).

**Props.** `{ open: boolean, title: string, body: React.ReactNode, confirmLabel="Confirm", cancelLabel="Cancel", busy=false, destructive=false, onConfirm: () => void, onCancel: () => void }`.

**Behavior.**
- `useEffect` [ConfirmDialog.tsx:30](Smart-Tutor-frontend/components/app/ConfirmDialog.tsx#L30) attaches a `keydown` listener while `open`; **Escape calls `onCancel` only when `!busy`** (you can't cancel mid-operation). Listener is removed on close/unmount.
- Rendered inside `<AnimatePresence>`; the backdrop is a full-screen `<button>` that calls `onCancel()` only when `!busy`. Both backdrop and panel animate (panel uses ease `[0.16, 1, 0.3, 1]`).
- ARIA: `role="dialog"`, `aria-modal="true"`, `aria-label={title}`.
- The confirm button shows a spinning `Loader2` when `busy`, and is styled rose (`bg-rose`) when `destructive`, else `btn-primary`. Both buttons are `disabled` while `busy`.

**Used by.** `app/devices/page.tsx` (Unlink confirmation) and `AdminView` MediaCard (delete-media confirmation). The header comment references "§7.3" (the device-unlink flow doc).

---

### 4.10 ErrorPanel.tsx

**File:** `components/app/ErrorPanel.tsx` — [ErrorPanel.tsx:9](Smart-Tutor-frontend/components/app/ErrorPanel.tsx#L9)

**Purpose.** Shared error surface for the pairing flow. Shows the mapped message + suggested action; renders a retry button for transient (network) failures.

**Props.** `{ error: FriendlyError, onRetry?: () => void }`.

**Behavior.** `showRetry = onRetry && (error.code === "NETWORK" || error.code === "UNKNOWN")` [ErrorPanel.tsx:16](Smart-Tutor-frontend/components/app/ErrorPanel.tsx#L16) — retry is offered only for the two transient codes. Renders an `AlertTriangle` icon, `error.message`, the `error.action` hint (only when **not** showing retry), and — when `showRetry` — a "Try again" button (label = `error.action ?? "Try again"`).

**Data source.** `FriendlyError` comes from `friendlyError(err)` / `friendlyByCode(code)` in `lib/devices.ts` [devices.ts:74](Smart-Tutor-frontend/lib/devices.ts#L74), which maps `ApiError` status/codes (404→CODE_NOT_FOUND, 409→ALREADY_PAIRED, 410→CODE_EXPIRED, 401→USER_AUTH_FAIL, 403→NOT_OWNER, 429→RATE_LIMIT, ≥500→NETWORK, else UNKNOWN; non-ApiError fetch rejections → NETWORK) to user-facing copy.

**Used by.** `app/pair/[code]/page.tsx` (the pairing confirmation page). The header comment references "§7.2 / §7.5".

---

### 4.11 BootDiagnostics.tsx

**File:** `components/app/BootDiagnostics.tsx` — [BootDiagnostics.tsx:25](Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L25)

**Purpose.** A passive, render-nothing (`return null`) page-load and runtime timing probe, mounted once app-wide inside `Providers`. While the API/query logs cover the network, this covers the **browser side** of "how long did the page take to load" and where the main thread stalls. All observers are best-effort and feature-detected — older browsers (or Firefox, which lacks `longtask`) simply log less, never throw.

**Props.** None. **Returns `null`.**

**State / hooks.** `usePathname()` (Next navigation) [BootDiagnostics.tsx:26](Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L26); refs `prevPath`, `routeChangeAt`. Two `useEffect`s.

**Effect 1 — one-time observers** [BootDiagnostics.tsx:31](Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L31):
- **Navigation Timing waterfall** [BootDiagnostics.tsx:35](Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L35): reads `performance.getEntriesByType("navigation")[0]` and computes `dns, tcp, tls, ttfb, response, domInteractive, domComplete, load` (all rounded). Reports via `log.lag("page load (navigation)", phases.load, 2500, 5000, phases)` (budget 2500 ms, severe 5000 ms) and an info line with TTFB/interactive. Fires immediately if `document.readyState === "complete"`, else on `window load`.
- **`observe(type, cb)`** helper [BootDiagnostics.tsx:58](Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L58): wraps `new PerformanceObserver(...).observe({type, buffered:true})` in try/catch (`buffered` replays entries fired before attach; unsupported types are silently skipped).
- **LCP** [BootDiagnostics.tsx:70](Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L70): `log.lag("largest contentful paint", last.startTime, 2500, 4000)`.
- **Long tasks** [BootDiagnostics.tsx:76](Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L76): for each entry, `log.lag("main-thread long task", e.duration, BUDGET.longTask /*120*/, 300, {startedAt})`.
- Cleanup disconnects all observers.

**Effect 2 — per-navigation timing** [BootDiagnostics.tsx:88](Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L88): on the first mount logs "landed on {pathname}"; on subsequent path changes logs `prev → pathname`, then uses a double `requestAnimationFrame` to measure time until the new route's first paint and reports `log.lag("route render {pathname}", elapsed, BUDGET.route /*800*/)`. Updates `prevPath`/`routeChangeAt` each run.

**`log.lag` semantics** [log.ts:140](Smart-Tutor-frontend/lib/log.ts#L140): under budget → `debug` PERF line; over budget → `warn` LAG; over `severe` → `error` SEVERE LAG. (Errors are always shown; other categories only when `VERBOSE`.)

**Used by.** `app/providers.tsx` (mounted once globally).

---

### 4.12 Pilot & UX components (added 2026-07-03)

A cluster of components added with the pilot program and the perceived-latency work. All are `"use client"` and (except `PageSkeleton`) consume `lib/pilot.ts`.

#### 4.12.1 SurveyView.tsx

**File:** `components/app/SurveyView.tsx`. **Props.** `{ kind: SurveyKind }` (`"baseline" | "exit"`). The pilot's matched before/after survey. A config-driven question list (`Question` union of `scale | choice | number | text`) built from a shared 4-subject **confidence** block (Physics/Chemistry/Mathematics/Biology, asked identically in both variants so the delta is measurable) plus variant-specific questions — baseline: recent mock score, weekly study hours, prior doubt-clearing tools, biggest challenge; exit: recent score, NPS scale, "did it help you learn", favourite thing, most frustrating. Answers accumulate in a `Record<string, unknown>` map. On submit it (baseline only) requires a consent checkbox and records it best-effort via `useRecordConsent()` first, then `useSubmitSurvey()` → `POST /api/frontend/pilot/survey`; `useSurveyStatus()` shows a "you already submitted this on `<date>`" notice. `SURVEY_VERSION`/`CONSENT_VERSION` are `"v1"`. **Used by.** `app/survey/page.tsx`.

#### 4.12.2 PersonalizationView.tsx

**File:** `components/app/PersonalizationView.tsx`. The `/personalize` "how I learn best" form body. Interests are a 12-chip preset picker (`Football, Cricket, Gaming, …`) plus free-text custom chips; `answer_length` is a `short | balanced | detailed` choice; `example_pref` is a `love | sometimes | rarely` choice; plus a free-text notes box. Seeds from `usePersonalization()` on load and persists via `useSavePersonalization()` → `POST /api/frontend/pilot/personalization` (best-effort; a "Saved" state flashes for 2s). **Collection-only** — the in-file comment is explicit that feeding these into the tutor's system prompt is a separate, still-under-review decision. **Used by.** `app/personalize/page.tsx`.

#### 4.12.3 PersonalizeCard.tsx

**File:** `components/app/PersonalizeCard.tsx`. The dashboard CTA linking to `/personalize`. `usePersonalization()` decides state: returns `null` while loading (avoids a nudge→done flash), a prominent amber "Tell Lumos how you learn best · 2 minutes…" nudge while the profile is empty, or a quiet cyan "Your learning preferences · Saved — tap to update" once any of interests/answer_length/example_pref is set — the "always-available option + one gentle nudge" pattern (never forced at signup, never repeated). **Used by.** `app/dashboard/page.tsx`.

#### 4.12.4 ReportProblem.tsx

**File:** `components/app/ReportProblem.tsx`. A one-tap global problem reporter mounted once inside `<AppHeader>`, so it appears on every signed-in page. A fixed bottom-right pill expands into an **inline panel** (deliberately not a native `dialog`, which would block the page): a category chip-row (`wrong_answer, lamp_offline, audio, app, other`) + optional free-text. On send it auto-attaches a context snapshot (`page` pathname, ISO `at`, `ua`) and posts via `useReportProblem()` → `POST /api/frontend/pilot/report`. Best-effort — shows "Thanks — we got it" and closes even on failure, never blocking the user. **Used by.** `AppHeader` (global mount).

#### 4.12.5 PageSkeleton.tsx

**File:** `components/app/PageSkeleton.tsx`. **Props.** `{ active?: string }`. The shared loading skeleton every route-level `loading.tsx` renders (`admin, analytics, connect, dashboard, devices, personalize, simulator`). It keeps the real `<AppHeader active>` (visual continuity; `useMe` is cached at 60s so it doesn't refetch on skeleton mount) above an `animate-pulse` glass placeholder grid. Its purpose is to give the App Router an **instant Suspense boundary** so a `<Link>` click to a `force-dynamic` page commits immediately instead of waiting on the uncached auth probe (up to 9s) — the fix for the "click a nav item → nothing → then it opens" symptom (`OPTIMIZATION.md §2.1`). **Used by.** all seven `app/*/loading.tsx` files.

---

## 5. Landing-Page Components

### 5.1 motion.tsx

**File:** `components/landing/motion.tsx` — shared Framer-Motion primitives for the landing site. Honors `prefers-reduced-motion`.

- **`EASE = [0.16, 1, 0.3, 1]`** [motion.tsx:7](Smart-Tutor-frontend/components/landing/motion.tsx#L7) — a slightly-overshooting cubic-bezier ease used across every reveal.
- **`Reveal({ children, delay=0, y=28, className })`** [motion.tsx:10](Smart-Tutor-frontend/components/landing/motion.tsx#L10): scroll-triggered fade + rise. Uses `useReducedMotion()` → when reduced, `initial={false}` (no offset). Otherwise `initial={{opacity:0, y}}`, `whileInView={{opacity:1, y:0}}`, `viewport={{once:true, margin:"-80px"}}` (fires once, 80 px before entering), `transition={{duration:0.9, delay, ease:EASE}}`.
- **`stagger: Variants`** [motion.tsx:36](Smart-Tutor-frontend/components/landing/motion.tsx#L36): `{ hidden:{}, show:{transition:{staggerChildren:0.09, delayChildren:0.1}} }` — staggers children by 90 ms after a 100 ms delay.
- **`riseItem: Variants`** [motion.tsx:41](Smart-Tutor-frontend/components/landing/motion.tsx#L41): `hidden:{opacity:0, y:24}` → `show:{opacity:1, y:0, transition:{duration:0.85, ease:EASE}}`.
- **`Float({ children, amplitude=14, duration=6, delay=0, rotate=0, className })`** [motion.tsx:48](Smart-Tutor-frontend/components/landing/motion.tsx#L48): "antigravity" endless drift. When reduced motion → returns a static `<div>`. Otherwise animates `y: [-amplitude, amplitude, -amplitude]` and (if `rotate`) `rotate: [-rotate, rotate, -rotate]`, with `repeat: Infinity, ease:"easeInOut"`. Per-instance `delay`/`amplitude` keep a field of floaters out of lockstep.

**Used by.** `CTA`, `Exams`, `Features`, `Hero` (via `Float`/`Reveal`/`stagger`/`riseItem`).

---

### 5.2 Lamp.tsx

**File:** `components/landing/Lamp.tsx` — [Lamp.tsx:5](Smart-Tutor-frontend/components/landing/Lamp.tsx#L5)

**Purpose.** A stylized anglepoise desk lamp drawn entirely in SVG (no "use client" — pure presentation), so the antigravity float and glow are fully controllable. Cool metal frame, warm glowing head, and a soft amber light cone spilling down-right.

**Props.** `{ className?: string }` (applied to the root `<svg>`).

**Composition.** `viewBox="0 0 360 440"`, `aria-hidden`. Defines gradients (`metal`, `metalDark`, `shade`, radial `bulb`, `cone`) and a Gaussian-blur `soft` filter, then draws: the light cone first (so the lamp sits atop it), the base ellipses + neck, two arm segments (lower base→elbow, upper elbow→head), three joints, the rotated shade with a warm rim, and the glowing bulb (radial gradient + a bright core circle). No state, no hooks.

**Used by.** `Hero` (large, with `drop-shadow` glow inside a `Float`) and `CTA` (small floating watermark).

---

### 5.3 Nav.tsx

**File:** `components/landing/Nav.tsx` — [Nav.tsx:8](Smart-Tutor-frontend/components/landing/Nav.tsx#L8)

**Purpose.** Fixed top nav for the marketing site, with a scroll-aware background and Clerk-aware auth buttons.

**Props.** None.

**State / hooks.** `const [scrolled, setScrolled] = useState(false)` [Nav.tsx:9](Smart-Tutor-frontend/components/landing/Nav.tsx#L9); a `useEffect` [Nav.tsx:10](Smart-Tutor-frontend/components/landing/Nav.tsx#L10) attaches a passive `scroll` listener that sets `scrolled = window.scrollY > 24`, calls it once on mount, and cleans up on unmount.

**Render.** A `motion.header` (entry: `opacity 0→1`, `y -16→0`, `ease EASE`) `fixed inset-x-0 top-0 z-50`. When `scrolled` it gains a bordered, blurred translucent background; otherwise transparent. Contains: the Lumos logo (anchor `#top`), in-page anchor links (`#features`, `#exams`, `#cta`), and the auth cluster using Clerk's `<SignedOut>` (Sign in + "Start Your Prep") and `<SignedIn>` (Dashboard link + `<UserButton afterSignOutUrl="/">`).

**Used by.** `app/page.tsx`.

---

### 5.4 Hero.tsx

**File:** `components/landing/Hero.tsx` — [Hero.tsx:20](Smart-Tutor-frontend/components/landing/Hero.tsx#L20)

**Purpose.** The landing hero — a two-column grid: marketing copy on the left, a glowing floating SVG lamp with drifting "doubt" formulas on the right.

**Props.** None.

**Constants.**
- `EXAMS = ["JEE","NEET","UPSC","CAT"]` [Hero.tsx:9](Smart-Tutor-frontend/components/landing/Hero.tsx#L9) → the exam badge row.
- `DOUBTS` [Hero.tsx:12](Smart-Tutor-frontend/components/landing/Hero.tsx#L12) — five real-syllabus formulas (`∫ e^{-x²} dx`, `C₆H₁₂O₆ + O₂ →`, `Article 21`, `∂v/∂t = a`, `DI · LR set`), each with absolute `x`/`y` position, float `amp`/`dur`/`delay`, and a color `tone`.

**Render.** The copy column is a `motion.div` with `variants={stagger}` + `initial="hidden" animate="show"`, and each child (`riseItem`) staggers in: an amber pill badge, the `<h1>` ("Crack the exam, one solved doubt at a time."), a paragraph, two CTA `<Link>`s ("Start Your Prep" → `/sign-up`, "Test the Brain" → `/simulator`), and the "Built for JEE/NEET/UPSC/CAT" badge row. The lamp stage is a `motion.div` (scale-in) with layered amber blur glows, a `dotgrid`, a `<Float amplitude=16 duration=7 rotate=1.5>` wrapping `<Lamp>`, and the `DOUBTS` mapped to absolutely-positioned `<Float>`-wrapped formula pills.

**Used by.** `app/page.tsx`.

---

### 5.5 Features.tsx

**File:** `components/landing/Features.tsx` — [Features.tsx:32](Smart-Tutor-frontend/components/landing/Features.tsx#L32)

**Purpose.** The three-up "why aspirants choose Lumos" feature grid.

**Props.** None.

**Constant.** `FEATURES` [Features.tsx:6](Smart-Tutor-frontend/components/landing/Features.tsx#L6) — three entries `{icon, title, blurb, accent}`:
- **Instant Doubt Solving** (`MessagesSquare`, `--amber`).
- **Syllabus-Aligned** (`Target`, `--cyan`).
- **Always Available** (`MoonStar`, `--violet`).

**Render.** A `<Reveal>` header, then a 3-col grid where each card is wrapped `<Reveal delay={i*0.12}>` → `<Float amplitude={8} duration={6.5+i} delay={i*0.5}>`. Each card is a glass `<article>` with a hover lift (`-translate-y-1.5`), an accent glow wash that fades in on hover, an accent icon tile (`color-mix(in srgb, accent 14%, transparent)`), the title, and the blurb. The per-card `duration: 6.5 + i` and `delay: i*0.5` keep the floaters out of phase.

**Used by.** `app/page.tsx`.

---

### 5.6 Exams.tsx

**File:** `components/landing/Exams.tsx` — [Exams.tsx:40](Smart-Tutor-frontend/components/landing/Exams.tsx#L40)

**Purpose.** The four-up exam grid — one card per supported exam family.

**Props.** None.

**Constant.** `EXAMS` [Exams.tsx:5](Smart-Tutor-frontend/components/landing/Exams.tsx#L5) — four entries `{code, name, accent, tint, focus[], blurb}`:
- **JEE / Engineering** (amber) — Physics, Chemistry, Mathematics.
- **NEET / Medical** (cyan) — Biology, Chemistry, Physics.
- **UPSC / Civil Services** (violet) — Polity, History, Geography.
- **CAT / Management** (rose) — Quant, DILR, VARC.

**Render.** A centered `<Reveal>` header, then a responsive grid (`sm:grid-cols-2 lg:grid-cols-4`) where each card is `<Reveal delay={i*0.1}>` → `<Float amplitude={8} duration={6.5+i} delay={i*0.4}>`. Each `<article>` uses a tinted top gradient (`linear-gradient(180deg, tint, transparent 70%)`), the exam code at 4xl in the accent color (scales 105% on hover), the category name, the blurb, and the focus subjects as bordered chips.

**Used by.** `app/page.tsx`.

---

### 5.7 CTA.tsx

**File:** `components/landing/CTA.tsx` — [CTA.tsx:7](Smart-Tutor-frontend/components/landing/CTA.tsx#L7)

**Purpose.** The closing call-to-action band.

**Props.** None.

**Render.** A `<Reveal>`-wrapped rounded panel with a warm radial wash and a small floating `<Lamp>` watermark (`<Float amplitude={12} duration={7}>`, `opacity-30`, desktop-only). Center copy: an eyebrow ("Your rank is waiting"), an `<h2>` ("Stop stalling on doubts. Start cracking it."), a paragraph naming JEE/NEET/UPSC/CAT, and two CTA `<Link>`s — "Start Your Prep" (`/sign-up`, `btn-primary`) and "Test the Brain" (`/simulator`, `btn-cyan`).

**Used by.** `app/page.tsx`.

---

### 5.8 Footer.tsx

**File:** `components/landing/Footer.tsx` — [Footer.tsx:1](Smart-Tutor-frontend/components/landing/Footer.tsx#L1)

**Purpose.** The site footer. The only landing component **without** "use client" (pure server-renderable presentation).

**Props.** None. **State/hooks.** None.

**Render.** A hairline-bordered `<footer>` with the Lumos dot + wordmark + "the smart tutor lamp" tagline, and a copyright that computes the year live via `new Date().getFullYear()` [Footer.tsx:10](Smart-Tutor-frontend/components/landing/Footer.tsx#L10).

**Used by.** `app/page.tsx`.

---

## 6. Algorithms Reference

This section collects the non-trivial logic, with parameters and constants quoted from the code.

### 6.1 Catmull-Rom → Bézier smoothing (`smoothPath`)
For an ordered list of points, each interior segment between `p1=pts[i]` and `p2=pts[i+1]` uses neighbors `p0=pts[i-1]` (or `p1`) and `p3=pts[i+2]` (or `p2`) to compute Bézier control points:
- `c1 = p1 + (p2 - p0)/6`
- `c2 = p2 - (p3 - p1)/6`

The `/6` is the standard Catmull-Rom tension. See [charts.tsx:19](Smart-Tutor-frontend/components/app/charts.tsx#L19).

### 6.2 Area-timeline point mapping
`max = Math.max(1, ...values)` (avoids ÷0 on all-zero series). `x = padX + (i/(n-1))*innerW` (or center when `n≤1`); `y = padTop + innerH - (value/max)*innerH`. Points only get a visible dot (radius 3) when `value > 0`. See [charts.tsx:54](Smart-Tutor-frontend/components/app/charts.tsx#L54).

### 6.3 Donut arc layout
Per slice: `frac = value/total`, `len = frac*C` where `C = 2πr`; rendered with `stroke-dasharray="len (C-len)"` and `stroke-dashoffset=-acc`; `acc += len` per slice. SVG rotated `-90°` so the first slice starts at 12 o'clock; center label counter-rotated `+90°`. See [charts.tsx:145](Smart-Tutor-frontend/components/app/charts.tsx#L145).

### 6.4 Journey total-time selection
`hasUpload = clientSteps.some(s => s.step==="upload")`. If `hasUpload`: `total = Σ clientSteps` (server work is nested inside the upload bar). Else `total = Σ clientSteps + Σ serverSteps`. This is what makes the live simulator view and the persisted admin view both correct from the same `timeline` shape. See [JourneyBreakdown.tsx:108](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L108).

### 6.5 Bounding-box validation + overlay mapping
`validBbox` requires a 4-number array, each in `[0,1000]` and finite, with `ymin<ymax && xmin<xmax`. The overlay then maps 0–1000 to 0–100 % by dividing each coordinate by 10: `top=ymin/10%`, `left=xmin/10%`, `width=(xmax-xmin)/10%`, `height=(ymax-ymin)/10%`. The `w-fit` wrapper guarantees the percentages map 1:1 onto image pixels. See [TraceView.tsx:49](Smart-Tutor-frontend/components/app/TraceView.tsx#L49) and [TraceView.tsx:213](Smart-Tutor-frontend/components/app/TraceView.tsx#L213).

### 6.6 Phase coloring thresholds
`phaseColor`: error→rose, skipped→muted, tier2/tier3→amber (escalated), `ms > SLOW_MS[phase] ?? 3000`→amber, else cyan. `SLOW_MS` budgets are per-phase (e.g. Whisper 800 ms, tier-1 5 s, tier-3 25 s). See [TraceView.tsx:78](Smart-Tutor-frontend/components/app/TraceView.tsx#L78).

### 6.7 Token→words estimate
`tokWords(tok) = round(tok * 0.75)` (1 token ≈ 0.75 English words) — shown so a non-technical admin reads approximate word sizes; exact counts live in the tooltip. See [TraceView.tsx:42](Smart-Tutor-frontend/components/app/TraceView.tsx#L42).

### 6.8 Relative-time formatting
Two variants exist with **different rollover thresholds**: AnalyticsView's `relTime` rolls to a calendar date after **7 days** [AnalyticsView.tsx:296](Smart-Tutor-frontend/components/app/AnalyticsView.tsx#L296); AdminView's `relTime` rolls over after **30 days** [AdminView.tsx:100](Smart-Tutor-frontend/components/app/AdminView.tsx#L100). Both use minute/hour granularity below the threshold.

### 6.9 Pairing-code extraction
`extractPairingCode` (delegated to `lib/pairing-code.ts`): URL → `/pair/CODE` path segment → `?code=` param → bare `code=` fragment → bare 6–8 alphanumerics; `normalize()` strips whitespace/hyphens and uppercases. See [pairing-code.ts:6](Smart-Tutor-frontend/lib/pairing-code.ts#L6).

### 6.10 Byte / number formatters
`fmtBytes` (GB/MB/KB/B thresholds 1,073,741,824 / 1,048,576 / 1024) [AdminView.tsx:248](Smart-Tutor-frontend/components/app/AdminView.tsx#L248); `fmtTok` (M/k thresholds 1e6 / 1e3) [AdminView.tsx:94](Smart-Tutor-frontend/components/app/AdminView.tsx#L94); `fmtUsd` (4-decimal under $0.01, else 2) [AdminView.tsx:84](Smart-Tutor-frontend/components/app/AdminView.tsx#L84); `fmtCost` (5-decimal under $0.01, else 4) [JourneyBreakdown.tsx:36](Smart-Tutor-frontend/components/app/JourneyBreakdown.tsx#L36).

---

## 7. Configuration, Constants & Environment

### Component-local constants
| Constant | File | Value / Effect |
| --- | --- | --- |
| `RANGES` | AdminView, AnalyticsView | `[7,14,30]` day-range toggle; default `14` |
| `MEDIA_RANGES` | AdminView | `[7,14,30,60]` media-deletion age toggle; default `14` |
| `DIFFICULTY_COLORS` | AdminView, AnalyticsView | `easy=#5fe3d2, medium=#ffb84d, hard=#ff9bb0, unknown=#5c5c72` |
| `STATUSES` | AdminView TurnsTab | turn-status filter options incl. `bad_json, truncated, safety_block` |
| `TABS` / `TabKey` | AdminView | 11 admin tabs (incl. Analytics, added 2026-07-11) |
| `ANALYTICS_RANGES`, `STEP_META`, `TIER_COLORS` | AdminView AnalyticsTab | range pills, pipeline-step grouping, per-tier accent colors |
| `PALETTE` | charts | 6-color categorical palette; cycled by `colorFor` |
| `STEP_META`, `CLIENT_TINT`, `SERVER_TINT`, `BAR_STYLE` | JourneyBreakdown | step labels, amber/cyan tints, prebuilt bar styles |
| `PHASE_LABELS`, `SLOW_MS` | TraceView | phase display names + per-phase slow budgets |
| `EXAMS`, `FEATURES`, `DOUBTS`, `EASE`, `stagger`, `riseItem` | landing | static content + motion variants |

### Hook config (the data the components rely on — in `lib/*`)
- **Admin polling** [admin.ts:286](Smart-Tutor-frontend/lib/admin.ts#L286): `useAdminOverview`/`useAdminDevices`/`useAdminModelEval` use `refetchInterval: 60_000` (matched to the backend's 45 s Redis cache) and `retry:false` (a 403 must not be retried). `useTurnTrace` uses `staleTime: 5*60_000` + `enabled: ...&& !!turnId` (idle until a drawer opens). `useAdminMedia` `staleTime: 30_000`.
- **Profile polling** [profile.ts:99](Smart-Tutor-frontend/lib/profile.ts#L99): `useAnalytics`/`useAnalyticsDetail` use `refetchInterval: 60_000`; `useMe`/`useProfile` use `staleTime: 60_000` (`IDENTITY_STALE_MS`).
- **Latency budgets** [log.ts:35](Smart-Tutor-frontend/lib/log.ts#L35) — used by `BootDiagnostics`: `longTask:120`, `route:800` (and inline `2500/5000` for nav-load, `2500/4000` for LCP, `120/300` for long tasks).

### Environment variables
- **`NEXT_PUBLIC_VERBOSE`** (`"0"`/`"1"`) and **`NODE_ENV`** [log.ts:45](Smart-Tutor-frontend/lib/log.ts#L45): gate whether `BootDiagnostics`' logging actually prints. Verbose is on automatically in development, off in production unless `NEXT_PUBLIC_VERBOSE=1` or runtime `localStorage.LUMOS_VERBOSE="1"` / `window.__LUMOS_VERBOSE=true`. Errors are always shown.
- The components themselves read **no** env vars directly; backend base URL/Clerk keys live in `lib/api.ts` and the Clerk provider.

---

## 8. Edge Cases, Errors, Timeouts & Fallbacks

| Component | Edge case | Handling |
| --- | --- | --- |
| AppHeader | `me` loading / non-admin | Admin link hidden; route also gated server-side |
| AnalyticsCards / AnalyticsView | backend down (`isError`) | quiet inline glass notice, never a crash |
| AnalyticsCards | empty `subject_mix` | subjects card omitted entirely |
| AdminView (all tabs) | 403 NOT_ADMIN | `ErrorState` → "Admin access required" (via `isForbidden`); `retry:false` so the 403 isn't retried |
| AdminView (all tabs) | other backend error | generic "Couldn't reach the Lumos backend" notice |
| AdminView ModelsTab | `models.length === 0` | prompt to use simulator picker / Compare mode |
| AdminView MediaCard | media endpoint missing (`isError`) | **returns `null`** (hidden quietly) |
| AdminView MediaCard | cleanup mutation throws | synthesizes a failure `result` with all counts 0 and a clear message |
| AdminView MediaCard | bounded deletion | `remaining_* > 0` → banner says "run it again to continue" |
| AdminView TurnRow | no `timeline` | Journey toggle hidden (`hasJourney` false) |
| AdminView TurnRow | trace drawer closed | `TraceView` not mounted → no fetch (80-row feed = 0 extra requests) |
| TraceView | 404 trace | "No trace was recorded… predates pipeline tracing, or tracing is disabled" |
| TraceView | invalid/absent bbox | `validBbox` → `null` → plain image, layout untouched |
| TraceView | bad LaTeX | `BlockMath renderError` falls back to raw LaTeX in rose |
| TraceView | missing media/transcript | quiet `ImageOff` placeholder / "no transcript captured" italics |
| JourneyBreakdown | empty `timeline` | "No step timing was recorded for this answer." |
| JourneyBreakdown | tiny step | bar floored at `Math.max(2, …)%` so it stays visible |
| QrScanner | camera denied | `denied` state → instructions to allow / upload / type |
| QrScanner | non-secure / no camera | `error` state with the thrown message; upload + manual still work |
| QrScanner | double decode | `firedRef` one-shot guard prevents double `onCode` |
| QrScanner | upload no-QR | "No pairing QR found in that image…"; object URL always revoked |
| QrScanner | unmount mid-scan | cleanup `useEffect` stops tracks + RAF |
| ConfirmDialog | busy | Escape, click-outside, and both buttons all disabled while `busy` |
| ErrorPanel | transient code | retry button only for `NETWORK`/`UNKNOWN`; otherwise just the action hint |
| BootDiagnostics | unsupported `PerformanceObserver` type | try/catch per observer → simply logs less, never throws |
| motion (all) | `prefers-reduced-motion` | `Reveal` skips offset; `Float` renders a static `<div>` |

There are no explicit request timeouts in these components — timeout behavior is delegated to `lib/api.ts` and the backend; the components only react to the resolved `isError`/`isLoading`/`data` states from TanStack Query.

---

## 9. Integration Points & Cross-References

### What these components call (downstream)

- **`lib/profile.ts`** — `useMe` (AppHeader), `useAnalytics` (AnalyticsCards), `useAnalyticsDetail` (AnalyticsView). Hits `GET /api/frontend/me`, `/api/frontend/analytics`, `/api/frontend/analytics/detail?days=`.
- **`lib/admin.ts`** — `useAdminOverview, useAdminModelEval, useAdminUsers, useAdminDevices, useAdminSessions, useAdminTurns, useAdminEvents, useAdminMedia, useMediaCleanup, useTurnTrace` (AdminView + TraceView). Hits `GET /api/frontend/admin/*` and `POST /api/frontend/admin/media/cleanup`.
- **`lib/devices.ts`** — `FriendlyError`/`friendlyError` consumed by `ErrorPanel`; `ConfirmDialog` is driven by `useUnlinkDevice`/`useRenameDevice` in the devices page.
- **`lib/pairing-code.ts`** — `extractPairingCode` (QrScanner).
- **`lib/models.ts`** — `TimelineStep` type (JourneyBreakdown).
- **`lib/api.ts`** — `ApiError` (AdminView/TraceView 403/404 branching), `useApi` (all hooks).
- **`lib/log.ts`** — `BUDGET`, `log` (BootDiagnostics).
- **`charts.tsx`** — consumed by both AnalyticsView and AdminView.
- **`jsqr`** (QrScanner), **`react-katex` + `katex` CSS** (TraceView), **`framer-motion`** (charts, AdminView, AnalyticsView, ConfirmDialog, all landing motion), **`@clerk/nextjs`** (AppHeader `UserButton`, Nav `SignedIn/SignedOut/UserButton`), **`lucide-react`** (icons throughout), **`next/link`** + **`next/navigation`** (routing).

### What renders these components (upstream)

| Component | Mounted by |
| --- | --- |
| AppHeader | dashboard, analytics, admin, connect, devices, simulator pages |
| AnalyticsCards | `app/dashboard/page.tsx` |
| AnalyticsView | `app/analytics/page.tsx` |
| AdminView | `app/admin/page.tsx` |
| charts (6 exports) | AnalyticsView, AdminView |
| JourneyBreakdown | AdminView TurnRow, `app/simulator/page.tsx` |
| TraceView | AdminView TurnRow |
| QrScanner | `app/connect/page.tsx` |
| ConfirmDialog | `app/devices/page.tsx`, AdminView MediaCard |
| ErrorPanel | `app/pair/[code]/page.tsx` |
| BootDiagnostics | `app/providers.tsx` (global) |
| Nav, Hero, Features, Exams, CTA, Footer | `app/page.tsx` |
| Lamp | Hero, CTA |
| motion (Reveal/Float/stagger/riseItem) | Hero, Features, Exams, CTA |

### Cross-system references

- **Backend (Python FastAPI).** The wire types mirror `app/schemas/admin.py`, `app/schemas/admin_pilot.py`, `app/schemas/insights.py`, `app/schemas/pilot.py`, and `app/schemas/frontend.py`. The admin endpoints are gated server-side (the page uses `requireOnboardedAndAdmin`; every `/api/frontend/admin/*` route re-checks `require_admin`) and return 403 NOT_ADMIN to non-admins — exactly the case `ErrorState`/`isForbidden` handle. Writes from AdminView: `MediaCard` cleanup, OTA publish/delete, and pilot report-status.
- **Firmware / Device.** `QrScanner` decodes the QR the **lamp renders on its screen** (a pairing URL `…/pair/CODE`); `TraceView` plays back the `raw_audio_url` "as the server received it" from the lamp and shows the camera frame the lamp captured (raw vs OpenCV/PIL-enhanced) plus the model's grounding box. `AdminView` device/turn status reflects lamp online state (heartbeat) and the tiered-escalation + Claude-fallback brain.
- **Web Simulator.** `JourneyBreakdown` is shared with the simulator (live path with `renderMs`); `TraceView`'s `SourceBadge` distinguishes `source === "simulator"` from a real lamp; the ModelsTab bench is populated by the simulator's model picker / Compare mode.
- **Database (Supabase/Postgres + Storage).** Admin counts/rollups derive from the queries in `SUPABASE_QUERIES.md`; per-turn media lives in Supabase Storage and `MediaCard` reports its byte/object usage and runs the bounded deletion pass.

---

## 10. Mermaid Diagrams

### 10.1 Admin Turns → Journey/Trace drawer (sequence)

```mermaid
sequenceDiagram
    participant A as Admin
    participant TV as AdminView (TurnsTab)
    participant TR as TurnRow (memo)
    participant H as lib/admin hooks
    participant BE as Backend /api/frontend/admin
    participant JB as JourneyBreakdown
    participant TC as TraceView

    A->>TV: open Turns tab (status filter)
    TV->>H: useAdminTurns({limit:80, status})
    H->>BE: GET /admin/turns?limit=80&status=
    BE-->>H: { rows: AdminTurnRow[] }
    H-->>TV: data
    TV->>TR: render 80 rows (memoized)
    A->>TR: click "Journey" (hasJourney only)
    TR->>JB: <JourneyBreakdown timeline tokens cost>
    JB-->>A: client/server waterfall (total via hasUpload rule)
    A->>TR: click "Trace"
    TR->>TC: mount <TraceView turnId> (lazy)
    TC->>H: useTurnTrace(turnId) [enabled now]
    H->>BE: GET /admin/turns/{id}/trace
    alt 404
        BE-->>TC: 404 → "no trace recorded"
    else ok
        BE-->>TC: AdminTurnTrace
        TC-->>A: audio + raw/enhanced image + bbox + phase waterfall + KaTeX
    end
```

### 10.2 QrScanner decode flow (flowchart)

```mermaid
flowchart TD
    Start([QrScanner mounted, state=idle]) --> Choice{input path}
    Choice -->|camera| Enable[enable: getUserMedia env 720p]
    Enable -->|denied/SecurityError| Denied[state=denied]
    Enable -->|other error| Err[state=error + message]
    Enable -->|ok| Scan[state=scanning, RAF scanLoop]
    Scan --> Frame[drawImage to canvas, getImageData]
    Frame --> JsQR[jsQR dontInvert]
    JsQR -->|no code| Frame
    JsQR -->|code| Fire
    Choice -->|upload| OnFile[onFile: decode img, jsQR]
    OnFile -->|no code| UpErr[error: no QR found]
    OnFile -->|code| Fire
    Choice -->|type| Manual[submitManual]
    Manual -->|invalid| MErr[error: invalid code]
    Manual -->|valid| Fire
    Fire{extractPairingCode and not fired?}
    Fire -->|null/already fired| NoOp[return false]
    Fire -->|ok| Stop[firedRef=true, stop camera, onCode code]
    Stop --> Nav[parent router.push /pair/code]
```

### 10.3 Landing page render & motion (flowchart)

```mermaid
flowchart LR
    Home[app/page.tsx] --> Nav
    Home --> Hero
    Home --> Features
    Home --> Exams
    Home --> CTA
    Home --> Footer
    Hero --> Lamp1[Lamp]
    Hero --> M1[motion: stagger/riseItem/Float]
    CTA --> Lamp2[Lamp]
    CTA --> M2[motion: Reveal/Float]
    Features --> M3[motion: Reveal/Float]
    Exams --> M4[motion: Reveal/Float]
    M1 -.reduced motion.-> Static1[no offset / static div]
    M3 -.reduced motion.-> Static2[no offset / static div]
```

---

### Appendix — file index

| File | Lines (approx) | Family | Client? |
| --- | --- | --- | --- |
| `components/app/AppHeader.tsx` | 103 | app | yes |
| `components/app/AnalyticsCards.tsx` | 99 | app | yes |
| `components/app/AnalyticsView.tsx` | 307 | app | yes |
| `components/app/AdminView.tsx` | 981 | app | yes |
| `components/app/charts.tsx` | 307 | app | yes |
| `components/app/JourneyBreakdown.tsx` | 169 | app | yes |
| `components/app/TraceView.tsx` | 522 | app | yes |
| `components/app/QrScanner.tsx` | 206 | app | yes |
| `components/app/ConfirmDialog.tsx` | 95 | app | yes |
| `components/app/ErrorPanel.tsx` | 37 | app | yes |
| `components/app/BootDiagnostics.tsx` | 108 | app | yes |
| `components/landing/motion.tsx` | 82 | landing | yes |
| `components/landing/Lamp.tsx` | 79 | landing | no |
| `components/landing/Nav.tsx` | 68 | landing | yes |
| `components/landing/Hero.tsx` | 112 | landing | yes |
| `components/landing/Features.tsx` | 67 | landing | yes |
| `components/landing/Exams.tsx` | 87 | landing | yes |
| `components/landing/CTA.tsx` | 43 | landing | yes |
| `components/landing/Footer.tsx` | 14 | landing | no |
