# Frontend — Overview, Stack & Architecture

The Smart Tutor Lamp ("Lumos") web frontend is a **Next.js 14 App-Router** application that is the human-facing surface of the system: users sign in, complete onboarding, view dashboards/analytics, pair their physical ESP32 lamp via an in-browser QR scanner, and exercise the AI brain through a web simulator. Authentication is delegated entirely to **Clerk** (human sessions only — never device secrets), styling uses **Tailwind CSS** with a hand-tuned dark "luminous nocturne" theme, and all backend data flows through a single authenticated **React Query** layer that attaches the Clerk JWT to every call to the unified Python FastAPI backend. This document is the definitive reference for the frontend's stack, configuration, global wiring (root layout, providers, middleware), route structure, and the end-to-end data-flow from the backend API into the rendered UI.

---

## Table of Contents

1. [Purpose & Responsibility](#1-purpose--responsibility)
2. [Technology Stack](#2-technology-stack)
3. [Repository & Route Structure](#3-repository--route-structure)
4. [Build & Type Configuration](#4-build--type-configuration)
   - [4.1 package.json](#41-packagejson)
   - [4.2 tsconfig.json](#42-tsconfigjson)
   - [4.3 tailwind.config.ts](#43-tailwindconfigts)
   - [4.4 postcss.config.js](#44-postcssconfigjs)
   - [4.5 next-env.d.ts](#45-next-envdts)
   - [4.6 types/react-katex.d.ts](#46-typesreact-katexdts)
5. [The Root Layout (`app/layout.tsx`)](#5-the-root-layout-applayouttsx)
6. [Global Providers (`app/providers.tsx`)](#6-global-providers-appproviderstsx)
7. [Middleware-Based Route Protection (`middleware.ts`)](#7-middleware-based-route-protection-middlewarets)
8. [The Two-Layer Auth Model](#8-the-two-layer-auth-model)
9. [The Data Flow: Backend API → UI](#9-the-data-flow-backend-api--ui)
10. [Diagnostics & Instrumentation Subsystem](#10-diagnostics--instrumentation-subsystem)
11. [Configuration & Environment Variables](#11-configuration--environment-variables)
12. [Edge Cases, Errors, Timeouts, Retries, Fallbacks](#12-edge-cases-errors-timeouts-retries-fallbacks)
13. [Integration Points (Cross-References)](#13-integration-points-cross-references)
14. [Diagrams](#14-diagrams)
15. [File-by-File / Function-by-Function Appendix](#15-file-by-file--function-by-function-appendix)

---

## 1. Purpose & Responsibility

Per the project's `RUN.md`, the frontend is *"the web app users sign into to onboard, see analytics, and **pair their ESP32 lamp** (in-app QR scanner). It talks to the unified Python backend over one base URL"* ([RUN.md:3-6](../../Smart-Tutor-frontend/RUN.md#L3)).

The frontend's responsibilities are:

- **Identity / sessions** — sign-in, sign-up, OAuth (Google) via Clerk; first-run onboarding.
- **Dashboard & analytics** — render per-user rollups (lamps linked, questions asked, sessions, subject mix, latency percentiles, cost) pulled live from the backend Frontend Manager.
- **Device pairing** — scan the QR shown on the ESP32 lamp's TFT (`/connect`), or follow a deep-linked pairing code (`/pair/[code]`), then complete pairing against the backend.
- **The simulator** — a "web brain bench" (`/simulator`) that mirrors what the lamp sends (push-to-talk audio, optional text, a multi-image queue of up to 5 photos) to the backend `/api/frontend/ws` WebSocket ([RUN.md:8-11](../../Smart-Tutor-frontend/RUN.md#L8), [RUN.md:157-158](../../Smart-Tutor-frontend/RUN.md#L157)).
- **Admin** — a gated `/admin` view of all activity, restricted to user IDs on the backend `admins` table ([RUN.md:13](../../Smart-Tutor-frontend/RUN.md#L13)).

A **hard architectural boundary** is stated in the middleware comment: *"the frontend only ever handles human sessions — never device secrets or device JWTs"* ([middleware.ts:5-6](../../Smart-Tutor-frontend/middleware.ts#L5)). Device authentication (device JWTs, pairing secrets) lives in the firmware and backend, not here.

---

## 2. Technology Stack

All versions are pinned in `package.json` ([package.json:12-32](../../Smart-Tutor-frontend/package.json#L12)).

| Concern | Package | Version | Role |
| --- | --- | --- | --- |
| Framework | `next` | `14.2.35` | App Router, RSC, server actions, middleware |
| UI runtime | `react` / `react-dom` | `^18` | Component model |
| Auth | `@clerk/nextjs` | `^5.1.0` | Hosted-but-embedded auth (`<ClerkProvider>`, `clerkMiddleware`, `useAuth`) |
| Server state | `@tanstack/react-query` | `^5.100.14` | Caching, polling, retries for all backend reads/writes |
| Animation | `framer-motion` | `^12.40.0` | Landing-page motion |
| QR decode | `jsqr` | `^1.4.0` | In-browser QR scanning for lamp pairing |
| Math render | `katex` + `react-katex` | `^0.17.0` / `^3.1.0` | LaTeX preview of answers/equations |
| Icons | `lucide-react` | `^0.378.0` | Icon set used across the app shell |
| Styling | `tailwindcss` | `^3.4.3` | Utility CSS + custom theme |
| CSS pipeline | `postcss`, `autoprefixer` | `^8.4.38`, `^10.4.19` | Tailwind/PostCSS build |
| Types | `typescript` | `^5` | Strict TS |

There is **no** `next.config.js` in the repository root — the directory listing shows only `postcss.config.js`, `tailwind.config.ts`, and `tsconfig.json` as config files (confirmed by listing the repo root). Next therefore runs with its built-in defaults. There is also **no** ESLint config file in-repo (`next lint` would prompt to create one on first run).

The `RUN.md` summarises the stack as *"Next.js 14 (App Router) + Clerk auth + Tailwind"* ([RUN.md:3](../../Smart-Tutor-frontend/RUN.md#L3)) and requires **Node.js ≥ 18.17** (Next 14.2's floor) ([RUN.md:17](../../Smart-Tutor-frontend/RUN.md#L17)).

---

## 3. Repository & Route Structure

The `app/` directory uses the **App Router** with a **flat route layout — there are NO route groups** (no parenthesised `(group)` folders). The directory listing of `app/` is:

```
app/
├── layout.tsx              # root layout (ClerkProvider + Providers + fonts)
├── page.tsx                # "/" landing page (public)
├── providers.tsx           # client: React Query + BootDiagnostics
├── globals.css             # Tailwind layers + the Lumos theme
├── admin/                  # /admin   (gated: session + admin role) + loading.tsx
├── analytics/              # /analytics + loading.tsx
├── connect/                # /connect (QR scanner) + loading.tsx
├── dashboard/              # /dashboard + loading.tsx
├── devices/                # /devices + loading.tsx
├── onboarding/             # /onboarding (+ OnboardingForm.tsx)
├── pair/                   # /pair  and  /pair/[code]
├── personalize/            # /personalize (pilot: "how I learn best") + loading.tsx
├── sign-in/[[...sign-in]]/ # Clerk catch-all (also /sign-in/sso-callback)
├── sign-up/[[...sign-up]]/ # Clerk catch-all
├── survey/                 # /survey?kind=baseline|exit (pilot baseline/exit survey)
└── simulator/              # /simulator (web brain bench) + loading.tsx
```

> **Updated 2026-07-03** (frontend tip `ef07d7f`). Since the 2026-06-16 sync (`5ac12b8`) the app added a **pilot-program surface** (`/survey`, `/personalize`, per-answer feedback, a global "Report a problem" widget), a large **admin console expansion** (Pilot, Insights, and firmware-OTA tabs), and a set of Next.js **route-level `loading.tsx` skeletons** (perceived-latency work, see the repo-root `OPTIMIZATION.md`).

Supporting code lives outside `app/`:

- `lib/` — the data layer and utilities: `api.ts` (authenticated fetch), `profile.ts`, `devices.ts`, `models.ts`, `admin.ts` (typed React Query hooks), `pilot.ts` (pilot instrumentation: feedback/surveys/personalization/consent/reports), `auth-guard.ts` (server-only gates), `log.ts` (diagnostics), `onboarding.ts`, `pairing-code.ts`, `time.ts`, `useSimulatorCapture.ts`.
- `components/` — `components/landing/*` (public marketing page) and `components/app/*` (the authed app shell: `AppHeader`, `AnalyticsCards`, `AnalyticsView`, `AdminView`, `TraceView`, `QrScanner`, `BootDiagnostics`, `ConfirmDialog`, `ErrorPanel`, charts, plus the pilot/UX additions `SurveyView`, `PersonalizationView`, `PersonalizeCard`, `ReportProblem`, and the shared `PageSkeleton` used by every `loading.tsx`).
- `types/react-katex.d.ts` — an ambient module declaration.

### Route map

Reproduced from the `RUN.md` quick map ([RUN.md:147-158](../../Smart-Tutor-frontend/RUN.md#L147)):

| Route | Purpose |
| --- | --- |
| `/sign-in`, `/sign-up` | Clerk auth (custom pages, not the hosted portal) |
| `/onboarding` | First-run profile (name, phone, exam, prep) → backend + Clerk |
| `/dashboard` | Glass UI: stats, analytics, connect-lamp CTA |
| `/devices` | Manage linked lamps (rename / unlink / online status); pairing success lands here |
| `/connect` | In-app QR scanner to pair the ESP32 |
| `/pair`, `/pair/[code]` | Pairing confirmation; deep-link target; calls `complete-pairing` then → `/devices` |
| `/simulator` | Web "brain bench" — sends a multimodal turn to the backend `/api/frontend/ws` |
| `/personalize` | Pilot "how I learn best" — collect interests + answer-length + analogy preference (collection only) |
| `/survey` | Pilot baseline/exit survey (`?kind=baseline\|exit`); baseline also records pilot consent |
| `/admin` | All-activity admin view, gated to allowlisted user IDs (tabs: Overview, Pilot, Insights, Models, Users, Devices, Sessions, Turns, Events, OTA) |

The catch-all dynamic segments `[[...sign-in]]` / `[[...sign-up]]` are required so Clerk can render its own sub-routes — most importantly the OAuth callback **`/sign-in/sso-callback`** ([sign-in/page.tsx:4](../../Smart-Tutor-frontend/app/sign-in/%5B%5B...sign-in%5D%5D/page.tsx#L4)).

---

## 4. Build & Type Configuration

### 4.1 package.json

```json
"scripts": {
  "dev": "next dev",
  "dev:turbo": "next dev --turbo",
  "build": "next build",
  "start": "next start",
  "lint": "next lint"
}
```
([package.json:5-11](../../Smart-Tutor-frontend/package.json#L5))

- `dev` — standard dev server with hot reload (Webpack). `dev:turbo` runs the Turbopack dev server, recommended in `RUN.md` when the dev server feels slow ([RUN.md:184-187](../../Smart-Tutor-frontend/RUN.md#L184)).
- `build` — production compile **and type-check** ([RUN.md:88-89](../../Smart-Tutor-frontend/RUN.md#L88)).
- `start` — serves the production build on port 3000.
- The package is marked `"private": true` and `"name": "smart-tutor-lamp-web"` ([package.json:1-4](../../Smart-Tutor-frontend/package.json#L1)).

### 4.2 tsconfig.json

```jsonc
{
  "compilerOptions": {
    "target": "es5",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [{ "name": "next" }],
    "paths": { "@/*": ["./*"] }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
```
([tsconfig.json:1-27](../../Smart-Tutor-frontend/tsconfig.json#L1))

Key effects:

- **`"strict": true`** — full strict-mode type checking (no implicit `any`, strict null checks, etc.). This is why the data-layer hooks declare exact wire interfaces and the API client narrows error bodies.
- **`"paths": { "@/*": ["./*"] }`** — the `@/` alias maps to the repo root. Every internal import in the codebase uses it: `@/lib/log`, `@/lib/api`, `@/components/app/BootDiagnostics`, `@/lib/auth-guard`, etc. ([providers.tsx:10-11](../../Smart-Tutor-frontend/app/providers.tsx#L10), [BootDiagnostics.tsx:5](../../Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L5)).
- **`"moduleResolution": "bundler"`** — modern resolution matching Next's bundler.
- **`"jsx": "preserve"`** — JSX is left for Next/SWC to transform.
- **`"plugins": [{ "name": "next" }]`** — enables the Next TS plugin for typed routes / RSC checks.
- **`"target": "es5"`** + `"incremental": true` — `incremental` produces `tsconfig.tsbuildinfo` (present at the repo root; `RUN.md` notes deleting `.next/` and `tsconfig.tsbuildinfo` to clear stale build state) ([RUN.md:172-173](../../Smart-Tutor-frontend/RUN.md#L172)).
- **`include`** pulls in `next-env.d.ts` and `.next/types/**/*.ts` (Next's generated route types).

### 4.3 tailwind.config.ts

```ts
const config: Config = {
  darkMode: "class",
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: { extend: { fontFamily: {...}, colors: {...} } },
  plugins: [],
};
```
([tailwind.config.ts:3-34](../../Smart-Tutor-frontend/tailwind.config.ts#L3))

- **`darkMode: "class"`** — dark mode toggles on a `class`. The root `<html>` is hard-coded `className="dark"` ([layout.tsx:90](../../Smart-Tutor-frontend/app/layout.tsx#L90)), so the app is always dark.
- **`content`** globs cover `pages/`, `components/`, `app/`, and importantly `lib/` (utility class strings used in hooks/helpers are scanned so Tailwind doesn't purge them).
- **`fontFamily`** maps Tailwind families to CSS variables set by `next/font` in the layout: `display → var(--font-display)`, `sans → var(--font-sans)`, `mono → var(--font-mono)`, each with a fallback stack ([tailwind.config.ts:13-17](../../Smart-Tutor-frontend/tailwind.config.ts#L13)).
- **`colors`** define the brand palette consumed by utilities like `bg-amber`, `text-cyan`, `bg-rose/10`:

  | Token | Value | Notes |
  | --- | --- | --- |
  | `void` | `#07070d` | page background base |
  | `paper` | `#f4efe6` | primary text |
  | `amber.DEFAULT` | `#ffb84d` | brand accent / `colorPrimary` in Clerk |
  | `amber.soft` | `#ffd89b` | |
  | `amber.deep` | `#d9851f` | |
  | `cyan.DEFAULT` | `#5fe3d2` | "machine intelligence" accent |
  | `violet.DEFAULT` | `#b9a3ff` | |
  | `rose.DEFAULT` | `#ff9bb0` | error/sign-out accent |

  ([tailwind.config.ts:18-29](../../Smart-Tutor-frontend/tailwind.config.ts#L18))

- **`plugins: []`** — no Tailwind plugins; all component styles (`.glass`, `.btn-primary`, `.aurora`, etc.) are hand-authored CSS in `app/globals.css` under `@layer components`/`@layer utilities`.

These same hex values are duplicated as raw CSS custom properties in `app/globals.css` `:root` ([globals.css:11-30](../../Smart-Tutor-frontend/app/globals.css#L11)) and a third time inside the Clerk `appearance.variables` in the layout — keep all three in sync when re-theming.

### 4.4 postcss.config.js

```js
module.exports = {
  plugins: { tailwindcss: {}, autoprefixer: {} },
};
```
([postcss.config.js:1-6](../../Smart-Tutor-frontend/postcss.config.js#L1))

The standard Tailwind + Autoprefixer PostCSS chain. Tailwind processes the `@tailwind base/components/utilities` directives in `globals.css`; Autoprefixer adds vendor prefixes (the CSS uses both `-webkit-backdrop-filter` and `backdrop-filter`, for example).

### 4.5 next-env.d.ts

```ts
/// <reference types="next" />
/// <reference types="next/image-types/global" />
// NOTE: This file should not be edited
```
([next-env.d.ts:1-5](../../Smart-Tutor-frontend/next-env.d.ts#L1))

Auto-generated by Next; pulls in Next's ambient types and image-import types. Not hand-edited.

### 4.6 types/react-katex.d.ts

`react-katex` ships a `.d.ts` but doesn't expose it via `package.json` `"types"`, so TypeScript can't resolve it. This file declares the slice the app uses ([react-katex.d.ts:1-17](../../Smart-Tutor-frontend/types/react-katex.d.ts#L1)):

```ts
declare module "react-katex" {
  interface MathComponentProps {
    math?: string;
    children?: ReactNode;
    errorColor?: string;
    renderError?: (error: Error) => ReactNode;
    settings?: Record<string, unknown>;
    as?: string | ComponentType<unknown>;
  }
  export const InlineMath: ComponentType<MathComponentProps>;
  export const BlockMath: ComponentType<MathComponentProps>;
}
```

Effect: `InlineMath`/`BlockMath` can be imported with typed props (used to preview LaTeX answers/equations). Without this shim, the strict TS build would error on the untyped import.

---

## 5. The Root Layout (`app/layout.tsx`)

`app/layout.tsx` is a **Server Component** (no `"use client"`). It is the single entry point that wraps every route. Its responsibilities, in order:

**1. Font loading via `next/font/google`** ([layout.tsx:2](../../Smart-Tutor-frontend/app/layout.tsx#L2), [layout.tsx:8-21](../../Smart-Tutor-frontend/app/layout.tsx#L8)):

| Variable | Font | Weights / styles | Role |
| --- | --- | --- | --- |
| `--font-display` | `Fraunces` | 400/500/600/700, normal + italic | Headings ("a soft, optical-sized modern serif") |
| `--font-sans` | `Hanken_Grotesk` | 300/400/500/600/700 | Body ("a warm, humanist grotesque") |
| `--font-mono` | `JetBrains_Mono` | default | "Technical labels & floating equations" |

Each call returns a `.variable` class name that injects a CSS custom property. These map to the Tailwind `fontFamily` tokens (§4.3) and to the `globals.css` `h1,h2,h3 { font-family: var(--font-display)... }` and `.label`/`.mono` rules.

**2. Page metadata** (`export const metadata`) — title *"Lumos — the smart tutor lamp that thinks"* and a description for the multimodal AI tutor ([layout.tsx:23-27](../../Smart-Tutor-frontend/app/layout.tsx#L23)).

**3. The `<ClerkProvider>` wrapper** ([layout.tsx:31-89](../../Smart-Tutor-frontend/app/layout.tsx#L31)) — the outermost runtime wrapper around the whole tree. Its props configure all Clerk-driven navigation:

| Prop | Value | Effect |
| --- | --- | --- |
| `signInUrl` | `/sign-in` | use the app's own sign-in page |
| `signUpUrl` | `/sign-up` | use the app's own sign-up page |
| `afterSignOutUrl` | `/` | return to the public landing page on sign-out |
| `signUpForceRedirectUrl` | `/onboarding` | **first-time sign-ups always land on onboarding** |
| `signInFallbackRedirectUrl` | `/dashboard` | returning sign-ins fall back to the dashboard |

The comment makes the policy explicit: *"First-time sign-up always lands on the forced onboarding form; returning sign-ins fall back to the dashboard."* ([layout.tsx:35-38](../../Smart-Tutor-frontend/app/layout.tsx#L35)). These match the `NEXT_PUBLIC_CLERK_*` env vars documented in `RUN.md` ([RUN.md:60-64](../../Smart-Tutor-frontend/RUN.md#L60)).

**4. Clerk `appearance` theming** ([layout.tsx:39-88](../../Smart-Tutor-frontend/app/layout.tsx#L39)) — Clerk's embedded UI is themed to match the dark glass app:

- `appearance.variables` sets `colorPrimary: "#ffb84d"` (amber), `colorBackground: "#0b0c16"`, glassy `colorInputBackground`, light text colors, etc. ([layout.tsx:40-47](../../Smart-Tutor-frontend/app/layout.tsx#L40)).
- `appearance.elements` overrides specific Clerk DOM nodes with Tailwind classes. Several entries are documented **bug fixes** for legibility on the dark theme:
  - `socialButtonsBlockButton` — Clerk's default "Continue with Google" button is light, so light-on-light text was invisible; forced to a dark glass button with explicit light text ([layout.tsx:52-55](../../Smart-Tutor-frontend/app/layout.tsx#L52)).
  - The whole `userButtonPopover*` block — the default action rows ("Manage account", "Sign out") "rendered as near-invisible dim text on the dark popover, so the menu looked empty"; forced to legible light text with a clear hover ([layout.tsx:63-87](../../Smart-Tutor-frontend/app/layout.tsx#L63)).
  - `userButtonPopoverCustomItemButton*` — the **custom** menu items (Dashboard, Analytics, My lamps, Connect a lamp) use a *separate* element key from the built-in actions; without these they render in unreadable dim text ([layout.tsx:78-83](../../Smart-Tutor-frontend/app/layout.tsx#L78)). There is a belt-and-suspenders CSS fallback for the same items in `globals.css` using Clerk's stable `cl-` classes with `!important` ([globals.css:317-333](../../Smart-Tutor-frontend/app/globals.css#L317)).

**5. The document body** ([layout.tsx:90-95](../../Smart-Tutor-frontend/app/layout.tsx#L90)):

```tsx
<html lang="en" className="dark">
  <body className={`${display.variable} ${sans.variable} ${mono.variable} font-sans`}>
    <Providers>{children}</Providers>
  </body>
</html>
```

`<html className="dark">` activates Tailwind's class-based dark mode (§4.3). The body composes the three font-variable classes plus `font-sans` (the default family). All routes render inside `<Providers>` (next section).

**Render order, outer → inner:** `ClerkProvider` → `html/body` → `Providers` (QueryClientProvider + BootDiagnostics) → page `children`.

---

## 6. Global Providers (`app/providers.tsx`)

`app/providers.tsx` is a **Client Component** (`"use client"`, [providers.tsx:1](../../Smart-Tutor-frontend/app/providers.tsx#L1)). It owns the **React Query client** for the entire app and mounts the app-wide diagnostics probe. It also instruments the React Query cache so the browser console "narrates the WHOLE lifecycle of each query" ([providers.tsx:13-27](../../Smart-Tutor-frontend/app/providers.tsx#L13)).

### 6.1 Module-level state

- `const fetchStart = new Map<string, number>()` — maps a query's `queryHash` to the timestamp its current fetch began, used to measure `queryFn` duration ([providers.tsx:30](../../Smart-Tutor-frontend/app/providers.tsx#L30)).
- `let queriesInFlight = 0` — a "burst gauge": how many queries are mid-fetch right now ([providers.tsx:32](../../Smart-Tutor-frontend/app/providers.tsx#L32)).

### 6.2 `buildClient(): QueryClient`

Constructs a fully instrumented `QueryClient` ([providers.tsx:34-106](../../Smart-Tutor-frontend/app/providers.tsx#L34)):

**`QueryCache` with `onError`** — belt-and-suspenders logging of any error that slips through (e.g. thrown inside a `select`/transform), tied to the query key via `log.error("QUERY", ...)` ([providers.tsx:35-42](../../Smart-Tutor-frontend/app/providers.tsx#L35)).

**`MutationCache` with `onError` / `onSuccess`** — every mutation logs its outcome with a human-readable key from `describeKey()` ([providers.tsx:44-51](../../Smart-Tutor-frontend/app/providers.tsx#L44)).

**`queryCache.subscribe(...)`** — the heart of the instrumentation ([providers.tsx:54-89](../../Smart-Tutor-frontend/app/providers.tsx#L54)). It filters for `event.type === "updated"` and switches on `action.type`:

| `action.type` | Logic | Output |
| --- | --- | --- |
| `"fetch"` | Records `fetchStart[hash] = performance.now()`, increments `queriesInFlight`. `isPoll = query.state.dataUpdateCount > 0` (had data already → it's a refetch/poll). | `QUERY` debug: `<hash> · initial load|REFETCH/poll start (N in flight)`. If `queriesInFlight >= 3`, an extra **burst** debug line. |
| `"failed"` | A retry tick — the `queryFn` threw and React Query is backing off. | `QUERY` warn: `attempt failed → retrying (failureCount=…)`. |
| `"success"` / `"error"` | Computes `ms = performance.now() - started`, decrements `queriesInFlight`. On success calls `log.lag(<hash> queryFn, ms, BUDGET.query, …, { rows: countRows(data) })`; on error logs `settled ERROR after Nms`. | `PERF`/`LAG` line with timing + a row count. |

**Default query options** ([providers.tsx:91-105](../../Smart-Tutor-frontend/app/providers.tsx#L91)):

```ts
defaultOptions: {
  queries: {
    retry: 1,                    // one retry, not the library default of 3
    refetchOnWindowFocus: false,
    staleTime: 10_000,           // 10 seconds
  },
}
```

The `retry: 1` choice is documented: *"a single transient blip — a Clerk token refreshing mid-flight, a cold backend, a momentary 401/5xx — self-heals … A genuine failure still surfaces fast (one extra attempt)."* ([providers.tsx:96-100](../../Smart-Tutor-frontend/app/providers.tsx#L96)). `staleTime: 10_000` means data is considered fresh for 10s before a background refetch is allowed; `refetchOnWindowFocus: false` suppresses refetch-on-tab-focus noise.

### 6.3 Helpers

- **`describeKey(key)`** — JSON-stringifies a mutation key for logs; falls back to `String(key)` or `"?"` on failure ([providers.tsx:108-115](../../Smart-Tutor-frontend/app/providers.tsx#L108)).
- **`countRows(data)`** — a rough "how much came back" gauge for the success line: array → `.length`; object → looks for known array fields `["devices","models","recent","daily"]` and reports `key:len`, else the object's key count; otherwise `"—"` ([providers.tsx:118-128](../../Smart-Tutor-frontend/app/providers.tsx#L118)).

### 6.4 `Providers({ children })` component

```tsx
const [client] = useState(() => {
  const sw = stopwatch();
  const c = buildClient();
  log.info("BOOT", `React Query client ready (${Math.round(sw.total())}ms)`);
  return c;
});
return (
  <QueryClientProvider client={client}>
    <BootDiagnostics />
    {children}
  </QueryClientProvider>
);
```
([providers.tsx:130-145](../../Smart-Tutor-frontend/app/providers.tsx#L130))

The client is created **once via lazy `useState` initialiser** — "so it survives re-renders but isn't shared across requests on the server" ([providers.tsx:131-138](../../Smart-Tutor-frontend/app/providers.tsx#L131)). This is the canonical Next.js + React Query SSR pattern: a per-render-tree client avoids leaking one user's cache to another on the server. The build is timed and reported as a `BOOT` log. `<BootDiagnostics />` (a `null`-rendering probe, §10) is mounted as a sibling of `children` so it observes the whole app.

---

## 7. Middleware-Based Route Protection (`middleware.ts`)

`middleware.ts` runs at the **edge on every matching request, before the page renders**. It is the **first** of the two auth layers (the second is `lib/auth-guard.ts`, §8).

```ts
import { clerkMiddleware, createRouteMatcher } from "@clerk/nextjs/server";

const isProtected = createRouteMatcher([
  "/dashboard(.*)",
  "/analytics(.*)",
  "/devices(.*)",
  "/pair(.*)",
  "/connect(.*)",
  "/onboarding(.*)",
  "/simulator(.*)",
  "/admin(.*)",
]);

export default clerkMiddleware((auth, req) => {
  if (isProtected(req)) auth().protect();
});

export const config = {
  matcher: ["/((?!.*\\..*|_next).*)", "/", "/(api|trpc)(.*)"],
};
```
([middleware.ts:1-26](../../Smart-Tutor-frontend/middleware.ts#L1))

**How it works:**

1. **`createRouteMatcher([...])`** compiles the listed path patterns (each `(.*)` matches the route and any sub-path) into the predicate `isProtected(req)` ([middleware.ts:7-18](../../Smart-Tutor-frontend/middleware.ts#L7)).
2. **`clerkMiddleware((auth, req) => …)`** wraps every request with Clerk's auth context. For protected requests it calls **`auth().protect()`**, which redirects unauthenticated users to the sign-in URL (configured on `ClerkProvider`) ([middleware.ts:20-22](../../Smart-Tutor-frontend/middleware.ts#L20)).
3. **`config.matcher`** controls which requests run the middleware at all:
   - `"/((?!.*\\..*|_next).*)"` — every path **except** those containing a `.` (static files like `.css`, `.png`) or starting with `_next` (Next internals).
   - `"/"` — the root.
   - `"/(api|trpc)(.*)"` — API/tRPC routes.

**Protected set:** `/dashboard`, `/analytics`, `/devices`, `/pair`, `/connect`, `/onboarding`, `/simulator`, `/admin` (all with sub-paths). **Public:** `/` (landing), `/sign-in`, `/sign-up` (and Clerk's `sso-callback`) — these are deliberately *not* in the matcher list so anonymous users can reach auth.

**Division of responsibility (explicit in the comments):**

- Middleware enforces *"is signed in"* only ([middleware.ts:4-6](../../Smart-Tutor-frontend/middleware.ts#L4), [auth-guard.ts:11-12](../../Smart-Tutor-frontend/lib/auth-guard.ts#L11)).
- The *"has finished onboarding"* gate lives in the pages via `lib/auth-guard.ts` ([middleware.ts:4-5](../../Smart-Tutor-frontend/middleware.ts#L4)).
- `/admin` requires a session here, but the **admin-role** gate (allowlist) is enforced server-side in `app/admin/page.tsx` via `requireOnboardedAndAdmin()` (Updated 2026-07-03; was `requireAdmin()`) and re-checked by the backend ([middleware.ts:15-17](../../Smart-Tutor-frontend/middleware.ts#L15)).
- Reiterated boundary: *"the frontend only ever handles human sessions — never device secrets or device JWTs."* ([middleware.ts:5-6](../../Smart-Tutor-frontend/middleware.ts#L5)).

---

## 8. The Two-Layer Auth Model

Authentication/authorisation is enforced in **two stacked layers**, both backed by Clerk but with different scopes:

### Layer 1 — Edge middleware (session gate)
`middleware.ts` redirects unauthenticated users away from every protected route before any rendering (§7).

### Layer 2 — Server-side page guards (`lib/auth-guard.ts`)
`lib/auth-guard.ts` is **server-only** (uses `auth()` from `@clerk/nextjs/server` and `redirect()` from `next/navigation`, [auth-guard.ts:14-15](../../Smart-Tutor-frontend/lib/auth-guard.ts#L14)). It enforces the onboarding-completion and admin-role gates. A critical design note: the **single source of truth is the backend Supabase profile row, NOT Clerk `publicMetadata`** — reading both caused drift where a fully-onboarded returning user could be bounced back to `/onboarding` when both signals transiently degraded ([auth-guard.ts:1-12](../../Smart-Tutor-frontend/lib/auth-guard.ts#L1)).

**`PROFILE_PROBE_TIMEOUT_MS = 9000`** ([auth-guard.ts:31](../../Smart-Tutor-frontend/lib/auth-guard.ts#L31)) — a hard ceiling for the server-side profile probe via `AbortSignal.timeout(...)`. Sized to the backend's real p95: a cold Clerk-verified request (JWKS fetch + RSA verify + a fresh asyncpg connection to remote Supabase) runs 6–13s in practice, so an earlier 2.5s ceiling aborted *every* probe and bounced real admins. The comment warns that without a timeout the `await fetch` inside the RSC would hang forever → blank screen ([auth-guard.ts:22-31](../../Smart-Tutor-frontend/lib/auth-guard.ts#L22)).

**`getBackendProfile()`** ([auth-guard.ts:56-99](../../Smart-Tutor-frontend/lib/auth-guard.ts#L56)) — one fetch returns both the gate status and the profile to render:

1. `auth().getToken()`; if no token → return `{ status: "unreachable", profile: null }`.
2. `GET ${BACKEND_URL}/api/frontend/profile` with `Authorization: Bearer <token>`, `cache: "no-store"`, `signal: AbortSignal.timeout(9000)`.
3. `!res.ok` → log and return `"unreachable"`.
4. `res.json()` → if body present `{ status: "exists", profile }`, else `{ status: "missing", profile: null }`.
5. Any thrown error (AbortError/timeout, network, backend down) → `"unreachable"`.

It returns one of three `ProfileStatus` values: `"exists" | "missing" | "unreachable"` ([auth-guard.ts:33](../../Smart-Tutor-frontend/lib/auth-guard.ts#L33)). The `BackendProfile` interface mirrors the backend `ProfileOut` schema 1:1 in snake_case so the dashboard can render straight off the wire ([auth-guard.ts:37-50](../../Smart-Tutor-frontend/lib/auth-guard.ts#L37)).

**`requireOnboarded(): Promise<BackendProfile | null>`** ([auth-guard.ts:111-118](../../Smart-Tutor-frontend/lib/auth-guard.ts#L111)) — called at the top of every authed page (e.g. `app/dashboard/page.tsx`):

- No `userId` → `redirect("/sign-in")`.
- `status === "missing"` → `redirect("/onboarding")`.
- `"exists"` → returns the profile; `"unreachable"` → returns `null` (degrade, **don't** re-ask). The asymmetry is deliberate: re-asking an already-onboarded user because of a transient blip is the worst outcome ([auth-guard.ts:104-110](../../Smart-Tutor-frontend/lib/auth-guard.ts#L104)).

`app/dashboard/page.tsx` shows the consumption pattern: `export const dynamic = "force-dynamic"` (never serve a cached per-user shell) then `const profile = await requireOnboarded()` before rendering ([dashboard/page.tsx:10-18](../../Smart-Tutor-frontend/app/dashboard/page.tsx#L10)).

**Admin gate — `requireOnboardedAndAdmin(): Promise<void>` (Updated 2026-07-03).** The `/admin` gate was refactored (commit `ef07d7f`, "optimizations") from two **sequential** awaits (`requireOnboarded()` then `requireAdmin()`, each a 9s-timeout probe → up to ~18s of blank on a cold backend) into a single guard that fires **both probes concurrently**:

- The old `requireAdmin()` is replaced by a redirect-free helper **`getAdminVerdict(): "admin" | "not_admin" | "unknown"`** ([auth-guard.ts](../../Smart-Tutor-frontend/lib/auth-guard.ts)). It probes `GET /api/frontend/me` for `is_admin` and returns `"not_admin"` only on a clear `is_admin === false` (or no token), `"admin"` on a clear `true`, and `"unknown"` on any unreachable/slow/errored probe.
- **`requireOnboardedAndAdmin()`** checks `userId` (→ `/sign-in`), then runs `Promise.all([getBackendProfile(), getAdminVerdict()])`. Redirects are applied **after** the await, in deterministic order: `status === "missing"` → `/onboarding`, then `verdict === "not_admin"` → `/dashboard`. Called from `app/admin/page.tsx`.
- The **degrade-on-unknown** policy is preserved and still safe: `/admin` shows no data of its own — every panel fetches `/api/frontend/admin/*`, which re-check `require_admin` server-side (403 `NOT_ADMIN`), so a non-admin who slips past a timed-out probe sees only an "Admin access required" notice, never data. `redirect()` throws `NEXT_REDIRECT` and is called **outside** any try so it isn't swallowed. The 9s `PROFILE_PROBE_TIMEOUT_MS` was intentionally left unchanged (now hidden behind the route's `loading.tsx` skeleton; see `OPTIMIZATION.md §2.1`).

---

## 9. The Data Flow: Backend API → UI

All UI data flows through one authenticated client. The chain is:

**Clerk session → `useApi()` (token + fetch + error shaping) → typed hooks (`lib/profile.ts` etc.) → React Query cache → components.**

### 9.1 `useApi()` — the single authenticated fetch (`lib/api.ts`)

`lib/api.ts` is `"use client"` and is *"the foundation the rest of the app builds on"* ([api.ts:1-10](../../Smart-Tutor-frontend/lib/api.ts#L1)). It exports the `useApi()` hook plus `BACKEND_URL`, `ApiError`, and `ApiErrorBody`.

**`BACKEND_URL`** = `process.env.NEXT_PUBLIC_BACKEND_URL ?? "http://localhost:8000"` ([api.ts:61-62](../../Smart-Tutor-frontend/lib/api.ts#L61)). It points at the unified backend hosting both the device surface (`/api/device/*`, `/api/pairing-info/*`) and the Frontend Manager (`/api/frontend/*`).

**Token single-flight (`fetchTokenShared`)** ([api.ts:21-55](../../Smart-Tutor-frontend/lib/api.ts#L21)) — Clerk session JWTs are short-lived and `getToken()` transparently refreshes them. When the dashboard fires `/me` + `/profile` + `/analytics` on the same tick, each could kick off a parallel refresh — a "token-refresh race" that is a prime cause of transient 401 flaps. The guard:

- `let tokenInFlight = 0` and `let sharedTokenPromise: Promise<string|null> | null = null` at module scope.
- If no shared promise exists, start one `async` IIFE that calls `getToken()`, and assign it to `sharedTokenPromise`. All concurrent callers `await` the *same* promise.
- The promise resets to `null` in its `finally`, so caching never outlives the in-flight window (Clerk's own expiry semantics are unchanged).
- `tokenInFlight` should never exceed 1 under single-flight; if it does, a `RACE` warning fires (meaning the dedup itself broke) ([api.ts:38-45](../../Smart-Tutor-frontend/lib/api.ts#L38)).

**`call<T>(path, init)`** — the generic authenticated fetch ([api.ts:81-168](../../Smart-Tutor-frontend/lib/api.ts#L81)). Every higher-level call funnels through it "so auth, JSON encoding, and error shaping live in exactly one place." Its three phases, with timing measured by a `stopwatch()`:

| Phase | Inputs | Transform | Output / logging |
| --- | --- | --- | --- |
| 0. setup | `path`, `init` | `method = init.method ?? "GET"`, `id = nextSeq()`, `key = "<METHOD> <path>"`, `raceEnter(key, id)` | `API` debug `start`; RACE warning if a duplicate `key` is already in flight |
| 1. token | shared `getToken` | `await fetchTokenShared(getToken)`; `log.lag(token fetch, …, BUDGET.token)` | sets `Authorization: Bearer <jwt>`; `AUTH` warn if **no** token (request goes out unauthenticated) |
| 2. network | headers + body | `fetch(`${BACKEND_URL}${path}`, …)`; sets `Content-Type: application/json` if a body exists and none was set | `log.lag(network, …, BUDGET.network, BUDGET.networkSevere, { status })`; on `fetch` reject → loud `API` error `NETWORK ERROR … backend down / CORS / DNS` and rethrow |
| 3. parse + outcome | `Response` | non-2xx → parse `{error,code}` (fallback `{ statusText, "UNKNOWN" }`) and `throw new ApiError(...)`; `204` → return `undefined`; else `res.json()` | `API` error on failure with full timing+body; `API` info on success with `tokenMs/netMs/parseMs/totalMs` |
| cleanup | — | `finally { raceExit(key) }` | decrements the in-flight count for `key` |

**`ApiError`** ([api.ts:64-74](../../Smart-Tutor-frontend/lib/api.ts#L64)) — carries `status: number` and `body: ApiErrorBody { error, code }`; its `message` is `"<status> <code>: <error>"`. On a non-2xx response the constructor is given `(body as any).detail ?? body` ([api.ts:144](../../Smart-Tutor-frontend/lib/api.ts#L144)), so a FastAPI `{ detail: {...} }` envelope is unwrapped if present.

**The hook's return value** ([api.ts:170-184](../../Smart-Tutor-frontend/lib/api.ts#L170)) is memoised and exposes:

- `ready: isLoaded && !!isSignedIn` — used by the data hooks' `enabled` flag so queries don't fire before Clerk is ready.
- `getToken` — passthrough.
- `get<T>(path)`, `post<T>(path, body)`, `put<T>(path, body)`, `del<T>(path)` — typed verbs that serialise the body with `JSON.stringify` and delegate to `call`.

### 9.2 Typed hooks layer (`lib/profile.ts` and siblings)

`lib/profile.ts` is the Frontend-Manager data layer; it defines wire interfaces that *"mirror the backend schemas in app/schemas/frontend.py"* ([profile.ts:1-6](../../Smart-Tutor-frontend/lib/profile.ts#L1)) and wraps `useApi()` in React Query hooks:

- **`Me`** — `{ user_id, email, has_profile, onboarding_complete, is_admin }` ([profile.ts:13-19](../../Smart-Tutor-frontend/lib/profile.ts#L13)).
- **`Profile`** / **`ProfileInput`** — the onboarding profile shape ([profile.ts:21-41](../../Smart-Tutor-frontend/lib/profile.ts#L21)).
- **`Analytics`** — dashboard rollup: `device_count, online_devices, total_turns, turns_last_7d, sessions_count, last_active_at, subject_mix, devices[]` ([profile.ts:49-58](../../Smart-Tutor-frontend/lib/profile.ts#L49)).
- **`AnalyticsDetail`** — the rich `/analytics` page payload with percentiles (`p50_ms`, `p95_ms`), `avg_confidence`, `total_cost_usd`, `escalated_pct`, and `daily[]`/mix dictionaries ([profile.ts:129-149](../../Smart-Tutor-frontend/lib/profile.ts#L129)).

The hooks ([profile.ts:66-159](../../Smart-Tutor-frontend/lib/profile.ts#L66)):

| Hook | Query key | Endpoint | Caching |
| --- | --- | --- | --- |
| `useMe()` | `["me"]` | `GET /api/frontend/me` | `staleTime: 60_000`, `enabled: api.ready` |
| `useProfile()` | `["profile"]` | `GET /api/frontend/profile` (200+null when not onboarded) | `staleTime: 60_000` |
| `useSaveProfile()` | mutation | `PUT /api/frontend/profile` | on success invalidates `["profile"]` + `["me"]` |
| `useAnalytics()` | `["analytics"]` | `GET /api/frontend/analytics` | `refetchInterval: 60_000` |
| `useAnalyticsDetail(days=14)` | `["analytics-detail", days]` | `GET /api/frontend/analytics/detail?days=<n>` | `refetchInterval: 60_000` |

`IDENTITY_STALE_MS = 60_000` ([profile.ts:64](../../Smart-Tutor-frontend/lib/profile.ts#L64)) keeps identity/profile fresh for a minute to avoid redundant refetches and cross-navigation flicker. The polling interval was deliberately raised from 30s to 60s because dashboard stats "don't change second-to-second," and TanStack pauses the interval while the tab is unfocused ([profile.ts:105-108](../../Smart-Tutor-frontend/lib/profile.ts#L105)).

### 9.3 Component consumption

`components/app/AnalyticsCards.tsx` is a representative consumer ([AnalyticsCards.tsx:11-99](../../Smart-Tutor-frontend/components/app/AnalyticsCards.tsx#L11)):

```tsx
const { data, isLoading, isError } = useAnalytics();
if (isLoading) return <loading pulse/>;
if (isError || !data) return <"Couldn't reach the Lumos backend" notice/>;
// otherwise render device/turn/session cards + subject_mix pills
```

It models all three states explicitly: a pulsing "Reading your activity…" skeleton while loading, a quiet inline "couldn't reach the backend" notice on error/empty, and the data cards otherwise — the graceful-degradation contract described at the top of the file ([AnalyticsCards.tsx:3-6](../../Smart-Tutor-frontend/components/app/AnalyticsCards.tsx#L3)). `subject_mix` (a `Record<string, number>`) is rendered as a row of pills via `Object.entries(...)` ([AnalyticsCards.tsx:55](../../Smart-Tutor-frontend/components/app/AnalyticsCards.tsx#L55)).

### 9.4 Two fetch paths

Note the system uses **two** distinct fetch mechanisms by deliberate design:

1. **Server-side, blocking, no-retry** — `lib/auth-guard.ts` does a raw `fetch` inside the RSC for the gate decision (one bounded probe; a retry would be "dead time the user stares at a blank screen", [auth-guard.ts:60-64](../../Smart-Tutor-frontend/lib/auth-guard.ts#L60)).
2. **Client-side, React Query, retry-once, polled** — everything actually displayed (`analytics`, `me`, devices, models) goes through `useApi()` + React Query, which retries once and polls.

---

## 10. Diagnostics & Instrumentation Subsystem

A cross-cutting, console-only diagnostics system funnels every noisy event (API client, React Query cache, boot/route timers) through `lib/log.ts` so the console has "a single, consistent, color-coded voice" ([log.ts:3-22](../../Smart-Tutor-frontend/lib/log.ts#L3)). It is part of the architecture because every layer above depends on it.

### 10.1 `lib/log.ts`

**Categories** (`LogCategory`): `API | QUERY | AUTH | BOOT | ROUTE | RACE | LAG | PERF` ([log.ts:24-32](../../Smart-Tutor-frontend/lib/log.ts#L24)).

**Latency budgets** — `BUDGET` (ms), the thresholds that decide when something is logged as LAG ([log.ts:35-43](../../Smart-Tutor-frontend/lib/log.ts#L35)):

| Key | ms | Meaning |
| --- | --- | --- |
| `token` | 500 | `getToken()` should be cache-fast; >0.5s implies a refresh/cold JWKS |
| `network` | 1000 | a single backend round trip |
| `networkSevere` | 3000 | round trip so slow it's almost certainly a problem |
| `parse` | 50 | JSON decode of the body |
| `query` | 1500 | a whole React Query `queryFn` (token + network + parse) |
| `longTask` | 120 | a main-thread task that blocks paint/interaction |
| `route` | 800 | client-side navigation between two pages |

**Gating (`resolveEnabled` / `VERBOSE`)** ([log.ts:45-66](../../Smart-Tutor-frontend/lib/log.ts#L45)) — decides whether non-error logs print, evaluated in order:

1. `NEXT_PUBLIC_VERBOSE === "0"` → off (build-time).
2. `NEXT_PUBLIC_VERBOSE === "1"` → on (build-time).
3. Runtime overrides (no rebuild): `window.__LUMOS_VERBOSE === true/false`, then `localStorage.LUMOS_VERBOSE === "1"/"0"`.
4. Default: on when `process.env.NODE_ENV !== "production"` (chatty in dev, silent in prod).

`emit()` always shows `error` regardless of `VERBOSE` ([log.ts:105](../../Smart-Tutor-frontend/lib/log.ts#L105)), uses `%c` CSS tints per category in the browser, and falls back to a plain `[Lumos CATEGORY]` prefix on the server where `%c` doesn't apply ([log.ts:111-117](../../Smart-Tutor-frontend/lib/log.ts#L111)).

**Other primitives:**

- `nextSeq()` — a monotonic per-page-load counter (`#001`, `#002`…) so the start/end lines of the same call can be correlated across interleaved logs ([log.ts:86-90](../../Smart-Tutor-frontend/lib/log.ts#L86)).
- `log.lag(label, ms, budget, severe?, data?)` — under budget → `PERF` debug; `≥ budget` → `LAG` warn; `≥ severe` → `LAG` error; returns the rounded ms ([log.ts:140-157](../../Smart-Tutor-frontend/lib/log.ts#L140)).
- `stopwatch()` — `{ lap(), total(), startedAt }` for phase breakdowns (token → network → parse) ([log.ts:163-181](../../Smart-Tutor-frontend/lib/log.ts#L163)).
- `raceEnter(key, seqId)` / `raceExit(key)` — an in-flight registry keyed by `"GET /api/frontend/me"`-style strings; if the same key is entered while a previous one hasn't exited, a `RACE` warning fires with the live count ([log.ts:183-208](../../Smart-Tutor-frontend/lib/log.ts#L183)).

### 10.2 `components/app/BootDiagnostics.tsx`

A `"use client"` component that renders `null` and is mounted once inside `Providers` ([BootDiagnostics.tsx:1-25](../../Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L1), [providers.tsx:141](../../Smart-Tutor-frontend/app/providers.tsx#L141)). It instruments the browser side of load performance with feature-detected `PerformanceObserver`s (best-effort; older browsers/Firefox simply log less, never throw):

- **Navigation Timing waterfall** (`report()`) — reads the `navigation` entry and logs `dns / tcp / tls / ttfb / response / domInteractive / domComplete / load`; `log.lag("page load (navigation)", load, 2500, 5000, phases)` ([BootDiagnostics.tsx:35-55](../../Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L35)).
- **Largest Contentful Paint** — `observe("largest-contentful-paint", …)` with `log.lag("largest contentful paint", startTime, 2500, 4000)` ([BootDiagnostics.tsx:70-73](../../Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L70)).
- **Long tasks** — `observe("longtask", …)` with `log.lag("main-thread long task", duration, BUDGET.longTask, 300, …)` ([BootDiagnostics.tsx:76-82](../../Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L76)).
- **Route-change timing** — a second `useEffect` keyed on `usePathname()` logs `prev → next` and, after two `requestAnimationFrame` ticks (i.e. after the new route paints), `log.lag("route render <path>", elapsed, BUDGET.route)` ([BootDiagnostics.tsx:88-105](../../Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L88)). The first mount only logs `landed on <path>` (it's not a navigation).

---

## 11. Configuration & Environment Variables

From `RUN.md` §3 ([RUN.md:46-69](../../Smart-Tutor-frontend/RUN.md#L46)) and the code:

| Variable | Scope | Used by | Default / effect |
| --- | --- | --- | --- |
| `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` | browser | Clerk SDK | required; missing → blank page / Clerk error ([RUN.md:163-164](../../Smart-Tutor-frontend/RUN.md#L163)) |
| `CLERK_SECRET_KEY` | server only | Clerk middleware / `auth()` | required; never exposed to the browser ([RUN.md:67-68](../../Smart-Tutor-frontend/RUN.md#L67)) |
| `NEXT_PUBLIC_BACKEND_URL` | browser | `lib/api.ts` `BACKEND_URL` ([api.ts:61](../../Smart-Tutor-frontend/lib/api.ts#L61)) | `http://localhost:8000`; where the browser reaches FastAPI |
| `BACKEND_URL` | server | `lib/auth-guard.ts` (fallback after `NEXT_PUBLIC_BACKEND_URL`) ([auth-guard.ts:17-18](../../Smart-Tutor-frontend/lib/auth-guard.ts#L17)) | server-side probe target |
| `NEXT_PUBLIC_CLERK_SIGN_IN_URL` | browser | Clerk | `/sign-in` |
| `NEXT_PUBLIC_CLERK_SIGN_UP_URL` | browser | Clerk | `/sign-up` |
| `NEXT_PUBLIC_CLERK_SIGN_IN_FALLBACK_REDIRECT_URL` | browser | Clerk | `/dashboard` |
| `NEXT_PUBLIC_CLERK_SIGN_UP_FORCE_REDIRECT_URL` | browser | Clerk | `/onboarding` |
| `NEXT_PUBLIC_VERBOSE` | build | `lib/log.ts` | `"1"` force-on, `"0"` force-off diagnostics ([log.ts:47-48](../../Smart-Tutor-frontend/lib/log.ts#L47)) |
| `NODE_ENV` | runtime | `lib/log.ts` | non-`production` → verbose by default ([log.ts:63](../../Smart-Tutor-frontend/lib/log.ts#L63)) |

Runtime-only toggles (no rebuild): `window.__LUMOS_VERBOSE` and `localStorage.LUMOS_VERBOSE` ([log.ts:50-61](../../Smart-Tutor-frontend/lib/log.ts#L50)).

Important operational notes from `RUN.md`: `.env.local` is gitignored; **Next reads env only at startup**, so changes require restarting `npm run dev` ([RUN.md:69-70](../../Smart-Tutor-frontend/RUN.md#L69)). The backend must run with `ENABLE_AUTH=true` + Clerk keys + a live `DATABASE_URL`, or the `/api/device/*` and `/api/frontend/*` routes aren't mounted and protected pages get 404s (sign-in/onboarding UI still renders) ([RUN.md:118-126](../../Smart-Tutor-frontend/RUN.md#L118)). The backend's `CORS_ALLOWED_ORIGINS` must include the frontend origin ([RUN.md:117](../../Smart-Tutor-frontend/RUN.md#L117)).

In-app constants: `BUDGET.*` (§10), `PROFILE_PROBE_TIMEOUT_MS = 9000` (§8), `IDENTITY_STALE_MS = 60_000` and the `60_000`ms poll intervals (§9), the React Query defaults `retry: 1` / `staleTime: 10_000` / `refetchOnWindowFocus: false` (§6), and the burst threshold `queriesInFlight >= 3` ([providers.tsx:67](../../Smart-Tutor-frontend/app/providers.tsx#L67)).

---

## 12. Edge Cases, Error Handling, Timeouts, Retries, Fallbacks

| Scenario | Mechanism | Location |
| --- | --- | --- |
| Backend down / CORS / DNS (no HTTP status) | `fetch` rejects → loud `API NETWORK ERROR` log, rethrow → React Query surfaces error | [api.ts:111-123](../../Smart-Tutor-frontend/lib/api.ts#L111) |
| Non-2xx HTTP | parse `{error,code}` (fallback `{statusText,"UNKNOWN"}`), `throw ApiError(status, detail ?? body)` | [api.ts:130-145](../../Smart-Tutor-frontend/lib/api.ts#L130) |
| `204 No Content` | return `undefined as T` (no JSON parse) | [api.ts:147-151](../../Smart-Tutor-frontend/lib/api.ts#L147) |
| Transient blip (401 flap, cold backend, token refresh) | React Query `retry: 1` — one extra attempt self-heals | [providers.tsx:96-100](../../Smart-Tutor-frontend/app/providers.tsx#L96) |
| Token-refresh race (parallel `getToken`) | single-flight `fetchTokenShared` shares one in-flight promise | [api.ts:29-55](../../Smart-Tutor-frontend/lib/api.ts#L29) |
| Duplicate concurrent requests | `raceEnter`/`raceExit` registry → `RACE` warning | [log.ts:188-208](../../Smart-Tutor-frontend/lib/log.ts#L188) |
| No Clerk token | request proceeds unauthenticated with an `AUTH` warning | [api.ts:99-101](../../Smart-Tutor-frontend/lib/api.ts#L99) |
| Server-side probe hangs (cold backend) | `AbortSignal.timeout(9000)` → `"unreachable"`, page degrades instead of blank-screen hang | [auth-guard.ts:73-98](../../Smart-Tutor-frontend/lib/auth-guard.ts#L73) |
| Onboarded user bounced on transient blip | `"unreachable"` returns `null`, does NOT redirect to `/onboarding` | [auth-guard.ts:104-117](../../Smart-Tutor-frontend/lib/auth-guard.ts#L104) |
| Admin probe times out | degrade to render; admin data endpoints still enforce `require_admin` → no leak | [auth-guard.ts:120-167](../../Smart-Tutor-frontend/lib/auth-guard.ts#L120) |
| `NEXT_REDIRECT` swallowed by catch | `redirect()` called outside the try/catch | [auth-guard.ts:168-170](../../Smart-Tutor-frontend/lib/auth-guard.ts#L168) |
| Analytics not yet populated / outage | `AnalyticsCards` shows loading skeleton, then an inline notice; backend returns zeros before traffic | [AnalyticsCards.tsx:14-30](../../Smart-Tutor-frontend/components/app/AnalyticsCards.tsx#L14) |
| `localStorage` throws (private mode) | wrapped in try/catch, ignored | [log.ts:54-60](../../Smart-Tutor-frontend/lib/log.ts#L54) |
| Older browsers / Firefox `longtask` unsupported | `PerformanceObserver` calls are try/caught and skipped | [BootDiagnostics.tsx:58-67](../../Smart-Tutor-frontend/components/app/BootDiagnostics.tsx#L58) |
| OAuth callback stuck/stale | `/sign-in` is `force-dynamic`; explicit `signUp*` redirect props on `<SignIn>` so a first-time Google user has a destination | [sign-in/page.tsx:4-30](../../Smart-Tutor-frontend/app/sign-in/%5B%5B...sign-in%5D%5D/page.tsx#L4) |
| Camera blocked on LAN (pairing) | `jsqr` needs a secure context; localhost ok, LAN IP needs HTTPS tunnel | [RUN.md:132-143](../../Smart-Tutor-frontend/RUN.md#L132) |

---

## 13. Integration Points (Cross-References)

**Frontend → Backend (FastAPI "Frontend Manager").** Every authed read/write hits `${NEXT_PUBLIC_BACKEND_URL}/api/frontend/*` with `Authorization: Bearer <Clerk JWT>`:

- `GET /api/frontend/me` → `Me` (incl. `is_admin`); consumed by `useMe()` and `getAdminVerdict()` (inside `requireOnboardedAndAdmin()`).
- `GET /api/frontend/profile` → `Profile | null`; consumed by `useProfile()` and the server-side `getBackendProfile()`.
- `PUT /api/frontend/profile` → save onboarding (`useSaveProfile()`).
- `GET /api/frontend/analytics` and `…/analytics/detail?days=` → dashboard + analytics page.
- `GET /api/frontend/admin/*` → admin panels (each re-enforces `require_admin`).
- `…/api/frontend/ws` → the `/simulator` WebSocket "brain bench" ([RUN.md:157-158](../../Smart-Tutor-frontend/RUN.md#L157)).

The frontend's TS wire interfaces (`Me`, `Profile`, `Analytics`, `AnalyticsDetail`, `BackendProfile`) explicitly mirror the backend `app/schemas/frontend.py` in snake_case ([profile.ts:6](../../Smart-Tutor-frontend/lib/profile.ts#L6), [auth-guard.ts:37](../../Smart-Tutor-frontend/lib/auth-guard.ts#L37)).

**Frontend → Backend (device/pairing surface).** `/connect` and `/pair/[code]` call the device-pairing routes (`/api/device/*`, `/api/pairing-info/*`) on the same `BACKEND_URL` to complete pairing, then route to `/devices` ([api.ts:57-60](../../Smart-Tutor-frontend/lib/api.ts#L57), [RUN.md:156](../../Smart-Tutor-frontend/Smart-Tutor-frontend/RUN.md#L156)).

**Frontend ↔ Clerk (third-party auth).** `<ClerkProvider>` (layout), `clerkMiddleware` (edge), `auth()` (server guards), and `useAuth().getToken()` (client API client). Clerk's OAuth never touches the Python backend ([RUN.md:181-183](../../Smart-Tutor-frontend/RUN.md#L181)).

**Frontend → Firmware (indirect).** The frontend does not talk to the ESP32 directly; it links a lamp to a user by scanning the QR shown on the lamp's TFT (`/connect`, `jsqr`) and confirming via the backend. The lamp then talks to the backend over its own WebSocket with device credentials the frontend never handles ([middleware.ts:5-6](../../Smart-Tutor-frontend/middleware.ts#L5), [RUN.md:132-135](../../Smart-Tutor-frontend/RUN.md#L132)).

**Frontend → Database (indirect).** All Supabase/Postgres+pgvector access is mediated by the backend; the frontend's single source of truth for onboarding is the backend's durable profile row ([auth-guard.ts:1-9](../../Smart-Tutor-frontend/lib/auth-guard.ts#L1)).

**What calls this part:** the end user's browser (the only client); Clerk's redirect machinery; and the Next.js runtime (root layout → providers → pages → guards).

---

## 14. Diagrams

### 14.1 Request lifecycle — sign-in to rendered dashboard data

```mermaid
sequenceDiagram
    participant U as User Browser
    participant MW as middleware.ts (edge)
    participant CK as Clerk
    participant PG as dashboard/page.tsx (RSC)
    participant AG as auth-guard.ts (server)
    participant API as useApi() (client)
    participant RQ as React Query
    participant BE as FastAPI /api/frontend/*

    U->>MW: GET /dashboard
    MW->>MW: isProtected(req) === true
    MW->>CK: auth().protect()
    alt not signed in
        CK-->>U: redirect /sign-in
    else signed in
        MW->>PG: continue (force-dynamic)
        PG->>AG: requireOnboarded()
        AG->>CK: auth().getToken()
        AG->>BE: GET /api/frontend/profile (Bearer, timeout 9s, no-store)
        alt status "missing"
            AG-->>U: redirect /onboarding
        else "exists" / "unreachable"
            AG-->>PG: BackendProfile | null
            PG-->>U: stream HTML (profile tiles)
            U->>API: AnalyticsCards mounts → useAnalytics()
            API->>RQ: queryFn enabled by api.ready
            RQ->>API: call("/api/frontend/analytics")
            API->>CK: fetchTokenShared(getToken) [single-flight]
            API->>BE: GET /api/frontend/analytics (Bearer)
            BE-->>API: Analytics JSON
            API-->>RQ: cache + log timing/rows
            RQ-->>U: render cards (poll every 60s)
        end
    end
```

### 14.2 Provider / wrapper composition tree

```mermaid
flowchart TD
    A["ClerkProvider (layout.tsx)<br/>redirects + appearance theme"] --> B["html.dark / body<br/>font-display/sans/mono"]
    B --> C["Providers (providers.tsx, client)"]
    C --> D["QueryClientProvider<br/>retry:1, staleTime:10s, instrumented cache"]
    D --> E["BootDiagnostics<br/>(nav timing, LCP, longtask, route timing)"]
    D --> F["children = route pages"]
    F --> G["Server pages: requireOnboarded / requireOnboardedAndAdmin<br/>(auth-guard.ts probes backend)"]
    F --> H["Client components: useApi() hooks<br/>(useMe / useAnalytics / devices / admin)"]
    H --> I["lib/api.ts call()<br/>token → network → parse"]
    I --> J[(FastAPI /api/frontend/*)]
    G --> J
    I -.logs.-> K["lib/log.ts<br/>API/QUERY/AUTH/RACE/LAG/PERF"]
    E -.logs.-> K
    D -.logs.-> K
```

### 14.3 `useApi().call()` phase flow

```mermaid
flowchart LR
    S["call(path, init)"] --> R["raceEnter(key) + nextSeq()"]
    R --> T["Phase 1: fetchTokenShared(getToken)<br/>log.lag vs BUDGET.token (500ms)"]
    T -->|no token| W["AUTH warn: unauthenticated"]
    T --> N["Phase 2: fetch BACKEND_URL+path<br/>log.lag vs BUDGET.network (1000/3000ms)"]
    N -->|reject| NE["API error: NETWORK ERROR → throw"]
    N --> P{"res.ok?"}
    P -->|no| E["parse {error,code} → throw ApiError"]
    P -->|204| V["return undefined"]
    P -->|yes| J["res.json() → log.lag vs BUDGET.parse (50ms) → return T"]
    E --> X["finally raceExit(key)"]
    V --> X
    J --> X
    NE --> X
```

---

## 15. File-by-File / Function-by-Function Appendix

### `package.json` ([package.json](../../Smart-Tutor-frontend/package.json))
Project manifest. Scripts (`dev`, `dev:turbo`, `build`, `start`, `lint`), and the pinned dependency set (§2).

### `tsconfig.json` ([tsconfig.json](../../Smart-Tutor-frontend/tsconfig.json))
Strict TS config; `@/*` path alias to root; Next TS plugin; `bundler` resolution; `incremental` builds (§4.2).

### `tailwind.config.ts` ([tailwind.config.ts](../../Smart-Tutor-frontend/tailwind.config.ts))
`config: Config` — class-based dark mode; content globs incl. `lib/`; font-variable families; brand color tokens; no plugins (§4.3).

### `postcss.config.js` ([postcss.config.js](../../Smart-Tutor-frontend/postcss.config.js))
Tailwind + Autoprefixer PostCSS chain (§4.4).

### `next-env.d.ts` ([next-env.d.ts](../../Smart-Tutor-frontend/next-env.d.ts))
Auto-generated Next ambient type references; not edited (§4.5).

### `types/react-katex.d.ts` ([types/react-katex.d.ts](../../Smart-Tutor-frontend/types/react-katex.d.ts))
`declare module "react-katex"` — `MathComponentProps`, `InlineMath`, `BlockMath` (§4.6).

### `app/layout.tsx` ([app/layout.tsx](../../Smart-Tutor-frontend/app/layout.tsx))
- `display`/`sans`/`mono` — `next/font/google` loaders → CSS variables.
- `metadata` — title/description.
- `RootLayout({ children })` — wraps everything in themed `<ClerkProvider>` (redirect props + `appearance` legibility fixes) → `<html className="dark">/<body>` → `<Providers>` (§5).

### `app/providers.tsx` ([app/providers.tsx](../../Smart-Tutor-frontend/app/providers.tsx))
- module state `fetchStart`, `queriesInFlight`.
- `buildClient()` — instrumented `QueryCache`/`MutationCache`, `queryCache.subscribe` lifecycle logging, default `retry:1`/`staleTime:10s`/`refetchOnWindowFocus:false`.
- `describeKey(key)`, `countRows(data)` — log helpers.
- `Providers({ children })` — lazy `useState` client (per-tree), mounts `<BootDiagnostics/>` + children (§6).

### `middleware.ts` ([middleware.ts](../../Smart-Tutor-frontend/middleware.ts))
- `isProtected = createRouteMatcher([...])` — the protected route set.
- `default clerkMiddleware(...)` — `auth().protect()` on protected requests.
- `config.matcher` — which paths run middleware (§7).

### `RUN.md` ([RUN.md](../../Smart-Tutor-frontend/RUN.md))
Operator guide: prerequisites, install, `.env.local` keys, run/build/lint, backend connection requirements, camera/secure-context notes, route map, and troubleshooting (referenced throughout).

### Supporting files documented for cross-reference
- `lib/api.ts` — `useApi()`, `call()`, `fetchTokenShared()`, `BACKEND_URL`, `ApiError` (§9.1).
- `lib/auth-guard.ts` — `getBackendProfile()`, `requireOnboarded()`, `getAdminVerdict()` + `requireOnboardedAndAdmin()` (Updated 2026-07-03), `PROFILE_PROBE_TIMEOUT_MS` (§8).
- `lib/profile.ts` — wire types + `useMe/useProfile/useSaveProfile/useAnalytics/useAnalyticsDetail` (§9.2).
- `lib/log.ts` — `BUDGET`, `VERBOSE`, `log`, `stopwatch`, `nextSeq`, `raceEnter/raceExit` (§10.1).
- `components/app/BootDiagnostics.tsx` — nav-timing/LCP/longtask/route-timing probe (§10.2).
- `components/app/AnalyticsCards.tsx` — representative data consumer with loading/error/data states (§9.3).
- `app/globals.css` — Tailwind layers, `:root` theme variables, glass/aurora/button component classes, Clerk dropdown legibility fallback (§4.3, §5).
- `app/dashboard/page.tsx` — `force-dynamic` + `requireOnboarded()` consumption pattern (§8).
- `app/sign-in/[[...sign-in]]/page.tsx` — `force-dynamic` Clerk catch-all with explicit OAuth redirect props (§3, §12).
