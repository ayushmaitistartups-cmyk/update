# Frontend — Pages & Routes

The Lumos / Smart Tutor Lamp frontend is a **Next.js 14 App Router** application (the directory is `Smart-Tutor-frontend/`). This document is the definitive, inch-by-inch reference for every **route/page** under `app/` **except** `app/simulator/page.tsx` (documented separately in the web-simulator section). It covers what each route renders, its authentication and onboarding gates, the data it loads (server-side probes vs. client-side React Query), the full pairing/onboarding user journey, the global navigation graph, and the global styling layer (`app/globals.css`). Everything below is grounded directly in the code that was read; constants, thresholds, and control-flow are quoted from source with clickable citations.

---

## Table of Contents

1. [Purpose & Responsibility](#1-purpose--responsibility)
2. [Routing Architecture & Auth Layers](#2-routing-architecture--auth-layers)
3. [Route Inventory (map)](#3-route-inventory-map)
4. [The Auth & Onboarding Gate Engine (`lib/auth-guard.ts`)](#4-the-auth--onboarding-gate-engine-libauth-guardts)
5. [Public Route: `/` (Landing)](#5-public-route--landing)
6. [Auth Routes: `/sign-in` and `/sign-up`](#6-auth-routes-sign-in-and-sign-up)
7. [Onboarding Route: `/onboarding`](#7-onboarding-route-onboarding)
8. [Gated App Routes](#8-gated-app-routes)
   - [8.1 `/dashboard`](#81-dashboard)
   - [8.2 `/analytics`](#82-analytics)
   - [8.3 `/admin`](#83-admin)
   - [8.4 `/devices`](#84-devices)
9. [The Pairing Journey: `/connect`, `/pair`, `/pair/[code]`](#9-the-pairing-journey-connect-pair-paircode)
10. [Shared Page Infrastructure](#10-shared-page-infrastructure)
11. [Global Styling Layer (`app/globals.css`)](#11-global-styling-layer-appglobalscss)
12. [Navigation Graph](#12-navigation-graph)
13. [Data-Flow Summary (inputs → transforms → outputs)](#13-data-flow-summary-inputs--transforms--outputs)
14. [Edge Cases, Errors, Timeouts, Fallbacks](#14-edge-cases-errors-timeouts-fallbacks)
15. [Integration Points (cross-references)](#15-integration-points-cross-references)
16. [Diagrams](#16-diagrams)

---

## 1. Purpose & Responsibility

The pages layer is the **human-facing surface** of the system. The architecture deliberately splits responsibilities:

- **Firmware (ESP32-S3)** renders a pairing QR on the lamp screen and talks WebSocket to the backend; it never touches the frontend pages.
- **Backend (FastAPI "Frontend Manager")** is the single source of truth for profiles, pairing, devices, and analytics. It exposes two API surfaces consumed by these pages: the device/pairing surface (`/api/device/*`, `/api/pairing-info/*`, `/api/devices`) and the Frontend Manager (`/api/frontend/*`). See [api.ts:57-62](lib/api.ts#L57).
- **Frontend pages** handle **only human sessions** — never device secrets or device JWTs ([middleware.ts:5-6](middleware.ts#L5)). They authenticate the human via **Clerk**, gate access, then either render server-side data (the durable profile) or hydrate live data client-side via **TanStack React Query**.

The page layer's responsibilities are therefore:
1. **Marketing/entry** — the public landing page (`/`).
2. **Identity** — Clerk-hosted sign-in/sign-up (`/sign-in`, `/sign-up`), including the OAuth (Google) SSO callback.
3. **Forced onboarding** — collect a 7-question learner profile and persist it to Supabase via the backend (`/onboarding`).
4. **The app shell** — dashboard, analytics, admin, devices (`/dashboard`, `/analytics`, `/admin`, `/devices`).
5. **Device pairing** — scan a QR, confirm, and link a lamp to the account (`/connect`, `/pair/[code]`).

---

## 2. Routing Architecture & Auth Layers

There are **two independent gates**, applied at different layers:

| Layer | File | Question it answers | Mechanism |
|---|---|---|---|
| **Middleware** | [middleware.ts](middleware.ts) | "Is there a signed-in human session?" | Clerk `auth().protect()` over a route matcher |
| **Per-page server guard** | [lib/auth-guard.ts](lib/auth-guard.ts) | "Has this user finished onboarding?" and "Is this user an admin?" | Server fetch against the backend profile/`me` endpoints, then `redirect()` |

### 2.1 Middleware-protected routes

`clerkMiddleware` calls `auth().protect()` for any request matching `isProtected`, which is built with `createRouteMatcher` over these patterns ([middleware.ts:7-22](middleware.ts#L7)):

```
/dashboard(.*)   /analytics(.*)   /devices(.*)
/pair(.*)        /connect(.*)     /onboarding(.*)
/simulator(.*)   /admin(.*)
```

Anything not matched (notably `/`, `/sign-in`, `/sign-up`) is public to the middleware. `auth().protect()` bounces an unauthenticated request to the Clerk sign-in. Note the comment: middleware only enforces "is signed in"; **the admin-ROLE gate is enforced separately** server-side ([middleware.ts:15-17](middleware.ts#L15)).

The matcher config runs middleware on everything except static files and `_next`, plus `/` and API/trpc routes ([middleware.ts:24-26](middleware.ts#L24)):

```ts
matcher: ["/((?!.*\\..*|_next).*)", "/", "/(api|trpc)(.*)"]
```

### 2.2 Global Clerk + provider configuration (`app/layout.tsx`)

The root layout ([app/layout.tsx](app/layout.tsx)) wraps the whole tree in `<ClerkProvider>` and a custom `<Providers>` (React Query). Key redirect policy lives here ([app/layout.tsx:31-38](app/layout.tsx#L31)):

```tsx
signInUrl="/sign-in"
signUpUrl="/sign-up"
afterSignOutUrl="/"
signUpForceRedirectUrl="/onboarding"        // first-time sign-up → forced onboarding
signInFallbackRedirectUrl="/dashboard"      // returning sign-in → dashboard
```

It also loads three Google fonts as CSS variables — `Fraunces` (`--font-display`, serif headlines), `Hanken_Grotesk` (`--font-sans`, body), `JetBrains_Mono` (`--font-mono`, technical labels) ([app/layout.tsx:8-21](app/layout.tsx#L8)) — and supplies a large `appearance` object that re-themes every Clerk widget (cards, social buttons, the `UserButton` popover) to match the dark "glass" aesthetic ([app/layout.tsx:39-88](app/layout.tsx#L39)). The `<html>` is forced to `className="dark"` and `color-scheme: dark` ([app/layout.tsx:90](app/layout.tsx#L90)).

### 2.3 `dynamic = "force-dynamic"` on every authed/identity page

Every per-user or post-redirect page exports `export const dynamic = "force-dynamic"` so Next never serves a cached/static shell that could leak one user's profile to another or flash stale state right after an OAuth redirect:

- Dashboard ([app/dashboard/page.tsx:10](app/dashboard/page.tsx#L10))
- Analytics ([app/analytics/page.tsx:7](app/analytics/page.tsx#L7))
- Admin ([app/admin/page.tsx:9](app/admin/page.tsx#L9))
- Onboarding ([app/onboarding/page.tsx:9](app/onboarding/page.tsx#L9))
- Sign-in ([app/sign-in/[[...sign-in]]/page.tsx:7](app/sign-in/[[...sign-in]]/page.tsx#L7))
- Sign-up ([app/sign-up/[[...sign-up]]/page.tsx:5](app/sign-up/[[...sign-up]]/page.tsx#L5))

`/devices`, `/connect`, and `/pair/[code]` are `"use client"` components, so they're inherently dynamic (no static profile is rendered server-side).

---

## 3. Route Inventory (map)

| Route | File | Rendering | Middleware (signed-in) | Onboarding gate | Admin gate | Live data |
|---|---|---|---|---|---|---|
| `/` | [app/page.tsx](app/page.tsx) | Server (static composition) | No (public) | No | No | None |
| `/sign-in/[[...sign-in]]` | [app/sign-in/[[...sign-in]]/page.tsx](app/sign-in/[[...sign-in]]/page.tsx) | Server, force-dynamic | No (public) | No | No | Clerk `<SignIn>` |
| `/sign-up/[[...sign-up]]` | [app/sign-up/[[...sign-up]]/page.tsx](app/sign-up/[[...sign-up]]/page.tsx) | Server, force-dynamic | No (public) | No | No | Clerk `<SignUp>` |
| `/onboarding` | [app/onboarding/page.tsx](app/onboarding/page.tsx) | Server (RSC) + client form | Yes | Special (see §7) | No | `getBackendProfile()` + `currentUser()` |
| `/dashboard` | [app/dashboard/page.tsx](app/dashboard/page.tsx) | Server (RSC) + client `<AnalyticsCards>` | Yes | `requireOnboarded` | No | profile (server) + analytics (client) |
| `/analytics` | [app/analytics/page.tsx](app/analytics/page.tsx) | Server shell + client `<AnalyticsView>` | Yes | `requireOnboarded` | No | `useAnalyticsDetail` (client) |
| `/admin` | [app/admin/page.tsx](app/admin/page.tsx) | Server shell + client `<AdminView>` | Yes | `requireOnboardedAndAdmin` | (same guard) | `/api/frontend/admin/*` (client) |
| `/devices` | [app/devices/page.tsx](app/devices/page.tsx) | Client | Yes | (none in page) | No | `useDevices` (client, 60s poll) |
| `/connect` | [app/connect/page.tsx](app/connect/page.tsx) | Client | Yes | (none in page) | No | Camera/QR (client) |
| `/personalize` | [app/personalize/page.tsx](app/personalize/page.tsx) | Server shell + client `<PersonalizationView>` | Yes | `requireOnboarded` | No | `usePersonalization` / `useSavePersonalization` (client) |
| `/survey` | [app/survey/page.tsx](app/survey/page.tsx) | Server shell + client `<SurveyView>` | Yes | `requireOnboarded` | No | pilot survey status/submit + consent (client) |
| `/pair` | [app/pair/page.tsx](app/pair/page.tsx) | Server | Yes | n/a (redirect) | No | None (redirect → `/devices`) |
| `/pair/[code]` | [app/pair/[code]/page.tsx](app/pair/[code]/page.tsx) | Client | Yes | (none in page) | No | `usePairingInfo`, `useCompletePairing` |

> Note: `/devices`, `/connect`, `/pair/[code]` are signed-in-only (middleware) but **do not** call `requireOnboarded()` in the page. They rely on `useApi().ready` (Clerk loaded + signed in) before issuing any backend call ([api.ts:171](lib/api.ts#L171)).

> **Updated 2026-07-03.** Two pilot routes were added: **`/personalize`** ("how I learn best" preference capture, collection-only) and **`/survey`** (pilot `?kind=baseline|exit` snapshot; baseline also records consent). Both use the `requireOnboarded` gate. The `/admin` gate was refactored from `requireOnboarded()` + `requireAdmin()` (two sequential probes) into the single concurrent `requireOnboardedAndAdmin()` (see §4.5). Every authed route segment (`admin, analytics, connect, dashboard, devices, personalize, simulator`) also gained a **`loading.tsx`** Suspense skeleton — see §8.5.

---

## 4. The Auth & Onboarding Gate Engine (`lib/auth-guard.ts`)

This server-only module ([lib/auth-guard.ts](lib/auth-guard.ts)) is the heart of page gating. Its central design decision (stated at the top of the file): **the durable Supabase profile row is the SINGLE source of truth**, NOT Clerk `publicMetadata`. The old design read both and drifted — right after sign-in/OAuth, `currentUser()` lags a render and the backend probe can transiently 401; when both degraded at once a fully-onboarded user got bounced back to `/onboarding`. Reading only the durable row removes that bug class and an extra Clerk round-trip per navigation ([lib/auth-guard.ts:1-12](lib/auth-guard.ts#L1)).

### 4.1 Constants

- `BACKEND_URL` = `process.env.NEXT_PUBLIC_BACKEND_URL ?? process.env.BACKEND_URL ?? "http://localhost:8000"` ([lib/auth-guard.ts:17-18](lib/auth-guard.ts#L17)).
- `PROFILE_PROBE_TIMEOUT_MS = 9000` — hard ceiling for the server-side probe ([lib/auth-guard.ts:31](lib/auth-guard.ts#L31)). The comment is critical: a cold Clerk-verified request (JWKS fetch + RSA verify + a fresh asyncpg connection to remote Supabase) runs **6–13s** in practice. The old 2.5s ceiling aborted *every* probe, making `requireAdmin()` fail-closed and bounce real admins. 9s lets a warm backend answer definitively while a truly-down backend still degrades after one bounded wait ([lib/auth-guard.ts:22-30](lib/auth-guard.ts#L22)).

### 4.2 `ProfileStatus` and `BackendProfile`

```ts
type ProfileStatus = "exists" | "missing" | "unreachable";   // line 33
```

`BackendProfile` ([lib/auth-guard.ts:37-50](lib/auth-guard.ts#L37)) mirrors the backend `ProfileOut` (snake_case 1:1 with the wire payload so the dashboard renders straight off it):

```
user_id, full_name, email, phone, target_exam, prep_duration,
learning_style, explain_depth, study_rhythm, focus_subject,
onboarding_complete, updated_at
```

### 4.3 `getBackendProfile()` — one fetch, both answers

[lib/auth-guard.ts:56-99](lib/auth-guard.ts#L56). Mechanics:

1. `const { getToken } = auth(); const token = await getToken();` — get the Clerk session JWT. If null → `{ status: "unreachable", profile: null }` ([lib/auth-guard.ts:67-72](lib/auth-guard.ts#L67)).
2. `fetch(\`${BACKEND_URL}/api/frontend/profile\`)` with `Authorization: Bearer <token>`, `cache: "no-store"`, and `signal: AbortSignal.timeout(9000)` ([lib/auth-guard.ts:73-77](lib/auth-guard.ts#L73)).
3. On `!res.ok` → log + `{ status: "unreachable", profile: null }` ([lib/auth-guard.ts:79-83](lib/auth-guard.ts#L79)).
4. On success, parse JSON. The backend returns **200 + profile** when the row exists, **200 + null** when it doesn't:
   - non-null body → `{ status: "exists", profile }`
   - null body → `{ status: "missing", profile: null }` ([lib/auth-guard.ts:90-92](lib/auth-guard.ts#L90)).
5. Any thrown error (AbortError timeout / network / backend down) → `{ status: "unreachable", profile: null }` ([lib/auth-guard.ts:93-98](lib/auth-guard.ts#L93)).

There is **no retry** — this runs inside the page's server render, so each extra attempt is dead time on a blank screen. It logs `(SLOW — blocks render)` if `ms > 3000` ([lib/auth-guard.ts:60-64](lib/auth-guard.ts#L60), [lib/auth-guard.ts:87-89](lib/auth-guard.ts#L87)).

### 4.4 `requireOnboarded()` — the dashboard/analytics/admin gate

[lib/auth-guard.ts:111-118](lib/auth-guard.ts#L111):

```ts
const { userId } = auth();
if (!userId) redirect("/sign-in");
const { status, profile } = await getBackendProfile();
if (status === "missing") redirect("/onboarding");
return profile;  // "exists" → profile; "unreachable" → null (degrade, don't re-ask)
```

The asymmetric bounce policy is deliberate ([lib/auth-guard.ts:101-110](lib/auth-guard.ts#L101)): on `"unreachable"` it does **not** redirect to `/onboarding` — re-asking a real onboarded user due to a transient backend blip is the exact bug being fixed. It lets them through with a `null` profile; the page degrades and the next navigation self-heals. Genuinely-new users reach `/onboarding` via `signUpForceRedirectUrl`, not this path.

### 4.5 `requireOnboardedAndAdmin()` — the admin gate (Updated 2026-07-03)

[lib/auth-guard.ts](lib/auth-guard.ts). The old `/admin` gate ran two **sequential** awaits — `requireOnboarded()` then `requireAdmin()`, each a 9s-timeout probe, so a cold backend meant up to ~18s of blank screen. Commit `ef07d7f` ("optimizations") collapsed them into **one concurrent guard**:

- The former `requireAdmin()` is replaced by a redirect-free helper **`getAdminVerdict(): "admin" | "not_admin" | "unknown"`**. It probes `GET /api/frontend/me → is_admin` (sourced solely from the `admins` table) and returns:
  - `"not_admin"` on a clear `is_admin === false`, or no session token (real auth failure).
  - `"admin"` on a clear `is_admin === true`.
  - `"unknown"` on any unreachable / slow / 5xx / errored probe.
- **`requireOnboardedAndAdmin()`** first checks `userId` (→ `redirect("/sign-in")`), then runs `Promise.all([getBackendProfile(), getAdminVerdict()])`. After the await it applies redirects in deterministic order: `status === "missing"` → `/onboarding`, then `verdict === "not_admin"` → `/dashboard`. Because `redirect()` throws `NEXT_REDIRECT`, both calls sit **outside** any `try` so the control-flow throw is never swallowed.

The **degrade on `"unknown"`** is still **safe**: `/admin` shows no data of its own — every panel fetches `/api/frontend/admin/*`, which re-check `require_admin` server-side (403 `NOT_ADMIN`). So a non-admin who slips past a timed-out probe sees only an "Admin access required" notice, never data. `PROFILE_PROBE_TIMEOUT_MS` (9s) was left unchanged — it is now hidden behind the route's `loading.tsx` skeleton (see `OPTIMIZATION.md §2.1`).

---

## 5. Public Route: `/` (Landing)

[app/page.tsx](app/page.tsx) — the marketing landing page. It is a pure server component that composes six section components in order ([app/page.tsx:8-19](app/page.tsx#L8)):

```tsx
<main className="relative">
  <Nav />       // components/landing/Nav
  <Hero />      // components/landing/Hero
  <Features />  // components/landing/Features
  <Exams />     // components/landing/Exams
  <CTA />       // components/landing/CTA
  <Footer />    // components/landing/Footer
</main>
```

- **Auth:** none — public (not matched by the middleware protector).
- **Data:** none. No backend calls.
- **Outbound navigation:** through the `Nav` / `CTA` components (not in scope here) — conventionally to `/sign-in` / `/sign-up`. It is also the `afterSignOutUrl` target ([app/layout.tsx:34](app/layout.tsx#L34)) and the "Cancel / Not your lamp?" target from the pairing card ([app/pair/[code]/page.tsx:116](app/pair/[code]/page.tsx#L116)).

---

## 6. Auth Routes: `/sign-in` and `/sign-up`

Both are **Clerk catch-all** routes (`[[...sign-in]]` / `[[...sign-up]]`), which also render the OAuth **SSO callback** sub-routes (`/sign-in/sso-callback`, `/sign-up/sso-callback`). Both export `dynamic = "force-dynamic"` so the Google round-trip always lands on a freshly-evaluated page (no stuck/refresh) ([app/sign-in/[[...sign-in]]/page.tsx:4-7](app/sign-in/[[...sign-in]]/page.tsx#L4), [app/sign-up/[[...sign-up]]/page.tsx:4-5](app/sign-up/[[...sign-up]]/page.tsx#L4)).

### 6.1 `/sign-in`

[app/sign-in/[[...sign-in]]/page.tsx:9-34](app/sign-in/[[...sign-in]]/page.tsx#L9) renders a centered layout (amber blur glow + Lumos wordmark linking to `/`) and the Clerk `<SignIn>` widget with **explicit redirect props on the component itself** (not only on the provider) so OAuth is unambiguous in both cases ([app/sign-in/[[...sign-in]]/page.tsx:18-30](app/sign-in/[[...sign-in]]/page.tsx#L18)):

```tsx
<SignIn
  routing="path" path="/sign-in"
  signUpUrl="/sign-up"
  fallbackRedirectUrl="/dashboard"          // existing user
  signUpForceRedirectUrl="/onboarding"      // brand-new user (OAuth transfers sign-in → sign-up)
/>
```

The comment explains why `signUp*` props are needed *here*: without them a first-time Google user can stall on the SSO callback because the sign-in→sign-up *transfer* has no destination ([app/sign-in/[[...sign-in]]/page.tsx:18-23](app/sign-in/[[...sign-in]]/page.tsx#L18)).

### 6.2 `/sign-up`

[app/sign-up/[[...sign-up]]/page.tsx:7-26](app/sign-up/[[...sign-up]]/page.tsx#L7) is the mirror: same layout, with `<SignUp>` configured to push **all new accounts** (including Google OAuth) straight into onboarding ([app/sign-up/[[...sign-up]]/page.tsx:16-22](app/sign-up/[[...sign-up]]/page.tsx#L16)):

```tsx
<SignUp routing="path" path="/sign-up" signInUrl="/sign-in" forceRedirectUrl="/onboarding" />
```

---

## 7. Onboarding Route: `/onboarding`

This is the **forced onboarding** step and the most logic-heavy page. It spans three files: the server page ([app/onboarding/page.tsx](app/onboarding/page.tsx)), the client form ([app/onboarding/OnboardingForm.tsx](app/onboarding/OnboardingForm.tsx)), and the server action ([app/onboarding/actions.ts](app/onboarding/actions.ts)). The shared question contract lives in [lib/onboarding.ts](lib/onboarding.ts).

### 7.1 Server page control flow (`app/onboarding/page.tsx`)

New OAuth (Google) sign-ups land here via `signUpForceRedirectUrl` ([app/onboarding/page.tsx:6-9](app/onboarding/page.tsx#L6)). Steps:

1. **Gate on `userId`, not `currentUser()`** ([app/onboarding/page.tsx:21-23](app/onboarding/page.tsx#L21)):
   ```ts
   const { userId } = auth();
   if (!userId) redirect("/sign-in");
   ```
   The comment: gate on `userId` (cookie/handshake — reliable post-OAuth), NOT `currentUser()` which can lag one render while the Google session propagates. Bouncing to `/sign-in` on that lag is what made OAuth feel stuck.

2. **Fire both reads concurrently** to avoid doubling time-to-render ([app/onboarding/page.tsx:27-30](app/onboarding/page.tsx#L27)):
   ```ts
   const [{ status }, user] = await Promise.all([
     getBackendProfile(),
     currentUser().catch(() => null),
   ]);
   ```
   `currentUser()` is best-effort, used **only** to prefill the name.

3. **Skip to dashboard only on a definitive `"exists"`** ([app/onboarding/page.tsx:36](app/onboarding/page.tsx#L36)):
   ```ts
   if (status === "exists") redirect("/dashboard");
   ```
   Both `"missing"` (new user) and `"unreachable"` (transient blip) fall through to the form so nobody is ever stranded and no redirect loop forms with `requireOnboarded()`. A re-submit is harmless because the backend upsert is idempotent ([app/onboarding/page.tsx:32-36](app/onboarding/page.tsx#L32)).

4. **Compute `defaultName`** = `[user?.firstName, user?.lastName].filter(Boolean).join(" ")` ([app/onboarding/page.tsx:38](app/onboarding/page.tsx#L38)).

5. **Render** a centered hero ("Let's tune the brain to you.") plus `<OnboardingForm defaultName={defaultName} />` ([app/onboarding/page.tsx:40-58](app/onboarding/page.tsx#L40)).

### 7.2 The onboarding contract (`lib/onboarding.ts`)

[lib/onboarding.ts](lib/onboarding.ts) is the **single shared contract** imported by the client form, the server action, the auth guard (shape-wise), and (shape-wise) the backend `ProfileIn`. It defines **7 option-based fields** plus the free-text name. The option lists are frozen `as const` tuples and a derived type for each:

| Constant | Values | Type |
|---|---|---|
| `TARGET_EXAMS` | `JEE`, `NEET`, `CAT`, `UPSC` | `TargetExam` ([lib/onboarding.ts:11-12](lib/onboarding.ts#L11)) |
| `PREP_DURATIONS` | "Just getting started", "A few months in", "About a year", "More than a year" | `PrepDuration` ([lib/onboarding.ts:14-20](lib/onboarding.ts#L14)) |
| `LEARNING_STYLES` | worked example / intuition first / picture or analogy / trying problems | `LearningStyle` ([lib/onboarding.ts:23-29](lib/onboarding.ts#L23)) |
| `EXPLAIN_DEPTHS` | short & simple / balanced / go deep | `ExplainDepth` ([lib/onboarding.ts:32-37](lib/onboarding.ts#L32)) |
| `STUDY_RHYTHMS` | short bursts / long sessions / a little every day / close to deadlines | `StudyRhythm` ([lib/onboarding.ts:40-46](lib/onboarding.ts#L40)) |
| `FOCUS_SUBJECTS` | Physics, Chemistry, Mathematics, Biology, "Still deciding" | `FocusSubject` ([lib/onboarding.ts:49-56](lib/onboarding.ts#L49)) |

Design note from the file: `target_exam` stays within the DB CHECK (JEE/NEET/CAT/UPSC); every psychology field lands in `user_profiles.extra` (JSONB, no migration) ([lib/onboarding.ts:5-9](lib/onboarding.ts#L5)).

`ONBOARDING_QUESTIONS` ([lib/onboarding.ts:66-100](lib/onboarding.ts#L66)) is the ordered render list, each entry `{ name, label, hint?, options }` where `name` matches the form field and the action keys. Six questions render (the name field is rendered separately by the form).

**Validators** are generated by a curried helper ([lib/onboarding.ts:115-123](lib/onboarding.ts#L115)):

```ts
const _oneOf = (list) => (v) => typeof v === "string" && list.includes(v);
export const isTargetExam = _oneOf(TARGET_EXAMS);  // …and one per field
```

`OnboardingMetadata` ([lib/onboarding.ts:104-113](lib/onboarding.ts#L104)) is the shape mirrored into Clerk `publicMetadata`, with `onboardingComplete: true`.

### 7.3 The client form (`app/onboarding/OnboardingForm.tsx`)

A `"use client"` form built on React's `useFormState`/`useFormStatus` ([app/onboarding/OnboardingForm.tsx:1-14](app/onboarding/OnboardingForm.tsx#L1)):

```tsx
const [state, formAction] = useFormState(completeOnboarding, INITIAL);
```

- On success the **server action itself redirects** to `/dashboard`, so `state` only ever carries a validation/save error to display — no client-side navigation effect (the old `push()+refresh()` race froze the page) ([app/onboarding/OnboardingForm.tsx:11-14](app/onboarding/OnboardingForm.tsx#L11)).
- Renders a required text `<input name="fullName">` prefilled with `defaultName` ([app/onboarding/OnboardingForm.tsx:20-34](app/onboarding/OnboardingForm.tsx#L20)).
- Maps `ONBOARDING_QUESTIONS` into `<fieldset>`s, each option a **`peer sr-only` radio** with a styled `<span>` label — the visual selection state is pure CSS `peer-checked:` ([app/onboarding/OnboardingForm.tsx:37-63](app/onboarding/OnboardingForm.tsx#L37)). Each radio is `required`.
- Error block renders `state.error` in a rose alert when present ([app/onboarding/OnboardingForm.tsx:66-71](app/onboarding/OnboardingForm.tsx#L66)).
- `SubmitButton` uses `useFormStatus().pending` to toggle between "Setting things up…" (spinner) and "Start learning with Lumos" ([app/onboarding/OnboardingForm.tsx:82-101](app/onboarding/OnboardingForm.tsx#L82)).

### 7.4 The server action (`app/onboarding/actions.ts`)

`completeOnboarding(_prev, formData)` is a `"use server"` action ([app/onboarding/actions.ts:1](app/onboarding/actions.ts#L1)). Full mechanics:

**Constants:**
- `BACKEND_URL` = same env fallback chain ([app/onboarding/actions.ts:20-21](app/onboarding/actions.ts#L20)).
- `SAVE_TIMEOUT_MS = 8000` — bounded write so a cold backend can't make the submit spin forever ([app/onboarding/actions.ts:34-36](app/onboarding/actions.ts#L34)).

**Step 0 — session check** ([app/onboarding/actions.ts:79-80](app/onboarding/actions.ts#L79)):
```ts
const { userId, getToken } = auth();
if (!userId) return { error: "Your session expired — sign in again." };
```

**Step 1 — read + validate all fields** ([app/onboarding/actions.ts:82-96](app/onboarding/actions.ts#L82)). `fullName` is trimmed; each option field runs through its `is*` validator, returning a specific human error on failure:

| Field | Failure message |
|---|---|
| `fullName.length < 2` | "Please enter your name." |
| `!isTargetExam` | "Choose what you're preparing for." |
| `!isPrepDuration` | "Let me know how long you've been preparing." |
| `!isLearningStyle` | "Pick what helps a concept click for you." |
| `!isExplainDepth` | "Tell me how much detail you like." |
| `!isStudyRhythm` | "Pick your study rhythm." |
| `!isFocusSubject` | "Pick a subject to focus on." |

**Step 2 — assemble `OnboardingMetadata`** with `onboardingComplete: true` ([app/onboarding/actions.ts:98-107](app/onboarding/actions.ts#L98)).

**Step 3 — durable save (source of truth)** ([app/onboarding/actions.ts:109-140](app/onboarding/actions.ts#L109)):
- Get a Clerk token, then best-effort resolve the user's primary email (`currentUser()?.primaryEmailAddress?.emailAddress ?? emailAddresses[0] ?? null`). Why: default Clerk session tokens don't carry email, so the backend can't derive it from the JWT — capturing it here makes the stored profile actually identify the human. Email resolution failure is non-fatal (`email = null`) ([app/onboarding/actions.ts:113-124](app/onboarding/actions.ts#L113)).
- `saveProfileToBackend(token, body)` ([app/onboarding/actions.ts:40-68](app/onboarding/actions.ts#L40)) does `PUT ${BACKEND_URL}/api/frontend/profile` with `Authorization: Bearer <token>`, `cache: "no-store"`, `signal: AbortSignal.timeout(8000)`, body = the `ProfileBody` (snake_case: `full_name, email, target_exam, prep_duration, learning_style, explain_depth, study_rhythm, focus_subject`). Returns `res.ok` boolean; any null token or thrown error returns `false`. It logs server-side timing and flags `(SLOW)` if `ms > 3000`.
- If `!saved` → return `{ error: "Couldn't reach the server to save your profile — it may be starting up. Please try again in a moment." }` ([app/onboarding/actions.ts:135-140](app/onboarding/actions.ts#L135)). **The durable save MUST succeed before onboarding is marked complete** ([app/onboarding/actions.ts:38-39](app/onboarding/actions.ts#L38)).

**Step 4 — mirror into Clerk `publicMetadata` (best-effort)** ([app/onboarding/actions.ts:142-153](app/onboarding/actions.ts#L142)). `getClerk()` handles the dual-shape `clerkClient` (callable vs object) ([app/onboarding/actions.ts:70-73](app/onboarding/actions.ts#L70)), then `client.users.updateUserMetadata(userId, { publicMetadata: metadata })`. A failure here is **non-fatal** — the Supabase row is now the single source of truth for the gate, so a failed metadata write must not block an already-onboarded user. It's still written for name prefill / Clerk-native flows.

**Step 5 — server-side redirect** ([app/onboarding/actions.ts:155-163](app/onboarding/actions.ts#L155)):
```ts
redirect("/dashboard");
```
The comment explains the race fix: navigating *in the action* (instead of returning `{ok:true}` and calling `router.push()+router.refresh()` from a client effect) is race-free. The old client pattern fired `refresh()` at the current route just as `push()` left it, cancelling the navigation and freezing the page on `/onboarding`. `redirect()` throws `NEXT_REDIRECT`, performed as part of the action response. The dashboard is `force-dynamic` and reads the profile fresh from the DB, so there's nothing stale to invalidate.

### 7.5 Onboarding journey diagram

```mermaid
sequenceDiagram
    participant U as User (browser)
    participant CL as Clerk
    participant OP as /onboarding (RSC)
    participant FA as completeOnboarding (server action)
    participant BE as Backend (FastAPI)
    participant DB as Supabase

    U->>CL: Sign up (email or Google OAuth)
    CL-->>U: signUpForceRedirectUrl → /onboarding
    U->>OP: GET /onboarding
    OP->>OP: auth() → userId? (no → redirect /sign-in)
    OP->>BE: GET /api/frontend/profile (getBackendProfile, 9s timeout)
    OP->>CL: currentUser() (best-effort, name prefill)
    alt status === "exists"
        OP-->>U: redirect /dashboard
    else missing / unreachable
        OP-->>U: render OnboardingForm(defaultName)
    end
    U->>FA: submit form (7 fields + name)
    FA->>FA: validate each field (is* checks)
    FA->>BE: PUT /api/frontend/profile (8s timeout)
    BE->>DB: upsert user_profiles (+ extra JSONB)
    BE-->>FA: 200 ok
    FA->>CL: updateUserMetadata (best-effort)
    FA-->>U: redirect /dashboard
```

---

## 8. Gated App Routes

These share the `<AppHeader>` chrome (§10.1) and the same `requireOnboarded` gate; `/admin` adds the admin gate (§4.5). The pilot routes `/personalize` and `/survey` are covered in §8.5, and the route-level loading skeletons in §8.6.

### 8.1 `/dashboard`

[app/dashboard/page.tsx](app/dashboard/page.tsx) — an **async server component** gated by `requireOnboarded()`. Control flow:

1. `const profile = await requireOnboarded();` — bounces signed-out → `/sign-in`, not-onboarded → `/onboarding` before anything renders ([app/dashboard/page.tsx:14-18](app/dashboard/page.tsx#L14)). `profile` is `null` only when the backend was transiently unreachable, in which case the tiles render placeholders.
2. `firstName = (profile?.full_name || "there").split(" ")[0]` ([app/dashboard/page.tsx:19](app/dashboard/page.tsx#L19)).
3. Build the `stats` tile array from the durable profile (the single source of truth, so tiles never disagree with the gate) ([app/dashboard/page.tsx:21-25](app/dashboard/page.tsx#L21)):
   - Target exam → `profile?.target_exam ?? "—"`
   - Preparation → `profile?.prep_duration ?? "—"`
   - Focus → `profile?.focus_subject ?? "—"`

**Rendered sections** ([app/dashboard/page.tsx:27-109](app/dashboard/page.tsx#L27)):
- An `.aurora` ambient backdrop + `<AppHeader active="/dashboard" />`.
- A hero greeting "Welcome back, {firstName}." with staggered `.rise` entrance.
- Three profile-glance glass tiles (staggered `animationDelay: 140 + i*80` ms).
- A **primary "Connect your lamp" CTA** — a `<Link href="/connect">` styled as liquid glass, the page's primary action ([app/dashboard/page.tsx:68-86](app/dashboard/page.tsx#L68)).
- **`<PersonalizeCard />`** (Updated 2026-07-03) — a "how I learn best" CTA linking to `/personalize`. Smart state: a prominent amber nudge ("Tell Lumos how you learn best · 2 minutes…") while the personalization profile is empty, flipping to a quiet cyan "Your learning preferences · Saved — tap to update" once filled, so it never nags. Returns `null` while `usePersonalization()` is loading to avoid a nudge→done flash ([components/app/PersonalizeCard.tsx](components/app/PersonalizeCard.tsx)).
- `<AnalyticsCards />` — live analytics fetched client-side from the backend Frontend Manager ([app/dashboard/page.tsx:88-89](app/dashboard/page.tsx#L88)); this is where `useAnalytics()` ([profile.ts:99-109](lib/profile.ts#L99)) feeds `/api/frontend/analytics`.
- A "Brain console — coming soon" teaser ([app/dashboard/page.tsx:91-105](app/dashboard/page.tsx#L91)).

### 8.2 `/analytics`

[app/analytics/page.tsx](app/analytics/page.tsx) — a thin server shell. It `await requireOnboarded()` (same gate as dashboard) then renders `.aurora` + `<AppHeader active="/analytics" />` + `<AnalyticsView />` ([app/analytics/page.tsx:9-20](app/analytics/page.tsx#L9)). All live data + charts are fetched **client-side** inside `<AnalyticsView>` ([app/analytics/page.tsx:5-6](app/analytics/page.tsx#L5)), which uses `useAnalyticsDetail(days)` → `GET /api/frontend/analytics/detail?days=N` (default 14 days, 60s poll) ([profile.ts:151-159](lib/profile.ts#L151)). The rich payload `AnalyticsDetail` includes `daily[]`, percentiles (`p50_ms`, `p95_ms`), `avg_confidence`, `total_cost_usd`, `escalated_pct`, and several `*_mix` maps ([profile.ts:129-149](lib/profile.ts#L129)).

### 8.3 `/admin`

[app/admin/page.tsx](app/admin/page.tsx) — gated by the single concurrent **`await requireOnboardedAndAdmin()`** (Updated 2026-07-03; previously two sequential `requireOnboarded()` + `requireAdmin()` awaits — see §4.5). A non-admin is bounced to `/dashboard` before any admin shell renders. Then renders `.aurora` + `<AppHeader active="/admin" />` + `<AdminView />`. Live system-wide data + charts are fetched client-side in `<AdminView>` against `/api/frontend/admin/*`, and those endpoints re-check `require_admin` server-side (403 `NOT_ADMIN`), so the degrade path cannot leak data. `<AdminView>` now spans **eleven tabs** — Overview, Pilot, Insights, **Analytics** (range-aware output-generation + total latency, added 2026-07-11), Models, Users, Devices, Sessions, Turns, Events, and **OTA** (firmware publish/history) — documented in [02-components.md](02-components.md).

### 8.4 `/devices`

[app/devices/page.tsx](app/devices/page.tsx) — a `"use client"` page, the lamp-management hub. It is **not** wrapped by `requireOnboarded`; it relies on middleware (signed-in) and `useApi().ready` before issuing calls.

**Top-level component (`DevicesPage`)** ([app/devices/page.tsx:25-76](app/devices/page.tsx#L25)):
- `const { data, isLoading, isError, error, refetch } = useDevices();` → `devices = data?.devices ?? []` ([app/devices/page.tsx:26-27](app/devices/page.tsx#L26)). `useDevices()` polls `GET /api/devices` every **60s** ([devices.ts:135-145](lib/devices.ts#L135)).
- Renders `<AppHeader active="/devices" />`, a header with a manual **Refresh** button (`onClick={() => refetch()}`), and a state machine for the list body ([app/devices/page.tsx:51-70](app/devices/page.tsx#L51)):
  - `isLoading` → `<SkeletonRow />`
  - `isError` → glass error card showing `friendlyError(error).message` + a "Try again" button
  - `devices.length === 0` → `<EmptyState />`
  - else → one `<DeviceRow>` per device
- Always renders `<AddLampGuide />` at the bottom (3-step guide + a "Scan a QR code" `<Link href="/connect">`) ([app/devices/page.tsx:72](app/devices/page.tsx#L72), [app/devices/page.tsx:249-282](app/devices/page.tsx#L249)).

**`DeviceRow`** ([app/devices/page.tsx:78-204](app/devices/page.tsx#L78)) — per-device card with inline rename + unlink:
- Hooks: `useRenameDevice()`, `useUnlinkDevice()` ([devices.ts:147-179](lib/devices.ts#L147)); local state `editing`, `name`, `confirmOpen`.
- A `useEffect` re-syncs the local field to `device.friendly_name` when not editing ([app/devices/page.tsx:86-88](app/devices/page.tsx#L86)).
- **Rename validation:** `canSave = trimmed.length >= 1 && trimmed.length <= 60 && trimmed !== device.friendly_name` ([app/devices/page.tsx:90-91](app/devices/page.tsx#L90)). The input is `maxLength={60}`, autoFocused; **Enter** saves, **Escape** cancels ([app/devices/page.tsx:119-129](app/devices/page.tsx#L119)). `save()` no-ops (closes editing) if `!canSave`, else `rename.mutate({ id, friendly_name: trimmed }, { onSuccess: () => setEditing(false) })` ([app/devices/page.tsx:93-102](app/devices/page.tsx#L93)).
- **Subtitle / status:** `subtitle` is `"last seen <ago>"` if online, `"offline (last seen <ago>)"` if offline-with-timestamp, else `"offline"` ([app/devices/page.tsx:104-109](app/devices/page.tsx#L104)). `formatAgo` renders `Ns/min/h/d ago` ([time.ts:19-31](lib/time.ts#L19)). A `<StatusDot online>` shows an animated emerald `ping` ring when online ([app/devices/page.tsx:206-221](app/devices/page.tsx#L206)).
- **Unlink:** opens a `<ConfirmDialog destructive>`; on confirm `unlink.mutate(device.device_id, { onSettled: () => setConfirmOpen(false) })` ([app/devices/page.tsx:184-201](app/devices/page.tsx#L184)). `useUnlinkDevice` does an **optimistic remove** (filters the device out of the cached list in `onMutate`, captures `prev`), rolls back on error, and `invalidateQueries(["devices"])` on settle ([devices.ts:160-179](lib/devices.ts#L160)).

**`Device` shape** ([devices.ts:21-27](lib/devices.ts#L21)): `device_id, friendly_name, paired_at, last_seen_at (nullable ISO), online (boolean — last_seen_at within 60 s, computed server-side)`.

### 8.5 `/personalize` and `/survey` — the pilot self-report routes (Updated 2026-07-03)

Both are thin `force-dynamic` server shells gated by `requireOnboarded()`, rendering `.aurora` + `<AppHeader>` + a client body. Their data layer is `lib/pilot.ts` (see [03-lib-and-data-layer.md](03-lib-and-data-layer.md)).

**`/personalize`** ([app/personalize/page.tsx](app/personalize/page.tsx)) renders `<PersonalizationView>` (`active="/personalize"`). The view is a **"how I learn best"** form — an interest chip-picker (12 presets + free-text custom chips), an answer-length choice (`short | balanced | detailed`), an "example preference" choice (`love | sometimes | rarely`), and a free-text notes box. It seeds from `usePersonalization()` and saves via `useSavePersonalization()` → `POST /api/frontend/pilot/personalization`. This is **collection-only**: the code comment is explicit that wiring the preferences into the tutor's system prompt is a separate, still-under-review decision.

**`/survey`** ([app/survey/page.tsx](app/survey/page.tsx)) reads `searchParams.kind` (`"exit"` → exit survey, anything else → `baseline`) and renders `<SurveyView kind={...}>`. This is the pilot's **matched before/after instrument**: a shared 4-subject confidence block (Physics/Chemistry/Mathematics/Biology, asked identically on both so the delta is measurable) plus baseline-specific questions (recent mock score, study hours, prior doubt-clearing tools, biggest challenge) or exit-specific ones (recent score, NPS, "did it help you learn", favourite thing, most frustrating). Config-driven — questions post as a JSON answer map (`POST /api/frontend/pilot/survey`), so they can change with no backend change. The **baseline** variant additionally shows a consent checkbox and records it best-effort via `POST /api/frontend/pilot/consent` (`consent_type: "pilot_participation"`) before the survey write. `useSurveyStatus()` surfaces a "you already submitted this on `<date>`" notice.

### 8.6 Route-level loading skeletons (`loading.tsx`) — Updated 2026-07-03

Every authed route segment now ships a Next.js `loading.tsx` — `admin, analytics, connect, dashboard, devices, personalize, simulator` — each a one-line file that renders `<PageSkeleton active="/…">`. `PageSkeleton` ([components/app/PageSkeleton.tsx](components/app/PageSkeleton.tsx)) keeps the real `<AppHeader>` (visual continuity; `useMe` is cached at 60s so it doesn't refetch on skeleton mount) above an `animate-pulse` glass placeholder grid. Their purpose is to give the App Router an **instant Suspense boundary**: without one, a `<Link>` click to a `force-dynamic` page couldn't commit until the server render finished — and those pages block on the uncached auth probe (up to 9s; `/admin` formerly ran two back-to-back). With the boundary the router swaps to the skeleton immediately and streams the real page behind it. This is the fix for the "click a nav item → nothing → stuck a few seconds → then it opens" symptom (repo-root `OPTIMIZATION.md §2.1`).

---

## 9. The Pairing Journey: `/connect`, `/pair`, `/pair/[code]`

This is the central user journey of the device side. The flow: lamp shows a QR → user scans at `/connect` → handoff to `/pair/[code]` → confirm → backend links the lamp → success → `/devices`.

### 9.1 `/connect` — the scanner

[app/connect/page.tsx](app/connect/page.tsx), a `"use client"` page. It renders `.aurora` + `<AppHeader active="/devices" />` (highlighting Devices in the nav) + a hero + `<QrScanner>` ([app/connect/page.tsx:13-43](app/connect/page.tsx#L13)). The single handoff is ([app/connect/page.tsx:37](app/connect/page.tsx#L37)):

```tsx
<QrScanner onCode={(code) => router.push(`/pair/${encodeURIComponent(code)}`)} />
```

**`QrScanner`** ([components/app/QrScanner.tsx](components/app/QrScanner.tsx)) offers three input methods in order of convenience ([components/app/QrScanner.tsx:3-11](components/app/QrScanner.tsx#L3)):

1. **Live camera scan** — `getUserMedia({ video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } } })`, then a `requestAnimationFrame` `scanLoop` draws each video frame to a hidden canvas and runs `jsQR(img.data, w, h, { inversionAttempts: "dontInvert" })`. On a hit it calls `fire(found.data)` and stops ([components/app/QrScanner.tsx:50-89](components/app/QrScanner.tsx#L50)). Camera `CamState` is `idle | requesting | scanning | denied | error`; `NotAllowedError`/`SecurityError` → `denied`, anything else → `error` ([components/app/QrScanner.tsx:82-88](components/app/QrScanner.tsx#L82)).
2. **Upload a QR photo** — decodes the image to a canvas and runs `jsQR` once ([components/app/QrScanner.tsx:94-118](components/app/QrScanner.tsx#L94)); on no-match: "No pairing QR found in that image…".
3. **Type the code** — a manual form; submit runs `fire(manual)` ([components/app/QrScanner.tsx:120-123](components/app/QrScanner.tsx#L120)).

`fire(raw)` ([components/app/QrScanner.tsx:30-40](components/app/QrScanner.tsx#L30)) runs `extractPairingCode(raw)` and guards against double-fire via `firedRef`. **`extractPairingCode`** ([lib/pairing-code.ts:6-38](lib/pairing-code.ts#L6)) is liberal: it tries to parse a URL and take the segment after `/pair/` (regex `/\/pair\/([A-Za-z0-9-]+)/`) or a `?code=` query param; falls back to a `/pair/CODE` path match on the raw string, a bare `code=CODE` fragment, or a bare **6–8 alphanumeric** code (`/^[A-Za-z0-9]{6,8}$/`, matching the backend's pairing-code shape). It always `normalize()`s — stripping whitespace/hyphens and uppercasing ([lib/pairing-code.ts:40-42](lib/pairing-code.ts#L40)). Returns `null` when nothing code-shaped is found.

### 9.2 `/pair` — bare redirect

[app/pair/page.tsx](app/pair/page.tsx) is a server component that just `redirect("/devices")` ([app/pair/page.tsx:6-8](app/pair/page.tsx#L6)). Pairing always happens at `/pair/[code]` (the QR target); a bare `/pair` has no standalone meaning, so users land on their lamp list where the "Add a new lamp" guide lives.

### 9.3 `/pair/[code]` — confirm & link

[app/pair/[code]/page.tsx](app/pair/[code]/page.tsx), a `"use client"` dynamic-segment page. It uses a **distinct minimal header** (`<PairHeader>`) instead of `<AppHeader>` — just the wordmark and the Clerk `<UserButton afterSignOutUrl="/" />` ([app/pair/[code]/page.tsx:130-142](app/pair/[code]/page.tsx#L130)).

**State & hooks** ([app/pair/[code]/page.tsx:27-54](app/pair/[code]/page.tsx#L27)):
- `code = decodeURIComponent(params.code)`.
- `info = usePairingInfo(code)` → `GET /api/pairing-info/<code>`, `retry: false`, enabled only when `api.ready && !!code` ([devices.ts:114-122](lib/devices.ts#L114)).
- `complete = useCompletePairing()` → `POST /api/device/complete-pairing` with `{ pairing_code: code }` ([devices.ts:124-133](lib/devices.ts#L124)).
- `now` ticks every 1000ms via `setInterval` for the live countdown ([app/pair/[code]/page.tsx:37-40](app/pair/[code]/page.tsx#L37)).
- On `done` → a 1500ms `setTimeout` then `router.push("/devices")` (brief celebration then off to the list) ([app/pair/[code]/page.tsx:43-47](app/pair/[code]/page.tsx#L43)).
- `expiresMs = new Date(info.data.expires_at).getTime() - now`; `expired = expiresMs <= 0` ([app/pair/[code]/page.tsx:49-50](app/pair/[code]/page.tsx#L49)).
- `onLink = () => complete.mutate(code, { onSuccess: () => setDone(true) })` ([app/pair/[code]/page.tsx:52-54](app/pair/[code]/page.tsx#L52)).

**Render state machine** (priority order) ([app/pair/[code]/page.tsx:64-123](app/pair/[code]/page.tsx#L64)):
1. `done || complete.isSuccess` → `<SuccessCard name={complete.data?.friendly_name ?? info.data?.friendly_name}>` — animated checkmark + 14 framer-motion confetti sparks fanning out via `cos/sin((i/14)·2π)` ([app/pair/[code]/page.tsx:189-222](app/pair/[code]/page.tsx#L189)).
2. `info.isLoading` → `<LoadingCard>` ("Looking up your lamp…").
3. `info.isError` → `<ErrorPanel error={friendlyError(info.error)} onRetry={info.refetch}>`.
4. `complete.isError` → `<ErrorPanel error={friendlyError(complete.error)} onRetry={complete.reset}>`.
5. `expired` → `<ErrorPanel error={friendlyByCode("CODE_EXPIRED")}>` (no retry).
6. else `info.data` → the **confirmation card**: detail rows for **Lamp name**, **Device ID** (mono), **Code** (mono), and a live **Expires** countdown via `formatCountdown(expiresMs)` (tone `warn` when `< 60_000` ms) ([app/pair/[code]/page.tsx:84-95](app/pair/[code]/page.tsx#L84)), plus the primary **"Link this lamp to my account"** button (disabled+spinner while `complete.isPending`) and a "Not your lamp? Cancel" link to `/` ([app/pair/[code]/page.tsx:97-120](app/pair/[code]/page.tsx#L97)).

`formatCountdown` ([time.ts:4-16](lib/time.ts#L4)) renders `"expired"` at ≤0, `"in N seconds"` under 60s, `"in N minutes"` / `"in N min M s"` under an hour, else `"in N hours"`.

### 9.4 Pairing data layer & error mapping (`lib/devices.ts`)

`usePairingInfo`, `useCompletePairing`, `useDevices`, `useRenameDevice`, `useUnlinkDevice` all funnel through `useApi()` (Clerk Bearer token attached) ([devices.ts:1-12](lib/devices.ts#L1)). The **error-mapping algorithm** turns a thrown `ApiError` or network failure into a stable `ErrorCode` ([devices.ts:49-72](lib/devices.ts#L49)): it prefers the backend's `body.code`, else maps HTTP status — `404→CODE_NOT_FOUND`, `409→ALREADY_PAIRED`, `410→CODE_EXPIRED`, `401→USER_AUTH_FAIL`, `403→NOT_OWNER`, `429→RATE_LIMIT`, `>=500→NETWORK`, else `UNKNOWN`; a `fetch` rejection (DNS/conn refused/CORS = `TypeError`, not `ApiError`) → `NETWORK`. `friendlyByCode` ([devices.ts:78-111](lib/devices.ts#L78)) maps each code to a user message + optional `action` (e.g. `CODE_EXPIRED` → "This pairing code expired. Restart your lamp to get a new one." / action "Restart your lamp"). `<ErrorPanel>` only shows a retry button for `NETWORK`/`UNKNOWN` ([components/app/ErrorPanel.tsx:16](components/app/ErrorPanel.tsx#L16)).

### 9.5 Pairing flow diagram

```mermaid
flowchart TD
    L["Lamp screen shows QR<br/>(encodes /pair/CODE)"] --> C["/connect (QrScanner)"]
    C -->|camera scan| EX[extractPairingCode]
    C -->|upload photo| EX
    C -->|type code| EX
    EX -->|null| ERRc["show inline error"]
    EX -->|CODE| PC["router.push(/pair/CODE)"]
    PC --> PI["usePairingInfo: GET /api/pairing-info/CODE"]
    PI -->|loading| LC[LoadingCard]
    PI -->|error| EP1["ErrorPanel(friendlyError)"]
    PI -->|expires_at <= now| EXP["ErrorPanel(CODE_EXPIRED)"]
    PI -->|ok| CARD["Confirmation card<br/>(name, device_id, code, countdown)"]
    CARD -->|click Link| CP["useCompletePairing:<br/>POST /api/device/complete-pairing"]
    CP -->|error| EP2["ErrorPanel(friendlyError)"]
    CP -->|success| SC["SuccessCard + confetti"]
    SC -->|1500ms| DEV["/devices"]
```

---

## 10. Shared Page Infrastructure

### 10.1 `<AppHeader>` — the app chrome

[components/app/AppHeader.tsx](components/app/AppHeader.tsx) renders on dashboard, analytics, admin, devices, connect. It is the **navigation hub** of the signed-in app:
- Logo links to `/dashboard` ([components/app/AppHeader.tsx:26](components/app/AppHeader.tsx#L26)).
- A primary nav array `NAV` = Dashboard, Analytics, Devices, **Simulator** ([components/app/AppHeader.tsx:8-13](components/app/AppHeader.tsx#L8)); the `active` prop underlines the current item.
- An **Admin** link appears only when `useMe()?.is_admin` is true ([components/app/AppHeader.tsx:19-21](components/app/AppHeader.tsx#L19), [components/app/AppHeader.tsx:48-61](components/app/AppHeader.tsx#L48)). Hiding it is purely cosmetic — `/admin` is also gated server-side.
- The Clerk `<UserButton afterSignOutUrl="/">` adds custom quick-nav menu items: Dashboard, Analytics, **My lamps** (`/devices`), **Connect a lamp** (`/connect`), **Personalize** (`/personalize`, added 2026-07-03), and Admin console (admins only), followed by the built-in Manage account / Sign out actions ([components/app/AppHeader.tsx:64-106](components/app/AppHeader.tsx#L64)).
- **`<ReportProblem />`** (Updated 2026-07-03) — the header now wraps its `<header>` and a globally-mounted `<ReportProblem>` in a fragment, so a fixed bottom-right "Report a problem" widget is available on **every** signed-in page without touching each one (§10.4).

`useMe()` ([profile.ts:66-74](lib/profile.ts#L66)) fetches `GET /api/frontend/me` (→ `is_admin`, `has_profile`, `onboarding_complete`), `staleTime` 60s.

### 10.4 `<ReportProblem>` — the global problem reporter (Updated 2026-07-03)

[components/app/ReportProblem.tsx](components/app/ReportProblem.tsx) is a one-tap "something's wrong" reporter mounted once inside `<AppHeader>`. It renders a fixed bottom-right pill that expands into an **inline panel** (deliberately not a browser `dialog`, which would block the page): a category chip-row (`wrong_answer, lamp_offline, audio, app, other`) + an optional free-text box. On send it auto-attaches a context snapshot (`page` pathname, ISO `at`, `ua`) and `POST`s to `/api/frontend/pilot/report` via `useReportProblem()`. It is **best-effort** — it shows the "Thanks — we got it" confirmation and closes even if the request fails, so it never blocks the user.

### 10.2 `<ConfirmDialog>` and `<ErrorPanel>`

`<ConfirmDialog>` ([components/app/ConfirmDialog.tsx](components/app/ConfirmDialog.tsx)) is an accessible modal (Escape to cancel unless `busy`, click-outside to cancel, `role="dialog" aria-modal`), with a `destructive` variant (rose confirm button) used for Unlink ([components/app/ConfirmDialog.tsx:30-95](components/app/ConfirmDialog.tsx#L30)). `<ErrorPanel>` (§9.4) is the shared pairing error surface.

### 10.3 The base API client (`lib/api.ts`)

`useApi()` ([lib/api.ts:76-184](lib/api.ts#L76)) is the foundation every client data hook builds on. `BACKEND_URL = NEXT_PUBLIC_BACKEND_URL ?? "http://localhost:8000"` ([api.ts:61-62](lib/api.ts#L61)). Every request fetches a fresh Clerk JWT via `getToken()` and sets `Authorization: Bearer <jwt>`. A **single-flight guard** (`fetchTokenShared`) dedups concurrent `getToken()` refreshes so several queries firing on one tick (dashboard's `/me` + `/profile` + `/analytics`) await one shared promise — mitigating the "token-refresh race" behind transient 401 flaps ([api.ts:21-55](lib/api.ts#L21)). Errors are shaped into `ApiError(status, body)` where `body` is `{ error, code }` ([api.ts:64-74](lib/api.ts#L64), [api.ts:130-145](lib/api.ts#L130)). `ready = isLoaded && !!isSignedIn` gates whether hooks even run ([api.ts:171](lib/api.ts#L171)).

---

## 11. Global Styling Layer (`app/globals.css`)

[app/globals.css](app/globals.css) defines the entire "luminous nocturne" visual language — a dark study-desk void lit by a single warm amber lamp, with cyan as the "machine intelligence" accent ([app/globals.css:5-9](app/globals.css#L5)). It is imported once in the root layout ([app/layout.tsx:3](app/layout.tsx#L3)) and underpins every page above.

### 11.1 Design tokens (`:root`)

CSS variables ([app/globals.css:11-30](app/globals.css#L11)):
- **Backgrounds:** `--void #07070d`, `--void-2 #0b0c16`, `--ink #11121d`.
- **Amber family:** `--amber #ffb84d`, `--amber-soft #ffd89b`, `--amber-deep #d9851f`.
- **Accents:** `--cyan #5fe3d2`, `--violet #b9a3ff`, `--rose #ff9bb0`.
- **Text:** `--paper #f4efe6`, `--muted #9a9ab0`, `--faint #5c5c72`.
- **Edges:** `--edge rgba(255,255,255,0.08)`, `--edge-strong rgba(255,255,255,0.14)`.

### 11.2 Base layer

`@layer base` ([app/globals.css:32-70](app/globals.css#L32)) sets smooth scroll, `color-scheme: dark`, the body's layered radial+linear gradient backdrop, a fixed SVG **film-grain** overlay at `opacity 0.045` z-index 100 (`pointer-events: none`), amber `::selection`, and forces `h1,h2,h3` to the display serif (`var(--font-display)`).

### 11.3 Component utilities (`@layer components`)

The reusable classes the pages compose ([app/globals.css:72-241](app/globals.css#L72)):
- `.label` — mono, uppercase, `letter-spacing 0.28em`, `0.6875rem` (the eyebrow voice used across pages).
- `.glass` — frosted card: `backdrop-filter: blur(20px) saturate(150%)`, inset specular highlight + depth shadow ([app/globals.css:83-91](app/globals.css#L83)).
- `.glass-liquid` — premium thicker surface (`blur(28px) saturate(170%)`, brighter top edge, inner bloom) — the dashboard Connect CTA ([app/globals.css:95-105](app/globals.css#L95)).
- `.glass-lift` / `.glass-lift-cyan` — hover lift (`translateY(-4px)`, warm/cyan halo) with a `cubic-bezier(0.2,0.8,0.2,1)` 0.4s transition.
- `.tile`, `.tile-amber`, `.tile-cyan` — glowing icon tiles.
- `.glow-text` / `.glow-text-cyan` — gradient clipped headline text.
- `.beam` — the lamp's conic light cone. `.hairline` — a subtle divider.
- `.btn-primary` (amber gradient), `.btn-ghost`, `.btn-cyan`, `.input` — the button + input system (the `.input` class was moved here because Turbopack mis-compiled the old scoped `<style jsx>` in `OnboardingForm` ([app/globals.css:196-216](app/globals.css#L196))).

### 11.4 Utilities & motion (`@layer utilities`)

[app/globals.css:243-294](app/globals.css#L243):
- `.dotgrid` — masked dot pattern (onboarding backdrop).
- `.aurora` — two slow-drifting blurred blobs (amber `drift-a` 20s, cyan `drift-b` 26s) placed as the first child of a `relative` container, with content in a `relative z-10` sibling (the exact pattern used on dashboard/analytics/admin).
- `.rise` — fade+lift entrance (`rise` 0.7s), paired with inline `animationDelay` for staggering.

Keyframes `drift-a`, `drift-b`, `rise` ([app/globals.css:296-307](app/globals.css#L296)) and a `prefers-reduced-motion: reduce` block that kills all drifts/entrances and forces `scroll-behavior: auto` ([app/globals.css:309-315](app/globals.css#L309)).

### 11.5 Clerk overrides

A final block hard-forces legible light text + amber icons on the Clerk `UserButton` custom menu items via stable `.cl-` classes (belt-and-suspenders to the `appearance` config in `layout.tsx`) ([app/globals.css:317-333](app/globals.css#L317)).

---

## 12. Navigation Graph

How pages connect (entry → exit):

| From | To | Trigger |
|---|---|---|
| `/` | `/sign-in`, `/sign-up` | Nav/CTA components |
| `/sign-in` | `/dashboard` | existing user (`fallbackRedirectUrl`) |
| `/sign-in` | `/onboarding` | new OAuth user (`signUpForceRedirectUrl`) |
| `/sign-up` | `/onboarding` | any new account (`forceRedirectUrl`) |
| `/onboarding` | `/dashboard` | profile exists, or successful save (server `redirect`) |
| `/onboarding` | `/sign-in` | no `userId` |
| any authed page | `/sign-in` | `requireOnboarded` (signed-out) |
| any authed page | `/onboarding` | `requireOnboarded` (`status === "missing"`) |
| `/admin` | `/dashboard` | `requireOnboardedAndAdmin` (verdict `not_admin`, i.e. `is_admin === false`) |
| `<AppHeader>` | `/dashboard`, `/analytics`, `/devices`, `/simulator`, `/admin` | nav links |
| `<UserButton>` menu | `/dashboard`, `/analytics`, `/devices`, `/connect`, `/admin`, `/` (sign out) | menu items |
| `/dashboard` | `/connect` | "Connect your lamp" CTA |
| `/devices` | `/connect` | "Scan a QR code" / Add-lamp guide |
| `/connect` | `/pair/[code]` | `QrScanner.onCode` → `router.push` |
| `/pair` | `/devices` | server `redirect` |
| `/pair/[code]` | `/devices` | success (1500ms after link) |
| `/pair/[code]` | `/` | "Not your lamp? Cancel" |

```mermaid
flowchart LR
    Landing["/"] --> SignIn["/sign-in"]
    Landing --> SignUp["/sign-up"]
    SignIn -->|existing| Dash["/dashboard"]
    SignIn -->|new OAuth| Onb["/onboarding"]
    SignUp -->|new| Onb
    Onb -->|saved / exists| Dash
    Onb -->|no userId| SignIn
    Dash --> Connect["/connect"]
    Dash --> Analytics["/analytics"]
    Dash --> Devices["/devices"]
    Dash --> Sim["/simulator"]
    Devices --> Connect
    Connect --> Pair["/pair/[code]"]
    Pair -->|success| Devices
    Pair -->|cancel| Landing
    PairIdx["/pair"] -->|redirect| Devices
    Dash -. admin only .-> Admin["/admin"]
    Admin -->|not admin| Dash
```

---

## 13. Data-Flow Summary (inputs → transforms → outputs)

| Stage | Input | Transform | Output |
|---|---|---|---|
| Onboarding submit | `FormData` (name + 6 radios) | trim + `is*` validators → `ProfileBody` (snake_case) | `PUT /api/frontend/profile` (8s timeout) → Supabase upsert |
| Onboarding gate | Clerk `userId` + token | `GET /api/frontend/profile` (9s) → `exists/missing/unreachable` | redirect or render |
| Dashboard tiles | `BackendProfile` (server) | pluck `target_exam / prep_duration / focus_subject`, `full_name.split(" ")[0]` | rendered glass tiles |
| Dashboard analytics | Clerk token (client) | `useAnalytics` → `GET /api/frontend/analytics` (60s poll) | `<AnalyticsCards>` |
| Analytics page | `days` (default 14) | `useAnalyticsDetail` → `GET /api/frontend/analytics/detail?days=N` (60s poll) | charts in `<AnalyticsView>` |
| Devices list | Clerk token (client) | `useDevices` → `GET /api/devices` (60s poll) | rows; `online` + `formatAgo` subtitle |
| Rename | local input | `canSave` rule (1–60 chars, changed) → `POST /api/device/<id>/rename` | invalidate `["devices"]` |
| Unlink | `device_id` | optimistic cache filter → `POST /api/device/<id>/unlink` | remove row (rollback on error) |
| QR scan | raw QR string / camera frame / typed text | `jsQR` decode → `extractPairingCode` (URL/path/query/bare, 6–8 alnum, uppercase) | `code` → `router.push(/pair/<code>)` |
| Pairing info | `code` | `usePairingInfo` → `GET /api/pairing-info/<code>` | name/device_id/expires_at card + countdown |
| Complete pairing | `code` | `useCompletePairing` → `POST /api/device/complete-pairing` `{pairing_code}` | success card → `/devices` |

---

## 14. Edge Cases, Errors, Timeouts, Fallbacks

- **Cold backend on gate:** 9s `AbortSignal.timeout` on the profile probe → `"unreachable"` → user is let through with a `null` profile (dashboard tiles show "—"); admin degrades to render (data endpoints still enforce) ([lib/auth-guard.ts:31](lib/auth-guard.ts#L31), [lib/auth-guard.ts:111-118](lib/auth-guard.ts#L111)).
- **Cold backend on onboarding save:** 8s timeout → `saved=false` → explicit "Couldn't reach the server… try again in a moment." Re-submit is idempotent ([app/onboarding/actions.ts:34-36](app/onboarding/actions.ts#L34), [app/onboarding/actions.ts:135-140](app/onboarding/actions.ts#L135)).
- **OAuth one-render lag:** onboarding gates on `userId` not `currentUser()`; both reads run concurrently; email/name resolution failures are non-fatal ([app/onboarding/page.tsx:21-30](app/onboarding/page.tsx#L21), [app/onboarding/actions.ts:115-124](app/onboarding/actions.ts#L115)).
- **Redirect-loop prevention:** `/onboarding` only skips on `"exists"`; `requireOnboarded` only redirects to `/onboarding` on `"missing"` — never on `"unreachable"` ([app/onboarding/page.tsx:36](app/onboarding/page.tsx#L36), [lib/auth-guard.ts:116](lib/auth-guard.ts#L116)).
- **Navigation race fix:** onboarding redirects **server-side** in the action (no client `push()+refresh()` race) ([app/onboarding/actions.ts:155-163](app/onboarding/actions.ts#L155)).
- **Expired pairing code:** live `now` tick → `expired` when `expires_at <= now` → `CODE_EXPIRED` panel (no retry) ([app/pair/[code]/page.tsx:49-50](app/pair/[code]/page.tsx#L49), [app/pair/[code]/page.tsx:72-73](app/pair/[code]/page.tsx#L72)).
- **Camera blocked / no webcam:** `denied`/`error` states with fallbacks to upload-photo or type-the-code ([components/app/QrScanner.tsx:82-88](components/app/QrScanner.tsx#L82), [components/app/QrScanner.tsx:149-157](components/app/QrScanner.tsx#L149)).
- **Bad QR:** `extractPairingCode` returns `null` → inline error; double-fire guarded by `firedRef` ([components/app/QrScanner.tsx:30-40](components/app/QrScanner.tsx#L30)).
- **Unlink failure:** optimistic remove rolls back from captured `prev` on error ([devices.ts:174-176](lib/devices.ts#L174)).
- **Rename no-op/over-length:** `canSave` blocks save when unchanged, empty, or >60 chars; `maxLength={60}` caps input ([app/devices/page.tsx:90-91](app/devices/page.tsx#L90)).
- **Token-refresh race:** `fetchTokenShared` single-flights `getToken()` to avoid parallel refreshes causing transient 401s ([api.ts:29-55](lib/api.ts#L29)).
- **Pairing info `retry: false`:** a wrong/expired code fails fast rather than retrying ([devices.ts:121](lib/devices.ts#L121)).
- **Reduced motion:** all aurora/rise animations disabled under `prefers-reduced-motion` ([app/globals.css:310-315](app/globals.css#L310)).

---

## 15. Integration Points (cross-references)

**These pages call (backend, `/api/...`):**
- `GET /api/frontend/profile` — onboarding gate + dashboard data ([lib/auth-guard.ts:73](lib/auth-guard.ts#L73), [profile.ts:81](lib/profile.ts#L81)).
- `PUT /api/frontend/profile` — onboarding save ([app/onboarding/actions.ts:48](app/onboarding/actions.ts#L48)).
- `GET /api/frontend/me` — admin gate + header `is_admin` ([lib/auth-guard.ts:144](lib/auth-guard.ts#L144), [profile.ts:70](lib/profile.ts#L70)).
- `GET /api/frontend/analytics` and `/analytics/detail?days=N` — dashboard cards + analytics page ([profile.ts:103](lib/profile.ts#L103), [profile.ts:155](lib/profile.ts#L155)).
- `/api/frontend/admin/*` — admin panels (re-checked server-side).
- `GET /api/pairing-info/<code>`, `POST /api/device/complete-pairing`, `GET /api/devices`, `POST /api/device/<id>/rename`, `POST /api/device/<id>/unlink` — pairing + device management ([lib/devices.ts:118](lib/devices.ts#L118), [lib/devices.ts:128](lib/devices.ts#L128), [lib/devices.ts:140](lib/devices.ts#L140), [lib/devices.ts:153](lib/devices.ts#L153), [lib/devices.ts:164](lib/devices.ts#L164)).

**What calls these pages:**
- **Clerk** redirects sign-in/sign-up → `/dashboard` or `/onboarding` ([app/layout.tsx:37-38](app/layout.tsx#L37)).
- **The lamp firmware** renders a QR encoding `/pair/<code>`, the entry to the pairing journey ([lib/pairing-code.ts:1-4](lib/pairing-code.ts#L1)).
- **The backend** is the source of truth feeding every gate and every analytic.

**Cross-layer notes:**
- The frontend **never** handles device secrets/JWTs — only human Clerk sessions ([middleware.ts:5-6](middleware.ts#L5)).
- `Device.online` is computed server-side as "last_seen_at within 60 s" ([lib/devices.ts:26](lib/devices.ts#L26)); the firmware's heartbeat drives it, which is why polling is 60s ([lib/devices.ts:142-144](lib/devices.ts#L142)).
- Onboarding's psychology fields feed LLM personalisation: stored in `user_profiles.extra` (JSONB) and mirrored to Clerk `publicMetadata` ([lib/onboarding.ts:7-9](lib/onboarding.ts#L7), [lib/onboarding.ts:102-103](lib/onboarding.ts#L102)).

---

## 16. Diagrams

### 16.1 Overall request gating (page render)

```mermaid
flowchart TD
    REQ[Incoming request] --> MW{middleware:<br/>isProtected route?}
    MW -->|no| RENDER_PUBLIC[Render public page]
    MW -->|yes| AUTH{Clerk session?}
    AUTH -->|no| CLERK[Redirect to Clerk sign-in]
    AUTH -->|yes| PAGE{Page type}
    PAGE -->|/dashboard /analytics /admin| RO[requireOnboarded]
    PAGE -->|/devices /connect /pair| CLIENT[Client page<br/>useApi.ready gates calls]
    RO --> PROBE["getBackendProfile<br/>(9s timeout, no retry)"]
    PROBE -->|missing| ONB[redirect /onboarding]
    PROBE -->|unreachable| DEGRADE[render with null profile]
    PROBE -->|exists| ADMINQ{admin page?}
    ADMINQ -->|no| RENDER[Render page]
    ADMINQ -->|yes| RA[requireOnboardedAndAdmin: profile + admin verdict concurrently]
    RA -->|is_admin false| BOUNCE[redirect /dashboard]
    RA -->|is_admin true / degrade| RENDER
```

### 16.2 Sign-in / sign-up / onboarding sequence

```mermaid
sequenceDiagram
    participant U as User
    participant SI as /sign-in or /sign-up
    participant CL as Clerk
    participant ON as /onboarding
    participant DA as /dashboard
    U->>SI: open auth page (force-dynamic)
    U->>CL: credentials / Google OAuth
    alt new account
        CL-->>ON: signUpForceRedirectUrl
        ON->>ON: requireOnboarded-style probe
        ON-->>U: render form (missing/unreachable)
        U->>ON: submit → completeOnboarding → PUT profile
        ON-->>DA: redirect (server-side)
    else returning user
        CL-->>DA: signInFallbackRedirectUrl
        DA->>DA: requireOnboarded → exists
        DA-->>U: render dashboard
    end
```

---

*End of reference. All behavior above is taken verbatim from the source files in `Smart-Tutor-frontend/` as read on 2026-06-16.*
