# Frontend — Lib & Data/API Layer

This is the definitive reference for the Smart Tutor Lamp Next.js frontend's `lib/` directory: the **data/API layer** that every page and component builds on. It centralizes (a) one authenticated HTTP client that attaches the Clerk session JWT to every request and shapes errors, (b) typed TanStack Query hooks for identity/profile/analytics/devices/admin/models data, (c) the server-side onboarding + admin route gates, (d) the multipart "solve" path for the Multi-LLM evaluation feature, and (e) pure helpers for logging, timing, pairing-code extraction, error-message mapping, and display formatting. Every network call here targets the unified **Lumos FastAPI backend** ("Frontend Manager" + device-pairing surface). The simulator-capture file (`useSimulatorCapture.ts`) is intentionally excluded — it is documented in the web-simulator reference.

---

## Table of Contents

1. [Purpose & Responsibility](#1-purpose--responsibility)
2. [Architecture Overview](#2-architecture-overview)
3. [Configuration, Environment Variables & Constants](#3-configuration-environment-variables--constants)
4. [The API Client — `api.ts`](#4-the-api-client--apits)
5. [The Auth/Onboarding/Admin Gate — `auth-guard.ts`](#5-the-authonboardingadmin-gate--auth-guardts)
6. [Identity / Profile / Analytics — `profile.ts`](#6-identity--profile--analytics--profilets)
7. [Device Pairing & Management — `devices.ts`](#7-device-pairing--management--devicests)
8. [Admin Data Layer — `admin.ts`](#8-admin-data-layer--admints)
9. [Multi-LLM Models & Solve — `models.ts`](#9-multi-llm-models--solve--modelsts)
10. [Onboarding Contract — `onboarding.ts`](#10-onboarding-contract--onboardingts)
11. [Pairing-Code Extraction — `pairing-code.ts`](#11-pairing-code-extraction--pairing-codets)
12. [Diagnostics & Timing — `log.ts`](#12-diagnostics--timing--logts)
13. [Time Formatters — `time.ts`](#13-time-formatters--timets)
14. [Complete Endpoint Map (Frontend → Backend)](#14-complete-endpoint-map-frontend--backend)
15. [Control-Flow Diagrams](#15-control-flow-diagrams)
16. [Edge Cases, Errors, Timeouts, Fallbacks](#16-edge-cases-errors-timeouts-fallbacks)
17. [Integration Points & Cross-References](#17-integration-points--cross-references)

---

## 1. Purpose & Responsibility

The `lib/` data layer is the **single funnel** through which all browser↔backend communication and all shared client logic flow. Its responsibilities:

- **One authenticated transport.** `useApi()` is the only place that fetches the Clerk JWT, sets the `Authorization` header, JSON-encodes bodies, parses responses, and converts non-2xx into a typed `ApiError`. Every higher-level hook calls through it ([api.ts:79-168](lib/api.ts#L79)).
- **Typed endpoint wrappers as React Query hooks.** `profile.ts`, `devices.ts`, `admin.ts`, `models.ts` expose `useQuery`/`useMutation` hooks that own query keys, polling intervals, stale times, retry policy, and cache invalidation.
- **Server-side route gating.** `auth-guard.ts` runs inside React Server Components to decide "must finish onboarding" and "is admin" before a protected page renders, reading the **durable Supabase profile row** as the single source of truth.
- **The shared onboarding contract.** `onboarding.ts` defines the option lists + validators used identically by the client form, the server action, the auth guard, and (shape-wise) the backend `ProfileIn`.
- **Pure helpers.** `pairing-code.ts` (QR/URL → code), `log.ts` (verbose console diagnostics + stopwatch + race detection), `time.ts` (countdown / "ago" labels), plus display formatters in `models.ts` and error mapping in `devices.ts`.

The frontend **only ever handles human sessions** — never device secrets or device JWTs ([middleware.ts:5-6](middleware.ts#L5)). Device authentication lives in firmware/backend; this layer authenticates the human and reads their data.

---

## 2. Architecture Overview

### Module map

| File | Kind | Role |
| --- | --- | --- |
| `api.ts` | `"use client"` | Core authenticated fetch (`useApi`), `BACKEND_URL`, `ApiError`, single-flight token fetch |
| `auth-guard.ts` | server-only | `requireOnboarded()`, `requireOnboardedAndAdmin()`, `getBackendProfile()`, `getAdminVerdict()` — RSC route gates (Updated 2026-07-03) |
| `profile.ts` | `"use client"` | Identity (`useMe`), profile read/write, dashboard + detailed analytics |
| `devices.ts` | `"use client"` | Pairing info/complete, list/rename/unlink devices, error-code mapping |
| `admin.ts` | `"use client"` | Admin overview/users/devices/sessions/turns/trace/media/events/model-eval + performance, OTA, pilot dashboard, learning insights, **range-aware Analytics tab** (Updated 2026-07-11) |
| `pilot.ts` | `"use client"` | Pilot instrumentation: turn feedback, surveys, problem reports, personalization, consent (added 2026-07-03) |
| `models.ts` | `"use client"` | Model catalog, multipart `solve`/`solve/compare`, feedback, display formatters |
| `onboarding.ts` | shared (no `"use client"`) | Option lists, types, `_oneOf` validators, question definitions |
| `pairing-code.ts` | pure | `extractPairingCode()` from QR/URL/bare string |
| `log.ts` | `"use client"` | `log`, `BUDGET`, `stopwatch`, `nextSeq`, `raceEnter`/`raceExit`, `VERBOSE` |
| `time.ts` | pure | `formatCountdown()`, `formatAgo()` |

### Dependency graph

- `api.ts` → imports from `log.ts` (`BUDGET`, `log`, `nextSeq`, `raceEnter`, `raceExit`, `stopwatch`) ([api.ts:14](lib/api.ts#L14)).
- `admin.ts` → `api.ts` + `models.ts` (`TimelineStep`) + `@tanstack/react-query` ([admin.ts:9-11](lib/admin.ts#L9)).
- `devices.ts` → `api.ts` (`ApiError`, `useApi`) + react-query ([devices.ts:7-12](lib/devices.ts#L7)).
- `profile.ts` → `api.ts` + `onboarding.ts` (`TargetExam`, `PrepDuration`) + react-query ([profile.ts:8-10](lib/profile.ts#L8)).
- `models.ts` → `api.ts` (`useApi`, `BACKEND_URL`) + `log.ts` + react-query ([models.ts:11-13](lib/models.ts#L11)).
- `auth-guard.ts` → `@clerk/nextjs/server` (`auth`) + `next/navigation` (`redirect`); it does **not** use `useApi` because it runs server-side ([auth-guard.ts:14-15](lib/auth-guard.ts#L14)).

### Two transport paths

There are **two distinct ways the lib layer talks to the backend**, by design:

1. **Client JSON path** — `useApi().get/post/put/del` for all standard JSON endpoints. Token fetched via Clerk `getToken()` in the browser ([api.ts:170-184](lib/api.ts#L170)).
2. **Client multipart path** — `postFormTimed()` in `models.ts` uses a raw `fetch` with `FormData` (audio + images + text) because `useApi` only JSON-encodes; it still attaches the Clerk token and measures the browser journey ([models.ts:161-232](lib/models.ts#L161)).
3. **Server path (separate, in `auth-guard.ts` and the onboarding action)** — uses `auth().getToken()` from `@clerk/nextjs/server` and a bare `fetch` with an `AbortSignal.timeout` ceiling, because RSCs cannot use React hooks ([auth-guard.ts:67-77](lib/auth-guard.ts#L67), [actions.ts:48-54](app/onboarding/actions.ts#L48)).

---

## 3. Configuration, Environment Variables & Constants

### Environment variables

| Variable | Read in | Default | Effect |
| --- | --- | --- | --- |
| `NEXT_PUBLIC_BACKEND_URL` | `api.ts`, `auth-guard.ts`, `actions.ts`, `models.ts` (via `BACKEND_URL`) | `http://localhost:8000` | Base URL of the unified Lumos FastAPI backend. `http://localhost:8000` matches `uvicorn app.main:app` ([api.ts:61-62](lib/api.ts#L61)). |
| `BACKEND_URL` (server) | `auth-guard.ts`, `actions.ts` | — | Server-only fallback after `NEXT_PUBLIC_BACKEND_URL` ([auth-guard.ts:17-18](lib/auth-guard.ts#L17)). |
| `NEXT_PUBLIC_VERBOSE` | `log.ts` | unset | `"1"` forces verbose logging on at build; `"0"` forces off ([log.ts:46-48](lib/log.ts#L47)). |
| `NODE_ENV` | `log.ts` | — | When not `"production"`, verbose logging defaults ON ([log.ts:62-63](lib/log.ts#L63)). |
| `localStorage.LUMOS_VERBOSE` / `window.__LUMOS_VERBOSE` | `log.ts` | — | Runtime toggle (no rebuild): `"1"`/`true` on, `"0"`/`false` off ([log.ts:50-61](lib/log.ts#L50)). |

`BACKEND_URL` (the exported constant) is computed once at module load: `process.env.NEXT_PUBLIC_BACKEND_URL ?? "http://localhost:8000"` ([api.ts:61-62](lib/api.ts#L61)).

### Latency budgets (ms) — `log.ts`

Crossing a budget escalates a `PERF` debug line into a `LAG` warning (or error if a "severe" ceiling is passed) ([log.ts:35-43](lib/log.ts#L35)):

| Key | Value | Meaning |
| --- | --- | --- |
| `token` | `500` | Clerk `getToken()` — >0.5 s implies a refresh / cold JWKS |
| `network` | `1000` | a single backend round trip |
| `networkSevere` | `3000` | round trip so slow it's almost certainly a problem |
| `parse` | `50` | JSON decode of the response body |
| `query` | `1500` | whole React Query queryFn (token + network + parse) |
| `longTask` | `120` | main-thread task that blocks paint/interaction |
| `route` | `800` | client-side navigation between two pages |

### Timeouts

| Constant | Value | File | Effect |
| --- | --- | --- | --- |
| `PROFILE_PROBE_TIMEOUT_MS` | `9000` | `auth-guard.ts` | Hard ceiling for the server-side `/profile` and `/me` probes. Sized to the backend's real p95 (cold Clerk-verified request: JWKS fetch + RSA verify + fresh asyncpg connection runs 6–13 s) ([auth-guard.ts:31](lib/auth-guard.ts#L31)). |
| `SAVE_TIMEOUT_MS` | `8000` | `app/onboarding/actions.ts` | Hard ceiling for the onboarding `PUT /profile` write ([actions.ts:36](app/onboarding/actions.ts#L36)). |
| `8000` / `20000` | inline | `models.ts` | Soft/severe LAG budgets for the solve upload+inference round trip (inference can legitimately take many seconds) ([models.ts:208](lib/models.ts#L208)). |

### Polling / staleness constants

| Constant | Value | Where | Effect |
| --- | --- | --- | --- |
| `refetchInterval` | `60_000` | overview, devices, model-eval, `useDevices`, `useAnalytics`, `useAnalyticsDetail` | Matches the backend's **45 s Redis cache** on admin queries; a 30 s poll wasted half the round trips. Pauses when tab unfocused (TanStack `refetchIntervalInBackground: false`) ([admin.ts:296](lib/admin.ts#L296), [admin.ts:317](lib/admin.ts#L317), [devices.ts:143](lib/devices.ts#L143), [profile.ts:107](lib/profile.ts#L107)). |
| `IDENTITY_STALE_MS` | `60_000` | `useMe`, `useProfile` | Identity/profile change only on onboarding/settings save (which invalidate), so kept fresh 1 min to avoid flicker ([profile.ts:64](lib/profile.ts#L64)). |
| `staleTime` | `5 * 60_000` | `useModels`, `useTurnTrace` | Catalog only changes on backend restart; a finished turn's trace never changes ([models.ts:122](lib/models.ts#L122), [admin.ts:357](lib/admin.ts#L357)). |
| `staleTime` | `30_000` | `useAdminMedia` | Media snapshot ([admin.ts:369](lib/admin.ts#L369)). |

---

## 4. The API Client — `api.ts`

The foundation. A `"use client"` module exporting `BACKEND_URL`, `ApiError`, `ApiErrorBody`, and the `useApi()` hook.

### Data structures

```ts
interface ApiErrorBody { error: string; code: string; }       // api.ts:64-67
class ApiError extends Error {                                  // api.ts:69-74
  constructor(public status: number, public body: ApiErrorBody)
  // message = `${status} ${body.code}: ${body.error}`, name = "ApiError"
}
```

### Single-flight token fetching (the 401-flap fix)

Two module-level variables track Clerk token-fetch concurrency:

- `tokenInFlight: number` — count of **actual** Clerk fetches in flight ([api.ts:21](lib/api.ts#L21)).
- `sharedTokenPromise: Promise<string|null> | null` — the dedup handle ([api.ts:29](lib/api.ts#L29)).

`fetchTokenShared(getToken)` ([api.ts:30-55](lib/api.ts#L30)) is the algorithm:

1. If `sharedTokenPromise` is null, create it by invoking an async IIFE.
2. Inside: increment `tokenInFlight`; if it exceeds 1, emit a `RACE` warning ("single-flight dedup broken?") — with dedup working this should never fire ([api.ts:38-45](lib/api.ts#L38)).
3. `return await getToken()` (may transparently refresh a short-lived Clerk JWT — a network hit).
4. `finally`: decrement `tokenInFlight`, reset `sharedTokenPromise = null` so the next tick fetches fresh.
5. Return the shared promise so **all concurrent callers await the same single fetch** instead of each kicking off a parallel refresh. No token caching beyond Clerk's own — expiry semantics unchanged. The dashboard mounting `/me + /profile + /analytics` simultaneously is the motivating case ([api.ts:16-28](lib/api.ts#L16)).

### `useApi()` and the `call<T>` pipeline

`useApi()` reads `getToken, isLoaded, isSignedIn` from Clerk `useAuth()` ([api.ts:77](lib/api.ts#L77)). The generic `call<T>(path, init)` ([api.ts:81-168](lib/api.ts#L81)) is memoized on `[getToken]` and runs three phases:

**Setup:** derive `method` (default `GET`, uppercased), allocate a sequence id via `nextSeq()`, build `key = "METHOD path"`, start a `stopwatch()`. `raceEnter(key, id)` records the in-flight request (logs a `RACE` if an identical one is already running) ([api.ts:83-90](lib/api.ts#L83)).

**Phase 1 — token** ([api.ts:93-107](lib/api.ts#L93)):
- `token = await fetchTokenShared(getToken)`; measure against `BUDGET.token` (500 ms).
- If no token → `AUTH` warning "request will be unauthenticated" (the call proceeds anyway).
- Build `Headers`; set `Authorization: Bearer <token>` if present; set `Content-Type: application/json` if there's a body and none set.

**Phase 2 — network** ([api.ts:109-128](lib/api.ts#L109)):
- `fetch(\`${BACKEND_URL}${path}\`, { ...init, headers })`.
- If `fetch` **rejects** (backend down / CORS / DNS — no HTTP status) → log an `API` error "NETWORK ERROR after Nms" and re-throw the original error ([api.ts:113-123](lib/api.ts#L113)). Callers (e.g. `devices.ts`) treat a non-`ApiError` throw as `"NETWORK"`.
- Measure round-trip against `BUDGET.network` (1000) / `BUDGET.networkSevere` (3000).

**Phase 3 — parse + outcome** ([api.ts:129-162](lib/api.ts#L129)):
- **Non-2xx:** parse the JSON error body; on parse failure fall back to `{ error: res.statusText, code: "UNKNOWN" }`. Log an `API` error with status + timing breakdown + body, then `throw new ApiError(res.status, body.detail ?? body)` — note it prefers a nested `detail` envelope when the backend wraps it (FastAPI `HTTPException(detail={...})`), otherwise the raw `{error, code}` ([api.ts:130-145](lib/api.ts#L130)).
- **204 No Content:** log and `return undefined as T` (used by `del`/`unlink`) ([api.ts:147-151](lib/api.ts#L147)).
- **Success:** `await res.json()` typed as `T`, measure parse against `BUDGET.parse` (50), log `info`, return ([api.ts:153-162](lib/api.ts#L153)).

**Always:** `finally { raceExit(key) }` decrements the in-flight registry ([api.ts:163-165](lib/api.ts#L163)).

### The public surface

`useApi()` returns a memoized object ([api.ts:170-184](lib/api.ts#L170)):

| Member | Signature | Behavior |
| --- | --- | --- |
| `ready` | `boolean` | `isLoaded && !!isSignedIn` — every query gates its `enabled` on this |
| `getToken` | `() => Promise<string\|null>` | re-exported for the multipart path in `models.ts` |
| `get<T>(path)` | `Promise<T>` | `call<T>(path)` |
| `post<T>(path, body?)` | `Promise<T>` | `method: "POST"`, body `JSON.stringify(body)` if provided |
| `put<T>(path, body?)` | `Promise<T>` | `method: "PUT"`, JSON body |
| `del<T>(path)` | `Promise<T>` | `method: "DELETE"` |

These are the "low-level escape hatches"; typed endpoint wrappers (the hooks in the other files) build on them.

---

## 5. The Auth/Onboarding/Admin Gate — `auth-guard.ts`

A **server-only** module (no `"use client"`). Runs inside React Server Components at the top of protected pages. Single source of truth is the **backend Supabase profile row**, deliberately NOT Clerk `publicMetadata` — the old dual-read design drifted and bounced fully-onboarded users back to `/onboarding` ([auth-guard.ts:1-12](lib/auth-guard.ts#L1)).

### `BackendProfile` type ([auth-guard.ts:37-50](lib/auth-guard.ts#L37))

Mirrors backend `ProfileOut` (`app/schemas/frontend.py`), snake_case to match the wire 1:1: `user_id, full_name, email, phone, target_exam, prep_duration, learning_style, explain_depth, study_rhythm, focus_subject, onboarding_complete, updated_at`.

`type ProfileStatus = "exists" | "missing" | "unreachable"` ([auth-guard.ts:33](lib/auth-guard.ts#L33)).

### `getBackendProfile()` ([auth-guard.ts:56-99](lib/auth-guard.ts#L56))

One fetch yields both the gate status and the renderable profile. **Single fast probe, no retry** (runs in the page server render; each retry is dead time on a blank screen). Mechanics:

1. `auth().getToken()`. No token → log error → `{ status: "unreachable", profile: null }`.
2. `fetch(\`${BACKEND_URL}/api/frontend/profile\`)` with `Authorization`, `cache: "no-store"`, `signal: AbortSignal.timeout(9000)`.
3. `!res.ok` → read body text, log status/latency → `"unreachable"`.
4. `res.json()` → if body present → `{ status: "exists", profile }`; if null → `{ status: "missing", profile: null }` (the backend returns **200 + null** when the row doesn't exist).
5. Logs the probe latency; flags `(SLOW — blocks render)` when `ms > 3000`.
6. `catch` (AbortError timeout / network / backend down) → `"unreachable"`.

### `requireOnboarded()` ([auth-guard.ts:111-118](lib/auth-guard.ts#L111))

Top of every authed page:
1. `auth().userId`; if absent → `redirect("/sign-in")`.
2. `getBackendProfile()`.
3. `status === "missing"` → `redirect("/onboarding")`.
4. Returns the profile on `"exists"`; on `"unreachable"` returns `null` (degrade, **do not** re-ask — re-asking a real onboarded user on a transient blip is the exact bug being fixed; genuinely-new users arrive via `signUpForceRedirectUrl=/onboarding`) ([auth-guard.ts:104-117](lib/auth-guard.ts#L104)).

### `getAdminVerdict()` + `requireOnboardedAndAdmin()` (Updated 2026-07-03)

The `/admin` gate was refactored (commit `ef07d7f`). It was two **sequential** awaits — `requireOnboarded()` then `requireAdmin()`, each a 9s-timeout probe → up to ~18s of blank on a cold backend. It is now one concurrent guard.

**`getAdminVerdict(): Promise<"admin" | "not_admin" | "unknown">`** — a private, **redirect-free** replacement for the old `requireAdmin()`. Asks `GET /api/frontend/me` → `is_admin` (from the `admins` table). **Asymmetric verdict**:

| Outcome | Verdict |
| --- | --- |
| No Clerk token | `"not_admin"` |
| `res.ok` and `me.is_admin === false` | `"not_admin"` |
| `res.ok` and `is_admin === true` | `"admin"` |
| `res.ok` but `is_admin` neither / `!res.ok` (5xx) | `"unknown"` |
| timeout / network error | `"unknown"` |

**`requireOnboardedAndAdmin(): Promise<void>`** — checks `userId` (`null` → `redirect("/sign-in")`), then runs `Promise.all([getBackendProfile(), getAdminVerdict()])`. **After** the await it applies redirects in deterministic order: `status === "missing"` → `/onboarding`, then `verdict === "not_admin"` → `/dashboard`. Both `redirect()` calls sit **outside** any try so their `NEXT_REDIRECT` throw is never swallowed. Callers: `app/admin/page.tsx`.

The degrade on `"unknown"` is safe because `/admin` renders **no data of its own**; every panel fetches `/api/frontend/admin/*`, which re-check `require_admin` server-side (403 `NOT_ADMIN`). A non-admin who slips past a timed-out probe sees only an "Admin access required" notice, never data. `PROFILE_PROBE_TIMEOUT_MS` (9s) was intentionally left unchanged — now hidden behind the route's `loading.tsx` skeleton (see the repo-root `OPTIMIZATION.md §2.1`).

---

## 6. Identity / Profile / Analytics — `profile.ts`

The Frontend Manager client data layer — identity, onboarding profile, dashboard + detailed analytics. Mirrors `app/schemas/frontend.py`.

### Wire types

- `Me`: `user_id, email, has_profile, onboarding_complete, is_admin` ([profile.ts:13-19](lib/profile.ts#L13)).
- `Profile`: full profile incl. all psychology fields + `onboarding_complete, updated_at` ([profile.ts:21-34](lib/profile.ts#L21)).
- `ProfileInput` (the PUT body): `full_name, phone, target_exam, prep_duration` ([profile.ts:36-41](lib/profile.ts#L36)).
- `Analytics` (dashboard summary): `device_count, online_devices, total_turns, turns_last_7d, sessions_count, last_active_at, subject_mix, devices[]` ([profile.ts:49-58](lib/profile.ts#L49)).
- `AnalyticsDetail` (dedicated page): adds `range_days, avg_total_ms, p50_ms, p95_ms, avg_confidence, total_cost_usd, escalated_pct`, mixes for difficulty/query-type/status, `daily[]` (`DailyPoint`), and `recent[]` (`RecentTurn`) ([profile.ts:112-149](lib/profile.ts#L112)).
- **Updated 2026-07-03:** `RecentTurn` gained two pilot-F1 fields — `turn_id: string | null` (so the analytics feed's `<TurnFeedbackControl>` can target the turn) and `feedback: TurnFeedbackState | null` (the learner's existing verdict, imported from `lib/pilot.ts`; `null` = not yet rated). See §8b (`pilot.ts`).

### Hooks

| Hook | Method/Endpoint | Caching | Notes |
| --- | --- | --- | --- |
| `useMe()` | `GET /api/frontend/me` | `staleTime 60s` | identity ([profile.ts:66-74](lib/profile.ts#L66)) |
| `useProfile()` | `GET /api/frontend/profile` | `staleTime 60s` | returns `200 + null` when not onboarded ([profile.ts:76-85](lib/profile.ts#L76)) |
| `useSaveProfile()` | `PUT /api/frontend/profile` | mutation | onSuccess invalidates `["profile"]` + `["me"]` ([profile.ts:87-97](lib/profile.ts#L87)) |
| `useAnalytics()` | `GET /api/frontend/analytics` | `refetchInterval 60s` | dashboard cards ([profile.ts:99-109](lib/profile.ts#L99)) |
| `useAnalyticsDetail(days=14)` | `GET /api/frontend/analytics/detail?days=N` | `refetchInterval 60s` | dedicated `/analytics` page ([profile.ts:151-159](lib/profile.ts#L151)) |

All reads gate `enabled: api.ready`.

---

## 7. Device Pairing & Management — `devices.ts`

Implements `IMPLEMENTATION_AUTH_PAIRING.md §6.1/§7.4`. The frontend never holds device secrets — pairing is "user proves ownership of a code the lamp displays."

### Wire types

- `PairingInfo`: `device_id, friendly_name, expires_at` (ISO) ([devices.ts:15-19](lib/devices.ts#L15)).
- `Device`: `device_id, friendly_name, paired_at, last_seen_at, online` — `online` = `last_seen_at` within 60 s (computed backend-side) ([devices.ts:21-27](lib/devices.ts#L21)).

### Error mapping algorithm (`§7.5`)

`ErrorCode` union: `CODE_NOT_FOUND | CODE_EXPIRED | ALREADY_PAIRED | USER_AUTH_FAIL | NOT_OWNER | NOT_FOUND | RATE_LIMIT | NETWORK | UNKNOWN` ([devices.ts:30-39](lib/devices.ts#L30)).

`errorCode(err)` ([devices.ts:49-72](lib/devices.ts#L49)) normalizes a thrown error to a stable code:
1. If `err instanceof ApiError`: prefer the backend's `body.code` when present and not `"UNKNOWN"`.
2. Else fall back by HTTP status: `404→CODE_NOT_FOUND`, `409→ALREADY_PAIRED`, `410→CODE_EXPIRED`, `401→USER_AUTH_FAIL`, `403→NOT_OWNER`, `429→RATE_LIMIT`, `≥500→NETWORK`, else `UNKNOWN`.
3. Not an `ApiError` (fetch rejected — DNS / conn refused / CORS) → `"NETWORK"`.

`friendlyError(err)` = `friendlyByCode(errorCode(err))`. `friendlyByCode(code)` maps each code to a `{ code, message, action? }` for the UI — e.g. `CODE_NOT_FOUND` → "We couldn't find that lamp. Please restart your lamp and try again." with action "Restart your lamp" ([devices.ts:74-111](lib/devices.ts#L74)).

### Hooks (`§7.4`)

| Hook | Method/Endpoint | Cache behavior |
| --- | --- | --- |
| `usePairingInfo(code)` | `GET /api/pairing-info/{code}` (URL-encoded) | `enabled: api.ready && !!code`, `retry:false` ([devices.ts:114-122](lib/devices.ts#L114)) |
| `useCompletePairing()` | `POST /api/device/complete-pairing` `{ pairing_code }` | mutation ([devices.ts:124-133](lib/devices.ts#L124)) |
| `useDevices()` | `GET /api/devices` → `{ devices: Device[] }` | `refetchInterval 60s` ([devices.ts:135-145](lib/devices.ts#L135)) |
| `useRenameDevice()` | `POST /api/device/{id}/rename` `{ friendly_name }` | onSuccess invalidates `["devices"]` ([devices.ts:147-158](lib/devices.ts#L147)) |
| `useUnlinkDevice()` | `POST /api/device/{id}/unlink` | optimistic remove ([devices.ts:160-179](lib/devices.ts#L160)) |

**Optimistic unlink algorithm** ([devices.ts:165-178](lib/devices.ts#L165)): `onMutate` cancels in-flight `["devices"]` queries, snapshots `prev`, removes the device from the cached list via `setQueryData(... filter(d => d.device_id !== id))`, returns `{ prev }` as context. `onError` rolls back to `ctx.prev`. `onSettled` always invalidates `["devices"]` to resync. Note `complete-pairing`/`rename`/`unlink` are all backend `POST` even though `rename` is logically a PUT and `unlink` a DELETE — they follow the pairing spec.

---

## 8. Admin Data Layer — `admin.ts`

The system-wide read surface for the `/admin` dashboard. Talks to `/api/frontend/admin/*`, mirrors `app/schemas/admin.py`. Every endpoint is gated server-side on the admin allowlist; a non-admin gets `403 NOT_ADMIN`, surfaced here as an `ApiError` the views render as an access notice — hence **`retry: false`** on every query (a 403 must not be retried) ([admin.ts:1-7](lib/admin.ts#L1), [admin.ts:297-298](lib/admin.ts#L297)).

### Key data structures

- `HealthSnapshot` — system counters: `users_onboarded, devices_total, devices_paired, devices_revoked, online_devices, pairing_codes_live, sessions_total, turns_total, turns_failed, memories_total, events_total, admins_total` ([admin.ts:14-27](lib/admin.ts#L14)).
- `CostSummary` — `total_usd, turns_costed, input_tok, output_tok, thinking_tok` ([admin.ts:29-35](lib/admin.ts#L29)).
- `AdminOverview` — `range_days, health, cost, daily[], subject_mix, difficulty_mix, query_type_mix, status_mix, tier_mix, event_counts` (mixes are `Record<string, number>`) ([admin.ts:43-54](lib/admin.ts#L43)).
- `AdminUserRow`, `AdminDeviceRow`, `AdminSessionRow`, `AdminTurnRow` — table rows. `AdminTurnRow` includes the persisted `timeline: TimelineStep[] | null` waterfall and the Claude timeout-fallback fields `fallback`/`fallback_from` (set when a Gemini server failure rerouted the turn to Claude) ([admin.ts:96-126](lib/admin.ts#L96)).
- `AdminTurnTrace` — full pipeline audit for one turn: per-stage latencies (`capture/image_enhance/stt/tier1/tier2/tier3/tts/latex/processing`), media URLs (`raw_audio/raw_image/enhanced_image`), the raw prompt/response/system prompt, **visual grounding** (`extracted_ocr_text`, `bounding_box: number[]` = `[ymin,xmin,ymax,xmax]` normalized 0-1000), `phases: TurnTracePhase[]`, and the turn's final fields ([admin.ts:138-190](lib/admin.ts#L138)).
- `TurnTracePhase` — `{ phase, ms, status ("ok"|"error"|"skipped"), detail }` ([admin.ts:129-134](lib/admin.ts#L129)).
- `AdminMedia` — storage card: `backend, bucket, turns_with_media, traces_with_media, storage_objects, storage_bytes, oldest_media_at` (object/byte counts null on local/off backends) ([admin.ts:195-203](lib/admin.ts#L195)).
- `MediaCleanupResult` — `ok, error, turns_cleared, traces_cleared, objects_deleted, remaining_turns, remaining_traces` (`remaining_* > 0` → "click again to continue") ([admin.ts:207-215](lib/admin.ts#L207)).
- `AdminModels` (Multi-LLM eval rollup) — `range_days, totals (ModelEvalTotals), models (ModelStatRow[]), daily (ModelEvalDailyPoint[]), available_models (ModelOption[])` ([admin.ts:277-283](lib/admin.ts#L277)). `ModelStatRow` carries per-model stats incl. `success_rate` (0–100), `avg_latency_ms`, cost/token aggregates, and feedback (`avg_rating` 1–5, `thumbs_up/down`) ([admin.ts:230-253](lib/admin.ts#L230)).
- `Envelope<T> = { rows: T[] }` — list-wrapper used by users/devices/sessions/turns/events ([admin.ts:225-227](lib/admin.ts#L225)).
- **Updated 2026-07-03 — new structures:**
  - `AdminPerformance` / `AdminPerfStage` — aggregate per-stage latency report: `range_days, sample_turns, avg_total_ms, avg_ttft_ms, avg_first_audio_ms, p95_first_audio_ms, n_first_audio, stages[]` (each `{ stage, label, n, avg_ms, p95_ms }`).
  - `AdminOtaRelease` / `AdminOtaReleases` — firmware release: `{ id, version, size, notes, is_current, created_by, created_at }` wrapped in `{ rows }`.
  - `AdminTurnRow` / `AdminTurnTrace` gained behavioural + curriculum analytics fields (data-collection §13): `topic, error_type, is_mcq, student_stuck, same_problem, student_disputes_prior, image_needed, concepts[], problem_statement` (row) and `turn_*` variants + `turn_solution_outline, turn_ocr_text, first_audio_ms` (trace). `AdminUserRow` gained `cohort` (pilot batch tag). All nullable.
  - **Pilot dashboard** (`app/schemas/admin_pilot.py`): `PilotFeedbackSummary`/`PilotFeedbackRow`, `PilotSurveyResults`/`ConfidenceDelta`/`PilotSurveyRow`, `PilotProblemReports`/`PilotProblemRow`, `PilotFunnel`.
  - **Learning insights** (`app/schemas/insights.py`): `InsightTopicRow`, `InsightCoverage`/`InsightCoverageSubject`, `InsightEngagement`, `InsightQuality`, `InsightMistakes`/`MistakeTypeRow`/`MistakeTopicRow`.
- **Updated 2026-07-09 → 07-11 — Analytics-tab structures** (+108 lines, mirror `app/schemas/admin.py`):
  - `AnalyticsRange = "today" | "yesterday" | "7d" | "30d"`.
  - `AdminAnalyticsSummary` — `range, n_questions, n_generation, avg/p95_generation_ms, avg/p95_total_ms, stages: AdminPerfStage[], escalation: AdminEscalationBreakdown`.
  - `AdminEscalationBreakdown` = five `AdminEscalationTier` (`{ n, avg_ms }`) buckets: `tier1, tier2_direct, tier2_esc, tier3_direct, tier3_esc` — every ok lamp turn lands in exactly one.
  - `AdminAnalyticsQuestionRow` — `trace_id` (stable id; `turn_id` null on failures), `status, reason, asked_at, device_id, device_name, question, generation_ms, latex_ms, graph_ms, tts_ms, total_ms, final_tier, llm_model, difficulty` (question level), `escalated`; wrapped in `AdminAnalyticsQuestions`.
  - `AdminAnalyticsPoint` / `AdminAnalyticsTimeseries` (`bucket: "hour" | "day"`) — the (currently unused-by-UI) trend series.

### Hooks

| Hook | Endpoint | Query params | Polling/stale |
| --- | --- | --- | --- |
| `useAdminOverview(days=14)` | `GET /api/frontend/admin/overview` | `days` | `refetchInterval 60s`, `retry:false` ([admin.ts:286-299](lib/admin.ts#L286)) |
| `useAdminUsers(limit=200)` | `GET .../admin/users` | `limit` | `retry:false` ([admin.ts:301-309](lib/admin.ts#L301)) |
| `useAdminDevices(limit=300)` | `GET .../admin/devices` | `limit` | `refetchInterval 60s` ([admin.ts:311-321](lib/admin.ts#L311)) |
| `useAdminSessions(limit=100)` | `GET .../admin/sessions` | `limit` | `retry:false` ([admin.ts:323-331](lib/admin.ts#L323)) |
| `useAdminTurns({limit=50,userId,status})` | `GET .../admin/turns` | `limit`,`user_id?`,`status?` via `URLSearchParams` | `retry:false` ([admin.ts:333-345](lib/admin.ts#L333)) |
| `useTurnTrace(turnId\|null)` | `GET .../admin/turns/{id}/trace` | — | `enabled: ready && !!turnId`, `staleTime 5m`, `retry:false` ([admin.ts:351-360](lib/admin.ts#L351)) |
| `useAdminMedia()` | `GET .../admin/media` | — | `staleTime 30s`, `retry:false` ([admin.ts:363-372](lib/admin.ts#L363)) |
| `useMediaCleanup()` | `POST .../admin/media/cleanup` `{ days }` | — | onSettled invalidates `["admin-media"]` ([admin.ts:376-386](lib/admin.ts#L376)) |
| `useAdminEvents(limit=100)` | `GET .../admin/events` | `limit` | `retry:false` ([admin.ts:388-396](lib/admin.ts#L388)) |
| `useAdminModelEval({days=30,model,userId})` | `GET .../admin/models` | `days`,`model?`,`user_id?` | `refetchInterval 60s` ([admin.ts:398-412](lib/admin.ts#L398)) |
| **`useAdminPerformance(days=14)`** | `GET .../admin/performance` | `days` | `refetchInterval 60s`, `retry:false` (Updated 2026-07-03) |
| **`useAnalyticsSummary(range="7d")`** | `GET .../admin/analytics/summary` | `range` | `refetchInterval 60s`, `retry:false` (added 2026-07-09→07-11) |
| **`useAnalyticsQuestions(range="7d")`** | `GET .../admin/analytics/questions` | `range` | `refetchInterval 60s`, `retry:false` |
| **`useAnalyticsTimeseries(range="7d")`** | `GET .../admin/analytics/timeseries` | `range` | `refetchInterval 60s`, `retry:false` |
| **`useAdminOtaReleases()`** | `GET .../admin/ota/releases` | — | `retry:false` |
| **`useUploadOtaRelease()`** | `POST .../admin/ota/release?version&notes` | raw `.bin` body | manual `fetch` w/ Clerk token, `Content-Type: application/octet-stream` (bypasses JSON) |
| **`useDeleteOtaRelease()`** | `DELETE .../admin/ota/release/{id}` | — | mutation |
| **`useAdminCohorts()`** | `GET .../admin/pilot/cohorts` | — | pilot batch list for the cohort filter |
| **`useAdminPilotFunnel(cohort)`** | `GET .../admin/pilot/funnel` | `cohort?` | activation funnel, 60s |
| **`useAdminPilotFeedback(days=14,cohort)`** | `GET .../admin/pilot/feedback` | `days`,`cohort?` | 60s |
| **`useAdminPilotSurveys(cohort)`** | `GET .../admin/pilot/surveys` | `cohort?` | confidence deltas + NPS, 60s |
| **`useAdminPilotReports(status,cohort)`** | `GET .../admin/pilot/reports` | `status?`,`cohort?` | 60s |
| **`useSetReportStatus()`** | `POST .../admin/pilot/reports/{id}/status` | `{status}` | the one mutating admin-pilot action; invalidates reports |
| **`useInsightTopics / Coverage / Engagement / Quality / Mistakes(exam?,cohort?)`** | `GET .../admin/pilot/insights/{topics,coverage,engagement,quality,mistakes}` | `exam?`,`cohort?` | 60s, `retry:false` |

`useTurnTrace` lazy-loads: pass `null` to keep the query idle until the Trace drawer opens (no fetch per list row); a 404 means "no trace recorded" rendered as empty state, so `retry:false`. `useMediaCleanup` is the only classic manual write — the backend has no scheduled deletion; deletion is batched server-side ([admin.ts:347-385](lib/admin.ts#L347)). **Updated 2026-07-03:** the cohort-filtered pilot/insights hooks build their query string via a shared `cohortQs(cohort, extra)` helper; `useUploadOtaRelease` and `useSetReportStatus` are additional writes.

---

## 8b. Pilot Instrumentation — `pilot.ts` (added 2026-07-03)

The client data layer for the pilot program's "low-risk (Green)" features. Talks to the backend's `/api/frontend/pilot/*` surface via `useApi()` (Clerk token attached); mirrors `app/schemas/pilot.py`. Kept deliberately separate from `profile.ts`/`models.ts` so the pilot additions stay an isolated, easy-to-remove module.

### Wire types

- **F1 feedback:** `Thumbs = "up" | "down"`; `Resolution = "got_it" | "still_stuck" | "explain_differently"`; `TurnFeedbackInput { turn_id, thumbs?, reason?, resolution?, rating?, feedback_text? }`; `TurnFeedbackState` (the pre-filled verdict the analytics feed returns on each `RecentTurn`).
- **F2 surveys:** `SurveyKind = "baseline" | "exit" | "weekly"`; `SurveyInput { survey_kind, version?, answers: Record<string, unknown> }`; `SurveyStatus { baseline, exit, weekly }` (each an ISO date or null).
- **F5 reports:** `ProblemReportInput { category?, message?, turn_id?, device_id?, context? }`.
- **Personalization:** `AnswerLength = "short" | "balanced" | "detailed"`; `ExamplePref = "love" | "sometimes" | "rarely"`; `Personalization { interests[], answer_length, example_pref, notes }`.
- **F7 consent:** `ConsentInput { consent_type, version?, granted?, source?, extra? }`.

### Hooks / functions

| Export | Method/Endpoint | Kind | Notes |
| --- | --- | --- | --- |
| `useTurnFeedback()` | `POST /api/frontend/pilot/turn-feedback` | fn | per-answer 👍/👎 + resolution; used by `AnalyticsView`'s `TurnFeedbackControl` |
| `useSurveyStatus()` | `GET /api/frontend/pilot/survey/status` | query | `staleTime 60s`; "already submitted" notice |
| `useSubmitSurvey()` | `POST /api/frontend/pilot/survey` | mutation | invalidates `["pilot-survey-status"]` |
| `useReportProblem()` | `POST /api/frontend/pilot/report` | fn | global `<ReportProblem>` widget |
| `usePersonalization()` | `GET /api/frontend/pilot/personalization` | query | `staleTime 60s`; seeds the form + `PersonalizeCard` |
| `useSavePersonalization()` | `POST /api/frontend/pilot/personalization` | mutation | invalidates `["personalization"]` |
| `useRecordConsent()` | `POST /api/frontend/pilot/consent` | fn | recorded best-effort before the baseline survey write |

All reads gate `enabled: api.ready`. The mutating flows are **best-effort** in their callers — feedback/report/consent failures are swallowed so they never block the UI.

---

## 9. Multi-LLM Models & Solve — `models.ts`

The Multi-LLM evaluation data layer: model catalog + the single/compare "solve" calls. The solve calls send **multipart FormData** (audio WAV + image blobs + text), so they bypass the JSON `useApi()` helpers and use a token-aware `fetch` directly — the same pattern the simulator uses for `/simulate` ([models.ts:1-13](lib/models.ts#L1)).

### Wire types

- `ModelInfo` — catalog row: `id, label, provider, available, vision, audio, input_per_mtok, output_per_mtok, note, is_default` ([models.ts:16-27](lib/models.ts#L16)).
- `ModelsOut` — `{ models: ModelInfo[], default_model }` ([models.ts:29-32](lib/models.ts#L29)).
- `SimResponse` / `SimDisplay` — the answer: `speech`, `display ({type:"latex"|"text"|"none", latex, text})`, optional `confidence/query_type/subject/difficulty` ([models.ts:34-47](lib/models.ts#L34)).
- `TimelineStep` — `{ step, ms, where: "client"|"server" }` (the shared type also imported by `admin.ts`) ([models.ts:52-56](lib/models.ts#L52)).
- `AutoStep` — one LLM call inside AUTO/tiered-escalation: `tier, model, role ("first-pass"|"escalation"|"keyed-nudge"), reason, latency_ms, input/thinking/output_tokens, estimated_cost, confidence` ([models.ts:60-71](lib/models.ts#L60)).
- `SolveMeta` — per-answer metadata: `model_id, label, provider, status ("ok"|"not_configured"|"timeout"|"busy"|"error"), latency_ms, tokens, estimated_cost, error, response_id (for feedback), timeline (server steps), server_ms`, plus AUTO-only `steps[], escalated, final_tier, memo_active` ([models.ts:73-97](lib/models.ts#L73)).
- `FeedbackInput` — `{ response_id, thumbs?, rating?, feedback_text? }` ([models.ts:99-104](lib/models.ts#L99)).
- `SolveOut = { response, meta }`; `CompareOut = { results: SolveOut[] }` ([models.ts:106-113](lib/models.ts#L106)).
- `SolveInput = { audio: Blob|null, images: Blob[], text? }` ([models.ts:127-131](lib/models.ts#L127)).

### `buildForm(input)` ([models.ts:133-145](lib/models.ts#L133))

Builds the multipart body: appends `audio` as `"question.wav"` (only if present); each image as `images` named `snap-{i+1}.jpg`; `text` (trimmed) only if non-empty. **The legacy single `image` field is deliberately not sent** — double-appending the first frame uploaded it twice (2× upload, enhanced/billed twice by Gemini — observed in prod 2026-06-12, implicated in free-tier OOM crashes) ([models.ts:137-143](lib/models.ts#L137)).

### `postFormTimed<T>(path, fd, getToken, startedAt?)` — the journey-instrumented uploader ([models.ts:161-232](lib/models.ts#L161))

Measures three browser-side phases and persists the pre-fetch ones to the backend:

1. **prepare** = `now() - startedAt` (WAV encode + snapshot + form build, from when the user "gave" the input).
2. **auth** = duration of `await getToken()` (measured against `BUDGET.token`; warns if no token).
3. Builds `preFetch: TimelineStep[]` = `[{step:"prepare"...}, {step:"auth"...}]` and appends it to the form as `client_timeline` (JSON string) so the **persisted** journey spans the whole path, not just the server half ([models.ts:186-191](lib/models.ts#L186)).
4. `fetch(\`${BACKEND_URL}${path}\`, { method:"POST", headers: token ? {Authorization} : undefined, body: fd })`. Note: no manual `Content-Type` — the browser sets the multipart boundary. On reject → log NETWORK ERROR + re-throw.
5. **upload** = round-trip ms (request upload + server work + download), logged with soft/severe budgets `8000`/`20000` (inference is legitimately slow).
6. On `!r.ok`: parse the error JSON, extract `code = e.detail?.code ?? e.code`, log, then throw a tagged `Error` with `.code` attached and message `e.detail?.error ?? "The request failed."` ([models.ts:210-217](lib/models.ts#L210)).
7. On success: returns `{ data, clientSteps }` where `clientSteps = [...preFetch, {step:"upload"...}]`. `upload` is returned for the live view but **not persisted** (a request can't carry its own round-trip time) ([models.ts:218-228](lib/models.ts#L218)).

Helpers: `withClientJourney(out, clientSteps)` prepends the client steps in front of `out.meta.timeline` ([models.ts:234-238](lib/models.ts#L234)); `sumFormBytes` / `fmtBytes` compute a best-effort payload size for the start log ([models.ts:240-254](lib/models.ts#L240)).

### Hooks & functions

| Export | Endpoint | Notes |
| --- | --- | --- |
| `useModels()` | `GET /api/frontend/models` | `staleTime 5m` ([models.ts:116-124](lib/models.ts#L116)) |
| `useSolve().solveOne(model, input, startedAt?)` | `POST /api/frontend/solve` | appends `model`; merges client journey ([models.ts:262-269](lib/models.ts#L262)) |
| `useSolve().solveCompare(models[], input, startedAt?)` | `POST /api/frontend/solve/compare` | appends each `models` entry; one batch round-trip → same `clientSteps` prefixed to every result ([models.ts:271-280](lib/models.ts#L271)) |
| `useFeedback()` | `POST /api/frontend/feedback` `FeedbackInput` | returns `{ ok }` ([models.ts:286-290](lib/models.ts#L286)) |

### Display formatters ([models.ts:292-308](lib/models.ts#L292))

- `formatCost(usd)`: `null → "—"`, `0 → "$0"`, `<0.01 → $X.XXXXX` (5 dp), else `$X.XXXX` (4 dp).
- `formatLatency(ms)`: `null → "—"`, `<1000 → "N ms"`, else `(ms/1000).toFixed(2) + " s"`.
- `formatTokens(n)`: `null → "—"`, else `n.toLocaleString()`.

---

## 10. Onboarding Contract — `onboarding.ts`

The **shared** onboarding contract (no `"use client"` — imported by the client form, the server action, the auth guard, and shape-wise the backend `ProfileIn`). All option lists live here so UI, validation, and LLM personalisation stay in lockstep ([onboarding.ts:1-9](lib/onboarding.ts#L1)).

### Option lists (`as const` tuples → literal types)

| Constant | Values | DB note |
| --- | --- | --- |
| `TARGET_EXAMS` | `JEE, NEET, CAT, UPSC` | within the DB CHECK constraint ([onboarding.ts:11-12](lib/onboarding.ts#L11)) |
| `PREP_DURATIONS` | "Just getting started" / "A few months in" / "About a year" / "More than a year" | ([onboarding.ts:14-20](lib/onboarding.ts#L14)) |
| `LEARNING_STYLES` | 4 options (worked example / intuition first / picture-diagram / trying problems) | ([onboarding.ts:23-29](lib/onboarding.ts#L23)) |
| `EXPLAIN_DEPTHS` | short / balanced / go deep | ([onboarding.ts:32-37](lib/onboarding.ts#L32)) |
| `STUDY_RHYTHMS` | bursts / deep sessions / daily / deadlines | ([onboarding.ts:40-46](lib/onboarding.ts#L40)) |
| `FOCUS_SUBJECTS` | Physics / Chemistry / Mathematics / Biology / Still deciding | ([onboarding.ts:49-56](lib/onboarding.ts#L49)) |

The psychology fields (learning style, depth, rhythm, focus) land in `user_profiles.extra` (JSONB, no migration needed); only `target_exam` is constrained by the DB CHECK ([onboarding.ts:6-9](lib/onboarding.ts#L6)).

### Structures & validators

- `OnboardingQuestion` = `{ name, label, hint?, options }`; `ONBOARDING_QUESTIONS[]` lists 6 questions in render order (`name` matches the form field + action) ([onboarding.ts:59-100](lib/onboarding.ts#L59)).
- `OnboardingMetadata` — the shape mirrored into Clerk `publicMetadata`: `fullName + 6 fields + onboardingComplete: true` ([onboarding.ts:104-113](lib/onboarding.ts#L104)).
- `_oneOf(list)` factory: returns `(v) => typeof v === "string" && list.includes(v)`. From it: `isTargetExam, isPrepDuration, isLearningStyle, isExplainDepth, isStudyRhythm, isFocusSubject` — used by the server action to validate every form field before writing ([onboarding.ts:115-123](lib/onboarding.ts#L115)). The action consumes all six validators ([actions.ts:91-96](app/onboarding/actions.ts#L91)).

---

## 11. Pairing-Code Extraction — `pairing-code.ts`

`extractPairingCode(raw): string | null` — extracts the pairing code from whatever a lamp's QR encodes, liberally ([pairing-code.ts:6-38](lib/pairing-code.ts#L6)). The algorithm, in order:

1. Trim; empty → `null`.
2. **Try as URL** (`new URL(s)`): prefer the path form via `fromPath` (regex `/\/pair\/([A-Za-z0-9-]+)/`), else the `?code=` query param. Found → `normalize`.
3. Not a URL → `fromPath(s)` directly on the raw string.
4. Bare `?code=`/`code=` fragment via `/[?&]?code=([A-Za-z0-9-]+)/i`.
5. **Bare code**: strip whitespace/hyphens, test against `/^[A-Za-z0-9]{6,8}$/` (matches the backend's pairing_code shape — 6–8 alphanumerics).
6. Nothing matched → `null`.

`normalize(code)` strips whitespace/hyphens and uppercases ([pairing-code.ts:40-42](lib/pairing-code.ts#L40)). Consumed by `app/pair/[code]/page.tsx` and `components/app/QrScanner.tsx`.

---

## 12. Diagnostics & Timing — `log.ts`

The single verbose-diagnostics module (`"use client"`). Everything noisy (API client, query cache, boot/route timers) funnels through here for a consistent, color-coded console voice calling out `ERROR`, `LAG`, `RACE`, `TIMING` ([log.ts:3-22](lib/log.ts#L3)).

### Gating — `resolveEnabled()` / `VERBOSE` ([log.ts:45-66](lib/log.ts#L45))

Precedence: `NEXT_PUBLIC_VERBOSE === "0"` → off; `=== "1"` → on; then runtime `window.__LUMOS_VERBOSE` (bool); then `localStorage.LUMOS_VERBOSE` (`"1"`/`"0"`, wrapped in try/catch for private mode); default = `NODE_ENV !== "production"`. `VERBOSE` is computed once at module load.

### `LogCategory` & `TINT` ([log.ts:24-78](lib/log.ts#L24))

Categories: `API, QUERY, AUTH, BOOT, ROUTE, RACE, LAG, PERF`, each with a CSS hex tint for `%c` styling.

### `emit()` ([log.ts:99-128](lib/log.ts#L99))

Core printer. **Errors are always shown** even when `VERBOSE` is false (`if (!VERBOSE && method !== "error") return`). On the server (`typeof window === "undefined"`) it falls back to a plain `[Lumos CATEGORY]` text prefix because `%c` only works in browser DevTools. In the browser it uses the `stamp()` badge formatting.

### `log` object ([log.ts:130-158](lib/log.ts#L130))

`debug/info/warn/error(category, msg, data?)` wrap `emit`. `log.lag(label, ms, budget, severe?, data?)` reports a measured duration: `ms >= severe` → `error`/`LAG` ("SEVERE LAG"); `ms >= budget` → `warn`/`LAG`; else `debug`/`PERF`. Returns the rounded ms so callers accumulate.

### `nextSeq()` / `stopwatch()` ([log.ts:86-181](lib/log.ts#L86))

`nextSeq()` — monotonic per-page-load counter formatted `#NNN` (zero-padded to 3) to correlate start/end lines of the same call across interleaved logs. `stopwatch()` returns `{ startedAt, lap() (ms since last lap), total() (ms since creation) }` using `performance.now()` when available, else `Date.now()`.

### Race detection ([log.ts:183-208](lib/log.ts#L183))

A module-level `inflight = Map<string, number>`. `raceEnter(key, seqId)` increments the count for `key`; when it exceeds 1 it emits a `RACE` warning ("N× concurrent in-flight … overlapping duplicate request"). `raceExit(key)` decrements, deleting the entry at 0. This surfaces the "three identical verifies fired at once" pattern. `api.ts` and `models.ts` wrap every request in `raceEnter`/`raceExit`.

---

## 13. Time Formatters — `time.ts`

Two pure formatters ([time.ts:1-31](lib/time.ts#L1)):

- `formatCountdown(msRemaining)` — for the pairing expiry countdown. `s = max(0, floor(ms/1000))`; `s<=0 → "expired"`; `s<60 → "in N second(s)"`; `m<60 → "in N minute(s)"` or `"in M min R s"` when there's a remainder; else `"in H hour(s)"` ([time.ts:4-16](lib/time.ts#L4)).
- `formatAgo(iso)` — for `last_seen_at`. `null → "never"`; unparseable → `"unknown"`; `s<60 → "N s ago"`; `m<60 → "N min ago"`; `h<24 → "N h ago"`; else `"N d ago"` ([time.ts:19-31](lib/time.ts#L19)).

---

## 14. Complete Endpoint Map (Frontend → Backend)

Every backend endpoint touched by this layer. Surfaces: **Frontend Manager** (`/api/frontend/*`), **device pairing** (`/api/device/*`, `/api/pairing-info/*`, `/api/devices`), **admin** (`/api/frontend/admin/*`), **pilot** (`/api/frontend/pilot/*`). (Updated 2026-07-03 — pilot, admin performance/OTA/pilot/insights rows added below.)

| Frontend lib call (file) | HTTP method | Backend endpoint | Transport |
| --- | --- | --- | --- |
| `getBackendProfile` / `requireOnboarded` (`auth-guard.ts`) | GET | `/api/frontend/profile` | server fetch (9 s timeout) |
| `getAdminVerdict` / `requireOnboardedAndAdmin` (`auth-guard.ts`) | GET | `/api/frontend/me` | server fetch (9 s timeout, concurrent w/ profile) |
| `saveProfileToBackend` (`actions.ts`) | PUT | `/api/frontend/profile` | server fetch (8 s timeout) |
| `useMe` (`profile.ts`) | GET | `/api/frontend/me` | `useApi.get` |
| `useProfile` (`profile.ts`) | GET | `/api/frontend/profile` | `useApi.get` |
| `useSaveProfile` (`profile.ts`) | PUT | `/api/frontend/profile` | `useApi.put` |
| `useAnalytics` (`profile.ts`) | GET | `/api/frontend/analytics` | `useApi.get` |
| `useAnalyticsDetail` (`profile.ts`) | GET | `/api/frontend/analytics/detail?days=N` | `useApi.get` |
| `usePairingInfo` (`devices.ts`) | GET | `/api/pairing-info/{code}` | `useApi.get` |
| `useCompletePairing` (`devices.ts`) | POST | `/api/device/complete-pairing` | `useApi.post` |
| `useDevices` (`devices.ts`) | GET | `/api/devices` | `useApi.get` |
| `useRenameDevice` (`devices.ts`) | POST | `/api/device/{id}/rename` | `useApi.post` |
| `useUnlinkDevice` (`devices.ts`) | POST | `/api/device/{id}/unlink` | `useApi.post` |
| `useAdminOverview` (`admin.ts`) | GET | `/api/frontend/admin/overview?days=N` | `useApi.get` |
| `useAdminUsers` (`admin.ts`) | GET | `/api/frontend/admin/users?limit=N` | `useApi.get` |
| `useAdminDevices` (`admin.ts`) | GET | `/api/frontend/admin/devices?limit=N` | `useApi.get` |
| `useAdminSessions` (`admin.ts`) | GET | `/api/frontend/admin/sessions?limit=N` | `useApi.get` |
| `useAdminTurns` (`admin.ts`) | GET | `/api/frontend/admin/turns?limit=N&user_id&status` | `useApi.get` |
| `useTurnTrace` (`admin.ts`) | GET | `/api/frontend/admin/turns/{id}/trace` | `useApi.get` |
| `useAdminMedia` (`admin.ts`) | GET | `/api/frontend/admin/media` | `useApi.get` |
| `useMediaCleanup` (`admin.ts`) | POST | `/api/frontend/admin/media/cleanup` | `useApi.post` |
| `useAdminEvents` (`admin.ts`) | GET | `/api/frontend/admin/events?limit=N` | `useApi.get` |
| `useAdminModelEval` (`admin.ts`) | GET | `/api/frontend/admin/models?days=N&model&user_id` | `useApi.get` |
| `useAdminPerformance` (`admin.ts`) | GET | `/api/frontend/admin/performance?days=N` | `useApi.get` |
| `useAdminOtaReleases` (`admin.ts`) | GET | `/api/frontend/admin/ota/releases` | `useApi.get` |
| `useUploadOtaRelease` (`admin.ts`) | POST | `/api/frontend/admin/ota/release?version&notes` | manual octet-stream fetch (Clerk token) |
| `useDeleteOtaRelease` (`admin.ts`) | DELETE | `/api/frontend/admin/ota/release/{id}` | `useApi.del` |
| `useAdminCohorts` (`admin.ts`) | GET | `/api/frontend/admin/pilot/cohorts` | `useApi.get` |
| `useAdminPilotFunnel` (`admin.ts`) | GET | `/api/frontend/admin/pilot/funnel?cohort` | `useApi.get` |
| `useAdminPilotFeedback` (`admin.ts`) | GET | `/api/frontend/admin/pilot/feedback?days&cohort` | `useApi.get` |
| `useAdminPilotSurveys` (`admin.ts`) | GET | `/api/frontend/admin/pilot/surveys?cohort` | `useApi.get` |
| `useAdminPilotReports` (`admin.ts`) | GET | `/api/frontend/admin/pilot/reports?status&cohort` | `useApi.get` |
| `useSetReportStatus` (`admin.ts`) | POST | `/api/frontend/admin/pilot/reports/{id}/status` | `useApi.post` |
| `useInsight{Topics,Coverage,Engagement,Quality,Mistakes}` (`admin.ts`) | GET | `/api/frontend/admin/pilot/insights/{…}?exam&cohort` | `useApi.get` |
| `useTurnFeedback` (`pilot.ts`) | POST | `/api/frontend/pilot/turn-feedback` | `useApi.post` |
| `useSurveyStatus` (`pilot.ts`) | GET | `/api/frontend/pilot/survey/status` | `useApi.get` |
| `useSubmitSurvey` (`pilot.ts`) | POST | `/api/frontend/pilot/survey` | `useApi.post` |
| `useReportProblem` (`pilot.ts`) | POST | `/api/frontend/pilot/report` | `useApi.post` |
| `usePersonalization` (`pilot.ts`) | GET | `/api/frontend/pilot/personalization` | `useApi.get` |
| `useSavePersonalization` (`pilot.ts`) | POST | `/api/frontend/pilot/personalization` | `useApi.post` |
| `useRecordConsent` (`pilot.ts`) | POST | `/api/frontend/pilot/consent` | `useApi.post` |
| `useModels` (`models.ts`) | GET | `/api/frontend/models` | `useApi.get` |
| `solveOne` (`models.ts`) | POST | `/api/frontend/solve` | multipart fetch |
| `solveCompare` (`models.ts`) | POST | `/api/frontend/solve/compare` | multipart fetch |
| `useFeedback` (`models.ts`) | POST | `/api/frontend/feedback` | `useApi.post` |

---

## 15. Control-Flow Diagrams

### `useApi().call<T>` request pipeline

```mermaid
flowchart TD
  A["Hook calls api.get/post/put/del(path, body?)"] --> B["call<T>: nextSeq, build key, stopwatch, raceEnter"]
  B --> C["Phase 1: token = fetchTokenShared(getToken)"]
  C -->|"sharedTokenPromise null"| C1["start ONE getToken(); tokenInFlight++"]
  C -->|"already in flight"| C2["await the same promise"]
  C1 --> D
  C2 --> D["Set Authorization header; Content-Type if body"]
  D --> E["Phase 2: fetch BACKEND_URL+path"]
  E -->|"fetch rejects"| ERR1["log NETWORK ERROR; throw original (=> NETWORK)"]
  E -->|"response"| F{"res.ok?"}
  F -->|"no"| G["parse {error,code}; log; throw ApiError(status, detail ?? body)"]
  F -->|"204"| H["return undefined"]
  F -->|"2xx"| I["res.json() as T; measure parse; log info; return"]
  ERR1 --> Z["finally: raceExit(key)"]
  G --> Z
  H --> Z
  I --> Z
```

### Protected page gate (RSC) sequence

```mermaid
sequenceDiagram
  participant MW as middleware.ts
  participant Page as RSC (e.g. /admin)
  participant Guard as auth-guard.ts
  participant Clerk
  participant BE as Lumos backend

  MW->>MW: isProtected(req)? auth().protect()
  Page->>Guard: requireOnboarded()
  Guard->>Clerk: auth().userId / getToken()
  alt no userId
    Guard-->>Page: redirect("/sign-in")
  end
  Guard->>BE: GET /api/frontend/profile (9s timeout, no-store)
  alt 200 + null
    Guard-->>Page: redirect("/onboarding")  (status=missing)
  else 200 + profile
    Guard-->>Page: profile  (status=exists)
  else error/timeout
    Guard-->>Page: null  (status=unreachable, degrade)
  end
  Note over Page,Guard: /admin (Updated 2026-07-03): requireOnboardedAndAdmin runs BOTH probes concurrently
  Page->>Guard: requireOnboardedAndAdmin() → Promise.all(getBackendProfile, getAdminVerdict)
  Guard->>BE: GET /api/frontend/me (9s timeout, in parallel with /profile)
  alt verdict not_admin (is_admin === false / no token)
    Guard-->>Page: redirect("/dashboard")
  else admin OR unknown (unreachable)
    Guard-->>Page: render (/admin panels re-check require_admin server-side)
  end
```

### Multipart solve journey

```mermaid
flowchart LR
  U["User releases mic / hits send (startedAt)"] --> P["buildForm: audio=question.wav, images=snap-N.jpg, text"]
  P --> PR["measure prepare = now - startedAt"]
  PR --> AU["measure auth = getToken()"]
  AU --> CT["append client_timeline = [prepare, auth] to FormData"]
  CT --> FE["fetch POST /api/frontend/solve(/compare) with Bearer token"]
  FE -->|"!r.ok"| EX["throw Error w/ .code = detail.code"]
  FE -->|"ok"| RJ["r.json() => SolveOut/CompareOut"]
  RJ --> WJ["withClientJourney: [prepare, auth, upload, ...server timeline]"]
  WJ --> OUT["return to caller (live + persisted journey)"]
```

---

## 16. Edge Cases, Errors, Timeouts, Fallbacks

- **Token-refresh race / 401-flap.** `fetchTokenShared` collapses concurrent `getToken()` into one in-flight fetch; `tokenInFlight > 1` would fire a `RACE` warning, signalling the dedup is broken ([api.ts:30-55](lib/api.ts#L30)).
- **No token.** `call` proceeds unauthenticated with an `AUTH` warning; the multipart path omits the `Authorization` header entirely ([api.ts:99-104](lib/api.ts#L99), [models.ts:196-198](lib/models.ts#L196)).
- **Network failure (fetch rejects).** No HTTP status → re-thrown as the original `TypeError`; `devices.ts errorCode` maps any non-`ApiError` to `"NETWORK"` ([api.ts:113-123](lib/api.ts#L113), [devices.ts:70-71](lib/devices.ts#L70)).
- **Non-2xx JSON.** Parsed to `{error,code}`; falls back to `{error: statusText, code: "UNKNOWN"}` if the body isn't JSON; thrown as `ApiError`, preferring a nested `detail` envelope ([api.ts:130-145](lib/api.ts#L130)).
- **204.** Returns `undefined` (used by DELETE-style calls) ([api.ts:147-151](lib/api.ts#L147)).
- **403 NOT_ADMIN.** All admin queries set `retry: false` so a non-admin's 403 isn't retried; rendered as an access notice ([admin.ts:297-298](lib/admin.ts#L297)).
- **404 trace.** `useTurnTrace` renders empty state, `retry:false` ([admin.ts:347-359](lib/admin.ts#L347)).
- **Server-side probe hang.** `AbortSignal.timeout(9000)` / `8000` caps the RSC `/profile`/`/me` probes and the onboarding write so a cold backend can't make the page never stream ([auth-guard.ts:73-77](lib/auth-guard.ts#L73), [actions.ts:53](app/onboarding/actions.ts#L53)).
- **Degrade-don't-bounce.** `"unreachable"` profile → let the user through with `null`; admin verdict `"unknown"` → render (endpoints still enforce). Only a definitive `"missing"`/`"not_admin"` verdict bounces (auth-guard.ts).
- **`redirect()` outside try.** `requireOnboardedAndAdmin` (and the `getAdminVerdict` degrade path) call `redirect()` **outside** any try so `NEXT_REDIRECT` isn't swallowed by the degrade catch (auth-guard.ts).
- **Optimistic unlink rollback.** `onError` restores the snapshot; `onSettled` always re-invalidates ([devices.ts:174-178](lib/devices.ts#L174)).
- **Double-upload bug fixed.** `buildForm` no longer appends the legacy single `image` field (caused 2× upload + double Gemini billing / OOM) ([models.ts:137-143](lib/models.ts#L137)).
- **Onboarding save must succeed first.** The Supabase row is the source of truth, so the Clerk `publicMetadata` mirror is best-effort and never blocks; a failed save returns a retry message and does **not** flip the gate ([actions.ts:109-153](app/onboarding/actions.ts#L109)).
- **No retry on server probes.** Single fast probe by design — every retry is dead time on a blank screen; client React Query handles its own retries ([auth-guard.ts:60-64](lib/auth-guard.ts#L60)).
- **`localStorage` in private mode.** `resolveEnabled` wraps the read in try/catch ([log.ts:54-60](lib/log.ts#L54)).

---

## 17. Integration Points & Cross-References

### What this layer calls (downstream)

- **Lumos FastAPI backend** at `BACKEND_URL` — all endpoints in the [map above](#14-complete-endpoint-map-frontend--backend). Backend schema mirrors: `app/schemas/frontend.py` (`Me`, `ProfileOut`/`ProfileIn`, analytics), `app/schemas/admin.py` (all `Admin*` rows + trace + media + model rollups), `app/schemas/model_eval.py` (`ModelInfo`, `SolveOut`, `CompareOut`, feedback). The 45 s backend Redis cache drives the 60 s poll intervals.
- **Clerk** — `useAuth().getToken` (client) and `auth().getToken()` / `currentUser()` / `clerkClient` (server) for the JWT and email/metadata.

### What calls this layer (upstream)

- `middleware.ts` enforces the signed-in gate on `/dashboard, /analytics, /devices, /pair, /connect, /onboarding, /simulator, /admin`; the onboarding-completion + admin-role gates are deferred to `auth-guard.ts` in the pages ([middleware.ts:7-22](middleware.ts#L7)).
- `app/onboarding/actions.ts` imports the `onboarding.ts` validators and writes `PUT /api/frontend/profile` server-side ([actions.ts:5-13](app/onboarding/actions.ts#L5)).
- Consuming pages/components (from grep): `app/dashboard/page.tsx`, `app/analytics/page.tsx` + `AnalyticsView`/`AnalyticsCards`, `app/devices/page.tsx`, `app/pair/[code]/page.tsx` + `QrScanner`, `app/admin/page.tsx` + `AdminView`/`TraceView`/`JourneyBreakdown`, `app/simulator/page.tsx`, `app/onboarding/{page,OnboardingForm}.tsx`, `app/providers.tsx`, `components/app/{AppHeader,BootDiagnostics,ErrorPanel}.tsx`.

### Cross-system references

- **Firmware** — the lamp displays a QR encoding the pairing URL/code consumed by `extractPairingCode`; `last_seen_at`/`online` reflect the firmware heartbeat (multi-second cadence; `online` = within 60 s) ([devices.ts:21-27](lib/devices.ts#L21)).
- **Backend brain** — `SolveMeta.steps`/`escalated`/`final_tier` expose the tiered-escalation multi-LLM flow; `AdminTurnRow.fallback`/`fallback_from` expose the Gemini→Claude timeout fallback ([models.ts:92-97](lib/models.ts#L92), [admin.ts:122-126](lib/admin.ts#L122)).
- **Database (Supabase/Postgres+pgvector)** — `user_profiles` (incl. `.extra` JSONB for psychology fields), `admins` table (the allowlist behind `is_admin`), `turn_traces.phases`, `model_responses.response_id`, media buckets surfaced by `AdminMedia`/`MediaCleanupResult` ([onboarding.ts:6-9](lib/onboarding.ts#L6), [admin.ts:128-215](lib/admin.ts#L128)).
- **Web simulator** — shares the multipart `fetch` pattern (`/simulate`); `useSimulatorCapture.ts` (excluded here) feeds the `SolveInput` blobs ([models.ts:7-9](lib/models.ts#L7)).
