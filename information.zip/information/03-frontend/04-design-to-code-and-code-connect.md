# Frontend — Design-to-Code & Figma Code Connect (status + reference)

> **Status: NOT configured (verified 2026-07-11).** This document is the knowledge base's canonical entry for the **design ↔ code** seam — specifically **Figma Code Connect**, which maps published Figma components to their code counterparts so that pulling a component out of Figma (or reading its context in an editor) surfaces the real codebase snippet. It was produced by running the **`/figma-code-connect`** skill's prerequisite/discovery workflow against this project. The finding: **Code Connect is not set up, and cannot be with the project's current Figma plan.** No `.figma.ts` / `.figma.tsx` mapping files exist, and none could be generated. This doc records *why*, *what the mappable surface would be*, and *the exact steps to enable it* — so the gap is documented rather than silently missing.

---

## 1. What Code Connect is (and why it's in this KB)

**Figma Code Connect** publishes a small template file per design-system component (`.figma.ts` using the Figma MCP tools, or `.figma.tsx` using the `@figma/code-connect` CLI/parser) that binds a Figma component node to a real code component and an example snippet. Designers and engineers then see production code — correct import path, prop names, variant mapping — instead of an auto-generated guess when they inspect that component in Figma or via the MCP `get_code_connect_map` tool.

It belongs in this knowledge base because the Lumos frontend is **design-forward** (a hand-tuned "luminous nocturne" dark theme, hand-built SVG charts, a large admin surface) yet its UI is authored **code-first** with **no Figma design source of truth**. Code Connect is the bridge that would tie the two together; documenting its status keeps the design→code story explicit alongside the component reference in [02-components.md](02-components.md).

## 2. Current status — verified against the live Figma connection

The `/figma-code-connect` skill's Step 1 needs a Figma design URL, and its prerequisites require a published component library on an Organization/Enterprise plan. Every check was run on **2026-07-11**:

| Prerequisite (from the skill) | Required | This project | Result |
|---|---|---|---|
| Figma MCP server connected | yes | ✅ authenticated as **Ayush Maiti** (`ayushmaiti.startups@gmail.com`, project owner) via `whoami` | **met** |
| Figma **plan** tier | Organization **or** Enterprise | ❌ **`starter`** tier, **`View`** seat ("Ayush Maiti's team") | **blocked** — Code Connect is unavailable on Free/Professional/Starter |
| A Figma **design file** with a `node-id` URL | yes | ❌ none referenced anywhere in the repo (no `figma.com` URLs) | **blocked** — the skill's Step 1 cannot start |
| **Published** components in a team library | yes | ❌ no Figma component library exists for this UI | **blocked** |
| `figma.config.json` (paths / include globs) | yes | ❌ absent | not present |
| `@figma/code-connect` dependency | yes | ❌ absent from `package.json` | not present |
| `@figma/code-connect/figma-types` in `tsconfig.json` `types` | for `.figma.ts` typing | ❌ absent | not present |

**Bottom line:** three independent, hard blockers — no design file, no published library, and a **plan tier (starter) that excludes Code Connect entirely**. The skill therefore produced **no mapping files** (correctly — fabricating `.figma.ts` files against a non-existent design would be wrong). The design system today lives **only in code**: Tailwind theme tokens + local presentational primitives, not a published Figma library.

## 3. The mappable surface (what *would* be connected)

If a Figma design system were published and the plan upgraded, the natural Code Connect targets are the reusable presentational primitives, not the data-bound views. From [02-components.md](02-components.md):

- **Chart primitives** — [`components/app/charts.tsx`](Smart-Tutor-frontend/components/app/charts.tsx): `AreaTimeline`, `Donut`, `SegmentedBar`, `BarRows`, `MetricBars` (the hand-built SVG chart set reused across dashboard/analytics/admin).
- **Admin presentational primitives** (local to `AdminView`): `Card`, `CardHead`, `Table`/`Td`, `Pill`, `EmptyRow`, `SkeletonGrid`/`SkeletonRows`, `StatTile` (the last introduced 2026-07-11 with the Analytics tab).
- **Shared widgets** — `ConfirmDialog`, `ErrorPanel`, `PageSkeleton`, `QrScanner`, `AppHeader`.
- **Composed views** (would be *documented* mappings rather than reusable primitives) — `AdminView` (11 tabs, incl. the new **Analytics** tab — see [02-components.md](02-components.md) §4.4), `AnalyticsCards`, `AnalyticsView`, `TraceView`, `JourneyBreakdown`, `SurveyView`, `PersonalizationView`, `PersonalizeCard`, `ReportProblem`, `BootDiagnostics`.

A Code Connect rollout would start with the primitives (charts + `Card`/`Pill`/`Table`/`StatTile`) since they carry the design-token styling and are reused everywhere.

## 4. Enablement checklist (for when a design file + Org plan exist)

To turn this from "not configured" into live mappings, in order:

1. **Upgrade the Figma plan** to Organization or Enterprise (Code Connect is gated on plan tier — the current `starter` team cannot use it).
2. **Publish a Figma component library** for the Lumos UI (or adopt an existing UI-kit library) so the components are addressable by `node-id`.
3. **Add tooling to `Smart-Tutor-frontend`:** `npm i -D @figma/code-connect`, create `figma.config.json` (`parser: "react"`, `include`/`paths`/`importPaths` for `components/app/**`), and add `"@figma/code-connect/figma-types"` to `tsconfig.json` `compilerOptions.types`.
4. **Run `/figma-code-connect` with a real node URL** (`https://www.figma.com/design/<fileKey>/<name>?node-id=<X-Y>`). The skill then: parses the URL → `get_code_connect_suggestions` (unmapped components) → `get_context_for_code_connect` (properties) → matches the code component (Step 4) → writes `ComponentName.figma.ts` (Step 5) → validates (Step 6).
5. **Update this doc** to `Status: configured` and link the generated `.figma.ts` files.

Until step 1 is done, Code Connect stays unavailable regardless of tooling. This document — not an empty mappings folder — is the accurate current-state record.

---

*Provenance: generated by the `/figma-code-connect` skill's prerequisite/discovery pass on 2026-07-11 (Figma MCP `whoami` + repo config scan). Companion to [02-components.md](02-components.md) (the code-side component reference) and [03-lib-and-data-layer.md](03-lib-and-data-layer.md).*
