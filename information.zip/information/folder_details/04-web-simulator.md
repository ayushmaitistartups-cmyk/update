# Web Simulator — Folder & File Catalog

The **Web Simulator** is the browser-based stand-in for the physical Smart Tutor Lamp. It lets anyone build, demo, and regression-test the AI tutor "brain" — multimodal capture (webcam image + spoken question + typed text), the multi-LLM solve pipeline, TTS, and the KaTeX "screen" — entirely in a browser tab, **without ESP32 hardware**. It deliberately mirrors what the lamp sends over the wire (a 16 kHz mono WAV uplink + JPEG snapshots + optional text), **reuses the same backend brain** (`gemini_brain`, or the deterministic `web_simulator` fallback) and the **same binary WebSocket frame protocol** the firmware uses, and persists its turns to the **same Postgres `turns` / `turn_traces` tables** (tagged `source="simulation"` / `source="simulator"`).

It is **cross-cutting, not a standalone folder** — its pieces live in two repos:

- **Backend** (`D:/clartiy/Smart-Tutor-Lamp-backend`) — the deterministic brain (`app/providers/web_simulator.py`), the FastAPI gateway that serves every simulator endpoint (`app/routes/frontend_manager.py`), plus standalone Python lamp/backend simulator scripts for testing.
- **Frontend** (`D:/clartiy/Smart-Tutor-frontend`) — the `/simulator` UI page (`app/simulator/page.tsx`) and the media-capture hook (`lib/useSimulatorCapture.ts`), wired to the backend through `lib/models.ts`.
- **Firmware repo** (`D:/clartiy/Smart-Tutor-Lamp`) — `dummy_backend.py`, a single-file *backend* simulator the real lamp can talk to.

> Note the two distinct stand-ins: the **web simulator** replaces the *lamp* (browser → real backend), while `dummy_backend.py` replaces the *backend* (real lamp → fake server). The `dummy_client.py` / `mock_lamp.py` / `stress_lamp_ingest.py` scripts replace the *lamp* from the command line (Python → real backend).

> **Updated 2026-07-03:** re-verified against the 2026-07-03 source trees — the web-simulator files themselves are unchanged since the 2026-06-16 sync (`app/providers/web_simulator.py`, the `/solve`·`/ws` simulator surface in `app/routes/frontend_manager.py`, and the frontend `app/simulator/page.tsx` + `lib/useSimulatorCapture.ts`). The backend's new pilot/insights/OTA routers (`routes/pilot.py`, `insights.py`, `ota.py`, `admin_pilot.py`) are *separate* from the simulator gateway and are documented under the backend/database areas, not here.

---

## Files map

| File path | Role |
|---|---|
| `Smart-Tutor-Lamp-backend/app/providers/web_simulator.py` | The deterministic "brain" fallback used when `GEMINI_API_KEY` is unset; defines the shared `BrainEvent` streaming contract. |
| `Smart-Tutor-Lamp-backend/app/routes/frontend_manager.py` | FastAPI router mounting every simulator endpoint (`/solve`, `/solve/compare`, `/models`, `/feedback`, `/simulate`, WS `/ws`); selects and drives the brain. |
| `Smart-Tutor-Lamp-backend/dummy_client.py` | Standalone Python script that impersonates the ESP32 lamp over WS to test the real backend (canonical lamp simulator). |
| `Smart-Tutor-Lamp-backend/scripts/mock_lamp.py` | Pointer/stub re-directing to the canonical `dummy_client.py` lamp simulator. |
| `Smart-Tutor-Lamp-backend/scripts/stress_lamp_ingest.py` | Heavy ingest stress test that drives the real `/lamp/ws` stack to catch freezes in the image-upload path. |
| `Smart-Tutor-Lamp/dummy_backend.py` | Single-file *backend* simulator (no auth/TLS WS server) the real lamp connects to for hardware bring-up. |
| `Smart-Tutor-frontend/app/simulator/page.tsx` | The `/simulator` page — UI, push-to-talk, hands-free auto-capture, model picker/Compare, telemetry, KaTeX render, feedback. |
| `Smart-Tutor-frontend/lib/useSimulatorCapture.ts` | Media-capture hook — `getUserMedia`, Web Audio PCM → 16 kHz WAV encoder, JPEG snapshotter. |
| `Smart-Tutor-frontend/lib/models.ts` | Data layer that wires the page to the backend (multipart form build, timed POST, `useSolve`/`useModels`/`useFeedback`). |

---

## Backend pieces

| File | Type | Purpose |
|---|---|---|
| `app/providers/web_simulator.py` | Provider module (deterministic brain) | The web bench's fallback brain. When `GEMINI_API_KEY` is unset, it keeps the full streaming stack (framing, Clerk auth, state animation, TTS) alive by emitting a scripted `THINKING → SPEAKING → text tokens → text_end → IDLE` timeline with no LLM, no network, no randomness. It **defines the `BrainEvent` dataclass** — the `(kind, payload, state_byte)` tagged-union streaming contract that both this *and* the real `gemini_brain` emit, so the WS gateway's `_drive_turn` stays brain-agnostic. Reads only typed `user_text` (echoed) and a duck-typed `UserProfile` (`target_exam`/`prep_duration` → persona); ignores audio/image. Ported from the prototype's `brain/simulator.py`. |
| `app/routes/frontend_manager.py` | FastAPI router / gateway | The single router that mounts every simulator-facing endpoint under `/api/frontend`. Imports **both** brains (`gemini_brain`, `web_simulator`) and the `BrainEvent` contract. Serves the page's HTTP path — `POST /solve` (single model), `POST /solve/compare` (many models concurrently), `GET /models` (catalog, flagging providers with configured keys), `POST /feedback`, and legacy `POST /simulate`. Hosts the binary `WS /ws` gateway whose `_build_stream` chooses `gemini_brain.respond()` when `gemini_brain.available()` else `web_simulator.respond()`, and whose `_drive_turn` translates `BrainEvent`s into `STATE`/`TEXT_OUT`/`AUDIO_OUT` (Piper TTS) frames. Persists turns fire-and-forget to `turns` (`source="simulation"`) + `turn_traces` (`source="simulator"`). |
| `dummy_client.py` | Standalone test script (lamp simulator) | A "full lamp" Python simulator that impersonates the ESP32 over WebSocket to the **real** backend (`/lamp/ws`): simulates a wake-word event, ships an image as `IMAGE_PART`×N + `IMAGE_JPEG`, streams `AUDIO_CHUNK` (640 B / 20 ms) + `AUDIO_END`, and verbosely logs every backend frame. Tests backend changes without the physical device. (Separate from the browser web simulator; same wire protocol.) |
| `scripts/mock_lamp.py` | Pointer / stub | A docstring-only stub that redirects to the canonical `dummy_client.py` lamp simulator (run it, or copy it here to edit). No standalone implementation. |
| `scripts/stress_lamp_ingest.py` | Standalone stress test (lamp simulator) | Heavy ESP32→backend ingest stress driving the real `/lamp/ws` stack. Validates the image-upload path (Files pre-upload, JPEG magic guard, abandon-flush protocol) never freezes the connection and that multi-image turns assemble correctly; every scenario is bounded by a hard timeout so a hang is reported as `FREEZE`. Asserts the wire lifecycle. |
| `Smart-Tutor-Lamp/dummy_backend.py` *(firmware repo)* | Standalone simulator (backend stand-in) | A single-file *backend* simulator — a plain no-auth/no-TLS WebSocket server at `ws://0.0.0.0:8000/lamp/ws`. When the real lamp sends a turn it saves the image/audio to `./received/`, streams a hardcoded MP3 back as TTS (ffmpeg → 24 kHz mono int16), alternates `TFT_FRAME` (LaTeX) / `TFT_TEXT`, and emits the proper `STATE` bytes — used for firmware bring-up without a real backend. |

---

## Frontend pieces

| File | Type | Purpose |
|---|---|---|
| `app/simulator/page.tsx` | Next.js client page (`"use client"`) | The whole `/simulator` screen (`SimulatorPage` + ~15 presentational sub-components). Owns push-to-talk, **hands-free multi-page auto-capture** (sharpness + frame-diff gating, up to `MAX_IMAGES = 5`), the image queue, model selection + **Compare mode**, and rendering: split speech/display answer via KaTeX (`ScreenDisplay`, the "TFT"), `SpokenResponse` (browser **Web Speech API** auto-speak), per-call telemetry (`MetaStrip`), the input→output **journey** waterfall, the AUTO tiered-escalation panel, and a `FeedbackBar`. Calls `useSimulatorCapture` + `lib/models.ts`; never talks to an LLM directly. |
| `lib/useSimulatorCapture.ts` | React hook (media engine) | The lower-level capture engine that mirrors the lamp's multimodal payload. Owns the `MediaStream` (`getUserMedia`, camera+mic with graceful mic-only fallback), the Web Audio graph (`ScriptProcessorNode` → `downsampleToInt16` → `Int16Array` chunks), the **WAV encoder** (`encodeWav` → 16 kHz mono `audio/wav` Blob matching the lamp's uplink contract), and the **JPEG snapshotter** (`snapshotJpeg`, quality 0.85). Exposes `enable/disable/startRecording/stopRecording/snapshotJpeg` + lifecycle `state`. |

> Supporting glue (not assigned but load-bearing): `lib/models.ts` builds the multipart form (`question.wav` + `snap-N.jpg` + `text`), runs the instrumented timed POST (`postFormTimed`), and exposes `useSolve` (`solveOne`/`solveCompare`), `useModels`, and `useFeedback`. `lib/api.ts` supplies `BACKEND_URL` + Clerk-token fetch; `components/app/JourneyBreakdown.tsx` renders the journey waterfall.

---

## How these files relate

A turn flows **capture in the browser → backend brain → response back to the browser**, grounded in the code:

1. **Capture (browser).** `app/simulator/page.tsx` drives `lib/useSimulatorCapture.ts`: the mic is recorded as raw PCM through the Web Audio graph and `downsampleToInt16` → `encodeWav` into a 16 kHz mono WAV; the webcam is snapshotted to JPEGs (hands-free auto-capture keeps up to 5 sharp, distinct frames). The page assembles the lamp-shaped payload (audio WAV + images + optional text).

2. **Dispatch (two surfaces).**
   - **HTTP path (the page's primary path):** `lib/models.ts` `buildForm` → `postFormTimed` POSTs multipart `FormData` (with a Clerk `Bearer` token + `client_timeline`) to `app/routes/frontend_manager.py` `POST /solve` or `POST /solve/compare`. The backend dedupes/enhances images, runs a direct model or the AUTO tiered flow, and returns `SolveOut`/`CompareOut` (`{response:{speech,display}, meta:{…telemetry}}`).
   - **Binary WS path:** a WS client connects to `frontend_manager.py` `WS /ws` (`?token=<Clerk JWT>`) using the lamp's **same binary frame protocol**. `_build_stream` selects `gemini_brain.respond()` when a key is configured, otherwise the deterministic `app/providers/web_simulator.py` `respond()`. Both yield the shared `BrainEvent` timeline.

3. **Brain (backend, brain-agnostic).** `frontend_manager.py` `_drive_turn` consumes `BrainEvent`s identically for either brain — emitting `STATE` / `TEXT_OUT` frames and sentence-chunking the text into Piper TTS `AUDIO_OUT` frames (`FRONTEND_TTS_PROVIDER`). `web_simulator.py` is the source of truth for `BrainEvent`, which `gemini_brain.py` imports.

4. **Response (browser).** On the HTTP path the page renders the answer: `ScreenDisplay` (KaTeX, the "TFT" stand-in), `SpokenResponse` (browser Web Speech voice), and `MetaStrip` + `JourneyBreakdown` telemetry. On the WS path the browser consumes the streamed `STATE`/`TEXT_OUT`/`AUDIO_OUT` frames directly.

5. **Persistence.** Both web paths write fire-and-forget to the same Postgres `turns` table (`source="simulation"`) and `turn_traces` (`source="simulator"`), so the same dashboard/analytics/admin surfaces cover both the lamp and the bench.

The standalone scripts sit *outside* this browser flow but exercise the same protocol/stack: `dummy_client.py` (+ the `mock_lamp.py` pointer) and `stress_lamp_ingest.py` impersonate the lamp against the real backend `/lamp/ws`, while `Smart-Tutor-Lamp/dummy_backend.py` impersonates the backend for the real lamp.
