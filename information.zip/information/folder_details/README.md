# Folder & File Details — Catalog Index

This folder is a **scan-based directory catalog** of the entire Smart Tutor Lamp codebase. Every folder and every file across the three repositories (firmware, backend, frontend) — plus the cross-cutting web-simulator, database, and system-prompt areas — is listed here with **what the folder is for**, **the type of files it contains**, and **the purpose of each individual file**.

It complements the deep architectural docs in the sibling area folders (`../01-firmware/`, `../02-backend/`, etc.): those explain *how things work*; this one tells you *what every folder/file is and why it exists*.

> Source of truth: complete file listings were scanned from the synced repos and saved under [`_source_trees/`](_source_trees/). As of the **2026-07-03 refresh** these hold **firmware: 70 files, backend: 247 files, frontend: 74 files** (up from 67 / 200 / 58 at the 2026-06-16 sync — the growth is the backend's Cartesia TTS, RDKit/graph renderers, OTA, pilot/insights/tagging subsystems, the safety-guardrail prompt, and the frontend's survey/personalization/report-a-problem/OTA surfaces). `.git`, `node_modules`, `.next`, `__pycache__`, and `*.pyc` are excluded.

## The six parts

| # | Document | Covers |
|---|----------|--------|
| 1 | [01-firmware.md](01-firmware.md) | The `Smart-Tutor-Lamp` repo (firmware branch): the `tutor_lamp/` main sketch (audio DSP, display/UI, networking, camera, buttons, settings), the `Wake word/` inference sketch, the bring-up rigs (`camera_test/`, `ei_data_collector/`, `mic_recorder/`, `push_buttons/`, `tft_latex_client/`, `wifi_audio_player/`), and root design docs. |
| 2 | [02-backend.md](02-backend.md) | The `Smart-Tutor-Lamp-backend` repo (FastAPI): the full `app/` package (`db`, `deps`, `formatting`, `prompts`, `providers`, `routes`, `schemas`, `services`, `storage`, `workers`), plus `audio-tts/`, `scripts/`, `tests/`, `temp_server_files/`, and every root doc/config/run-artifact. |
| 3 | [03-frontend.md](03-frontend.md) | The `Smart-Tutor-frontend` repo (Next.js App Router): every route segment under `app/`, `components/app/`, `components/landing/`, `lib/`, `types/`, and root config. |
| 4 | [04-web-simulator.md](04-web-simulator.md) | The cross-cutting web simulator: backend `web_simulator.py` + the route that serves it, the frontend `/simulator` page + `useSimulatorCapture.ts`, and the lamp-/backend-simulator helper scripts. |
| 5 | [05-database.md](05-database.md) | The Supabase / Postgres + pgvector layer: `app/db/` (models + session), `app/storage/` (the repository modules and the tables they own), the SQL/setup files, and DB config. |
| 6 | [06-system-prompt.md](06-system-prompt.md) | The LLM system-prompt files: `app/prompts/` (active + `_unused/` legacy), `system_prompt_arch.md`, and where prompts are assembled at runtime — for both the web and lamp paths. |

## Where to find X

- **"What is this file?"** → open the part for that area and look up the file in its folder table.
- **"What does this folder do?"** → the "Folder map" overview table at the top of each part.
- **"How does it actually work?"** → the deep docs one level up (`../01-firmware/` … `../06-git-history/`).
- **"Which model / prompt does the web vs lamp use?"** → part 6 here, and the deep dive in [`../system-prompt-web-and-lamp/`](../system-prompt-web-and-lamp/).
