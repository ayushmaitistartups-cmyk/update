# Database — Folder & File Catalog

The Smart Tutor Lamp ("Lumos") database is **PostgreSQL hosted on Supabase**, accessed asynchronously from the backend via **SQLAlchemy 2.x + asyncpg** (`postgresql+asyncpg://…`). It relies on three Supabase/Postgres extensions: **pgvector** (`vector(1536)` ANN for the deferred long-term memory table), **pgcrypto** (`gen_random_uuid()`), and `pg_stat_statements` (query analytics). The schema is defined entirely as ORM models in `app/db/models.py` (**24 mapped tables** as of the 2026-07-03 refresh, up from 16) and brought online lazily by `app/db/session.py`.

> **Updated 2026-07-03:** eight new tables were added since the 2026-06-16 sync — five pilot-instrumentation tables written by the new `app/storage/pilot.py` (`turn_feedback`, `survey_responses`, `problem_reports`, `user_consents`, `student_personalization`), two offline analytics-tagging tables plus a controlled vocabulary written by the new workers `app/workers/topic_tag.py` / `mistake_tag.py` (`syllabus_topics`, `turn_topics`, `turn_mistakes`), and one OTA table written by `app/services/ota_release.py` (`firmware_releases`). All follow the house style and are auto-created by `create_all`.

There is **intentionally NO `users` table** — Clerk owns human identity. Every row instead carries the Clerk `user_id` *string* (`user_2abc…`), denormalized onto child tables so per-user reads are a single index hop with no join. The database is **optional at boot**: it activates only when `DATABASE_URL` is set, and the whole app degrades cleanly to stateless when it is absent. There are also no DB-level FOREIGN KEYs in the ORM — joins are by id in code.

All database-related code/docs live in the backend repo `D:/clartiy/Smart-Tutor-Lamp-backend`.

---

## Folder/Files map

| Location | Role | Key contents |
|---|---|---|
| `app/db/` | Schema + connection | `models.py` (all table definitions), `session.py` (async engine/session), `migrations/.keep` (Alembic placeholder), `__init__.py` (empty) |
| `app/storage/` | Repository layer | one module per table cluster: `turns.py`, `events.py`, `user_memory.py`, `user_profiles.py`, `model_eval.py`, **`pilot.py`** (pilot-instrumentation cluster), plus `blobs.py` (object storage URLs), `memory_vec.py` (deferred pgvector), `dev_capture.py` (local debug dumps) |
| `app/workers/`, `app/services/ota_release.py` | Other writers | `topic_tag.py` / `mistake_tag.py` workers write `turn_topics` / `turn_mistakes` (offline, via `topic_tagger` / `mistake_tagger`); `ota_release.py` writes `firmware_releases`; `syllabus_topics` is seeded reference data |
| `scripts/admin_setup.sql` | One-shot setup SQL | creates + RLS-locks the `admins` table, seeds first admin |
| `SUPABASE_SETUP.md` (root) | Setup guide | provision Supabase, full schema, extensions, Alembic, scaling |
| `SUPABASE_QUERIES.md` (root) | SQL cookbook | copy-paste debug/analytics queries for the SQL Editor |
| `app/config.py` | DB configuration | `DATABASE_URL`, `DATABASE_SSL`, storage/blob + memory env vars |

---

## Folder: `app/db/`

**Purpose:** owns ONLY the database schema and the connection surface. It defines what the tables are (`models.py`) and how the process talks to Postgres (`session.py`). The code that actually *writes* these tables lives one layer up in `app/storage/*` (and `app/services/*`).

| File | Type | Purpose |
|---|---|---|
| `__init__.py` | Python (empty, 0 bytes) | namespace package marker only |
| `models.py` | SQLAlchemy ORM models — **this IS the schema** | Defines the shared `Base(DeclarativeBase)` and all 24 mapped tables. Imports Postgres-dialect column types (`ARRAY`, `JSONB`, `UUID`) so the schema is Postgres-specific (partial indexes via `postgresql_where`, `text[]`, JSONB). Conventions: UUID PKs on append-heavy tables, natural string PKs on lookup tables, `timestamptz` everywhere, `server_default=func.now()`, JSONB `extra`/`payload` escape-hatch columns, denormalized `user_id`, partial indexes, no DB FOREIGN KEYs. |
| `session.py` | Connection / engine module | The entire connection surface (~160 lines). Holds the process-wide async engine + session factory as lazy module singletons. |
| `migrations/.keep` | Empty placeholder | Reserves the Alembic migrations dir. **Alembic is NOT initialized** — documented as the intended prod path but not yet wired; dev relies on `create_all`. |

### Tables defined in `models.py` (24 ORM models)

| Model (class) | `__tablename__` | PK | What it stores |
|---|---|---|---|
| `Device` | `devices` | `device_id` (str) | One row per physical lamp — the authoritative auth table (secret hash, paired Clerk `user_id`, `revoked_at`). Partial idx `devices_user_idx`. |
| `PairingCode` | `pairing_codes` | `code` (str) | Short-lived (5-min) single-use QR pairing bridge. CHECK on `status IN ('pending','paired','expired')`. |
| `UserProfile` | `user_profiles` | `user_id` (Clerk str) | Web-onboarding self-declared profile (name, phone, target exam JEE/NEET/CAT/UPSC, prep duration). CHECK on exam; partial exam index. |
| `SessionRecord` | `sessions` | `id` (UUID) | One contiguous interaction window per lamp; resume/compaction columns. Indexes for device, user, and reconnect-resume. |
| `TurnRecord` | `turns` | `id` (UUID) | Most-written table — one completed turn (question→reply): transcript, speech, LaTeX, classification, provider/telemetry, cost, escalation (`final_tier`, `escalation_path` as `text[]`). |
| `TurnTrace` | `turn_traces` | `id` (UUID) | Verbose per-turn pipeline audit trace (per-phase latencies, media URLs, raw prompt/response, OCR text, bounding box, `phases` storyboard). Written for FAILED turns too. The 3 additive columns live here. |
| `UserMemory` | `user_memory` | `id` (UUID) | Cross-session learner profile, one row per device (unique `device_id`), DERIVED from turns. |
| `Event` | `events` | `id` (UUID) | Generic lifecycle/audit log (`kind` + JSONB `payload`): pairing, ws_open/close, reboots, button. |
| `CostLog` | `cost_log` | `id` (UUID) | Optional per-API-call cost ledger (LLM+TTS+STT fan-out). |
| `Admin` | `admins` | `user_id` (Clerk str) | Dashboard admin allowlist — durable source of truth for `/admin` access. Partial email index. |
| `ModelProvider` | `model_providers` | `id` (UUID), `model_name` unique | Bench registry of comparable models + list pricing, seeded from the in-code catalog. |
| `ModelRequest` | `model_requests` | `request_id` (UUID) | One question submitted to the model-comparison bench (single or compare group). |
| `ModelResponse` | `model_responses` | `response_id` (UUID) | One model's answer (latency, tokens, cost, success/status). Failure rows KEPT. |
| `ModelFeedback` | `model_feedback` | `id` (UUID) | Learner's rating of a response (thumbs / 1–5 stars / text). UNIQUE `(response_id, user_id)` → UPSERT. CHECK on thumbs + rating. |
| `TurnFeedback` | `turn_feedback` | `id` (UUID) | **(new)** Learner's verdict on ONE real `turns` answer (pilot F1) — thumbs + down-vote `reason` chip + `resolution` (`got_it`/`still_stuck`/`explain_differently`) + optional 1–5 rating/text. UNIQUE `(turn_id, user_id)` → UPSERT. Distinct from `model_feedback` (which rates a web-bench `model_responses` row). |
| `SurveyResponse` | `survey_responses` | `id` (UUID) | **(new)** One pilot survey (F2) — `survey_kind` CHECK `('baseline','exit','weekly')`, answers in JSONB so the questionnaire can evolve with no migration. Append-only. |
| `ProblemReport` | `problem_reports` | `id` (UUID) | **(new)** One-tap "something's wrong" report (F5) — `category`, `message`, JSONB `context`, `status` CHECK `('open','triaged','resolved')` driving an admin triage queue. |
| `UserConsent` | `user_consents` | `id` (UUID) | **(new)** Immutable pilot/parental-consent audit log (F7) — one append-only row per grant/withdrawal event with policy `version`. |
| `StudentPersonalization` | `student_personalization` | `user_id` (Clerk str) | **(new)** Per-student personalization profile (interests, `answer_length`, `example_pref`) — COLLECTION ONLY; kept apart from `user_profiles` for a stricter PII boundary. |
| `SyllabusTopic` | `syllabus_topics` | `id` (UUID) | **(new)** Canonical syllabus controlled vocabulary — `exams` as Postgres `text[]`, subject/unit/topic/code. Seeded reference data. |
| `TurnTopic` | `turn_topics` | `id` (UUID) | **(new)** Tagging result linking one turn → one `syllabus_topics` row (or `unmapped`). Written fire-and-forget by the OFFLINE `topic_tag` worker; UNIQUE `turn_id` → UPSERT; `turns` is never touched. |
| `TurnMistake` | `turn_mistakes` | `id` (UUID) | **(new)** Mistake-type classification for one turn (or `none`). Written by the OFFLINE `mistake_tag` worker; UNIQUE `turn_id` → UPSERT. |
| `FirmwareRelease` | `firmware_releases` | `id` (UUID) | **(new)** A published lamp OTA image — the `.bin` stored IN-DB (bytea) and served by the backend itself (`GET /lamp/ota/firmware.bin`). Exactly one row `is_current=True`; old releases pruned to the newest 5. Written by `app/services/ota_release.py`. |
| *(not ORM-mapped)* | `memories` | — | pgvector ANN table (`embedding vector(1536)`) — **deferred**, intentionally NOT mapped; future access via raw SQL. DDL documented in `SUPABASE_SETUP.md`. |

> First two model groups note: `Base` is the shared declarative base every model subclasses, so `Base.metadata.create_all` / Alembic autogen see one schema.

### Key logic in `session.py`

- **Lazy engine**: `_engine` / `_session_factory` stay `None` until `init_db()` runs from the FastAPI lifespan — so dev mode boots without even installing asyncpg. `get_engine()` / `get_session_factory()` raise `RuntimeError` if used before init.
- **`_ssl_connect_args(url)`**: AUTO TLS — forces `ssl=require` for `*.supabase.co` / `*.supabase.com` hosts, off for localhost; overridable via `DATABASE_SSL`.
- **`init_db(create_tables=True)`**: builds the engine (`pool_size=10`, `max_overflow=10`, `pool_pre_ping=True`, `pool_recycle=1800`, `expire_on_commit=False`), then runs `Base.metadata.create_all` (creates MISSING tables only, never ALTERs).
- **`_ADDITIVE_COLUMNS` + `_ensure_additive_columns()`**: idempotent `ALTER TABLE … ADD COLUMN IF NOT EXISTS` shim for columns added after a table first shipped (the three `turn_traces` columns `llm_raw_system_prompt`, `extracted_ocr_text`, `bounding_box`). Best-effort per-column.
- **`get_db()`**: FastAPI dependency yielding one async session per request; logs + rolls back on exception, does NOT auto-commit.
- **`dispose_db()`**: tears down the pool and resets the singletons.

---

## Folder: `app/storage/`

**Purpose:** the **repository layer** — off-hot-path persistence that runs fire-and-forget (`asyncio.create_task` from the orchestrator) and NEVER blocks a response. Each module owns one table (or table cluster) and follows the house contract: **DB-availability-gated** (no-op when the engine isn't initialised → `_session_factory()` returns `None` instead of raising) and **crash-safe** (every DB error logged + swallowed).

| File | Type | DB table(s) owned/managed | Purpose |
|---|---|---|---|
| `__init__.py` | Package doc | — | Explains the package boundary vs `app.db` / `app.services.memory`; lists the Layer-9 responsibilities. |
| `turns.py` | Repository | **`sessions`** + **`turns`** | The core conversation writer. `open_session` (resume-or-open with 30-min idle window, `IS NOT DISTINCT FROM` user match), `close_session`, `write_turn` (atomic `turn_count` bump + INSERT; skips non-ok turns), `load_recent_turns` (builds the LLM history block, scoped to session or device+user). |
| `events.py` | Repository | **`events`** | `log_event` (fire-and-forget INSERT of a lifecycle event) and `recent_events` (read latest events for a device). |
| `user_memory.py` | Repository | **`user_memory`** | `get_user_memory` and `upsert_user_memory` — the per-device cross-session learner profile (caller passes the `AsyncSession`). |
| `user_profiles.py` | Repository | **`user_profiles`** | `get_profile` and `upsert_profile` — the web onboarding profile keyed by Clerk `user_id`, via Postgres `INSERT … ON CONFLICT DO UPDATE` with JSONB merge. |
| `model_eval.py` | Repository | **`model_requests`**, **`model_responses`**, **`model_feedback`**, **`model_providers`** | The model-comparison bench writer cluster: `record_request`, `record_response` (keeps failures), `record_feedback` (UPSERT on `(response_id,user_id)`), and `seed_providers` (best-effort upsert of the in-code catalog into `model_providers` at startup). |
| `pilot.py` | Repository **(new)** | **`turn_feedback`**, **`survey_responses`**, **`problem_reports`**, **`user_consents`**, **`student_personalization`** | The pilot-instrumentation writer cluster (F1/F2/F5/F7 + personalization): `record_turn_feedback` (UPSERT, validates the target turn exists), `feedback_for_turns`, `submit_survey` + `survey_status`, `record_problem_report`, `upsert_personalization` + `get_personalization`, `record_consent`. Same DB-gated, crash-safe, fire-and-forget discipline as `model_eval.py`; deliberately off the live turn path. |
| `memory_vec.py` | Repository (stub) | **`memories`** (deferred pgvector) | Layer-3.3 long-term vector memory. `insert_memory` / `fetch_relevant` currently `raise NotImplementedError` — deferred per BACKEND_TODO; documents the pgvector schema + ivfflat index for when it ships. |
| `blobs.py` | Object-storage helper | none directly — produces the URLs stored in **`turns.image_url` / `turns.audio_url`** (and `turn_traces.*_url`) | Uploads per-turn audio (PCM→WAV) + image (JPEG) to a backend chosen by `STORAGE_BACKEND` (`off` / `local` / `s3` / `r2`, via aioboto3). Also `delete_keys` (manual admin cleanup) and `key_from_url`. Every path best-effort → returns `None`/NULL on failure. |
| `dev_capture.py` | Local debug helper | no DB | Dev-only per-turn capture dump to `DEV_CAPTURE_DIR` (raw/enhanced images, audio, LlmReply JSON), gated by `DEV_CAPTURE_DUMP`. Throwaway debug mirror, distinct from the durable `blobs.py` path; never runs in prod. |

---

## SQL & setup files

| File | Type | Purpose |
|---|---|---|
| `scripts/admin_setup.sql` | One-shot SQL (run once in Supabase SQL Editor) | Creates the `admins` allowlist table + `admins_email_idx`, **enables RLS with no policy** (deny-all to anon/authenticated; defense-in-depth so the table is never world-readable via PostgREST), and seeds the first admin. OPTIONAL — the backend also auto-creates `admins` via `create_all` and auto-seeds from the env allowlist; this file's value is turning on RLS (which `create_all` does not) and SQL-only seeding. |
| `SUPABASE_SETUP.md` | Markdown setup guide | The single consolidated DB reference. Step-by-step: create a Supabase project → connection string (direct port 5432, not the 6543 pooler) → required extensions (`vector`, `pgcrypto`, `pg_stat_statements`) → **full schema** (durable + analytics + scalable DDL, incl. the `memories` pgvector table) → RLS → Alembic migrations → backend wiring → analytics queries → production scaling. |
| `SUPABASE_QUERIES.md` | Markdown SQL cookbook | Copy-paste debug/analytics queries for the Supabase SQL Editor (runs as a privileged role / service_role → sees all rows past RLS). Covers the Clerk identity model, logins/pairing, sessions, stored conversations, memory, cost, events, integrity checks, and the standalone `admins` + RLS SQL. |

---

## DB configuration

DB-related entries in `app/config.py` (the pydantic `Settings`), with the env var name = the field name:

| Env var / setting | Default | Purpose |
|---|---|---|
| `DATABASE_URL` | `""` | The Postgres connection string (`postgresql+asyncpg://…`). **Empty = DB off** (app runs stateless); required when `ENABLE_AUTH=True`. This single var switches the whole persistence layer on/off. |
| `DATABASE_SSL` | `""` (AUTO) | asyncpg SSL mode. AUTO → `require` TLS for Supabase hosts (`*.supabase.co` / `*.pooler.supabase.com`), off for local Postgres. Override with a libpq sslmode (`disable`/`prefer`/`require`/`verify-ca`/`verify-full`). Supabase rejects non-TLS, so AUTO is what makes a Supabase URL actually connect. |
| `STORAGE_BACKEND` | `"local"` | Where per-turn blobs go (`off` / `local` / `s3` / `r2`); decides whether `turns.image_url` / `turns.audio_url` get real URLs. Used by `app/storage/blobs.py`. |
| `STORAGE_LOCAL_DIR` | `"./turn_blobs"` | Host filesystem dir for `STORAGE_BACKEND=local` writes. |
| `STORAGE_PUBLIC_BASE_URL` | `""` | Optional public URL prefix mapped onto the local dir / bucket to build browser-fetchable blob URLs; empty → local writes return a `file://` URL. |
| `S3_BUCKET` / `S3_REGION` / `S3_ENDPOINT_URL` / `S3_ACCESS_KEY` / `S3_SECRET_KEY` | `""` | S3-compatible object store config for `STORAGE_BACKEND=s3/r2` (Supabase Storage / Cloudflare R2 / MinIO). `S3_ENDPOINT_URL` empty = AWS default. |
| `MEMORY_SESSION_IDLE_MIN` | `30` | Idle gap (minutes) before a reconnect/next-turn starts a fresh `sessions` row instead of resuming (drives the `turns.py` resume query). |
| `DEV_CAPTURE_DUMP` / `DEV_CAPTURE_DIR` | `False` / `"./turn_captures"` | Toggle + target dir for the dev-only per-turn capture dump (`app/storage/dev_capture.py`). Not a durable-DB path. |
| `TURN_TRACE_ENABLED` | `True` | Whether each turn also writes a `turn_traces` row (needs `DATABASE_URL` to persist). |
| `REDIS_URL` | `""` | Optional read-accelerator in front of Postgres (session-id + history cache). Empty = Supabase-only; Postgres remains the source of truth either way. |

> Related toggles: `ENABLE_AUTH` (requires `DATABASE_URL` when true), `ENABLE_MEMORY` / `MEMORY_COMPACT_THRESHOLD` / `MEMORY_TAIL_SIZE` / `ENABLE_MEMORY_COMPACTION` (the session-memory layer that writes `sessions`/`turns`/`user_memory`).
