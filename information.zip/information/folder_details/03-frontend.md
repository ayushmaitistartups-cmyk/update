# Frontend — Folder & File Catalog

The **Smart Tutor Lamp ("Lumos") web frontend** is a **Next.js 14 (App Router) + TypeScript + Tailwind CSS + Clerk** dashboard. It is the human-facing surface of the system: users sign in via Clerk (email or Google OAuth), complete a forced 7-question onboarding profile, view a dashboard / analytics, pair their physical ESP32 lamp with an in-browser QR scanner, and exercise the AI brain through a web simulator. All backend data flows through one authenticated **TanStack React Query** layer that attaches the Clerk session JWT to every call to the unified Python FastAPI backend ("Frontend Manager"). A hard architectural boundary holds throughout: the frontend **only ever handles human sessions** — never device secrets or device JWTs.

> **Scope note.** `node_modules/`, `.next/`, and `.git/` are build/dependency/VCS artifacts and are **excluded** from this catalog. Two items belong to the web simulator and are also cataloged in `04-web-simulator.md`; they are listed here and marked **(web simulator)**: `app/simulator/page.tsx` and `lib/useSimulatorCapture.ts`.

Repo root: `D:/clartiy/Smart-Tutor-frontend` (git branch `main`).

> **Status note (2026-07-06).**
> The local working copy at `D:/clartiy/Smart-Tutor-frontend/` was briefly removed from disk earlier today and has been **restored** by re-cloning the remote (tip unchanged at `ef07d7f`, 2026-07-02 — exactly the tree this catalog describes). All files below exist locally again.

> **Updated 2026-07-03** (tip `ef07d7f`). Cataloged since the 2026-06-16 sync (`5ac12b8`): a **pilot-program surface** — new routes `app/survey/` and `app/personalize/`; new components `SurveyView`, `PersonalizationView`, `PersonalizeCard`, `ReportProblem` (global widget); new lib `lib/pilot.ts`; a **perceived-latency pass** — `PageSkeleton` + a `loading.tsx` in every authed route segment; a large **admin console expansion** (Pilot / Insights / firmware-OTA tabs and a performance card in `AdminView`, with matching hooks in `lib/admin.ts`); and a new repo-root writeup `OPTIMIZATION.md`.

---

## Folder map overview

| Folder | Purpose | Primary file types |
| --- | --- | --- |
| `/` (repo root) | Project config, middleware, run docs | `.json`, `.ts`, `.js`, `.md`, `.d.ts`, dotfiles |
| `app/` | Next.js App Router root: root layout, global providers, landing page, route segments | `.tsx`, `.ts`, `.css` |
| `app/admin/` | Admin route — system-wide insights, gated to allowlisted admins | `page.tsx` |
| `app/analytics/` | Per-user rich analytics route | `page.tsx` |
| `app/connect/` | "Connect a lamp" — QR scanner entry point | `page.tsx` |
| `app/dashboard/` | Authenticated landing dashboard | `page.tsx` |
| `app/devices/` | "Your lamps" — list / rename / unlink paired devices | `page.tsx` |
| `app/onboarding/` | Forced 7-question learner profile (page + form + server action) | `page.tsx`, `.tsx`, `actions.ts` |
| `app/pair/` | Bare `/pair` redirect to `/devices` | `page.tsx` |
| `app/pair/[code]/` | Pairing confirmation for a scanned code | `page.tsx` |
| `app/personalize/` | Pilot "how I learn best" preference capture (collection-only) | `page.tsx`, `loading.tsx` |
| `app/survey/` | Pilot baseline/exit survey (`?kind=baseline\|exit`) | `page.tsx` |
| `app/sign-in/[[...sign-in]]/` | Clerk sign-in catch-all (+ OAuth SSO callback) | `page.tsx` |
| `app/sign-up/[[...sign-up]]/` | Clerk sign-up catch-all (+ OAuth SSO callback) | `page.tsx` |
| `app/simulator/` | Web simulator test bench **(web simulator)** | `page.tsx` |
| `components/app/` | Authenticated dashboard React components (header, charts, dialogs, scanner, admin/analytics views) | `.tsx` |
| `components/landing/` | Marketing landing-page components + Framer-Motion primitives | `.tsx` |
| `lib/` | Data/API layer: authenticated HTTP client, typed React-Query hooks, server gates, pure helpers | `.ts` |
| `types/` | Ambient TypeScript module declarations | `.d.ts` |

---

## Folder: `/` (repo root)

**Purpose:** Project-level configuration, Clerk route-protection middleware, and operator documentation.
**File types:** `.json` (package/lock), `.ts` (middleware, tailwind), `.js` (postcss), `.md` (run docs), `.d.ts` (Next env), dotfiles, build cache.

| File | Type | Purpose |
| --- | --- | --- |
| `package.json` | npm manifest | Declares the app (`smart-tutor-lamp-web`), scripts (`dev`, `dev:turbo`, `build`, `start`, `lint`), and dependencies: `@clerk/nextjs`, `@tanstack/react-query`, `framer-motion`, `jsqr`, `katex` + `react-katex`, `lucide-react`, `next 14.2.35`, `react 18`; devDeps include TypeScript, Tailwind, PostCSS, autoprefixer. |
| `package-lock.json` | npm lockfile | Pinned full dependency tree for reproducible installs. |
| `tsconfig.json` | TS config | Strict TypeScript; `target es5`, `module esnext`, `moduleResolution bundler`, `jsx preserve`, `noEmit`, `next` plugin, and the `@/*` → `./*` path alias used throughout imports. |
| `tailwind.config.ts` | Tailwind config | `darkMode: "class"`; content globs for `app/`, `components/`, `lib/`; extends fonts (`display`/`sans`/`mono` via CSS vars) and the Lumos palette (`void`, `paper`, `amber{,soft,deep}`, `cyan`, `violet`, `rose`). |
| `postcss.config.js` | PostCSS config | Enables the `tailwindcss` and `autoprefixer` plugins. |
| `middleware.ts` | Next.js middleware | Clerk `clerkMiddleware` + `createRouteMatcher`. Protects `/dashboard`, `/analytics`, `/devices`, `/pair`, `/connect`, `/onboarding`, `/simulator`, `/admin` (requires signed-in human session via `auth().protect()`). Onboarding-completion and admin-role gates live in the pages/`lib/auth-guard.ts`. |
| `next-env.d.ts` | TS ambient decl | Auto-generated Next.js type references (`next`, `next/image-types`); not edited. |
| `types/react-katex.d.ts` | TS ambient decl | (in `types/`) declares the `react-katex` module surface (`InlineMath`, `BlockMath`) since the package doesn't expose its `.d.ts`. |
| `tsconfig.tsbuildinfo` | Build cache | TypeScript incremental build info (generated artifact). |
| `RUN.md` | Docs | How to run the frontend: prerequisites (Node ≥18.17), env vars, `npm` commands, the `/simulator` multi-image flow, and the `/admin` allowlist note. |
| `OPTIMIZATION.md` | Docs | **(added 2026-07-03)** Performance/optimization audit of the web app + backend: perceived-lag causes, resource leaks, conversion/UX, and backend latency, each cited `file:line`. Documents the 2026-07-02 "Applied" fixes (route `loading.tsx` skeletons, concurrent admin gate, simulator/QR camera-mic leak fixes, double-send guard) and the still-open items. |
| `.gitignore` | Git config | Ignores media files (`*.mp3/jpg/png/wav`), `.env*`, `node_modules`, `.next/`, `*.tsbuildinfo`, Python caches. |

---

## Folder: `app/`

**Purpose:** App Router root. Holds the root HTML layout, global client providers, global styles, the public landing page, and one subfolder per route segment.
**File types:** `.tsx` (layout, pages, providers), `.css` (global styles).

| File | Type | Purpose |
| --- | --- | --- |
| `app/layout.tsx` | Root layout (server) | Wraps the whole app in `<ClerkProvider>` (sign-in/up URLs, post-sign-up → `/onboarding`, post-sign-in → `/dashboard`, dark "luminous nocturne" Clerk theme overrides). Loads Google fonts (Fraunces/Hanken Grotesk/JetBrains Mono) into CSS vars, sets page metadata, mounts `<Providers>`. |
| `app/providers.tsx` | Global client providers | Builds the singleton TanStack `QueryClient` with verbose lifecycle instrumentation (fetch start/retry/success timing, in-flight burst counter, mutation logging), default options (`retry: 1`, `staleTime 10s`, no refetch-on-focus). Mounts `<BootDiagnostics/>` and provides the client to the tree. |
| `app/globals.css` | Global styles | Tailwind layers + the Lumos design system: CSS color vars, glass/aurora/glow utilities, `.rise`/`.label`/`.btn-*`/`.tile`/`.input` component classes, animations. |
| `app/page.tsx` | Landing page (server) | Public marketing home; composes `Nav`, `Hero`, `Features`, `Exams`, `CTA`, `Footer` from `components/landing/`. |

### Folder: `app/admin/`
**Purpose:** Admin route — system-wide insights restricted to allowlisted admins. **File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `app/admin/page.tsx` | Route page (server) | `force-dynamic`; gated by the single concurrent `requireOnboardedAndAdmin()` (bounces non-admins to `/dashboard`; Updated 2026-07-03, was `requireOnboarded()` + `requireAdmin()`). Renders `AppHeader` + `AdminView` (which fetches `/api/frontend/admin/*` client-side). |
| `app/admin/loading.tsx` | Route loading UI | Renders `<PageSkeleton active="/admin">` as the App Router Suspense fallback (Updated 2026-07-03). |

### Folder: `app/analytics/`
**Purpose:** Per-user rich analytics. **File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `app/analytics/page.tsx` | Route page (server) | `force-dynamic`; gated by `requireOnboarded()`. Renders `AppHeader` + `AnalyticsView` (data fetched client-side). |
| `app/analytics/loading.tsx` | Route loading UI | `<PageSkeleton active="/analytics">` Suspense fallback (Updated 2026-07-03). |

### Folder: `app/connect/`
**Purpose:** "Connect a lamp" entry point for QR pairing. **File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `app/connect/page.tsx` | Route page (client) | Renders the `QrScanner`; on a successful decode pushes to `/pair/[code]` (URL-encoded). Shows the scan instructions and `AppHeader` (active `/devices`). |
| `app/connect/loading.tsx` | Route loading UI | `<PageSkeleton active="/connect">` Suspense fallback (Updated 2026-07-03). |

### Folder: `app/dashboard/`
**Purpose:** Authenticated landing dashboard. **File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `app/dashboard/page.tsx` | Route page (server) | `force-dynamic`; `requireOnboarded()` returns the durable profile used to greet the user and show profile-glance tiles (target exam, prep, focus). Includes a "Connect your lamp" CTA, the `PersonalizeCard` (Updated 2026-07-03), the live `AnalyticsCards`, and a "Brain console — coming soon" teaser. |
| `app/dashboard/loading.tsx` | Route loading UI | `<PageSkeleton active="/dashboard">` Suspense fallback (Updated 2026-07-03). |

### Folder: `app/devices/`
**Purpose:** "Your lamps" — manage paired devices. **File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `app/devices/page.tsx` | Route page (client) | Lists devices via `useDevices` with inline rename (`useRenameDevice`), unlink-with-confirm (`useUnlinkDevice` + `ConfirmDialog`), online status dots, "last seen" labels (`formatAgo`), skeleton/empty/error states, and an "Add a new lamp" guide linking to `/connect`. |
| `app/devices/loading.tsx` | Route loading UI | `<PageSkeleton active="/devices">` Suspense fallback (Updated 2026-07-03). |

### Folder: `app/onboarding/`
**Purpose:** Forced 7-question learner profile capture (page shell + client form + server action). **File types:** `.tsx`, `.ts`.

| File | Type | Purpose |
| --- | --- | --- |
| `app/onboarding/page.tsx` | Route page (server) | `force-dynamic`. Gates on Clerk `userId`; runs `getBackendProfile()` + `currentUser()` concurrently. If a durable profile already exists → redirect `/dashboard`; otherwise renders `OnboardingForm` (prefilled with the OAuth name). "missing"/"unreachable" both fall through to the form so no user is stranded. |
| `app/onboarding/OnboardingForm.tsx` | Client component | The form, driven by `useFormState(completeOnboarding)`. Renders the name field + the 6 radio-group questions from `ONBOARDING_QUESTIONS`; shows server-side validation/save errors; the server action handles navigation (no client redirect race). |
| `app/onboarding/actions.ts` | Server action (`"use server"`) | `completeOnboarding`: validates all 7 fields against `lib/onboarding` guards, resolves the user's email, `PUT`s the profile to `/api/frontend/profile` (durable source of truth, 8s timeout), best-effort mirrors metadata into Clerk `publicMetadata`, then `redirect("/dashboard")`. |

### Folder: `app/pair/`
**Purpose:** Pairing routes. **File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `app/pair/page.tsx` | Route page (server) | Bare `/pair` has no standalone meaning; immediately `redirect("/devices")`. |

### Folder: `app/pair/[code]/`
**Purpose:** Pairing confirmation for a specific scanned code. **File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `app/pair/[code]/page.tsx` | Dynamic route page (client) | Decodes the `code` param, looks it up via `usePairingInfo`, shows the device + a live expiry countdown (`formatCountdown`), and confirms with `useCompletePairing` — linking the lamp to the signed-in account, then redirecting to `/devices`. Errors render via `ErrorPanel` (`friendlyByCode`/`friendlyError`). |

### Folder: `app/personalize/` (added 2026-07-03)
**Purpose:** Pilot "how I learn best" preference capture. **File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `app/personalize/page.tsx` | Route page (server) | `force-dynamic`; gated by `requireOnboarded()`. Renders `AppHeader` (active `/personalize`) + `PersonalizationView`. Collection-only — preferences are saved to the pilot profile, not (yet) wired into the tutor prompt. |
| `app/personalize/loading.tsx` | Route loading UI | `<PageSkeleton active="/personalize">` Suspense fallback. |

### Folder: `app/survey/` (added 2026-07-03)
**Purpose:** Pilot baseline/exit self-report survey. **File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `app/survey/page.tsx` | Route page (server) | `force-dynamic`; gated by `requireOnboarded()`. Reads `searchParams.kind` (`exit` else `baseline`) and renders `AppHeader` (active `/survey`) + `SurveyView kind={...}`. The matched before/after instrument; baseline also records pilot consent. |

### Folder: `app/sign-in/[[...sign-in]]/`
**Purpose:** Clerk sign-in (catch-all also serves the OAuth SSO callback). **File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `app/sign-in/[[...sign-in]]/page.tsx` | Route page (server) | `force-dynamic`; renders Clerk `<SignIn>` (path routing) with explicit redirect targets: existing user → `/dashboard`, first-time OAuth → `/onboarding`. |

### Folder: `app/sign-up/[[...sign-up]]/`
**Purpose:** Clerk sign-up (catch-all also serves the OAuth SSO callback). **File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `app/sign-up/[[...sign-up]]/page.tsx` | Route page (server) | `force-dynamic`; renders Clerk `<SignUp>` (path routing) forcing new accounts (incl. Google OAuth) into `/onboarding`. |

### Folder: `app/simulator/`
**Purpose:** Web simulator test bench mirroring the lamp's multimodal payload. **File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `app/simulator/page.tsx` | Route page (client) **(web simulator)** | The brain test bench: push-to-talk mic + optional text + a multi-image queue (webcam/upload), model picker (`useModels`), single/compare "solve" calls, KaTeX-rendered output, and a `JourneyBreakdown` latency waterfall. Cataloged in detail in `04-web-simulator.md`. (Updated 2026-07-03: unmount preview-URL cleanup via a ref + a synchronous double-send guard.) |
| `app/simulator/loading.tsx` | Route loading UI | `<PageSkeleton active="/simulator">` Suspense fallback (Updated 2026-07-03). |

---

## Folder: `components/app/`

**Purpose:** React components for the authenticated dashboard surface — header/nav, the analytics & admin view bodies, hand-built SVG charts, pairing scanner, dialogs, error/diagnostics panels, the shared journey waterfall, the pilot self-report/feedback UIs (`SurveyView`, `PersonalizationView`, `PersonalizeCard`, `ReportProblem`), and the shared route-loading `PageSkeleton`.
**File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `AdminView.tsx` | Client component | Admin dashboard body (~1842 lines, Updated 2026-07-03): **ten** tabbed system-wide panels — Overview (health/cost/daily/**performance**), **Pilot** (funnel/feedback/surveys/reports by cohort), **Insights** (engagement/coverage/quality/mistakes/topic-strength), Models, Users, Devices, Sessions, Turns, Events, and **OTA** (firmware publish + release history) — fetched from `/api/frontend/admin/*` via `lib/admin.ts`; opens `TraceView` per turn. 403 surfaces as a quiet access notice. |
| `AnalyticsCards.tsx` | Client component | Live per-user rollup (`useAnalytics`) for the dashboard — device/turn counts; loading shimmer and graceful outage notice. |
| `AnalyticsView.tsx` | Client component | The `/analytics` page body: fetches the rich rollup (`useAnalyticsDetail`) and renders glass metric cards + SVG charts (trend, donuts, segmented bars). Updated 2026-07-03: each recent-turn row carries an inline `TurnFeedbackControl` (👍/👎 + resolution, pilot F1). |
| `AppHeader.tsx` | Client component | Top nav: links to Dashboard/Analytics/Devices/Simulator, Clerk `UserButton` (+ Personalize link), and an Admin link shown only when `useMe()` reports `is_admin`. Updated 2026-07-03: also mounts the global `ReportProblem` widget. |
| `BootDiagnostics.tsx` | Client component | App-wide timing probe (mounted once in `Providers`): Navigation Timing breakdown, LCP, long-task and route-change timing with LAG warnings via `lib/log`. |
| `ConfirmDialog.tsx` | Client component | Accessible confirm modal (Escape/click-outside cancel, focus trap, busy state, destructive styling) used for the device Unlink action. |
| `ErrorPanel.tsx` | Client component | Shared error surface for the pairing flow: shows a mapped `FriendlyError` message + suggested action; renders a retry button for transient (network/unknown) failures. |
| `JourneyBreakdown.tsx` | Client component | Shared input→output waterfall for one answer (timed steps + tokens + cost); reused by the simulator (live) and the admin Turns log (persisted). Consumes `TimelineStep` from `lib/models`. |
| `PageSkeleton.tsx` | Client component | **(added 2026-07-03)** Shared route-loading skeleton (`{ active? }`): real `AppHeader` + `animate-pulse` glass placeholder grid. Rendered by every `app/*/loading.tsx` to give the App Router an instant Suspense boundary (ties to `OPTIMIZATION.md §2.1`). |
| `PersonalizationView.tsx` | Client component | **(added 2026-07-03)** The `/personalize` form body: interest chip-picker (+ custom), answer-length choice, real-life-example preference, notes. Seeds from `usePersonalization`, saves via `useSavePersonalization`. Collection-only. |
| `PersonalizeCard.tsx` | Client component | **(added 2026-07-03)** Dashboard CTA to `/personalize`; smart state via `usePersonalization` — amber nudge while empty, quiet cyan "saved — edit" once filled. |
| `QrScanner.tsx` | Client component | In-app QR scanner with three inputs: live camera (`getUserMedia` + `jsQR` per frame), photo upload, or typed code. Extracts the code via `extractPairingCode` and calls `onCode`. Updated 2026-07-03: decode throttled to ~10 fps + downscaled to ≤640 px; stream stopped if unmounted mid-permission-prompt. |
| `ReportProblem.tsx` | Client component | **(added 2026-07-03)** Global one-tap problem reporter mounted once in `AppHeader`: fixed bottom-right pill → inline panel (category chips + text), auto-attaches page/time/UA context, posts via `useReportProblem`. Best-effort. |
| `SurveyView.tsx` | Client component | **(added 2026-07-03)** The pilot baseline/exit survey body (`{ kind }`): config-driven question list (shared confidence block + variant questions), consent checkbox on baseline; submits via `lib/pilot`. |
| `TraceView.tsx` | Client component | Admin per-turn pipeline "visual audit" drawer (~580 lines): source badge, question audio, raw vs. enhanced frame, latency waterfall, transcript/answer (KaTeX), escalation reason + raw LLM JSON. Updated 2026-07-03: adds a "first audio" perceived-latency milestone bar and an analytics-tags block (topic/error-type/MCQ/stuck/concepts/problem statement). Data from `useTurnTrace` (`/api/frontend/admin/turns/{id}/trace`). |
| `charts.tsx` | Client module | Self-contained SVG chart primitives (no external chart lib): exports `PALETTE`, `colorFor`, `AreaTimeline`, `Donut`, `BarRows`, `MetricBars`, `SegmentedBar` — all responsive via viewBox, themed to the Lumos palette. |

---

## Folder: `components/landing/`

**Purpose:** Public marketing landing-page sections plus shared Framer-Motion animation primitives and the SVG lamp illustration.
**File types:** `.tsx`.

| File | Type | Purpose |
| --- | --- | --- |
| `Nav.tsx` | Client component | Sticky landing nav; transparent → frosted on scroll; Clerk `SignedIn`/`SignedOut`/`UserButton` aware. |
| `Hero.tsx` | Client component | Hero section with the floating SVG `Lamp`, staggered headline, exam pills, and drifting "doubt" equations in the lamp's beam. |
| `Features.tsx` | Client component | Three-up feature cards (Instant Doubt Solving, Syllabus-Aligned, etc.) with icons and reveal animations. |
| `Exams.tsx` | Client component | Exam-family cards (JEE/NEET/CAT/UPSC) with accent tints, focus subjects, and blurbs. |
| `CTA.tsx` | Client component | Closing call-to-action band with a warm wash + small floating `Lamp` watermark. |
| `Footer.tsx` | Server component | Simple footer: brand mark, tagline, current-year copyright. |
| `Lamp.tsx` | Server component | Stylized anglepoise desk lamp drawn in SVG (metal frame, glowing head, amber light cone); takes an optional `className`. |
| `motion.tsx` | Client module | Framer-Motion primitives shared across landing: `Reveal` (scroll fade+rise), `Float` (gentle hover), and the `stagger`/`riseItem` variants; respects reduced-motion. |

---

## Folder: `lib/`

**Purpose:** The data/API layer every page and component builds on — the single authenticated HTTP client, typed React-Query hooks, server-only route gates, the onboarding contract, and pure helpers.
**File types:** `.ts`.

| File | Type | Purpose |
| --- | --- | --- |
| `api.ts` | Client module | The base authenticated fetch client (`useApi()`): attaches the Clerk session JWT (`Bearer`) via a single-flight `getToken` dedup, shapes errors into `ApiError`, instruments timing/race diagnostics, and exposes `get/post/put/del` + a `ready` flag. `BACKEND_URL` default `http://localhost:8000`. |
| `auth-guard.ts` | Server module | Server-only gates: `getBackendProfile()` (one bounded probe of `/api/frontend/profile` → exists/missing/unreachable), `requireOnboarded()` (bounce signed-out → sign-in, missing → onboarding; degrade on unreachable), and — Updated 2026-07-03 — `getAdminVerdict()` (redirect-free `/api/frontend/me` → admin/not_admin/unknown) + `requireOnboardedAndAdmin()` (runs both probes concurrently via `Promise.all`, replacing the old sequential `requireAdmin()`). |
| `profile.ts` | Client module | Frontend Manager hooks: `useMe`, `useProfile`, `useSaveProfile`, `useAnalytics` (dashboard rollup, 60s poll), `useAnalyticsDetail` (rich `/analytics` data). Defines wire types (`Me`, `Profile`, `Analytics`, `AnalyticsDetail`, etc.). Updated 2026-07-03: `RecentTurn` gained `turn_id` + `feedback` (pilot F1). |
| `devices.ts` | Client module | Device pairing/management data layer: `useDevices`, `useRenameDevice`, `useUnlinkDevice`, `usePairingInfo`, `useCompletePairing`; wire types (`Device`, `PairingInfo`); error normalization (`errorCode`, `friendlyError`, `friendlyByCode`). |
| `admin.ts` | Client module | Admin read surface hooks for `/api/frontend/admin/*` (health, cost, daily, users/devices/sessions, turns, per-turn trace, media, model-eval); wire types mirroring the backend admin schemas. Updated 2026-07-03: adds `useAdminPerformance` (per-stage latency + time-to-first-audio), firmware OTA (`useAdminOtaReleases`, `useUploadOtaRelease` raw-`.bin` fetch, `useDeleteOtaRelease`), the pilot dashboard (`useAdminCohorts`, `useAdminPilotFunnel/Feedback/Surveys/Reports`, `useSetReportStatus`), and learning insights (`useInsightTopics/Coverage/Engagement/Quality/Mistakes`). |
| `pilot.ts` | Client module | **(added 2026-07-03)** Pilot instrumentation client for `/api/frontend/pilot/*` (mirrors `app/schemas/pilot.py`): `useTurnFeedback` (F1), `useSurveyStatus`/`useSubmitSurvey` (F2), `useReportProblem` (F5), `usePersonalization`/`useSavePersonalization`, `useRecordConsent` (F7); wire types (`Thumbs`, `Resolution`, `SurveyKind`, `Personalization`, etc.). |
| `models.ts` | Client module | Multi-LLM evaluation layer: `useModels` catalog + the single/compare "solve" calls (multipart FormData: WAV audio + image blobs + text) using a token-aware `fetch`; defines `ModelInfo`, `SimResponse`, `TimelineStep`, etc. |
| `onboarding.ts` | Shared module | The onboarding contract: option lists (target exams, prep durations, learning styles, explain depths, study rhythms, focus subjects), the `ONBOARDING_QUESTIONS` array, the `OnboardingMetadata` shape, and `isXxx` type guards. Imported by the form, the server action, and the auth guard. |
| `pairing-code.ts` | Pure helper | `extractPairingCode(raw)` — liberally parses a lamp's QR (full pairing URL, `/pair/CODE` path, `?code=` query, or a bare code) into a normalized uppercased code, or `null`. |
| `time.ts` | Pure helper | `formatCountdown(msRemaining)` for the pairing-expiry countdown and `formatAgo(iso)` for device "last seen" labels. |
| `log.ts` | Client module | Central browser diagnostics: color-coded `log` (ERROR/LAG/RACE/TIMING categories), latency `BUDGET`s, `stopwatch`, sequence/race helpers (`nextSeq`, `raceEnter`, `raceExit`). Gated on dev / `NEXT_PUBLIC_VERBOSE` / runtime localStorage flag. |
| `useSimulatorCapture.ts` | Client hook **(web simulator)** | Camera + mic capture for the `/simulator` bench: webcam JPEG snapshot + 16 kHz mono WAV (raw PCM via Web Audio, encoded on release). Cataloged in detail in `04-web-simulator.md`. |

---

## Folder: `types/`

**Purpose:** Ambient TypeScript module declarations.
**File types:** `.d.ts`.

| File | Type | Purpose |
| --- | --- | --- |
| `types/react-katex.d.ts` | TS ambient decl | Declares the small `react-katex` surface used by the app (`InlineMath`, `BlockMath`) because the package doesn't expose its bundled types via `package.json`. |
