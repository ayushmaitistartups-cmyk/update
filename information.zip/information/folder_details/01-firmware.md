# Firmware — Folder & File Catalog

> **Updated 2026-07-05** — re-synced against firmware branch tip `c699e72` (2026-07-03). The previous sync was `8c13325` (2026-06-16); firmware development resumed after that with +4 commits (`7408aa5` bug fixes, `aa2143c` graphs + compression, `e1de15a` OTA + chemistry, `c699e72` "FIRST ITERATION COMPLETE"). New this pass: over-the-air self-update (`ota.cpp`/`ota.h`), a single-source-of-truth panel-geometry header (`display_config.h`), the large `tft_ui` rewrite (interactive graph + chemistry pages, JPEG-compressed equations), optional Opus TTS decode, and — new in `c699e72` — the scroll-document TFT page (`PAGE_DOC`/`TFT_SCROLL_DOC`), a filled-in `BTN_RIGHT_LONG` long-press mapping, multi-graph support (`graph_id`-prefixed `GRAPH_VIEW`), and two new design docs (`NAVIGATION.md`, `TFT_UX_FINDINGS.md`).

This is the on-device firmware for the **Smart Tutor Lamp** ("Lumos"), an ESP32-S3 AI tutor lamp. The repo lives at `D:/clartiy/Smart-Tutor-Lamp` on git branch **firmware**. The production firmware is a single Arduino/C++ sketch (`tutor_lamp/tutor_lamp.ino`) plus ~30 module `.cpp`/`.h` files compiled together; around it sits a constellation of standalone Arduino bring-up sketches (`.ino`) and a few PC-side **Python** helpers (`.py`) used to calibrate, train, and locally simulate each peripheral. The lamp captures a spoken question (INMP441 mic + on-device DSP + a local "hey lumos" wake word), snaps a page photo (OV5640 camera), streams both to a Python/FastAPI backend over one persistent WebSocket, then plays the spoken answer (MAX98357A speaker) while rendering text/LaTeX/images on a 320×240 TFT panel. As of `e1de15a` it also renders **interactive graphs** (pan/zoom over a backend-cached formula) and **multi-step chemistry structures** on the panel, receives equations as compact **grayscale JPEG** (~3–15 KB vs ~70 KB raw pixels), can decode **Opus** TTS (~4 KB/s), and **self-updates over the air** (HTTPS-pull firmware flash on boot).

The languages used are: C++/Arduino (`.ino` top-level sketches, `.cpp`/`.h` modules, one vendored `.c`), and Python (test servers and a backend simulator), plus Markdown design docs and a PNG pinout.

## Folder map

| Folder path | One-line purpose |
|---|---|
| `/` (repo root) | Design/spec docs, pinout image, the `dummy_backend.py` simulator, and repo config (`.gitignore`, `.env.local`). |
| `tutor_lamp/` | The main production firmware: every device module (state machine, audio DSP, display/UI, networking, camera, buttons, settings/provisioning, QR) compiled as one sketch. |
| `Wake word/wake_word_hey_lamp/` | Standalone Edge Impulse wake-word inference sketch ("hey lumos") used to validate the model before integration. |
| `camera_test/` | OV5640 document-capture bring-up rig: ESP32 capture sketch + Flask/OpenCV rectifier server + camera pin headers. |
| `camera_test/docs/` | Operator manual for the camera_test rig (wiring, IDE settings, serial commands, pipeline). |
| `ei_data_collector/` | Edge Impulse wake-word training-data collector: streams 16 kHz mic samples over serial. |
| `mic_recorder/` | Dual-mode INMP441 mic recorder/EI forwarder that streams DSP-processed PCM over WiFi and (in EI mode) serial. |
| `push_buttons/` | Smallest rig: probes the 5-way resistor-ladder ADC button hardware on one analog pin. |
| `tft_latex_client/` | TFT panel bring-up rig validating the RGB565 frame protocol and hardware scroll for the LaTeX display path. |
| `wifi_audio_player/` | WiFi PCM audio sink rig: TCP/UDP PCM → ring buffer → I2S → MAX98357A. |

---

## Folder: `/` (repo root)

The repo root holds the design/specification documents (Markdown), the hardware pinout image, the single-file backend simulator used during development, and repo configuration. File types: `.md` docs, `.png` image, `.py` script, dotfile config.

| File | Type | Purpose |
|---|---|---|
| `BACKEND_DESIGN.md` | Markdown doc | Backend design spec — the sub-2-second end-of-speech→first-audio latency goal and the full hardware-in-the-loop pipeline the backend must serve. |
| `HARDWARE_CONTEXT.md` | Markdown doc | The contract the backend needs to know about the lamp (audio formats, TFT frame layout, pin/peripheral facts) written for Python backend engineers. |
| `IMPLEMENTATION_AUTH_PAIRING.md` | Markdown doc | Spec for account creation, linking a physical lamp to an account, and how the lamp authenticates (the design behind the inert `provisioning` module). |
| `IMPLEMENTATION_WEBSOCKET.md` | Markdown doc | Self-contained spec of the ESP32-side WebSocket transport: the 11-frame `[type][u24 len][payload]` protocol that `net_ws` implements. |
| `PROJECT_CONTEXT.md` | Markdown doc | Living project overview/changelog kept in sync with every code change; the high-level map of firmware + backend + tooling. |
| `ESP32S3_Pinout.png` | PNG image | Reference pinout diagram for the ESP32-S3 board used to wire mic, speaker, camera, TFT, and buttons. |
| `dummy_backend.py` | Python script | Single-file WebSocket backend simulator (`ws://0.0.0.0:8000/lamp/ws`): saves received image+audio, streams a hardcoded MP3 as TTS, and alternates TFT_FRAME (a huge LaTeX integral) / TFT_TEXT replies — a drop-in stand-in for the real FastAPI backend. |
| `.gitignore` | Config dotfile | Excludes media artifacts (`*.mp3/jpg/png/wav`) and secrets (`.env`) from version control. |
| `.env.local` | Config dotfile | Frontend/dev environment values (Clerk auth keys, `NEXT_PUBLIC_BACKEND_URL`, sign-in/up redirect URLs); git-ignored. |

---

## Folder: `tutor_lamp/`

The main production firmware. Every file here is compiled together as one Arduino sketch. It contains the top-level entry/state machine (`.ino`), paired `.cpp`/`.h` modules for each subsystem, configuration headers, and one vendored C QR library. Files are grouped logically below; every file is listed.

### Entry point & state machine

| File | Type | Purpose |
|---|---|---|
| `tutor_lamp.ino` | Arduino sketch | Top-level firmware: drives the MODE_IDLE → MODE_COMMAND → MODE_SENDING state machine, wires every module in `setup()`, and orchestrates wake detection, camera capture, audio streaming, and the TFT UI in `loop()`. As of `e1de15a` `setup()` also calls `ota::check_boot()` (self-update window), the frame dispatcher handles the graph/chem/compressed-equation/Opus frames, and `loop()` commits deferred graph pans and ships `FRAME_GRAPH_VIEW` requests. It also holds the optional in-sketch Opus decoder (`USE_OPUS_DECODER`). |

### Audio capture & DSP pipeline

| File | Type | Purpose |
|---|---|---|
| `mic_i2s.h` / `mic_i2s.cpp` | C++ module | INMP441 I2S RX + DMA capture task; produces training-identical samples (`>>8` → DC-blocker IIR → `sat16(y>>4)`) and invokes user hooks in the strict order raw→wake→postprocess→cleaned. |
| `audio_post_process.h` / `audio_post_process.cpp` | C++ module | Thin pipeline wrapper that chains the four DSP stages in order (NS → ALE → AGC → VAD), re-exporting every stage accessor through one include. |
| `ns_stage.h` / `ns_stage.cpp` | C++ module | Single-band time-domain Wiener noise suppression using a minimum-statistics two-speed noise-floor estimator with attack/release smoothing. |
| `ale_stage.h` / `ale_stage.cpp` | C++ module | Adaptive Line Enhancer (NLMS) that removes tonal/correlated interference (mains hum, fan whine) without a loudspeaker reference; the residual is broadband speech. |
| `agc_stage.h` / `agc_stage.cpp` | C++ module | Auto Gain Control that normalizes RMS to `AGC_TARGET` so the EI model sees training-level audio; holds gain during silence to avoid noise "pumping". |
| `vad_stage.h` / `vad_stage.cpp` | C++ module | Voice Activity Detector: 2-of-3 majority vote over energy ratio, zero-crossing rate, and spectral-flatness proxy, with a hangover counter; gates the wake-word trigger only. |
| `wake_word.h` / `wake_word.cpp` | C++ module | Edge Impulse continuous "hey lumos" classifier: owns the inference double-buffer, the `feed_frame` callback (fed pre-postprocess audio), and debounced trigger logic. |
| `spk_i2s.h` / `spk_i2s.cpp` | C++ module | MAX98357A TTS output: pushes received PCM into a 32 KB FreeRTOS ring buffer drained by a core-0 playback task to I2S_NUM_0 (shared half-duplex with the mic). |
| `adpcm_dec.h` / `adpcm_dec.cpp` | C++ module | IMA/DVI 4-bit ADPCM decoder for AUDIO_OUT_ADPCM (0x12) frames; bit-exact counterpart of CPython's `audioop` encoder, 4:1 compression, state continuous per TTS stream and reset at AUDIO_OUT_END. |

### Networking

| File | Type | Purpose |
|---|---|---|
| `net_ws.h` / `net_ws.cpp` | C++ module | Persistent secure WebSocket client implementing the single binary protocol (`[u8 type][u24 len BE][payload]`); only `net::loop()` touches the WS library, with a TX queue safe for the mic capture task to enqueue audio chunks. The `FrameType` enum grew (as of `e1de15a`) with graph/chemistry/compressed-equation/Opus frames — `FRAME_GRAPH_VIEW (0x09)` uplink pan/zoom, `FRAME_AUDIO_OUT_OPUS (0x13)`, `FRAME_TFT_IMAGE_JPEG/PART (0x27/0x28)`, `FRAME_TFT_GRAPH_JPEG (0x29)`, `FRAME_TFT_CHEM_JPEG (0x2A)`. `net_ws.cpp` also gained a "SLOW WRITE" stall detector that logs when a blocking TLS `sendBinary()` (or the TX drain) stalls `loop()` on a congested link. |
| `backend_config.h` | Config header | Single source of truth for the backend address; one `BACKEND_USE_SERVER` switch selects LAN dev (`ws://`/`http://`) vs deployed Render (`wss://`/`https://`); included by `net_ws.h`, `provisioning.h`, and `ota.cpp`. Also carries the `USE_OPUS_DECODER` toggle (build with the `arduino-libopus` library to decode ~4 KB/s Opus TTS instead of ADPCM/PCM). |
| `ota.h` / `ota.cpp` | C++ module (NEW `e1de15a`) | HTTPS-pull over-the-air firmware self-update. `ota::check_boot()` runs ONCE in `setup()` after WiFi associates but BEFORE `net::begin()` (a guaranteed-quiet window — no turn/audio/TTS/upload in flight, WSS TLS heap not yet allocated). It GETs `…/lamp/ota/version` (plain text: `version\n.bin-URL`); if the reported int exceeds `FIRMWARE_VERSION` it streams the `.bin` straight into the spare OTA partition via `HTTPUpdate`, verifies it, and reboots. Guarded by a free-heap floor (`OTA_MIN_FREE_HEAP`), a short probe timeout so an asleep backend never freezes boot, and an anti-loop `tried_ver` NVS key (namespace `ota`). Paints a full-screen "Updating… NN%" progress bar via `tft_ui`. |

### Camera

| File | Type | Purpose |
|---|---|---|
| `camera.h` / `camera.cpp` | C++ module | OV5640 + autofocus capture (mirrors `camera_test.ino`): idles VGA, captures UXGA JPEG on wake with single-shot AF at 10 MHz XCLK, then drops back to VGA; invoked from `loop()` in the wake-detected branch. |
| `board_config.h` | Config header | Espressif camera-model selector (`#define CAMERA_MODEL_*`, exactly one active) that then includes `camera_pins.h`. |
| `camera_pins.h` | Config header | Canonical per-board GPIO pin map for the selected camera model (`#if defined(...)` blocks). |

### Buttons

| File | Type | Purpose |
|---|---|---|
| `buttons.h` / `buttons.cpp` | C++ module | 5-way ADC resistor-ladder button reader on GPIO 2 (mapping matches `push_buttons.ino`); adds edge detection, ~50 ms debounce, rate-limiting, a 1500 ms long-press SELECT, and `held()` for hold-to-talk. |

### Display & UI

| File | Type | Purpose |
|---|---|---|
| `tft_ui.h` / `tft_ui.cpp` | C++ module | Master TFT UI module owning the single TFT_eSPI instance (largely rewritten in `aa2143c`/`e1de15a`, +733 lines). Renders all pages (boot, WiFi-connecting, QR pairing, greeting, idle eyes, listening waveform, thinking spinner, image preview, speaking-text, speaking-LaTeX with manual scroll, error) plus two new full-screen pages: `PAGE_GRAPH` (12) — interactive graph, 4-dir buttons pan x/y and SELECT/long-press zoom, each gesture asking the backend to re-render via `FRAME_GRAPH_VIEW`; and `PAGE_CHEM` (13) — up to 4 RDKit-rendered chemistry structure steps cached on-device with L/R step navigation. Also decodes JPEG-compressed equations (`on_tft_image_jpeg`, via `TJpg_Decoder` straight into the `s_latex` buffer) and reuses the 200 KB camera-preview buffer for graph/equation JPEG accumulation. All layout coordinates now derive from `display_config.h` scale helpers. Keeps the always-on phone-style status bar. |
| `tft_display.h` / `tft_display.cpp` | C++ module | Paints server-rendered RGB565 frames on the TFT (the lamp does NOT render LaTeX; it only pushes finished pixels); an older module superseded by `tft_ui`, kept for back-compat. |
| `image_viewer.h` / `image_viewer.cpp` | C++ module | Debug-only TFT JPEG viewer to visually verify camera focus/exposure/framing; gated by `ENABLE_IMAGE_VIEWER` and not for production UI. |
| `text_entry.h` / `text_entry.cpp` | C++ module | Full on-screen keyboard (landscape 320×240) painted via `tft_ui`, used to enter WiFi credentials and other text from the device. All metrics now scale via `display_config.h`'s `lamp_sx()/lamp_sy()` (identity at 320×240). |
| `display_config.h` | Config header (NEW `aa2143c`) | Single source of truth for the TFT panel geometry (`LAMP_SCREEN_W/H`, rotation) and the `lamp_sx()/lamp_sy()/lamp_smin()` scale helpers that reflow the whole UI to a different panel size. Authored at a 320×240 reference (helpers are the identity there → byte-for-byte identical coordinates on current hardware). `tft_ui.h` re-exports `SCREEN_W/H` from it; `LAMP_LATEX_AREA_H` is mirrored server-side in `app/config.py` so rendered equation/graph pixels line up with the slot the firmware paints. |

### QR / pairing display

| File | Type | Purpose |
|---|---|---|
| `tft_qr.h` / `tft_qr.cpp` | C++ module | Renders the pairing QR code plus a human-readable caption on the TFT (portrait) for the user to scan with their phone during provisioning. |
| `RICqrcode.c` / `RICqrcode.h` | Vendored C library | Richard Moore's MIT-licensed QR-code generator (the encoder backing `tft_qr`). |

### Settings & provisioning

| File | Type | Purpose |
|---|---|---|
| `settings_store.h` / `settings_store.cpp` | C++ module | NVS-backed user preferences (namespace `lumos_set`): TTS volume and user WiFi credentials, persisted via the Preferences library; setters write through immediately and notify subsystems (e.g. `spk::set_volume`). |
| `tft_settings.h` / `tft_settings.cpp` | C++ module | The on-device Settings page: Volume (live-applied), Re-pair lamp (wipes JWT + reboots), and Reconfigure WiFi (opens `text_entry` for SSID/password, writes settings, reboots). |
| `provisioning.h` / `provisioning.cpp` | C++ module | Lamp↔account pairing over HTTPS with JWT issuance; self-contained but currently inert (not wired into `tutor_lamp.ino`, `ENABLE_AUTH=0`); owns its own NVS namespace (`lamp`) for device_id/secret/jwt. |

### Documentation

| File | Type | Purpose |
|---|---|---|
| `NAVIGATION.md` | Markdown doc (NEW `c699e72`) | Buttons/navigation user guide: the 5-way pad, tap vs. **hold ≥ 1.5 s**, a per-page button table (text/equation/chemistry/scroll-document/graph-arena pages), and the scroll-document convention — a plain **RIGHT** tap opens the on-screen graph into the interactive arena, **LEFT** toggles answer⇄spoken-transcript. |
| `TFT_UX_FINDINGS.md` | Markdown doc (NEW `c699e72`) | UI/UX design critique of the old combined-view TFT layout: 9 numbered findings (sideways-scrolling equations, only ~5 lines visible, no boxed "hero" answer, weak typography, permanent nav chrome, cold palette, no progressive reveal, hard-cut transitions, off-screen-scrolling equations), each tagged ✅/🟡/🔲 addressed-status and `[backend]`/`[firmware]`/`[hw]` cost. Argues `TFT_SCROLL_DOC` (§4.9, `02-display-and-ui.md`) is the shipped fix for several findings, plus a prioritized backend/firmware/hardware next-steps list. |

---

## Folder: `Wake word/wake_word_hey_lamp/`

A standalone Edge Impulse **inference** sketch that runs the trained "hey lumos" wake-word model in isolation to validate it before it is folded into `tutor_lamp/wake_word.{h,cpp}`. File type: Arduino sketch.

| File | Type | Purpose |
|---|---|---|
| `wake_word_hey_lamp.ino` | Arduino sketch | Runs the continuous EI wake-word classifier on live INMP441 audio using the exact training DSP chain (DC block + `>>4` gain + `sat16`); its header documents the cautionary tale of gappy serial-streamed training data that broke an earlier model. |

---

## Folder: `camera_test/`

A lamp-mounted OV5640 document-capture bring-up rig: an ESP32 sketch captures a sharp UXGA JPEG and POSTs it to a Flask/OpenCV server that rectifies the page into an LLM-ready clean image. It de-risks the production `camera.{h,cpp}` and the backend image-cleanup stage. File types: Arduino sketch, Python server, camera config headers.

| File | Type | Purpose |
|---|---|---|
| `camera_test.ino` | Arduino sketch | ESP32-S3 OV5640 capture sketch: direct AF/VCM register control, serial command UI (capture/preview/focus/quality), document-mode sensor tuning, and a dual-retry (blur re-AF / framebuffer-overflow quality bump) upload loop. |
| `camera_server.py` | Python (Flask) server | Receives raw JPEG bytes and runs a 6-stage adaptive document pipeline (sharpness gate → page-quad detect → perspective warp → denoise → deskew → background bleach → CLAHE+sharpen), saving an LLM-ready cleaned PNG; serves `/upload`, `/preview`, `/latest`, `/status`. |
| `board_config.h` | Config header | Camera-model selector (here `CAMERA_MODEL_ESP32S3_EYE`) that includes `camera_pins.h`. |
| `camera_pins.h` | Config header | Per-board GPIO pin map; the `ESP32S3_EYE` block matches the inline pin defines used in `camera_test.ino`. |

## Folder: `camera_test/docs/`

Operator documentation for the camera_test rig. File type: Markdown.

| File | Type | Purpose |
|---|---|---|
| `README.md` | Markdown doc | ~420-line operator manual: wiring (incl. the AF-VCC fix), Arduino IDE settings, OV5640 AF library install, serial-command reference, focus/quality tradeoffs, server setup, HTTP endpoint docs, the processing pipeline, and troubleshooting. |

---

## Folder: `ei_data_collector/`

Collects the **training dataset** for the "hey lumos" wake-word model by streaming INMP441 audio at 16 kHz mono as one int16 per line over serial in the format `edge-impulse-data-forwarder` expects. File types: Arduino sketch and a `.txt` holding an earlier sketch variant.

| File | Type | Purpose |
|---|---|---|
| `ei_data_collector.ino` | Arduino sketch | Final simplified collector: I2S port 1, 16-bit frames, 2 Mbaud serial, ×8 gain ("same as inference"); drains 10 reads then streams `%d\n` samples for EI. |
| `mic_EI.txt` | Arduino sketch (text-saved) | Earlier collector variant (header still says `.ino`): uses I2S_NUM_0, 32-bit frames, `MIC_SHIFT=4` (+24 dB), `sat16`, and a DC-blocker IIR (Q15 coeff 32604) — the same DSP chain the wake-word inference uses. |

---

## Folder: `mic_recorder/`

A single 16 kHz audio pipeline with two modes (record / EI) that always streams DSP-processed PCM over WiFi to a PC (`mic_server.py`, which saves a WAV) and additionally, in EI mode, prints int16/line over serial for the forwarder — guaranteeing the saved WAV equals what EI Studio receives. File type: Arduino sketch.

| File | Type | Purpose |
|---|---|---|
| `mic_recorder.ino` | Arduino sketch | Dual-mode mic streamer with a core-1 capture task applying the production DC-blocker + gain + `sat16` DSP; sinks PCM to WiFi (WAV) and optionally serial (Edge Impulse), bridging data collection, inference, and the production mic path. |

---

## Folder: `push_buttons/`

The smallest rig in the set: proves the 5-button **resistor-ladder** hardware where all five buttons share one ADC pin, each pulling it to a distinct voltage. Direct ancestor of `tutor_lamp/buttons.{h,cpp}`. File type: Arduino sketch.

| File | Type | Purpose |
|---|---|---|
| `push_buttons.ino` | Arduino sketch | Reads the 12-bit ADC on GPIO 2, thresholds bottom-up into buttons 1–5 (no-press ≈ 4095), and prints which button is pressed every 100 ms — the threshold table inherited by production `buttons`. |

---

## Folder: `tft_latex_client/`

A TFT-panel bring-up rig for the LaTeX display path: the ESP32 sends a LaTeX string to a PC server, receives a stream of RGB565 pixel frames, and paints them with hardware-scroll support. It validates the exact wire format `tutor_lamp/tft_ui` consumes and supplies the canonical stress-test equations. File type: Arduino sketch.

| File | Type | Purpose |
|---|---|---|
| `tft_latex_client.ino` | Arduino sketch | Requests rendered LaTeX (length-prefixed), parses the 8-byte frame header (W/H/fmt/payloadLen), and paints each RGB565 frame with `pushColors` including odd-byte carry handling and a 3 s watchdog; ships the `EQUATIONS[]` table reused by `dummy_backend.py`. |

---

## Folder: `wifi_audio_player/`

A network audio sink rig: the ESP32-S3 + MAX98357A amp receives raw PCM (16-bit, 44.1 kHz, stereo) over TCP or UDP and plays it via I2S, using a 32 KB ring buffer and two per-core FreeRTOS tasks to decouple ingest from output. De-risks the production `spk_i2s.{h,cpp}` I2S/ring-buffer mechanics. File type: Arduino sketch.

| File | Type | Purpose |
|---|---|---|
| `wifi_audio_player.ino` | Arduino sketch | TCP/UDP PCM → ring buffer → I2S DMA → MAX98357A player: a `net_rx_task` (core 0) fills the ring and an `i2s_tx_task` (core 1) drains it, with diagnostics for latency/jitter tuning. |

---

> Note: `*.pyc`, `__pycache__/`, and `.git/` are excluded from this catalog.
