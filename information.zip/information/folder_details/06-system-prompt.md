# System Prompt (Web + Lamp) — Folder & File Catalog

These files are the **instruction layer** of the Smart-Tutor-Lamp backend brain — the natural-language system prompts that tell the Gemini models how to turn a student's audio + camera frames (lamp) or text + audio + images (web) into a disciplined, multi-channel JSON tutoring reply. They live in `app/prompts/` (plus runtime "companion" fragments in `app/services/`), are **prompt text only** (no control flow), and are assembled per-turn by the orchestrator (lamp) and `gemini_brain` (web).

**Web vs Lamp — the one thing to know up front:** the two paths do **NOT** share one big system prompt. The **lamp** path uses `app/prompts/turn1_system.get_turn1_prompt()` for every tier (1, 2, 3). The **web** simulator path uses a **separate, hand-written prompt** inside `app/providers/gemini_brain.py` (`_system_prompt` + `_STRUCTURED_SUFFIX`), because the web renders LaTeX with KaTeX (full LaTeX, aligned environments) while the lamp renders only the matplotlib-mathtext subset. The prompt strings actually shared between the two surfaces are `PERCEIVED_QUESTION_SUFFIX` (imported by the web brain from `turn1_system`), the child-safety `_guardrails.GUARDRAILS` block (injected into *both* prompts), and the conceptual lineage of `_latex_rules.LATEX_RULES`. Everything in `app/prompts/` except `turn1_system.py`, `_latex_rules.py`, `_guardrails.py`, and `__init__.py` is **dead code** (defined, never imported).

> **Updated 2026-07-03:** a new **`app/prompts/_guardrails.py`** is now a LIVE shared prompt module (SAFETY / SCOPE / INSTRUCTION-HIERARCHY / PRIVACY boundary), imported by *both* surface prompts and gated by `SAFETY_GUARD_ENABLED` (default ON). `turn1_system.get_turn1_prompt()` also grew four independently-gated rule fragments (graph / molecular-structure / rich-analytics / math-verifier capture), each injected only when its feature flag is on; those flags now default on, so the default config injects all four fragments.

> A deeper narrative of the prompt internals lives in `../system-prompt-web-and-lamp/` and in `D:/clartiy/information/02-backend/07-prompts-and-llm-instructions.md`. This file is the directory catalog.

---

## Folder / Files map

| Path | Live? | What it is |
|---|---|---|
| `app/prompts/turn1_system.py` | **LIVE** | The single lamp prompt (all tiers) + `PERCEIVED_QUESTION_SUFFIX`. Injects `GUARDRAILS`, `LATEX_RULES`, and four feature-gated rule fragments. |
| `app/prompts/_latex_rules.py` | **LIVE** | `LATEX_RULES` — matplotlib mathtext subset, injected into `turn1`. |
| `app/prompts/_guardrails.py` | **LIVE** (shared) | `GUARDRAILS` — child-safety SAFETY/SCOPE/instruction-hierarchy/PRIVACY boundary, injected into BOTH surface prompts; gated by `SAFETY_GUARD_ENABLED` (default ON). |
| `app/prompts/__init__.py` | **LIVE** (empty) | Package marker (0 bytes, no exports). |
| `app/prompts/turn2_system.py` | dead | `get_turn2_prompt()` — never imported. |
| `app/prompts/classifier.py` | dead | `get_classifier_prompt()` — never imported. |
| `app/prompts/conceptual_module.py` | dead | `get_conceptual_module_prompt()` — never imported. |
| `app/prompts/technical_module.py` | dead | `get_technical_module_prompt()` — never imported. |
| `app/prompts/escalation.py` | dead | `get_escalation_prompt()` — never imported. |
| `app/prompts/_unused/` | dead | Older copies of the 5 dead files + `README.md`. |
| `app/providers/gemini_brain.py` | **LIVE** (web) | Holds the web's separate `_system_prompt` + `_STRUCTURED_SUFFIX` + `build_system_prompt()`. |
| `app/providers/web_simulator.py` | **LIVE** (fallback) | Deterministic, **no-LLM / no-prompt** web fallback. |
| `app/services/orchestrator.py` | **LIVE** (lamp) | Imports `get_turn1_prompt`; assembles the per-turn lamp prompt. |
| `app/services/model_solver.py` | **LIVE** | Reuses the web prompt for cross-provider verification. |
| `app/services/turn_handler.py` | stub | Prototype mock; not wired to the live prompts. |
| `system_prompt_arch.md` (repo root) | doc | Authoritative architecture writeup. |

---

## Folder: `app/prompts/`

**Purpose:** owns the instruction layer — the persona ("Lumos, a warm Socratic desk-lamp tutor"), input-handling rules (audio + 0..5 camera frames + an XML-tagged CONTEXT block), the three independent output channels (`speech` / `display` / `latex_equations`), the Socratic pedagogy, the routing/telemetry contract, and the LaTeX subset. It contains no logic; assembly happens in `app/services/orchestrator.py`. `__init__.py` is empty (just makes it a package).

### Active prompt files

| File | Type | Purpose (what it instructs the model to do) |
|---|---|---|
| `turn1_system.py` | **LIVE** lamp prompt | `get_turn1_prompt()` returns one large f-string — the only live lamp prompt, used for the fast first pass AND every escalated re-take (tiers 1/2/3). Instructs the model to: adopt the Lumos persona; silently classify each image by role (`problem`/`detail`/`attempt`/`pointer`/`environment`); resolve FOCUS on multi-question pages (pointer vs spoken reference, occlusion, conflict→ask one question); apply CURRENT-TURN PRIMACY + the TWO-SIDED CONTEXT RULE (FRESH vs CONTINUATION); emit three independent channels (`speech` = voice only, `display` = ≤100-word text card referencing `eq1/eq2`, `latex_equations[]` = separate single-line formulas, no `$`); never put math as text; obey the STATE ISOLATION boundary (never reveal `problem_statement`/`solution_outline`/answer key; nudge-by-default, SOLVE only when authorized or on explicit surrender); follow RULES 1–9 (speech brevity, separate equations, image-is-the-question, verify-before-accuse, no invented facts + confidence bands, match level & language, personalize, read-the-room nudge-vs-solve, `user_input` restatement); and fill the audit/routing/handoff/memo fields (`ocr_text`/`bounding_box`, `confidence`/`query_type`/`subject`/`difficulty`, `problem_statement`/`image_needed`, `solution_outline`/`same_problem`). Its interpolations are `{GUARDS}` (the `GUARDRAILS` block, gated by `SAFETY_GUARD_ENABLED`, prepended right after the persona line), `{LATEX_RULES}`, and four feature-gated rule fragments injected only when their flag is on — `GRAPH_RULES` (`GRAPH_ENABLED`), `STRUCTURE_RULES` (`CHEM_STRUCTURE_ENABLED`), `ANALYTICS_RULES` (`RICH_ANALYTICS_ENABLED`), and `VERIFIER_RULES` (`MATH_VERIFY_ENABLED`) — all of which now default on, so the default config injects all four fragments. Also defines `PERCEIVED_QUESTION_SUFFIX` (a triage echo appended on both surfaces when `DEBUG_PERCEIVED_QUESTION` or `MEMO_CAPTURE_QUESTION` is on). |
| `_guardrails.py` | **LIVE** shared string | `GUARDRAILS` — a surface-neutral child-safety boundary block (SCOPE: study-tutor only, steer off-topic back; SAFETY: assume the student may be a child, refuse actionable real-world harm, redirect distress to a trusted adult; INSTRUCTIONS-ARE-FIXED: ignore prompt-injection / "give me the answer key" attempts, worked answers released only via `[SOLVE AUTHORIZED]` / genuine surrender; PRIVACY). Injected into BOTH `turn1_system` and the web `gemini_brain.build_system_prompt`, gated by `SAFETY_GUARD_ENABLED` (default ON, ~490 tokens). |
| `_latex_rules.py` | **LIVE** shared string | `LATEX_RULES` — the matplotlib-mathtext-subset contract injected into `turn1` (and the dead `turn2`). Lists the ALLOWED commands (`\frac`, `\dfrac`, `\sqrt`, sums/integrals, greek, trig, accents, relations, delimiters), the FORBIDDEN list that crashes the on-device render (`\tfrac`, `\boxed`, `\text`, `\xrightarrow`, `\\` line-breaks, `\begin{aligned|cases|array}`, raw Unicode), the multiple-equations rule with a **hard cap of 3**, the **~40-char / 320 px width** rule, and 7 "PROVEN ON THE LAMP" calibration equations. |
| `__init__.py` | **LIVE** (empty) | Package marker; 0 bytes, no exports. |

---

## Folder: `app/prompts/_unused/`

**Purpose:** archive for the deprecated five-prompt design (the earlier two-tier-with-modules architecture). Its `README.md` states these are "not imported anywhere," explains exactly why each contradicts the current `LlmReply` contract, and concludes that the LIVE prompts are `../turn1_system.py` (lamp) + `../_latex_rules.py` (shared), and that the web frontend uses a separate prompt in `gemini_brain.py`. The top-level (non-`_unused`) copies of these same five files are also dead — both sets are functionally equivalent vestiges.

| File | Type | Purpose — **UNUSED** |
|---|---|---|
| `_unused/README.md` | doc | Explains the deprecation and lists the contract mismatches. **UNUSED** (doc). |
| `_unused/turn2_system.py` | dead prompt | `get_turn2_prompt()` — a follow-up/"Turn N>1" prompt with a hand-written JSON schema, an `attempt_count`-based escalation, a `graph` field, and `latex_equations` declared "0..8" (fights the live cap-3). **UNUSED.** |
| `_unused/classifier.py` | dead prompt | `get_classifier_prompt()` — a standalone query classifier with a 7-field taxonomy that does NOT match `LlmReply.query_type`. **UNUSED** (classification is folded into the live first-pass call). |
| `_unused/conceptual_module.py` | dead prompt | `get_conceptual_module_prompt()` — orphaned "conceptual track" rules (UPSC/CAT/SSC, "strictly NO LaTeX"). **UNUSED.** |
| `_unused/technical_module.py` | dead prompt | `get_technical_module_prompt()` — "technical track" rules that say use `$…$`/`$$…$$`, the **opposite** of the live no-`$` rule. **UNUSED.** |
| `_unused/escalation.py` | dead prompt | `get_escalation_prompt()` — a verification-fallback block referencing `voice_output`/`is_confident`, fields that do not exist in `LlmReply`. **UNUSED.** |

> The same five files also exist at the top level of `app/prompts/` (`turn2_system.py`, `classifier.py`, `conceptual_module.py`, `technical_module.py`, `escalation.py`). They are equally dead — a project-wide grep shows each `get_*_prompt` appears ONLY at its own definition, never at a call site.

---

## Related files

### `system_prompt_arch.md` (repo root)
The authoritative architecture narrative for the whole prompt + escalation system: the "tier-1 as router" thesis, the escalation thresholds, the runtime guards (solution-bleed / reveal-completeness / focus / echo), the memo design, and the tier model/cap/thinking knobs. The deep doc and this catalog are its `app/prompts/`-focused companions.

### Runtime assembly points (how prompts are pulled)

| File | How it pulls/uses prompts |
|---|---|
| `app/services/orchestrator.py` (lamp) | Imports `get_turn1_prompt` (line 32) and caches it once at boot as `self._turn1_prompt` (line 45). Per turn it appends fragments: `decision.prompt_suffix` (option-verify / mistake-localize / focus), `PERCEIVED_QUESTION_SUFFIX` (imported lazily at line 357, gated by the two settings), `CONTINUATION_HINT`, `solve_authorized_note`, then a mutually-exclusive dispute-note / answer-key-block / question-context-block. The companion fragments come from `app/services/problem_memo.py` and `app/services/escalation_router.py` (not from `app/prompts/`). The assembled string is sent as Gemini's `system_instruction`. |
| `app/providers/gemini_brain.py` (web) | Holds the web's **own** prompt. `_system_prompt(profile)` builds markdown-headed sections (WHO YOU ARE / HOW YOU TALK / FOCUS / WHAT TO ANSWER per `query_type` with hard word caps / SOCRATIC GATE / HOW DEEP / VERIFY YOUR OWN MATH / CHECKING THE STUDENT'S WORK). `_STRUCTURED_SUFFIX` is the KaTeX reply-format contract (`type='latex'|'text'|'none'`, `aligned` allowed in SOLVE). `build_system_prompt(profile, extra_instruction="")` prepends the shared `GUARDRAILS` block (when `SAFETY_GUARD_ENABLED`), then `_system_prompt + _STRUCTURED_SUFFIX + extra_instruction`, then appends `PERCEIVED_QUESTION_SUFFIX` (imported from `turn1_system`) when the two settings are on. `extra_instruction` is how the web threads its guard notes. |
| `app/services/model_solver.py` | Cross-provider verification helper. Imports `_system_prompt` and `_STRUCTURED_SUFFIX` from `gemini_brain` and rebuilds them via `_solve_system_prompt(profile, extra_instruction)` so a non-Gemini solver (used by the solution-bleed guard / `/solve` route) sees the **same** web system prompt for parity. |
| `app/providers/web_simulator.py` | The **deterministic, no-LLM** web fallback used when `GEMINI_API_KEY` is unset. It emits a canned `BrainEvent` timeline (state → text tokens) so the `/simulator` UI still animates without a live model. It uses **no `app/prompts/` modules and no LLM system prompt at all** — only a tiny `_persona(profile)` string. |
| `app/services/turn_handler.py` | A prototype/mock stub ("BAO architecture, Phase 1-4"). Uses obsolete field names (`is_confident`, `voice_output`, `master_solution`) and a mock LLM response; it is **not** wired to the live prompts. Listed for completeness. |

---

## Web vs Lamp — does the prompt differ by source?

Yes — they are **two distinct prompts**, selected by which entry point handles the turn:

- **Lamp** (firmware path, `app/services/orchestrator.py`): the cached `get_turn1_prompt()` base + runtime fragments. LaTeX is the matplotlib mathtext subset (no `$`, no `\\`, no `aligned`), equations go in `latex_equations[]`, hard cap 3.
- **Web simulator** (`/api/frontend/simulate` + `/ws`, `app/providers/gemini_brain.py`): the separate `_system_prompt` + `_STRUCTURED_SUFFIX`, with KaTeX/full-LaTeX and `aligned` environments allowed in SOLVE mode.
- **Web fallback** (`app/providers/web_simulator.py`): no prompt at all — deterministic canned output when no API key is configured.

What they **share**: the same *pedagogy and guardrails* are mirrored across both prompts (FOCUS priority, Socratic gate / STATE ISOLATION, verify-before-accuse, depth/word caps, profile personalization), and they literally share two strings — `PERCEIVED_QUESTION_SUFFIX` (the web imports it from `turn1_system`) and the conceptual lineage of `LATEX_RULES`. The runtime guard/memo fragments (`problem_memo.py`, `escalation_router.py`) feed both surfaces.
