# Backend — Folder & File Catalog

> **Catalog updated 2026-07-06** (backend tip `db470f6`). New files as of 2026-07-03: providers `document.py`/`graph_renderer.py`/`rdkit_renderer.py` (Cartesia now live); routes `pilot.py`/`admin_pilot.py`/`insights.py`/`ota.py`; schemas `pilot.py`/`admin_pilot.py`/`insights.py`; services `admin_pilot`/`insights`/`topic_tagger`/`mistake_tagger`/`output_validator`/`input_guard`/`math_verifier`/`render_check`/`error_messages`/`notify`/`ota_release`; storage `pilot.py`; workers `topic_tag.py`/`mistake_tag.py`; prompt `_guardrails.py`. Moved: `services/{turn_handler,validator}.py` → `app/legacy/`. Deleted: the whole `temp_server_files/` tree. The 2026-07-03/04 commits (`0896f7c`, `a5533e5` — memory-leak/OOM hardening) added **no new files**, only modified `ENV.md`, `config.py`, and existing modules under `providers/`, `services/`, and `routes/`.
>
> New as of the 2026-07-06 brain-optimization commit (`db470f6`, see `02-backend/13-brain-optimization-eval-harness-and-ci.md`): the **`evals/` offline eval harness** (`README.md`, `graders.py`, `run_evals.py`, `report.py`, five `cases/*.jsonl` golden sets, `results/`), the **CI workflow `.github/workflows/backend-ci.yml`**, and tests `test_prompt_version_budget.py` + `test_evals_graders.py`; 13 existing script-style tests were converted to real pytest suites (same filenames, now assert-based and collected by CI).

The backend (`D:/clartiy/Smart-Tutor-Lamp-backend`, git branch `backend`) is the **AI brain** of the Smart Tutor Lamp: an async **FastAPI + uvicorn** Python 3.11 application. It terminates one persistent binary WebSocket per ESP32-S3 lamp, accepts a multimodal "turn" (camera JPEG(s) + microphone PCM), and runs it through a deterministic pre-router → tiered multimodal LLM (Gemini 3.1 Flash-Lite by default, with Claude/OpenAI/DeepSeek swappable and a Pro tier-3) → code-enforced output validator → reply schema → TTS (Gemini, Piper, or Cartesia) + LaTeX / graph / chemistry / TFT rendering, streaming paced audio + chunked screen frames back to the lamp. The same engine drives a web "brain-bench" simulator, a beta-cohort pilot instrumentation surface, and firmware OTA; sessions/turns/memory persist to Supabase Postgres (+pgvector) and optionally Redis.

The codebase follows a clean **routes → services → providers → storage** layering:

- **routes/** — HTTP + WebSocket endpoints (the gateway / edge).
- **services/** — orchestration and business logic (the turn pipeline, auth, memory, analytics). `services/orchestrator.py` is the turn-pipeline brain.
- **providers/** — vendor SDK adapters (LLM, TTS, image/audio/LaTeX preprocessing).
- **storage/** + **db/** — durable persistence (Postgres tables, blob storage, pgvector).
- **schemas/** — pydantic v2 request/response contracts. **prompts/** — system-prompt text. **deps/** — FastAPI `Depends` helpers. **formatting/** — TFT display formatting. **workers/** — deferred async background jobs.

---

## Folder map

| Folder | What it is / purpose | Main file types |
|---|---|---|
| repo root (`./`) | Project root — design/guide docs, config, run artifacts, the lamp simulator, top-level test scripts. | `.md`, `.toml`, `.txt`, `.log`, `.py`, dotfiles |
| `app/` | The FastAPI application package — entrypoint, config, wire protocol, per-lamp session, startup self-tests. | `.py`, `.md` |
| `app/db/` | SQLAlchemy ORM models + async engine/session factory (durable schema). | `.py` |
| `app/db/migrations/` | Alembic migration folder (placeholder). | `.keep` |
| `app/deps/` | FastAPI `Depends` helpers for auth (Clerk, device secret), admin gating, rate limiting. | `.py` |
| `app/formatting/` | TFT-display formatting (320×240 line caps, LaTeX-vs-plain track routing). Still live. | `.py` |
| `app/legacy/` | CI-guarded quarantine for the dead "BAO" prototype (`validator.py`, `turn_handler.py`) — nothing in `app/` may import them. | `.py`, `.md` |
| `app/prompts/` | System-prompt text modules (turn-1/turn-2, LaTeX rules, track modules). | `.py` |
| `app/prompts/_unused/` | Deprecated/orphaned prompt variants kept for reference only. | `.py`, `.md` |
| `app/providers/` | Vendor SDK adapters — LLM brains, TTS engines, image/audio/LaTeX preprocessing. | `.py` |
| `app/routes/` | Every HTTP + WebSocket endpoint (lamp, device pairing, frontend, admin, health, webhooks). | `.py` |
| `app/schemas/` | Pydantic v2 request/response models (auth, frontend, llm reply, admin, model-eval). | `.py` |
| `app/services/` | Orchestration + business logic — the turn pipeline, escalation, memory, analytics, auth services. | `.py` |
| `app/storage/` | Layer 9 durable persistence — turns, blobs, events, pgvector memory, profiles. | `.py` |
| `app/workers/` | Deferred async background jobs (transcribe, embed, daily rollup) — stubs. | `.py` |
| `.github/workflows/` | GitHub Actions CI — the backend CI workflow (ruff + offline pytest on 3.11). **(new 2026-07-06)** | `.yml` |
| `audio-tts/` | Self-hosted Piper TTS voice models (`.onnx` weights + JSON config). | `.onnx`, `.json` |
| `evals/` | Offline golden-set eval harness — graders, runner, report, `cases/*.jsonl` seed sets, `results/`. **(new 2026-07-06)** | `.py`, `.jsonl`, `.md` |
| `scripts/` | Live + dry-run test harnesses, model probes, mock lamp, SQL setup, audio fixtures. | `.py`, `.sql`, `.wav` |
| `tests/` | Pytest suites (offline-by-default) for fallback, escalation, dispatch, LLM I/O, pipeline stress. | `.py`, `.keep` |

---

## Folder: `./` (repo root)

Purpose: project root holding all design/guide documentation, config + dependency files, run-output artifacts, the lamp simulator, and standalone smoke scripts. File types: `.md` design docs, config (`.toml`, `.txt`, dotfiles), `.log`/`.txt` artifacts, `.py` tools.

### Design & guide documentation (`.md`)

| File | Type | Purpose |
|---|---|---|
| `BACKEND_DESIGN.md` | Markdown | The architecture spec — defines the sub-2-second latency goal, the hardware-in-the-loop pipeline, and the §8 suggested module layout the code is mapped onto. |
| `BACKEND_TODO.md` | Markdown | Phased implementation checklist (Phases/Layers 1–9) with "Done when" cues, ordered so each layer is independently testable. |
| `CLAUDE_BRANCH_GUIDE.md` | Markdown | Self-contained guide for adding a switchable, additive Claude capability in two modes (timeout-fallback first, then A/B), without breaking the live Gemini pipeline. |
| `CLAUDE_FALLBACK_GUIDE.md` | Markdown | The fallback-only spec — whenever Gemini fails at any tier, the orchestrator re-runs the same turn on Claude with full history/memory/guards intact so the student never sees a timeout. |
| `ESCALATION_PLAN.md` | Markdown | Two-in-one: postmortem of the JSON-truncation (thinking-tokens) bug, plus the forward plan for multi-tier LLM escalation (Flash no-think → Flash thinking → Pro → text-only powerhouse). |
| `HARDWARE_CONTEXT.md` | Markdown | What the backend must know about the lamp — every byte format, timing constraint, state-machine state, and endpoint the firmware uses, so backend devs needn't read firmware. |
| `IMPLEMENTATION_AUTH_PAIRING.md` | Markdown | Spec for account creation, device pairing, and post-pairing device auth across FastAPI backend, Next.js+Clerk frontend, and ESP32 firmware. |
| `IMPLEMENTATION_WEBSOCKET.md` | Markdown | ESP32-side WebSocket transport spec (frame protocol) — self-contained enough to implement the firmware `net_ws` module; serves as the authoritative protocol reference. |
| `PROJECT_CONTEXT.md` | Markdown | Living document (updated every change) — running changelog of hardware inventory, DSP behaviour, and every numbered backend change with root-cause/fix detail. |
| `RUN.md` | Markdown | 5-minute dev quickstart — prereqs, env setup, boot the backend, and run `dummy_client.py` to print an LLM JSON reply. |
| `SESSION_MEMORY_GUIDE.md` | Markdown | Step-by-step guide to replace the 3-turn Redis stub with the full three-layer (L1 Redis / L2 compacted sessions / L3 user profile) intelligent memory system on Postgres. |
| `SUPABASE_QUERIES.md` | Markdown | Copy-paste SQL debug cookbook for the Supabase SQL Editor to inspect logins, pairing, sessions, conversations, memory, cost, events, and integrity. |
| `SUPABASE_SETUP.md` | Markdown | Step-by-step guide to wire the backend to a fresh Supabase project — schema, Alembic migrations, code wiring, analytics, and production scaling. |
| `TTS_INTEGRATION.md` | Markdown | Every viable TTS path (Cartesia, ElevenLabs, Gemini Live, Piper, Kokoro, Coqui) with drop-in code, comparison table, and fallback patterns — preserving the half-duplex/paced WS audio contract. |
| `system_prompt_arch.md` | Markdown | Complete reference for how a question becomes an answer — prompts, tiers, the flash→Pro handoff, the problem memo, and every guard — shared across the lamp and web surfaces. |
| `app/LAYOUT.md` | Markdown | Maps `BACKEND_DESIGN.md` §8's aspirational folders onto the actual consolidated `app/` package layout. |
| `todo.md` | Markdown | Forward-looking TODO list (grew substantially since the last sync — graphs, chemistry, scroll-doc, guardrails, pilot, OTA plans). |
| `audit_bugs.md` | Markdown | **(new)** Running audit of bugs found + fixed during the guardrail/rendering/verdict work. |
| `COST_ANALYSIS.md` | Markdown | **(new)** Per-turn / per-tier LLM + TTS cost analysis for the pipeline. |
| `ENV.md` | Markdown | **(new)** Consolidated environment-variable reference (companion to `.env.example`). |
| `SESSION_HANDOFF.md` | Markdown | **(new)** Cross-session engineering handoff notes. |

### Config & dependency files

| File | Type | Purpose |
|---|---|---|
| `pyproject.toml` | TOML | Project metadata + core dependencies + per-provider optional extras (`[gemini]`, `[openai]`, `[claude]`, …) so you install only the SDKs you use. |
| `requirements.txt` | Text | Flat pinned dependency list (≈ `pip install -e .[gemini,claude]`), with notes (e.g. the aiohttp pin needed for Gemini streaming). |
| `.env` | Dotenv | Local secrets/runtime config (gitignored) — actual API keys and tunable knobs loaded by `app/config.py`. |
| `.env.example` | Dotenv | Annotated template of every env var (LLM provider/keys, TTS engine, auth, storage, scaling knobs) — copy to `.env` and fill in. |
| `.mcp.json` | JSON | MCP server config pointing at the project's hosted Supabase MCP endpoint. |
| `.gitignore` | Git config | Excludes secrets (`.env*`), local blob dumps (`turn_blobs/`), and Python caches (`__pycache__`, `.pytest_cache`, etc.). |

### Test/run output artifacts

These are captured stdout/log files from running the `scripts/` and `tests/` harnesses — not source, just evidence of past runs.

| File | Type | Purpose |
|---|---|---|
| `auto_test_result.txt` | Run artifact | Captured result of an automated/e2e test run. |
| `conv_final.txt` | Run artifact | Captured output of a final `conversation_dryrun.py` run. |
| `conv_out.txt` | Run artifact | Captured output of a `conversation_dryrun.py` run. |
| `e2e_live_out.txt` | Run artifact | Captured output of a live end-to-end (`e2e_auto_live.py`) run. |
| `focus_dryrun_out.txt` | Run artifact | Captured output of `focus_dryrun.py`. |
| `nudge_dryrun_out.txt` | Run artifact | Captured output of `nudge_dryrun.py`. |
| `qcap_dryrun_out.txt` | Run artifact | Captured output of `qcap_dryrun.py` (question-capture dry run). |
| `qcap_dryrun_out2.txt` | Run artifact | Second captured `qcap_dryrun.py` run. |
| `rel_out.txt` | Run artifact | Captured output of `relevance_dryrun.py`. |
| `t5_out.txt` | Run artifact | Captured output of `probe_t5.py` (reveal-final-answer probe). |
| `vbc_out.txt` | Run artifact | Captured output of `probe_verify_by_code.py`. |
| `vbc2_out.txt` | Run artifact | Second captured `probe_verify_by_code.py` run. |
| `wiring_out.txt` | Run artifact | Captured output of `wiring_dryrun.py` (feature-wiring proof). |
| `server_e2e.log` | Run artifact | Uvicorn server log captured during an e2e test session. |
| `server_final.log` | Run artifact | Uvicorn server log from a final test session. |
| `server_runb.log` | Run artifact | Uvicorn server log from a "run B" test session. |
| `server_stress.log` | Run artifact | Uvicorn server log captured during the lamp-ingest stress run. |

### Root-level tools

| File | Type | Purpose |
|---|---|---|
| `dummy_client.py` | Python | The canonical ESP32-lamp simulator — connects over WebSocket, ships chunked IMAGE + AUDIO_CHUNK + AUDIO_END, and logs/validates every backend frame, saving received TTS audio to `./received_from_backend/`. |
| `test_gemini_tts.py` | Python | Quick standalone Gemini TTS smoke test — verifies the configured TTS model/voice produces audio and writes `gemini_tts_test.wav`, independent of the turn pipeline. |

---

## Folder: `app/`

Purpose: the FastAPI application package — entrypoint, configuration, wire protocol, per-lamp session state, and startup self-tests. File types: `.py` modules + one `.md`.

| File | Type | Purpose |
|---|---|---|
| `app/__init__.py` | Python | Package initializer (empty). |
| `app/config.py` | Python | Pydantic-settings + dotenv loader — the canonical source of all configurable behaviour (LLM provider/keys, TTS, auth, storage, thinking budgets, tier-escalation thresholds, timeouts). |
| `app/logging.py` | Python | Configures centralized logging idempotently at startup (timestamps, SQL echo, pool events) at the configured verbosity. |
| `app/main.py` | Python | FastAPI entrypoint — lifespan hooks (DB/Redis/TTS warmup + graceful shutdown), exception handlers (422/500/unhandled), request-tracing middleware, and route mounting. |
| `app/protocol.py` | Python | Wire-protocol primitives — `FrameType` enums (image/audio/TFT/debug), state bytes (idle/listening/thinking/speaking/error), and hard size guards (WS message ≤ 4 KB to avoid lamp bad_alloc reboots). |
| `app/session.py` | Python | Per-WebSocket lamp `Session` — accumulates chunked image/audio into `Turn` objects, gates on duration, dispatches turns, and enforces half-duplex audio safety with PCM/ADPCM/Opus codec support. |
| `app/startup.py` | Python | Boot-time self-tests — verify the configured LLM provider has a key + SDK loaded, and render proven LaTeX samples to catch matplotlib-subset drift before the first turn. |
| `app/LAYOUT.md` | Markdown | (See root docs) maps the design doc's folder layout onto the actual `app/` package. |

---

## Folder: `app/db/`

Purpose: SQLAlchemy ORM models for the full durable schema plus the lazy async engine/session factory. File types: `.py`.

| File | Type | Purpose |
|---|---|---|
| `app/db/__init__.py` | Python | Package initializer (empty). |
| `app/db/models.py` | Python | All SQLAlchemy ORM models — Device/PairingCode (auth), UserProfile/SessionRecord/TurnRecord (persistence), TurnTrace (audit), UserMemory/Event/CostLog (analytics), Admin (allowlist), the ModelProvider/Request/Response/Feedback bench tables, plus the **new** pilot tables (TurnFeedback, SurveyResponse, ProblemReport, StudentPersonalization, UserConsent), the tagger tables (SyllabusTopic, TurnTopic, TurnMistake), and FirmwareRelease (OTA). `user_profiles` gained a `cohort` column and turn rows gained the rich-analytics columns. |
| `app/db/session.py` | Python | Lazy async SQLAlchemy engine + session factory (built on first `DATABASE_URL` use), Supabase SSL auto-detection, and additive-column migrations for backward-compatible schema evolution. |

### Folder: `app/db/migrations/`

Purpose: Alembic migration folder. File types: placeholder.

| File | Type | Purpose |
|---|---|---|
| `app/db/migrations/.keep` | Placeholder | Keeps the empty Alembic migrations directory tracked in git. |

---

## Folder: `app/deps/`

Purpose: FastAPI `Depends` helpers for authentication, admin gating, and rate limiting. File types: `.py`.

| File | Type | Purpose |
|---|---|---|
| `app/deps/__init__.py` | Python | Package initializer (empty). |
| `app/deps/admin.py` | Python | Dependency that verifies Clerk auth then gates `/api/frontend/admin/*` routes against the `admins` table allowlist, returning the verified Clerk user_id. |
| `app/deps/clerk.py` | Python | Clerk session-token verifier for HTTP routes — validates Bearer tokens against Clerk's JWKS (cached, concurrency-collapsed), supports `azp` matching, returns the user_id. |
| `app/deps/clerk_ws.py` | Python | Clerk JWT verifier for WebSocket handshakes (`/api/frontend/ws`) — decodes the `?token=` query param via PyJWT + JWKS, raising `WsAuthError` on failure. |
| `app/deps/device_auth.py` | Python | Device-secret auth helpers — `hash_secret()` (argon2id one-way) and `verify_secret()` (constant-time, no exception leaks). |
| `app/deps/rate_limit.py` | Python | slowapi rate-limiter singleton — per-remote-IP buckets backed by Redis (or in-memory fallback), swallowing storage errors so a dead Redis doesn't brick the frontend. |

---

## Folder: `app/formatting/`

Purpose: formats reply content for the lamp's 320×240 TFT display. File types: `.py`.

| File | Type | Purpose |
|---|---|---|
| `app/formatting/__init__.py` | Python | Package initializer (empty). |
| `app/formatting/tft_formatter.py` | Python | Enforces the TFT constraint by truncating display content to ≤ 4 lines (ellipsis for non-LaTeX text). |
| `app/formatting/track_router.py` | Python | Two-track formatting — routes display content (LaTeX vs plain) by exam track (technical allows LaTeX; conceptual downgrades to plain text). |

---

## Folder: `app/prompts/`

Purpose: system-prompt text kept separate so token-economy edits stay localized. File types: `.py`.

| File | Type | Purpose |
|---|---|---|
| `app/prompts/__init__.py` | Python | Package marker (empty). |
| `app/prompts/_guardrails.py` | Python | **(new)** `GUARDRAILS` — the always-on SAFETY/SCOPE/INPUT-HIERARCHY/PRIVACY boundary block injected into BOTH surface prompts (lamp `turn1_system` + web `gemini_brain`); prompt-side companion to `input_guard`/`output_validator`. |
| `app/prompts/_latex_rules.py` | Python | Shared matplotlib-mathtext subset rules (forbidden commands, width/height limits) injected into prompts to prevent TFT render crashes. |
| `app/prompts/classifier.py` | Python | Returns a query-classification prompt that parses questions into JSON (query_type, subject, exam_type, difficulty, grounding needs). |
| `app/prompts/conceptual_module.py` | Python | Pedagogy rules for the conceptual track (UPSC/CAT/SSC) — logic/analogies/plain text over derivations. |
| `app/prompts/escalation.py` | Python | Low-confidence escalation prompt instructing the fallback model to re-solve from scratch and report honest confidence. |
| `app/prompts/technical_module.py` | Python | Pedagogy rules for the technical track (JEE/GATE) — strict derivations, LaTeX equations, exact constants. |
| `app/prompts/turn1_system.py` | Python | Main fresh-question system prompt — the Socratic lamp tutor, image classification, multi-part focus logic, output schema (speech/display/latex_equations), and optional perceived-question echo. |
| `app/prompts/turn2_system.py` | Python | Follow-up system prompt for the same problem — escalation by attempt_count (hint at 2, solve at 3+) and MSM handoff. |

### Folder: `app/prompts/_unused/`

Purpose: deprecated/orphaned prompt variants no longer matching the current `LlmReply` schema, kept for reference. File types: `.py`, `.md`.

| File | Type | Purpose |
|---|---|---|
| `app/prompts/_unused/README.md` | Markdown | Documents why these prompts are orphaned (outdated schema/field names) and that they are reference-only. |
| `app/prompts/_unused/classifier.py` | Python | Deprecated classifier using an outdated query_type taxonomy and JSON fields. |
| `app/prompts/_unused/conceptual_module.py` | Python | Deprecated conceptual-track rules, orphaned when unified into turn1/turn2. |
| `app/prompts/_unused/escalation.py` | Python | Deprecated escalation prompt referencing non-existent fields (voice_output, is_confident). |
| `app/prompts/_unused/technical_module.py` | Python | Deprecated technical-track rules using inline `$...$` LaTeX, contradicting the current `latex_equations[]` design. |
| `app/prompts/_unused/turn2_system.py` | Python | Deprecated turn-2 prompt with an incompatible JSON shape and outdated escalation rules. |

---

## Folder: `app/providers/`

Purpose: vendor SDK adapters — the LLM brains, TTS engines, and image/audio/LaTeX preprocessing. File types: `.py`.

| File | Type | Purpose |
|---|---|---|
| `app/providers/__init__.py` | Python | Package marker (empty). |
| `app/providers/audio_preprocessor.py` | Python | Wraps raw int16-LE PCM (16 kHz mono) from the lamp as a WAV blob so Gemini's `generateContent` accepts it without a 400. |
| `app/providers/document.py` | Python | **(new)** Scrollable-document (`TFT_SCROLL_DOC`) composer — turns an `LlmReply` into an ORDERED list of BLOCKS (native text / equation JPEG / graph JPEG / chem JPEG) the lamp stacks + scrolls; reflows for any panel size; serializes a wire manifest. Fail-open. |
| `app/providers/gemini_brain.py` | Python | Web-bench Gemini multimodal interface (separate from the lamp's `llm_gemini`) that renders KaTeX in-browser; includes simulator + structured-response helpers. |
| `app/providers/graph_renderer.py` | Python | **(restored/expanded)** Graph renderer — a `GraphSpec` (function/parametric/implicit) → matplotlib (restricted-AST safe-eval, dark theme, asymptote handling) → color JPEG + rendered-window tuple for the lamp's interactive pan/zoom arena. Gated `GRAPH_ENABLED`. |
| `app/providers/grounding.py` | Python | Mock Google-Search grounding-context provider for UPSC/SSC current-affairs questions needing post-2024 verification. |
| `app/providers/rdkit_renderer.py` | Python | **(new)** RDKit 2D molecular-structure depiction — a SMILES or reaction SMILES (`A.B>>C.D`) → skeletal drawing → color JPEG fit to the panel. Gated `CHEM_STRUCTURE_ENABLED`; no-op if `rdkit` absent. |
| `app/providers/image_preprocessor.py` | Python | Enhances lamp camera JPEGs (denoise, deskew, CLAHE, unsharp) and downscales for VLM ingestion; falls back to PIL when OpenCV is absent. |
| `app/providers/latex_engine.py` | Python | Matplotlib-mathtext → RGB565 renderer for the 320×240 TFT — equation scaling, horizontal scroll animation, and eqN label badges. |
| `app/providers/latex_renderer.py` | Python | Thin wrapper over `latex_engine.py` — orchestrates multi-equation packing, per-equation frame budgets, Redis caching, and progressive dispatch. |
| `app/providers/llm_base.py` | Python | Abstract `LlmProvider` interface + `@register_provider` factory + thinking/code-execution helpers; all providers implement this contract. |
| `app/providers/llm_claude.py` | Python | Claude Sonnet 4 provider — text+image support with inline Groq Whisper STT for audio transcription. |
| `app/providers/llm_deepseek.py` | Python | DeepSeek chat provider stub — text-only input with inline Groq STT; image captioning left as TODO. |
| `app/providers/llm_gemini.py` | Python | Reference Gemini 2.5/3.x Flash multimodal provider — audio+image, schema-constrained JSON, thinking budgets, code-execution sandbox, and retry logic. |
| `app/providers/llm_openai.py` | Python | GPT-4o provider stub — audio+image via base64 with JSON mode. |
| `app/providers/tts_base.py` | Python | Abstract `TtsProvider` interface + factory; all engines implement a streaming `synthesize()` for low-latency first audio. |
| `app/providers/tts_cartesia.py` | Python | **(now LIVE)** Cartesia Sonic streaming-TTS adapter — streaming `POST https://api.cartesia.ai/tts/bytes` via httpx, requesting the lamp wire format directly (24 kHz int16 PCM, no resample), `incremental=True` (~170 ms first byte, no daily cap). |
| `app/providers/tts_gemini.py` | Python | Gemini TTS provider streaming 24 kHz mono PCM — reuses the warm genai client and falls back from streaming to unary on pre-output errors. |
| `app/providers/tts_piper.py` | Python | Self-hosted Piper TTS — warm in-process `.onnx` voice (or subprocess fallback), resamples to 24 kHz and chunks ≤ 4 KB for lamp DRAM. |
| `app/providers/web_simulator.py` | Python | Deterministic fallback brain for the web bench when `GEMINI_API_KEY` is unset — streams fake thinking/speaking/idle states with a canned Socratic reply. |

---

## Folder: `app/routes/`

Purpose: every HTTP + WebSocket endpoint — the gateway/edge layer. File types: `.py`.

| File | Type | Purpose |
|---|---|---|
| `app/routes/__init__.py` | Python | Package marker (empty). |
| `app/routes/admin.py` | Python | System-wide read dashboard (`/api/frontend/admin/*`) — health overview, **performance** (per-stage latency), per-model eval stats, user/device/session/turn lists, turn traces, media storage + cleanup, and the **OTA release console** (publish/list/delete firmware); all gated on `require_admin`. |
| `app/routes/admin_pilot.py` | Python | **(new)** Admin pilot rollups (`/api/frontend/admin/pilot/*`) — cohorts, activation funnel, feedback summary, survey results, problem-report queue + the single triage write; `require_admin`. |
| `app/routes/clerk_webhook.py` | Python | Receives signed Clerk `user.deleted` events (`POST /api/clerk/webhook`) — revokes paired devices, publishes revocation signals, and clears conversation history. |
| `app/routes/insights.py` | Python | **(new)** Admin learning-analytics (`/api/frontend/admin/pilot/insights/*`) — topic strength, syllabus coverage, engagement, mistakes, quality; cohort/exam filterable; `require_admin`. |
| `app/routes/ota.py` | Python | **(new)** Lamp-facing firmware OTA (`/lamp/ota/version` plain-text poll + `/lamp/ota/firmware.bin`); mounted UNCONDITIONALLY (no auth) so a lamp can always self-update. |
| `app/routes/pilot.py` | Python | **(new)** Student-facing pilot instrumentation (`/api/frontend/pilot/*`) — turn feedback, surveys, one-tap problem reports (+ email alert), preference profile, consent log; Clerk-gated. |
| `app/routes/device_lamp.py` | Python | Two public lamp endpoints — `POST /api/device/register` (first-boot + pairing-code mint, idempotent) and `POST /api/device/poll-pairing` (lamp polls every 3 s). |
| `app/routes/device_user.py` | Python | Frontend device CRUD (Clerk-gated) — `complete-pairing`, `GET /api/devices`, `unlink`, `rename`. |
| `app/routes/frontend_manager.py` | Python | Web app identity/profile/analytics + brain-bench surface — `me`, `profile` (GET/PUT), `analytics`, `simulate`, `models`, `solve`, and `solve/compare`. |
| `app/routes/health.py` | Python | Liveness (`GET /healthz`) and readiness (`GET /readyz`) probes; readiness checks Postgres, Redis, and LLM provider keys. |
| `app/routes/pairing_info.py` | Python | Public read-only `GET /api/pairing-info/{code}` for the frontend `/pair/[code]` page (device name, expiry) without auth leakage. |
| `app/routes/ws_lamp.py` | Python | WebSocket endpoint `ws /lamp/ws` for the lamp — dev-bypass or production JWT auth, optional revocation watcher + heartbeat, and idle-timeout backstop. |

---

## Folder: `app/schemas/`

Purpose: pydantic v2 request/response contracts. File types: `.py`.

| File | Type | Purpose |
|---|---|---|
| `app/schemas/__init__.py` | Python | Package marker (empty). |
| `app/schemas/admin.py` | Python | Admin-dashboard response models — health snapshot, cost summary, daily activity, user/device/session/turn rows (+ cohort tag + §13 analytics), turn-trace audit, **performance** (`AdminPerfOut`), **OTA release** metadata, media storage, and multi-LLM eval stats. |
| `app/schemas/admin_pilot.py` | Python | **(new)** Admin pilot response models — feedback summary, confidence deltas, survey results, problem-report rows + status, activation funnel, cohort list (all defaulted → empty not 500). |
| `app/schemas/auth.py` | Python | Pairing contracts — lamp-facing `DeviceRegisterIn/Out` + `DevicePollIn/Out`, frontend-facing `CompletePairingIn/Out`, `DeviceList*`, `DeviceRename*`, and shared `PairingInfoOut`. |
| `app/schemas/frontend.py` | Python | Identity/profile/analytics shapes — `MeOut`, `ProfileIn/Out` (onboarding form), `AnalyticsOut`, `AnalyticsDetailOut`; `RecentTurn` gained `turn_id`/`feedback` (pilot 👍/👎 pre-fill). |
| `app/schemas/insights.py` | Python | **(new)** Insights response models — `TopicStrengthOut`/`TopicRow`, `CoverageOut`, `EngagementOut`, `MistakesOut`, `QualityOut` (every field defaulted). |
| `app/schemas/llm_response.py` | Python | The lamp's LLM reply contract — `Display`/`GraphCurve`/`GraphSpec`/`ChemStructure` + the **29-field** `LlmReply` (speech, display, latex_equations, **graph**, **structures**; analytics, `is_mcq`, gated rich-analytics + hidden verifier fields, memory, audit) with a tolerant validator, canned fallbacks, and the feature-gated `response_schema` twin `llm_reply_schema(...)`. |
| `app/schemas/model_eval.py` | Python | Multi-LLM bench models — `ModelInfo`, `ModelsOut`, `AutoStep`, `SolveMeta`, `SolveOut`, `CompareOut`, and `FeedbackIn/Out`. |
| `app/schemas/pilot.py` | Python | **(new)** Student pilot request/response models — `TurnFeedbackIn/Out`, `SurveyIn/Out`, `SurveyStatusOut`, `ProblemReportIn/Out`, `PersonalizationIn/Out`, `ConsentIn/Out`. |

---

## Folder: `app/services/`

Purpose: orchestration + business logic — the turn pipeline, escalation, memory, analytics, and auth services. File types: `.py`.

| File | Type | Purpose |
|---|---|---|
| `app/services/__init__.py` | Python | Package marker (empty). |
| `app/services/admin.py` | Python | System-wide analytics + admin-dashboard queries (savepoint-guarded); `is_admin()` checks the DB `admins` allowlist. Grew with `latency_breakdown` (performance), `model_stats` (bench dashboard), and cohort-tag reads. |
| `app/services/admin_pilot.py` | Python | **(new)** Admin pilot rollup service (raw SQL, reuses `admin._rows`/`_scalar`) — feedback summary, survey results (confidence deltas/NPS), problem-report queue + status write, activation funnel, cohort list. |
| `app/services/analytics.py` | Python | Per-user dashboard analytics (device count, turns, subjects) with graceful degradation when tables are unmigrated. |
| `app/services/cache.py` | Python | Optional Redis cache seam for admin analytics + session state; no-op without `REDIS_URL` (all callsites have a Postgres fallback). |
| `app/services/error_messages.py` | Python | **(new)** User-facing error catalog — `classify(text/status)` → category and `tft_line(subsystem, category)` → an ASCII TFT line (e.g. "Tutor - daily limit reached", "Voice off - servers busy"). |
| `app/services/input_guard.py` | Python | **(new)** Child-safety + prompt-injection guard — `screen_input`/`screen_output_text` classify distress/dangerous/sexual/injection; `safe_reply` returns a deterministic redirect. Tuned near-zero false positives on homework. |
| `app/services/insights.py` | Python | **(new)** Admin learning-analytics service — topic strength (0-100 struggle score), syllabus coverage, engagement (DAU/WAU/MAU, streaks), mistakes, quality; joins the offline tag tables, cohort/exam scoped. |
| `app/services/math_verifier.py` | Python | **(new)** Numpy-free AST verifier — independently recomputes the answer from the reply's hidden `equation`/`given` fields and checks chemistry atom-balance/molar-mass; DISAGREE is an escalation signal, never a replacement. |
| `app/services/mistake_tagger.py` | Python | **(new, offline)** Classifies a turn's student-error type into a fixed 8-category taxonomy (`MISTAKE_TYPES`) via keyword pre-pass + Gemini; writes `turn_mistakes`. |
| `app/services/notify.py` | Python | **(new)** Best-effort outbound email (problem-report alerts) via stdlib `smtplib`+STARTTLS; fire-and-forget, OFF until SMTP creds set. |
| `app/services/ota_release.py` | Python | **(new)** Firmware-release store — the `.bin` lives in Postgres (`firmware_releases.bin`); `publish`/`current_meta`/`current_bin`/`list_releases`/`delete_release`, keeps newest 5. |
| `app/services/output_validator.py` | Python | **(new)** The post-parse/pre-dispatch deterministic gate — ordered checks (output-safety REPLACE, speech/display purity, render FLAG, voice caps, dangling-eqn FLAG); pure + fail-open. |
| `app/services/render_check.py` | Python | **(new)** Fast syntactic render-heuristic (brace/`$`/`\left`-`\right` balance + tiny denylist, `lru_cache`) used FLAG-only by the output validator; never test-renders, never false-fails valid chemistry. |
| `app/services/topic_tagger.py` | Python | **(new, offline)** Maps a turn to one `syllabus_topics` row — deterministic keyword scorer first, Gemini disambiguation for ambiguous cases; writes `turn_topics`. |
| `app/services/device_jwt.py` | Python | HS256 device-JWT mint/verify for lamp pairing (no expiry; revocation checked at WS-connect via `devices.revoked_at`). |
| `app/services/dispatch.py` | Python | Layer 5.3 reply dispatcher — orchestrates parallel TTS audio + LaTeX equation rendering (progressive multi-frame delivery, audio-first gating). |
| `app/services/escalation_router.py` | Python | Deterministic pre-LLM tier-router — picks the starting tier from image-quality + text-pattern rules (prove/derive/JEE/diagram/MCQ detection). |
| `app/services/image_prep.py` | Python | Early image enhancement + Gemini Files API pre-upload kicked off while the student speaks (zero hot-path cost via a parallel awaited task). |
| `app/services/media_cleanup.py` | Python | Manual admin media-retention — batched blob delete + URL-column nulling for turns older than N days (fire-and-forget, never auto-purge). |
| `app/services/memory.py` | Python | Redis short-term history (Layer 3.2) — last 3 turns per device, loaded plaintext for LLM context, pushed fire-and-forget after a turn. |
| `app/services/model_catalog.py` | Python | Single source of truth for the multi-LLM models (Gemini/GPT/Claude/DeepSeek) + pricing — the dropdown source and cost estimator for `/solve`. |
| `app/services/model_solver.py` | Python | Provider-agnostic `generate_solution` dispatcher with a unified output schema; non-ok turns return a graceful fallback without raising. |
| `app/services/orchestrator.py` | Python | **The turn-pipeline brain** — glues Layers 3–5: history load, pre-router, LLM call, escalation, echo/focus/history-bleed guards, dispatch, and trace finalize. |
| `app/services/pairing.py` | Python | Pairing-code generator — 6-char A-Z0-9 codes via the CSPRNG `secrets` module. |
| `app/services/problem_memo.py` | Python | Solve-once, tutor-many — caches the escalated tier's full solution in Redis, injects it as `[INTERNAL ANSWER KEY]` into tier-1 nudges, flushes on problem mismatch. |
| `app/services/revocation.py` | Python | Redis pub/sub revocation fan-out — publish on unlink; the WS subscriber closes 4402 sub-second on revoke (falls back to polling `devices.revoked_at`). |
| `app/services/session_memory.py` | Python | Three-layer conversation memory (L1 Redis recent / L2 compacted sessions / L3 user profile) — loads into LLM context with background compaction on a turn threshold. |
| `app/services/turn_trace.py` | Python | Passive execution tracer for the admin audit — logs every phase and persists a `turn_traces` row (media URLs, LLM JSON, latencies), gated by `TURN_TRACE_ENABLED`. |

> `turn_handler.py` and `validator.py` (the old "BAO" prototype) were **moved to `app/legacy/`** (see that folder below); `tests/test_no_legacy_imports.py` fails CI if `app/` re-imports them.

---

## Folder: `app/storage/`

Purpose: Layer 9 off-hot-path durable persistence — turns, blobs, events, pgvector memory, and profiles. File types: `.py`.

| File | Type | Purpose |
|---|---|---|
| `app/storage/__init__.py` | Python | Package docstring describing Layer 9 off-hot-path persistence (turns, blobs, pgvector memory). |
| `app/storage/blobs.py` | Python | Audio+image blob uploader (Layer 9.2) — local/S3/R2 backend dispatch, best-effort crash-safe (failures → NULL URLs, turn proceeds). |
| `app/storage/dev_capture.py` | Python | Dev-only per-turn folder dump of raw+enhanced images + audio + LLM JSON (gated by `DEV_CAPTURE_DUMP`; OFF by default). |
| `app/storage/events.py` | Python | Generic lifecycle/audit-log writer — `log_event` opens a short-lived session (fire-and-forget, DB-gated) for events (paired/unlinked/ws_open/reboot/…). |
| `app/storage/memory_vec.py` | Python | pgvector long-term ANN memory stub (Layer 3.3) — deferred; would embed (turn, answer) pairs for cross-session continuity lookup. |
| `app/storage/model_eval.py` | Python | Multi-LLM bench persistence — `model_requests`/`model_responses`/`model_feedback` tables + catalog seeding to `model_providers` (fire-and-forget, DB-gated). |
| `app/storage/pilot.py` | Python | **(new)** Pilot persistence (DB-gated, crash-safe) — UPSERT turn feedback, submit/append surveys, problem reports, personalization, consent; tables `turn_feedback`/`survey_responses`/`problem_reports`/`student_personalization`/`user_consents`. |
| `app/storage/turns.py` | Python | Session+turn writer (Layer 9.1) — atomically INSERTs turns + bumps `session.turn_count`, resumes/opens sessions with Redis cache + Postgres fallback. Now also persists behavioural bools + inline rich-analytics columns (`topic`/`concepts`/`error_type`, gated `RICH_ANALYTICS_ENABLED`). |
| `app/storage/user_memory.py` | Python | L3 learner-profile CRUD (`user_memory` table) — cross-session subject/difficulty profile + LLM-distilled summary, read into context via `session_memory.py`. |
| `app/storage/user_profiles.py` | Python | Web onboarding-profile CRUD (`user_profiles` table) — upsert-on-conflict preserving `created_at`, JSONB-merging `extra` (learning style, focus subject, …). |

---

## Folder: `app/workers/`

Purpose: deferred async background jobs (Layers 9.3/9.4). The transcribe/embed/rollup trio are still stubs; the **topic/mistake taggers are real** offline batch workers. File types: `.py`.

| File | Type | Purpose |
|---|---|---|
| `app/workers/__init__.py` | Python | Package docstring describing the async background jobs (transcribe/embed/rollup) and three deployment patterns (Arq/Celery/Temporal). |
| `app/workers/embed.py` | Python | Embedding worker stub (Layer 3.3) — deferred; would embed turn (transcript, response) into pgvector after transcribe writes `turns.transcript`. |
| `app/workers/mistake_tag.py` | Python | **(new, real)** Offline mistake-tag batch worker — anti-join poll of un-tagged `status='ok'` turns → `mistake_tagger` → UPSERT `turn_mistakes`; `run_batch`/`tag_all`, crash-safe, never raises. |
| `app/workers/rollup.py` | Python | Daily metrics-rollup stub (Layer 9.4) — deferred; would REFRESH a materialized view of per-day turns/cost/latencies for Metabase/Grafana. |
| `app/workers/topic_tag.py` | Python | **(new, real)** Offline topic-tag batch worker — anti-join poll → `topic_tagger` (keyword→LLM) → UPSERT `turn_topics`; `run_batch`/`tag_all`, crash-safe, never raises. |
| `app/workers/transcribe.py` | Python | Offline transcription worker stub (Layer 9.3) — deferred; would fetch `audio_url`, call Groq Whisper Large v3, and UPDATE `turns.transcript`. |

---

## Folder: `audio-tts/`

Purpose: self-hosted Piper TTS voice models (weights + config) used by `providers/tts_piper.py`. File types: `.onnx`, `.json`.

| File | Type | Purpose |
|---|---|---|
| `audio-tts/en_US-amy-low.onnx` | ONNX model | Piper "Amy" US-English voice weights, low quality (smaller/faster). |
| `audio-tts/en_US-amy-low.onnx.json` | JSON | Piper voice config (sample rate, phoneme map, inference settings) for the low-quality Amy voice. |
| `audio-tts/en_US-amy-medium.onnx` | ONNX model | Piper "Amy" US-English voice weights, medium quality (better/slower). |
| `audio-tts/en_US-amy-medium.onnx.json` | JSON | Piper voice config for the medium-quality Amy voice. |

---

## Folder: `.github/workflows/` **(new 2026-07-06)**

Purpose: GitHub Actions CI for the backend branch. File types: `.yml`.

| File | Type | Purpose |
|---|---|---|
| `.github/workflows/backend-ci.yml` | YAML workflow | The backend CI gate (improvment/08 §6.4) — on push/PR to `backend`: ruff lint + the offline pytest suite on Python 3.11. No provider keys — live-model tests and rdkit-dependent tests are excluded; the live golden-set eval is a separate key-bearing job. |

---

## Folder: `evals/` **(new 2026-07-06)**

Purpose: the offline golden-set accuracy harness — the measurement layer for the >95%-answer-accuracy target (improvment/08 §6). Turns "accuracy" from a vibe into a number with a confidence interval. See `02-backend/13-brain-optimization-eval-harness-and-ci.md`. File types: `.py`, `.jsonl`, `.md`, `.gitkeep`.

| File | Type | Purpose |
|---|---|---|
| `evals/README.md` | Markdown | How to run the harness (selftest / live / sliced / paired comparison) and the rules that keep it honest (programmatic primary metric — no LLM judge for answer accuracy). |
| `evals/graders.py` | Python | Deterministic grading (numeric tolerance, option letter/value, string alternatives) + Wilson CI + McNemar. No network; unit-tested by `tests/test_evals_graders.py`. |
| `evals/run_evals.py` | Python | Drives the REAL backend brain (`model_solver`) over the case files; `--selftest` runs offline, `--model`/`--limit` slice live runs. |
| `evals/report.py` | Python | One-run summary, or PAIRED McNemar comparison of two result files (the honest before/after). |
| `evals/cases/jee_physics.jsonl` | JSONL golden set | Seed JEE physics cases (one JSON case per line; schema in `graders.py`). |
| `evals/cases/jee_math.jsonl` | JSONL golden set | Seed JEE mathematics cases. |
| `evals/cases/jee_chemistry.jsonl` | JSONL golden set | Seed JEE chemistry cases. |
| `evals/cases/neet_biology.jsonl` | JSONL golden set | Seed NEET biology cases. |
| `evals/cases/refusal_and_perception.jsonl` | JSONL golden set | Refusal/safety + image-perception cases. |
| `evals/results/.gitkeep` | Placeholder | Keeps the (otherwise gitignored) timestamped run-output folder tracked. |

---

## Folder: `scripts/`

Purpose: live + dry-run test harnesses, model-capability probes, the mock lamp pointer, SQL setup, and audio fixtures. File types: `.py`, `.sql`, `.wav`.

| File | Type | Purpose |
|---|---|---|
| `scripts/admin_setup.sql` | SQL | Creates the admin-dashboard SQL objects (the `admins` allowlist table with RLS, seeding the first admin by email/Clerk ID). |
| `scripts/check_minimal_live.py` | Python | One live tier-1 Flash-Lite call with zero thinking budget to confirm minimal thinking tokens + clean JSON parsing (~$0.002). |
| `scripts/check_thinking_map.py` | Python | Offline unit check of the 4-level `thinking_level` budget mapping for Gemini models across tiers. |
| `scripts/conversation_dryrun.py` | Python | Live conversational-flow test through the real pipeline (`_solve_auto` with real memory writes) — multiple problems, follow-ups, recall, content-bleed prevention. |
| `scripts/dispute_semantic_dryrun.py` | Python | Proves the semantic-dispute backstop — disputes route to tier-3, checks stay at tier-2 without interference. |
| `scripts/dryrun_tts_codecs.py` | Python | Full-chain dry run of the lamp TTS wire codecs (pcm/adpcm/opus) validating `Session.stream_audio_out` against firmware codec decoding + wire-contract assertions. |
| `scripts/e2e_auto_live.py` | Python | Full live end-to-end — frontend `/api/frontend/solve` HTTP + firmware `TurnOrchestrator.run_turn` with real Gemini, JEE audio, and escalation/gate-consistency assertions. |
| `scripts/e2e_dryrun.py` | Python | Full-stack dry run simulating the ESP32's exact wire role against a live local backend (payload sizes, TFT commit/append, LaTeX packing, ADPCM, frame ordering). |
| `scripts/e2e_jee_question.wav` | Audio fixture | Sample audio fixture used by e2e scripts (a JEE physics question). |
| `scripts/e2e_question.wav` | Audio fixture | Sample audio fixture used by e2e scripts (a generic question). |
| `scripts/fallback_live_smoke.py` | Python | Live smoke test of the Claude fallback — forced Gemini timeout → Claude answers reusing the Groq transcript, with fallback telemetry + cost recording. |
| `scripts/falsealarm_dryrun.py` | Python | Live proof of the false-alarm guard — correct work is affirmed, genuine arithmetic errors still caught, and the dispute guard coexists. |
| `scripts/focus_dryrun.py` | Python | Live end-to-end test of the focus stack + nudge interplay on a multi-question JEE page (dynamic targets, label backstop, guard recovery, reveal authorization). |
| `scripts/groq_check.py` | Python | Validates the Groq API key and lists models, flagging the Whisper STT models the pre-router uses (no audio billed). |
| `scripts/harmony_dryrun.py` | Python | Fresh-POV test that the dispute guard and false-alarm guard work in harmony (dispute correct → confirm; dispute wrong → correct). |
| `scripts/history_bleed_dryrun.py` | Python | Live replay of the history-bleed bug fix — the problem-switch memo flush prevents old context bleeding via `same_problem` + NEW-PROBLEM marker. |
| `scripts/journey_dryrun.py` | Python | End-to-end live walkthrough of the tiered-tutor flow with every decision logged (tier-1 → gate → flash→Pro handoff → memo → keyed nudges → flush). |
| `scripts/mock_lamp.py` | Python | Pointer to the canonical lamp simulator (`dummy_client.py` at repo root) that mimics the wire protocol without the physical ESP32. |
| `scripts/newdev_dryrun.py` | Python | Live test of the new-developments / image-freshness heads-up — the model re-reads a re-uploaded image instead of assuming continuity. |
| `scripts/nudge_dryrun.py` | Python | Live simulation of the nudge gate (solve-reveal policy) on a real JEE image — counter bumps, soft/hard frustration thresholds, first-attempt denial, memo flush. |
| `scripts/probe_code_execution.py` | Python | Probe: does Gemini's code-execution tool combine with `response_schema` + `thinking_level` at tier-3 before wiring `GEMINI_TIER3_CODE_EXECUTION`. |
| `scripts/probe_flash_lite.py` | Python | Live de-risking probe for migrating tiers 1/2 to Gemini-3.x Flash-Lite — model-ID discovery, structured output, latency, thinking floor, code-exec, audio gate. |
| `scripts/probe_flash_lite_ga.py` | Python | Verifies the GA-vs-preview + `thinking_level` claims live — reachability of the GA Flash-Lite id, accepted presets, and THOUGHT tokens drawn. |
| `scripts/probe_flash_lite_raw.py` | Python | Raw-API checks for the code-exec combo (Flash-Lite 3.x ok, 2.5-flash 400) and the audio gate, using synchronous genai calls outside an event loop. |
| `scripts/probe_outline_ab.py` | Python | A/B probe: does attaching code-execution to Gemini-3.1-Pro cause it to skip optional schema fields (solution_outline / problem_statement). |
| `scripts/probe_t5.py` | Python | Focused retest that an authorized reveal states the FINAL ANSWER — seeds a real Q3 memo and runs one keyed flash call with `[SOLVE AUTHORIZED]`. |
| `scripts/probe_tier1_codeexec.py` | Python | Measures whether code-exec at tier-1 on Flash-Lite pays off (OFF vs ON for wall time, tokens, cost, loop detection). |
| `scripts/probe_verify_by_code.py` | Python | Plan-B proof — with the strengthened SOLVE_SUFFIX, does Pro actually run substitution-back code via `executable_code` + `code_execution_result`. |
| `scripts/qcap_dryrun.py` | Python | Live end-to-end test of `MEMO_CAPTURE_QUESTION` — question capture in non-escalated + escalated cases, flush on new problem, no regression of existing behavior. |
| `scripts/relevance_dryrun.py` | Python | Live checks that the escalation plan is intact, no answer bleed before nudge-gate authorization, and relevance inference captures problem values not noise. |
| `scripts/semantic_escalation_dryrun.py` | Python | Proves the `SEMANTIC_CHECK_ESCALATION` fix — deterministic routing for check/mistake_id vs non-check, plus a live paraphrased check that escalates and affirms. |
| `scripts/stress_lamp_ingest.py` | Python | Heavy ESP32→backend ingest stress on the real `/lamp/ws` stack (Files pre-upload, JPEG magic guard, abandon-flush) — never freezes, multi-image turns assemble. |
| `scripts/timeout_retry_check.py` | Python | Unit check of the lamp timeout-retry — one stalled call gets one fresh retry; two timeouts fall back (capped), mocking `GeminiProvider._drain`. |
| `scripts/wiring_dryrun.py` | Python | Proves every refined feature is actually wired into both production paths (lamp orchestrator + web `_solve_auto`) using real code with a FAKE LLM (zero API cost). |
| `scripts/cartesia_smoke.py` | Python | **(new)** Standalone Cartesia TTS smoke test — verifies streaming `POST /tts/bytes` produces 24 kHz PCM. |
| `scripts/streaming_probe.py` | Python | **(new)** Probes TTS streaming first-byte latency + chunk cadence. |
| `scripts/tag_topics.py` | Python | **(new)** CLI backfill/cron entrypoint for the offline topic tagger (`--limit/--once/--no-llm/--model`) → `turn_topics`. |
| `scripts/tag_mistakes.py` | Python | **(new)** CLI backfill/cron entrypoint for the offline mistake tagger → `turn_mistakes`. |
| `scripts/check_verdict_dryrun.py` | Python | **(new)** Dry-run of the check-verdict guard (verify-before-accuse, confirm-and-stop, first-error-only). |
| `scripts/fixes_dryrun.py` | Python | **(new)** Aggregated dry-run proving the batch of nudge/verdict/guard fixes are wired. |

---

## Folder: `tests/`

Purpose: pytest suites (offline-by-default, opt-in live) covering fallback, escalation, dispatch, LLM I/O, and pipeline stress. File types: `.py`, `.keep`.

| File | Type | Purpose |
|---|---|---|
| `tests/.keep` | Placeholder | Keeps the tests directory tracked in git. |
| `tests/test_admin_fallback_visibility.py` | Python test | Admin-visibility persistence test (no network/DB) — Claude-fallback telemetry and per-turn `cost_usd` computation. |
| `tests/test_claude_fallback.py` | Python test | Forced-failure test of the Claude timeout-fallback — Gemini failure at any tier → Claude re-run at the same tier reusing prompt/history/images/transcript, no Pro escalation. |
| `tests/test_claude_fallback_qa.py` | Python test | QA suite for Groq-STT + Claude-fallback — latency, API-error handling, and regression/isolation (Claude failure never crashes the turn). |
| `tests/test_dispatch_dryrun.py` | Python test | Dry-runs every TFT path (text-only, text+latex sizes, parallel audio/TFT timing) asserting skeleton order, non-blocking, truncation, and multi-frame scroll. |
| `tests/test_escalation_router.py` | Python test | Unit tests for the deterministic pre-router — keyword rules, image-quality gate (synthetic frames), retake short-circuit, tier ceiling clamping, answer-shaping suffix. |
| `tests/test_fallback_continuity.py` | Python test | Cross-brain continuity — a Claude fallback turn persists into the same session memory Gemini reads next turn (L1→L2, no poisoning of failed turns). |
| `tests/test_fallback_strict_invariants.py` | Python test | Adversarial invariants — Gemini success never calls Claude, Claude can't sneak in via a guard re-call, the escalation gate stays intact, error status isn't a fallback trigger. |
| `tests/test_gemini_to_esp_live.py` | Python test | Live end-to-end — real Gemini output → `dispatch.py` → ESP32-parseable frames (the only test making real Gemini calls), proving the output chain on genuine model output. |
| `tests/test_infra.py` | Python test | Infrastructure smoke tests (DB/AUTH/WEBSOCKET) — offline + safe by default, opt-in `RUN_LIVE_DB=1` for a live Supabase round-trip. |
| `tests/test_llm_input.py` | Python test | Offline LLM-input contract test — turn-1 prompt assembly, answer-shaping suffix, deterministic classification → starting tier, image-cleaning robustness. |
| `tests/test_llm_output.py` | Python test | Exhaustive offline LLM-output contract test — `LlmReply` tolerant coercion, fallback/retake canned replies, LaTeX wire contract, dispatch routing, adversarial inputs. |
| `tests/test_orchestrator_preroute.py` | Python test | Integration test of the lamp orchestrator's deterministic pre-router path (mocked LLM + session) — tiering, MCQ suffix, blurry-image retake (zero LLM calls). |
| `tests/test_pipeline_stress.py` | Python test | Stress test of LLM → JSON parser → dispatcher → TTS+TFT with garbage real models produce — never crashes, never TTS on empty speech, always terminal state + status frame. |
| `tests/test_problem_memo.py` | Python test | Deterministic lifecycle test for the solve-once/tutor-many memo (no network) — MATCHED, FLUSH, and REPLACE cases. |
| `tests/test_output_validator.py` | Python test | **(new)** The pre-dispatch output-validator gate — speech/display purity, voice caps, render flag, output-safety REPLACE, dangling-eqn flag. |
| `tests/test_input_guard.py` | Python test | **(new)** The child-safety + injection classifier — catches distress/harm/injection without flagging textbook science. |
| `tests/test_math_verifier.py` | Python test | **(new)** The numpy-free AST + chemistry verifier — agrees on correct projectile/Ohm/combustion answers, disagrees on wrong ones, never false-disagrees. |
| `tests/test_render_check.py` | Python test | **(new)** The syntactic render-heuristic — keeps valid chemistry, flags `\boxed`/`aligned`/broken LaTeX; FLAG-only (never drops). |
| `tests/test_no_legacy_imports.py` | Python test | **(new)** CI guard — fails if any `app/` module imports from `app.legacy`. |
| `tests/test_graph.py` / `tests/test_graph_edge.py` | Python test | **(new)** Graph renderer — function/parametric/implicit specs, safe-eval sandbox, asymptote handling, degenerate/edge cases. |
| `tests/test_chem_structure.py` | Python test | **(new)** RDKit structure rendering — SMILES + reaction SMILES → JPEG, fail-open when rdkit absent. |
| `tests/test_scroll_doc.py` | Python test | **(new)** The scrollable-document composer — block ordering, equation-into-prose splicing, manifest serialization. |
| `tests/test_sync_dispatch.py` | Python test | **(new)** The sync-to-audio dispatch mode — hold-until-first-audio reveal, interleave, JPEG codec path. |
| `tests/test_tts_chunking.py` | Python test | **(new)** TTS sentence-chunking modes (single/hybrid/balanced/full) + one-ahead prefetch. |
| `tests/test_thinking_keepalive.py` | Python test | **(new)** The `_thinking_keepalive` caption pump that keeps the lamp's 45 s watchdog alive during long tier calls. |
| `tests/test_focus_carry.py` | Python test | **(new)** Focus-label persistence across turns (soft anchor unless question-switch). |
| `tests/test_firmware_compat.py` | Python test | **(new)** Firmware backward-compatibility of the wire frames / OTA. |
| `tests/test_tft_image_jpeg.py` | Python test | **(new)** The JPEG equation codec path (`TFT_IMAGE_CODEC="jpeg"`). |
| `tests/test_tester_issue_smoke.py` | Python test | **(new)** Smoke test reproducing tester-reported issues end-to-end. |
| `tests/test_prompt_version_budget.py` | Python test | **(new 2026-07-06)** Enforces `PROMPT_VERSION` semver, byte-stable `get_turn1_prompt()` within a process, prompt char/token budget, newline-prefixed per-turn notes. |
| `tests/test_evals_graders.py` | Python test | **(new 2026-07-06)** Offline unit tests for `evals/graders.py` (grading, Wilson CI, McNemar) — the CI stand-in for the live eval. |

> **Note (2026-07-06):** 13 of the script-style files above (the 2026-07-01→03 "(new)" batch, e.g. `test_graph*`, `test_scroll_doc`, `test_tts_chunking`, `test_tft_image_jpeg`, `test_tester_issue_smoke`) were converted from print-style scripts to real assert-based pytest suites in `db470f6`, so the CI workflow collects them.

---

## Folder: `app/legacy/` (quarantined dead code)

Purpose: CI-guarded quarantine for superseded "BAO architecture" prototype modules. Nothing in the live app imports them, and `tests/test_no_legacy_imports.py` fails CI if `app/` re-imports any of them. File types: `.py`, `.md`.

| File | Type | Purpose |
|---|---|---|
| `app/legacy/README.md` | Markdown | Explains the quarantine and that these are reference-only. |
| `app/legacy/__init__.py` | Python | Package marker. |
| `app/legacy/turn_handler.py` | Python | The old BAO mock turn-handler (superseded by `services/orchestrator.py`). |
| `app/legacy/validator.py` | Python | The old BAO output validator + toy LaTeX-bracket checker (superseded by `services/output_validator.py`). |

> **Deleted since the last sync:** the entire `temp_server_files/` tree (`Latex_engine_tft.py` + the `audio_server/` standalone utilities) was removed from the repo — the LaTeX engine now lives vendored at `app/providers/latex_engine.py`, and the audio path is fully in `app/`.

---

> **Excluded from this catalog:** `__pycache__/` directories, compiled `*.pyc` bytecode, and the `.git/` directory are intentionally not listed.
