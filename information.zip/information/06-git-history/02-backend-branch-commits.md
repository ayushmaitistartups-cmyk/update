# Git History — Backend Branch (full commit log)

This document is the complete, readable history of the **`backend`** branch of the
`ayushmaitistartups-cmyk/Smart-Tutor-Lamp` repository — the FastAPI backend that powers the
Smart Tutor Lamp (an ESP32‑S3 AI tutor lamp). The `backend` branch is an **orphan branch**
(no common ancestor with the `firmware` branch) and is by far the largest history in the project at
**136 commits**, spanning **2026‑05‑26 → 2026‑07‑11** (about seven weeks of intense development).

Three authors contributed:

| Author | Identity | Role (inferred from commits) |
| --- | --- | --- |
| **samiul** | `samiulseikh1221@gmail.com` | Core backend: WebSocket/session pipeline, LLM providers, TTS (incl. Cartesia streaming), memory, escalation, codecs, focus mode, graphs + chemistry/RDKit rendering, OTA, backend dev docs (`docs/`) |
| **shashi-3000** | `shashi.yadav.ug23@nsut.ac.in` | DB/Supabase, admin endpoints, Clerk auth, model‑eval, screen/turns work, reasoning/TTS updates, analytics/pilot/insights |
| **ayushmaitistartups-cmyk** | `ayushmaiti.startups@gmail.com` | Prompt architecture, tiered escalation design, web simulator, graph rendering, nudge/verdict guardrails + output‑validator/math‑verifier, brain‑optimization pass + eval harness + CI (Claude‑assisted; CI later removed), range-aware admin **Analytics tab** + latency/escalation analytics, config-to-prod alignment |

> Note on commit ordering: the table below is **reverse‑chronological** (newest first, hash `5ea5815`
> at the top, oldest `bc4ba83` at the bottom) to match the raw `git log` output. The thematic
> narrative that follows reads **forward in time** (oldest → newest) so the architecture story makes sense.

---

## Table of contents

1. [Summary](#summary)
2. [Full commit table (all 136 commits)](#full-commit-table-all-136-commits)
3. [Thematic narrative](#thematic-narrative)
   - [3.1 FastAPI scaffold & app skeleton](#31-fastapi-scaffold--app-skeleton)
   - [3.2 WebSocket protocol & the lamp session pipeline](#32-websocket-protocol--the-lamp-session-pipeline)
   - [3.3 LLM providers (Gemini, Claude, OpenAI, DeepSeek)](#33-llm-providers-gemini-claude-openai-deepseek)
   - [3.4 Tiered escalation & the deterministic pre-router](#34-tiered-escalation--the-deterministic-pre-router)
   - [3.5 TTS (Piper, Gemini TTS) & audio codecs](#35-tts-piper-gemini-tts--audio-codecs)
   - [3.6 Memory, sessions & vectors](#36-memory-sessions--vectors)
   - [3.7 Auth, pairing & device JWTs](#37-auth-pairing--device-jwts)
   - [3.8 Database, Supabase & admin/analytics](#38-database-supabase--adminanalytics)
   - [3.9 Prompt architecture & the web simulator](#39-prompt-architecture--the-web-simulator)
   - [3.10 Image pipeline, LaTeX rendering & graph rendering](#310-image-pipeline-latex-rendering--graph-rendering)
   - [3.11 Claude fallback work](#311-claude-fallback-work)
   - [3.12 Streaming & chunk mode (final push)](#312-streaming--chunk-mode-final-push)
   - [3.13 Bug fixes & operational hygiene](#313-bug-fixes--operational-hygiene)
   - [3.14 Post‑snapshot work (2026‑06‑17 → 2026‑07‑06)](#314-postsnapshot-work-2026-06-17--2026-07-06)
   - [3.15 Admin Analytics tab + config-to-prod alignment (2026-07-07 → 2026-07-11)](#315-admin-analytics-tab--config-to-prod-alignment-2026-07-07--2026-07-11)
4. [Appendix: authorship & cadence](#appendix-authorship--cadence)

---

## Summary

> **Updates since the 2026‑06‑16 snapshot (36 new commits, through 2026‑07‑06).** The branch
> grew from 81 → **117** commits. Highlights, oldest → newest (detailed in [§3.14](#314-postsnapshot-work-2026-06-17--2026-07-06)):
> - **TTS leads + focus mode** (`027013c`, 06‑17) and a **verbose TFT error path** (`1ca7dcf`).
> - **Tutor nudge/verdict guardrails** (06‑18 → 06‑24): open‑start/recheck/MCQ fixes (`74c3e2f`),
>   objective‑question direct verdict (`dc9a936`), and the **check‑verdict guard + nudge threshold
>   3 → 2** (`8db448f`, 06‑22 — deterministic `check_verdict_note()` / `CHECK_VERDICT_GUARD`, gated
>   behind surrender/dispute/re‑affirm; see [02-backend/03-orchestrator-and-turn-pipeline.md](../02-backend/03-orchestrator-and-turn-pipeline.md) §9.5).
> - **Cartesia streaming TTS** (`667052a`, `2e1542b`, `09ad85f`, 06‑19 → 06‑25) and the second
>   backend **sync merge** `60f9237` (06‑19).
> - **Graphs end‑to‑end** (`47c2a9e`, 06‑26) + **backward‑compatible firmware upgrades** (`a5c7ac2`).
> - **Analytics / pilot / insights** and the **aggregated decomposition** (06‑28).
> - **OTA** (`910303d`), a **code‑enforced output validator + guardrails + math verifier**
>   (`4d79344`, 07‑01), and **chemistry / RDKit rendering** with a UX change (`9cf98ff` → `80f04b6`,
>   07‑02 → 07‑03).
> - **Graph‑UX polish + memory‑leak/CPU‑crash hardening** (`0896f7c`, `a5533e5`, 07‑03 → 07‑04,
>   the iteration‑1 close) — a semaphore‑gated graph renderer, closed matplotlib/HTTP‑client leaks, hard
>   per‑turn buffer ceilings, GRAPH_VIEW request coalescing, and event‑loop‑friendly image‑quality
>   checks (see [§3.14](#314-postsnapshot-work-2026-06-17--2026-07-06)).
> - **Brain‑optimization pass** (`db470f6`, 07‑06, the then‑tip, Claude‑assisted) — math verifier
>   ON by default, `GEMINI_TEMPERATURE` 0.4, an MCQ option‑match check, `PROMPT_VERSION` stamping,
>   a new `evals/` harness, and the branch's first CI workflow (later removed, see below)
>   (see [§3.14](#314-postsnapshot-work-2026-06-17--2026-07-06)).

> **Update (2026‑07‑11): +19 commits, now 136 (tip `5ea5815`).** After the brain‑optimization pass the
> branch adds one wave — a range‑aware admin **"Analytics" tab** — over 2026‑07‑07 → 2026‑07‑11
> (detailed in [§3.15](#315-admin-analytics-tab--config-to-prod-alignment-2026-07-07--2026-07-11)):
> - **Backend dev docs** under `docs/` (samiul `7b1fb94`, `5077d5d`, 07‑07).
> - **Config defaults aligned to production** (`939e0bd`, 07‑08) and the **backend CI workflow removed**
>   (`e53ce33`, 07‑08 — the `.github/workflows/backend-ci.yml` that `db470f6` added on 07‑06 is
>   **added‑then‑removed** across three days).
> - **Range‑aware admin analytics endpoints + model‑selection latency** (`324bc6d`, 07‑09), per‑stage
>   latency instrumentation (equation / TTS / graph‑render in the dispatch paths: `87b4759`, `7a8088d`,
>   `7fd47cd`, `a26a9f5`), and **IST (Asia/Kolkata)** bucketing (`9b245cc`).
> - **Per‑question rows sourced from `turn_traces`** including **failed / cancelled** turns (`f2505a0`),
>   **lamp‑only** filtering + failure Reason (`6adc1d1`), a tier **escalation breakdown / funnel**
>   (`7387ed7`), ending on tip `5ea5815` (question Level + per‑question escalation).
> - A **Gemini "Tutor unavailable" bugfix** — `given` open‑dict → typed `list[GivenItem]` (`591ca0b`).

The `backend` branch tells the story of building a real‑time, multimodal AI tutor backend from
an empty repo to a streaming, multi‑provider, tiered‑LLM system in about seven weeks.

- **Day 1 (2026‑05‑26):** the entire FastAPI skeleton lands — `app/main.py`, the WebSocket lamp
  route, provider base classes for **four** LLM vendors (Gemini, Claude, OpenAI, DeepSeek), the
  prompt package, image/audio preprocessors, and a large set of design docs
  (`BACKEND_DESIGN.md`, `IMPLEMENTATION_WEBSOCKET.md`, `IMPLEMENTATION_AUTH_PAIRING.md`).
- **Week 1:** the "layers" get built out — auth & device pairing (Clerk + device JWTs), the
  Supabase data model, session memory, the escalation plan, the LaTeX engine, and the TTS stack.
- **Week 2:** Redis + multi‑image, **tiered LLM escalation** (tier‑1 Flash → tier‑2 Flash+thinking
  → tier‑3 Pro) with a smart‑skip router, the web `/simulate` brain, prompt re‑architecture around
  `query_type`, the image‑enhancement pipeline, audio **Opus/ADPCM** codecs, and admin/analytics.
- **Week 3:** a deterministic escalation **pre‑router**, problem‑memo continuity,
  Nudge/Focus/Follow‑up tutoring behaviors, **Gemini Flash 3** wiring, a full **Claude fallback**
  subsystem (with an extensive test suite), Claude STT, and **streaming / chunk mode**.
- **Weeks 4–7 (post‑2026‑06‑16, the current tail):** focus mode + Cartesia streaming TTS, a wave of
  **nudge/verdict guardrails**, **graphs end‑to‑end**, analytics/pilot/insights, **OTA**, a
  code‑enforced **output validator + math verifier**, **chemistry / RDKit** rendering, a
  **memory‑leak/CPU‑crash hardening pass** (`a5533e5` "added memory leak protection and
  cpu crash Iteration 1 done", 2026‑07‑04), a **brain‑optimization pass** —
  verifier‑on defaults, an `evals/` harness, and CI (`db470f6`, 2026‑07‑06) — and finally a
  range‑aware admin **Analytics‑tab** wave (config‑to‑prod alignment, CI removal, `turn_traces`‑sourced
  latency/escalation analytics) ending on `5ea5815` (2026‑07‑11).

The work is dominated by **Gemini** as the primary brain, with **Claude** added mid‑project as a
fallback/STT path, and a persistent focus on keeping the spoken voice short (hard word‑caps) while
pushing detail to the lamp's screen; the final weeks add rich on‑screen rendering (graphs, chemistry
structures) and a deterministic safety/validation layer around the LLM output — now exercised by an
offline eval harness and CI.

---

## Full commit table (all 136 commits)

Reverse‑chronological (newest → oldest). Dates are author dates (`--date=short`, date only; the
regenerated log no longer carries the `+0530` time-of-day). Rows 42 (`60f9237`) and 111 (`5a82708`)
are the two backend **sync merges**.

| # | Hash | Date | Author | Subject |
|---:|------|------|--------|---------|
| 1 | `5ea5815` | 2026-07-11 | ayushmaitistartups-cmyk | Admin Analytics: add question Level + per-question escalation to Questions table *(tip)* |
| 2 | `7387ed7` | 2026-07-11 | ayushmaitistartups-cmyk | Admin dashboard: escalation breakdown + fix Tier/model & Reason accuracy |
| 3 | `9b245cc` | 2026-07-11 | ayushmaitistartups-cmyk | Analytics: bucket today/yesterday + trend by IST, not UTC |
| 4 | `6adc1d1` | 2026-07-11 | ayushmaitistartups-cmyk | Analytics: lamp-only + failure Reason (drop web-simulator turns) |
| 5 | `f2505a0` | 2026-07-11 | ayushmaitistartups-cmyk | Analytics questions: include failed/cancelled turns (source turn_traces) |
| 6 | `4b96e63` | 2026-07-11 | ayushmaitistartups-cmyk | Analytics: rename "Upload from lamp" stage to "Lamp response loading" |
| 7 | `7fd47cd` | 2026-07-11 | ayushmaitistartups-cmyk | Record equation/graph/voice latency in document-mode dispatch (the lamp's path) |
| 8 | `591ca0b` | 2026-07-11 | ayushmaitistartups-cmyk | Fix Gemini "Tutor unavailable": `given` open-dict -> typed list[GivenItem] |
| 9 | `7a8088d` | 2026-07-11 | ayushmaitistartups-cmyk | Record equation + voice latency in the sync-to-audio dispatch path |
| 10 | `a26a9f5` | 2026-07-10 | ayushmaitistartups-cmyk | Track graph-render latency as its own analytics stage |
| 11 | `2616aca` | 2026-07-10 | ayushmaitistartups-cmyk | analytics summary: expose n_generation (generation-avg sample count) |
| 12 | `230f74b` | 2026-07-10 | ayushmaitistartups-cmyk | Revert stale config.py clobber; keep only the intended main.py gzip change |
| 13 | `070a65a` | 2026-07-10 | ayushmaitistartups-cmyk | Sync main.py + config.py to latest collaborator edits |
| 14 | `87b4759` | 2026-07-10 | ayushmaitistartups-cmyk | Add equation-render + TTS latency to analytics questions rows |
| 15 | `324bc6d` | 2026-07-09 | ayushmaitistartups-cmyk | Add range-aware admin analytics endpoints + model-selection latency |
| 16 | `e53ce33` | 2026-07-08 | ayushmaitistartups-cmyk | Remove backend CI workflow |
| 17 | `939e0bd` | 2026-07-08 | ayushmaitistartups-cmyk | Align config defaults with production env |
| 18 | `5077d5d` | 2026-07-07 | samiul | fixed readme ci error |
| 19 | `7b1fb94` | 2026-07-07 | samiul | added docs |
| 20 | `db470f6` | 2026-07-06 | ayushmaitistartups-cmyk | Brain optimization pass: verifier ON, MCQ option-match, eval harness, CI |
| 21 | `a5533e5` | 2026-07-04 | samiul | added memory leak protection and cpu crash Iteration 1 done |
| 22 | `0896f7c` | 2026-07-03 | samiul | ux ui fixed of tft graph |
| 23 | `80f04b6` | 2026-07-03 | samiul | fixed graph |
| 24 | `9f00682` | 2026-07-03 | samiul | added rdkit in req |
| 25 | `7250e51` | 2026-07-03 | samiul | bug fixes |
| 26 | `5dcb235` | 2026-07-02 | samiul | fixed graph |
| 27 | `4f89153` | 2026-07-02 | samiul | added CHEM RDKIT + CHANGE THE UX + FRONTEND optimzations |
| 28 | `9cf98ff` | 2026-07-02 | samiul | added chemistry equation |
| 29 | `1ed9d99` | 2026-07-01 | samiul | fixed previous bugs and updated |
| 30 | `4d79344` | 2026-07-01 | ayushmaitistartups-cmyk | Add code-enforced output validator, guardrails, and math verifier |
| 31 | `910303d` | 2026-07-01 | samiul | added OTA |
| 32 | `3813d1e` | 2026-06-28 | samiul | added the aggregated decomposition |
| 33 | `95b6123` | 2026-06-28 | samiul | added todo |
| 34 | `57e76f1` | 2026-06-28 | samiul | updated the db |
| 35 | `4a4af29` | 2026-06-28 | shashi-3000 | analysis related updates |
| 36 | `47c2a9e` | 2026-06-26 | samiul | added GRAPHS end to end |
| 37 | `a5c7ac2` | 2026-06-25 | samiul | added new firmware upgrades with backward compaitibility |
| 38 | `09ad85f` | 2026-06-25 | samiul | added TTS fix |
| 39 | `2e1542b` | 2026-06-24 | samiul | TTS Cartesia Stream Optimized and chemistry latext bug fixes |
| 40 | `8db448f` | 2026-06-22 | ayushmaitistartups-cmyk | Add check-verdict guard + lower frustration nudge threshold to 2 |
| 41 | `ac0e726` | 2026-06-19 | samiul | fixed the requirements |
| 42 | `60f9237` | 2026-06-19 | samiul | Merge branch 'backend' of …/Smart-Tutor-Lamp into backend *(sync merge)* |
| 43 | `667052a` | 2026-06-19 | samiul | added cartersia |
| 44 | `dc9a936` | 2026-06-19 | ayushmaitistartups-cmyk | Objective questions: direct verdict instead of a Socratic nudge |
| 45 | `bd03851` | 2026-06-19 | samiul | turned on the flags |
| 46 | `8014385` | 2026-06-19 | shashi-3000 | reasoning and tts related updates |
| 47 | `74c3e2f` | 2026-06-18 | ayushmaitistartups-cmyk | Fix tutor nudge/verdict issues: open-start, recheck loop, MCQ option (+ H1/H2) |
| 48 | `b235d4e` | 2026-06-18 | ayushmaitistartups-cmyk | Confirm correct answers on recheck instead of nudging |
| 49 | `6cc7423` | 2026-06-18 | ayushmaitistartups-cmyk | Fix nudges starting mid-solution on open-ended queries |
| 50 | `f831ccb` | 2026-06-18 | samiul | added claude fix |
| 51 | `c44f5cb` | 2026-06-18 | ayushmaitistartups-cmyk | Fix nudges starting mid-solution on open-ended queries |
| 52 | `027013c` | 2026-06-17 | samiul | TTS leads + focus mode |
| 53 | `1ca7dcf` | 2026-06-16 | samiul | TFT error verbose and bug fix |
| 54 | `eecd87a` | 2026-06-16 | samiul | bugs fixses |
| 55 | `466fced` | 2026-06-16 | samiul | fixed prompt |
| 56 | `00d20d6` | 2026-06-16 | samiul | added STREAM |
| 57 | `920e0e3` | 2026-06-16 | samiul | upgraded Aiohttp |
| 58 | `fad55b5` | 2026-06-16 | samiul | CHUNK MODE ADDED |
| 59 | `e17e0dc` | 2026-06-16 | samiul | added temp fix |
| 60 | `467d2a5` | 2026-06-16 | shashi-3000 | Added Claude STT |
| 61 | `dae5bb9` | 2026-06-15 | samiul | fixed broken json of tier 2 thinking |
| 62 | `afeac3a` | 2026-06-15 | samiul | added gemini fixes |
| 63 | `cbc2920` | 2026-06-15 | samiul | added claude prompt guide |
| 64 | `a68f9b0` | 2026-06-15 | samiul | 503 fix |
| 65 | `9f90c1d` | 2026-06-14 | samiul | fixed history bleed |
| 66 | `af0587e` | 2026-06-14 | samiul | added false alarm gaurd |
| 67 | `fa73195` | 2026-06-13 | samiul | gemini flash 3 wired |
| 68 | `0e3e481` | 2026-06-13 | samiul | fixed doubts and other bugs |
| 69 | `f033ea2` | 2026-06-13 | samiul | Follow up fixes |
| 70 | `4322c20` | 2026-06-13 | samiul | FOCUS + NUDGE + FOLLOW up |
| 71 | `2d63ee2` | 2026-06-12 | samiul | Nudge + FOCUS + Escalation |
| 72 | `456d78a` | 2026-06-12 | shashi-3000 | Updated Screen display outputs |
| 73 | `4fdb6de` | 2026-06-12 | shashi-3000 | Added Bound Box and Updated supabase |
| 74 | `1f79f60` | 2026-06-12 | shashi-3000 | Turns Updated and other issues resolved |
| 75 | `93bb729` | 2026-06-12 | samiul | added frontend error log |
| 76 | `17837d6` | 2026-06-12 | samiul | added arch.md |
| 77 | `c381255` | 2026-06-12 | samiul | fixed the bugs |
| 78 | `b193321` | 2026-06-12 | samiul | Changes the system prompt arch |
| 79 | `76c4257` | 2026-06-11 | samiul | bug fix |
| 80 | `9195645` | 2026-06-11 | samiul | bug fix |
| 81 | `2632caa` | 2026-06-10 | samiul | fixed bug |
| 82 | `c89f20f` | 2026-06-10 | samiul | fixed bugs |
| 83 | `5e4f5cb` | 2026-06-10 | samiul | added ADPCM and bug fixes |
| 84 | `0c4bdc2` | 2026-06-10 | samiul | Added Opus and ADPCM coded |
| 85 | `efaca49` | 2026-06-10 | samiul | fixed unmirror |
| 86 | `67ac4e9` | 2026-06-10 | samiul | bu fix 2 |
| 87 | `1eb928f` | 2026-06-10 | samiul | Fixed bugs and added enhancements |
| 88 | `cd70a9c` | 2026-06-09 | samiul | Fixed the tts and DBMS bugs |
| 89 | `cf28136` | 2026-06-08 | samiul | Added Pointing and INFO for latex latency |
| 90 | `dc166bf` | 2026-06-08 | ayushmaitistartups-cmyk | Remove graph_renderer.py — graph rendering feature dropped |
| 91 | `5664677` | 2026-06-08 | ayushmaitistartups-cmyk | Reapply web prompt changes lost in Samiul integration pull |
| 92 | `10a342d` | 2026-06-08 | samiul | fixed the Redis |
| 93 | `6a7c293` | 2026-06-08 | samiul | Fixed Memory issue |
| 94 | `6b16c38` | 2026-06-08 | samiul | Fixed the whole integration, removed the graphs, fixed the camera iamge pipeline |
| 95 | `7154406` | 2026-06-08 | ayushmaitistartups-cmyk | Add TFT graph rendering + escalation pre-router; align lamp prompts |
| 96 | `8418c76` | 2026-06-07 | ayushmaitistartups-cmyk | Refine query_type templates, voice caps, profile and hint rules |
| 97 | `285fd2d` | 2026-06-07 | samiul | Fixed image processing and gemini Network retry |
| 98 | `75b96f8` | 2026-06-07 | shashi-3000 | Updates Turns and other fixes |
| 99 | `b46cefa` | 2026-06-07 | samiul | chore: update gitignore and untrack sensitive files |
| 100 | `f55399e` | 2026-06-06 | samiul | Fixed TTS bug |
| 101 | `77212ae` | 2026-06-06 | samiul | added tts and latex bug fixed |
| 102 | `90477e4` | 2026-06-06 | ayushmaitistartups-cmyk | Restructure web simulator prompt around query_type + hard voice cap |
| 103 | `b376cf7` | 2026-06-05 | samiul | push small fixes |
| 104 | `6b093ac` | 2026-06-05 | samiul | added low TTS |
| 105 | `73c8499` | 2026-06-04 | shashi-3000 | Added multi llm features |
| 106 | `b67e3e9` | 2026-06-04 | samiul | bug fixes from firmware side and storing iamge locally from esp32 for dev purpose |
| 107 | `3249c35` | 2026-06-03 | shashi-3000 | Run.md updates |
| 108 | `8b02271` | 2026-06-03 | shashi-3000 | Admin data fetch Updates |
| 109 | `53138d8` | 2026-06-02 | shashi-3000 | supabase updates |
| 110 | `017ca24` | 2026-06-02 | shashi-3000 | fixed bugs |
| 111 | `5a82708` | 2026-06-02 | shashi-3000 | Merge branch 'backend' of …/Smart-Tutor-Lamp into backend *(sync merge)* |
| 112 | `45440c6` | 2026-06-02 | shashi-3000 | Admin,DB and consistency related updates |
| 113 | `224be7f` | 2026-06-02 | ayushmaitistartups-cmyk | Make web tutor voice length adaptive + document prompt sections |
| 114 | `25e3ad2` | 2026-05-31 | ayushmaitistartups-cmyk | Revert tier-3 escalation on the lamp (keep it web-only) |
| 115 | `2584767` | 2026-05-31 | ayushmaitistartups-cmyk | Crisp web voice output: cap speech + explain-properly trigger |
| 116 | `96221c1` | 2026-05-31 | ayushmaitistartups-cmyk | Enhance web /simulate images before LLM (helps small handwriting) |
| 117 | `61ac092` | 2026-05-31 | ayushmaitistartups-cmyk | Fix escalation_path column type to match live schema (text[] not jsonb) |
| 118 | `cb128eb` | 2026-05-31 | ayushmaitistartups-cmyk | Add tier-3 (Gemini Pro) escalation + smart-skip routing |
| 119 | `9d242b4` | 2026-05-30 | samiul | Added Redis and multi-image system |
| 120 | `faa480d` | 2026-05-30 | samiul | Bug fixes |
| 121 | `5355018` | 2026-05-30 | samiul | Clerk OAuth Fix |
| 122 | `4754be0` | 2026-05-29 | shashi-3000 | Added clerk |
| 123 | `f12d9fb` | 2026-05-29 | samiul | added full session and db with frotnend |
| 124 | `21fac62` | 2026-05-29 | samiul | Added frontend backend connection |
| 125 | `7d894d5` | 2026-05-29 | samiul | major fixes |
| 126 | `4b012c7` | 2026-05-29 | samiul | DB added |
| 127 | `e71b78a` | 2026-05-28 | samiul | Added Redis and Auth with esp to backend to frontend |
| 128 | `7f5a737` | 2026-05-28 | samiul | Added and refined DBMS doc |
| 129 | `c7dc2ce` | 2026-05-27 | samiul | Added Latest Session memory Guide |
| 130 | `ed25ac8` | 2026-05-27 | samiul | Added TTS guide and Layer 5 and 6 DONE! |
| 131 | `43d54be` | 2026-05-26 | samiul | Added escalation intial with supabase doc |
| 132 | `c3531d0` | 2026-05-26 | samiul | Added guide for DB |
| 133 | `c19e3b0` | 2026-05-26 | samiul | Layer 1,2,3,4 DONE! |
| 134 | `da4bd6a` | 2026-05-26 | shashi-3000 | LAYER 1 TO LAYER 4 |
| 135 | `4f7a77d` | 2026-05-26 | samiul | Layer 3 and layer 4 done |
| 136 | `bc4ba83` | 2026-05-26 | samiul | Added temp files |

---

## Thematic narrative

The sections below read **forward in time**. Each cites the notable commits and the files they
touched (per the `--stat` data in `backend-full-log.txt`).

### 3.1 FastAPI scaffold & app skeleton

The branch opens with two huge foundational commits on **2026‑05‑26**.

- **`bc4ba83` — "Added temp files"** (oldest commit, 7 files, +1837). This is a staging area of
  prototype "audio server" scripts under `temp_server_files/` — `Latex_engine_tft.py`,
  `audio_server/audio_analyzer.py`, `audio_stream.py`, `cmd_audio_receiver.py`, `mic_server.py`,
  `raw_receiver.py`. These early experiments seed the LaTeX‑on‑TFT and audio‑streaming ideas that
  become real later.
- **`4f7a77d` — "Layer 3 and layer 4 done"** (59 files, +6472) lays down the entire app package
  and design docs in one shot:
  - **App skeleton:** `app/__init__.py`, `app/main.py`, `app/config.py`, `app/logging.py`,
    `app/protocol.py`, `app/session.py`, `app/startup.py`, `pyproject.toml`.
  - **Provider base + four vendors:** `app/providers/llm_base.py` (+146), `llm_gemini.py` (+206),
    `llm_claude.py` (+173), `llm_openai.py` (+143), `llm_deepseek.py` (+142), plus `grounding.py`,
    `latex_renderer.py`, and a `tts_cartesia.py` stub.
  - **Prompts package:** `app/prompts/turn1_system.py`, `turn2_system.py`, `_latex_rules.py`,
    `classifier.py`, `conceptual_module.py`, `technical_module.py`, `escalation.py`.
  - **Routing/formatting/services:** `app/routes/ws_lamp.py`, `routes/health.py`,
    `app/formatting/tft_formatter.py`, `track_router.py`, `app/services/orchestrator.py` (+126),
    `turn_handler.py`, `validator.py`, `memory.py`; `app/schemas/llm_response.py`.
  - **Design docs:** `BACKEND_DESIGN.md`, `BACKEND_TODO.md`, `HARDWARE_CONTEXT.md`,
    `IMPLEMENTATION_AUTH_PAIRING.md` (+2098), `IMPLEMENTATION_WEBSOCKET.md` (+684).
  - **Dev tooling:** `scripts/mock_lamp.py`, `tests/.keep`.

This single commit establishes the layered architecture (providers → services/orchestrator →
routes → protocol/session) and the four‑provider abstraction that the rest of the branch builds on.

### 3.2 WebSocket protocol & the lamp session pipeline

The lamp talks to the backend over a WebSocket. The protocol/session machinery is built up across
several commits.

- **`c19e3b0` — "Layer 1,2,3,4 DONE!"** (2026‑05‑26, 22 files, +1548) substantially expands
  `app/session.py` (+197), `app/protocol.py`, and `app/routes/ws_lamp.py` (+70), and adds the
  storage layer: `app/storage/__init__.py`, `blobs.py`, `turns.py`, `memory_vec.py`, plus the
  `app/workers/` package (`embed.py`, `rollup.py`, `transcribe.py`). `RUN.md` and `app/LAYOUT.md`
  document how to run and lay out the app.
- **`da4bd6a` — "LAYER 1 TO LAYER 4"** (2026‑05‑26, 26 files, +2678) by shashi greatly extends
  `app/session.py` (+344) and `app/routes/ws_lamp.py` (+225), and wires the device/auth routes
  (`device_lamp.py` +165, `device_user.py` +220, `pairing_info.py`, `clerk_webhook.py`) into
  `app/main.py`. `app/services/orchestrator.py` jumps by +389.
- **`7d894d5` — "major fixes"** (2026‑05‑29) reshapes the protocol response: `app/session.py`
  (+62), `app/routes/ws_lamp.py`, `app/schemas/llm_response.py` (+71), and removes 73 lines from
  the orchestrator (consolidation).
- **`2632caa` — "fixed bug"** (2026‑06‑10) and **`c89f20f` — "fixed bugs"** harden the session
  loop, touching `app/protocol.py`, `app/session.py`, `app/services/dispatch.py` (+115 in
  `2632caa`), and `app/providers/latex_renderer.py`, with stress logs captured
  (`server_final.log` +1213).
- **`67ac4e9` — "bu fix 2"** adds `scripts/stress_lamp_ingest.py` (+190) and large stress logs
  (`server_stress.log` +758) to validate the ingest path under load.

The `dispatch.py` service (how a finished LLM reply is turned into screen frames + spoken audio and
shipped to the lamp) becomes a central, frequently‑touched file from here on.

### 3.3 LLM providers (Gemini, Claude, OpenAI, DeepSeek)

Four provider modules were stubbed on day 1 (`4f7a77d`), but **Gemini** quickly becomes the
production brain.

- **`43d54be` — "Added escalation intial with supabase doc"** (2026‑05‑26) is the first big
  Gemini build‑out: `app/providers/llm_gemini.py` (+222), `llm_base.py`, `latex_renderer.py`,
  and `schemas/llm_response.py`. It also introduces `ESCALATION_PLAN.md` (+443) and `.mcp.json`.
- **`e71b78a`** (2026‑05‑28) adds `app/providers/gemini_brain.py` (+194) and
  `app/providers/web_simulator.py` (+67) — the higher‑level "brain" wrapper used for web/simulate
  and richer prompting, distinct from the raw `llm_gemini.py` client.
- **`73c8499` — "Added multi llm features"** (2026‑06‑04, shashi, 8 files, +1399) adds the
  model‑evaluation subsystem: `app/services/model_catalog.py` (+179),
  `app/services/model_solver.py` (+396), `app/schemas/model_eval.py`,
  `app/storage/model_eval.py` (+229), plus DB models and a large `frontend_manager.py` (+316). This
  is the multi‑model A/B/eval harness used by the web tooling.
- **`285fd2d` — "Fixed image processing and gemini Network retry"** (2026‑06‑07) hardens
  `app/providers/llm_gemini.py` with network retry and improves `image_preprocessor.py`.
- **`fa73195` — "gemini flash 3 wired"** (2026‑06‑13) wires the newer **Gemini Flash 3** model via
  `app/providers/llm_base.py` (+44) and a battery of probe scripts:
  `scripts/probe_flash_lite.py` (+231), `probe_flash_lite_ga.py`, `probe_flash_lite_raw.py`,
  `probe_tier1_codeexec.py`, `check_minimal_live.py`, `check_thinking_map.py`.
- **`a68f9b0` — "503 fix"** (2026‑06‑15) adds retry/backoff for Gemini 503s in
  `app/providers/llm_gemini.py` plus `scripts/timeout_retry_check.py`.
- **`afeac3a` — "added gemini fixes"** (2026‑06‑15) tweaks `llm_gemini.py`, `llm_base.py`,
  `problem_memo.py`, and dumps a large refresh of `PROJECT_CONTEXT.md` (+699) and
  `CLAUDE_BRANCH_GUIDE.md` (+206).

`llm_claude.py`, `llm_openai.py`, and `llm_deepseek.py` remain present throughout (visible in the
`.pyc` churn of `b376cf7` and `5355018`), but Claude only becomes an active runtime path late
(see [§3.11](#311-claude-fallback-work)).

### 3.4 Tiered escalation & the deterministic pre-router

A defining feature of this backend is its **tiered LLM dispatch**: cheap/fast first, escalate only
when needed.

- The plan is documented first in **`43d54be`** via `ESCALATION_PLAN.md` (+443).
- **`cb128eb` — "Add tier-3 (Gemini Pro) escalation + smart-skip routing"** (2026‑05‑31, Claude‑assisted)
  implements it: tier‑1 Flash self‑classifies and escalates to tier‑2 (Flash + thinking) or tier‑3
  (Pro) via a **smart‑skip router** that jumps straight to the right ceiling. Wired into *both* the
  lamp `app/services/orchestrator.py` (+136) and the web path `app/routes/frontend_manager.py`
  (+111). Adds `final_tier` + `escalation_path` telemetry columns (`app/db/models.py`,
  `app/storage/turns.py`). Tier‑3 is **off by default** behind `GEMINI_TIER3_ENABLED`; a tier‑4
  bridge is stubbed/deferred.
- **`61ac092`** (2026‑05‑31) fixes the `escalation_path` column type to `ARRAY(Text)` (`text[]`) to
  match the live Supabase schema — the model had declared JSONB, which would have rejected every
  insert (`app/db/models.py`).
- **`25e3ad2` — "Revert tier-3 escalation on the lamp (keep it web-only)"** (2026‑05‑31) pulls
  tier‑3 back off the lamp: the lamp returns to a two‑tier (Flash thinking‑0 → Flash thinking‑512)
  dispatch, while tier‑3 (Pro) runs only on web `/simulate`. Restores `orchestrator.py` and
  `llm_gemini.py` to their pre‑tier‑3 (multi‑image) state; the telemetry columns stay.
- **`7154406` — "Add TFT graph rendering + escalation pre-router; align lamp prompts"** (2026‑06‑08,
  Claude‑assisted) adds the **deterministic escalation pre‑router**:
  `app/services/escalation_router.py` (+311) with an image‑quality gate (retake blurry/dark/tiny
  photos for **zero LLM spend**) plus keyword text rules that pick a deterministic START tier. A
  **Groq Whisper** fast pre‑STT gives the lamp a routing transcript before tier‑1 (parallel with
  image enhancement). MCQ → option verification; "where did I go wrong" → mistake localization.
  Tests: `tests/test_escalation_router.py` (+141), `tests/test_orchestrator_preroute.py` (+141).
- **`2d63ee2` — "Nudge + FOCUS + Escalation"** (2026‑06‑12) and **`4322c20` — "FOCUS + NUDGE +
  FOLLOW up"** (2026‑06‑13) significantly extend `escalation_router.py` (+84, +42) and
  `app/services/problem_memo.py` (+254, …) to support tutoring behaviors — nudging the student,
  staying focused on the current problem, and handling follow‑up turns — with extensive dry‑run
  scripts (`scripts/nudge_dryrun.py` +468, `scripts/focus_dryrun.py` +333, `scripts/wiring_dryrun.py`).
- **`af0587e` — "added false alarm gaurd"** (2026‑06‑14) adds a guard against false escalation
  alarms across `escalation_router.py`, `orchestrator.py`, `frontend_manager.py`, with semantic
  dry‑run scripts (`dispute_semantic_dryrun.py`, `falsealarm_dryrun.py`, `semantic_escalation_dryrun.py`,
  `harmony_dryrun.py`).

### 3.5 TTS (Piper, Gemini TTS) & audio codecs

Speech output evolves from a local neural voice to cloud TTS, then gets squeezed through tight
audio codecs for the ESP32 link.

- **`4b012c7` — "DB added"** (2026‑05‑29) brings the **Piper** voice online: large work in
  `app/providers/tts_piper.py` (+232) and the `en_US-amy-medium.onnx.json` voice config (+493).
- **`e71b78a`** (2026‑05‑28) further extends `tts_piper.py` (+186).
- **`6b093ac` — "added low TTS"** (2026‑06‑05) commits the binary low‑quality voice model
  `audio-tts/en_US-amy-low.onnx` (~63 MB) and its JSON.
- **`ed25ac8` — "Added TTS guide and Layer 5 and 6 DONE!"** (2026‑05‑27) lands the
  `TTS_INTEGRATION.md` guide (+1008), the `app/providers/latex_engine.py` (+590), and the big
  `app/services/dispatch.py` (+280) that turns replies into TFT frames + audio, plus
  `tests/test_dispatch_dryrun.py` and `tests/test_pipeline_stress.py`.
- **`77212ae` — "added tts and latex bug fixed"** (2026‑06‑06) introduces **Gemini TTS**:
  `app/providers/tts_base.py` (+243) and `app/providers/tts_gemini.py` (+303), wired through
  `dispatch.py` and `schemas/llm_response.py`; also `test_gemini_tts.py` (+67).
- **`f55399e` — "Fixed TTS bug"** (2026‑06‑06) follows up with fixes in `tts_base.py`,
  `tts_gemini.py`, `llm_gemini.py`, and `dispatch.py` (+99).
- **Audio codecs** for the constrained link arrive on 2026‑06‑10:
  - **`0c4bdc2` — "Added Opus and ADPCM coded"** adds codec handling in `app/session.py` (+117)
    and `app/protocol.py`, with `scripts/dryrun_tts_codecs.py` (+201) and Opus deps in
    `requirements.txt`.
  - **`5e4f5cb` — "added ADPCM and bug fixes"** finishes ADPCM in `app/session.py` and config.
- **`cd70a9c` — "Fixed the tts and DBMS bugs"** (2026‑06‑09) fixes TTS alongside admin/DB code
  (`app/services/admin.py` +226).

### 3.6 Memory, sessions & vectors

The tutor needs cross‑turn and cross‑session memory.

- **`4f7a77d`** stubs `app/services/memory.py`; **`da4bd6a`** grows it to +125 and adds
  `app/services/pairing.py` and `app/services/revocation.py` (+119).
- **`c19e3b0`** adds the vector store stub `app/storage/memory_vec.py` (+56) and the async workers
  `app/workers/embed.py`, `rollup.py`, `transcribe.py` — the embedding/roll‑up/transcribe pipeline
  for long‑term memory.
- **`c7dc2ce` — "Added Latest Session memory Guide"** (2026‑05‑27) commits the
  `SESSION_MEMORY_GUIDE.md` (+1570) design doc.
- **`f12d9fb` — "added full session and db with frotnend"** (2026‑05‑29) is the big session‑memory
  implementation: `app/services/session_memory.py` (+484), plus `gemini_brain.py` (+127) and
  `frontend_manager.py` (+120).
- **`9195645` — "bug fix"** (2026‑06‑11) and **`6a7c293` — "Fixed Memory issue"** (2026‑06‑08)
  patch `session_memory.py` and the orchestrator; `6a7c293` also trims `PROJECT_CONTEXT.md`
  (−500) and fixes the LaTeX engine/renderer.
- **`b193321`, `2d63ee2`, `456d78a`, `f033ea2`, `0e3e481`, `afeac3a`** all build out
  `app/services/problem_memo.py` (introduced at +231 in `b193321`; then +254, +125, +146, +76, +46)
  — a structured "memo" of the current problem that gives the tutor continuity across turns within a
  problem. `tests/test_problem_memo.py` grows in lockstep.
- **`9f90c1d` — "fixed history bleed"** (2026‑06‑14) fixes conversation history leaking between
  contexts: `app/services/memory.py` (+45), `session_memory.py`, `gemini_brain.py`,
  `schemas/llm_response.py`, with `scripts/history_bleed_dryrun.py` (+105).

### 3.7 Auth, pairing & device JWTs

The lamp is a physical device that must pair to a user account.

- The auth design is specified up front in **`4f7a77d`** via `IMPLEMENTATION_AUTH_PAIRING.md` (+2098).
- **`da4bd6a`** implements it: `app/deps/clerk.py` (+120), `app/deps/device_auth.py` (+61),
  `app/deps/rate_limit.py`, `app/services/device_jwt.py` (+87), `app/services/pairing.py`,
  `app/services/revocation.py` (+119), `app/routes/device_lamp.py`, `device_user.py`,
  `pairing_info.py`, `clerk_webhook.py`, and `app/schemas/auth.py` (+89).
- **`e71b78a` — "Added Redis and Auth with esp to backend to frontend"** (2026‑05‑28) adds
  WebSocket‑side Clerk auth (`app/deps/clerk_ws.py` +103) and the cache (`app/services/cache.py` +67,
  Redis‑backed).
- **`4754be0` — "Added clerk"** (2026‑05‑29, shashi) bumps the Clerk dependency in
  `requirements.txt`.
- **`5355018` — "Clerk OAuth Fix"** (2026‑05‑30) fixes `app/deps/clerk.py` and the frontend schema;
  **`faa480d`** is a tiny follow‑up removing stale `.pyc` files.
- **`10a342d` — "fixed the Redis"** (2026‑06‑08) hardens token revocation in
  `app/services/revocation.py` (+54).
- **`b46cefa` — "chore: update gitignore and untrack sensitive files"** (2026‑06‑07) and
  **`017ca24` — "fixed bugs"** (2026‑06‑02, which deletes a committed `.env` of −98 lines) are the
  secret‑hygiene commits.

### 3.8 Database, Supabase & admin/analytics

Persistence runs on **Supabase (Postgres)** with SQLAlchemy models.

- **`da4bd6a`** adds `app/db/session.py` (+101) and grows `app/db/models.py` (+93).
- **`c3531d0` — "Added guide for DB"** (2026‑05‑26) commits `SUPABASE_SETUP.md` (+903); the doc is
  refined further in **`43d54be`**, **`7f5a737`** (`PROJECT_CONTEXT.md` +716, `SUPABASE_SETUP.md`
  +430), and **`7d894d5`** (`SUPABASE_QUERIES.md` +566).
- **`e71b78a`** heavily expands turn persistence: `app/storage/turns.py` (+312) and
  `app/services/analytics.py` (+89).
- **`4b012c7`** adds `app/storage/events.py` (+63) and `app/storage/user_memory.py` (+59).
- **`45440c6` — "Admin,DB and consistency related updates"** (2026‑06‑02, shashi, 19 files, +1196)
  builds the **admin** surface: `app/routes/admin.py` (+119), `app/services/admin.py` (+454),
  `app/schemas/admin.py` (+148), `app/deps/admin.py` (+43), `scripts/admin_setup.sql` (+50), plus
  expanded `app/logging.py` (+94) and `analytics.py`.
- **`8b02271` — "Admin data fetch Updates"** and **`53138d8` — "supabase updates"** (both
  2026‑06‑02/03) iterate on `app/services/admin.py`, `app/deps/clerk.py` (+195), and
  `SUPABASE_QUERIES.md`. `5a82708` is a merge commit reconciling parallel `backend` work.
- **`1f79f60` — "Turns Updated and other issues resolved"** (2026‑06‑12, shashi, 24 files, +987)
  adds the **turn‑trace** subsystem: `app/services/turn_trace.py` (+296), `app/db/models.py` (+64),
  `app/routes/admin.py`, `app/services/admin.py` (+92), and grows `orchestrator.py` (+226). It also
  begins committing `turn_captures/` debug artifacts (audio.wav / llm_reply.json / images).
- **`4fdb6de` — "Added Bound Box and Updated supabase"** (2026‑06‑12, shashi, 33 files, +784) adds
  `app/services/media_cleanup.py` (+175), `app/storage/blobs.py` (+109), `SUPABASE_QUERIES.md`
  (+178), and bound‑box fields on `schemas/llm_response.py`.
- **`224be7f`, `73c8499`** also touch analytics/eval (see [§3.3](#33-llm-providers-gemini-claude-openai-deepseek)).

### 3.9 Prompt architecture & the web simulator

A recurring theme — largely driven by **ayushmaitistartups‑cmyk** with Claude assistance — is the
"voice short, screen detailed" prompting discipline, applied separately to the **web `/simulate`
brain** (`gemini_brain.py`) and the **lamp brain** (`turn1_system.py` / `turn2_system.py`).

- **`224be7f` — "Make web tutor voice length adaptive…"** (2026‑06‑02) replaces a fixed
  "2‑3 sentences" rule with an adaptive SHORT/MEDIUM/DETAILED rubric and adds a
  screen‑by‑question‑type guide (KaTeX / aligned env) — web‑only (`gemini_brain.py` +108).
- **`2584767` — "Crisp web voice output…"** (2026‑05‑31) caps web speech at ~50 words and pushes
  step‑by‑step working to the screen, with an "explain properly" trigger.
- **`96221c1` — "Enhance web /simulate images before LLM"** (2026‑05‑31) runs the lamp's
  CLAHE+unsharp pipeline on web frames too (`frontend_manager.py` +17).
- **`90477e4` — "Restructure web simulator prompt around query_type + hard voice cap"** (2026‑06‑06)
  replaces the length‑tier system with per‑`query_type` answer templates each carrying a hard
  15‑45‑word voice cap (`gemini_brain.py`, ±130).
- **`8418c76` — "Refine query_type templates, voice caps, profile and hint rules"** (2026‑06‑07)
  turns each template into an explicit fixed recipe (what / order / what‑on‑screen), raises voice
  caps, and adds a hint‑frustration rule (`gemini_brain.py`).
- **`5664677` — "Reapply web prompt changes lost in Samiul integration pull"** (2026‑06‑08)
  restores the `8418c76` changes that an integration merge (`6b16c38`) had overwritten — a
  classic merge‑recovery commit.
- **Lamp‑side prompts** evolve in **`17837d6` — "added arch.md"** (2026‑06‑12,
  `system_prompt_arch.md` +310) and **`b193321` — "Changes the system prompt arch"** (2026‑06‑12),
  which reworks `turn1_system.py` and the orchestrator around the new architecture, plus
  `0e3e481`, `f033ea2`, `4322c20`, `2d63ee2` which keep tuning `turn1_system.py` and
  `system_prompt_arch.md`.

The web simulator itself was introduced in **`e71b78a`** (`app/providers/web_simulator.py` +67) and
the large `app/routes/frontend_manager.py` (+371) that serves the web `/simulate` path.

### 3.10 Image pipeline, LaTeX rendering & graph rendering

The lamp captures handwriting via camera; the backend enhances images, renders math to the TFT, and
briefly experimented with on‑screen graphs.

- **Image preprocessing:** `app/providers/image_preprocessor.py` is born in `da4bd6a` (+165),
  greatly expanded in **`c19e3b0`** (+492), then refined in **`b67e3e9`** (+65, plus
  `app/storage/dev_capture.py` +120 to save ESP32 images locally for dev), **`285fd2d`** (+55), and
  **`4322c20`** (+151). A separate `app/services/image_prep.py` (+87) lands in **`1eb928f`**.
- **LaTeX rendering:** `app/providers/latex_renderer.py` and the `latex_engine.py` (added +590 in
  `ed25ac8`) carry math‑to‑image work, with notable expansion in **`1eb928f`**
  (`latex_renderer.py` +287) and pointing/latency info in **`cf28136` — "Added Pointing and INFO for
  latex latency"** (2026‑06‑08, `turn1_system.py` +80).
- **Graph rendering (added then dropped):**
  - **`7154406`** adds `app/providers/graph_renderer.py` (+280): a restricted‑AST evaluator (no
    `eval` of raw input) that renders matplotlib graphs to 320×200 RGB565 in the TFT frame format,
    with precedence graph > equations > text and a defensive fallback.
  - **`6b16c38` — "Fixed the whole integration, removed the graphs, fixed the camera image
    pipeline"** (2026‑06‑08, 33 files) is a major integration commit that removes the graph feature
    from the pipeline, reorganizes prompts into `app/prompts/_unused/`, and adds a large test suite
    (`tests/test_gemini_to_esp_live.py` +220, `test_infra.py` +163, `test_llm_input.py` +139,
    `test_llm_output.py` +324).
  - **`dc166bf` — "Remove graph_renderer.py — graph rendering feature dropped"** (2026‑06‑08)
    finally deletes `app/providers/graph_renderer.py` (−280).
- **`456d78a` — "Updated Screen display outputs"** (2026‑06‑12, shashi) and **`4fdb6de`**
  (bound boxes) refine what actually reaches the screen (`frontend_manager.py`, `model_solver.py`,
  `gemini_brain.py`).

### 3.11 Claude fallback work

Late in the branch, **Claude** is promoted from a day‑1 stub to a real fallback brain and an STT
provider — substantial, well‑tested work.

- **`cbc2920` — "added claude prompt guide"** (2026‑06‑15) commits the design:
  `CLAUDE_BRANCH_GUIDE.md` (+693), with a small touch to `app/providers/llm_claude.py` and
  `scripts/groq_check.py`, plus `system_prompt_arch.md` updates.
- **`dae5bb9` — "fixed broken json of tier 2 thinking"** (2026‑06‑15) commits
  `CLAUDE_FALLBACK_GUIDE.md` (+340) and fixes broken JSON from tier‑2 "thinking" output in
  `app/config.py` and `app/services/orchestrator.py` (+30), with `scripts/wiring_dryrun.py`.
  (`afeac3a` on the same day expands `CLAUDE_BRANCH_GUIDE.md` by another +206.)
- **`467d2a5` — "Added Claude STT"** (2026‑06‑16, shashi) is the headline Claude commit: it builds
  out `app/providers/llm_claude.py` (+83), the orchestrator (+168),
  `app/services/model_catalog.py` (+24), `app/schemas/admin.py`, plus a smoke script
  (`scripts/fallback_live_smoke.py` +160) and a **comprehensive Claude‑fallback test suite**:
  - `tests/test_claude_fallback.py` (+267)
  - `tests/test_claude_fallback_qa.py` (+444)
  - `tests/test_fallback_continuity.py` (+145)
  - `tests/test_fallback_strict_invariants.py` (+186)
  - `tests/test_admin_fallback_visibility.py` (+123)

  (This commit also re‑adds a large batch of `turn_captures/` debug artifacts that `e17e0dc` later
  removes — see [§3.13](#313-bug-fixes--operational-hygiene).)
- **`e17e0dc` — "added temp fix"** (2026‑06‑16) tweaks `app/providers/llm_claude.py` and config as
  part of the streaming/temp‑fix push.

### 3.12 Streaming & chunk mode (final push)

The branch ends with the move to streaming responses — getting first audio to the lamp faster.

- **`fad55b5` — "CHUNK MODE ADDED"** (2026‑06‑16) adds chunked dispatch:
  `app/services/dispatch.py` (+20) and `app/config.py` (+19), documented in `PROJECT_CONTEXT.md`.
- **`920e0e3` — "upgraded Aiohttp"** (2026‑06‑16) upgrades `requirements.txt` and adapts
  `app/providers/tts_gemini.py` for the streaming HTTP client.
- **`00d20d6` — "added STREAM"** (2026‑06‑16) — a focused change to `app/config.py` (+15/−8)
  flipping on streaming mode. This was the tip at the 2026‑06‑16 snapshot; the branch then
  continues for another 55 commits (see [§3.14](#314-postsnapshot-work-2026-06-17--2026-07-06) for the
  36 through 07‑06 and [§3.15](#315-admin-analytics-tab--config-to-prod-alignment-2026-07-07--2026-07-11)
  for the 19 through 07‑11).

### 3.13 Bug fixes & operational hygiene

A large share of the 136 commits are fixes, cleanups, and dev‑artifact churn. Highlights:

- **General bug‑fix commits:** `7d894d5` ("major fixes"), `faa480d` ("Bug fixes"),
  `1eb928f` ("Fixed bugs and added enhancements", 26 files, ±977), `c89f20f`, `2632caa`, `9195645`,
  `76c4257`, `c381255`, `0e3e481` ("fixed doubts and other bugs"), `285fd2d`,
  `6b16c38` ("Fixed the whole integration…").
- **`b376cf7` — "push small fixes"** (2026‑06‑05) is almost entirely `__pycache__/*.pyc` deletions
  (41 files) — the moment compiled bytecode stops being tracked; the only source change is
  `app/session.py` (+28). Several other commits (`4322c20`, `2d63ee2`, `5355018`, `9d242b4`,
  `faa480d`) carry large `.pyc` add/remove noise as `.gitignore` rules churned.
- **`e17e0dc` — "added temp fix"** (2026‑06‑16) deletes **144 files** of `turn_captures/` debug
  artifacts (the captured audio/JSON/JPEGs that `467d2a5`, `4fdb6de`, `1f79f60`, and `b193321` had
  committed). These capture dirs are a recurring source of churn (`c381255` also removes 77 of them).
- **Logs as artifacts:** `c89f20f` (`server_final.log` +1213), `67ac4e9`
  (`server_stress.log` +758, `server_runb.log` +149), `1eb928f` (`server_e2e.log` +168) commit
  raw server logs alongside fixes — useful as a record, heavy as repo content.
- **Secret hygiene:** `017ca24` removes a tracked `.env` (−98); `b46cefa` and `5355018` tidy
  `.gitignore` / untrack sensitive files.
- **Docs‑only commits:** `c3531d0`, `c7dc2ce`, `7f5a737`, `17837d6`, `3249c35` ("Run.md updates"),
  and the `CLAUDE_*`/`PROJECT_CONTEXT.md` refreshes are documentation‑centric.
- **`efaca49` — "fixed unmirror"** (2026‑06‑10) is a tiny config‑only fix (`.env.example`,
  `app/config.py`) for camera mirroring.

### 3.14 Post‑snapshot work (2026‑06‑17 → 2026‑07‑06)

The 36 commits after the 2026‑06‑16 snapshot take the backend from a streaming tutor into a
guard‑railed, richly‑rendering, leak‑hardened one. Eight themes dominate (file‑stats from
`backend-full-log.txt`):

- **Verbose TFT errors + focus mode.** `1ca7dcf` "TFT error verbose and bug fix" (06‑16) adds
  `app/services/error_messages.py` (+83) and expands `dispatch.py`. `027013c` "TTS leads + focus
  mode" (06‑17) is the larger one — `app/services/dispatch.py` (+206), `escalation_router.py`,
  `orchestrator.py`, `problem_memo.py`, `session.py`, plus `tests/test_focus_carry.py` (+148) and a
  big `tests/test_sync_dispatch.py` (+280).
- **Tutor nudge/verdict guardrails (06‑18 → 06‑24, mostly ayushmaitistartups‑cmyk + Claude).**
  `c44f5cb`/`6cc7423` add RULE 9 ("match the nudge to where the student is") to `turn1_system.py`
  and `gemini_brain.py`; `f831ccb` "added claude fix" adds `tests/test_thinking_keepalive.py` (+102)
  and reworks `orchestrator.py`; `b235d4e` adds a check/recheck carve‑out; `74c3e2f` "Fix tutor
  nudge/verdict issues" (+337) extends `escalation_router.py` (+53) and `problem_memo.py` with an
  open‑start detector, recheck‑consistency, and an MCQ‑option guard; `dc9a936` "Objective questions:
  direct verdict" adds an objective‑answer path to `escalation_router.py` (+101). `8db448f` "Add
  check‑verdict guard + lower frustration nudge threshold to 2" (06‑22) adds
  `problem_memo.is_check_request()` / `check_verdict_note()` (+63) behind `CHECK_VERDICT_GUARD` and
  drops `SOLVE_NUDGE_THRESHOLD` 3 → 2, with `scripts/check_verdict_dryrun.py` (+119).
- **Cartesia streaming TTS + firmware compatibility.** `667052a` "added cartersia" (06‑19) builds out
  `app/providers/tts_cartesia.py` (+196), `dispatch.py` (+68), and `tests/test_tts_chunking.py` (+89);
  the second backend **sync merge `60f9237`** (06‑19) reconciles it with `dc9a936`. `2e1542b` (06‑24)
  optimizes the Cartesia stream and fixes chemistry‑LaTeX (`latex_engine.py`, `tts_cartesia.py`);
  `09ad85f` (06‑25) adds a dispatch TTS fix. `a5c7ac2` "added new firmware upgrades with backward
  compaitibility" (06‑25) adds `tests/test_firmware_compat.py` (+96) and `tests/test_tft_image_jpeg.py`
  (+136). `8014385` (shashi, 06‑19) lands reasoning/TTS updates across `orchestrator.py` (+172) and
  `problem_memo.py` (+234).
- **Graphs end‑to‑end.** `47c2a9e` "added GRAPHS end to end" (06‑26) reintroduces
  `app/providers/graph_renderer.py` (+195) — the on‑TFT graph renderer previously dropped in June —
  wired through `dispatch.py`, `session.py`, `schemas/llm_response.py` (+58), with
  `tests/test_graph.py` (+161) and `tests/test_graph_edge.py` (+198).
- **Analytics / pilot / insights + aggregation (06‑28).** `4a4af29` (shashi, +2466, 22 files) is the
  largest post‑snapshot commit: `app/routes/pilot.py` / `insights.py` / `admin_pilot.py`,
  `app/services/insights.py` (+281), `mistake_tagger.py`, `topic_tagger.py`, `app/storage/pilot.py`
  (+332), and `app/workers/mistake_tag.py` / `topic_tag.py`. `57e76f1` "updated the db", `95b6123`
  "added todo" (`todo.md` +304), and `3813d1e` "added the aggregated decomposition" (admin +88) round
  out the day.
- **OTA + guardrail layer + chemistry/RDKit (07‑01 → 07‑03, the finish).** `910303d` "added OTA"
  adds `app/routes/ota.py` (+79), `app/services/ota_release.py` (+86), `notify.py` (+50), and
  `ENV.md` (+265). `4d79344` "Add code‑enforced output validator, guardrails, and math verifier"
  (ayushmaitistartups‑cmyk + Claude, +1447) adds `app/services/output_validator.py` (+258),
  `math_verifier.py` (+352), `input_guard.py` (+160), `render_check.py` (+100), and
  `app/prompts/_guardrails.py` (+45), plus 50 new tests and a `legacy/` move guarded by
  `tests/test_no_legacy_imports.py`. `1ed9d99` (07‑01) completes that reorg — moving dead code into
  `app/legacy/`, deleting the `temp_server_files/` prototypes (~2,117 deletions) and adding
  `COST_ANALYSIS.md` (+375). The chemistry track lands in `9cf98ff` "added chemistry equation"
  (`app/providers/rdkit_renderer.py` +94, `tests/test_chem_structure.py` +148) and `4f89153` "added
  CHEM RDKIT + CHANGE THE UX + FRONTEND optimzations" (`app/providers/document.py` +468 for scroll‑doc,
  `dispatch.py`, `test_scroll_doc.py`). `80f04b6` "fixed graph" (07‑03) — with `9f00682` "added rdkit
  in req", `7250e51`, and `5dcb235` — are further graph/chemistry render fixes.
- **Graph‑UX polish & memory‑leak/CPU‑crash hardening (07‑03 → 07‑04, the iteration‑1 close).** `0896f7c`
  "ux ui fixed of tft graph" (07‑03, 3 files, +16/−4) is a small graph‑UX fix touching
  `app/providers/graph_renderer.py` (+15/−2), `app/services/dispatch.py`, and `app/session.py`.
  `a5533e5` "added memory leak protection and cpu crash Iteration 1 done" (07‑04, 11 files,
  +226/−79) is the larger, coordinated hardening pass — prompted by real
  memory‑leak/CPU‑crash incidents on the 512 MB Render box, it closes every leak, caps every
  unbounded buffer, and gates every expensive render:
  - A new **`render_graph_gated()`** wraps all graph rendering (the per‑turn dispatch render and the
    interactive pan/zoom re‑render) in a process‑wide `asyncio.Semaphore`, sized by a new
    `GRAPH_RENDER_CONCURRENCY` setting (default 2, `app/config.py`) — the actual OOM‑prevention
    mechanism.
  - `graph_renderer.render_graph()` and `latex_engine.LatexRenderer` now close matplotlib figures in
    a `try`/`finally` on the exception path — previously `plt.close(fig)` only ran on success, so an
    error mid‑render leaked the figure into pyplot's global registry forever.
  - The two Whisper STT helpers (`llm_claude.py` and `model_solver.py`, both `_stt_via_groq`) now
    close their `AsyncGroq` clients with `async with` instead of leaking a socket/fd on every turn.
  - `session.py` gains hard ceilings on per‑turn accumulators (`_MAX_AUDIO_BYTES`,
    `_MAX_IMAGE_ACCUM_HARD`) for lamps that never send a terminator frame, and coalesces bursty
    GRAPH_VIEW pan/zoom requests (`_graph_pending`/`_graph_draining`) into one render per finished
    frame, now keyed per `graph_id` — the backend counterpart to the firmware's new
    multi‑graph‑per‑document support in `c699e72` (see
    [01-firmware-branch-commits.md](01-firmware-branch-commits.md) §2.10 and
    [01-firmware/02-display-and-ui.md](../01-firmware/02-display-and-ui.md) §4.7 for the
    firmware‑side `graph_id` wiring).
  - `orchestrator.py` backgrounds the L1/L2/L3 memory load as an `asyncio.create_task` at turn start
    (only awaited later, at first real use) instead of blocking turn processing on it, and moves the
    CPU‑bound `assess_image_quality` off the event loop via `asyncio.to_thread` at three call sites
    (`orchestrator.py`'s pre‑router gate, `frontend_manager.py`'s `/simulate` route and
    `_solve_auto()`).
  - `ENV.md`/`config.py` lower `CARTESIA_TIMEOUT_S` 30→20s and document `MALLOC_ARENA_MAX=2` as a
    Render‑platform env var (not a `config.py` setting) capping glibc malloc arenas for the same
    OOM‑prevention reason; `render_graph()` also gains a `chrome` margin parameter and a
    400²→300² meshgrid resolution cut (~44% less array memory per implicit‑plot render).

  This closes out **iteration 1** at `a5533e5`, and pairs with the firmware's own
  "FIRST ITERATION COMPLETE" pass (`c699e72`, documented in
  [01-firmware-branch-commits.md](01-firmware-branch-commits.md)) — both commits landing as part of
  the same cross‑repo hardening/UX push.

- **Brain‑optimization pass (07‑06, the current tip).** Two days after the iteration‑1 close,
  `db470f6` "Brain optimization pass: verifier ON, MCQ option‑match, eval harness, CI"
  (ayushmaitistartups‑cmyk + Claude, 35 files, +1203/−88) lands the `improvment/08`
  brain‑optimization plan on top of the guardrail layer that `4d79344` had introduced. On the
  accuracy side it flips the free math verifier on by default (`MATH_VERIFY_ENABLED` False → True,
  so the numpy/chem/option verifier now runs on every quantitative turn and its DISAGREE gates
  escalation), lowers `GEMINI_TEMPERATURE` 1.0 → 0.4, and adds an **MCQ option‑match** check to
  `math_verifier.py` — a computed final answer that matches no listed option is treated as a
  wrong‑equation signal that outranks a substitute‑back agree. Prompts become versioned code:
  `PROMPT_VERSION = "1.0.0"` is stamped into every turn trace. Around the runtime it adds a new
  **`evals/` harness** (graders + runner + paired‑McNemar report + a ~50‑case JEE/NEET golden set)
  and the branch's first **CI workflow**, `.github/workflows/backend-ci.yml` (ruff + pytest +
  grader selftest), converting 13 script‑style tests to run under pytest along the way.

### 3.15 Admin Analytics tab + config-to-prod alignment (2026-07-07 → 2026-07-11)

The 19 commits after the brain‑optimization pass are a single, coherent wave: the backend half of a
new admin **"Analytics" tab** (the frontend half is Hellinferno's seed `b91a229` plus
ayushmaitistartups‑cmyk's iterations — see
[03-frontend-commits-and-pull-requests.md](03-frontend-commits-and-pull-requests.md) §3.11). All 19
are single‑parent commits; all but two (samiul's docs) are by ayushmaitistartups‑cmyk.

- **Docs + config + CI removal (07‑07 → 07‑08).** samiul lands backend dev docs under `docs/`
  (`7b1fb94` "added docs", `5077d5d` "fixed readme ci error"). ayushmaitistartups‑cmyk then aligns
  `config.py` defaults with the production env (`939e0bd`) and **removes the CI workflow**
  (`e53ce33`) — deleting the `.github/workflows/backend-ci.yml` that `db470f6` had added on 07‑06, so
  the branch's brief CI experiment was **added‑then‑removed** across three days.
- **Range‑aware analytics endpoints + latency stages (07‑09 → 07‑10).** `324bc6d` adds range‑aware
  (today / yesterday / 7d / 30d) admin analytics endpoints plus a **model‑selection** latency stage.
  A run of dispatch‑path instrumentation records equation‑render, voice (TTS), and graph‑render
  latency as their own analytics stages (`87b4759`, `7a8088d`, `7fd47cd`, `a26a9f5`), and `2616aca`
  exposes the generation‑avg sample count (`n_generation`). `070a65a` / `230f74b` are a
  sync‑then‑revert pair that keeps only the intended `main.py` gzip change after a stale `config.py`
  clobber.
- **`turn_traces`‑sourced per‑question rows + IST bucketing (07‑11).** The final push sources the
  Questions table from `turn_traces` so **failed / cancelled** turns appear (`f2505a0`), filters to
  **lamp‑only** turns and surfaces a failure **Reason** (dropping web‑simulator turns, `6adc1d1`),
  buckets today/yesterday and the trend by **IST (Asia/Kolkata)** rather than UTC (`9b245cc`), renames
  the "Upload from lamp" stage to "Lamp response loading" (`4b96e63`), adds a tier **escalation
  breakdown / funnel** and fixes Tier/model + Reason accuracy (`7387ed7`), and finishes on the current
  tip `5ea5815` "Admin Analytics: add question Level + per‑question escalation to Questions table".
- **Gemini "Tutor unavailable" fix.** `591ca0b` retypes the `given` field from an open dict to a
  typed `list[GivenItem]`, fixing a schema‑validation crash that had surfaced to the lamp as
  "Tutor unavailable".

---

## Appendix: authorship & cadence

**Commits per author (of 136, exact per `contributors.txt`):**

| Author | Commits | Signature areas |
| --- | ---: | --- |
| samiul | 84 | session/protocol, dispatch, providers, TTS/codecs (incl. Cartesia), memory, escalation, streaming, graphs, chemistry/RDKit, OTA, memory‑leak/CPU‑crash hardening, backend dev docs (`docs/`) |
| ayushmaitistartups-cmyk | 36 | prompt architecture, tiered escalation, web simulator, nudge/verdict guardrails, output‑validator/math‑verifier (Claude‑assisted), brain‑optimization pass, eval harness, CI (later removed), range‑aware admin **Analytics tab** + latency/escalation analytics, config‑to‑prod alignment |
| shashi-3000 | 16 | DB/Supabase, admin, Clerk, model‑eval, turn‑trace, screen outputs, Claude STT, reasoning/TTS, analytics/pilot/insights |

**Co‑authorship:** several `ayushmaitistartups‑cmyk` commits carry `Co-Authored-By:` trailers for
**Claude Opus 4.8 (1M context)** (`7154406`, `cb128eb`, `90477e4`, `224be7f`, `25e3ad2`, `2584767`,
`96221c1`, `61ac092`, and the post‑snapshot guardrail work `c44f5cb`, `6cc7423`, `b235d4e`, `74c3e2f`,
`dc9a936`, `8db448f`, `4d79344`), **Claude Sonnet 4.6** (`8418c76`, `5664677`), and **Claude Fable 5**
(`db470f6`, the 2026‑07‑06 brain‑optimization pass), reflecting AI‑assisted prompt, escalation,
output‑validation, and eval/CI work.

**Cadence:** development is bursty, concentrated in late‑night/early‑morning IST sessions (the earlier
detailed export clustered around 20:00–03:00 `+0530`; the regenerated log is date‑only). The two
largest single commits remain the scaffold `4f7a77d` (+6472) and the auth/layer build `da4bd6a`
(+2678), both on day 1; the largest post‑snapshot commits are the analytics/pilot drop `4a4af29`
(+2466), the guardrail layer `4d79344` (+1447), and the brain‑optimization pass `db470f6` (+1203).
The most file‑heavy commits are still the `turn_captures/` artifact moves (`e17e0dc` touches 144
files, `467d2a5` 127 files). The 2026‑07‑07 → 07‑11 admin Analytics‑tab wave is the opposite shape —
19 mostly small, single‑purpose commits (docs, config, per‑stage latency instrumentation,
`turn_traces` rows), clustered on 2026‑07‑11 (9 commits).

**Date span:** `2026‑05‑26` (`bc4ba83`) → `2026‑07‑11` (`5ea5815`), i.e. ~46 calendar days for all
136 commits.

---

*Source: `D:/clartiy/information/06-git-history/raw/backend-full-log.txt` (full `--stat` log) and
`backend-oneline.txt` (oneline log). All hashes, dates, authors, subjects, and file paths above are
transcribed from those two files.*
