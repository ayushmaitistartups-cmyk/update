# Git History — Frontend Branch & Pull-Request / Merge Analysis

> **Repository:** `ayushmaitistartups-cmyk/Smart-Tutor-frontend`
> **Branch documented:** `main` (59 commits)
> **Stack:** Next.js (App Router) + TypeScript + Tailwind + Clerk auth + Supabase-backed admin + FastAPI backend integration
> **Span:** 2026-05-28 → 2026-07-11 (≈ 44 days)
> **Contributors (by commit count):** `ayushmaitistartups-cmyk` (40) · `shashi-3000` (12) · `samiul` (6) · `Hellinferno` (1, new)

> **Note (2026-07-06):** the local clone of `Smart-Tutor-frontend` was briefly removed from disk earlier that day and **restored the same day** by re-cloning the (unaffected) remote — tip at the time unchanged at `ef07d7f` (2026-07-02).

> **Update (2026-07-11):** the frontend has since advanced **16 commits** past `ef07d7f` — one wave, an admin **"Analytics" tab** (see [§3.11](#311-admin-analytics-tab)) — bringing `main` to **59 commits** (tip `2a09869`, 2026-07-11) and adding a **fourth contributor, `Hellinferno <ravi832006ravi@gmail.com>`**, who created the tab (`b91a229`, 2026-07-09) before `ayushmaitistartups-cmyk` iterated the remaining 15. The `raw/frontend-*.txt` and `contributors.txt` exports were regenerated to the new tip; note the regenerated `frontend-full-log.txt` carries commit messages + `Co-Authored-By` trailers but **not** `--stat` diffstats, so the "Files / ±" column is left as "—" for the 07-09 → 07-11 rows.

This document reconstructs the complete `main`-branch history of the Smart-Tutor-Lamp **frontend** (the web companion app for the ESP32-S3 AI tutor lamp). It is built entirely from local Git data — the full per-commit log, the oneline log, and the contributor tally — because the GitHub Pull-Request API could not be reached from this environment (see the [Pull Requests & Merges](#pull-requests--merges) section for the caveat about PR metadata).

---

## Table of Contents

1. [Summary](#1-summary)
2. [Complete Chronological Commit Table (all 59 commits)](#2-complete-chronological-commit-table-all-59-commits)
3. [Thematic Narrative](#3-thematic-narrative)
   - [3.1 Next.js Scaffold](#31-nextjs-scaffold)
   - [3.2 Landing Page](#32-landing-page)
   - [3.3 Authentication / Clerk](#33-authentication--clerk)
   - [3.4 Dashboard](#34-dashboard)
   - [3.5 Devices](#35-devices)
   - [3.6 Pairing / Onboarding](#36-pairing--onboarding)
   - [3.7 Analytics](#37-analytics)
   - [3.8 Admin](#38-admin)
   - [3.9 Simulator](#39-simulator)
   - [3.10 Deployment](#310-deployment)
   - [3.11 Admin Analytics Tab](#311-admin-analytics-tab)
4. [Pull Requests & Merges](#4-pull-requests--merges)
   - [4.1 What the Git data shows](#41-what-the-git-data-shows)
   - [4.2 Merge commits](#42-merge-commits)
   - [4.3 Three-contributor collaboration pattern](#43-three-contributor-collaboration-pattern)
   - [4.4 Caveat: formal PR metadata requires GitHub authentication](#44-caveat-formal-pr-metadata-requires-github-authentication)
   - [4.5 Same caveat applies to the Smart-Tutor-Lamp repo](#45-same-caveat-applies-to-the-smart-tutor-lamp-repo)
5. [Appendix: Author Tally Across All Repos](#5-appendix-author-tally-across-all-repos)

---

## 1. Summary

The `Smart-Tutor-frontend` repo holds a single `main` branch with **59 commits** spanning roughly six weeks (2026-05-28 → 2026-07-11). Unlike the `Smart-Tutor-Lamp` repo (which carries two unrelated orphan branches — firmware and backend — with no common ancestor), the frontend is a conventional linear-ish history with one cross-author sync merge.

The project went from a **single large "first commit"** that landed the entire Next.js scaffold (45 files, 5,633 insertions, authored by `samiul`) to a mature application featuring a marketing landing page, Clerk authentication, an onboarding flow, device pairing (QR + numeric code), a dashboard, an analytics dashboard with charts, a Supabase-backed admin console with trace/journey inspection, a browser-based **simulator** that exercises the lamp's multimodal (camera + mic + multi-LLM) tutoring pipeline without physical hardware, and — most recently — an admin **"Analytics" tab** with range-aware (today / yesterday / 7d / 30d) generation/total-latency and per-question latency + tier-escalation reporting.

Three people drove the work, each with a recognizable focus:

| Contributor | Commits | Center of gravity |
|---|---:|---|
| `ayushmaitistartups-cmyk` (Ayush) | 40 | Simulator capture UX, deployment (`RUN.md`) cadence, multi-LLM, bug fixes, analytics/aggregation + OTA admin views, page-skeleton optimizations, the admin **Analytics tab** build-out (15 of its 16 commits), repo ownership |
| `shashi-3000` (Shashi) | 12 | Admin console, trace/journey views, Supabase, multi-LLM models, auth-guard time handling, personalization/survey + analysis views |
| `samiul` (Samiul) | 6 | Initial scaffold, onboarding, backend↔frontend wiring, analytics pages, multi-image |
| `Hellinferno` (new) | 1 | Created the admin **Analytics tab** (`b91a229`, 2026-07-09) — generation + total latency, range-aware — which Ayush then iterated |

A single merge commit (`d0c299b`, by `shashi-3000`) records a `git pull`-style integration of divergent `main` histories between collaborators — the only structural evidence of parallel branches in the local data.

---

## 2. Complete Chronological Commit Table (all 59 commits)

Ordered **oldest → newest** (top = first commit, bottom = latest). Hashes are short SHAs. "Files / ±" summarizes the diffstat from the full log; the merge commit has no diffstat, and the 2026-07-09 → 07-11 admin Analytics-tab rows (#44–#59) show "—" because the regenerated `frontend-full-log.txt` omits `--stat` for those commits (see the 2026-07-11 note near the top).

| # | Date | SHA | Author | Subject | Files / ± |
|---:|---|---|---|---|---|
| 1 | 2026-05-28 | `ea2805b` | samiul | first commit | 45 files, **+5,633** |
| 2 | 2026-05-29 | `bf70c03` | samiul | Fixes | 3 files, +283 / −18 |
| 3 | 2026-05-29 | `4320bbb` | samiul | added backend frontend connection | 11 files, +272 / −83 |
| 4 | 2026-05-29 | `df38eca` | samiul | Added more onboarding question and fixes | 8 files, +267 / −200 |
| 5 | 2026-05-30 | `c6e35d5` | ayushmaitistartups-cmyk | Use rear camera for simulator capture | 1 file, +1 / −1 |
| 6 | 2026-05-30 | `e313709` | samiul | Clerk Bug Fix and Analytics pages | 11 files, +743 / −17 |
| 7 | 2026-05-30 | `b4bc5e4` | samiul | Fixed the profile and added Multi-Image support | 3 files, +284 / −68 |
| 8 | 2026-05-30 | `3db01e0` | ayushmaitistartups-cmyk | fixed | 1 file, +6 |
| 9 | 2026-05-30 | `fe978cc` | ayushmaitistartups-cmyk | Fix server-side crash: make AppHeader a client component | 1 file, +2 |
| 10 | 2026-05-30 | `f05e944` | ayushmaitistartups-cmyk | Fixed profile UI | 2 files, +24 |
| 11 | 2026-05-31 | `9b1c619` | ayushmaitistartups-cmyk | Portrait camera in simulator (worksheet pages are taller than wide) | 2 files, +5 / −2 |
| 12 | 2026-05-31 | `a5cd611` | ayushmaitistartups-cmyk | Hands-free auto multi-capture while holding the mic | 1 file, +122 / −7 |
| 13 | 2026-06-02 | `6a1a261` | shashi-3000 | Admin , DB and consistency related updates | 13 files, +1,053 / −119 |
| 14 | 2026-06-02 | `e571690` | ayushmaitistartups-cmyk | fixed bugs | 1 file, +18 / −11 |
| 15 | 2026-06-02 | `12b8fdf` | shashi-3000 | fixed bugs | 1 file, +1 / −1 |
| 16 | 2026-06-02 | `d0c299b` | shashi-3000 | **Merge branch 'main'** of …/Smart-Tutor-frontend | _(merge — no diffstat)_ |
| 17 | 2026-06-02 | `28a2d88` | ayushmaitistartups-cmyk | Changed the md for deployment | 1 file, +1 / −1 |
| 18 | 2026-06-02 | `1311e27` | shashi-3000 | time mismtach updates | 1 file, +44 / −32 |
| 19 | 2026-06-02 | `450ab0d` | ayushmaitistartups-cmyk | for deployment | 1 file, +1 / −1 |
| 20 | 2026-06-03 | `3d29f76` | shashi-3000 | Run.md updates | 1 file, +3 |
| 21 | 2026-06-04 | `1db7e75` | shashi-3000 | Added multiple LLM features | 2 files, +710 / −65 |
| 22 | 2026-06-06 | `8f0973f` | ayushmaitistartups-cmyk | for deployment | 1 file, +2 / −5 |
| 23 | 2026-06-06 | `544da14` | shashi-3000 | Updates | 5 files, +270 / −6 |
| 24 | 2026-06-07 | `8b2e21a` | shashi-3000 | Updated Turns and other fixes | 11 files, +1,034 / −131 |
| 25 | 2026-06-07 | `4a19acf` | ayushmaitistartups-cmyk | For deployment | 1 file, +1 / −1 |
| 26 | 2026-06-10 | `e4fa516` | ayushmaitistartups-cmyk | Big fixed | 6 files, +74 / −28 |
| 27 | 2026-06-11 | `ca7251f` | ayushmaitistartups-cmyk | bug fix | 1 file, +22 / −1 |
| 28 | 2026-06-11 | `748a334` | ayushmaitistartups-cmyk | fixed Latex | 1 file, +56 / −4 |
| 29 | 2026-06-12 | `85ada6c` | ayushmaitistartups-cmyk | added multi LLM support | 2 files, +79 |
| 30 | 2026-06-12 | `9002e68` | ayushmaitistartups-cmyk | added error log screen | 2 files, +18 / −5 |
| 31 | 2026-06-12 | `5c8a4ba` | shashi-3000 | Tunrs Updated | 3 files, +492 |
| 32 | 2026-06-12 | `f0556f3` | ayushmaitistartups-cmyk | for deployment | 1 file, +1 / −1 |
| 33 | 2026-06-12 | `0b93f95` | shashi-3000 | Added Bound Box and Updated Supabase | 3 files, +340 / −11 |
| 34 | 2026-06-12 | `ea696b3` | ayushmaitistartups-cmyk | for the deployment | 1 file, +1 / −1 |
| 35 | 2026-06-13 | `d3b66a4` | ayushmaitistartups-cmyk | bug fixed | 1 file, +6 / −2 |
| 36 | 2026-06-13 | `9c93242` | ayushmaitistartups-cmyk | added retry info | 1 file, +11 / −5 |
| 37 | 2026-06-16 | `f676e92` | shashi-3000 | Added claude stt related updates | 2 files, +35 / −1 |
| 38 | 2026-06-16 | `5ac12b8` | ayushmaitistartups-cmyk | for the deployment | 1 file, +1 / −1 |
| 39 | 2026-06-28 | `283da32` | shashi-3000 | few analysis related updates | 13 files, +1,980 / −31 |
| 40 | 2026-06-28 | `1bd9723` | ayushmaitistartups-cmyk | added analytics | 4 files, +544 / −19 |
| 41 | 2026-06-28 | `841b71c` | ayushmaitistartups-cmyk | added the aggregated | 3 files, +126 |
| 42 | 2026-07-01 | `0ad46f7` | ayushmaitistartups-cmyk | added OTA | 2 files, +173 / −3 |
| 43 | 2026-07-02 | `ef07d7f` | ayushmaitistartups-cmyk | optimizations | 14 files, +239 / −57 |
| 44 | 2026-07-09 | `b91a229` | **Hellinferno** | Add admin Analytics tab (generation + total latency) | — |
| 45 | 2026-07-10 | `e7b70ec` | ayushmaitistartups-cmyk | chore: trigger Vercel deploy of Analytics tab under account owner | — |
| 46 | 2026-07-10 | `79c103c` | ayushmaitistartups-cmyk | Analytics tab: add Equation-render + Voice (TTS) columns per question | — |
| 47 | 2026-07-10 | `90ca75f` | ayushmaitistartups-cmyk | Analytics tab: show the window + sample counts on every card | — |
| 48 | 2026-07-10 | `415d8c5` | ayushmaitistartups-cmyk | Analytics tab: raise text contrast (faint -> muted, key numbers bright) | — |
| 49 | 2026-07-10 | `e2b441e` | ayushmaitistartups-cmyk | Analytics questions: explain what a dash (—) means | — |
| 50 | 2026-07-10 | `db12929` | ayushmaitistartups-cmyk | Analytics: add Graph-render column per question | — |
| 51 | 2026-07-11 | `b8e84b1` | ayushmaitistartups-cmyk | Analytics table: show failed/cancelled turns with a Status column | — |
| 52 | 2026-07-11 | `68fefa3` | ayushmaitistartups-cmyk | Analytics: show averages only (hide p95 in stage rows, tiles, legend) | — |
| 53 | 2026-07-11 | `372e56e` | ayushmaitistartups-cmyk | Analytics: number stages as a step sequence (pipeline order, 1..N) | — |
| 54 | 2026-07-11 | `ec5b6cd` | ayushmaitistartups-cmyk | Analytics table: lamp-only + swap Status column for Reason | — |
| 55 | 2026-07-11 | `87be573` | ayushmaitistartups-cmyk | Analytics stages: accurate step grouping (parallel + escalation) | — |
| 56 | 2026-07-11 | `5b1ef69` | ayushmaitistartups-cmyk | Admin Analytics: replace latency chart with tier Escalation breakdown | — |
| 57 | 2026-07-11 | `365862b` | ayushmaitistartups-cmyk | Admin Analytics: remove Graph column from the Questions table | — |
| 58 | 2026-07-11 | `54f330c` | ayushmaitistartups-cmyk | Admin Analytics: show question Level + escalation in the Questions table | — |
| 59 | 2026-07-11 | `2a09869` | ayushmaitistartups-cmyk | Admin Analytics: remove Lamp column from the Questions table _(tip)_ | — |

> **Note on ordering near 2026-06-02:** Commits #14–#19 all share the date `2026-06-02` and bracket the merge commit `d0c299b`. The table follows the reverse order of the source `git log` (which lists newest-first), so the relative ordering of same-day commits reflects the log's topological output, not necessarily wall-clock authoring time. The presence of the merge at #16 is the key structural fact (see §4.2).

---

## 3. Thematic Narrative

The history is best understood as **one big scaffold drop followed by feature deepening across nine functional areas plus a constant deployment heartbeat**, and — in a late cluster (06-28 → 07-02) — additional personalization/survey/analytics surfaces and a load-performance pass, then — in the final wave (07-09 → 07-11) — a new admin **"Analytics" tab** (§3.11). The areas below trace how each feature surface evolved.

### 3.1 Next.js Scaffold

Everything begins with **`ea2805b` "first commit"** (samiul, 2026-05-28) — a single commit that lays down the entire Next.js App Router project: 45 files, 5,633 insertions. This one commit already contains the skeletons of nearly every later feature:

- **Tooling / config:** `package.json`, `package-lock.json` (2,061 lines), `tsconfig.json`, `tailwind.config.ts`, `postcss.config.js`, `next-env.d.ts`, `.gitignore`, plus a custom type shim `types/react-katex.d.ts` (early signal that LaTeX/math rendering was in scope).
- **App shell:** `app/layout.tsx`, `app/globals.css` (294 lines), `app/providers.tsx`, `app/page.tsx` (landing entry), and `middleware.ts` (route protection).
- **Route stubs:** `app/connect`, `app/dashboard`, `app/devices`, `app/onboarding`, `app/pair` + `app/pair/[code]`, `app/sign-in/[[...sign-in]]`, `app/sign-up/[[...sign-up]]`, `app/simulator`.
- **Lib layer:** `lib/api.ts`, `lib/auth-guard.ts`, `lib/devices.ts`, `lib/onboarding.ts`, `lib/pairing-code.ts`, `lib/profile.ts`, `lib/time.ts`, `lib/useSimulatorCapture.ts`.
- **Components:** app components (`AppHeader`, `AnalyticsCards`, `ConfirmDialog`, `ErrorPanel`, `QrScanner`) and a full landing-page component set (`Hero`, `Nav`, `Features`, `Exams`, `CTA`, `Footer`, `Lamp`, `motion`).

So the architecture (App Router pages + a `lib/` service layer + `components/app` and `components/landing` split) was set on day one; subsequent commits are refinements within this structure rather than re-architectures.

### 3.2 Landing Page

The marketing surface arrives whole in the scaffold (`components/landing/*`): a `Hero` (112 lines), animated `Lamp` (79), `Features` (67), `Exams` (87 — exam-prep targeting), `CTA`, `Nav`, `Footer`, and a `motion.tsx` animation helper (82). The landing page sees little churn afterward — it was effectively "done" at scaffold time, which is why no later commit subject is dedicated to it. Global polish that touches the landing experience flows through `app/globals.css` / `app/layout.tsx` edits in later commits (e.g. `f05e944` "Fixed profile UI").

### 3.3 Authentication / Clerk

Clerk is the auth provider, wired from the scaffold via `middleware.ts`, `app/providers.tsx`, `lib/auth-guard.ts`, and the catch-all `sign-in` / `sign-up` routes. The auth surface then absorbed several targeted fixes:

- **`fe978cc`** (ayush, 05-30) "Fix server-side crash: make AppHeader a client component" — `AppHeader` was rendering Clerk client-only sub-components (`UserButton.MenuItems` / `Link` / `Action`) from a Server Component, producing a React Client Manifest error that 500'd `/dashboard` and `/analytics`. Adding `'use client'` moved the header into the client boundary. (A genuine Next.js server/client boundary bug — classic App Router footgun.)
- **`e313709`** (samiul, 05-30) "Clerk Bug Fix and Analytics pages" — touches the sign-in/sign-up pages and `lib/auth-guard.ts` alongside building analytics.
- **`1311e27`** (shashi, 06-02) "time mismtach updates" and parts of **`6a1a261`** rework `lib/auth-guard.ts` heavily (a near-full rewrite: +197/−119 in `6a1a261`) to harden session/time handling and consistency.

### 3.4 Dashboard

`app/dashboard/page.tsx` ships in the scaffold (102 lines) and is the authenticated home. It receives incremental adjustments rather than a rewrite: `df38eca` and `6a1a261` both tweak `app/dashboard/page.tsx` as onboarding/admin data plumbing changed. The dashboard composes shared pieces like `components/app/AnalyticsCards.tsx` and `AppHeader`.

### 3.5 Devices

Device management lands fully formed in the scaffold: `app/devices/page.tsx` (282 lines) plus `lib/devices.ts` (177 lines) for the device service layer, and `app/connect/page.tsx` (43) as the connection entry point. Later bug-fix passes touch `lib/devices.ts` (e.g. `e4fa516` "Big fixed", which adjusts `lib/api.ts`, `lib/devices.ts`, `lib/profile.ts`, and admin/journey components together) but the devices feature was largely complete at scaffold time.

### 3.6 Pairing / Onboarding

Two intertwined flows that got the most early iteration after the scaffold:

- **Pairing** is delivered in the scaffold: `app/pair/page.tsx`, the dynamic `app/pair/[code]/page.tsx` (222 lines), `lib/pairing-code.ts`, and `components/app/QrScanner.tsx` (206 lines) for QR-based device linking.
- **Onboarding** is the area samiul iterated hardest on across the first week:
  - `4320bbb` (05-29) "added backend frontend connection" — connects `app/onboarding/*` and the simulator to the FastAPI backend, adding `RUN.md`, editing `app/layout.tsx`, `OnboardingForm.tsx`, `actions.ts`, `page.tsx`, `lib/auth-guard.ts`, and a new `package.json` dependency.
  - `df38eca` (05-29) "Added more onboarding question and fixes" — large rework of `OnboardingForm.tsx` (−200/+187 churn), `lib/onboarding.ts`, and `lib/auth-guard.ts`.
  - `e313709` (05-30) and `6a1a261` (06-02) further adjust `app/onboarding/actions.ts` / `page.tsx` / `OnboardingForm.tsx` as profile persistence and admin consistency evolved.

### 3.7 Analytics

The student-analytics dashboard is introduced by **`e313709`** (samiul, 05-30) "Clerk Bug Fix and Analytics pages": it adds `app/analytics/page.tsx`, the substantial `components/app/AnalyticsView.tsx` (307 lines), and a reusable `components/app/charts.tsx` (271 lines), wiring them through `lib/profile.ts` and `middleware.ts`. Charts later gain reuse in the admin console (`544da14` adds 36 more lines to `components/app/charts.tsx`). The analytics surface is substantially expanded in the late cluster — `283da32` (06-28) grows `AnalyticsView.tsx` (+197) and adds personalization/survey views, while `1bd9723` / `841b71c` add analytics and aggregated-decomposition reporting (see §3.8).

### 3.8 Admin

The admin/observability console is **`shashi-3000`'s signature contribution** and grows steadily:

- **`6a1a261`** (06-02) "Admin , DB and consistency related updates" — the big bang: a new `components/app/AdminView.tsx` (593 lines), a new `lib/admin.ts` (194 lines), a new `app/admin/page.tsx`, plus consistency edits across auth-guard, api, profile, providers, header, and middleware. (Largest non-scaffold commit at 13 files / +1,053.)
- **`544da14`** (06-06) "Updates" — expands `AdminView.tsx` (+157) and `lib/admin.ts` (+71), adds chart support.
- **`8b2e21a`** (06-07) "Updated Turns and other fixes" — a wide 11-file commit (+1,034) introducing `components/app/BootDiagnostics.tsx` (108) and `components/app/JourneyBreakdown.tsx` (159), a new `lib/log.ts` (208) logging layer, and big growth in `lib/models.ts` and `lib/api.ts` — connecting admin to per-session tutoring "turns."
- **`5c8a4ba`** (06-12) "Tunrs Updated" — adds `components/app/TraceView.tsx` (402) plus `AdminView` / `lib/admin.ts` growth: a trace inspector for tutoring sessions.
- **`0b93f95`** (06-12) "Added Bound Box and Updated Supabase" — extends `TraceView.tsx` (+140) and `AdminView.tsx` (+151), wires Supabase via `lib/admin.ts` (+60); "Bound Box" implies image bounding-box visualization for captured worksheet frames.
- **`f676e92`** (06-16) "Added claude stt related updates" — adds Claude speech-to-text reporting to `AdminView.tsx` and `lib/admin.ts`.
- **`283da32`** (shashi, 06-28) "few analysis related updates" — the largest post-snapshot frontend commit (13 files, +1,980): a big `AdminView.tsx` (+595) and `AnalyticsView.tsx` (+197) growth plus **new** `components/app/PersonalizationView.tsx` (+229), `SurveyView.tsx` (+322), `PersonalizeCard.tsx`, `ReportProblem.tsx`, `lib/pilot.ts` (+133), and new `app/personalize` / `app/survey` pages — extending admin/analytics into personalization and survey capture.
- **`1bd9723`** (ayush, 06-28) "added analytics" — `AdminView.tsx` (+125), `TraceView.tsx` (+38), `lib/admin.ts`, and a new top-level `OPTIMIZATION.md` (+377).
- **`841b71c`** (ayush, 06-28) "added the aggregated" — the aggregated-decomposition view across `AdminView.tsx` (+71), `TraceView.tsx`, `lib/admin.ts` (mirrors the backend "aggregated decomposition" work).
- **`0ad46f7`** (ayush, 07-01) "added OTA" — surfaces the backend OTA subsystem in the admin console: `AdminView.tsx` (+118) and `lib/admin.ts` (+58).
- **`ef07d7f`** (ayush, 07-02) "optimizations" — the tip at the 2026-07-02 snapshot: adds per-route `loading.tsx` skeletons and a shared `components/app/PageSkeleton.tsx`, reworks `lib/auth-guard.ts` (+82/−…), and tunes `QrScanner.tsx` / `useSimulatorCapture.ts` / the simulator — a load-performance pass across 14 files.
- **Admin Analytics tab (`b91a229` → `2a09869`, 07-09 → 07-11)** — the newest addition to `AdminView.tsx` / `lib/admin.ts`, a range-aware latency + tier-escalation observability view carrying `main` to its current tip. Documented separately in **§3.11**.

### 3.9 Simulator

The **simulator** (`app/simulator/page.tsx`, 309 lines in the scaffold; `lib/useSimulatorCapture.ts`, 188) is the app's most actively developed feature — a browser harness that emulates the physical lamp's capture-and-tutor loop. Its evolution:

- **Camera capture UX** (ayush + samiul):
  - `c6e35d5` (05-30) "Use rear camera for simulator capture" — `facingMode: ideal environment` so phones use the rear camera.
  - `9b1c619` (05-31) "Portrait camera in simulator" — portrait constraints (720×1280) and `aspect-[3/4]` preview, because worksheet pages are taller than wide.
  - `a5cd611` (05-31) "Hands-free auto multi-capture while holding the mic" — while the mic is held, snap a frame every ~1.4 s and keep only visibly-different, non-blurry pages (160 px grayscale diff + Laplacian-variance sharpness), capped at `MAX_IMAGES` with a live N/5 counter. Lets a student flip question/working pages and send them all without tapping the shutter.
  - `b4bc5e4` (samiul, 05-30) "Fixed the profile and added Multi-Image support" — large simulator rework (+302/−68) enabling multi-image submission.
- **Multimodal pipeline & LaTeX:**
  - `bf70c03` (samiul, 05-29) "Fixes" — early big simulator edit (+138) and the first large `RUN.md` (161 lines).
  - `748a334` (06-11) "fixed Latex" — math rendering in the simulator.
  - `ca7251f` (06-11) "bug fix", `9002e68` (06-12) "added error log screen", `9c93242` (06-13) "added retry info" — progressive resilience (error surfacing + retry UX) in `app/simulator/page.tsx`.
- **Multi-LLM support** (the recurring theme of the second half):
  - `1db7e75` (shashi, 06-04) "Added multiple LLM features" — massive simulator rework (+604) plus a new `lib/models.ts` (171) abstracting model selection.
  - `85ada6c` (ayush, 06-12) "added multi LLM support" — adds model wiring (+59 in simulator, +20 in `lib/models.ts`).
  - `d3b66a4` (06-13) "bug fixed" — `lib/models.ts` fix.
  - `8b2e21a` (shashi, 06-07) also grows `lib/models.ts` (+155) as part of turns/logging work.

The simulator is thus the integration point where camera, mic, multi-image, LaTeX, multi-LLM model routing, and error/retry handling all converge.

### 3.10 Deployment

A distinct, **recurring "deployment heartbeat"** runs through the whole history: a string of tiny commits that flip one line in `RUN.md` (the run/deploy instructions). These are almost all by `ayushmaitistartups-cmyk` and act as deploy markers / redeploy triggers:

`3db01e0` "fixed" (+6) · `e571690` "fixed bugs" (RUN.md +18/−11) · `28a2d88` "Changed the md for deployment" · `450ab0d` "for deployment" · `3d29f76` "Run.md updates" · `8f0973f` "for deployment" · `4a19acf` "For deployment" · `f0556f3` "for deployment" · `ea696b3` "for the deployment" · `5ac12b8` "for the deployment" (06-16, the **last of the `RUN.md` deploy-marker one-liners**). These `RUN.md` bumps stop after 06-16; the deploy-trigger habit later reappears in a different form — `e7b70ec` (07-10) "chore: trigger Vercel deploy of Analytics tab under account owner", an owner-authored no-change re-commit that re-triggers the Vercel Hobby deploy (the Analytics-tab commit `b91a229` was authored by a non-owner identity that Vercel Hobby blocks). The current branch tip is `2a09869` (07-11), an Analytics-tab commit — no longer a deployment bump.

This pattern (≈10 of Ayush's 40 commits are `RUN.md`-only one-liners, plus the later Vercel-deploy chore `e7b70ec`) strongly suggests `RUN.md` — and later the owner-authored commit itself — doubled as a deployment-config / trigger in whatever host the team used (Vercel).

### 3.11 Admin Analytics Tab

The final wave (07-09 → 07-11, **16 commits**) adds a new **"Analytics" tab** to the admin console — a latency/escalation observability surface distinct from the student-facing analytics of §3.7. It is the frontend half of the cross-repo Analytics work whose backend half is documented in [02-backend-branch-commits.md](02-backend-branch-commits.md) §3.15.

- **Seed — `b91a229` (Hellinferno, 07-09) "Add admin Analytics tab (generation + total latency)".** The **only** commit by the new contributor `Hellinferno <ravi832006ravi@gmail.com>`. It adds an `AnalyticsTab` component to `AdminView.tsx` (range pills; co-headline tiles for avg generation + avg total, each with p95; a generation/total trend chart; per-stage avg+p95 bars; and a per-question table) plus an `AnalyticsRange` type and `useAnalytics{Summary,Questions,Timeseries}` hooks in `lib/admin.ts`, answering "how long does output generation take?" per question and in aggregate over a today / yesterday / 7d / 30d range. (Co-authored by Claude Opus 4.8, like the rest of the wave.)
- **Deploy unblock — `e7b70ec` (Ayush, 07-10).** Because `b91a229` was authored by a non-owner git identity that Vercel Hobby refuses to deploy, this owner-authored `chore:` re-commit ships the same tree so the tab actually deploys (see §3.10).
- **Ayush's 14-commit iteration (07-10 → 07-11)**, all by `ayushmaitistartups-cmyk`:
  - *Per-question columns:* Equation-render + Voice (TTS) columns (`79c103c`), a Graph-render column (`db12929`), a legend explaining that "—" means the turn didn't run that stage (`e2b441e`), and later a question **Level** (difficulty) column (`54f330c`).
  - *Readability:* window + sample counts on every card (`90ca75f`) and a text-contrast bump (faint → muted, bright key numbers, `415d8c5`).
  - *Failed/cancelled turns:* a Status column with row-tinting keyed on `trace_id` (`b8e84b1`), then swapping Status for a short failure **Reason** and filtering to **lamp-only** turns (`ec5b6cd`).
  - *Stage sequencing:* numbering stages as a step sequence (`372e56e`), then accurate parallel + escalation step grouping with ∥ / ↳ markers (`87be573`), and hiding p95 to show averages only (`68fefa3`).
  - *Escalation view:* replacing a broken latency-trend chart with a tier **Escalation breakdown** funnel and fixing the answering-tier read (`5b1ef69`), plus a further escalation-breakdown + Tier/model & Reason accuracy pass (`7387ed7`).
  - *Column pruning:* removing the near-empty Graph column (`365862b`) and the redundant Lamp/device column (`2a09869`, the current tip).

Net effect: the admin console gains a dedicated, range-aware latency + tier-escalation analytics view, sourced (on the backend) from `turn_traces` so failed/cancelled lamp turns are included.

---

## 4. Pull Requests & Merges

### 4.1 What the Git data shows

The GitHub Pull-Request API was **not accessible** in this environment: the `gh` CLI is unauthenticated, so no PR list, PR numbers, review threads, approval states, or PR↔commit associations could be retrieved. Everything in this section is therefore **reconstructed from local Git history only** (the merge graph, commit authorship, and timestamps). Where this report uses the word "PR-like" it means *inferred collaboration*, not a confirmed GitHub Pull Request.

The frontend `main` branch is **predominantly a single shared line of development**: most collaborators committed directly to `main` and pushed, rather than opening feature branches that merged via the GitHub UI. The evidence for this is that there is **exactly one merge commit** in the entire 59-commit history, and it is a `git pull`-style sync merge (subject literally `Merge branch 'main' of https://github.com/...`), not a `Merge pull request #N from ...` commit (which is the message GitHub auto-generates when a PR is merged).

> The absence of any `Merge pull request #N` commit message in the log is itself a signal: it is consistent with a **direct-push / shared-`main`** workflow rather than a PR-gated one — though it does **not** rule out PRs merged with "Squash and merge" or "Rebase and merge" (both of which erase the merge-commit evidence). This ambiguity can only be resolved with authenticated GitHub API access (see §4.4).

### 4.2 Merge commits

There is **one** merge commit on `main`:

| SHA | Date | Author | Subject | Interpretation |
|---|---|---|---|---|
| `d0c299b` | 2026-06-02 | `shashi-3000` | `Merge branch 'main' of https://github.com/ayushmaitistartups-cmyk/Smart-Tutor-frontend` | **Cross-author sync merge.** Shashi had local commits on `main` (e.g. `12b8fdf` "fixed bugs", and the larger `6a1a261` admin work) while the upstream `main` had advanced with Ayush's commits (e.g. `e571690` "fixed bugs"). Running `git pull` produced this no-diff merge to reconcile the two divergent histories. |

This is the textbook "two people pushed to `main` and the second one had to `pull` before pushing" merge. It is the **only** structural proof in the local data that development branched and re-converged, and it is what binds Shashi's admin/DB stream (`6a1a261`, `12b8fdf`) back together with Ayush's concurrent fixes (`e571690`) around 2026-06-02.

No other merges exist; the remaining 58 commits are linear additions on top of one another.

### 4.3 Three-contributor collaboration pattern

Three contributors drove the sustained collaboration on a shared `main` with clear, complementary specializations, and a fourth (`Hellinferno`) made a single drive-by commit late:

| Contributor | Commits | Role inferred from the diffs |
|---|---:|---|
| **`ayushmaitistartups-cmyk`** (Ayush) | **40** | Repo owner (the GitHub org/remote is under his name). Owns the **simulator capture experience** (rear/portrait camera, hands-free multi-capture), the **multi-LLM** front-end wiring, the **error/retry** UX, the **deployment heartbeat** (the many one-line `RUN.md` bumps), the late **analytics/aggregation + OTA admin views** and **page-skeleton optimizations**, and the **admin Analytics-tab build-out** (15 of its 16 commits, 07-10 → 07-11). Many small, high-frequency commits. |
| **`shashi-3000`** (Shashi) | **12** | Owns the **admin / observability** subsystem end-to-end: `AdminView`, `TraceView`, `JourneyBreakdown`, `BootDiagnostics`, `PersonalizationView`, `SurveyView`, `lib/admin.ts`, `lib/log.ts`, `lib/pilot.ts`, Supabase integration, plus the **multi-LLM `lib/models.ts`** core and **auth-guard time/consistency** hardening. Fewer but very large commits (e.g. +1,980, +1,053, +1,034, +710). Author of the lone sync merge. |
| **`samiul`** (Samiul) | **6** | **Founder of the codebase** — authored the entire scaffold "first commit" (+5,633), then the early **onboarding** depth, **backend↔frontend connection**, **analytics pages**, **Clerk fixes**, and **multi-image** support. Concentrated in the first week (05-28 → 05-30). |
| **`Hellinferno`** | **1** | New drive-by contributor (`ravi832006ravi@gmail.com`) — created the admin **Analytics tab** (`b91a229`, 07-09), which Ayush then iterated and re-triggered for deploy (§3.11). |

Collaboration timeline at a glance:

- **Week 1 (05-28 → 05-30):** samiul-dominated — scaffold + onboarding + backend wiring + analytics; Ayush begins simulator camera fixes in parallel.
- **Transition (05-31 → 06-02):** Ayush's simulator UX work overlaps Shashi's first admin/DB landing → the **sync merge `d0c299b`** reconciles the two streams.
- **Weeks 2–3 (06-03 → 06-16):** Shashi builds out admin/trace/journey + multi-LLM models in big drops; Ayush iterates simulator multi-LLM, error/retry, LaTeX, and keeps the deployment cadence; samiul tapers off after week 1.
- **Late cluster (06-28 → 07-02):** after a ~two-week gap the work resumes — Shashi's big analysis/personalization/survey drop (`283da32`, +1,980) and Ayush's analytics/aggregation (`1bd9723`, `841b71c`), OTA admin view (`0ad46f7`), and a page-skeleton optimization pass (`ef07d7f`, 07-02). These mirror the backend's contemporaneous analytics/OTA/graphs waves.
- **Analytics-tab wave (07-09 → 07-11):** `Hellinferno` seeds a new admin **Analytics tab** (`b91a229`), which Ayush unblocks for deploy and iterates over 15 commits to the current branch tip `2a09869` (07-11) — the frontend half of the cross-repo Analytics work (backend §3.15). See §3.11.

This is a **small, high-trust team committing directly to `main`** with light coordination (one pull-merge), each person effectively "owning" a vertical slice of the app (Ayush=simulator/deploy/analytics-tab, Shashi=admin/models, Samiul=scaffold/onboarding/analytics; plus Hellinferno's one-off Analytics-tab seed).

### 4.4 Caveat: formal PR metadata requires GitHub authentication

The following could **not** be determined from local Git data and **require authenticated access to the GitHub API** (e.g. an authenticated `gh pr list` / `gh api`):

- Whether any GitHub **Pull Requests** were actually opened, and their **PR numbers / titles / descriptions**.
- **Review** activity: requested reviewers, review comments, **approvals**, change-requests.
- **Merge method** used per PR (merge commit vs. **squash** vs. **rebase**) — squash/rebase merges would have collapsed PR history into the linear commits seen here, making them invisible locally.
- **CI / status checks**, linked issues, labels, milestones, and merge timestamps.
- Mapping of which commits belonged to which PR.

Because `gh` is unauthenticated in this environment, **none of the above is asserted in this document.** The collaboration described in §4.3 is inferred strictly from commit authorship, timestamps, diffstats, and the single merge commit — it should be read as a faithful reconstruction of the *git record*, not as confirmed GitHub PR metadata.

### 4.5 Same caveat applies to the Smart-Tutor-Lamp repo

The identical limitation applies to the companion **`ayushmaitistartups-cmyk/Smart-Tutor-Lamp`** repository, which holds two **orphan branches with no common ancestor** — `firmware` (21 commits) and `backend` (136 commits). Because those branches share no merge base, they were never merged into each other in Git, and any cross-branch coordination or pull-request workflow for that repo likewise **cannot be confirmed without GitHub authentication**. PR numbers, reviews, approvals, and merge methods for `Smart-Tutor-Lamp` are unavailable here for the same reason (unauthenticated `gh` CLI) and would need an authenticated GitHub API call to retrieve.

---

## 5. Appendix: Author Tally Across All Repos

For cross-reference, the contributor counts from `contributors.txt` across the whole project:

| Repo / branch | Author | Commits |
|---|---|---:|
| **Smart-Tutor-Lamp · firmware** | samiul | 21 |
| **Smart-Tutor-Lamp · backend** | samiul | 84 |
| | ayushmaitistartups-cmyk | 36 |
| | shashi-3000 | 16 |
| **Smart-Tutor-frontend · main** | ayushmaitistartups-cmyk | 40 |
| | shashi-3000 | 12 |
| | samiul | 6 |
| | Hellinferno | 1 |

*(The `Smart-Tutor-frontend · main` rows sum to 59, matching the commit table in §2. The merge commit `d0c299b` is counted under its author `shashi-3000`. Project-wide grand total: 21 + 136 + 59 = 216 across the two repos / three branches, current as of 2026-07-11 — the backend added 19 commits and the frontend 16 (the admin Analytics-tab wave) since the 2026-07-06 snapshot; firmware is unchanged at 21.)*

---

*Document generated from local Git logs (`frontend-full-log.txt`, `frontend-oneline.txt`, `contributors.txt`). PR/review metadata intentionally omitted — see §4.4–§4.5 — because GitHub API access was unavailable (unauthenticated `gh` CLI).*
