# Git History — Repositories, Branches, Contributors & Timeline

This is the definitive reference for the **version-control topology** of the Smart Tutor Lamp project. It documents the two GitHub repositories under the `ayushmaitistartups-cmyk` account, the unusual branching model (the firmware and the backend live as two *orphan* branches of a single repository that share **no common ancestor**), every contributor and their per-branch commit counts, and the full development timeline (2026-05-25 → 2026-07-11). All numbers, dates, hashes, author identities, and merge facts in this document are derived **directly** from the raw `git log` exports in `raw/` — nothing here is inferred about code behavior that is not visible in those logs.

> **Refresh note (2026-07-05).** This document was refreshed on 2026-07-05 after pulling 3 new commits (1 firmware, 2 backend) from GitHub and regenerating the three raw logs to the new branch tips. The regenerated `*-full-log.txt` exports use git's default `git log --stat --date=short` format (full 40-char hashes, date-only `Date:` lines) rather than the earlier custom banner format; §2.3 and §11.2 describe the current format.

> **Update (2026-07-06).** Four deltas since the 2026-07-05 refresh; the backend raw logs (`backend-full-log.txt`, `backend-oneline.txt`) and `contributors.txt` were regenerated today to match.
>
> 1. **New backend tip `db470f6`** (2026-07-06, `ayushmaitistartups-cmyk`, Claude-assisted): "Brain optimization pass: verifier ON, MCQ option-match, eval harness, CI" — 35 files, +1203/−88. It implements the `improvment/08` brain-optimization plan: `MATH_VERIFY_ENABLED` default flipped to True, `GEMINI_TEMPERATURE` 1.0 → 0.4, an MCQ option-match verifier, `PROMPT_VERSION` stamping into traces, a new `evals/` harness, the branch's first CI workflow (`.github/workflows/backend-ci.yml`), and 13 script-style tests converted to pytest.
> 2. **New counts:** backend **117** commits (samiul 82 / ayushmaitistartups-cmyk **19** / shashi-3000 16); backend span 2026-05-26 → **2026-07-06** (~41 days); project span 2026-05-25 → **2026-07-06**; grand total **181** (backend share ≈ 65%). Because `backend-oneline.txt` gained a line at the top, all line anchors into that file shifted by **+1**; anchors have been fixed where adjacent to updated claims, but anchors in untouched historical sections may point one line high.
> 3. **A fourth branch, `information`,** now exists in `Smart-Tutor-Lamp` (pushed to origin): a documentation branch forked from `firmware` at `e1de15a`, carrying the `information/` + `improvment/` knowledge-base folders on top of a firmware-code snapshot — 3 commits, all by ayushmaitistartups-cmyk: `11fff3d` "Add information documentation" (2026-07-03), `79705ae` "Add improvement documentation" (2026-07-03), `ed65231` "docs: brain-optimization plan + 2026-07-06 implementation record" (2026-07-06). Its docs-only commits are **excluded** from the 21 / 117 / 43 code-history counts. See §3.2.
> 4. **The local `Smart-Tutor-frontend` clone was briefly removed from disk and restored** on 2026-07-06 (re-cloned from the unaffected remote; tip unchanged at `ef07d7f`, 2026-07-02). The frontend raw logs and `contributors.txt` were **regenerated live from the restored clone** the same day — all three histories are locally re-queryable again, and the regenerated exports confirmed the prior snapshot exactly (43 commits, 25/12/6 by author).
>
> Tables and charts below have been updated where load-bearing; daily-cadence charts and other point-in-time visuals that still reflect the 2026-07-05 snapshot are footnoted rather than redrawn.

> **Update (2026-07-11).** Thirty-five new commits since 2026-07-06 (**19 backend + 16 frontend**; firmware unchanged) — all one theme: an admin **"Analytics" tab**. The `raw/*.txt` exports and `contributors.txt` were regenerated to the new tips.
>
> 1. **New backend tip `5ea5815`** (2026-07-11, `ayushmaitistartups-cmyk`): "Admin Analytics: add question Level + per-question escalation to Questions table". Backend grows 117 → **136** commits (samiul 82 → **84**, ayushmaitistartups-cmyk 19 → **36**, shashi-3000 16 unchanged); backend span now 2026-05-26 → **2026-07-11**. Because `backend-oneline.txt` gained 19 lines at the top, historical anchors into that file now point up to **19** lines high (the tip anchor `#L1` still resolves — it is the new tip `5ea5815`).
> 2. **New frontend tip `2a09869`** (2026-07-11, `ayushmaitistartups-cmyk`): "Admin Analytics: remove Lamp column from the Questions table". Frontend grows 43 → **59** commits and its tip has now **advanced past `ef07d7f`** (the 2026-07-02 tip recorded at the prior refresh); span now 2026-05-28 → **2026-07-11**. `frontend-oneline.txt` gained 16 lines at the top, so its historical anchors point up to **16** lines high.
> 3. **A fourth contributor identity, `Hellinferno <ravi832006ravi@gmail.com>`,** now appears — **1 frontend commit** (`b91a229`, 2026-07-09, "Add admin Analytics tab (generation + total latency)"), the seed of the whole Analytics wave, then iterated by `ayushmaitistartups-cmyk`. See §6.
> 4. **New counts:** grand total **216** (backend 136 / firmware 21 / frontend 59); project span 2026-05-25 → **2026-07-11**. Merges are **still exactly three** — all 35 new commits are plain single-parent commits.
> 5. **The 35 commits are one wave:** a range-aware (today / yesterday / 7d / 30d) admin **Analytics tab** — range-aware generation + total latency, per-question rows sourced from `turn_traces` (**failed / cancelled** turns included), a tier **escalation funnel**, new latency stages (model-selection, graph-render), **IST (Asia/Kolkata)** bucketing, and lamp-only filtering — plus a **config-defaults-to-production** alignment (`939e0bd`), **removal of the backend CI workflow** (`e53ce33`, 07-08 — the `.github/workflows/backend-ci.yml` added on 07-06 was **added-then-removed**), a Gemini "Tutor unavailable" bugfix (`591ca0b`), and backend dev docs under `docs/` (`7b1fb94`, `5077d5d`, samiul).

The source-of-truth artifacts read to produce this document are: [contributors.txt](raw/contributors.txt), [firmware-oneline.txt](raw/firmware-oneline.txt), [backend-oneline.txt](raw/backend-oneline.txt), [frontend-oneline.txt](raw/frontend-oneline.txt), plus the per-file `*-full-log.txt` exports ([firmware-full-log.txt](raw/firmware-full-log.txt), [backend-full-log.txt](raw/backend-full-log.txt), [frontend-full-log.txt](raw/frontend-full-log.txt)).

---

## Table of Contents

1. [Purpose & Scope of This Document](#1-purpose--scope-of-this-document)
2. [The Raw Data Sources (the "files" being documented)](#2-the-raw-data-sources-the-files-being-documented)
3. [Repository & Branch Topology](#3-repository--branch-topology)
4. [Why firmware + backend Are Unrelated Branches of One Repo](#4-why-firmware--backend-are-unrelated-branches-of-one-repo)
5. [Branching Model & Collaboration Workflow](#5-branching-model--collaboration-workflow)
6. [Contributors — Identities & Per-Branch Commit Counts](#6-contributors--identities--per-branch-commit-counts)
7. [Development Timeline (Date Ranges & Cadence per Branch)](#7-development-timeline-date-ranges--cadence-per-branch)
8. [The Three Sync-Merge Commits (the only merges)](#8-the-three-sync-merge-commits-the-only-merges)
9. [What Each Branch Contains (file-tree evidence from first commits)](#9-what-each-branch-contains-file-tree-evidence-from-first-commits)
10. [Integration Points & Cross-References to the Rest of the System](#10-integration-points--cross-references-to-the-rest-of-the-system)
11. [Edge Cases, Data Caveats & How To Reproduce](#11-edge-cases-data-caveats--how-to-reproduce)
12. [Appendix A — Full Firmware Commit Table](#appendix-a--full-firmware-commit-table)
13. [Appendix B — Full Backend Commit Table](#appendix-b--full-backend-commit-table)
14. [Appendix C — Full Frontend Commit Table](#appendix-c--full-frontend-commit-table)

---

## 1. Purpose & Scope of This Document

**Responsibility of this "subsystem".** Unlike the firmware, backend, or frontend chapters of this documentation set — which describe *running code* — this chapter describes the **project's source-control history**: where the code lives, how the three code-bases are split across repos and branches, who wrote what, and when. It exists so that a new engineer can:

- find the right repository and branch for a given component (firmware C++, Python backend, or Next.js frontend);
- understand the *non-obvious* repo layout (two unrelated branches in one repo) before they `git clone` and get confused by `git checkout firmware` showing a completely different file tree than `git checkout backend`;
- attribute work and understand contribution distribution;
- reconstruct the timeline of when features landed (useful when correlating a behavior change to a date).

**Scope.** Three logical histories:

| Logical history | GitHub repo | Branch | Commits |
|---|---|---|---|
| Firmware (ESP32-S3, C++/Arduino) | `Smart-Tutor-Lamp` | `firmware` (orphan) | **21** |
| Backend (Python FastAPI brain) | `Smart-Tutor-Lamp` | `backend` (orphan) | **136** |
| Frontend (Next.js + web simulator) | `Smart-Tutor-frontend` | `main` | **59** |
| **Total** | 2 repos | 3 code branches | **216** |

The commit counts above are quoted from the contributor summary in [contributors.txt:1](raw/contributors.txt#L1) (firmware = 21 by one author), [contributors.txt:4](raw/contributors.txt#L4) (backend = 84 + 36 + 16 = 136), and [contributors.txt:9](raw/contributors.txt#L9) (frontend = 40 + 12 + 6 + 1 = 59). The `information` docs branch (§3.2) is excluded from these code-history totals.

> **Counting caveat.** Earlier exports of the `*-oneline.txt` files lacked a trailing newline, so a naive `wc -l` under-counted each by 1 (it reported 20 / 115 / 42). The current exports end with a newline, so `wc -l` now reports the true counts directly — **21 / 136 / 59** — and the per-author tallies in `contributors.txt` (and an `awk | sort | uniq -c` over the author column) independently reproduce them. This document uses 21 / 136 / 59 throughout.

---

## 2. The Raw Data Sources (the "files" being documented)

Because this chapter documents history rather than executable code, the "files" under analysis are the seven git-export text files in [raw/](raw/). Their structure, generation, and field semantics:

### 2.1 `contributors.txt` — the aggregate shortlog

A pre-aggregated `git shortlog -sne`-style summary, partitioned by three headings. Full content:

```
=== FIRMWARE (Smart-Tutor-Lamp @firmware) ===
    21	samiul <samiulseikh1221@gmail.com>

=== BACKEND (Smart-Tutor-Lamp @backend) ===
    84	samiul <samiulseikh1221@gmail.com>
    36	ayushmaitistartups-cmyk <ayushmaiti.startups@gmail.com>
    16	shashi-3000 <shashi.yadav.ug23@nsut.ac.in>

=== FRONTEND (Smart-Tutor-frontend @main) ===
    40	ayushmaitistartups-cmyk <ayushmaiti.startups@gmail.com>
    12	shashi-3000 <shashi.yadav.ug23@nsut.ac.in>
     6	samiul <samiulseikh1221@gmail.com>
     1	Hellinferno <ravi832006ravi@gmail.com>
```

- **Format:** `<count><TAB><name> <<email>>`, grouped under `===`-delimited section banners (each naming the repo + branch), one section per logical history (regenerated live from all three clones on 2026-07-11; the frontend section gained a fourth line, `Hellinferno`, in this pass). See [contributors.txt:1-13](raw/contributors.txt#L1-L13).
- **Field 1 (count):** number of commits authored by that identity on that branch.
- **Field 2 (identity):** the git `author` name + email. The email is the canonical disambiguator (names can collide; emails here do not).

### 2.2 `*-oneline.txt` — one row per commit (the timeline backbone)

Each file is `git log --pretty='%h | %ad | %an | %s' --date=short` for one branch. Four pipe-delimited columns:

| Column | Meaning | Example (from [backend-oneline.txt:1](raw/backend-oneline.txt#L1)) |
|---|---|---|
| `%h` | abbreviated commit hash (7 chars) | `80f04b6` |
| `%ad` | author date, `--date=short` (YYYY-MM-DD) | `2026-07-03` |
| `%an` | author name | `samiul` |
| `%s` | commit subject line | `fixed graph` |

Rows are in reverse-chronological order (newest first), which is git's default `log` ordering.

### 2.3 `*-full-log.txt` — per-commit detail with file change-stats

Each commit is a standard `git log --stat --date=short` block: a `commit <full-40-char-hash>` header, an `Author:` line (name + **email**), a `Date:` line (`--date=short`, so **date-only** — e.g. `2026-07-03` at [firmware-full-log.txt:3](raw/firmware-full-log.txt#L3)), the indented subject, and the `--stat` file list (path + `+/-` churn), with merge commits also carrying a `Merge:` parent line. These files give:

- **The full 40-char commit hash** (the oneline `%h` is abbreviated to 7).
- **Author email** per commit (the oneline `%an` only has the name).
- **The file tree touched** — used in §9 to prove what each branch physically contains.

> The earlier (pre-2026-07-03) export used a custom `===== COMMIT =====` banner format with ISO `Date:` lines carrying **time + `+0530`** (India Standard Time) offsets; those detailed timestamps established that all three contributors committed from an IST locale (still reflected in the per-commit times in doc 01's table). The regenerated exports are date-only, so time-of-day is no longer carried in `raw/`.

---

## 3. Repository & Branch Topology

### 3.1 Two repositories under one GitHub owner

Both repos are owned by the GitHub account **`ayushmaitistartups-cmyk`**. The repo URLs are not guessed — they appear verbatim inside the sync merge-commit subject lines:

- `https://github.com/ayushmaitistartups-cmyk/Smart-Tutor-Lamp` — from the backend sync merge at [backend-oneline.txt:91](raw/backend-oneline.txt#L91) / [backend-full-log.txt:2163](raw/backend-full-log.txt#L2163) (and again in the newer backend merge at [backend-oneline.txt:22](raw/backend-oneline.txt#L22) / [backend-full-log.txt:459](raw/backend-full-log.txt#L459)).
- `https://github.com/ayushmaitistartups-cmyk/Smart-Tutor-frontend` — from the frontend merge at [frontend-oneline.txt:28](raw/frontend-oneline.txt#L28) / [frontend-full-log.txt:302](raw/frontend-full-log.txt#L302).

### 3.2 `Smart-Tutor-Lamp` holds **two** orphan branches (plus an `information` docs branch)

The `Smart-Tutor-Lamp` repository contains the device firmware **and** the Python backend, but they are **not** in the same working tree on one branch and **not** in two sub-directories of one branch. They are two **orphan branches** — independent root histories with **no common ancestor commit**:

- **`firmware`** — 21 commits, root commit `ab1313c` "Added Firmware" (2026-05-25), tip `c699e72` "FIRST ITERATION COMPLETE" (2026-07-03). See first/last rows [firmware-oneline.txt:1](raw/firmware-oneline.txt#L1) and [firmware-oneline.txt:21](raw/firmware-oneline.txt#L21).
- **`backend`** — 136 commits, root commit `bc4ba83` "Added temp files" (2026-05-26), tip `5ea5815` "Admin Analytics: add question Level + per-question escalation to Questions table" (2026-07-11). See [backend-oneline.txt:1](raw/backend-oneline.txt#L1) and [backend-oneline.txt:136](raw/backend-oneline.txt#L136).

Since 2026-07-03 the repo also carries a **third branch, `information`** (pushed to origin) — **not** an orphan: it forks from `firmware` at `e1de15a` (2026-07-02) and layers the `information/` + `improvment/` knowledge-base folders (the documentation set this chapter belongs to) on top of that firmware-code snapshot. Three commits so far, all by `ayushmaitistartups-cmyk`: `11fff3d` "Add information documentation" (2026-07-03), `79705ae` "Add improvement documentation" (2026-07-03), and `ed65231` "docs: brain-optimization plan + 2026-07-06 implementation record" (2026-07-06). Its docs-only commits are excluded from the 21 / 136 / 59 code-history counts. In the local working copy, `information` is currently checked out at the `Smart-Tutor-Lamp` repo root (so the `firmware` branch is not checked out anywhere right now) while `backend` is checked out as a linked worktree.

That the two branches share no ancestor is evidenced by their **disjoint root commits** (`ab1313c` vs `bc4ba83`, one day apart) and **completely disjoint file trees** (firmware = `tutor_lamp/*.cpp/.h/.ino`; backend = `app/*.py`); see §9.

### 3.3 `Smart-Tutor-frontend` holds a single `main` branch

- **`main`** — 59 commits, root commit `ea2805b` "first commit" (2026-05-28, by samiul) at [frontend-oneline.txt:59](raw/frontend-oneline.txt#L59), tip `2a09869` "Admin Analytics: remove Lamp column from the Questions table" (2026-07-11, by ayushmaitistartups-cmyk) at [frontend-oneline.txt:1](raw/frontend-oneline.txt#L1). This is an ordinary single-line `main` branch (plus one sync-merge — see §8).

> **Restoration note (2026-07-06).** The local clone of `Smart-Tutor-frontend` was briefly removed from disk earlier on 2026-07-06 and **restored the same day** by re-cloning the (unaffected) remote — tip at the time was unchanged at `ef07d7f` (2026-07-02), and the regenerated `raw/frontend-*.txt` exports confirmed that 43-commit snapshot exactly. **Since then (Update 2026-07-11)** the frontend has advanced 16 commits to tip `2a09869` (the admin Analytics-tab wave, 59 commits total), so the "tip unchanged" framing above applies only to the 2026-07-06 restoration itself — see §3.3's date range in §7.1 and the 2026-07-11 update banner at the top.

### 3.4 Topology diagram

```mermaid
flowchart TB
    subgraph OWNER["GitHub owner: ayushmaitistartups-cmyk"]
      direction TB

      subgraph REPO1["Repository: Smart-Tutor-Lamp"]
        direction TB
        FW["branch: firmware (ORPHAN)\nroot ab1313c (2026-05-25)\ntip c699e72 (2026-07-03)\n21 commits | C++/Arduino\ntutor_lamp/*.ino, *.cpp, *.h"]
        BE["branch: backend (ORPHAN)\nroot bc4ba83 (2026-05-26)\ntip 5ea5815 (2026-07-11)\n136 commits | Python FastAPI\napp/*.py"]
        INFO["branch: information (docs)\nforked from firmware @ e1de15a\n3 commits (2026-07-03 → 2026-07-06)\ninformation/ + improvment/ KB folders"]
        NOANC(["NO common ancestor\n(two independent roots)"])
        FW -.->|unrelated histories| NOANC
        BE -.->|unrelated histories| NOANC
        FW -->|fork point e1de15a| INFO
      end

      subgraph REPO2["Repository: Smart-Tutor-frontend"]
        direction TB
        MAIN["branch: main\nroot ea2805b (2026-05-28)\ntip 2a09869 (2026-07-11)\n59 commits | Next.js + simulator"]
      end
    end

    DEV["Physical device\nESP32-S3 lamp"]
    SUPA["Supabase / Postgres + pgvector"]

    FW -- "WebSocket audio/image" --> BE
    BE -- "REST + admin data" --> MAIN
    BE -- "SQL / vectors" --> SUPA
    MAIN -- "reads admin views" --> SUPA
    DEV -. "runs" .- FW
```

---

## 4. Why firmware + backend Are Unrelated Branches of One Repo

This is the single most surprising structural fact and the one most likely to trip up a new contributor, so it is documented mechanically.

### 4.1 The observable facts

1. **One repo, two branches:** both `firmware` and `backend` are branches of `Smart-Tutor-Lamp` (the backend merge message names that exact repo at [backend-full-log.txt:2133](raw/backend-full-log.txt#L2133)).
2. **Disjoint roots:** `firmware`'s earliest commit is `ab1313c` (2026-05-25, [firmware-oneline.txt:21](raw/firmware-oneline.txt#L21)); `backend`'s earliest is `bc4ba83` (2026-05-26, [backend-oneline.txt:136](raw/backend-oneline.txt#L136)). They are different root commits a day apart.
3. **Disjoint contents:** every file path in the `firmware` history lives under `tutor_lamp/` or sibling Arduino sketch folders (`camera_test/`, `wake_word_hey_lamp/`, `mic_recorder/`, etc. — see the big initial-import stat block at [firmware-full-log.txt:305-348](raw/firmware-full-log.txt#L305-L348)); every file path in the `backend` history lives under `app/`, `scripts/`, `tests/`, or repo-root `*.md` (see the scaffold stat block at [backend-full-log.txt:2654-2705](raw/backend-full-log.txt#L2654-L2705)). The two trees never share a single source file.
4. **One shared doc lineage, copied not merged:** both branches independently carry root-level design docs like `PROJECT_CONTEXT.md` and `BACKEND_DESIGN.md` (firmware imports them in `ab1313c` at [firmware-full-log.txt:329-334](raw/firmware-full-log.txt#L329-L334); backend keeps editing `PROJECT_CONTEXT.md` e.g. [backend-full-log.txt:2535](raw/backend-full-log.txt#L2535)). These were duplicated across the orphan roots rather than shared through a common ancestor.

### 4.2 The mechanism (how this is created in git)

An **orphan branch** is created with `git checkout --orphan <name>`. The resulting branch has its own root commit and **no parent linking it to any other branch**, so `git merge-base firmware backend` would return nothing and `git log firmware..backend` would list *all* of backend (no shared base to subtract). The two branches are effectively two repositories cohabiting one `.git`.

### 4.3 Why the team did it this way (rationale from the evidence)

The logs support a clear, pragmatic rationale:

- **Single device, two code-bases that ship together.** Firmware (the lamp) and backend (its brain) are halves of one product; keeping both under `Smart-Tutor-Lamp` keeps the *device* code in one place conceptually, while orphan branches keep their **build systems and toolchains from colliding** — Arduino/PlatformIO expects sketch folders at the root (`tutor_lamp/tutor_lamp.ino`), whereas FastAPI expects a Python package root (`app/main.py`). Putting them on separate orphan branches means a single `git checkout` yields a clean, tool-appropriate tree with no foreign files.
- **Independent release cadence.** They evolve on different clocks: firmware went quiet for a stretch after the 2026-06-10 ADPCM push, then **resumed** with intermittent commits (`7408aa5` 06-12, `aa2143c` 06-29 graphs/compression, `e1de15a` 07-02 OTA/chem/UX, `c699e72` 07-03 first-iteration nav/scroll-doc polish — its current tip), while backend and frontend committed steadily through 2026-07-06 / 2026-07-02. Orphan branches let each half stop and restart on its own schedule.
- **Cross-cutting design docs travel with each branch.** Because both halves need the same `PROJECT_CONTEXT.md` / `BACKEND_DESIGN.md` to make sense locally, those docs are duplicated into each orphan root rather than forcing a contributor to clone a second branch to read them.

The trade-off — and the practical hazard — is that `git checkout firmware` and `git checkout backend` show entirely different repositories; there is no `git diff firmware backend` that is meaningful, and tooling that assumes a single linear history must be told which branch to operate on.

---

## 5. Branching Model & Collaboration Workflow

### 5.1 "Trunk-per-component, direct push" model

The history shows a **direct-to-branch** workflow with essentially no feature-branch / pull-request discipline:

- **Almost no merge commits.** Across all 216 commits there are exactly **three** merge commits, and all three are *sync* merges (reconciling a local branch with its remote after a `git pull`), not feature-PR merges. They are detailed in §8. Every other commit is a plain, single-parent commit applied directly on top of the branch tip.
- **No long-lived feature branches are visible.** There are no `feature/*`, no squash-merge bubbles, no "Merge pull request #N" subjects anywhere in the three logs. Work was committed straight onto `firmware`, `backend`, and `main`.
- **Linear histories with occasional pull-then-push collisions.** The only places the linear chain breaks are the three sync merges, which appear precisely when two contributors pushed to the same branch on the same day (two on 2026-06-02, one on 2026-06-19; see §8).

### 5.2 Commit-message conventions (as actually used)

The subject lines reveal informal, free-text conventions rather than Conventional Commits. Observable patterns:

- **Free-form, often capitalized status notes:** `"Fixed"` ([firmware-oneline.txt:19](raw/firmware-oneline.txt#L19)), `"bug fix"`, `"Big fixed"` ([frontend-oneline.txt:18](raw/frontend-oneline.txt#L18)), and the typo-laden `"Bug fixes and Lates sequential"` ([firmware-oneline.txt:5](raw/firmware-oneline.txt#L5)).
- **SHOUTED milestones** for big features: `"ADDED ADPCM"` ([firmware-oneline.txt:5](raw/firmware-oneline.txt#L5)), `"CHUNK MODE ADDED"` ([backend-oneline.txt:36](raw/backend-oneline.txt#L36)), `"FOCUS + NUDGE + FOLLOW up"` ([backend-oneline.txt:48](raw/backend-oneline.txt#L48)), `"LAYER 1 TO LAYER 4"` ([backend-oneline.txt:112](raw/backend-oneline.txt#L112)), and later `"added GRAPHS end to end"` / `"added CHEM RDKIT + CHANGE THE UX + FRONTEND optimzations"` ([backend-oneline.txt:14](raw/backend-oneline.txt#L14), [backend-oneline.txt:5](raw/backend-oneline.txt#L5)).
- **Two rare Conventional-style prefixes:** only two commits across the whole project use a `chore:` prefix — the backend's `"chore: update gitignore and untrack sensitive files"` (`b46cefa`, `backend-oneline.txt` L98 after the +19 shift) and the frontend's newer `"chore: trigger Vercel deploy of Analytics tab under account owner"` (`e7b70ec`, 2026-07-10, [frontend-oneline.txt:15](raw/frontend-oneline.txt#L15)) — the exceptions that prove the convention was not enforced.
- **Deployment-marker commits on the frontend:** the frontend `main` is peppered with `"for deployment"` / `"for the deployment"` / `"Changed the md for deployment"` commits ([frontend-oneline.txt:6,10,12,19,22,25,27](raw/frontend-oneline.txt#L6)), each touching only `RUN.md`, used as lightweight deploy triggers/markers.

### 5.3 Author-role specialization (who owned which trunk)

The contribution split (quantified in §6) shows a clean ownership pattern:

- **samiul** = firmware owner (100% of firmware) **and** lead backend author (84/136).
- **ayushmaitistartups-cmyk** = frontend lead (40/59) and prompt/escalation/analytics author on the backend (36/136) — including the 2026-07-11 admin **Analytics-tab** wave, which he drove on *both* trunks.
- **shashi-3000** = backend DB/admin author (16/136) and frontend admin-UI author (12/59).
- **Hellinferno** = newest frontend contributor (1/59) — created the admin **Analytics tab** (`b91a229`, 2026-07-09) that ayushmaitistartups-cmyk then iterated 15 more commits.

This explains why the model worked without PRs: each trunk had a primary owner, so direct pushes rarely collided (the three collisions that did happen — two on 2026-06-02, one on 2026-06-19 — produced the only three merges).

### 5.4 Workflow sequence (how a typical change reached a branch)

```mermaid
sequenceDiagram
    autonumber
    participant Dev as Contributor (local clone)
    participant LB as Local branch (firmware/backend/main)
    participant GH as GitHub (Smart-Tutor-Lamp / -frontend)

    Dev->>LB: edit files, git add
    Dev->>LB: git commit -m "free-text subject"
    Note over Dev,LB: single-parent commit on tip<br/>(no feature branch, no PR)
    Dev->>GH: git push
    alt Remote unchanged (the common case)
        GH-->>Dev: fast-forward accepted
    else Another author pushed first (rare, 06-02 / 06-19)
        GH-->>Dev: push rejected (non-fast-forward)
        Dev->>LB: git pull  (creates sync MERGE commit)
        Note over LB: e.g. 5a82708 & 60f9237 (backend), d0c299b (frontend)
        Dev->>GH: git push (merge + own commits)
    end
```

---

## 6. Contributors — Identities & Per-Branch Commit Counts

### 6.1 Canonical identities

There are exactly **three** author identities across all branches (no duplicate-email/alias problems exist in this data):

| Display name (`%an`) | Email | Role inferred from work |
|---|---|---|
| `samiul` | `samiulseikh1221@gmail.com` | Firmware author; backend audio/LLM/orchestration lead |
| `ayushmaitistartups-cmyk` | `ayushmaiti.startups@gmail.com` | Repo owner; frontend/simulator lead; backend prompts & escalation |
| `shashi-3000` | `shashi.yadav.ug23@nsut.ac.in` | Backend DB/admin/turns; frontend admin & trace UI |

`ayushmaiti.startups@gmail.com` is the project owner's email (it also matches the GitHub owner account `ayushmaitistartups-cmyk`). The `shashi.yadav.ug23@nsut.ac.in` address indicates an NSUT (Netaji Subhas University of Technology) academic account.

### 6.2 Commit counts per branch (verbatim from `contributors.txt`)

```
FIRMWARE   : samiul 21                                                          (total 21)
BACKEND    : samiul 84 | ayushmaitistartups 36 | shashi-3000 16                 (total 136)
FRONTEND   : ayushmaitistartups 40 | shashi-3000 12 | samiul 6 | Hellinferno 1  (total 59)
```

Source lines: firmware [contributors.txt:2](raw/contributors.txt#L2); backend [contributors.txt:5-7](raw/contributors.txt#L5-L7); frontend [contributors.txt:10-13](raw/contributors.txt#L10-L13). These per-author counts independently sum to the 21 / 136 / 59 branch totals, cross-validating the commit counts in §1.

### 6.3 Cross-branch contribution matrix

| Author | firmware | backend | frontend | **Total across all branches** |
|---|---:|---:|---:|---:|
| **samiul** | 21 | 84 | 6 | **111** |
| **ayushmaitistartups-cmyk** | 0 | 36 | 40 | **76** |
| **shashi-3000** | 0 | 16 | 12 | **28** |
| **Hellinferno** | 0 | 0 | 1 | **1** |
| **Branch total** | **21** | **136** | **59** | **216** |

> Note: 216 is the sum of per-branch commits, not necessarily the count of *unique* humans-times-changes — but because the three branches are independent histories (two orphans + one separate repo), there is no commit double-counted across branches, so 216 is the true grand total of commits in the project (excluding the 3 docs-only commits on the `information` branch — see §3.2).

### 6.4 Distribution insight

- **samiul wrote ~51%** of all commits (111/216) and is the only contributor on firmware.
- **The backend is the busiest history** (136 of 216 commits ≈ 63%) and a **three-author** history; the frontend, after Hellinferno joined for the Analytics tab, is now the only **four-author** history.
- **shashi-3000 never touched firmware**; ayushmaitistartups-cmyk and Hellinferno also never touched firmware. Firmware is a single-author code-base.

---

## 7. Development Timeline (Date Ranges & Cadence per Branch)

All commit dates are in IST (`+0530`) — established by the original detailed export (the regenerated `Date:` lines are now date-only, e.g. [firmware-full-log.txt:3](raw/firmware-full-log.txt#L3)). The project ran **2026-05-25 → 2026-07-11** (about 47 days).

### 7.1 Per-branch date ranges

| Branch | First commit (date / hash / subject) | Last commit (date / hash / subject) | Span | Commits |
|---|---|---|---|---|
| **firmware** | 2026-05-25 · `ab1313c` · "Added Firmware" ([firmware-oneline.txt:21](raw/firmware-oneline.txt#L21)) | 2026-07-03 · `c699e72` · "FIRST ITERATION COMPLETE" ([firmware-oneline.txt:1](raw/firmware-oneline.txt#L1)) | 39 days | 21 |
| **backend** | 2026-05-26 · `bc4ba83` · "Added temp files" ([backend-oneline.txt:136](raw/backend-oneline.txt#L136)) | 2026-07-11 · `5ea5815` · "Admin Analytics: add question Level + per-question escalation to Questions table" ([backend-oneline.txt:1](raw/backend-oneline.txt#L1)) | 46 days | 136 |
| **frontend** | 2026-05-28 · `ea2805b` · "first commit" ([frontend-oneline.txt:59](raw/frontend-oneline.txt#L59)) | 2026-07-11 · `2a09869` · "Admin Analytics: remove Lamp column from the Questions table" ([frontend-oneline.txt:1](raw/frontend-oneline.txt#L1)) | 44 days | 59 |

**Key timeline observations:**

- **Firmware led the project** (first commit 2026-05-25) and reached feature-complete first (the 2026-06-10 ADPCM push), then **paused and resumed** with sparse commits (06-12, 06-29, 07-02, 07-03) tracking backend feature waves (graphs/compression, OTA, chemistry/UX, and a first-iteration navigation/scroll-document UX pass) rather than freezing outright.
- **Backend and frontend now both run to 2026-07-11** while **firmware alone ends earlier** (07-03). The iteration-1 close (through 07-04) is dominated by graphs/chemistry rendering, OTA, analytics, the output-validator/guardrail work, and a firmware UX pass (the scroll-document reading experience) paired with backend memory-leak/OOM hardening (a process-wide render-concurrency gate, hard per-turn buffer ceilings, and closed HTTP/matplotlib handles); two days later the backend adds the brain-optimization pass (`db470f6`, 07-06 — verifier ON, MCQ option-match, eval harness, CI), and finally a **cross-repo admin Analytics-tab wave (07-07 → 07-11, 19 backend + 16 frontend commits)** — range-aware latency/escalation analytics with `turn_traces`-sourced per-question rows, plus a config-to-prod alignment and the removal of the 07-06 backend CI workflow — carries both trunks to their current 2026-07-11 tips (`5ea5815` / `2a09869`).
- **All three started within 3 days of each other** (05-25, 05-26, 05-28), implying a coordinated kickoff.

### 7.2 Commit cadence (commits per day)

Daily commit counts derived from the `%ad` column of each oneline file:

**firmware** (21 commits over 14 active days):
```
2026-05-25  ███ 3      2026-06-04  █ 1        2026-06-10  ██ 2
2026-05-26  █ 1        2026-06-05  █ 1        2026-06-12  █ 1
2026-05-27  █ 1        2026-06-07  ████ 4     2026-06-29  █ 1
2026-05-28  █ 1        2026-06-08  █ 1        2026-07-02  █ 1
2026-05-29  ██ 2                              2026-07-03  █ 1
```
Bursts: the 05-25 bring-up (3 commits) and the 06-07 push-to-talk/UI day (4 commits, e.g. [firmware-oneline.txt:8-11](raw/firmware-oneline.txt#L8-L11)). After the 06-10 ADPCM push firmware went sparse — four trailing single-commit days (06-12, 06-29, 07-02, 07-03) that piggyback on backend feature waves (compression/graphs, then OTA/chemistry/UX, then a first-iteration navigation/scroll-document UX pass).

**backend** (117 commits over 34 active days — the most sustained history):
```
2026-05-26  ██████ 6   2026-06-07  ████ 4     2026-06-18  █████ 5
2026-05-27  ██ 2       2026-06-08  ███████ 7  2026-06-19  ██████ 6
2026-05-28  ██ 2       2026-06-09  █ 1        2026-06-22  █ 1
2026-05-29  █████ 5    2026-06-10  ███████ 7  2026-06-24  █ 1
2026-05-30  ███ 3      2026-06-11  ██ 2       2026-06-25  ██ 2
2026-05-31  █████ 5    2026-06-12  ████████ 8 2026-06-26  █ 1
2026-06-02  █████ 5    2026-06-13  ████ 4     2026-06-28  ████ 4
2026-06-03  ██ 2       2026-06-14  ██ 2       2026-07-01  ███ 3
2026-06-04  ██ 2       2026-06-15  ████ 4     2026-07-02  ███ 3
2026-06-05  ██ 2       2026-06-16  ████████ 8 2026-07-03  ████ 4
2026-06-06  ███ 3      2026-06-17  █ 1        2026-07-04  █ 1
```
*(Chart drawn at the 2026-07-05 snapshot. Since then the branch added **20** more commits across 6 active days — `2026-07-06 █ 1` (`db470f6`), `07-07 ██ 2` (samiul docs), `07-08 ██ 2`, `07-09 █ 1`, `07-10 █████ 5`, `07-11 █████████ 9` — for the current **136-commit / 40-active-day** totals; the 07-07 → 07-11 span is the admin Analytics-tab wave.)*

Heaviest days: **2026-06-12 and 2026-06-16 (8 commits each)** — the "Turns / Bound Box / Screen display + Nudge/Focus/Escalation" wave (backend-oneline rows in that window) and the 06-16 STT/streaming + TFT-verbose day; **2026-07-11 (9 commits)** later matches them, in the admin Analytics-tab wave. Post-06-16 the backend stays busy through 07-11: nudge/verdict guardrails (06-18), Cartesia TTS + the sync merge (06-19), graphs end-to-end (06-26), analytics/aggregation (06-28), the OTA + output-validator + chemistry/RDKit finish (07-01 → 07-03), a same-day-plus-one memory-leak/render-concurrency hardening pass (07-03 → 07-04), the brain-optimization pass (07-06), and finally the range-aware admin **Analytics tab** + config-to-prod alignment + CI-workflow removal (07-07 → 07-11).

**frontend** (43 commits over 17 active days):
```
2026-05-28  █ 1        2026-06-04  █ 1        2026-06-13  ██ 2
2026-05-29  ███ 3      2026-06-06  ██ 2       2026-06-16  ██ 2
2026-05-30  ██████ 6   2026-06-07  ██ 2       2026-06-28  ███ 3
2026-05-31  ██ 2       2026-06-10  █ 1        2026-07-01  █ 1
2026-06-02  ███████ 7  2026-06-11  ██ 2       2026-07-02  █ 1
2026-06-03  █ 1        2026-06-12  ██████ 6
```
Two peaks: **2026-06-02 (7 commits, includes the sync merge)** and **2026-06-12 (6 commits, the admin/trace-view wave)**. A late cluster on **2026-06-28 (3 commits)** lands analytics/aggregation and personalization/survey views, followed by the OTA (07-01) and optimization/skeleton (07-02) commits.

*(Chart drawn at the 2026-07-02 snapshot. Since then the frontend added **16** more commits across 3 active days — `2026-07-09 █ 1` (`b91a229`, Hellinferno's admin Analytics tab), `07-10 ██████ 6`, `07-11 █████████ 9` — for the current **59-commit / 20-active-day** totals; the 07-09 → 07-11 span is the admin Analytics-tab wave that also drives the backend's 07-07 → 07-11 commits.)*

### 7.3 Thematic phases (read from subject lines across branches)

| Phase | Dates | Evidence (representative commits) |
|---|---|---|
| **Hardware bring-up** | 05-25 → 05-29 | firmware `ab1313c` "Added Firmware", `39bc06c` "Added Full firmware pipeline", `7d9b370` "added fully working version with dummy backend" |
| **Backend layers 1–6 + DB** | 05-26 → 05-29 | backend "Layer 1,2,3,4 DONE!" ([backend-oneline.txt:113](raw/backend-oneline.txt#L113)), "Added TTS guide and Layer 5 and 6 DONE!" ([backend-oneline.txt:110](raw/backend-oneline.txt#L110)) |
| **Auth / Clerk / Redis / sessions** | 05-28 → 05-30 | backend "Added Redis and Auth with esp to backend to frontend" ([backend-oneline.txt:107](raw/backend-oneline.txt#L107)), "Added clerk" ([backend-oneline.txt:102](raw/backend-oneline.txt#L102)) |
| **Escalation / multi-LLM / tiers** | 05-31 → 06-08 | backend "Add tier-3 (Gemini Pro) escalation" ([backend-oneline.txt:98](raw/backend-oneline.txt#L98)), "Added multi llm features" ([backend-oneline.txt:85](raw/backend-oneline.txt#L85)) |
| **Image pipeline / ADPCM audio** | 06-08 → 06-10 | firmware "ADDED ADPCM" ([firmware-oneline.txt:6](raw/firmware-oneline.txt#L6)); backend "Added Opus and ADPCM coded" ([backend-oneline.txt:64](raw/backend-oneline.txt#L64)) |
| **Turns / admin / trace UI** | 06-12 | backend + frontend "Turns Updated", "Added Bound Box", "Tunrs Updated", "added error log screen" |
| **Prompt / focus / nudge / follow-up** | 06-12 → 06-15 | backend "Nudge + FOCUS + Escalation", "FOCUS + NUDGE + FOLLOW up", "added claude prompt guide" |
| **Claude STT + streaming** | 06-16 → 06-17 | backend "Added Claude STT" ([backend-oneline.txt:40](raw/backend-oneline.txt#L40)) + "added STREAM", "TTS leads + focus mode"; frontend "Added claude stt related updates" ([frontend-oneline.txt:7](raw/frontend-oneline.txt#L7)) |
| **Tutor nudge/verdict guardrails** | 06-18 → 06-24 | backend "Fix tutor nudge/verdict issues: open-start, recheck loop, MCQ option" ([backend-oneline.txt:27](raw/backend-oneline.txt#L27)), "Objective questions: direct verdict" ([backend-oneline.txt:24](raw/backend-oneline.txt#L24)), "Add check-verdict guard + lower frustration nudge threshold to 2" ([backend-oneline.txt:20](raw/backend-oneline.txt#L20)) |
| **Cartesia TTS** | 06-19 → 06-25 | backend "added cartersia" ([backend-oneline.txt:23](raw/backend-oneline.txt#L23)), "TTS Cartesia Stream Optimized and chemistry latext bug fixes" ([backend-oneline.txt:19](raw/backend-oneline.txt#L19)), "added TTS fix" ([backend-oneline.txt:18](raw/backend-oneline.txt#L18)) |
| **Graphs end-to-end + compression** | 06-26 → 06-29 | backend "added GRAPHS end to end" ([backend-oneline.txt:16](raw/backend-oneline.txt#L16)); firmware "added Graphs and other optimization of compression" ([firmware-oneline.txt:3](raw/firmware-oneline.txt#L3)) |
| **Analytics / aggregated decomposition** | 06-28 | backend "analysis related updates" ([backend-oneline.txt:15](raw/backend-oneline.txt#L15)), "added the aggregated decomposition" ([backend-oneline.txt:12](raw/backend-oneline.txt#L12)); frontend "added analytics" ([frontend-oneline.txt:4](raw/frontend-oneline.txt#L4)), "few analysis related updates" ([frontend-oneline.txt:5](raw/frontend-oneline.txt#L5)) |
| **Chemistry / RDKit + OTA + output-validator (final push)** | 07-01 → 07-03 | backend "added OTA" ([backend-oneline.txt:11](raw/backend-oneline.txt#L11)), "Add code-enforced output validator, guardrails, and math verifier" ([backend-oneline.txt:10](raw/backend-oneline.txt#L10)), "added CHEM RDKIT + CHANGE THE UX + FRONTEND optimzations" ([backend-oneline.txt:7](raw/backend-oneline.txt#L7)); firmware "added ota and chem and its before ux change" ([firmware-oneline.txt:2](raw/firmware-oneline.txt#L2)); frontend "added OTA" ([frontend-oneline.txt:2](raw/frontend-oneline.txt#L2)) |
| **First-iteration UX polish + memory/OOM hardening (post-launch)** | 07-03 → 07-04 | firmware "FIRST ITERATION COMPLETE" (`c699e72`, [firmware-oneline.txt:1](raw/firmware-oneline.txt#L1)) — the scroll-document `TFT_SCROLL_DOC` page, a filled-in `BTN_RIGHT_LONG` mapping, `NAVIGATION.md`/`TFT_UX_FINDINGS.md` design docs; backend "ux ui fixed of tft graph" (`0896f7c`) and "added memory leak protection and cpu crash Iteration 1 done" (`a5533e5`, [backend-oneline.txt:2-3](raw/backend-oneline.txt#L2-L3)) — a process-wide `GRAPH_RENDER_CONCURRENCY` render gate, closed matplotlib figures/httpx clients, and hard per-turn audio/image buffer ceilings |
| **Brain-optimization pass (backend only)** | 07-06 | backend "Brain optimization pass: verifier ON, MCQ option-match, eval harness, CI" (`db470f6`, [backend-oneline.txt:20](raw/backend-oneline.txt#L20)) — lands the `improvment/08` plan: `MATH_VERIFY_ENABLED` default True, `GEMINI_TEMPERATURE` 0.4, an MCQ option-match verifier, `PROMPT_VERSION` stamping, the `evals/` harness, and the `.github/workflows/backend-ci.yml` CI workflow (**removed two days later** by `e53ce33`, 07-08 — see the next phase) |
| **Admin Analytics tab + config-to-prod alignment** | 07-07 → 07-11 | frontend admin **Analytics tab** created by Hellinferno "Add admin Analytics tab (generation + total latency)" (`b91a229`, [frontend-oneline.txt:16](raw/frontend-oneline.txt#L16)), then iterated 15 commits by ayushmaitistartups-cmyk to tip `2a09869` ([frontend-oneline.txt:1](raw/frontend-oneline.txt#L1)); backend "Add range-aware admin analytics endpoints + model-selection latency" (`324bc6d`, 07-09) → tip `5ea5815` ([backend-oneline.txt:1](raw/backend-oneline.txt#L1)) — range-aware latency/escalation analytics from `turn_traces`, plus config-defaults-to-production (`939e0bd`, 07-08), **backend CI-workflow removal** (`e53ce33`, 07-08), a Gemini "Tutor unavailable" fix (`591ca0b`), and samiul `docs/` (`7b1fb94`, `5077d5d`, 07-07) |

---

## 8. The Three Sync-Merge Commits (the only merges)

Out of 216 commits, exactly three are merge commits, and **all three are `git pull` reconciliations** (same-branch, after a concurrent push), not feature-PR merges. Two occurred on 2026-06-02 (both authored by `shashi-3000`) and one on 2026-06-19 (authored by `samiul`) — every commit added since (the 07-05 refresh's 3, the 2026-07-06 tip `db470f6`, and the 35-commit 07-07 → 07-11 admin Analytics-tab wave) is a plain single-parent commit, so the merge count is unchanged. (Anchors into `backend-oneline.txt` in this section predate the regenerations and now point up to **19** lines high; `frontend-oneline.txt` anchors up to 16 — see the Update note at the top.)

### 8.1 Backend sync merge #1 — `5a82708`

```
5a82708 | 2026-06-02 | shashi-3000 |
    Merge branch 'backend' of https://github.com/ayushmaitistartups-cmyk/Smart-Tutor-Lamp into backend
```
Source: [backend-oneline.txt:91](raw/backend-oneline.txt#L91) and the full-log banner at [backend-full-log.txt:2163](raw/backend-full-log.txt#L2163). The subject is git's auto-generated message for `git pull` of `backend` into `backend` — a same-branch reconciliation after a concurrent push. It surrounds shashi-3000's `45440c6` "Admin,DB and consistency related updates" ([backend-oneline.txt:92](raw/backend-oneline.txt#L92)) and `017ca24` "fixed bugs" ([backend-oneline.txt:90](raw/backend-oneline.txt#L90)) on the same date.

### 8.2 Frontend sync merge — `d0c299b`

```
d0c299b | 2026-06-02 | shashi-3000 |
    Merge branch 'main' of https://github.com/ayushmaitistartups-cmyk/Smart-Tutor-frontend
```
Source: [frontend-oneline.txt:28](raw/frontend-oneline.txt#L28) and [frontend-full-log.txt:302](raw/frontend-full-log.txt#L302). Same pattern: `main` pulled into `main` after a concurrent push. It sits between `12b8fdf` "fixed bugs" ([frontend-oneline.txt:29](raw/frontend-oneline.txt#L29)) and `28a2d88` "Changed the md for deployment" ([frontend-oneline.txt:27](raw/frontend-oneline.txt#L27)).

### 8.3 Backend sync merge #2 — `60f9237`

```
60f9237 | 2026-06-19 | samiul |
    Merge branch 'backend' of https://github.com/ayushmaitistartups-cmyk/Smart-Tutor-Lamp into backend
```
Source: [backend-oneline.txt:22](raw/backend-oneline.txt#L22) and the full-log banner (with `Merge: 667052a dc9a936` parent line) at [backend-full-log.txt:459](raw/backend-full-log.txt#L459). This was the third merge, added in the 2026-07-03 snapshot: a `git pull` of `backend` into `backend` on 2026-06-19 — this time run by **samiul** (not shashi-3000) — reconciling samiul's `667052a` "added cartersia" ([backend-oneline.txt:23](raw/backend-oneline.txt#L23)) with ayushmaitistartups-cmyk's `dc9a936` "Objective questions: direct verdict instead of a Socratic nudge" ([backend-oneline.txt:24](raw/backend-oneline.txt#L24)) — the two parents named on its `Merge:` line. It is immediately followed by `ac0e726` "fixed the requirements" ([backend-oneline.txt:21](raw/backend-oneline.txt#L21)).

### 8.4 Implication

These three merges are the **only** non-linear points in the entire project. They confirm the §5 finding: the team used a direct-push, no-PR model, and the only history bifurcations were accidental same-day push collisions resolved by `git pull`, not deliberate feature integrations. Note the merges are **not** all by one author: the two 2026-06-02 merges are shashi-3000's, while the 2026-06-19 merge is samiul's — i.e. whoever happened to `git pull` after losing a push race that day.

---

## 9. What Each Branch Contains (file-tree evidence from first commits)

The orphan split (§4) is proven by the disjoint file trees imported in each branch's foundational commits.

### 9.1 firmware branch — Arduino/C++ tree

The initial firmware import `ab1313c` (2026-05-25) adds a pure Arduino sketch tree plus design docs ([firmware-full-log.txt:305-348](raw/firmware-full-log.txt#L305-L348)). Representative paths:

- **Main sketch & DSP:** `tutor_lamp/tutor_lamp.ino`, `tutor_lamp/agc_stage.cpp/.h`, `ale_stage.cpp/.h`, `ns_stage.cpp/.h`, `vad_stage.cpp/.h`, `audio_post_process.cpp/.h` ([firmware-full-log.txt:322-345](raw/firmware-full-log.txt#L322-L345)).
- **I/O:** `mic_i2s.cpp/.h`, `spk_i2s.*` (added later in `39bc06c`), `camera.*`, `net_ws.cpp/.h`, `provisioning.cpp/.h`, `tft_display.*`, `tft_qr.*`.
- **Sibling test sketches:** `camera_test/`, `wake_word/wake_word_hey_lamp/`, `ei_data_collector/`, `mic_recorder/`, `push_buttons/`, `tft_latex_client/`, `wifi_audio_player/`.
- **Docs:** `BACKEND_DESIGN.md`, `CLAUDE.md`, `IMPLEMENTATION_AUTH_PAIRING.md`, `IMPLEMENTATION_WEBSOCKET.md`, `PROJECT_CONTEXT.md`, `ESP32S3_Pinout.png`.

Later additions visible in the log: ADPCM decoder `tutor_lamp/adpcm_dec.cpp/.h` ([firmware-full-log.txt:92-93](raw/firmware-full-log.txt#L92-L93)), settings store `settings_store.*`, on-device text entry `text_entry.*`, TFT settings `tft_settings.*`, and the resumed-work modules `tutor_lamp/ota.cpp/.h` + `display_config.h` (added in `e1de15a`, 07-02, [firmware-full-log.txt:31-33](raw/firmware-full-log.txt#L31-L33)). The now-current tip `c699e72` (07-03) adds two more docs, `tutor_lamp/NAVIGATION.md` and `tutor_lamp/TFT_UX_FINDINGS.md` ([firmware-full-log.txt:1-24](raw/firmware-full-log.txt#L1-L24)), alongside the scroll-document TFT feature (see `01-firmware/02-display-and-ui.md` §4.9).

### 9.2 backend branch — Python/FastAPI tree

The backend history touches a disjoint Python package. Representative paths (from many commits): `app/main.py` ([backend-full-log.txt:2662](raw/backend-full-log.txt#L2662)), `app/config.py`, `app/routes/frontend_manager.py`, `app/routes/admin.py`, `app/routes/ota.py` / `pilot.py` / `insights.py` (added in the late analytics/OTA work), `app/services/orchestrator.py`, `app/services/escalation_router.py`, `app/services/dispatch.py`, `app/services/problem_memo.py`, `app/services/session_memory.py`, `app/services/turn_trace.py`, `app/services/output_validator.py` / `math_verifier.py` / `input_guard.py` / `render_check.py` (the 07-01 guardrail layer), `app/providers/llm_claude.py` / `llm_gemini.py` / `gemini_brain.py` / `tts_gemini.py` / `tts_cartesia.py` / `graph_renderer.py` / `rdkit_renderer.py` / `document.py`, `app/prompts/turn1_system.py`, `app/schemas/*.py`, `app/db/models.py` / `session.py`, `app/storage/blobs.py` / `turns.py` / `pilot.py`, `tests/test_*.py`, `scripts/*dryrun*.py`, plus generated `turn_captures/**` blobs and root docs (`PROJECT_CONTEXT.md`, `CLAUDE_BRANCH_GUIDE.md`, `CLAUDE_FALLBACK_GUIDE.md`, `system_prompt_arch.md`, `SUPABASE_QUERIES.md`, and later `COST_ANALYSIS.md` / `ENV.md` / `todo.md` / `audit_bugs.md`). The 2026-07-06 commit `db470f6` added the `evals/` harness (graders, runner, golden set) and the branch's first CI workflow, `.github/workflows/backend-ci.yml` — but that workflow was **added-then-removed**: `e53ce33` "Remove backend CI workflow" (2026-07-08) deletes it, so it does **not** exist at the current tip. The 07-07 → 07-11 admin Analytics-tab wave instead adds backend dev docs under `docs/` (samiul `7b1fb94` / `5077d5d`), range-aware analytics endpoints/services (`324bc6d` and later) that source per-question latency/escalation rows from `turn_traces`, and a config-defaults-to-production alignment (`939e0bd`).

**No path overlap** with the firmware tree — confirming the two are genuinely separate code-bases on separate orphan branches.

### 9.3 frontend branch — Next.js tree

The frontend `main` history touches `app/simulator/page.tsx`, `components/app/AdminView.tsx` (see the +593 admin bang at [frontend-full-log.txt:339](raw/frontend-full-log.txt#L339)), `components/app/TraceView.tsx` (the +402 trace inspector at [frontend-full-log.txt:150](raw/frontend-full-log.txt#L150)), `components/app/AppHeader` (made client-side in `fe978cc`), `lib/admin.ts`, `lib/models.ts`, and `RUN.md` (the deployment-marker file). Later commits add `components/app/PersonalizationView.tsx` / `SurveyView.tsx` / `PageSkeleton.tsx`, `lib/pilot.ts`, `app/*/loading.tsx` skeletons, and `OPTIMIZATION.md` (analytics/OTA/optimization work at [frontend-full-log.txt:29-74](raw/frontend-full-log.txt#L29-L74)).

---

## 10. Integration Points & Cross-References to the Rest of the System

The git topology mirrors the runtime architecture. Each history maps to a documented subsystem:

| Branch / repo | Runtime subsystem | Documented in |
|---|---|---|
| `Smart-Tutor-Lamp` @ `firmware` | ESP32-S3 device: audio DSP, TFT UI, camera, networking | `01-firmware/00-overview-and-architecture.md`, `01-firmware/01-audio-dsp-pipeline.md`, `01-firmware/02-display-and-ui.md`, `01-firmware/03-networking-camera-buttons.md`, `01-firmware/04-test-sketches-and-subprojects.md` |
| `Smart-Tutor-Lamp` @ `backend` | FastAPI brain: WebSocket protocol, orchestrator, multi-LLM, escalation, TTS, memory, admin | `02-backend/*` (00–10), incl. `02-backend/02-websocket-protocol.md`, `02-backend/03-orchestrator-and-turn-pipeline.md`, `02-backend/04-escalation-and-model-selection.md`, `02-backend/05-llm-providers.md` |
| `Smart-Tutor-frontend` @ `main` | Next.js dashboard + web device simulator | `03-frontend/*`, `04-web-simulator/*` |

**Runtime call-edges that the branch split hides but the history confirms:**

- **firmware → backend (WebSocket).** Firmware commits add `net_ws.cpp` and the ADPCM codec ([firmware-oneline.txt:6](raw/firmware-oneline.txt#L6)) on the same dates the backend adds the matching decode/stream path ("Added Opus and ADPCM coded" [backend-oneline.txt:64](raw/backend-oneline.txt#L64), "added STREAM" [backend-oneline.txt:36](raw/backend-oneline.txt#L36)). The two orphan branches co-evolve through this wire protocol even though they share no git ancestor — the co-evolution continues in the later "firmware upgrades with backward compaitibility" ([backend-oneline.txt:17](raw/backend-oneline.txt#L17)) and shared OTA work (firmware `e1de15a` + backend `910303d`), and again in the newest tip pair — firmware's `c699e72` adds a `graph_id`-prefixed `FRAME_GRAPH_VIEW` (17 B, was 16) and two scroll-document frame types (`0x2B`/`0x2C`), matched on the backend by `a5533e5`'s per-`graph_id` spec lookup in `session.py`'s GRAPH_VIEW handler. Protocol details: `02-backend/02-websocket-protocol.md`.
- **backend → frontend (admin/trace REST).** The 2026-06-12 wave lands `app/routes/admin.py` + `app/services/turn_trace.py` on backend ([backend-oneline.txt:52-54](raw/backend-oneline.txt#L52-L54)) in lockstep with `AdminView.tsx`/`TraceView.tsx` on frontend ([frontend-oneline.txt:11,13](raw/frontend-oneline.txt#L11) and [frontend-full-log.txt:129-150](raw/frontend-full-log.txt#L129-L150)); the pattern repeats in the 06-28 analytics/aggregation wave (backend `4a4af29`/`3813d1e` + frontend `1bd9723`/`841b71c`). See `02-backend/10-formatting-schemas-and-admin.md` and `03-frontend/01-pages-and-routes.md`.
- **backend/frontend → Supabase/Postgres+pgvector.** "Updated supabase" / "supabase updates" commits ([backend-oneline.txt:91](raw/backend-oneline.txt#L91), [backend-oneline.txt:55](raw/backend-oneline.txt#L55)) and the `SUPABASE_QUERIES.md` doc tie the DB schema to both repos. See `02-backend/08-memory-workers-and-analytics.md`.
- **Cross-branch prompt & analytics work.** ayushmaitistartups-cmyk's 36 backend commits are almost entirely prompt/escalation/validation tuning and admin-analytics work — "Restructure web simulator prompt around query_type", "Add tier-3 (Gemini Pro) escalation", the later nudge/verdict guardrails + "Add code-enforced output validator, guardrails, and math verifier", the 2026-07-06 brain-optimization pass `db470f6` ([backend-oneline.txt:20](raw/backend-oneline.txt#L20)), and the 07-07 → 07-11 range-aware admin **Analytics tab** ending on `5ea5815` ([backend-oneline.txt:1](raw/backend-oneline.txt#L1)) — connecting the frontend simulator's prompt and the admin dashboard to the backend brain. (Historical anchors into `backend-oneline.txt` in this bullet now point up to 19 lines high — see §11.1.) See `02-backend/07-prompts-and-llm-instructions.md`.

---

## 11. Edge Cases, Data Caveats & How To Reproduce

### 11.1 Caveats baked into the data

- **Off-by-one line counts (historical).** Earlier oneline exports lacked a trailing newline, so `wc -l` undercounted each by 1; the current exports end with a newline and `wc -l` now matches the true counts (21 / 136 / 59), which `uniq -c` author sums and `contributors.txt` confirm.
- **Shifted `*-oneline.txt` anchors.** The 2026-07-11 regeneration added **19** lines at the top of `backend-oneline.txt` (the 07-07 → 07-11 wave) and **16** at the top of `frontend-oneline.txt` (07-09 → 07-11), on top of the earlier 2026-07-06 backend +1. Line anchors into those files from untouched historical passages therefore point up to 19 (backend) / 16 (frontend) lines high; anchors adjacent to updated claims have been re-pointed. The two current tips still resolve at `#L1` (backend `5ea5815`, frontend `2a09869`).
- **Frontend clone briefly removed and restored (2026-07-06).** The local `Smart-Tutor-frontend` clone was removed from disk earlier on 2026-07-06 and restored the same day by re-cloning the remote (tip unchanged at `ef07d7f`, 2026-07-02). `frontend-*.txt` and `contributors.txt` were regenerated live from the restored clone; the regenerated data matched the prior snapshot exactly, so no frontend fact in this area changed.
- **`author date` vs `commit date`.** The `--date=short` / `%ad` in the oneline files is the **author** date. Rebasing/cherry-picking can desync author and committer dates, but with this near-linear history (only 3 merges) the author dates are a faithful timeline.
- **Date-only timestamps in the regenerated logs.** The current `*-full-log.txt` exports use `--date=short`, so they carry **no time-of-day or timezone**. The earlier detailed export established every commit was made in IST (`+0530`); those per-commit times survive only in doc 01's firmware table, not in the current `raw/` files. Cross-day ordering remains unambiguous.
- **Generated artifacts in history.** The backend history commits large binary blobs under `turn_captures/**` (e.g. `audio.wav` 32044 bytes, `FINAL_0.jpg` 1531 bytes) and `.pyc` caches, then deletes them (e.g. `e17e0dc` "added temp fix" deletes 144 files [backend-full-log.txt:748-898](raw/backend-full-log.txt#L748-L898)). These inflate per-commit file counts but are debug captures, not source — discount them when reading change-stats. The backend `chore:` commit `b46cefa` ([backend-oneline.txt:98](raw/backend-oneline.txt#L98), after the +19 shift) was the cleanup that started untracking such files. The 07-01 commit `1ed9d99` also does a large tree reorganization (moving dead code to `legacy/`, deleting the `temp_server_files/` prototypes — ~2,117 deletions) which likewise skews its raw change-stat.
- **"Merge by whoever pulled".** The two 2026-06-02 merges are authored by shashi-3000 and the 2026-06-19 merge by samiul; this does **not** mean either wrote the merged work — it means that author ran the `git pull` that produced the merge after someone else (across the three merges: ayushmaitistartups-cmyk, samiul, or shashi-3000) had pushed first that day.

### 11.2 How to reproduce these exports

For each branch (`firmware`, `backend` in `Smart-Tutor-Lamp`; `main` in `Smart-Tutor-frontend`):

```bash
# one-line timeline (what *-oneline.txt is)
git log <branch> --pretty='%h | %ad | %an | %s' --date=short > <name>-oneline.txt

# per-commit detail with change-stats (what *-full-log.txt is; regenerated 2026-07-03)
git log <branch> --stat --date=short > <name>-full-log.txt

# aggregate contributors (what each contributors.txt section is; the
# "=== FIRMWARE (… @branch) ===" banners are added by hand around each run)
git shortlog -sne <branch>
```

To **confirm the orphan relationship** between firmware and backend (no shared ancestor):

```bash
git merge-base firmware backend   # prints nothing / errors -> no common ancestor
git rev-list --max-parents=0 firmware   # -> ab1313c  (firmware root)
git rev-list --max-parents=0 backend    # -> bc4ba83  (backend root, different root)
```

---

## Appendix A — Full Firmware Commit Table

All 21 commits, newest → oldest, from [firmware-oneline.txt](raw/firmware-oneline.txt). Author = `samiul` for every row.

| # | Date | Hash | Subject |
|---:|---|---|---|
| 21 | 2026-07-03 | `c699e72` | FIRST ITERATION COMPLETE *(tip)* |
| 20 | 2026-07-02 | `e1de15a` | added ota and chem and its before ux change |
| 19 | 2026-06-29 | `aa2143c` | added Graphs and other optimization of compression |
| 18 | 2026-06-12 | `7408aa5` | fixed bugs |
| 17 | 2026-06-10 | `8c13325` | Bug fixes and Lates sequential |
| 16 | 2026-06-10 | `7db8fcc` | ADDED ADPCM |
| 15 | 2026-06-08 | `f8c53a6` | Fixed bugs and UI enhancement |
| 14 | 2026-06-07 | `7092bab` | Added push to talk and bug fixes |
| 13 | 2026-06-07 | `8bf384b` | tft ui enhanced |
| 12 | 2026-06-07 | `af16f95` | fixed VAD and ui |
| 11 | 2026-06-07 | `713c6b0` | fix tts and i2s speaker and mic |
| 10 | 2026-06-05 | `e1573d5` | fixed auth and flow with the backend |
| 9 | 2026-06-04 | `080d6be` | added setting page and wifi and tft bug fixes |
| 8 | 2026-05-29 | `598839a` | added context |
| 7 | 2026-05-29 | `79ef4b3` | bug fixes |
| 6 | 2026-05-28 | `b822044` | cleaned the auth |
| 5 | 2026-05-27 | `0960476` | Fixes |
| 4 | 2026-05-26 | `7d9b370` | added fully working version with dummy backend |
| 3 | 2026-05-25 | `ee76d03` | Fixed |
| 2 | 2026-05-25 | `39bc06c` | Added Full firmware pipeline |
| 1 | 2026-05-25 | `ab1313c` | Added Firmware *(root)* |

---

## Appendix B — Full Backend Commit Table

All 136 commits, newest → oldest, from [backend-oneline.txt](raw/backend-oneline.txt). Authors: **S**=samiul, **A**=ayushmaitistartups-cmyk, **K**=shashi-3000. Rows 95 (`60f9237`) and 26 (`5a82708`) are the two backend **sync merges**. (Rows are numbered from oldest = #1, so the 19 rows added in the 2026-07-11 pass are #118–#136 and no existing row's number changed.)

| # | Date | Hash | Auth | Subject |
|---:|---|---|:--:|---|
| 136 | 2026-07-11 | `5ea5815` | A | Admin Analytics: add question Level + per-question escalation to Questions table *(tip)* |
| 135 | 2026-07-11 | `7387ed7` | A | Admin dashboard: escalation breakdown + fix Tier/model & Reason accuracy |
| 134 | 2026-07-11 | `9b245cc` | A | Analytics: bucket today/yesterday + trend by IST, not UTC |
| 133 | 2026-07-11 | `6adc1d1` | A | Analytics: lamp-only + failure Reason (drop web-simulator turns) |
| 132 | 2026-07-11 | `f2505a0` | A | Analytics questions: include failed/cancelled turns (source turn_traces) |
| 131 | 2026-07-11 | `4b96e63` | A | Analytics: rename "Upload from lamp" stage to "Lamp response loading" |
| 130 | 2026-07-11 | `7fd47cd` | A | Record equation/graph/voice latency in document-mode dispatch (the lamp's path) |
| 129 | 2026-07-11 | `591ca0b` | A | Fix Gemini "Tutor unavailable": `given` open-dict -> typed list[GivenItem] |
| 128 | 2026-07-11 | `7a8088d` | A | Record equation + voice latency in the sync-to-audio dispatch path |
| 127 | 2026-07-10 | `a26a9f5` | A | Track graph-render latency as its own analytics stage |
| 126 | 2026-07-10 | `2616aca` | A | analytics summary: expose n_generation (generation-avg sample count) |
| 125 | 2026-07-10 | `230f74b` | A | Revert stale config.py clobber; keep only the intended main.py gzip change |
| 124 | 2026-07-10 | `070a65a` | A | Sync main.py + config.py to latest collaborator edits |
| 123 | 2026-07-10 | `87b4759` | A | Add equation-render + TTS latency to analytics questions rows |
| 122 | 2026-07-09 | `324bc6d` | A | Add range-aware admin analytics endpoints + model-selection latency |
| 121 | 2026-07-08 | `e53ce33` | A | Remove backend CI workflow |
| 120 | 2026-07-08 | `939e0bd` | A | Align config defaults with production env |
| 119 | 2026-07-07 | `5077d5d` | S | fixed readme ci error |
| 118 | 2026-07-07 | `7b1fb94` | S | added docs |
| 117 | 2026-07-06 | `db470f6` | A | Brain optimization pass: verifier ON, MCQ option-match, eval harness, CI |
| 116 | 2026-07-04 | `a5533e5` | S | added memory leak protection and cpu crash Iteration 1 done |
| 115 | 2026-07-03 | `0896f7c` | S | ux ui fixed of tft graph |
| 114 | 2026-07-03 | `80f04b6` | S | fixed graph |
| 113 | 2026-07-03 | `9f00682` | S | added rdkit in req |
| 112 | 2026-07-03 | `7250e51` | S | bug fixes |
| 111 | 2026-07-02 | `5dcb235` | S | fixed graph |
| 110 | 2026-07-02 | `4f89153` | S | added CHEM RDKIT + CHANGE THE UX + FRONTEND optimzations |
| 109 | 2026-07-02 | `9cf98ff` | S | added chemistry equation |
| 108 | 2026-07-01 | `1ed9d99` | S | fixed previous bugs and updated |
| 107 | 2026-07-01 | `4d79344` | A | Add code-enforced output validator, guardrails, and math verifier |
| 106 | 2026-07-01 | `910303d` | S | added OTA |
| 105 | 2026-06-28 | `3813d1e` | S | added the aggregated decomposition |
| 104 | 2026-06-28 | `95b6123` | S | added todo |
| 103 | 2026-06-28 | `57e76f1` | S | updated the db |
| 102 | 2026-06-28 | `4a4af29` | K | analysis related updates |
| 101 | 2026-06-26 | `47c2a9e` | S | added GRAPHS end to end |
| 100 | 2026-06-25 | `a5c7ac2` | S | added new firmware upgrades with backward compaitibility |
| 99 | 2026-06-25 | `09ad85f` | S | added TTS fix |
| 98 | 2026-06-24 | `2e1542b` | S | TTS Cartesia Stream Optimized and chemistry latext bug fixes |
| 97 | 2026-06-22 | `8db448f` | A | Add check-verdict guard + lower frustration nudge threshold to 2 |
| 96 | 2026-06-19 | `ac0e726` | S | fixed the requirements |
| 95 | 2026-06-19 | `60f9237` | S | **Merge branch 'backend' … into backend** *(sync merge)* |
| 94 | 2026-06-19 | `667052a` | S | added cartersia |
| 93 | 2026-06-19 | `dc9a936` | A | Objective questions: direct verdict instead of a Socratic nudge |
| 92 | 2026-06-19 | `bd03851` | S | turned on the flags |
| 91 | 2026-06-19 | `8014385` | K | reasoning and tts related updates |
| 90 | 2026-06-18 | `74c3e2f` | A | Fix tutor nudge/verdict issues: open-start, recheck loop, MCQ option (+ H1/H2) |
| 89 | 2026-06-18 | `b235d4e` | A | Confirm correct answers on recheck instead of nudging |
| 88 | 2026-06-18 | `6cc7423` | A | Fix nudges starting mid-solution on open-ended queries |
| 87 | 2026-06-18 | `f831ccb` | S | added claude fix |
| 86 | 2026-06-18 | `c44f5cb` | A | Fix nudges starting mid-solution on open-ended queries |
| 85 | 2026-06-17 | `027013c` | S | TTS leads + focus mode |
| 84 | 2026-06-16 | `1ca7dcf` | S | TFT error verbose and bug fix |
| 83 | 2026-06-16 | `eecd87a` | S | bugs fixses |
| 82 | 2026-06-16 | `466fced` | S | fixed prompt |
| 81 | 2026-06-16 | `00d20d6` | S | added STREAM |
| 80 | 2026-06-16 | `920e0e3` | S | upgraded Aiohttp |
| 79 | 2026-06-16 | `fad55b5` | S | CHUNK MODE ADDED |
| 78 | 2026-06-16 | `e17e0dc` | S | added temp fix |
| 77 | 2026-06-16 | `467d2a5` | K | Added Claude STT |
| 76 | 2026-06-15 | `dae5bb9` | S | fixed broken json of tier 2 thinking |
| 75 | 2026-06-15 | `afeac3a` | S | added gemini fixes |
| 74 | 2026-06-15 | `cbc2920` | S | added claude prompt guide |
| 73 | 2026-06-15 | `a68f9b0` | S | 503 fix |
| 72 | 2026-06-14 | `9f90c1d` | S | fixed history bleed |
| 71 | 2026-06-14 | `af0587e` | S | added false alarm gaurd |
| 70 | 2026-06-13 | `fa73195` | S | gemini flash 3 wired |
| 69 | 2026-06-13 | `0e3e481` | S | fixed doubts and other bugs |
| 68 | 2026-06-13 | `f033ea2` | S | Follow up fixes |
| 67 | 2026-06-13 | `4322c20` | S | FOCUS + NUDGE + FOLLOW up |
| 66 | 2026-06-12 | `2d63ee2` | S | Nudge + FOCUS + Escalation |
| 65 | 2026-06-12 | `456d78a` | K | Updated Screen display outputs |
| 64 | 2026-06-12 | `4fdb6de` | K | Added Bound Box and Updated supabase |
| 63 | 2026-06-12 | `1f79f60` | K | Turns Updated and other issues resolved |
| 62 | 2026-06-12 | `93bb729` | S | added frontend error log |
| 61 | 2026-06-12 | `17837d6` | S | added arch.md |
| 60 | 2026-06-12 | `c381255` | S | fixed the bugs |
| 59 | 2026-06-12 | `b193321` | S | Changes the system prompt arch |
| 58 | 2026-06-11 | `76c4257` | S | bug fix |
| 57 | 2026-06-11 | `9195645` | S | bug fix |
| 56 | 2026-06-10 | `2632caa` | S | fixed bug |
| 55 | 2026-06-10 | `c89f20f` | S | fixed bugs |
| 54 | 2026-06-10 | `5e4f5cb` | S | added ADPCM and bug fixes |
| 53 | 2026-06-10 | `0c4bdc2` | S | Added Opus and ADPCM coded |
| 52 | 2026-06-10 | `efaca49` | S | fixed unmirror |
| 51 | 2026-06-10 | `67ac4e9` | S | bu fix 2 |
| 50 | 2026-06-10 | `1eb928f` | S | Fixed bugs and added enhancements |
| 49 | 2026-06-09 | `cd70a9c` | S | Fixed the tts and DBMS bugs |
| 48 | 2026-06-08 | `cf28136` | S | Added Pointing and INFO for latex latency |
| 47 | 2026-06-08 | `dc166bf` | A | Remove graph_renderer.py — graph rendering feature dropped |
| 46 | 2026-06-08 | `5664677` | A | Reapply web prompt changes lost in Samiul integration pull |
| 45 | 2026-06-08 | `10a342d` | S | fixed the Redis |
| 44 | 2026-06-08 | `6a7c293` | S | Fixed Memory issue |
| 43 | 2026-06-08 | `6b16c38` | S | Fixed the whole integration, removed the graphs, fixed the camera iamge pipeline |
| 42 | 2026-06-08 | `7154406` | A | Add TFT graph rendering + escalation pre-router; align lamp prompts |
| 41 | 2026-06-07 | `8418c76` | A | Refine query_type templates, voice caps, profile and hint rules |
| 40 | 2026-06-07 | `285fd2d` | S | Fixed image processing and gemini Network retry |
| 39 | 2026-06-07 | `75b96f8` | K | Updates Turns and other fixes |
| 38 | 2026-06-07 | `b46cefa` | S | chore: update gitignore and untrack sensitive files |
| 37 | 2026-06-06 | `f55399e` | S | Fixed TTS bug |
| 36 | 2026-06-06 | `77212ae` | S | added tts and latex bug fixed |
| 35 | 2026-06-06 | `90477e4` | A | Restructure web simulator prompt around query_type + hard voice cap |
| 34 | 2026-06-05 | `b376cf7` | S | push small fixes |
| 33 | 2026-06-05 | `6b093ac` | S | added low TTS |
| 32 | 2026-06-04 | `73c8499` | K | Added multi llm features |
| 31 | 2026-06-04 | `b67e3e9` | S | bug fixes from firmware side and storing iamge locally from esp32 for dev purpose |
| 30 | 2026-06-03 | `3249c35` | K | Run.md updates |
| 29 | 2026-06-03 | `8b02271` | K | Admin data fetch Updates |
| 28 | 2026-06-02 | `53138d8` | K | supabase updates |
| 27 | 2026-06-02 | `017ca24` | K | fixed bugs |
| 26 | 2026-06-02 | `5a82708` | K | **Merge branch 'backend' … into backend** *(sync merge)* |
| 25 | 2026-06-02 | `45440c6` | K | Admin,DB and consistency related updates |
| 24 | 2026-06-02 | `224be7f` | A | Make web tutor voice length adaptive + document prompt sections |
| 23 | 2026-05-31 | `25e3ad2` | A | Revert tier-3 escalation on the lamp (keep it web-only) |
| 22 | 2026-05-31 | `2584767` | A | Crisp web voice output: cap speech + explain-properly trigger |
| 21 | 2026-05-31 | `96221c1` | A | Enhance web /simulate images before LLM (helps small handwriting) |
| 20 | 2026-05-31 | `61ac092` | A | Fix escalation_path column type to match live schema (text[] not jsonb) |
| 19 | 2026-05-31 | `cb128eb` | A | Add tier-3 (Gemini Pro) escalation + smart-skip routing |
| 18 | 2026-05-30 | `9d242b4` | S | Added Redis and multi-image system |
| 17 | 2026-05-30 | `faa480d` | S | Bug fixes |
| 16 | 2026-05-30 | `5355018` | S | Clerk OAuth Fix |
| 15 | 2026-05-29 | `4754be0` | K | Added clerk |
| 14 | 2026-05-29 | `f12d9fb` | S | added full session and db with frotnend |
| 13 | 2026-05-29 | `21fac62` | S | Added frontend backend connection |
| 12 | 2026-05-29 | `7d894d5` | S | major fixes |
| 11 | 2026-05-29 | `4b012c7` | S | DB added |
| 10 | 2026-05-28 | `e71b78a` | S | Added Redis and Auth with esp to backend to frontend |
| 9 | 2026-05-28 | `7f5a737` | S | Added and refined DBMS doc |
| 8 | 2026-05-27 | `c7dc2ce` | S | Added Latest Session memory Guide |
| 7 | 2026-05-27 | `ed25ac8` | S | Added TTS guide and Layer 5 and 6 DONE! |
| 6 | 2026-05-26 | `43d54be` | S | Added escalation intial with supabase doc |
| 5 | 2026-05-26 | `c3531d0` | S | Added guide for DB |
| 4 | 2026-05-26 | `c19e3b0` | S | Layer 1,2,3,4 DONE! |
| 3 | 2026-05-26 | `da4bd6a` | K | LAYER 1 TO LAYER 4 |
| 2 | 2026-05-26 | `4f7a77d` | S | Layer 3 and layer 4 done |
| 1 | 2026-05-26 | `bc4ba83` | S | Added temp files *(root)* |

---

## Appendix C — Full Frontend Commit Table

All 59 commits, newest → oldest, from [frontend-oneline.txt](raw/frontend-oneline.txt). Authors: **S**=samiul, **A**=ayushmaitistartups-cmyk, **K**=shashi-3000, **H**=Hellinferno. Row 16 (`d0c299b`) is the **sync merge**. (Rows are numbered from oldest = #1, so the 16 rows added in the 2026-07-11 pass are #44–#59 and no existing row's number changed.)

| # | Date | Hash | Auth | Subject |
|---:|---|---|:--:|---|
| 59 | 2026-07-11 | `2a09869` | A | Admin Analytics: remove Lamp column from the Questions table *(tip)* |
| 58 | 2026-07-11 | `54f330c` | A | Admin Analytics: show question Level + escalation in the Questions table |
| 57 | 2026-07-11 | `365862b` | A | Admin Analytics: remove Graph column from the Questions table |
| 56 | 2026-07-11 | `5b1ef69` | A | Admin Analytics: replace latency chart with tier Escalation breakdown |
| 55 | 2026-07-11 | `87be573` | A | Analytics stages: accurate step grouping (parallel + escalation) |
| 54 | 2026-07-11 | `ec5b6cd` | A | Analytics table: lamp-only + swap Status column for Reason |
| 53 | 2026-07-11 | `372e56e` | A | Analytics: number stages as a step sequence (pipeline order, 1..N) |
| 52 | 2026-07-11 | `68fefa3` | A | Analytics: show averages only (hide p95 in stage rows, tiles, legend) |
| 51 | 2026-07-11 | `b8e84b1` | A | Analytics table: show failed/cancelled turns with a Status column |
| 50 | 2026-07-10 | `db12929` | A | Analytics: add Graph-render column per question |
| 49 | 2026-07-10 | `e2b441e` | A | Analytics questions: explain what a dash (—) means |
| 48 | 2026-07-10 | `415d8c5` | A | Analytics tab: raise text contrast (faint -> muted, key numbers bright) |
| 47 | 2026-07-10 | `90ca75f` | A | Analytics tab: show the window + sample counts on every card |
| 46 | 2026-07-10 | `79c103c` | A | Analytics tab: add Equation-render + Voice (TTS) columns per question |
| 45 | 2026-07-10 | `e7b70ec` | A | chore: trigger Vercel deploy of Analytics tab under account owner |
| 44 | 2026-07-09 | `b91a229` | H | Add admin Analytics tab (generation + total latency) |
| 43 | 2026-07-02 | `ef07d7f` | A | optimizations |
| 42 | 2026-07-01 | `0ad46f7` | A | added OTA |
| 41 | 2026-06-28 | `841b71c` | A | added the aggregated |
| 40 | 2026-06-28 | `1bd9723` | A | added analytics |
| 39 | 2026-06-28 | `283da32` | K | few analysis related updates |
| 38 | 2026-06-16 | `5ac12b8` | A | for the deployment |
| 37 | 2026-06-16 | `f676e92` | K | Added claude stt related updates |
| 36 | 2026-06-13 | `9c93242` | A | added retry info |
| 35 | 2026-06-13 | `d3b66a4` | A | bug fixed |
| 34 | 2026-06-12 | `ea696b3` | A | for the deployment |
| 33 | 2026-06-12 | `0b93f95` | K | Added Bound Box and Updated Supabase |
| 32 | 2026-06-12 | `f0556f3` | A | for deployment |
| 31 | 2026-06-12 | `5c8a4ba` | K | Tunrs Updated |
| 30 | 2026-06-12 | `9002e68` | A | added error log screen |
| 29 | 2026-06-12 | `85ada6c` | A | added multi LLM support |
| 28 | 2026-06-11 | `748a334` | A | fixed Latex |
| 27 | 2026-06-11 | `ca7251f` | A | bug fix |
| 26 | 2026-06-10 | `e4fa516` | A | Big fixed |
| 25 | 2026-06-07 | `4a19acf` | A | For deployment |
| 24 | 2026-06-07 | `8b2e21a` | K | Updated Turns and other fixes |
| 23 | 2026-06-06 | `544da14` | K | Updates |
| 22 | 2026-06-06 | `8f0973f` | A | for deployment |
| 21 | 2026-06-04 | `1db7e75` | K | Added multiple LLM features |
| 20 | 2026-06-03 | `3d29f76` | K | Run.md updates |
| 19 | 2026-06-02 | `450ab0d` | A | for deployment |
| 18 | 2026-06-02 | `1311e27` | K | time mismtach updates |
| 17 | 2026-06-02 | `28a2d88` | A | Changed the md for deployment |
| 16 | 2026-06-02 | `d0c299b` | K | **Merge branch 'main' of … Smart-Tutor-frontend** *(sync merge)* |
| 15 | 2026-06-02 | `12b8fdf` | K | fixed bugs |
| 14 | 2026-06-02 | `e571690` | A | fixed bugs |
| 13 | 2026-06-02 | `6a1a261` | K | Admin , DB and consistency related updates |
| 12 | 2026-05-31 | `a5cd611` | A | Hands-free auto multi-capture while holding the mic |
| 11 | 2026-05-31 | `9b1c619` | A | Portrait camera in simulator (worksheet pages are taller than wide) |
| 10 | 2026-05-30 | `f05e944` | A | Fixed profile UI |
| 9 | 2026-05-30 | `fe978cc` | A | Fix server-side crash: make AppHeader a client component |
| 8 | 2026-05-30 | `3db01e0` | A | fixed |
| 7 | 2026-05-30 | `b4bc5e4` | S | Fixed the profile and added Multi-Image support |
| 6 | 2026-05-30 | `e313709` | S | Clerk Bug Fix and Analytics pages |
| 5 | 2026-05-30 | `c6e35d5` | A | Use rear camera for simulator capture |
| 4 | 2026-05-29 | `df38eca` | S | Added more onboarding question and fixes |
| 3 | 2026-05-29 | `4320bbb` | S | added backend frontend connection |
| 2 | 2026-05-29 | `bf70c03` | S | Fixes |
| 1 | 2026-05-28 | `ea2805b` | S | first commit *(root)* |

---

*End of document. All facts above are grounded in the git exports under [raw/](raw/); commit hashes, dates, authors, and the two repo URLs are quoted verbatim from those logs.*
