# Git History — Firmware Branch (full commit log)

This document is a complete, readable history of the **`firmware`** branch of the
`ayushmaitistartups-cmyk/Smart-Tutor-Lamp` repository. The `firmware` branch is one
of two **orphan** branches in that repo (it shares no common ancestor with the
`backend` branch); it contains the ESP32-S3 device code for the Smart Tutor Lamp —
an AI tutor lamp that captures audio over I2S, runs an on-device DSP front end
(VAD/AGC/NS/ALE), streams audio to a backend over WebSocket, and renders responses
on a TFT display.

The branch holds **21 commits**, all authored by **samiul
`<samiulseikh1221@gmail.com>`**, spanning **2026-05-25 → 2026-07-03**. The work moves
from a large monolithic "Added Firmware" drop, through a full audio + display +
networking bring-up, into provisioning/settings, backend auth integration, push-to-talk,
and an ADPCM audio-compression codec with sequential bug fixes — then, after a pause,
**resumes** with graph rendering + compression optimization, an OTA + on-device chemistry
+ UX-rework commit, and finally a first-iteration UX/navigation pass that ships a new
scroll-document reading experience for the TFT (2026-06-12 → 2026-07-03).

> All file statistics below are taken directly from the `git log --stat` output in
> `raw/firmware-full-log.txt`; the chronological ordering and one-line subjects come
> from `raw/firmware-oneline.txt`. (The regenerated `raw/firmware-full-log.txt` is now
> date-only, so the four post-2026-06-10 commits carry a date but no wall-clock time.)

---

## Table of Contents

1. [Complete Commit Table (all 21 commits, chronological)](#1-complete-commit-table-all-21-commits-chronological)
2. [Thematic Narrative](#2-thematic-narrative)
   - [2.1 Initial ESP32-S3 Bring-up & Repository Seed](#21-initial-esp32-s3-bring-up--repository-seed)
   - [2.2 Audio DSP Pipeline (mic I2S, VAD/AGC/NS/ALE, speaker I2S)](#22-audio-dsp-pipeline-mic-i2s-vadagcnsale-speaker-i2s)
   - [2.3 TFT / UI](#23-tft--ui)
   - [2.4 Networking / WebSocket](#24-networking--websocket)
   - [2.5 Pairing, Provisioning, Settings & Auth](#25-pairing-provisioning-settings--auth)
   - [2.6 Push-to-Talk & Input Controls](#26-push-to-talk--input-controls)
   - [2.7 ADPCM Audio Compression Codec](#27-adpcm-audio-compression-codec)
   - [2.8 Bug Fixes & Sequencing](#28-bug-fixes--sequencing)
   - [2.9 Documentation & Project Context](#29-documentation--project-context)
   - [2.10 Resumed Work: Compression, Graphs, OTA, UX & Navigation](#210-resumed-work-compression-graphs-ota-ux--navigation)
3. [Module Reference (firmware source files)](#3-module-reference-firmware-source-files)
4. [Timeline at a Glance](#4-timeline-at-a-glance)

---

## 1. Complete Commit Table (all 21 commits, chronological)

The table is ordered **oldest → newest** (chronological), the reverse of `git log`'s
default newest-first ordering. All commits are on the orphan `firmware` branch and all
are authored by **samiul `<samiulseikh1221@gmail.com>`**.

| #  | Hash      | Date (IST, +0530)      | Author | Subject |
|----|-----------|------------------------|--------|---------|
| 1  | `ab1313c` | 2026-05-25 15:48:05    | samiul | Added Firmware |
| 2  | `39bc06c` | 2026-05-25 18:02:56    | samiul | Added Full firmware pipeline |
| 3  | `ee76d03` | 2026-05-25 22:38:51    | samiul | Fixed |
| 4  | `7d9b370` | 2026-05-26 00:47:15    | samiul | added fully working version with dummy backend |
| 5  | `0960476` | 2026-05-27 01:30:02    | samiul | Fixes |
| 6  | `b822044` | 2026-05-28 23:03:05    | samiul | cleaned the auth |
| 7  | `79ef4b3` | 2026-05-29 11:29:40    | samiul | bug fixes |
| 8  | `598839a` | 2026-05-29 16:06:12    | samiul | added context |
| 9  | `080d6be` | 2026-06-04 01:04:57    | samiul | added setting page and wifi and tft bug fixes |
| 10 | `e1573d5` | 2026-06-05 22:56:23    | samiul | fixed auth and flow with the backend |
| 11 | `713c6b0` | 2026-06-07 00:01:49    | samiul | fix tts and i2s speaker and mic |
| 12 | `af16f95` | 2026-06-07 00:33:30    | samiul | fixed VAD and ui |
| 13 | `8bf384b` | 2026-06-07 13:48:22    | samiul | tft ui enhanced |
| 14 | `7092bab` | 2026-06-07 15:57:07    | samiul | Added push to talk and bug fixes |
| 15 | `f8c53a6` | 2026-06-08 21:16:57    | samiul | Fixed bugs and UI enhancement |
| 16 | `7db8fcc` | 2026-06-10 20:06:51    | samiul | ADDED ADPCM |
| 17 | `8c13325` | 2026-06-10 23:15:21    | samiul | Bug fixes and Lates sequential |
| 18 | `7408aa5` | 2026-06-12 *(date only)* | samiul | fixed bugs |
| 19 | `aa2143c` | 2026-06-29 *(date only)* | samiul | added Graphs and other optimization of compression |
| 20 | `e1de15a` | 2026-07-02 *(date only)* | samiul | added ota and chem and its before ux change |
| 21 | `c699e72` | 2026-07-03 *(date only)* | samiul | FIRST ITERATION COMPLETE |

> Rows 18–21 land after a pause following the 2026-06-10 ADPCM push; the regenerated
> date-only log no longer carries their commit times (rows 1–17 retain the times from
> the earlier detailed export).

**Totals at a glance** (insertions/deletions per commit, from `--stat` summary lines):

| #  | Hash      | Files changed | Insertions | Deletions |
|----|-----------|--------------:|-----------:|----------:|
| 1  | `ab1313c` | 43            | 9,854      | 0         |
| 2  | `39bc06c` | 14            | 2,713      | 60        |
| 3  | `ee76d03` | 10            | 1,762      | 197       |
| 4  | `7d9b370` | 6             | 1,010      | 94        |
| 5  | `0960476` | 7             | 331        | 22        |
| 6  | `b822044` | 3             | 101        | 47        |
| 7  | `79ef4b3` | 3             | 44         | 30        |
| 8  | `598839a` | 5             | 1,229      | 127       |
| 9  | `080d6be` | 15            | 1,706      | 64        |
| 10 | `e1573d5` | 6             | 450        | 68        |
| 11 | `713c6b0` | 4             | 34         | 2         |
| 12 | `af16f95` | 5             | 148        | 78        |
| 13 | `8bf384b` | 13            | 595        | 112       |
| 14 | `7092bab` | 7             | 227        | 98        |
| 15 | `f8c53a6` | 7             | 289        | 46        |
| 16 | `7db8fcc` | 12            | 838        | 128       |
| 17 | `8c13325` | 9             | 460        | 15        |
| 18 | `7408aa5` | 4             | 35         | 3         |
| 19 | `aa2143c` | 7             | 775        | 284       |
| 20 | `e1de15a` | 9             | 676        | 248       |
| 21 | `c699e72` | 16            | 198,355    | 23        |

---

## 2. Thematic Narrative

The 21 commits cluster into a clear arc: a big monolithic firmware seed and full-pipeline
bring-up (commits 1–4), a stabilization/auth-cleanup phase with a dummy backend
(commits 4–8), a settings/Wi-Fi/provisioning build-out and real backend integration
(commits 9–10), an audio + VAD + UI refinement burst (commits 11–13), push-to-talk
(commit 14), an ADPCM codec with sequential fixes (commits 15–17), and — after a
multi-week pause — a resumed cluster of graph rendering + compression optimization, an
OTA / on-device chemistry / UX rework, and a first-iteration UX/navigation pass shipping a
new TFT scroll-document reading experience (commits 18–21). The
sections below group the commits thematically; because most commits touch several
subsystems at once, individual commits are referenced under more than one theme where
appropriate.

### 2.1 Initial ESP32-S3 Bring-up & Repository Seed

**Commit 1 — `ab1313c` "Added Firmware" (2026-05-25 15:48:05) — 43 files, +9,854.**
This is the repository seed and by far the largest commit. It lands the entire ESP32-S3
firmware project plus extensive design docs and several standalone Arduino test sketches.
Everything is additive (zero deletions). Highlights from the `--stat`:

- **Design / context docs:** `BACKEND_DESIGN.md` (+449), `CLAUDE.md` (+113),
  `IMPLEMENTATION_AUTH_PAIRING.md` (+2,098), `IMPLEMENTATION_WEBSOCKET.md` (+684),
  `PROJECT_CONTEXT.md` (+435), and a hardware pinout image `ESP32S3_Pinout.png`
  (binary, 214,830 bytes).
- **Core firmware sketch + DSP front end** under `tutor_lamp/`: the main
  `tutor_lamp.ino` (+329) plus a full audio DSP chain delivered as discrete stages —
  `mic_i2s.{cpp,h}` (microphone capture), `agc_stage.{cpp,h}` (automatic gain control),
  `ale_stage.{cpp,h}` (adaptive line enhancer, +119/+55), `ns_stage.{cpp,h}` (noise
  suppression), `vad_stage.{cpp,h}` (voice activity detection, +99/+59),
  `audio_post_process.{cpp,h}`, and `wake_word.{cpp,h}` (+112/+45).
- **Networking & provisioning:** `net_ws.{cpp,h}` (WebSocket client, +208/+82) and
  `provisioning.{cpp,h}` (device provisioning, +341/+92).
- **Display:** `tft_display.{cpp,h}`, `tft_qr.{cpp,h}` (QR rendering for pairing), and
  `image_viewer.{cpp,h}` (+155/+73).
- **Standalone test/bring-up sketches** (separate Arduino projects committed alongside
  the firmware): `wake_word_hey_lamp/` (+293), `camera_test/` (including a 765-line
  `camera_server.py`, a 720-line `camera_test.ino`, `board_config.h`, `camera_pins.h`,
  and a docs README), `ei_data_collector/` (Edge Impulse data collection),
  `mic_recorder/`, `push_buttons/`, `tft_latex_client/` (+183, hints at LaTeX rendering
  on TFT), and `wifi_audio_player/` (+314).

This commit establishes the project's entire shape: an Arduino/ESP32-S3 sketch composed
of per-concern modules (audio stages, networking, provisioning, display), a set of
exploratory hardware test sketches, and design documentation describing the WebSocket
protocol and the auth/pairing flow.

**Commit 2 — `39bc06c` "Added Full firmware pipeline" (2026-05-25 18:02:56) — 14 files,
+2,713/−60.** Roughly two and a half hours later, this commit wires the pipeline
together end-to-end and adds the major interactive pieces:

- **Speaker output:** new `spk_i2s.{cpp,h}` (+224/+82) introduces I2S speaker playback —
  the output side that complements the existing `mic_i2s` capture side.
- **Display UI layer:** a large new `tft_ui.{cpp,h}` (+913/+116) becomes the central UI
  module, on top of the lower-level `tft_display`/`tft_qr` from commit 1; `tft_qr.cpp`
  is also extended (+44/−... ).
- **Buttons / input:** new `buttons.{cpp,h}` (+62/+53) add physical-button handling.
- **Pairing QR asset:** `RICqrcode.{c,h}` (+872/+95) — a large generated QR-code data
  asset (the "RIC" QR), used for the pairing screen.
- **Provisioning + WS tweaks:** small edits to `provisioning.{cpp,h}` and `net_ws.h`.
- The main `tutor_lamp.ino` grows by +295/−... to orchestrate the now-complete pipeline,
  and a `.gitignore` (+5) is added.

After these two same-day commits, the device has its full intended feature surface: audio
in/out, DSP, display+UI, buttons, networking, and provisioning with a pairing QR.

### 2.2 Audio DSP Pipeline (mic I2S, VAD/AGC/NS/ALE, speaker I2S)

The audio path is a recurring theme across the whole history. It is introduced in
commits 1–2 (above) and then repeatedly tuned:

- **Commit 1 `ab1313c`** seeds the full DSP front end as separate stages: `mic_i2s`,
  `agc_stage`, `ale_stage`, `ns_stage`, `vad_stage`, `audio_post_process`, and
  `wake_word`. This is the "capture + clean + detect speech + detect wake word" chain.
- **Commit 2 `39bc06c`** adds the output half with `spk_i2s` (I2S speaker playback).
- **Commit 3 — `ee76d03` "Fixed" (2026-05-25 22:38:51) — 10 files, +1,762/−197.** A large
  same-day stabilization pass that heavily reworks the audio and I/O layers and also adds
  the camera. The mic path is substantially extended (`mic_i2s.cpp` +139/−... rewrite-scale
  change) and the speaker path is reworked (`spk_i2s.cpp` +111/−... ). It also lands the
  full camera subsystem on the firmware sketch for the first time: `camera.{cpp,h}`
  (+476/+132), `camera_pins.h` (+338), and `board_config.h` (+34) — bringing the
  camera_test sketch's hardware definitions into the main `tutor_lamp` build. `net_ws`,
  `tft_ui`, and a very large `tutor_lamp.ino` change (+510/−197) round it out. This is the
  point where mic, speaker, camera, networking, and UI are all being made to work together.
- **Commit 11 — `713c6b0` "fix tts and i2s speaker and mic" (2026-06-07 00:01:49) — 4
  files, +34/−2.** A small, targeted audio fix focused on text-to-speech playback and the
  I2S speaker/mic path: `spk_i2s.cpp` (+7/−1) plus a new `wake_word.{cpp,h}` pair
  (+15/+11) and a one-line `backend_config.h` tweak. (`wake_word` had existed since commit
  1; this re-adds/adjusts a wake-word helper alongside the TTS/I2S fix.)
- **Commit 12 — `af16f95` "fixed VAD and ui" (2026-06-07 00:33:30) — 5 files,
  +148/−78.** Tunes voice-activity detection (`vad_stage.cpp` +19/−..., `vad_stage.h`
  +17) together with a large UI rework (`tft_ui.cpp` +172/−...), plus small touches to
  `tft_settings.cpp` and `tutor_lamp.ino`. VAD and the UI that reflects listening state
  are tightened together.
- **Commit 13 — `8bf384b` "tft ui enhanced"** also adjusts `vad_stage.{cpp,h}` (+7/−...,
  +12) alongside its big UI work (see §2.3).
- **Commit 14 — `7092bab` "Added push to talk"** touches `vad_stage.h` (+14/−...) because
  push-to-talk changes how/when VAD gating applies (see §2.6).
- **Commits 16–17** ( `7db8fcc`, `8c13325`) revisit `spk_i2s.cpp` (+71/−... and +10/−...
  respectively) and `vad_stage.{cpp,h}` as part of the ADPCM codec work (see §2.7) — the
  decoder feeds decoded PCM into the I2S speaker, so the playback path is touched again.

In short: the DSP front end (`mic_i2s` → `agc`/`ns`/`ale`/`vad` → `wake_word`) and the
playback back end (`spk_i2s`) are seeded early and then iteratively tuned for VAD
behavior, TTS playback, and finally ADPCM-decoded audio.

### 2.3 TFT / UI

The TFT display and its UI are among the most frequently edited areas of the firmware.

- **Commit 1 `ab1313c`** seeds the low-level display stack: `tft_display.{cpp,h}`,
  `tft_qr.{cpp,h}` (QR rendering), and `image_viewer.{cpp,h}`.
- **Commit 2 `39bc06c`** adds the high-level `tft_ui.{cpp,h}` (+913/+116) — the main UI
  module — and extends `tft_qr.cpp`.
- **Commit 3 `ee76d03`** reworks `tft_ui.cpp` (+121/−...) as part of the big bring-up.
- **Commit 4 — `7d9b370` "added fully working version with dummy backend"** makes a very
  large UI change: `tft_ui.cpp` +395/−... and `tft_ui.h` +28 (see §2.4 for the dummy
  backend context).
- **Commit 5 — `0960476` "Fixes"** extends `tft_ui.{cpp,h}` (+124/+11) alongside
  networking fixes.
- **Commit 7 — `79ef4b3` "bug fixes"** makes a tiny `tft_ui.cpp` tweak (+5/−2).
- **Commit 9 — `080d6be` "added setting page and wifi and tft bug fixes"** adds a whole
  settings UI subsystem (see §2.5) and extends `tft_ui.{cpp,h}` (+74/+34).
- **Commit 12 — `af16f95` "fixed VAD and ui"** reworks `tft_ui.cpp` (+172/−...) — see §2.2.
- **Commit 13 — `8bf384b` "tft ui enhanced" (2026-06-07 13:48:22) — 13 files,
  +595/−112.** A dedicated UI-enhancement commit. The headline change is `tft_ui.cpp`
  (+301/−...) plus `tft_ui.h` (+15), and a substantial settings-screen rework
  (`tft_settings.cpp` +125/−...). It also brings the camera back into play on the UI side
  (`camera.{cpp,h}` +11/+9), extends `settings_store.{cpp,h}` (+53/+19) and
  `text_entry.{cpp,h}`, and tunes `vad_stage.{cpp,h}`. This commit is squarely about
  polishing the on-device experience.
- **Commit 14 — `7092bab` "Added push to talk and bug fixes"** reworks `tft_ui.{cpp,h}`
  (+90/+4) to surface push-to-talk state.
- **Commit 15 — `f8c53a6` "Fixed bugs and UI enhancement" (2026-06-08 21:16:57) — 7
  files, +289/−46.** Another UI-focused fix: the dominant change is `tft_ui.cpp`
  (+262/−...), with smaller speaker (`spk_i2s.cpp` +42/−...) and networking
  (`net_ws.{cpp,h}`) touches.
- **Commit 16 — `7db8fcc` "ADDED ADPCM"** also reworks `tft_ui.cpp` (+173/−...) and
  `tft_ui.h` (+8) as part of the codec/streaming UX (see §2.7).
- **Commit 17 — `8c13325`** adds to `tft_ui.{cpp,h}` (+68/+22) in the final fix pass.

The pattern: a low-level display stack (commit 1) → a central `tft_ui` module
(commit 2) → continuous enhancement, with a dedicated settings UI (`tft_settings`,
`text_entry`) introduced in commit 9 and polished in commit 13.

### 2.4 Networking / WebSocket

Networking is built around the `net_ws` (WebSocket) module and a `dummy_backend.py`
used for local development before the real backend was ready.

- **Commit 1 `ab1313c`** seeds `net_ws.{cpp,h}` (+208/+82) and the protocol design docs
  (`IMPLEMENTATION_WEBSOCKET.md`).
- **Commit 2 `39bc06c`** makes a minor `net_ws.h` tweak (+2/−1).
- **Commit 3 `ee76d03`** extends `net_ws.{cpp,h}` (+64/+34, with header churn −...) during
  the big bring-up.
- **Commit 4 — `7d9b370` "added fully working version with dummy backend" (2026-05-26
  00:47:15) — 6 files, +1,010/−94.** A milestone: the first end-to-end "working" device.
  It adds a standalone **`dummy_backend.py` (+463)** — a local stand-in server so the
  firmware can be exercised without the real backend — and pairs it with a large camera
  change (`camera.cpp` +68/−...), a big UI change (`tft_ui.cpp` +395/−..., `tft_ui.h`
  +28), a small `spk_i2s.cpp` fix, and a substantial `tutor_lamp.ino` change (+148/−94)
  to drive the full flow against the dummy backend.
- **Commit 5 — `0960476` "Fixes" (2026-05-27 01:30:02) — 7 files, +331/−22.** Networking
  hardening: `net_ws.cpp` (+49/−...) and `net_ws.h` (+32/−...) are extended, a new block of
  `backend_config.h` (+53) is added (endpoint/config constants), `provisioning.h` is
  touched, and `tft_ui.{cpp,h}` (+124/+11) and `tutor_lamp.ino` (+73/−...) are updated to
  match.
- **Commit 7 — `79ef4b3` "bug fixes" (2026-05-29 11:29:40) — 3 files, +44/−30.** Small
  WebSocket-centric bug-fix pass: `net_ws.cpp` (+31/−...), a tiny `tft_ui.cpp` change, and
  a `tutor_lamp.ino` cleanup (+38/−... with net deletions, i.e. simplification).
- **Commit 10 — `e1573d5` "fixed auth and flow with the backend"** contains the single
  largest `net_ws.cpp` change in the history (+324/−...) as the device is connected to the
  real backend auth/flow (see §2.5).
- **Commits 15, 16, 17** all make smaller `net_ws.{cpp,h}` edits: `f8c53a6` (+11/+6),
  `7db8fcc` (+167/+29, the ADPCM-over-WebSocket transport), and `8c13325` (+13/+13). The
  big `net_ws.cpp` growth in commit 16 is the streaming transport for ADPCM frames (see
  §2.7).

The arc here is: protocol seed → dummy backend for local iteration (commit 4) →
config + connection hardening (commits 5, 7) → real backend auth/flow integration
(commit 10) → ADPCM streaming transport (commit 16).

### 2.5 Pairing, Provisioning, Settings & Auth

Pairing/provisioning (getting the device onto Wi-Fi and bound to a user account) and the
on-device settings UI form a major theme.

- **Commit 1 `ab1313c`** seeds `provisioning.{cpp,h}` (+341/+92) and the
  `IMPLEMENTATION_AUTH_PAIRING.md` design doc (+2,098 — the single largest doc), plus
  `tft_qr` for displaying a pairing QR.
- **Commit 2 `39bc06c`** adds the `RICqrcode.{c,h}` QR asset used on the pairing screen
  and tweaks `provisioning.{cpp,h}`.
- **Commit 6 — `b822044` "cleaned the auth" (2026-05-28 23:03:05) — 3 files, +101/−47.** A
  focused refactor of the provisioning/auth code: `provisioning.cpp` (+139/−47, a
  significant rewrite), `provisioning.h` (+5/−...), and a 4-line `tutor_lamp.ino` change.
  This is a cleanup/consolidation of the auth flow before deeper backend integration.
- **Commit 9 — `080d6be` "added setting page and wifi and tft bug fixes" (2026-06-04
  01:04:57) — 15 files, +1,706/−64.** A large feature commit that introduces the entire
  **on-device settings + Wi-Fi configuration UI**. New modules:
  - `settings_store.{cpp,h}` (+167/+75) — persistent settings storage.
  - `text_entry.{cpp,h}` (+360/+93) — an on-screen text-entry widget (for typing Wi-Fi
    SSID/password and other settings on the TFT).
  - `tft_settings.{cpp,h}` (+471/+58) — the settings screen itself.

  It also substantially reworks `backend_config.h` (+109/−...), extends
  `buttons.{cpp,h}`, `spk_i2s.{cpp,h}` (+39/+8), `tft_ui.{cpp,h}` (+74/+34),
  `provisioning.cpp` (+7), and makes a large `tutor_lamp.ino` change (+222/−...). After
  this commit the user can configure Wi-Fi and settings directly on the device.
- **Commit 10 — `e1573d5` "fixed auth and flow with the backend" (2026-06-05 22:56:23) —
  6 files, +450/−68.** The real-backend auth integration milestone. Dominated by
  `net_ws.cpp` (+324/−...) plus a reworked `backend_config.h` (+55/−...), `buttons.{cpp,h}`
  changes, a `spk_i2s.cpp` addition (+17), and a `tutor_lamp.ino` change (+95/−...). This
  is where the device's auth/pairing handshake and overall flow are made to work against
  the actual backend (replacing the dummy-backend behavior from commit 4).
- **Commit 13 — `8bf384b`** further extends `settings_store.{cpp,h}` (+53/+19),
  `text_entry.{cpp,h}`, and `tft_settings.cpp` (+125/−...) as part of the UI-enhancement
  pass (see §2.3).
- **Commit 12 — `af16f95`** makes a small `tft_settings.cpp` change (+14/−...).

Provisioning/auth therefore evolves from a seeded module (commit 1) → an auth cleanup
(commit 6) → a full on-device settings/Wi-Fi UI (commit 9) → real backend auth/flow
integration (commit 10) → settings UI polish (commit 13).

### 2.6 Push-to-Talk & Input Controls

Physical input is handled by the `buttons` module (seeded in commit 2), and the headline
input feature is push-to-talk.

- **Commit 2 `39bc06c`** introduces `buttons.{cpp,h}` (+62/+53).
- **Commits 9 and 10** extend `buttons.{cpp,h}` (`080d6be`: +31/+22; `e1573d5`: +16/−...,
  +11/−...) as buttons are wired into settings navigation and the backend flow.
- **Commit 14 — `7092bab` "Added push to talk and bug fixes" (2026-06-07 15:57:07) — 7
  files, +227/−98.** The push-to-talk feature. It adds new fields/handlers to
  `buttons.{cpp,h}` (+3, +7), reworks the UI to reflect PTT state (`tft_ui.cpp` +90/−...,
  `tft_ui.h` +4), adjusts VAD gating for held-button capture (`vad_stage.h` +14/−...), and
  makes a large `tutor_lamp.ino` change (+205/−98 — note the heavy deletions, i.e. the
  capture/turn-taking loop was reworked, not just extended). A `backend_config.h` one-liner
  rounds it out. Push-to-talk lets the user hold a button to talk instead of relying purely
  on wake-word/VAD-triggered capture.

### 2.7 ADPCM Audio Compression Codec

The final feature cluster adds **ADPCM** (Adaptive Differential PCM) audio compression so
audio can be streamed more efficiently over the WebSocket link.

- **Commit 16 — `7db8fcc` "ADDED ADPCM" (2026-06-10 20:06:51) — 12 files, +838/−128.** The
  feature commit. It introduces a new decoder module **`adpcm_dec.{cpp,h}` (+85/+33)** and
  wires it through the whole streaming/playback path:
  - **Transport:** `net_ws.{cpp,h}` (+167/+29) gains the ADPCM frame transport over the
    WebSocket (receiving compressed audio frames from the backend).
  - **Playback:** `spk_i2s.cpp` (+71/−...) is updated to play back the decoded PCM.
  - **Capture/DSP:** `vad_stage.{cpp,h}` (+20/+24) and `audio_post_process.cpp` (+7/−...)
    are adjusted for the new frame sizing/flow.
  - **UI:** `tft_ui.{cpp,h}` (+173/+8) and a large `tutor_lamp.ino` change (+345/−...) tie
    the codec into the main loop and UI, with a `backend_config.h` tweak.
- **Commit 17 — `8c13325` "Bug fixes and Lates sequential" (2026-06-10 23:15:21) — 9
  files, +460/−15.** A same-evening follow-up that fixes and extends the ADPCM path and
  reworks sequencing. It substantially extends `adpcm_dec.{cpp,h}` (+68/+12 — bug fixes /
  more of the decoder), touches `net_ws.{cpp,h}` (+13/+13) and `spk_i2s.cpp` (+10/−...),
  adds to `tft_ui.{cpp,h}` (+68/+22), and makes the largest single change in this commit to
  `tutor_lamp.ino` (+267/−... ). The subject's "Lates sequential" refers to reworking the
  sequential/turn-taking flow (capture → encode/decode → playback ordering) so the ADPCM
  pipeline behaves correctly end-to-end.

The codec is therefore added in one commit (16) and immediately stabilized in the next
(17), both on the same day.

### 2.8 Bug Fixes & Sequencing

Several commits are primarily stabilization passes rather than new features. They are
spread throughout the history and typically touch whichever subsystem was most recently
changed:

- **Commit 3 — `ee76d03` "Fixed"** — large early stabilization (audio + camera + net + UI;
  +1,762/−197). See §2.2.
- **Commit 5 — `0960476` "Fixes"** — networking + UI hardening (+331/−22). See §2.4.
- **Commit 7 — `79ef4b3` "bug fixes"** — small WebSocket + `tutor_lamp.ino` cleanup
  (+44/−30). See §2.4.
- **Commit 11 — `713c6b0` "fix tts and i2s speaker and mic"** — small targeted audio fix
  (+34/−2). See §2.2.
- **Commit 12 — `af16f95` "fixed VAD and ui"** — VAD + UI fix (+148/−78). See §2.2/§2.3.
- **Commit 15 — `f8c53a6` "Fixed bugs and UI enhancement"** — UI + speaker + net fixes
  (+289/−46). See §2.3.
- **Commit 17 — `8c13325` "Bug fixes and Lates sequential"** — ADPCM stabilization +
  sequencing rework (+460/−15). See §2.7.

Notably, the heavier "fix" commits (3, 5, 12, 15, 17) each pair bug fixes with UI work,
reflecting a workflow where stabilization and on-device-UX polish happened together.

### 2.9 Documentation & Project Context

Two commits are documentation-heavy:

- **Commit 1 `ab1313c`** ships the original design docs: `BACKEND_DESIGN.md` (+449),
  `CLAUDE.md` (+113), `IMPLEMENTATION_AUTH_PAIRING.md` (+2,098),
  `IMPLEMENTATION_WEBSOCKET.md` (+684), and `PROJECT_CONTEXT.md` (+435), plus the
  `ESP32S3_Pinout.png` hardware reference.
- **Commit 8 — `598839a` "added context" (2026-05-29 16:06:12) — 5 files, +1,229/−127.** A
  documentation-only commit that substantially expands the project context. It **adds a new
  `HARDWARE_CONTEXT.md` (+612)** (the largest single doc added here, a detailed hardware
  reference), expands `PROJECT_CONTEXT.md` (+400/−...), `BACKEND_DESIGN.md` (+98/−...), and
  `IMPLEMENTATION_AUTH_PAIRING.md` (+133/−...), and **removes `CLAUDE.md` (−113)** (the
  agent-instructions file is deleted in favor of the richer context docs). No firmware
  source files are touched in this commit — it is purely about documenting hardware,
  backend design, and the auth/pairing implementation.

### 2.10 Resumed Work: Compression, Graphs, OTA, UX & Navigation

After the 2026-06-10 ADPCM push the firmware went quiet, then resumed with four commits
that track the backend's late feature waves (graphs/compression, then OTA + chemistry,
then a first-iteration UX/navigation pass).

- **Commit 18 — `7408aa5` "fixed bugs" (2026-06-12) — 4 files, +35/−3.** A small
  networking/config fix pass immediately after the ADPCM work: `net_ws.cpp` (+24/−1) plus
  one-line touches to `backend_config.h`, `tft_ui.cpp`, and `tutor_lamp.ino`.
- **Commit 19 — `aa2143c` "added Graphs and other optimization of compression"
  (2026-06-29) — 7 files, +775/−284.** The device-side counterpart to the backend's
  "added GRAPHS end to end" work: `tft_ui.cpp` (+250) and `tft_ui.h` (+36) gain graph
  display, `buttons.{cpp,h}` and `net_ws.h` are extended, and the main loop is heavily
  reworked (`tutor_lamp.ino` +687/−... — the largest `.ino` change in the branch) to add
  the compression optimization and graph frames.
- **Commit 20 — `e1de15a` "added ota and chem and its before ux change" (2026-07-02) —
  9 files, +676/−248.** Adds three new modules —
  an over-the-air-update path **`ota.cpp` (+150) / `ota.h` (+38)** and a
  **`display_config.h` (+65)** — alongside a large UX rework of the TFT layer
  (`tft_ui.cpp` +489/−..., `tft_ui.h`, `text_entry.cpp`, `tft_settings.cpp`) plus
  `net_ws.h` and `tutor_lamp.ino` (+34). It lands on-device OTA, a centralized display
  configuration, and the pre-chemistry UX change that pairs with the backend's
  chemistry/RDKit rendering.
- **Commit 21 — `c699e72` "FIRST ITERATION COMPLETE" (2026-07-03) — 10 non-binary
  files, +198,355/−23 (branch tip).** The huge insertion count is almost entirely the
  generated `tutor_lamp.ino.map` build artifact (197,559 lines); the commit also touches
  five `tutor_lamp/build/esp32.esp32.esp32s3/*.bin/.elf/.map` binary/build outputs that
  aren't narrated further (same treatment as this doc gives other generated/binary blobs).
  The real source diff across the 10 tracked files is modest, ~700 lines, and is the
  device's first-iteration UX/navigation pass:
  - **New scroll-document TFT page** (`PAGE_DOC` / `TFT_SCROLL_DOC`) — the headline change,
    almost entirely inside **`tft_ui.cpp` (+378) / `tft_ui.h` (+24)**: one continuous
    vertical scrollable document stacking text/equations/graphs/chemistry, replacing the
    old combined-view + separate-frame-pages model for reading an answer. Two new
    WebSocket frame types land in `net_ws.h` (+2): `FRAME_TFT_DOC_MANIFEST = 0x2B` and
    `FRAME_TFT_DOC_ELEM = 0x2C`. (Full technical write-up in the companion doc
    `01-firmware/02-display-and-ui.md` §4.9 — summarized here, not duplicated.)
  - **New button:** `buttons.cpp` (+3) / `buttons.h` (+3) add a `BTN_RIGHT_LONG`
    long-press mapping — RIGHT previously had no long-press variant at all — used to open
    the interactive graph arena from the scroll-document.
  - **Multi-graph support:** the `FRAME_GRAPH_VIEW` (0x09) wire payload grows from 16 to
    17 bytes, gaining a leading `graph_id` byte so one turn's document can hold several
    independently-focusable graphs (the backend counterpart is documented in
    `02-backend-branch-commits.md`'s memory-leak-hardening entry).
  - **`backend_config.h` (+4):** flips the `BACKEND_SERVER_HOST` default to
    `lumi-smart-lamp.onrender.com` (was `smart-tutor-lamp.onrender.com`, now the
    commented-out alternate).
  - **`ota.h` (+2):** `FIRMWARE_VERSION` bumped 1 → 4 (a monotonic OTA release-counter
    bump).
  - **`tutor_lamp.ino` (+56):** `setup()`'s `while (!Serial);` (an infinite hang with no
    USB host attached) becomes `while (!Serial && millis() < 2000);` — boots headless
    after a 2 s grace period — and wires up the new `BTN_RIGHT_LONG` dispatch and the
    `FRAME_GRAPH_VIEW` `graph_id` prefix byte.
  - **Two new docs:** `NAVIGATION.md` (+202), a buttons/navigation user guide (5-way pad,
    1.5 s hold threshold, a per-page button table, and the RIGHT=open-graph /
    LEFT=transcript-toggle design rationale), and `TFT_UX_FINDINGS.md` (+145), a UI/UX
    design critique of the old combined-view TFT layout (9 numbered findings each tagged
    ✅/🟡/🔲 addressed-status, explaining `TFT_SCROLL_DOC` as the shipped fix for several,
    plus a prioritized backlog).

---

## 3. Module Reference (firmware source files)

All firmware source lives under `tutor_lamp/`. The table summarizes each module's role and
the commits in which it was introduced or notably changed.

| Module | Role | Introduced | Notably changed in |
|--------|------|-----------|--------------------|
| `tutor_lamp.ino` | Main sketch / orchestration loop | `ab1313c` | `39bc06c`, `ee76d03` (+510/−197), `080d6be` (+222), `7092bab` (+205/−98), `7db8fcc` (+345), `8c13325` (+267), `aa2143c` (+687), `e1de15a` (+34), `c699e72` (56 lines) |
| `mic_i2s.{cpp,h}` | I2S microphone capture | `ab1313c` | `ee76d03` (+139) |
| `spk_i2s.{cpp,h}` | I2S speaker playback | `39bc06c` (+224/+82) | `ee76d03` (+111), `080d6be`, `e1573d5`, `f8c53a6`, `7db8fcc` (+71), `8c13325` |
| `agc_stage.{cpp,h}` | Automatic gain control | `ab1313c` | — |
| `ale_stage.{cpp,h}` | Adaptive line enhancer | `ab1313c` | — |
| `ns_stage.{cpp,h}` | Noise suppression | `ab1313c` | — |
| `vad_stage.{cpp,h}` | Voice activity detection | `ab1313c` | `af16f95`, `8bf384b`, `7092bab`, `7db8fcc` |
| `audio_post_process.{cpp,h}` | Audio post-processing | `ab1313c` | `7db8fcc` |
| `wake_word.{cpp,h}` | Wake-word ("hey lamp") detection | `ab1313c` | `713c6b0` |
| `adpcm_dec.{cpp,h}` | ADPCM audio decoder | `7db8fcc` (+85/+33) | `8c13325` (+68/+12) |
| `net_ws.{cpp,h}` | WebSocket client / transport | `ab1313c` (+208/+82) | `ee76d03`, `0960476`, `79ef4b3`, `e1573d5` (+324), `f8c53a6`, `7db8fcc` (+167), `8c13325`, `c699e72` (+2, `net_ws.h` only — new frame types) |
| `provisioning.{cpp,h}` | Device provisioning / pairing | `ab1313c` (+341/+92) | `b822044` (+139/−47), `080d6be` |
| `backend_config.h` | Backend endpoint/config constants | `ab1313c` (in docs) / `0960476` (+53) | `080d6be` (+109), `e1573d5` (+55), `c699e72` (+4, default host flipped), and several small tweaks |
| `settings_store.{cpp,h}` | Persistent settings storage | `080d6be` (+167/+75) | `8bf384b` (+53/+19) |
| `text_entry.{cpp,h}` | On-screen text-entry widget | `080d6be` (+360/+93) | `8bf384b` |
| `tft_settings.{cpp,h}` | Settings screen UI | `080d6be` (+471/+58) | `af16f95`, `8bf384b` (+125) |
| `tft_ui.{cpp,h}` | Main TFT UI module | `39bc06c` (+913/+116) | nearly every later commit (see §2.3); most recently `c699e72` (+378/+24 — new `PAGE_DOC`/`TFT_SCROLL_DOC`) |
| `tft_display.{cpp,h}` | Low-level display driver | `ab1313c` | — |
| `tft_qr.{cpp,h}` | QR-code rendering (pairing) | `ab1313c` | `39bc06c` |
| `image_viewer.{cpp,h}` | Image display | `ab1313c` | — |
| `buttons.{cpp,h}` | Physical button handling | `39bc06c` (+62/+53) | `080d6be`, `e1573d5`, `7092bab`, `c699e72` (+3/+3 — new `BTN_RIGHT_LONG`) |
| `camera.{cpp,h}` | Camera capture | `ee76d03` (+476/+132) | `7d9b370` (+68), `8bf384b` |
| `camera_pins.h` / `board_config.h` | Hardware pin/board definitions | `ee76d03` | — |
| `RICqrcode.{c,h}` | Generated pairing-QR data asset | `39bc06c` (+872/+95) | — |
| `ota.{cpp,h}` | Over-the-air firmware update | `e1de15a` (+150/+38) | `c699e72` (+2, `ota.h` only — `FIRMWARE_VERSION` 1→4) |
| `display_config.h` | Centralized TFT display configuration | `e1de15a` (+65) | — |
| `NAVIGATION.md` | Buttons/navigation user guide | `c699e72` (+202) | — |
| `TFT_UX_FINDINGS.md` | TFT UI/UX design critique | `c699e72` (+145) | — |

Standalone helper artifacts at the repo root or in sibling sketch folders include
`dummy_backend.py` (local test server, `7d9b370`), plus the bring-up sketches added in
`ab1313c`: `wake_word_hey_lamp/`, `camera_test/` (with `camera_server.py`),
`ei_data_collector/`, `mic_recorder/`, `push_buttons/`, `tft_latex_client/`, and
`wifi_audio_player/`.

---

## 4. Timeline at a Glance

```
2026-05-25  ab1313c  Added Firmware                          (seed; 43 files, +9,854)
2026-05-25  39bc06c  Added Full firmware pipeline            (spk_i2s, tft_ui, buttons, QR)
2026-05-25  ee76d03  Fixed                                   (camera + audio + net bring-up)
2026-05-26  7d9b370  added fully working version w/ dummy backend  (dummy_backend.py)
2026-05-27  0960476  Fixes                                   (net_ws + config hardening)
2026-05-28  b822044  cleaned the auth                        (provisioning refactor)
2026-05-29  79ef4b3  bug fixes                               (WebSocket + ino cleanup)
2026-05-29  598839a  added context                           (docs: HARDWARE_CONTEXT.md)
            ── ~6-day gap ──
2026-06-04  080d6be  added setting page and wifi + tft fixes (settings_store/text_entry/tft_settings)
2026-06-05  e1573d5  fixed auth and flow with the backend    (real backend auth; net_ws +324)
2026-06-07  713c6b0  fix tts and i2s speaker and mic         (TTS/I2S fix)
2026-06-07  af16f95  fixed VAD and ui                        (VAD + UI)
2026-06-07  8bf384b  tft ui enhanced                         (UI + settings polish)
2026-06-07  7092bab  Added push to talk and bug fixes        (push-to-talk)
2026-06-08  f8c53a6  Fixed bugs and UI enhancement           (UI + speaker + net fixes)
2026-06-10  7db8fcc  ADDED ADPCM                             (adpcm_dec; codec + transport)
2026-06-10  8c13325  Bug fixes and Lates sequential          (ADPCM stabilization + sequencing)
            ── pause, then intermittent resume ──
2026-06-12  7408aa5  fixed bugs                              (net_ws / config fix pass)
2026-06-29  aa2143c  added Graphs and other optimization...  (graph display + compression; tutor_lamp.ino +687)
2026-07-02  e1de15a  added ota and chem and its before ux..  (ota.*, display_config.h; TFT UX rework)
2026-07-03  c699e72  FIRST ITERATION COMPLETE                (TFT_SCROLL_DOC; NAVIGATION.md, TFT_UX_FINDINGS.md — tip)
```

The work is bursty: four commits on the very first day (2026-05-25), steady daily progress
through 2026-05-29, a roughly six-day quiet stretch, then an intense 2026-06-04 → 2026-06-10
finishing push covering settings/Wi-Fi, real backend auth, audio/VAD/UI refinement,
push-to-talk, and the ADPCM codec. After 2026-06-10 the branch does **not** freeze — it
goes quiet and then resumes with four sparse commits (06-12, 06-29, 07-02, 07-03) that mirror
the backend's later graphs/compression, OTA/chemistry, and memory-leak-hardening waves,
ending on the 2026-07-03 tip `c699e72`.

---

*Source data: `D:/clartiy/information/06-git-history/raw/firmware-full-log.txt`
(per-commit `--stat` file lists) and
`D:/clartiy/information/06-git-history/raw/firmware-oneline.txt` (chronological subjects).
Branch: `firmware` (orphan) of `ayushmaitistartups-cmyk/Smart-Tutor-Lamp`. 21 commits,
all by samiul `<samiulseikh1221@gmail.com>`, 2026-05-25 → 2026-07-03.*
