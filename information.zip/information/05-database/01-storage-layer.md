# Database — Storage Layer (Repositories)

The `app/storage/` package is the backend's **repository layer (Layer 9)** — the off-hot-path persistence boundary between the live turn pipeline and Postgres/object-storage. It owns the writers/readers for the lamp's conversation history (`sessions`, `turns`), the generic audit log (`events`), the cross-session learner profile (`user_memory`), the web-onboarding profile (`user_profiles`), the multi-LLM evaluation bench tables (`model_requests`/`model_responses`/`model_feedback`/`model_providers`), the **pilot-instrumentation cluster** (`turn_feedback`/`survey_responses`/`problem_reports`/`user_consents`/`student_personalization`, added 2026-07-03), the durable audio/image blob store (S3/R2/local), a deferred pgvector long-term memory stub, and a dev-only per-turn debug dump. Every module here is designed around one invariant: **persistence must never break or slow a live turn** — writes are fire-and-forget, DB-availability-gated, and swallow all errors.

> **Updated 2026-07-03:** this package gained [`pilot.py`](app/storage/pilot.py) (§9A). The offline analytics-tagging tables (`turn_topics`/`turn_mistakes`) and OTA (`firmware_releases`) are written *outside* this package — by `app/workers/topic_tag.py` / `mistake_tag.py` and `app/services/ota_release.py` respectively — so they are noted in the §4 map but not documented as storage modules here.

This is THE reference for what each repository module reads/writes, the exact SQL/ORM it issues, how blobs are stored, and the full data lifecycle.

---

## Table of Contents

1. [Purpose & Responsibility](#1-purpose--responsibility)
2. [Architecture Overview](#2-architecture-overview)
3. [Cross-Cutting Patterns (the "house style")](#3-cross-cutting-patterns-the-house-style)
4. [Module → Table Map](#4-module--table-map)
5. [`turns.py` — sessions + turns writer/reader](#5-turnspy--sessions--turns-writerreader)
6. [`blobs.py` — audio/image object store](#6-blobspy--audioimage-object-store)
7. [`events.py` — lifecycle/audit log](#7-eventspy--lifecycleaudit-log)
8. [`memory_vec.py` — pgvector long-term memory (deferred stub)](#8-memory_vecpy--pgvector-long-term-memory-deferred-stub)
9. [`model_eval.py` — multi-LLM bench persistence](#9-model_evalpy--multi-llm-bench-persistence)
9A. [`pilot.py` — pilot instrumentation (new 2026-07-03)](#9a-pilotpy--pilot-instrumentation-new-2026-07-03)
10. [`user_memory.py` — cross-session learner profile](#10-user_memorypy--cross-session-learner-profile)
11. [`user_profiles.py` — web onboarding profile](#11-user_profilespy--web-onboarding-profile)
12. [`dev_capture.py` — dev-only per-turn debug dump](#12-dev_capturepy--dev-only-per-turn-debug-dump)
13. [`__init__.py` — package contract](#13-__init__py--package-contract)
14. [Configuration, Env Vars & Constants](#14-configuration-env-vars--constants)
15. [Edge Cases, Error Handling, Timeouts & Retries](#15-edge-cases-error-handling-timeouts--retries)
16. [Integration Points (callers & callees)](#16-integration-points-callers--callees)
17. [End-to-End Diagrams](#17-end-to-end-diagrams)

---

## 1. Purpose & Responsibility

The package docstring states it plainly: it is "Off-hot-path persistence: turns table writer, S3/R2 blob uploads, pgvector long-term memory. Everything in here runs via `asyncio.create_task` from the orchestrator's `_persist_turn` — NEVER blocks a response." ([__init__.py:5](app/storage/__init__.py#L5)).

The deliberate boundary with other persistence-ish packages is enumerated in the same docstring ([__init__.py:8-14](app/storage/__init__.py#L8)):

| Package | Role |
| --- | --- |
| `app.db.models` | SQLAlchemy ORM models (the table definitions) |
| `app.services.memory` | Redis short-term history (Layer 3.2) — last 3 turns, ephemeral |
| `app.services.revocation` | Redis pub/sub (Layer 10) — auth-only |
| `app.storage.turns` | Postgres `turns`/`sessions` writer (Layer 9.1) |
| `app.storage.blobs` | S3/R2/local audio + image uploader (Layer 9.2) |
| `app.storage.memory_vec` | pgvector long-term ANN memory (Layer 3.3 — deferred) |

So `app/storage/` is the **repository tier**: it does not define the ORM (that's `app/db/models.py`), it does not own the engine (that's `app/db/session.py`), and it does not implement business logic (that's `app/services/`). It is the thin, crash-safe data-access surface that the services and routes call.

---

## 2. Architecture Overview

```
                         ┌──────────────────────────────────────────────┐
   callers (services,    │              app/storage/  (Layer 9)          │
   routes, workers)      │                                              │
   ───────────────►      │  turns.py        sessions + turns            │──► Postgres
                         │  events.py       events                      │──► Postgres
                         │  user_memory.py  user_memory                 │──► Postgres
                         │  user_profiles.py user_profiles              │──► Postgres
                         │  model_eval.py   model_requests/responses/   │──► Postgres
                         │                  feedback/providers          │
                         │  memory_vec.py   memories  (NotImplemented)  │──► (deferred)
                         │  blobs.py        raw audio/image blobs       │──► S3 / R2 / local FS
                         │  dev_capture.py  debug dump (local FS)       │──► local FS (dev only)
                         └──────────────────────────────────────────────┘
                                  │ obtains AsyncSession via
                                  ▼
                         app/db/session.py  (lazy async engine + factory)
                                  │
                         app/db/models.py   (ORM table defs)
```

Two distinct **session-acquisition styles** coexist (both are part of the design):

1. **Self-opening modules** (`turns.py`, `events.py`, `model_eval.py`) call a private `_session_factory()` that returns the process-wide factory or `None`, then open their own short-lived `async with factory() as db:` block. This lets them be called fire-and-forget from anywhere (including `asyncio.create_task`) without a caller-supplied session. The factory wrapper swallows the "DB not initialised" `RuntimeError` and returns `None` so callers never need a try/except for "DB off" ([turns.py:43-50](app/storage/turns.py#L43), [events.py:20-25](app/storage/events.py#L20), [model_eval.py:27-33](app/storage/model_eval.py#L27)).

2. **Session-injected modules** (`user_memory.py`, `user_profiles.py`) take an `AsyncSession` parameter so they compose inside an existing request/turn transaction (`Depends(get_db)` or a `get_session_factory()` block) ([user_memory.py:5-8](app/storage/user_memory.py#L5), [user_profiles.py:17-18](app/storage/user_profiles.py#L17)).

`blobs.py` and `dev_capture.py` are not DB modules at all — they talk to object storage / the local filesystem.

The underlying engine is **lazy**: `app/db/session.py` keeps `_engine = None` until `init_db()` runs in the FastAPI lifespan, which is what makes "DB off" a first-class, gracefully-degraded state ([session.py:29-30](app/db/session.py#L29), [session.py:55-64](app/db/session.py#L55)). `get_session_factory()` raises `RuntimeError` if the factory isn't built ([session.py:67-70](app/db/session.py#L67)) — and that raise is exactly what `_session_factory()` catches to return `None`.

---

## 3. Cross-Cutting Patterns (the "house style")

Every storage module follows the same contract, restated module-by-module. Documenting it once:

- **DB-availability gate.** `factory = _session_factory(); if factory is None: return` (or `return None`/`return False`/`return EMPTY_HISTORY_TEXT` depending on the function's return type). The DB being off is a no-op, never an error ([turns.py:64-65](app/storage/turns.py#L64), [events.py:35-37](app/storage/events.py#L35), [model_eval.py:61-63](app/storage/model_eval.py#L61)).
- **Crash-safe.** Every write is wrapped in `try/except Exception: log.exception(...)` and swallows the error. The comment in `turns.py` is the canonical statement: "Persistence MUST NEVER break a live turn or tear down the WS." ([turns.py:12-13](app/storage/turns.py#L12)).
- **Fire-and-forget.** Writers return `None`; the orchestrator launches them via `asyncio.create_task`. No caller awaits a commit before responding.
- **UUID PKs, no DB-level FKs.** Joins are by id in code (`turns.session_id → sessions.id`), explicitly noted in the model file ([models.py:430-432](app/db/models.py#L430)).
- **JSONB `extra` escape hatch** on most tables for additive metadata without migrations.
- **Caller-supplied IDs** where an HTTP response must hand the frontend an id before the (fire-and-forget) write lands — `model_eval` generates `request_id`/`response_id` in the route ([model_eval.py:13-15](app/storage/model_eval.py#L13)); `write_turn` accepts a pre-generated `turn_id` so the admin trace row can pre-link to it ([turns.py:233-237](app/storage/turns.py#L233)).

---

## 4. Module → Table Map

| Module | Owns table(s) | ORM model(s) (`app/db/models.py`) | Session style | Status |
| --- | --- | --- | --- | --- |
| `turns.py` | `sessions`, `turns` | `SessionRecord` ([models.py:158](app/db/models.py#L158)), `TurnRecord` ([models.py:191](app/db/models.py#L191)) | self-opening | live |
| `blobs.py` | (object storage, not a table) — populates `turns.image_url`/`audio_url`, `turn_traces.*_url` | — | n/a (S3/FS) | live |
| `events.py` | `events` | `Event` ([models.py:346](app/db/models.py#L346)) | mixed (write self-opens; read takes `db`) | live |
| `memory_vec.py` | `memories` (pgvector) | **not ORM-mapped** ([models.py:558-561](app/db/models.py#L558)) | — | deferred / `NotImplementedError` |
| `model_eval.py` | `model_requests`, `model_responses`, `model_feedback`, `model_providers` | `ModelRequest` ([models.py:461](app/db/models.py#L461)), `ModelResponse` ([models.py:492](app/db/models.py#L492)), `ModelFeedback` ([models.py:528](app/db/models.py#L528)), `ModelProvider` ([models.py:436](app/db/models.py#L436)) | self-opening | live |
| `pilot.py` **(new 2026-07-03)** | `turn_feedback`, `survey_responses`, `problem_reports`, `user_consents`, `student_personalization` | `TurnFeedback` ([models.py:608](app/db/models.py#L608)), `SurveyResponse` ([models.py:654](app/db/models.py#L654)), `ProblemReport` ([models.py:679](app/db/models.py#L679)), `UserConsent` ([models.py:707](app/db/models.py#L707)), `StudentPersonalization` ([models.py:729](app/db/models.py#L729)) | self-opening | live |
| `user_memory.py` | `user_memory` | `UserMemory` ([models.py:327](app/db/models.py#L327)) | injected `AsyncSession` | live |
| `user_profiles.py` | `user_profiles` | `UserProfile` ([models.py:109](app/db/models.py#L109)) | injected `AsyncSession` | live |
| `dev_capture.py` | (local FS only, dev debug) | — | n/a (FS) | live (off by default) |

Related tables written elsewhere (not by `app/storage/`): `turn_traces` is written by `app/services/turn_trace.py` (it calls into `blobs.py` for media URLs); `devices`/`pairing_codes`/`admins`/`cost_log` are touched by routes/services outside this package; the offline analytics-tagging tables `turn_topics`/`turn_mistakes` are written by the batch workers `app/workers/topic_tag.py` / `mistake_tag.py` (`syllabus_topics` is seeded reference data); and the OTA `firmware_releases` image store is written by `app/services/ota_release.py`.

---

## 5. `turns.py` — sessions + turns writer/reader

**File:** [app/storage/turns.py](app/storage/turns.py) (the largest module). Owns `sessions` and `turns`. This is "the save the conversation against the paired user path" ([turns.py:1-3](app/storage/turns.py#L1)). Every row is tagged with `user_id` (the Clerk ID from the lamp's device_jwt) + `device_id` so a learner's whole history lives under their account ([turns.py:4-7](app/storage/turns.py#L4)).

### 5.1 Module constants

| Constant | Value | Meaning | Cite |
| --- | --- | --- | --- |
| `EMPTY_HISTORY_TEXT` | `"[Session start — no prior turns]"` | placeholder returned when no history / DB off | [turns.py:29](app/storage/turns.py#L29) |
| `_SESSION_IDLE_MIN` | `30` | idle window (minutes): a reconnect within this gap CONTINUES a session rather than starting a new row | [turns.py:34](app/storage/turns.py#L34) |
| `_SID_CACHE_KEY` | `"lamp:sid:"` | Redis key prefix for the active-session-id cache | [turns.py:39](app/storage/turns.py#L39) |
| `_SID_CACHE_TTL_S` | `(30 + 5) * 60 = 2100` s | cache TTL, deliberately 5 min longer than the idle window so a reconnecting lamp hits the cache instead of the resume query | [turns.py:40](app/storage/turns.py#L40) |

### 5.2 `_session_factory()` — [turns.py:43](app/storage/turns.py#L43)

Imports `get_session_factory` lazily and returns it, or `None` on any exception. This is the DB-off gate used by all three functions in the file.

### 5.3 `open_session(device_id, user_id) -> str | None` — [turns.py:53](app/storage/turns.py#L53)

Returns the session UUID (as a string) the WS connection should write turns to. **Resume-or-open** logic:

**Step 0 — DB gate.** `if factory is None: return None`. When DB is off, turns persist with `session_id=NULL` but still carry `user_id` ([turns.py:62-65](app/storage/turns.py#L62)).

**Step 1 — Fast path (Redis cache).** Reads `cget("lamp:sid:<device_id>")` ([turns.py:76](app/storage/turns.py#L76)). On a hit it loads `SessionRecord` by UUID and resumes only if BOTH:
- `same_user` — `row.user_id == user_id` OR both are `None` ([turns.py:81-83](app/storage/turns.py#L81)); and
- `fresh` — `row.last_activity_at` is set and `(now - last_activity_at).total_seconds() < _SESSION_IDLE_MIN * 60` (i.e. < 1800 s) ([turns.py:84-87](app/storage/turns.py#L84)).

On resume it clears `ended_at` (the session is live again), bumps `last_activity_at = now`, commits, re-sets the cache, and returns the cached id ([turns.py:88-94](app/storage/turns.py#L88)). A stale/bad cache entry falls through to the DB path ([turns.py:95-98](app/storage/turns.py#L95)). **Today there is no Redis** ([cache.py:4](app/services/cache.py#L4)), so `cget` always returns `None` and this whole block is skipped — the Postgres path runs exactly as before ([turns.py:73-75](app/storage/turns.py#L73)).

**Step 2 — Source of truth (Postgres resume).** Raw SQL ([turns.py:103-112](app/storage/turns.py#L103)):

```sql
SELECT id FROM sessions
WHERE device_id = :d
  AND user_id IS NOT DISTINCT FROM :u          -- NULL matches NULL (dev mode)
  AND last_activity_at > now() - make_interval(mins => :m)   -- :m = 30
ORDER BY last_activity_at DESC LIMIT 1
```

`IS NOT DISTINCT FROM` is the key safety/correctness detail: a NULL `user_id` (dev) matches NULL too, and a device re-paired to a *different* user won't resume → a fresh session opens, so history never bleeds across users ([turns.py:106](app/storage/turns.py#L106), [turns.py:58-60](app/storage/turns.py#L58)).

**Step 3a — Resume found.** Load the `SessionRecord`, set `ended_at = None`, `last_activity_at = now`, commit, cache the id, log `[SESSION] resumed`, return the id string ([turns.py:114-123](app/storage/turns.py#L114)).

**Step 3b — None found → open new.** `new_sid = uuid4()`, `db.add(SessionRecord(id=new_sid, device_id=device_id, user_id=user_id))`, commit, cache, log `[SESSION] opened`, return ([turns.py:125-131](app/storage/turns.py#L125)).

**Error path.** Any exception (e.g. `last_activity_at` column missing on an un-migrated DB) is logged and the function degrades to `return None` — no session row, but turns still tagged with `user_id` ([turns.py:132-136](app/storage/turns.py#L132)).

### 5.4 `close_session(session_id) -> None` — [turns.py:139](app/storage/turns.py#L139)

No-op when DB off or `session_id` missing. Loads `SessionRecord` by UUID, sets `ended_at = datetime.now(timezone.utc)`, commits ([turns.py:144-152](app/storage/turns.py#L144)). Errors logged + swallowed.

### 5.5 `_decay_resistance(query_type, difficulty) -> float` — [turns.py:157](app/storage/turns.py#L157)

A pure scoring function (no I/O) that maps the model's classification to a 0–1 "decay-resistance" stored on each turn — how strongly a memory resists being forgotten by the (future) memory layer. **Exact math:**

```
base = {
  "derivation": 0.90, "formula": 0.85, "calc": 0.75, "definition": 0.70,
  "concept": 0.65, "mistake_id": 0.60, "check": 0.20, "other": 0.20,
}.get(query_type or "other", 0.40)          # unknown type → 0.40
mod  = {"hard": 0.10, "medium": 0.0, "easy": -0.15}.get(difficulty or "medium", 0.0)
return max(0.0, min(1.0, base + mod))         # clamp to [0, 1]
```

So a `hard` `derivation` → `min(1.0, 1.00) = 1.00`; an `easy` `check` → `max(0.0, 0.05) = 0.05` ([turns.py:158-163](app/storage/turns.py#L158)). The value is written to `turns.decay_resistance` (`Numeric(3,2)`).

### 5.6 `write_turn(...)` — [turns.py:166](app/storage/turns.py#L166)

Inserts ONE `turns` row and atomically bumps the session's turn count. Keyword-only signature ([turns.py:166-178](app/storage/turns.py#L166)): `device_id`, `user_id`, `session_id`, `reply` (an `LlmReply`, typed `Any` to avoid a circular import), `telemetry: dict`, `total_ms: int`, `image_url`, `audio_url`, `extra: dict | None`, `turn_id: str | None`.

**Step 0 — skip non-ok turns.** `if telemetry.get("status") not in (None, "ok"): return` — an error fallback must not pollute the learner's history ([turns.py:188-189](app/storage/turns.py#L188), docstring [turns.py:186-187](app/storage/turns.py#L186)). Then the DB gate.

**Step 1 — atomic turn_index bump.** If a `session_id` is supplied, parse it to UUID and run a single atomic statement that increments the counter and returns the new value ([turns.py:208-223](app/storage/turns.py#L208)):

```sql
UPDATE sessions SET
  turn_count       = turn_count + 1,
  last_activity_at = now(),
  primary_subject  = COALESCE(:subj, primary_subject),
  avg_difficulty   = COALESCE(:diff, avg_difficulty)
WHERE id = :sid
RETURNING turn_count
```

Doing the read+increment in one `UPDATE … RETURNING` (rather than read-then-write) is what prevents two concurrent fire-and-forget writers (e.g. rapid web `/simulate` calls) from producing a duplicate `turn_index` / lost update — Postgres row-locks the session row for the duration ([turns.py:198-202](app/storage/turns.py#L198)). `COALESCE` means `primary_subject`/`avg_difficulty` are only set when the reply carries them, never clobbered to NULL ([turns.py:213-214](app/storage/turns.py#L213)).

- If `RETURNING` yields a count → `turn_index = int(new_count)` ([turns.py:224-225](app/storage/turns.py#L224)).
- If it yields `None`, the session row vanished (wiped) → set `sess_uuid = None` and still write the turn detached, rather than lose it ([turns.py:226-229](app/storage/turns.py#L226)).
- Any exception during the bump → `sess_uuid = None` (turn written without a session link) ([turns.py:230-231](app/storage/turns.py#L230)).
- If no `session_id` was supplied, `turn_index` stays at its default of `1` ([turns.py:203](app/storage/turns.py#L203)).

**Step 2 — row id.** Use the caller-supplied `turn_id` (parse to UUID) or generate fresh; any parse failure falls back to a fresh `uuid4()` ([turns.py:234-237](app/storage/turns.py#L234)).

**Step 3 — build the `TurnRecord`.** Field-by-field mapping ([turns.py:238-271](app/storage/turns.py#L238)):

| Column | Source | Note |
| --- | --- | --- |
| `id` | `row_id` | caller-supplied or fresh |
| `device_id`, `user_id`, `session_id` | args | join keys; `session_id` may be `None` |
| `turn_index` | atomic bump | running count within the session |
| `image_url`, `audio_url` | args | blob URLs from `blobs.py` (first image only for back-compat; full list lives in `extra.image_urls`) |
| `transcript` | `reply.user_input or None` | the model's short restatement of the question — durable side of L1 memory ([turns.py:246-248](app/storage/turns.py#L246)) |
| `speech` | `reply.speech or ""` | the spoken answer |
| `display_kind` | `reply.display.kind` | |
| `display_content` | `reply.display.content or None` | |
| `latex_equations` | `list(reply.latex_equations or [])` | JSONB array |
| `confidence` | `reply.confidence` | `Numeric(3,2)` |
| `query_type`, `subject`, `difficulty` | from `reply` | classification |
| `decay_resistance` | `_decay_resistance(reply.query_type, reply.difficulty)` | computed (§5.5) |
| `llm_provider`, `llm_model` | `telemetry` | |
| `llm_input_tok`, `llm_output_tok`, `llm_thinking_tok` | `telemetry` | token counts |
| `ttft_ms` | `telemetry` | time-to-first-token |
| `total_ms` | arg | end-to-end |
| `cost_usd` | `telemetry` | `Numeric(10,6)` |
| `status` | `telemetry.get("status") or "ok"` | |
| `escalated` | `bool(telemetry.get("escalated"))` | |
| `final_tier` | `int(telemetry.get("final_tier") or 1)` | which tier shipped the answer |
| `escalation_path` | `list(telemetry.get("escalation_path") or [])` | Postgres `text[]` |
| `extra` | `extra or {}` | JSONB; e.g. `{"source": "simulation"}` distinguishes web-bench turns ([turns.py:181-184](app/storage/turns.py#L181)) |

Commit, log `[TURN] persisted`. All errors logged + swallowed ([turns.py:272-276](app/storage/turns.py#L272)).

### 5.7 `load_recent_turns(device_id, user_id, session_id, *, limit=3) -> str` — [turns.py:279](app/storage/turns.py#L279)

Builds the **LLM history block directly from Postgres `turns`** (no Redis) — this is what makes the conversation stateful: the last `limit` successful turns, oldest-first, prepended to the next LLM call ([turns.py:286-294](app/storage/turns.py#L286)).

**Query** (`select(TurnRecord)` builder, [turns.py:302-311](app/storage/turns.py#L302)):

```
WHERE status == "ok"
  AND (session_id == <uuid>                       if session_id given
       ELSE device_id == <device_id>
            AND user_id == <user_id>  (or user_id IS NULL when None))
ORDER BY asked_at DESC
LIMIT <limit>
```

Scoping rule: when a session row exists it scopes by `session_id` (the live conversation); otherwise it falls back to this device's turns **filtered by `user_id`** — so a lamp re-paired to a different user never sees the prior user's turns; cross-user safety holds without any Redis clear ([turns.py:288-294](app/storage/turns.py#L288), [turns.py:303-310](app/storage/turns.py#L303)).

**Post-processing** ([turns.py:313-324](app/storage/turns.py#L313)): if no rows → `EMPTY_HISTORY_TEXT`. Else `reversed()` for oldest-first reading order, then format each row:
- `speech` truncated to **500 chars**, `asked` (the `transcript`) truncated to **200 chars**.
- If `asked` present: `"{i}. Student asked: {asked} — You answered: {speech}"`.
- Else: `"{i}. (display={display_kind or 'none'}) {speech}"`.

Returns `"\n".join(lines)`. On any exception → `EMPTY_HISTORY_TEXT` ([turns.py:325-327](app/storage/turns.py#L325)).

---

## 6. `blobs.py` — audio/image object store

**File:** [app/storage/blobs.py](app/storage/blobs.py). Stores per-turn raw audio (16 kHz mono int16 → WAV) and image (JPEG) so `turns.audio_url` / `turns.image_url` become real, for offline analytics, `workers/transcribe.py`, and audit/debugging ([blobs.py:3-6](app/storage/blobs.py#L3)).

### 6.1 Backend selection

Chosen by `settings.STORAGE_BACKEND` (mirrors the LLM_PROVIDER pattern) ([blobs.py:8-13](app/storage/blobs.py#L8)):

| Value | Behaviour |
| --- | --- |
| `off` | no-op, return `None` (URLs stay NULL) |
| `local` | write to `./{STORAGE_LOCAL_DIR}/turn-{uuid}.{wav,jpg}` (dev default) |
| `s3` / `r2` | S3-compatible object store (AWS S3 / Cloudflare R2 / Supabase Storage / MinIO) via `aioboto3` |

`aioboto3` is **optional**, resolved lazily; a module-global `_s3_unavailable_warned` flag warns once (not per-turn) if it's missing or `S3_BUCKET` unset ([blobs.py:30-32](app/storage/blobs.py#L30), [blobs.py:219-230](app/storage/blobs.py#L219)).

### 6.2 `_wav_bytes(pcm_bytes, sample_rate=16_000) -> bytes` — [blobs.py:35](app/storage/blobs.py#L35)

Wraps raw int16 LE mono PCM in a WAV container so the file is playable and Whisper-readable. Uses the stdlib `wave` module into a `BytesIO`: `setnchannels(1)`, `setsampwidth(2)` (16-bit), `setframerate(16000)`, `writeframes(pcm_bytes)` ([blobs.py:39-44](app/storage/blobs.py#L39)).

### 6.3 Upload entry points

- **`upload_image(jpeg_bytes, turn_id)`** — [blobs.py:47](app/storage/blobs.py#L47). Persists the lamp's JPEG as-is. Returns `None` for empty bytes; else `_put(f"turn-{turn_id}.jpg", jpeg_bytes, "image/jpeg")`.
- **`upload_audio(pcm_bytes, turn_id)`** — [blobs.py:54](app/storage/blobs.py#L54). Wraps raw int16 LE 16 kHz mono PCM as WAV (`_wav_bytes`) then `_put(f"turn-{turn_id}.wav", data, "audio/wav")`. A WAV-wrap failure is logged and returns `None` ([blobs.py:58-63](app/storage/blobs.py#L58)).
- **`upload_audio_wav(wav_bytes, turn_id)`** — [blobs.py:66](app/storage/blobs.py#L66). Persists an **already-containerised** WAV as-is. This exists because the web simulator uploads a complete WAV; re-wrapping it via `upload_audio` would corrupt it ([blobs.py:67-69](app/storage/blobs.py#L67)). Used by the trace path ([turn_trace.py:265](app/services/turn_trace.py#L265)).

The blob key naming is always a **flat filename**: `turn-<id>.{wav,jpg}` for live turns and `trace-<id>...` for trace media (set by `turn_trace.py`).

### 6.4 Backend dispatch — `_put(key, data, content_type)` — [blobs.py:185](app/storage/blobs.py#L185)

Lowercases `STORAGE_BACKEND` (default `"off"`) and routes: `off → None`; `local → _put_local`; `s3`/`r2 → _put_s3`; unknown → warn + `None`. A wrapping `try/except` guarantees a storage hiccup never propagates into the turn ([blobs.py:186-199](app/storage/blobs.py#L186)).

**`_put_local(key, data)`** — [blobs.py:202](app/storage/blobs.py#L202). Runs the blocking write in `asyncio.to_thread`. Creates `STORAGE_LOCAL_DIR` (`mkdir(parents=True, exist_ok=True)`), writes bytes, and returns:
- `f"{STORAGE_PUBLIC_BASE_URL.rstrip('/')}/{key}"` if a public base URL is set, else
- `path.resolve().as_uri()` — a `file://` URL (durable but not web-served) ([blobs.py:205-214](app/storage/blobs.py#L205)).

**`_put_s3(key, data, content_type)`** — [blobs.py:217](app/storage/blobs.py#L217). Requires `S3_BUCKET` (warns once + `None` otherwise) and `aioboto3` (warns once + `None`). Builds an `aioboto3.Session().client("s3", ...)` from `S3_ACCESS_KEY`/`S3_SECRET_KEY`/`S3_REGION` and optional `S3_ENDPOINT_URL` (only non-None kwargs passed). Calls `put_object(Bucket, Key, Body, ContentType)`. URL resolution order ([blobs.py:243-247](app/storage/blobs.py#L243)):
1. `STORAGE_PUBLIC_BASE_URL` prefix + key, else
2. `S3_ENDPOINT_URL/<bucket>/<key>`, else
3. `s3://<bucket>/<key>`.

### 6.5 Key recovery & deletion (manual admin cleanup)

**`key_from_url(url)`** — [blobs.py:75](app/storage/blobs.py#L75). Recovers the bare key from any URL form this module ever produced (`file://`, public-base-prefixed, S3-endpoint, or `s3://`). Strips query string, normalizes backslashes, takes the last path segment, and **only returns it if it starts with `turn-` or `trace-`** — a safety guard so the cleanup path can never delete arbitrary names ([blobs.py:83-87](app/storage/blobs.py#L83)).

**`delete_keys(keys) -> int`** — [blobs.py:90](app/storage/blobs.py#L90). The **manual** admin-cleanup path — "there is deliberately NO automatic deletion anywhere in this codebase" ([blobs.py:91-93](app/storage/blobs.py#L91)). De-dupes (`dict.fromkeys`) + drops empties, returns 0 if none. Routes by backend: `local → _delete_local`, `s3`/`r2 → _delete_s3`, `off → len(keys)` (report all as processed so the caller still nulls the dead URL columns) ([blobs.py:97-111](app/storage/blobs.py#L97)). Missing objects count as deleted (S3 semantics).

- **`_delete_local(keys)`** — [blobs.py:114](app/storage/blobs.py#L114). In a thread: for each key, build `base / k`, **guard against path escape** (`p.parent.resolve() == base.resolve()` — keys are flat filenames only), `p.unlink(missing_ok=True)`, count it done (missing == already gone) ([blobs.py:117-131](app/storage/blobs.py#L117)).
- **`_delete_s3(keys)`** — [blobs.py:134](app/storage/blobs.py#L134). **Per-object `DeleteObject` with bounded concurrency (`Semaphore(16)`)** — deliberately NOT the batch `DeleteObjects` API, because Supabase Storage's S3 layer rejects it (verified 2026-06-12: `InvalidRequest: must have required property 'Body'`), and per-object deletes are universally supported (AWS/R2/MinIO) ([blobs.py:135-140](app/storage/blobs.py#L135)). Each `_rm` treats `NoSuchKey`/`404` as success; other errors leave the key for a retry on the next manual run ([blobs.py:170-178](app/storage/blobs.py#L170)). Returns the count of successes.

The single caller is `app/services/media_cleanup.py`, which deletes storage FIRST then nulls the DB columns, so a storage failure is retryable and never leaves dangling DB pointers ([media_cleanup.py:124-128](app/services/media_cleanup.py#L124)).

---

## 7. `events.py` — lifecycle/audit log

**File:** [app/storage/events.py](app/storage/events.py). CRUD for the `events` table — the generic lifecycle/audit log. Suggested kinds: `'paired' | 'unlinked' | 'ws_open' | 'ws_close' | 'reboot' | 'cancel' | 'button'`; new kinds need no migration, just a new string + structured `payload` ([events.py:1-10](app/storage/events.py#L1)).

- **`_session_factory()`** — [events.py:20](app/storage/events.py#L20). Same DB-off gate as `turns.py`.
- **`log_event(device_id, user_id, kind, payload=None)`** — [events.py:28](app/storage/events.py#L28). Opens its own short-lived session, inserts one `Event(id=uuid4(), device_id, user_id, kind, payload=payload or {})`, commits ([events.py:40-48](app/storage/events.py#L40)). No-op without DB; fire-and-forget; all errors logged + swallowed ([events.py:49-50](app/storage/events.py#L49)).
- **`recent_events(db, device_id, *, limit=50) -> list`** — [events.py:53](app/storage/events.py#L53). The **read** path; the caller owns the `db` session. `select(Event).where(Event.device_id == device_id).order_by(Event.occurred_at.desc()).limit(limit)`, newest-first ([events.py:57-63](app/storage/events.py#L57)).

The `Event` model stores `payload` as JSONB and is indexed on `(device_id, occurred_at)` and `(kind, occurred_at)` ([models.py:360-363](app/db/models.py#L360)).

---

## 8. `memory_vec.py` — pgvector long-term memory (deferred stub)

**File:** [app/storage/memory_vec.py](app/storage/memory_vec.py). The intended Layer 3.3 per-user vector store: after each turn, embed `(question, answer)` with a small embedding model; before each turn, do top-3 ANN lookup on the user's vectors and inject results as "Things you've discussed before" into the system prompt ([memory_vec.py:3-8](app/storage/memory_vec.py#L3)).

It documents the intended schema in the docstring ([memory_vec.py:15-26](app/storage/memory_vec.py#L15)):

```sql
CREATE EXTENSION IF NOT EXISTS vector;
CREATE TABLE memories (
  id          uuid PRIMARY KEY,
  user_id     text NOT NULL,
  kind        text,
  content     text NOT NULL,
  embedding   vector(1536),    -- text-embedding-3-small (or bge-small)
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX memories_user_idx ON memories(user_id);
CREATE INDEX memories_embedding_idx ON memories USING ivfflat (embedding vector_cosine_ops);
```

Both functions currently **raise `NotImplementedError`** ([memory_vec.py:44-56](app/storage/memory_vec.py#L44)):
- `insert_memory(*, user_id, content)` — "Embed `content` and upsert into the user's memory."
- `fetch_relevant(*, user_id, query, k=3) -> list[str]` — "Top-k ANN lookup."

The deferral is intentional per `BACKEND_TODO.md §3.3` ("skip entirely for now") ([memory_vec.py:28-39](app/storage/memory_vec.py#L28)), and the model file confirms the `memories` table is **not ORM-mapped** because the `embedding vector(1536)` column needs the `pgvector` package; when shipped it will be accessed via raw SQL (`ORDER BY embedding <=> $1::vector`) ([models.py:558-561](app/db/models.py#L558)). The two living memory layers today are `services/memory.py` (Redis, last 3 turns) and `storage/turns.py` (Postgres, all turns) ([memory_vec.py:10-13](app/storage/memory_vec.py#L10)).

---

## 9. `model_eval.py` — multi-LLM bench persistence

**File:** [app/storage/model_eval.py](app/storage/model_eval.py). Writes every model invocation to the dedicated `model_requests` / `model_responses` / `model_feedback` tables (distinct from the lamp's `turns` history) and seeds the `model_providers` registry from the in-code catalog ([model_eval.py:1-6](app/storage/model_eval.py#L1)). IDs are generated by the CALLER (the `/solve` endpoint) and passed in, so the HTTP response can hand the frontend a `response_id` to attach feedback to without waiting on the fire-and-forget DB write ([model_eval.py:13-15](app/storage/model_eval.py#L13)).

- **`_session_factory()`** — [model_eval.py:27](app/storage/model_eval.py#L27). DB-off gate.
- **`_as_uuid(val)`** — [model_eval.py:36](app/storage/model_eval.py#L36). Coerce str/UUID/None → UUID or None, never raises (used so caller-supplied id strings parse safely) ([model_eval.py:36-44](app/storage/model_eval.py#L36)).

### 9.1 `record_request(...)` — [model_eval.py:47](app/storage/model_eval.py#L47)

Inserts one `model_requests` row (one per bench submit, single OR a compare group). Notable field transforms ([model_eval.py:67-79](app/storage/model_eval.py#L67)):
- `request_id = _as_uuid(request_id) or uuid4()`,
- `selected_model = selected_model[:500]` (truncated; a compare group is a comma-joined list),
- `image_reference = f"{image_count} image(s)"` when `image_count` else `None` (a lightweight reference, not the bytes),
- `image_count = int(image_count or 0)`, `had_audio = bool(had_audio)`, `channel` (default `"web"`), `extra or {}`.

Fire-and-forget; all errors logged + swallowed.

### 9.2 `record_response(...)` — [model_eval.py:85](app/storage/model_eval.py#L85)

Inserts one `model_responses` row per model that answered. **Failures/timeouts are KEPT** because they're the failure-rate metric ([model_eval.py:102-103](app/storage/model_eval.py#L102), and `success_status=False` rows kept per model docstring [models.py:494-495](app/db/models.py#L494)). Transforms ([model_eval.py:110-126](app/storage/model_eval.py#L110)):
- `response_id = _as_uuid(...) or uuid4()`, `request_id = _as_uuid(request_id)`,
- `generated_answer = (generated_answer or "")[:8000]` (truncated to 8000 chars),
- latency/token/cost columns passed through,
- `success_status = (status == "ok")` — the boolean derived from the finer-grained `status` string (`"ok"|"not_configured"|"timeout"|"error"`),
- `status = status or "ok"`, `error_message = error_message or None`, `extra or {}`.

### 9.3 `record_feedback(...) -> bool` — [model_eval.py:132](app/storage/model_eval.py#L132)

**UPSERT** one `model_feedback` row keyed on `(response_id, user_id)`. Returns `True` if persisted, `False` if DB off / write failed / invalid target ([model_eval.py:138-148](app/storage/model_eval.py#L138)).

**Validation/clamping** (the route also validates) ([model_eval.py:149-152](app/storage/model_eval.py#L149)):
- `rid = _as_uuid(response_id)`; `None` → return `False`.
- `thumb = thumbs if thumbs in ("up","down") else None`,
- `rating = int(user_rating)` only if it's an int in `1..5`, else `None`,
- `text_val = (feedback_text or "").strip()[:2000] or None` (clamped to 2000 chars).

**Existence check.** `SELECT response_id FROM model_responses WHERE response_id == rid`; if absent, log + return `False` — don't accumulate orphan feedback ([model_eval.py:157-162](app/storage/model_eval.py#L157)).

**Upsert.** `SELECT ModelFeedback WHERE response_id == rid AND (user_id IS NULL when None else user_id == user_id)`. If no row → `db.add(ModelFeedback(id=uuid4(), response_id=rid, user_id, user_rating=rating, thumbs=thumb, feedback_text=text_val))`. If a row exists → **merge: only overwrite the fields the user actually provided this time** (each guarded `if … is not None`), set `updated_at = now` ([model_eval.py:164-184](app/storage/model_eval.py#L164)). Commit, return `True`. The uniqueness is backed by the unique index `model_feedback_resp_user_idx` on `(response_id, user_id)` ([models.py:553-554](app/db/models.py#L553)).

### 9.4 `seed_providers()` — [model_eval.py:191](app/storage/model_eval.py#L191)

Upserts the in-code model catalog into `model_providers` so the registry is queryable in SQL. Best-effort, called once at startup after `init_db` ([model_eval.py:192-194](app/storage/model_eval.py#L192)).

**Algorithm** ([model_eval.py:203-226](app/storage/model_eval.py#L203)):
1. Load all existing `ModelProvider` rows into a dict keyed by `model_name`.
2. For each `spec` in `model_catalog.list_models()`: compute `active = model_catalog.is_available(spec)` (whether that provider's API key is configured on this deployment).
3. If no existing row → INSERT a new `ModelProvider(id=uuid4(), model_name=spec.id, provider_name=spec.provider, label=spec.label, version=spec.vendor_model, active_status=active, input_per_mtok=spec.input_per_mtok, output_per_mtok=spec.output_per_mtok)`.
4. Else UPDATE the existing row's `provider_name`, `label`, `version`, `active_status`, pricing, and `updated_at = now`.
5. Commit; log the count.

The `ModelSpec` fields it reads are defined in `app/services/model_catalog.py` (`id`, `provider`, `label`, `vendor_model`, `input_per_mtok`, `output_per_mtok`) ([model_catalog.py:35-42](app/services/model_catalog.py#L35)).

---

## 9A. `pilot.py` — pilot instrumentation (new 2026-07-03)

**File:** [app/storage/pilot.py](app/storage/pilot.py). The persistence for the low-risk "Green" pilot features — `turn_feedback` (F1), `survey_responses` (F2), `problem_reports` (F5), `user_consents` (F7), and the `student_personalization` profile. It is a **self-opening** module modeled exactly on `model_eval.py`: DB-availability-gated (`_session_factory()` returns `None` → every function no-ops with `False`/`{}`/`None`), crash-safe (every error logged + swallowed), and deliberately **off the live turn path** — "the worst case is a dropped feedback row" ([pilot.py:1-13](app/storage/pilot.py#L1)). Helpers `_session_factory()` and `_as_uuid()` mirror the bench module.

Functions:

- **`record_turn_feedback(*, turn_id, user_id, device_id=None, thumbs=None, reason=None, resolution=None, user_rating=None, feedback_text=None) -> bool`** — [pilot.py:45](app/storage/pilot.py#L45). UPSERT one `turn_feedback` row keyed on `(turn_id, user_id)`. **Validates the target `turns` row exists** first (`SELECT turns.id WHERE id == tid`) so feedback can't reference a stray id ([pilot.py:79-83](app/storage/pilot.py#L79)); defensively normalizes/clamps `thumbs`/`reason`(≤60)/`resolution`/`rating`(1–5)/`text`(≤2000); on an existing row **merges only the fields actually provided this time** ([pilot.py:98-111](app/storage/pilot.py#L98)).
- **`feedback_for_turns(user_id, turn_ids) -> dict[str, dict]`** — [pilot.py:119](app/storage/pilot.py#L119). Batch read of this user's existing feedback for a set of turn ids so the analytics feed can pre-fill the widget. `{}` on any error / DB off.
- **`submit_survey(*, user_id, survey_kind, version, answers) -> bool`** — [pilot.py:153](app/storage/pilot.py#L153). Append-only INSERT into `survey_responses`; rejects a `survey_kind` outside `('baseline','exit','weekly')`.
- **`survey_status(user_id) -> dict[str, str|None]`** — [pilot.py:180](app/storage/pilot.py#L180). `{survey_kind: latest_submitted_at_iso | None}` (grouped `MAX(submitted_at)`) so the UI can gate re-submission of baseline/exit.
- **`record_problem_report(*, user_id, device_id, turn_id, category, message, context=None) -> bool`** — [pilot.py:206](app/storage/pilot.py#L206). INSERT one `problem_reports` row (message clamped ≤4000).
- **`upsert_personalization(*, user_id, interests, answer_length, example_pref, notes) -> bool`** — [pilot.py:237](app/storage/pilot.py#L237). Read-modify-write partial save keyed on `user_id`; validates `answer_length ∈ (short,balanced,detailed)` / `example_pref ∈ (love,sometimes,rarely)`, clamps interests (≤20 items, ≤60 chars each).
- **`get_personalization(user_id) -> dict | None`** — [pilot.py:282](app/storage/pilot.py#L282). Read the student's row (COLLECTION-ONLY data; not yet injected into any prompt).
- **`record_consent(*, user_id, consent_type, version, granted, source=None, extra=None) -> bool`** — [pilot.py:307](app/storage/pilot.py#L307). Append one immutable `user_consents` audit row.

Callers are the pilot routes `app/routes/pilot.py` (+ `admin_pilot.py` for the admin triage/insights surfaces); nothing here is awaited on the lamp's question→answer path.

---

## 10. `user_memory.py` — cross-session learner profile

**File:** [app/storage/user_memory.py](app/storage/user_memory.py). CRUD for `user_memory` — the cross-session learner profile (one row per **device**), refreshed at session end by the memory service; read into the LLM context as the L3 block ([user_memory.py:1-8](app/storage/user_memory.py#L1)). Unlike the self-opening modules, **the caller passes an `AsyncSession`** so these compose inside an existing transaction.

- **`get_user_memory(db, device_id) -> UserMemory | None`** — [user_memory.py:24](app/storage/user_memory.py#L24). `select(UserMemory).where(UserMemory.device_id == device_id)` → `scalar_one_or_none()`.
- **`upsert_user_memory(db, *, device_id, user_id, long_term_summary=None, subject_profile=None, session_count=None, total_turns=None) -> UserMemory`** — [user_memory.py:30](app/storage/user_memory.py#L30). Read-modify-write **partial update**: fetch the row (insert a fresh `UserMemory(id=uuid4(), device_id, user_id)` if absent), then overwrite **only the non-None** fields passed in ([user_memory.py:42-55](app/storage/user_memory.py#L42)), set `updated_at = now`, commit, log `[USER_MEMORY] upserted`, return the row. `device_id` is the unique key on the model ([models.py:336](app/db/models.py#L336)).

This module is `UserMemory` (DERIVED from turns: subjects/difficulty mix) — distinct from `user_profiles` (self-declared onboarding) ([models.py:328-331](app/db/models.py#L328)). Sole caller: `app/services/session_memory.py` at session finalize ([session_memory.py:405](app/services/session_memory.py#L405), [session_memory.py:467](app/services/session_memory.py#L467)).

---

## 11. `user_profiles.py` — web onboarding profile

**File:** [app/storage/user_profiles.py](app/storage/user_profiles.py). Async CRUD for `user_profiles` — the web onboarding profile, keyed by Clerk `user_id`, used by the Frontend Manager router. Postgres-backed so the profile the learner enters on the web is durable + analytics-readable, not just in Clerk `publicMetadata` ([user_profiles.py:1-8](app/storage/user_profiles.py#L1)). Also takes an injected `AsyncSession`.

- **`get_profile(db, user_id) -> UserProfile | None`** — [user_profiles.py:23](app/storage/user_profiles.py#L23). `db.get(UserProfile, user_id)` (PK lookup).
- **`upsert_profile(db, *, user_id, full_name, phone, target_exam, prep_duration, onboarding_complete=True, extra=None) -> UserProfile`** — [user_profiles.py:28](app/storage/user_profiles.py#L28).

This is the **race-safe** writer: it uses a single atomic PostgreSQL `INSERT ... ON CONFLICT (user_id) DO UPDATE` rather than `get()`-then-`add()`, so two concurrent submits for the same user (double-click, or onboarding racing a background refresh) can never both INSERT and collide on the primary key ([user_profiles.py:40-52](app/storage/user_profiles.py#L40)).

**Mechanics** ([user_profiles.py:53-91](app/storage/user_profiles.py#L53)):
1. `delta = {k: v for k, v in (extra or {}).items() if v is not None}` — drop None values so a missing field never clobbers a stored one.
2. Build `values` with normalized strings: `full_name.strip()`, `phone.strip() or None`, `prep_duration.strip() or None`, `target_exam` passthrough, `onboarding_complete`, `extra = delta`, `updated_at = now`.
3. `pg_insert(UserProfile).values(**values)` (Postgres dialect insert).
4. `.on_conflict_do_update(index_elements=[UserProfile.user_id], set_={...})` where the `set_` overwrites scalar columns from `stmt.excluded.*`, **JSONB-merges `extra`** via `UserProfile.extra.op("||")(stmt.excluded.extra)` (existing keys preserved, new non-null keys overlaid), and bumps `updated_at`. `created_at` is NOT in `set_`, so it's preserved on conflict and only set on the initial insert ([user_profiles.py:67-79](app/storage/user_profiles.py#L67)).
5. Execute + commit, then **re-SELECT** the committed row with `.execution_options(populate_existing=True)` (avoids a stale identity-map hit) so callers get the merged DB-truth state to serialize back ([user_profiles.py:84-91](app/storage/user_profiles.py#L84)). Logs `[PROFILE] upserted`.

The `target_exam` is constrained at the DB level to `'JEE'|'NEET'|'CAT'|'UPSC'` or NULL ([models.py:146-149](app/db/models.py#L146)). Caller: `app/routes/frontend_manager.py` `PUT /api/frontend/profile` ([frontend_manager.py:147](app/routes/frontend_manager.py#L147)).

---

## 12. `dev_capture.py` — dev-only per-turn debug dump

**File:** [app/storage/dev_capture.py](app/storage/dev_capture.py). A **dev-only** per-turn capture dump gated by `settings.DEV_CAPTURE_DUMP`. When enabled, every turn writes one self-contained folder under `DEV_CAPTURE_DIR`, named `<YYYYmmdd_HHMMSS_mmm>_<device>/`, containing the complete record of what the camera pipeline did and what the model saw ([dev_capture.py:1-16](app/storage/dev_capture.py#L1)):

```
<DEV_CAPTURE_DIR>/<ts>_<device>/
    audio.wav                  exact mic PCM this turn was built from
    raw_<i>.jpg                each JPEG as the ESP32 sent it (pre-enhance)
    img<i>_NN_<stage>.jpg      every intermediate image-enhancement stage
    FINAL_<i>.jpg              the exact bytes handed to the LLM
    llm_reply.json             the parsed LlmReply JSON
```

It is **OFF by default**, never runs in prod, and is **distinct from `STORAGE_BACKEND`/`blobs.py`** (which is the durable `turns.image_url`/`audio_url` path) — this module is the throwaway debug mirror with the intermediate stages `blobs.py` never sees ([dev_capture.py:21-23](app/storage/dev_capture.py#L21)).

- **`enabled()`** — [dev_capture.py:37](app/storage/dev_capture.py#L37). `bool(settings.DEV_CAPTURE_DUMP)`. The cheap guard every function checks.
- **`_safe(token)`** — [dev_capture.py:41](app/storage/dev_capture.py#L41). Filesystem-safe token: keep alnum + `-_`, fallback `"lamp"` (device ids look like `lamp-7C9EB42F`).
- **`new_turn_dir(device_id) -> Path | None`** — [dev_capture.py:46](app/storage/dev_capture.py#L46). No-op `None` when disabled / on error. Timestamp `strftime("%Y%m%d_%H%M%S_%f")[:-3]` (µs→ms precision keeps back-to-back turns distinct), makes `Path(DEV_CAPTURE_DIR)/<ts>_<safe(device)>`, `mkdir(parents=True, exist_ok=True)` ([dev_capture.py:51-55](app/storage/dev_capture.py#L51)).
- **`_write_bytes(d, name, data)` / `_write_text(d, name, text)`** — [dev_capture.py:61](app/storage/dev_capture.py#L61), [dev_capture.py:70](app/storage/dev_capture.py#L70). No-op on `None` dir / empty data; each wrapped in try/except.
- **`dump_turn_inputs(d, raw_images, final_images, stages, audio_pcm)`** — [dev_capture.py:79](app/storage/dev_capture.py#L79). Writes the whole turn: `audio.wav` (via `wrap_pcm_as_wav` from `app.providers.audio_preprocessor`), each `raw_<i>.jpg`, per-stage `img<i>_<stage>.jpg` from the `stages` list of `{stage_name: blob}` maps, and `FINAL_<i>.jpg` (the exact post-enhancement/resized bytes sent to the LLM) ([dev_capture.py:93-107](app/storage/dev_capture.py#L93)). **Blocking file I/O** — the docstring instructs callers to invoke via `asyncio.to_thread(...)` so the event loop isn't held; the orchestrator does exactly that ([dev_capture.py:88-90](app/storage/dev_capture.py#L88), [orchestrator.py:270](app/services/orchestrator.py#L270)).
- **`save_llm_json(d, reply_json)`** — [dev_capture.py:118](app/storage/dev_capture.py#L118). Writes `llm_reply.json` next to the media ([orchestrator.py:944](app/services/orchestrator.py#L944)).

---

## 13. `__init__.py` — package contract

**File:** [app/storage/__init__.py](app/storage/__init__.py). Contains no executable code — it is a docstring-only module that documents the package's role (off-hot-path persistence) and the boundary with `app.db` / `app.services.memory` / `app.services.revocation` (the table from §1). It does not re-export symbols; callers import the submodules directly (e.g. `from app.storage import blobs`, `from app.storage.turns import write_turn`).

---

## 14. Configuration, Env Vars & Constants

All defined in `app/config.py` (Pydantic `Settings`). Effects:

| Setting | Default | Effect | Cite |
| --- | --- | --- | --- |
| `DATABASE_URL` | `""` | When empty, the engine is never built → every self-opening storage module's `_session_factory()` returns `None` → all DB writes no-op. Required when `ENABLE_AUTH=True` ([session.py:83-87](app/db/session.py#L83)) | [config.py:213](app/config.py#L213) |
| `DATABASE_SSL` | `""` (AUTO) | AUTO → TLS `require` for `*.supabase.co/.com` hosts, off for localhost ([session.py:33-52](app/db/session.py#L33)) | — |
| `STORAGE_BACKEND` | `"local"` | `off`/`local`/`s3`/`r2` — selects the blob backend ([blobs.py:186](app/storage/blobs.py#L186)). `off` → URLs stay NULL | [config.py:241](app/config.py#L241) |
| `STORAGE_LOCAL_DIR` | `"./turn_blobs"` | local write dir + delete base ([blobs.py:118](app/storage/blobs.py#L118), [blobs.py:206](app/storage/blobs.py#L206)) | [config.py:242](app/config.py#L242) |
| `STORAGE_PUBLIC_BASE_URL` | `""` | optional public URL prefix; empty local → `file://` URL ([blobs.py:210-212](app/storage/blobs.py#L210)) | [config.py:246](app/config.py#L246) |
| `S3_BUCKET` | `""` | required for s3/r2 put/delete (warn-once + no-op otherwise) ([blobs.py:142](app/storage/blobs.py#L142), [blobs.py:219](app/storage/blobs.py#L219)) | [config.py:247](app/config.py#L247) |
| `S3_REGION` | `""` | `region_name` for the S3 client | [config.py:248](app/config.py#L248) |
| `S3_ENDPOINT_URL` | `""` | Supabase/R2/MinIO endpoint; empty = AWS default; also used to build a URL when no public base set ([blobs.py:245-246](app/storage/blobs.py#L245)) | [config.py:249](app/config.py#L249) |
| `S3_ACCESS_KEY` / `S3_SECRET_KEY` | `""` | S3 credentials | [config.py:250-251](app/config.py#L250) |
| `DEV_CAPTURE_DUMP` | `False` | master toggle for `dev_capture.py` ([dev_capture.py:38](app/storage/dev_capture.py#L38)) | [config.py:265](app/config.py#L265) |
| `DEV_CAPTURE_DIR` | `"./turn_captures"` | dev-dump root ([dev_capture.py:53](app/storage/dev_capture.py#L53)) | [config.py:266](app/config.py#L266) |

In-code constants: `_SESSION_IDLE_MIN=30`, `_SID_CACHE_TTL_S=2100`, `EMPTY_HISTORY_TEXT` (turns.py); decay-resistance lookup tables (turns.py §5.5); `Semaphore(16)` delete concurrency (blobs.py); truncation limits `selected_model[:500]`, `generated_answer[:8000]`, `feedback_text[:2000]`, `speech[:500]`, `transcript[:200]`; `load_recent_turns(limit=3)`; `fetch_relevant(k=3)`.

Engine config (context): `pool_size=10`, `max_overflow=10`, `pool_pre_ping=True`, `pool_recycle=1800`, `expire_on_commit=False` ([session.py:89-98](app/db/session.py#L89)).

---

## 15. Edge Cases, Error Handling, Timeouts & Retries

- **DB off (no `DATABASE_URL`).** All self-opening writers no-op via `_session_factory() is None`. `open_session` returns `None`; `load_recent_turns` returns `EMPTY_HISTORY_TEXT`; turns still persist `user_id` tagging through subsequent calls only if the DB later comes up — but in this mode nothing is written and the conversation degrades to "L1-Redis-only → stateless" cleanly.
- **Un-migrated DB (missing column).** `open_session` catches a missing `last_activity_at` and degrades to `return None` ([turns.py:132-136](app/storage/turns.py#L132)). For `turn_traces` additive columns, `init_db` runs idempotent `ALTER TABLE … ADD COLUMN IF NOT EXISTS` best-effort ([session.py:113-134](app/db/session.py#L113)).
- **Concurrent turn writers.** Resolved by the atomic `UPDATE … RETURNING turn_count` (no read-then-write race) ([turns.py:208-225](app/storage/turns.py#L208)).
- **Concurrent profile submits.** Resolved by `INSERT … ON CONFLICT DO UPDATE` ([user_profiles.py:66-79](app/storage/user_profiles.py#L66)).
- **Session row wiped mid-turn.** `write_turn` detects `RETURNING` → `None` and writes the turn detached (`session_id=NULL`) rather than losing it ([turns.py:226-229](app/storage/turns.py#L226)).
- **Non-ok turns.** Both `write_turn` and `record_turn` (the service wrapper) skip `status not in (None,"ok")` so error fallbacks never become history ([turns.py:188-189](app/storage/turns.py#L188), [session_memory.py:222-223](app/services/session_memory.py#L222)). `model_responses` is the deliberate exception — failures are kept as the metric.
- **Blob upload timeout.** The orchestrator wraps the N-image + 1-audio gather in `asyncio.wait_for(..., timeout=15.0)`; on timeout/error it logs and stores the turn **without media URLs** ([orchestrator.py:1315-1325](app/services/orchestrator.py#L1315)).
- **Optional `aioboto3`.** Missing → warn-once + return `None` (no media persisted) ([blobs.py:147-151](app/storage/blobs.py#L147), [blobs.py:225-230](app/storage/blobs.py#L225)).
- **S3 batch-delete incompatibility.** Worked around with per-object `DeleteObject` ([blobs.py:135-140](app/storage/blobs.py#L135)).
- **Path-escape on local delete.** Guarded by `p.parent.resolve() == base.resolve()` ([blobs.py:123-124](app/storage/blobs.py#L123)).
- **Orphan / unknown ids.** `record_feedback` rejects feedback whose `response_id` doesn't exist ([model_eval.py:157-162](app/storage/model_eval.py#L157)); `key_from_url` refuses non-`turn-`/`trace-` filenames ([blobs.py:85](app/storage/blobs.py#L85)).
- **Retries.** There are no automatic retries in this layer; the only retry surface is the **manual** `delete_keys` cleanup (failed keys are simply re-attempted on the next admin run). Auto-deletion is deliberately absent ([blobs.py:91-93](app/storage/blobs.py#L91)).
- **Redis absent (today).** All `cget`/`cset` calls in `open_session` are no-ops; the Postgres path is the source of truth ([cache.py:4](app/services/cache.py#L4)).

---

## 16. Integration Points (callers & callees)

**Calls into `app/storage/`:**

| Caller | Storage call | Where |
| --- | --- | --- |
| `app/routes/ws_lamp.py` (lamp WS connect) | `open_session` → sets `session.db_session_id` | [ws_lamp.py:199-200](app/routes/ws_lamp.py#L199) |
| `app/routes/frontend_manager.py` (web `/simulate` context) | `open_session` (parallel with `get_profile`) | [frontend_manager.py:766-769](app/routes/frontend_manager.py#L766) |
| `app/services/session_memory.py` `record_turn` | `write_turn` (durable Supabase write) | [session_memory.py:227-233](app/services/session_memory.py#L227) |
| `app/services/session_memory.py` `load_context` | `load_recent_turns` (L1 history) | [session_memory.py:117](app/services/session_memory.py#L117) |
| `app/services/session_memory.py` finalize | `close_session`, `get_user_memory`, `upsert_user_memory` | [session_memory.py:381](app/services/session_memory.py#L381), [session_memory.py:405](app/services/session_memory.py#L405), [session_memory.py:467](app/services/session_memory.py#L467) |
| `app/services/orchestrator.py` `_persist_turn` | `blobs.upload_image` × N + `blobs.upload_audio` (gathered, 15 s cap); `dev_capture.new_turn_dir` / `dump_turn_inputs` / `save_llm_json` | [orchestrator.py:1311-1320](app/services/orchestrator.py#L1311), [orchestrator.py:113](app/services/orchestrator.py#L113), [orchestrator.py:270](app/services/orchestrator.py#L270), [orchestrator.py:944](app/services/orchestrator.py#L944) |
| `app/services/turn_trace.py` | `blobs.upload_image` (raw/enhanced), `blobs.upload_audio` / `upload_audio_wav` | [turn_trace.py:255-265](app/services/turn_trace.py#L255) |
| `app/services/media_cleanup.py` | `blobs.key_from_url`, `blobs.delete_keys` | [media_cleanup.py:114-125](app/services/media_cleanup.py#L114) |
| `app/routes/frontend_manager.py` (bench) | `model_eval.record_request` / `record_response` / `record_feedback` | [frontend_manager.py:1789](app/routes/frontend_manager.py#L1789), [frontend_manager.py:1808](app/routes/frontend_manager.py#L1808), [frontend_manager.py:1815](app/routes/frontend_manager.py#L1815) |
| `app/routes/frontend_manager.py` (onboarding) | `user_profiles.get_profile` / `upsert_profile` | [frontend_manager.py:147](app/routes/frontend_manager.py#L147) |
| `app/main.py` (startup lifespan, after `init_db`) | `model_eval.seed_providers` | [main.py:86-87](app/main.py#L86) |
| `app/routes/device_user.py`, services | `events.log_event` / `events.recent_events` | (lifecycle logging) |

**`app/storage/` calls out to:**
- `app/db/session.py` (`get_session_factory`, `get_db`) for sessions, `app/db/models.py` for ORM classes.
- `app/services/cache.py` (`cget`/`cset`) from `open_session` — Redis fast path (currently no-op).
- `app/services/model_catalog.py` (`list_models`, `is_available`, `ModelSpec`) from `seed_providers`.
- `app/providers/audio_preprocessor.py` (`wrap_pcm_as_wav`) from `dev_capture.dump_turn_inputs`.
- External: `aioboto3` (optional, S3/R2), stdlib `wave` (WAV containerization), the local filesystem.

**Cross-system context:** the firmware (ESP32-S3) sends the raw audio PCM + JPEG over WebSocket; the orchestrator turns those into the bytes `blobs.py` persists and `dev_capture.py` mirrors. The Next.js frontend reads `turns`/`user_profiles`/`model_*` rows (via admin/frontend routes) and the persisted `turns.image_url`/`audio_url`. The web simulator's `/solve` path persists through the same `write_turn`/`model_eval` repositories, tagged via `extra.source` so its turns are distinguishable in analytics. The Supabase/Postgres+pgvector DB is the storage backend; `memories` (pgvector) is the deferred table this layer's `memory_vec.py` will eventually own.

---

## 17. End-to-End Diagrams

### 17.1 Turn-persistence flow (sequence)

```mermaid
sequenceDiagram
    participant Lamp as ESP32 Lamp / Web Sim
    participant WS as ws_lamp.py / frontend_manager
    participant Orch as orchestrator._persist_turn
    participant Blobs as storage/blobs.py
    participant SM as services/session_memory.record_turn
    participant Turns as storage/turns.write_turn
    participant PG as Postgres
    participant OS as S3 / R2 / local FS

    Lamp->>WS: connect (device_jwt → device_id, user_id)
    WS->>Turns: open_session(device_id, user_id)
    Turns->>PG: SELECT ... last_activity_at > now()-30min (IS NOT DISTINCT FROM)
    alt fresh session for same user
        Turns->>PG: UPDATE ended_at=NULL, last_activity_at=now()
        Turns-->>WS: existing session_id (resume)
    else
        Turns->>PG: INSERT sessions(new uuid)
        Turns-->>WS: new session_id
    end

    Note over Orch: turn answered (status ok)
    Orch->>Blobs: gather(upload_image×N, upload_audio)  [wait_for 15s]
    Blobs->>OS: put_object / write_bytes (turn-<id>.{jpg,wav})
    Blobs-->>Orch: URLs (or None on timeout/off)
    Orch->>SM: record_turn(reply, telemetry, image_url, audio_url, turn_id)
    SM->>Turns: write_turn(...)
    Turns->>PG: UPDATE sessions SET turn_count+1 RETURNING turn_count
    Turns->>PG: INSERT turns(... decay_resistance, escalation_path, extra)
    Turns-->>SM: (fire-and-forget)
```

### 17.2 Module dispatch / control flow (flowchart)

```mermaid
flowchart TD
    A[storage function called] --> B{Self-opening module?}
    B -- yes --> C["_session_factory()"]
    C --> D{factory is None?}
    D -- yes --> E[no-op return None/False/EMPTY_HISTORY_TEXT]
    D -- no --> F["async with factory() as db"]
    B -- no, injected --> F2[use caller's AsyncSession db]
    F --> G[run query / build ORM row]
    F2 --> G
    G --> H{exception?}
    H -- yes --> I["log.exception(...) + swallow"]
    H -- no --> J[db.commit]
    J --> K[return result]

    subgraph Blobs[blobs._put dispatch]
        L{STORAGE_BACKEND} -->|off| M[return None]
        L -->|local| N["_put_local → file:// or public URL"]
        L -->|s3/r2| O["_put_s3 → aioboto3 put_object"]
    end
```

---

*Document grounded entirely in the source files under `D:/clartiy/Smart-Tutor-Lamp-backend/app/storage/` plus `app/db/models.py`, `app/db/session.py`, `app/config.py`, and the verified call sites in `app/services/` and `app/routes/`.*
