# Database — Supabase Setup, Queries & Admin SQL

This is the definitive reference for the **Smart Tutor Lamp** (codename **Lumos**) Postgres-on-Supabase data layer. It documents, inch-by-inch, three source files: the project setup guide ([SUPABASE_SETUP.md](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md)), the SQL debug/analytics cookbook ([SUPABASE_QUERIES.md](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md)), and the admin-table bootstrap script ([scripts/admin_setup.sql](../../Smart-Tutor-Lamp-backend/scripts/admin_setup.sql)). It covers Supabase project creation, the full durable + analytics + scalable schema (every table, column, index, CHECK constraint), the `pgvector`/`pgcrypto`/`pg_stat_statements` extensions, Row-Level Security (RLS), the admin allowlist, materialized views, the reconnect-resume algorithm, the smart-compaction `decay_resistance` math, the Redis accelerator seam, Alembic migrations, and every operational SQL query (health, pairing, conversations, memory, cost, events, analytics, integrity, storage, housekeeping). Everything below is grounded entirely in the three source files; nothing is invented.

> Identity reminder used throughout: a **user** is a **Clerk `user_id`** text string (the JWT `sub` claim), e.g. `user_2abc…`. There is intentionally **no `users` table** — Clerk owns human identity; Postgres only stores the Clerk ID string. ([SUPABASE_QUERIES.md:13-26](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L13))

> **Updated 2026-07-03:** this operations doc covers the schema/DDL/queries as they appear in the three source files. Since the 2026-06-16 sync the ORM schema grew from 16 to **24 tables** — eight new ORM-defined tables (pilot instrumentation, syllabus/topic/mistake tagging, and OTA `firmware_releases`) that are auto-created by `create_all` and cataloged in [00-overview-and-schema.md §7.13](00-overview-and-schema.md#713-tables-added-since-the-2026-06-16-sync); their writers are in [01-storage-layer.md §9A](01-storage-layer.md) and the backend workers/services. The Supabase setup/queries below are unchanged for the original tables.

---

## Table of contents

1. [Purpose & responsibility](#1-purpose--responsibility)
2. [Why Supabase + Postgres](#2-why-supabase--postgres)
3. [Phase 1 — Create the project](#3-phase-1--create-the-project)
4. [Phase 2 — Backend connection](#4-phase-2--backend-connection)
5. [Architecture & entity-relationship map](#5-architecture--entity-relationship-map)
6. [Schema design principles](#6-schema-design-principles)
7. [Table-by-table breakdown](#7-table-by-table-breakdown)
8. [Indexes — what each one pays for](#8-indexes--what-each-one-pays-for)
9. [Row-Level Security (RLS)](#9-row-level-security-rls)
10. [The Clerk ↔ Supabase JWT bridge](#10-the-clerk--supabase-jwt-bridge)
11. [Materialized views](#11-materialized-views)
12. [Normalization stance & the three deliberate denormalizations](#12-normalization-stance--the-three-deliberate-denormalizations)
13. [Hot path vs analytics — query-latency strategy](#13-hot-path-vs-analytics--query-latency-strategy)
14. [Algorithms — resume, compaction, profile-tiering, ANN, escalation](#14-algorithms--resume-compaction-profile-tiering-ann-escalation)
15. [The Redis accelerator seam](#15-the-redis-accelerator-seam)
16. [Phase 4 — Alembic migrations](#16-phase-4--alembic-migrations)
17. [Phase 5 — Wiring the backend (session factory + write_turn)](#17-phase-5--wiring-the-backend-session-factory--write_turn)
18. [The admin allowlist & admin_setup.sql](#18-the-admin-allowlist--admin_setupsql)
19. [Operational SQL cookbook (SUPABASE_QUERIES.md)](#19-operational-sql-cookbook-supabase_queriesmd)
20. [Analytics queries you'll actually run (Phase 6)](#20-analytics-queries-youll-actually-run-phase-6)
21. [Stored media (Supabase Storage)](#21-stored-media-supabase-storage)
22. [Housekeeping & destructive resets](#22-housekeeping--destructive-resets)
23. [Configuration, env vars & constants](#23-configuration-env-vars--constants)
24. [Edge cases, error handling, fallbacks](#24-edge-cases-error-handling-fallbacks)
25. [Integration points (firmware ↔ backend ↔ frontend ↔ db)](#25-integration-points-firmware--backend--frontend--db)
26. [Production scaling notes (Phase 7)](#26-production-scaling-notes-phase-7)
27. [Troubleshooting (Phase 9)](#27-troubleshooting-phase-9)
28. [Diagrams](#28-diagrams)
29. [Setup checklist (Phase 8)](#29-setup-checklist-phase-8)

---

## 1. Purpose & responsibility

The database layer's job is to provide **durable storage** so the Lumos backend's per-turn history, analytics, and per-user memory become real. The backend works without a database today (everything `print()`s); the guide adds Postgres-on-Supabase so the conversation, telemetry, and learner profile survive a restart ([SUPABASE_SETUP.md:8-11](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L8)).

The data layer's single responsibility is best summarized by the setup doc itself: **"tie one human (Clerk user) to one or more lamps (ESP32 devices), and hang every session / turn / equation / analytics row off that link so nothing is orphaned"** ([SUPABASE_SETUP.md:169-171](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L169)).

This single Postgres database is described as the **single consolidated DB reference: auth + pairing + conversation + memory + analytics, all in one schema** ([SUPABASE_SETUP.md:21-22](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L21)). It is the durable **source of truth**; Redis (when enabled) is only a read accelerator layered on top ([SUPABASE_SETUP.md:1031-1035](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1031)).

Companion docs referenced (not the subject of this document but cited for cross-reference): `RUN.md` (boot the backend), `LAYOUT.md` (module map), `IMPLEMENTATION_AUTH_PAIRING.md` §6.2 (the `devices` + `pairing_codes` auth tables), `ESCALATION_PLAN.md` §2.8 (tier columns), and `SESSION_MEMORY_GUIDE.md` (the runtime memory spec the `sessions`/`turns`/`user_memory` tables are kept in lock-step with — it is the authoritative source for the ORM models and the memory service) ([SUPABASE_SETUP.md:12-22](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L12)).

---

## 2. Why Supabase + Postgres

The setup doc opens with a needs-to-capability table ([SUPABASE_SETUP.md:28-40](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L28)):

| Need | Supabase covers it via |
|---|---|
| Relational store for `devices` / `turns` / `memories` | Postgres 15+ |
| Long-term memory (semantic search) | `pgvector` extension |
| Object storage (raw audio WAV + image JPEG) | Supabase Storage (S3-compatible) |
| Auth | **Clerk** owns user identity — Supabase only stores the Clerk user ID. Supabase Auth is **not** used. |
| Realtime (future) | Supabase Realtime (Postgres logical replication) for a future "watch this lamp from the frontend" feature |
| Auto REST + GraphQL | PostgREST + pg_graphql — handy for the frontend's `/devices` page |
| Built-in dashboard | SQL editor, table editor, log viewer, metrics |
| Free tier | 500 MB DB + 1 GB storage + 50 K MAU + 2 M Edge Function invocations / month |

The free tier alone covers ~50 K turns at typical row sizes; paid tiers scale to billions ([SUPABASE_SETUP.md:39-40](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L39)).

---

## 3. Phase 1 — Create the project

### 3.1 Create the Supabase project (web UI)

Steps ([SUPABASE_SETUP.md:46-54](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L46)):
1. supabase.com → Sign in → New project.
2. Set **Name** (`lumos-tutor-lamp`), **Database Password** (save in a password manager — needed for `DATABASE_URL`), **Region** (closest to where the **backend** deploys, NOT closest to you — for Gemini's `us-central1` use `us-east-1`; for Asia `ap-south-1` Mumbai), **Plan** Free.
3. Wait ~2 minutes for provisioning.

### 3.2 Connection details

From Project Settings → Database ([SUPABASE_SETUP.md:60-66](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L60)):

```
Host:          db.<project-ref>.supabase.co
Port:          5432
Database name: postgres
User:          postgres
Password:      <the one you set>
```

There are **two connection modes** worth knowing ([SUPABASE_SETUP.md:70-74](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L70)):

| Mode | Port | When to use |
|---|---|---|
| **Direct** | 5432 | Long-lived connections (backend, Alembic migrations). What Lumos uses. |
| **Transaction pooler (PgBouncer)** | 6543 | Serverless / Lambda / Cloud Functions that open one connection per request. NOT used here — Lumos keeps persistent connections via SQLAlchemy's pool. |
| **Session pooler** | 5432 | Same as direct for our purposes. |

For asyncpg + SQLAlchemy, **use direct on 5432** — some `prepare`-statement features in asyncpg conflict with the transaction pooler ([SUPABASE_SETUP.md:76](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L76)).

### 3.3 Enable required extensions

Dashboard → Database → Extensions → toggle ON ([SUPABASE_SETUP.md:80-88](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L80)):

| Extension | Why |
|---|---|
| `vector` (pgvector) | Long-term memory ANN (Layer 3.3) |
| `pg_stat_statements` | Query-performance analytics |
| `pgcrypto` | `gen_random_uuid()` for primary keys |

`uuid-ossp` also gives `uuid_generate_v4()`, but `pgcrypto`'s `gen_random_uuid()` is **faster** and is the one used ([SUPABASE_SETUP.md:88](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L88)). You can confirm extensions are installed with: `select extname, extversion from pg_extension order by extname;` ([SUPABASE_QUERIES.md:611-614](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L611)).

---

## 4. Phase 2 — Backend connection

### 4.1 Install Postgres deps

From `backend/lumos-backend/` ([SUPABASE_SETUP.md:96-113](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L96)):

```powershell
pip install "sqlalchemy[asyncio]" asyncpg alembic pgvector
```

Or uncomment the relevant lines in `requirements.txt` (the diff in the doc enables `sqlalchemy[asyncio]`, `asyncpg`, `alembic`, `pgvector` — "Layer 9 persistence").

### 4.2 Add `DATABASE_URL` to `.env`

```
# backend/lumos-backend/.env
DATABASE_URL=postgresql+asyncpg://postgres:<YOUR_PASSWORD>@db.<project-ref>.supabase.co:5432/postgres
```

**URL-encode the password** if it contains symbols (`@`, `#`, `:`, `/`) — the doc shows `quote_plus("my:weird@pass")` → `my%3Aweird%40pass` ([SUPABASE_SETUP.md:117-128](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L117)). Note the driver is `postgresql+asyncpg` (async).

### 4.3 Smoke-test the connection

A one-liner connects via raw asyncpg and prints `SELECT version()`; it should print `PostgreSQL 15.x on …` ([SUPABASE_SETUP.md:132-147](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L132)). If it hangs/refuses: check the (URL-encoded) password; enable the **IPv4 add-on** (Free tier sometimes routes only IPv6); check a firewall blocking outbound 5432.

---

## 5. Architecture & entity-relationship map

The whole DB exists to link one human → one-or-more lamps → every conversation row. The ASCII ER map ([SUPABASE_SETUP.md:173-209](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L173)) shows:

- **Clerk (managed)** owns human identity. `user_id = "user_2abc…"` is a **string**, not a row Lumos owns.
- **`devices`** (`device_id` PK, `user_id`, `..._hash`, `revoked_at`) is the join point between a Clerk user and a physical lamp.
- **`pairing_codes`** (short-lived, 5-min, single-use) bridges "this lamp" ↔ "this user" and holds the minted `device_jwt` until the lamp polls and deletes it.
- `user_id` is **denormalised onto every child row** (`sessions`, `turns`, `user_memory`, `events`) so per-user analytics is one index hop, no join.
- **`sessions`** (1→N `turns`), **`user_memory`** (1 row per device, L3 profile), **`events`** (buttons, ws_open/close, reboots), **`cost_log`** (per-API-call ledger), **`memories`** (pgvector ANN, deferred).

### 5.1 Identity flow (where `user_id` comes from, end-to-end)

Six steps ([SUPABASE_SETUP.md:211-232](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L211)):

1. Human signs up on the frontend → **Clerk** mints identity. Lumos never stores password/email; only the Clerk user-ID string. There is **no `users` table** — Clerk is source of truth; the `user.deleted` webhook cascades a revoke into `devices`.
2. Lamp boots unpaired → `POST /register` → backend upserts a `devices` row (`device_secret_hash`, no `user_id` yet) and a `pairing_codes` row → lamp shows the QR.
3. User scans QR, logs in (Clerk), clicks "Link" → `/complete-pairing` verifies the Clerk session, writes `devices.user_id = "user_2abc…"`, `paired_at = now()`, and mints a `device_jwt` (claim `uid = user_id`) into the `pairing_codes` row.
4. Lamp polls, receives + stores the `device_jwt`, deletes the pairing row.
5. Every WS connect: gateway verifies the JWT signature, then checks `devices.user_id == jwt.uid AND revoked_at IS NULL` — **no Clerk call on the hot path**. `last_seen_at` is bumped every ~30 s.
6. On the authenticated socket, the orchestrator stamps the **same `user_id` and `device_id`** onto every `sessions` / `turns` / `user_memory` row it writes — so "show me everything this learner ever did" is one `WHERE user_id = $1` scan, and RLS lets the frontend read it directly.

### 5.2 The "WIRED IN CODE" note (how the schema connects to runtime)

The `user_id` flows end-to-end through real code ([SUPABASE_SETUP.md:234-249](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L234)): `ws_lamp.py:_authenticate_prod` reads `device_jwt.uid` → `Session(user_id=…)` → `app/storage/turns.py:open_session()` **resumes-or-opens** a `sessions` row for `(device_id, user_id)` (resumes within a 30-min idle window so reconnects don't fragment a conversation; a re-paired-to-different-user device won't resume) → `orchestrator._persist_turn` → `write_turn()` inserts a `turns` row carrying `user_id` + `device_id` + `session_id` and bumps the session's `last_activity_at`/`turn_count`. ORM models `SessionRecord` / `TurnRecord` live in `app/db/models.py` (auto-created by `create_all` on boot when `ENABLE_AUTH=True`).

All persistence is **crash-safe + DB-availability-gated**: in dev (`ENABLE_AUTH=False`, `user_id=NULL`) it cleanly no-ops; **error-status turns are skipped** so fallbacks never pollute history. **Cross-user safety:** on unlink (`device_user.py`) and Clerk `user.deleted` (`clerk_webhook.py`) the device's short-term Redis history (`lamp:hist:{device_id}`) is **cleared** (`memory.clear_history`), so the next user to pair the same lamp never inherits the prior user's turns.

**Unlink / account-delete** ([SUPABASE_SETUP.md:251-254](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L251)): `devices.revoked_at = now()`, `user_id = NULL`, and a Redis `device:revoked:<id>` publish closes the live socket (close code 4402). Historical `turns`/`sessions` keep their `user_id` for analytics unless you scrub them (GDPR path — §26).

### 5.3 Coverage matrix — "is everything stored?"

Every concern has a home ([SUPABASE_SETUP.md:256-280](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L256)):

| Concern | Where it lives |
|---|---|
| Human identity (email, password, OAuth) | **Clerk** (not the DB) |
| Clerk user ID → rows | `devices.user_id`, denormalised onto `sessions`/`turns`/`user_memory`/`events` |
| Web onboarding profile | `user_profiles` (keyed by Clerk `user_id`) |
| Lamp identity + secret | `devices.device_id`, `devices.device_secret_hash` (argon2id) |
| User ↔ lamp pairing | `devices.user_id` + `pairing_codes` (transient) + minted `device_jwt` |
| Auth state / revocation | `devices.revoked_at`, `devices.last_seen_at` (+ Redis `device:revoked:*`) |
| Session grouping + compaction | `sessions` (`summary`, `summary_as_of`, `turn_count`) |
| Every Q→A turn (verbatim) | `turns.speech` / `display_content` / `transcript` |
| Equations shown | `turns.latex_equations jsonb` |
| Which model answered | `turns.llm_provider`, `turns.llm_model` |
| Did it escalate + how far | `turns.final_tier`, `turns.escalation_path[]`, `turns.escalated` |
| Thinking-token spend (the bug metric) | `turns.llm_thinking_tok` |
| Per-call cost ledger | `turns.cost_usd` + `turns.cost_usd_breakdown jsonb` (+ optional `cost_log`) |
| Cross-session learner profile | `user_memory` (`long_term_summary`, `subject_profile`) |
| Hardware / network context | `turns.client_fw_version`, `turns.wifi_rssi_dbm` |
| Lifecycle events | `events` |
| Raw audio/image blobs | object storage; URLs in `turns.audio_url`/`image_url` |

Rule: a future concern goes in `turns.extra` / `events.payload` (JSONB) first, and **graduates to a real column once it's hot-queried** ([SUPABASE_SETUP.md:278-280](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L278)).

---

## 6. Schema design principles

Ten opinionated principles drive every column and index ([SUPABASE_SETUP.md:155-165](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L155)):

1. **`uuid` primary keys, sortable.** Use `gen_random_uuid()` (v4) for almost everything; high-write tables (`turns`, `events`) may switch to UUIDv7 later (Postgres 17 native `uuidv7()`; for now generated in Python via the `uuid7` package) so B-tree indexes stay tight.
2. **Denormalise `user_id` into hot tables** (`turns.user_id`, `memories.user_id`) — per-user queries become one index hop, no joins.
3. **`timestamptz` everywhere**, never `timestamp` (avoids timezone-arithmetic bugs).
4. **JSONB for "future fields"** (`turns.extra`, `events.payload`) — adding metadata needs no migration; index specific JSONB paths once hot.
5. **BRIN indexes on append-only timestamp columns** — ~1000× smaller than B-tree, perfect for `turns.asked_at` analytics.
6. **Partial indexes** for "the queries that matter" — e.g. only index `revoked_at IS NULL` devices.
7. **No premature partitioning.** Add range-partitioning on `turns` past ~10 M rows.
8. **RLS prepared but permissive.** Backend writes via the **service role key** (bypasses RLS). Policies are written so the future frontend can read user-scoped rows directly via the **anon key** + Clerk JWT.
9. **3NF baseline, denormalize only with a written reason.** Exactly three deliberate denormalizations (`user_id` fan-out, `sessions` rollups, `turns.cost_usd`) — each with a documented invariant (§12).
10. **Tune per workload, not globally.** Hot path (session reads, < 10 ms) vs analytics (seconds OK) have opposite priorities (§13).

---

## 7. Table-by-table breakdown

The schema authority note ([SUPABASE_SETUP.md:284-306](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L284)) clarifies that this file is the **analytics + scaling** reference, while `SESSION_MEMORY_GUIDE.md` is the **memory + runtime** reference (the one the code implements). They describe **one unified schema**. Key reconciliations: `turns.speech` (not `response_text`), `turns.latex_equations jsonb` (separate equations channel), `turns.turn_index` + `turns.decay_resistance` (compaction), `display_kind` only `'text'`|`'none'` (the `'latex'` kind was removed). The **canonical writer** when `ENABLE_MEMORY=true` is `SessionMemoryService.persist_turn` (writes only `status='ok'` turns); the standalone `write_turn` in §17 is the analytics-only variant for when memory is off (it may log failure rows with `status<>'ok'`, hence `speech` defaults to `''`).

### 7.1 `devices` — the authoritative auth table

The join point between a Clerk user and a physical lamp. `user_id` holds the Clerk ID (NULL until paired, NULL again on unlink), `device_secret_hash` is the argon2id of the lamp's secret, and `revoked_at` is the **single revocation signal** the WS gateway checks on every connect ([SUPABASE_SETUP.md:308-337](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L308)):

```sql
CREATE TABLE devices (
  device_id           text PRIMARY KEY,
  device_secret_hash  text NOT NULL,
  user_id             text,                            -- Clerk user_2abc… or NULL when unpaired
  friendly_name       text NOT NULL DEFAULT 'Tutor Lamp',
  paired_at           timestamptz,
  last_seen_at        timestamptz,
  revoked_at          timestamptz,
  created_at          timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX devices_user_idx
  ON devices(user_id)
  WHERE user_id IS NOT NULL AND revoked_at IS NULL;

CREATE INDEX devices_last_seen_idx
  ON devices(last_seen_at DESC)
  WHERE revoked_at IS NULL;
```

`devices_user_idx` answers "what devices does THIS user own and not yet unlink"; `devices_last_seen_idx` powers "online now" views.

### 7.2 `pairing_codes` — transient pairing bridge

Short-lived (5-min TTL), single-use. The backend writes the minted `device_jwt` here on `status='paired'`; the lamp polls, stores it in NVS, and the row is deleted. A cron sweep deletes rows `expires_at < now() - 1 hour`. **NEVER store the raw `device_secret` here — only the minted JWT** ([SUPABASE_SETUP.md:339-360](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L339)):

```sql
CREATE TABLE pairing_codes (
  code        text PRIMARY KEY,
  device_id   text NOT NULL REFERENCES devices(device_id) ON DELETE CASCADE,
  user_id     text,
  status      text NOT NULL CHECK (status IN ('pending','paired','expired')),
  device_jwt  text,
  expires_at  timestamptz NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX pairing_codes_device_idx ON pairing_codes(device_id);
CREATE INDEX pairing_codes_expires_idx ON pairing_codes(expires_at) WHERE status = 'pending';
```

The `status` CHECK constrains values to `'pending' | 'paired' | 'expired'`. The partial expires index only covers `pending` rows (the only set the sweep scans).

### 7.3 `user_profiles` — web onboarding profile

One row per **Clerk user** (NOT per device). Written by the Next.js onboarding flow through the backend's Frontend Manager (`PUT /api/frontend/profile`), so the profile lands in Postgres — not just in Clerk `publicMetadata`. Doubles as durable learner context the LLM system prompt can read (target exam → tailor difficulty). Distinct from `user_memory` (per-device, derived from turns) ([SUPABASE_SETUP.md:362-389](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L362)):

```sql
CREATE TABLE user_profiles (
  user_id             text        PRIMARY KEY,           -- Clerk user ID "user_2abc…"
  full_name           text        NOT NULL DEFAULT '',
  phone               text,
  target_exam         text        CHECK (target_exam IN ('JEE','NEET','CAT','UPSC') OR target_exam IS NULL),
  prep_duration       text,                              -- 'Just started' | 'Less than 6 months' | '1 year' | '2+ years'
  onboarding_complete boolean     NOT NULL DEFAULT false,
  extra               jsonb       NOT NULL DEFAULT '{}'::jsonb,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX user_profiles_exam_idx ON user_profiles(target_exam)
  WHERE target_exam IS NOT NULL;
```

`target_exam` is constrained to `JEE | NEET | CAT | UPSC | NULL`. The partial `user_profiles_exam_idx` powers cohort analytics ("how many JEE learners onboarded this month").

### 7.4 `sessions` — groups turns into one "lamp boot" window

A session is a contiguous run of turns from the same device with **< 30 min idle gaps** ([SUPABASE_SETUP.md:391-420](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L391)):

```sql
CREATE TABLE sessions (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id        text NOT NULL REFERENCES devices(device_id) ON DELETE CASCADE,
  user_id          text,                  -- denormed from devices for fast user-scoped queries
  started_at       timestamptz NOT NULL DEFAULT now(),
  ended_at         timestamptz,
  last_activity_at timestamptz NOT NULL DEFAULT now(),  -- bumped per turn; drives reconnect-resume
  turn_count       int  NOT NULL DEFAULT 0,
  summary          text,                  -- LLM-compacted text of turns 1..(turn_count - TAIL_SIZE)
                                          -- format: "KEY_FACTS:\n<verbatim keepers>\n\nSUMMARY:\n<prose>"
  summary_as_of    int  NOT NULL DEFAULT 0,-- turn_count at last compaction (prevents re-compaction)
  primary_subject  text,                  -- most recent subject (denorm for analytics)
  avg_difficulty   text                   -- most recent difficulty (denorm for analytics)
);

CREATE INDEX sessions_device_idx ON sessions(device_id, started_at DESC);
CREATE INDEX sessions_user_idx   ON sessions(user_id, started_at DESC) WHERE user_id IS NOT NULL;
CREATE INDEX sessions_resume_idx ON sessions(device_id, last_activity_at DESC);
```

**WIRED behaviour** ([SUPABASE_SETUP.md:422-430](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L422)): on every WS connect the backend **resumes** the most recent session for `(device_id, user_id)` whose `last_activity_at` is within 30 min — so the lamp's frequent reconnects (60-s idle timeout, WiFi blips) don't shatter one conversation. A device re-paired to a *different* user won't match → a fresh session opens (history never bleeds across users). `last_activity_at` is bumped per turn; `ended_at` is set on disconnect (cleared on resume). The compaction/summary columns are reserved for `SESSION_MEMORY_GUIDE.md`'s layer.

### 7.5 `turns` — the heart of analytics

The most-written and most-queried table. The **migration cost-of-omission warning** ([SUPABASE_SETUP.md:438-445](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L438)) notes that columns like `final_tier`, `escalation_path`, `llm_thinking_tok`, `request_id`, `client_fw_version`, `cost_usd_breakdown` cost ~0 storage when unfilled (Postgres NULLs are 1 byte) but save an `ALTER TABLE` on a multi-million-row table later. Full DDL ([SUPABASE_SETUP.md:447-526](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L447)):

```sql
CREATE TABLE turns (
  -- Identity
  id                  uuid       PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id          uuid,                                 -- correlation ID with backend log traces
  device_id           text       NOT NULL REFERENCES devices(device_id) ON DELETE CASCADE,
  user_id             text,                                 -- denorm; NULL in dev / unpaired
  session_id          uuid       REFERENCES sessions(id) ON DELETE SET NULL,
  turn_index          int        NOT NULL DEFAULT 1,        -- 1-based position within session (compaction ordering)
  -- Timing
  asked_at            timestamptz NOT NULL DEFAULT now(),
  ended_at            timestamptz,
  total_ms            int,                                  -- EOS → AUDIO_OUT_END
  -- Inputs
  audio_url           text,
  image_url           text,
  audio_duration_s    numeric(5, 2),
  image_bytes_in      int,
  image_bytes_clean   int,
  image_enhanced      boolean    NOT NULL DEFAULT false,    -- did the OpenCV pipeline run?
  transcript          text,                                 -- filled async by Groq Whisper Large v3
  -- LLM reply (mirrors app/schemas/llm_response.py:LlmReply)
  speech              text       NOT NULL DEFAULT '',       -- TTS text; '' on logged failure rows
  display_kind        text       CHECK (display_kind IN ('text','none') OR display_kind IS NULL),
  display_content     text,
  latex_equations     jsonb      NOT NULL DEFAULT '[]'::jsonb,  -- separate equation channel
  -- LLM self-classification (drives the tier router)
  confidence          numeric(3, 2),                        -- 0.00 - 1.00
  query_type          text,                                 -- 'concept'|'calc'|'formula'|'derivation'|…
  subject             text,                                 -- 'math'|'physics'|'chemistry'|…
  difficulty          text       CHECK (difficulty IN ('easy','medium','hard') OR difficulty IS NULL),
  decay_resistance    numeric(3, 2) DEFAULT 0.5,            -- 0.0-1.0 importance anchor for compaction
  -- Provider + telemetry
  llm_provider        text,                                 -- 'gemini' | 'openai' | 'claude' | 'deepseek'
  llm_model           text,
  llm_input_tok       int,
  llm_output_tok      int,
  llm_thinking_tok    int,                                  -- Gemini 2.5 hidden CoT; null on non-thinking models
  ttft_ms             int,
  cost_usd            numeric(10, 6),                       -- total turn cost (sum of all calls if escalated)
  cost_usd_breakdown  jsonb      NOT NULL DEFAULT '{}'::jsonb,
  -- Multi-tier escalation (Layer 4)
  final_tier          smallint,                             -- 1 | 2 | 3 | 4 — which tier shipped
  escalation_path     text[]     NOT NULL DEFAULT '{}',     -- e.g. ARRAY['tier1','tier2']
  escalated           boolean    NOT NULL DEFAULT false,    -- denorm of (array_length(escalation_path) > 1)
  -- Outcome
  status              text       NOT NULL DEFAULT 'ok',
  cancel_source       text,                                 -- 'button' | 'ws_close' | 'timeout' | NULL
  -- Transport / hardware context
  client_fw_version   text,
  wifi_rssi_dbm       smallint,
  -- A/B testing + escape hatch
  ab_test_arm         text,
  extra               jsonb      NOT NULL DEFAULT '{}'::jsonb
);
```

The `status` CHECK is added as a named constraint with **nine allowed values** ([SUPABASE_SETUP.md:528-543](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L528)):

```sql
ALTER TABLE turns ADD CONSTRAINT turns_status_check CHECK (status IN (
  'ok','timeout','upstream_unavailable','rate_limited','bad_json',
  'truncated','safety_block','error','cancelled'
));
```

Notable field semantics:
- `latex_equations` — array of LaTeX strings, each a renderable frame on the lamp's L/R-navigable LaTeX region. `[]` when no math. Stored **verbatim** so the compaction "keeper" logic can re-inject exact formulas (not the TTS paraphrase) ([SUPABASE_SETUP.md:478-483](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L478)).
- `decay_resistance` — 0.0-1.0 importance anchor, derived at write-time from `query_type`+`difficulty`; `0.9` = hard derivation kept verbatim, `0.15` = easy check decays first ([SUPABASE_SETUP.md:490-492](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L490)).
- `cost_usd_breakdown` — per-call cost ledger, e.g. `{"tier1": 0.0003, "stt_groq": 0.00003, "vision_describe": 0.00005, "deepseek_r1": 0.005}`; empty `{}` for simple turns ([SUPABASE_SETUP.md:502-506](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L502)).
- `escalation_path` smart-skip — e.g. `['tier1','tier3']` proves the orchestrator skipped tier-2 ([SUPABASE_SETUP.md:510](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L510)).

Total per-row overhead when all new columns are NULL is ~15 bytes — negligible vs the 200-800 byte typical row dominated by `speech` + `transcript` ([SUPABASE_SETUP.md:635](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L635)).

### 7.6 `user_memory` — cross-session learner profile (Layer 3, ACTIVE)

One row per device (or per user once auth is on). Updated **once per session end**, not per turn. The distilled "who is this learner" block injected as Layer 3 of the LLM context ([SUPABASE_SETUP.md:637-661](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L637)):

```sql
CREATE TABLE user_memory (
  id                uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id         text        NOT NULL UNIQUE,      -- key in dev mode
  user_id           text,                              -- key in prod (Clerk ID)
  long_term_summary text,                              -- 1-2 sentence LLM-distilled learning profile
  subject_profile   jsonb       NOT NULL DEFAULT '{}'::jsonb,  -- {"math":"hard","physics":"medium"}
  session_count     int         NOT NULL DEFAULT 0,
  total_turns       int         NOT NULL DEFAULT 0,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX user_memory_user_idx ON user_memory(user_id) WHERE user_id IS NOT NULL;
```

`UNIQUE(device_id)` already gives the device lookup index; the partial `user_memory_user_idx` adds prod reads by `user_id`. The profile build is anti-hallucination guarded (see §14.3).

### 7.7 `memories` — long-term per-user vector memory (Layer 3.3, deferred)

```sql
CREATE TABLE memories (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     text NOT NULL,
  kind        text NOT NULL DEFAULT 'turn' CHECK (kind IN ('turn','note','goal','correction')),
  content     text NOT NULL,                   -- natural-language summary
  embedding   vector(1536),                    -- OpenAI text-embedding-3-small dim
  source_turn uuid REFERENCES turns(id) ON DELETE SET NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX memories_user_idx ON memories(user_id, created_at DESC);

CREATE INDEX memories_embedding_idx
  ON memories USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
```

The `embedding` column is `vector(1536)` (OpenAI `text-embedding-3-small`). **You can't mix dimensions in one column** — if you switch to `bge-small` (384-dim) or `text-embedding-3-large` (3072-dim), change the dimension ([SUPABASE_SETUP.md:668-692](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L668)). The IVFFlat index uses `lists ≈ sqrt(N_rows)`; **start with 100, recreate when crossing 10K rows** ([SUPABASE_SETUP.md:684-689](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L684)).

### 7.8 `events` — generic event log

```sql
CREATE TABLE events (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id   text NOT NULL REFERENCES devices(device_id) ON DELETE CASCADE,
  user_id     text,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  kind        text NOT NULL,                  -- 'wake' | 'cancel' | 'ws_close' | 'ws_open' | 'reboot' | …
  payload     jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX events_device_idx ON events(device_id, occurred_at DESC);
CREATE INDEX events_kind_idx   ON events(kind, occurred_at DESC);
CREATE INDEX events_at_brin    ON events USING BRIN(occurred_at);
```

New event types need **no migration** — just write a new `kind` string + structured fields in `payload` ([SUPABASE_SETUP.md:694-711](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L694)). Kinds in use: `paired · unlinked · ws_open · ws_close · reboot · cancel · button` ([SUPABASE_QUERIES.md:388-389](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L388)).

### 7.9 `cost_log` — per-API-call cost ledger (optional)

```sql
CREATE TABLE cost_log (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  turn_id      uuid REFERENCES turns(id) ON DELETE SET NULL,
  user_id      text,
  occurred_at  timestamptz NOT NULL DEFAULT now(),
  provider     text NOT NULL,            -- 'gemini' | 'openai' | 'cartesia' | 'groq' | …
  kind         text NOT NULL,            -- 'llm' | 'tts' | 'stt' | 'embed' | 'image'
  input_units  int,
  output_units int,
  cost_usd     numeric(10, 6)
);

CREATE INDEX cost_log_user_at_idx ON cost_log(user_id, occurred_at DESC) WHERE user_id IS NOT NULL;
CREATE INDEX cost_log_at_brin     ON cost_log USING BRIN(occurred_at);
```

Skip in v1 (compute `cost_usd` from `turns` columns directly); add when there are multiple cost sources per turn (LLM + TTS + STT) ([SUPABASE_SETUP.md:713-732](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L713)).

### 7.10 `admins` — admin allowlist (from admin_setup.sql)

Created by `scripts/admin_setup.sql` (and auto-created by SQLAlchemy `create_all`). One row per Clerk user permitted to open `/admin` (see §18 for the full treatment) ([scripts/admin_setup.sql:24-29](../../Smart-Tutor-Lamp-backend/scripts/admin_setup.sql#L24)):

```sql
create table if not exists admins (
  user_id    text primary key,                 -- Clerk user id "user_2abc…"
  email      text,                             -- lower-cased; for display + email-allowlist match
  note       text,                             -- free-form ("founder", "auto-seeded from env", …)
  created_at timestamptz not null default now()
);
create index if not exists admins_email_idx on admins(email) where email is not null;
```

### 7.11 `turn_traces` and `storage.objects` (referenced)

The queries doc references two more relations that store media metadata: **`turn_traces`** (admin-drawer trace media: `raw_image_url`, `enhanced_image_url`, `raw_audio_url`, `source`, `extracted_ocr_text`, `bounding_box`) and Supabase's built-in **`storage.objects`** (bucket file metadata). These are covered in §21.

---

## 8. Indexes — what each one pays for

### 8.1 `turns` indexes (the index inventory)

The full set ([SUPABASE_SETUP.md:545-596](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L545)):

| Index | Type | Purpose |
|---|---|---|
| `turns_device_idx` `(device_id, asked_at DESC)` | B-tree | Hottest: "this device's last N turns". Never drop. |
| `turns_user_idx` `(user_id, asked_at DESC) WHERE user_id IS NOT NULL` | partial B-tree | Frontend `/history` page |
| `turns_session_idx` `(session_id, turn_index)` | B-tree | Compaction / session replay (ordered) |
| `turns_decay_idx` `(session_id, decay_resistance DESC) WHERE decay_resistance > 0.7` | partial B-tree | Smart-compaction keeper lookup |
| `turns_latex_gin` `USING GIN(latex_equations)` | GIN | "Which turns emitted this/any equation" |
| `turns_asked_at_brin` `USING BRIN(asked_at)` | BRIN | Time-range analytics — 1000× smaller than B-tree |
| `turns_subject_idx` `(subject, asked_at DESC) WHERE subject IS NOT NULL AND status = 'ok'` | partial B-tree | Subject-mix dashboards |
| `turns_error_idx` `(asked_at DESC) WHERE status <> 'ok'` | partial B-tree | Error monitoring (sparse, tiny) |
| `turns_tier_at_idx` `(final_tier, asked_at DESC) WHERE final_tier IS NOT NULL` | partial B-tree | Tier-mix + cost-per-tier rollups |
| `turns_escalated_idx` `(asked_at DESC) WHERE escalated = true` | partial B-tree | "How often does it escalate, by week" |
| `turns_escalation_path_gin` `USING GIN(escalation_path)` | GIN | "How often was tier-3 the final hop" |
| `turns_extra_gin` `USING GIN(extra)` | GIN | JSONB key-existence queries |
| `turns_cost_breakdown_gin` `USING GIN(cost_usd_breakdown)` | GIN | Per-cost-line tier-4 queries |
| `turns_request_id_idx` `(request_id) WHERE request_id IS NOT NULL` | partial B-tree | Log line → row debugging |
| `turns_ab_test_idx` `(ab_test_arm, asked_at DESC) WHERE ab_test_arm IS NOT NULL` | partial B-tree | A/B cohort rollups |

The doc's "Why each index pays off" table ([SUPABASE_SETUP.md:600-612](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L600)) gives a drop-condition for each (e.g. `turns_device_idx` "Never. Drop = O(N) scan on every turn lookup").

### 8.2 Why the future-proof columns pay off

The companion table ([SUPABASE_SETUP.md:614-635](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L614)) quantifies each added column's NULL storage cost (mostly 1 byte): `request_id` (1 B), `final_tier` (1 B), `escalation_path` (1 B empty-array overhead), `escalated` (1 B), `llm_thinking_tok` (1 B — "the very metric that bit us in the JSON-truncation bug"), `cost_usd_breakdown` (1 B empty JSONB), `client_fw_version` (1 B), `wifi_rssi_dbm` (1 B smallint), `image_enhanced` (1 B), `cancel_source` (1 B), `ab_test_arm` (1 B), `audio_duration_s`/`image_bytes_in`/`image_bytes_clean` (4-5 B each), `turn_index` (4 B), `latex_equations` (~16 B empty array), `decay_resistance` (2 B), `speech` (inline text).

---

## 9. Row-Level Security (RLS)

### 9.1 Design

The future use case: the Next.js `/history` page reads `turns` for the logged-in user **directly** via Supabase's auto-generated REST API, no backend hop. RLS makes that safe. The **backend always uses the service role key, which bypasses RLS**, so backend writes are unaffected ([SUPABASE_SETUP.md:734-738](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L734)).

### 9.2 Enable RLS on every table

```sql
ALTER TABLE devices      ENABLE ROW LEVEL SECURITY;
ALTER TABLE turns        ENABLE ROW LEVEL SECURITY;
ALTER TABLE memories     ENABLE ROW LEVEL SECURITY;
ALTER TABLE events       ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions      ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_memory   ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE pairing_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE cost_log      ENABLE ROW LEVEL SECURITY;
```

`pairing_codes` + `cost_log` get **RLS-enabled but NO policy on purpose** — RLS-on + no-policy = **deny-all** to the anon/authenticated roles, the correct lockdown for backend-only tables. The backend's service_role key bypasses RLS, so it still reads/writes them freely. This also clears the linter's "RLS enabled no policy" INFO ([SUPABASE_SETUP.md:740-756](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L740)).

### 9.3 SELECT policies — the wrapped `auth.jwt()` pattern

**Performance-critical detail:** wrap `auth.jwt()` in a scalar `(SELECT …)` so Postgres evaluates it **once per query (initplan)** rather than once per row — this clears advisor lint 0003 (`auth_rls_initplan`) and matters at scale. **Always use the wrapped form** ([SUPABASE_SETUP.md:762-764](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L762)).

```sql
CREATE POLICY "users see their own devices"
  ON devices FOR SELECT
  USING (user_id = (SELECT auth.jwt()->>'sub') AND revoked_at IS NULL);

CREATE POLICY "users see their own turns"
  ON turns FOR SELECT USING (user_id = (SELECT auth.jwt()->>'sub'));

CREATE POLICY "users see their own memories"
  ON memories FOR SELECT USING (user_id = (SELECT auth.jwt()->>'sub'));

CREATE POLICY "users see their own events"
  ON events FOR SELECT USING (user_id = (SELECT auth.jwt()->>'sub'));

CREATE POLICY "users see their own sessions"
  ON sessions FOR SELECT USING (user_id = (SELECT auth.jwt()->>'sub'));

CREATE POLICY "users see their own memory profile"
  ON user_memory FOR SELECT USING (user_id = (SELECT auth.jwt()->>'sub'));

CREATE POLICY "users see their own profile"
  ON user_profiles FOR SELECT USING (user_id = (SELECT auth.jwt()->>'sub'));
```

The `devices` policy adds `AND revoked_at IS NULL` so unlinked devices vanish from the frontend. There are **no INSERT/UPDATE/DELETE policies** — frontend can ONLY read; writes go through the backend ([SUPABASE_SETUP.md:766-795](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L766)).

You can audit RLS state with `select relname, relrowsecurity from pg_class where relnamespace='public'::regnamespace and relkind='r'` and list policies with `select tablename, policyname, cmd, qual from pg_policies where schemaname='public'` ([SUPABASE_QUERIES.md:596-609](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L596)).

---

## 10. The Clerk ↔ Supabase JWT bridge

Supabase must validate Clerk's JWT. Two options ([SUPABASE_SETUP.md:797-805](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L797)):

1. **Use Clerk's "Supabase integration"** (recommended): Clerk → Integrations → enable Supabase → Clerk auto-mints a JWT with Supabase's signing key + a `sub` claim equal to the Clerk user ID. RLS matches `auth.jwt()->>'sub' = devices.user_id`. ← Use this.
2. Hand-roll: configure Supabase's JWT secret to Clerk's. Brittle, skip.

This is **deferred** — wire only when the frontend exists. Today the backend uses the service role key, so **no RLS check happens** on the hot path.

---

## 11. Materialized views

Pre-compute the dashboard queries so a Metabase/Grafana refresh is O(1) instead of O(N) ([SUPABASE_SETUP.md:807-849](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L807)).

### 11.1 `turns_daily` — daily metrics per device

```sql
CREATE MATERIALIZED VIEW turns_daily AS
SELECT
  date_trunc('day', asked_at)              AS day,
  device_id,
  user_id,
  count(*)                                 AS n_turns,
  count(*) FILTER (WHERE status = 'ok')    AS n_ok,
  count(*) FILTER (WHERE status <> 'ok')   AS n_err,
  count(*) FILTER (WHERE escalated)        AS n_escalated,
  count(*) FILTER (WHERE final_tier = 1)   AS n_tier1,
  count(*) FILTER (WHERE final_tier = 2)   AS n_tier2,
  count(*) FILTER (WHERE final_tier = 3)   AS n_tier3,
  count(*) FILTER (WHERE final_tier = 4)   AS n_tier4,
  percentile_cont(0.50) WITHIN GROUP (ORDER BY ttft_ms) FILTER (WHERE status='ok') AS p50_ttft,
  percentile_cont(0.95) WITHIN GROUP (ORDER BY ttft_ms) FILTER (WHERE status='ok') AS p95_ttft,
  percentile_cont(0.95) WITHIN GROUP (ORDER BY total_ms) FILTER (WHERE status='ok') AS p95_total,
  sum(cost_usd)                            AS cost_usd_total,
  sum(llm_input_tok)                       AS llm_in_tok_total,
  sum(llm_output_tok)                      AS llm_out_tok_total,
  sum(llm_thinking_tok)                    AS llm_thinking_tok_total
FROM turns
GROUP BY 1, 2, 3;

CREATE UNIQUE INDEX turns_daily_pk ON turns_daily(day, device_id);
```

Mechanics: `date_trunc('day', …)` buckets rows; `count(*) FILTER (WHERE …)` does conditional counts in a single pass; `percentile_cont(0.5|0.95) WITHIN GROUP (ORDER BY …)` computes interpolated median/p95 latency, filtered to `status='ok'`. The UNIQUE index is **required** for `REFRESH … CONCURRENTLY`.

### 11.2 `turns_subject_weekly` — subject mix per week per user

```sql
CREATE MATERIALIZED VIEW turns_subject_weekly AS
SELECT date_trunc('week', asked_at) AS week, user_id, subject, count(*) AS n_turns
FROM turns
WHERE user_id IS NOT NULL AND status = 'ok'
GROUP BY 1, 2, 3;

CREATE UNIQUE INDEX turns_subject_weekly_pk ON turns_subject_weekly(week, user_id, subject);
```

### 11.3 Refresh

Refreshed nightly via `workers/rollup.py`. `CONCURRENTLY` requires the UNIQUE indexes above ([SUPABASE_SETUP.md:852-858](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L852)):

```sql
REFRESH MATERIALIZED VIEW CONCURRENTLY turns_daily;
REFRESH MATERIALIZED VIEW CONCURRENTLY turns_subject_weekly;
```

The cookbook also shows the non-concurrent form for ad-hoc use: `refresh materialized view turns_daily;` ([SUPABASE_QUERIES.md:482-485](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L482)). These views are **stale until refreshed** ([SUPABASE_QUERIES.md:424](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L424)).

---

## 12. Normalization stance & the three deliberate denormalizations

The entities are in **3rd normal form**: each fact lives in exactly one place (`device_secret_hash` only in `devices`, pairing material only in `pairing_codes`, the spoken answer only in `turns.speech`, the profile only in `user_memory`). The schema then denormalizes in **exactly three spots**, each a conscious read-speed-for-write-cost trade ([SUPABASE_SETUP.md:870-888](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L870)):

| # | Denormalization | Why it's correct | Invariant that keeps it consistent |
|---|---|---|---|
| 1 | `user_id` copied onto `sessions`/`turns`/`user_memory`/`events` | Per-user reads + **RLS** must work without joining `devices` on every row | Backend stamps `user_id` **at write time** from the authenticated socket. Historical rows are **never rewritten** if the device is later re-paired — a turn keeps the `user_id` that owned it then (what analytics + GDPR want). |
| 2 | `sessions.turn_count` / `primary_subject` / `avg_difficulty` | The session-resume + profile-load hot path must not `COUNT(*)`/`GROUP BY turns` | Updated **in the same transaction** as each turn insert (`_db_increment_session`). |
| 3 | `turns.cost_usd` | Dashboards `SUM(cost_usd)` must not unpack JSONB per row | Written together at persist time; breakdown is the audit trail, scalar is the index-friendly aggregate. |

Everything else stays normalized. In particular: **do not** copy `speech` / `display_content` / `latex_equations` into a second table — they're large and single-home. The Redis hot cache holds a *truncated* copy for speed, but Postgres `turns` is the single source of truth ([SUPABASE_SETUP.md:885-888](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L885)).

---

## 13. Hot path vs analytics — query-latency strategy

The single most important design fact: **this database serves two workloads with opposite priorities** ([SUPABASE_SETUP.md:860-868](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L860)):

| Workload | Latency budget | Runs… | Examples |
|---|---|---|---|
| **Hot path (session)** | **< ~10 ms** (inside the per-turn LLM TTFT budget) | BEFORE / during a turn | resolve active session, load profile + session summary for the prompt |
| **Analytics** | seconds is fine | nightly / on dashboard open, never on a turn | tier-mix rollups, p95 latency, subject mix, cost trends |

### 13.1 Hot-path techniques

The two reads before the LLM call (`SessionMemoryService.load_context`) must be PK/unique lookups, parallel, tiny rows ([SUPABASE_SETUP.md:890-912](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L890)):

1. **Key-lookups only — never a scan, never an aggregate.** `user_memory` by `device_id` (UNIQUE → index-only equality); `sessions.summary` by `id` (PK). The hot path never touches `turns` for reads (recent turns come from Redis, or one bounded index read).
2. **Parallel fetch.** `load_context` `asyncio.gather`s the profile read and the session-summary read — two round-trips become one wall-clock latency.
3. **Tiny rows by construction.** Char caps (profile ≤ 240, summary ≤ 480) enforced at write time — reads move ~1 KB total.
4. **`SELECT` only the needed columns** (never `SELECT *` on the hot path).
5. **Keep the pool warm.** `create_async_engine(pool_size=10, pool_pre_ping=True)` — never open a connection per turn (TLS+auth handshake alone blows the 10 ms budget). In prod, front with PgBouncer.
6. **Co-locate** backend and Supabase region — a cross-region round-trip is 80-150 ms and instantly busts the budget.

### 13.2 Analytics techniques

Heavy `GROUP BY` / `percentile_cont` / window functions are fine — they run on the materialized views or ad-hoc in the SQL editor, never on a turn. **BRIN** on `asked_at`/`occurred_at` makes 90-day range scans cheap without bloating writes. When dashboards compete with writes, point Metabase/Grafana at a **read replica**. Rule: **if a hot-path value needs an aggregate, denormalize it** ([SUPABASE_SETUP.md:914-924](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L914)).

---

## 14. Algorithms — resume, compaction, profile-tiering, ANN, escalation

### 14.1 Reconnect / resume the active session (WIRED, no Redis needed)

This is what `app/storage/turns.py:open_session` runs on every WS connect — a bounded, index-backed query that **resumes** within the idle window ([SUPABASE_SETUP.md:926-957](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L926)):

```sql
SELECT id
FROM sessions
WHERE device_id = :d
  AND user_id IS NOT DISTINCT FROM :u           -- NULL matches NULL (dev mode)
  AND last_activity_at > now() - make_interval(mins => :m)   -- :m = 30
ORDER BY last_activity_at DESC
LIMIT 1;
-- hit  → resume it: clear ended_at, bump last_activity_at, write turns to it
-- miss → INSERT a fresh session row
```

Mechanics, step by step:
1. **Match key** is `(device_id, user_id)` where `user_id IS NOT DISTINCT FROM :u` — the `IS NOT DISTINCT FROM` operator makes `NULL` match `NULL` (dev mode where `user_id` is NULL), and ensures a device re-paired to a *different* user starts a **fresh** session (so history never bleeds across users).
2. **Idle window** is `last_activity_at > now() - 30 minutes` — it resumes on `last_activity_at` (bumped per turn), **NOT** on `ended_at IS NULL`, so a session survives the disconnect/reconnect cycle (we set `ended_at` on disconnect but clear it on resume).
3. **Order + limit** `ORDER BY last_activity_at DESC LIMIT 1` picks the single most-recent candidate.
4. **Hit** → resume (clear `ended_at`, bump `last_activity_at`); **miss** → `INSERT` a fresh session.

Constants: idle window `:m = 30` minutes. Supporting index: `sessions_resume_idx (device_id, last_activity_at DESC)`. No Redis required; when Redis lands it caches the resolved session id in front of this query.

### 14.2 Smart compaction & `decay_resistance` (the keeper algorithm)

`decay_resistance` is a 0.0-1.0 importance anchor **derived at write-time from `query_type` + `difficulty`**, default `0.5` ([SUPABASE_SETUP.md:490-492](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L490)). The quoted endpoints: **`0.9` = hard derivation kept verbatim**, **`0.15` = easy check decays first**. The `sessions.summary` format is `"KEY_FACTS:\n<verbatim keepers>\n\nSUMMARY:\n<prose>"` and covers turns `1..(turn_count - TAIL_SIZE)` ([SUPABASE_SETUP.md:406-408](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L406)). `summary_as_of` stores the `turn_count` at last compaction to **prevent re-compaction**. The keeper lookup (turns that resist decay) is served by the partial index `turns_decay_idx (session_id, decay_resistance DESC) WHERE decay_resistance > 0.7` — the `> 0.7` threshold defines a "keeper". The `latex_equations` are stored verbatim so the keeper logic can re-inject **exact formulas** rather than the TTS paraphrase. Compaction kicks in past `MEMORY_COMPACT_THRESHOLD` (the cookbook's compaction-health query uses `turn_count >= 8`) ([SUPABASE_SETUP.md:1584-1591](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1584)).

### 14.3 User-memory profile tiering (anti-hallucination guard)

The `user_memory.long_term_summary` build uses a 3-tier rule based on turn count ([SUPABASE_SETUP.md:663-666](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L663)):

- **`< 3` turns** → **no profile**.
- **`3-9` turns** → **template** (numbers only, no LLM).
- **`≥ 10` turns** → **LLM-generated** with a strict "report only the numbers" prompt.

(See `SESSION_MEMORY_GUIDE.md` §4 `_update_user_memory` / `_call_profile_llm`.)

### 14.4 Vector ANN search (pgvector cosine)

The deferred semantic-memory query ([SUPABASE_SETUP.md:1466-1471](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1466)):

```sql
SELECT id, content, 1 - (embedding <=> $1::vector) AS similarity
FROM memories
WHERE user_id = $2
ORDER BY embedding <=> $1::vector
LIMIT 5;
```

`<=>` is pgvector's **cosine distance** operator; `1 - distance` gives cosine similarity in `[-1, 1]` (1 = identical) ([SUPABASE_SETUP.md:1602](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1602)). The IVFFlat index (`lists = 100`) approximates the nearest neighbours; `ORDER BY embedding <=> $1` is the ANN scan, `LIMIT 5` returns the top-5 closest memories for that user.

### 14.5 Escalation tiering (how `final_tier`/`escalation_path` are produced)

The LLM self-classifies (`confidence`, `query_type`, `subject`, `difficulty`), which **drives the orchestrator's tier router** ([SUPABASE_SETUP.md:485-492](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L485)). `final_tier` (1-4) is which tier produced the shipped reply; `escalation_path` is the array of tiers attempted (e.g. `['tier1','tier2']`, or `['tier1','tier3']` for smart-skip). `escalated` is the denormed `array_length(escalation_path) > 1`. The cost of each tier hop is itemised in `cost_usd_breakdown`. (Full router logic lives in `ESCALATION_PLAN.md` §2.8 — not in these files.)

---

## 15. The Redis accelerator seam

**Redis is fully wired in code** as the L1 hot layer, **with Supabase as the durable source of truth and automatic fallback**. It is *optional at runtime*: set `REDIS_URL` to turn it on, leave it blank to run Supabase-only — both paths are fully conversational. **No schema change either way** ([SUPABASE_SETUP.md:975-982](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L975)).

### 15.1 The switch & the seam

`.env`: `REDIS_URL=rediss://default:<pwd>@<host>:6379/0` (Upstash / self-hosted); `pip install "redis[hiredis]"`. `app/main.py`'s lifespan does `if settings.REDIS_URL: await init_redis()` (eager PING, logs `✓ Redis ready`). The single cache seam is `app/services/cache.py` (`cget`/`cset`/`cdel`), **all no-ops that return a miss when Redis is off**; the shared client is opened by `app.services.revocation` ([SUPABASE_SETUP.md:984-1003](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L984)).

### 15.2 What Redis accelerates (and source-of-truth fallback)

Four concerns, each with a Postgres source of truth behind it ([SUPABASE_SETUP.md:1005-1012](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1005)):

| Concern | Source of truth (always) | Redis role |
|---|---|---|
| Active session id | `sessions` resume query (§14.1) | `GET/SET lamp:sid:{device_id}` (TTL = idle+5 min) — cache hits re-validate `user_id` + idle |
| Rate-limit buckets | n/a (counters) | shared bucket store across uvicorn workers (`deps/rate_limit.py`, `settings.REDIS_URL or "memory://"`) |
| Revocation fan-out | `devices.revoked_at` (canonical) | `device:revoked:<id>` pub/sub → sub-second unlink vs the ≤30 s heartbeat |
| L1 recent-turns history | `turns` table (`load_recent_turns`) | `LPUSH/LTRIM lamp:hist:{device_id}` write-through list; backfills from Supabase on a Redis miss |

### 15.3 Invariants that keep the flip safe

([SUPABASE_SETUP.md:1014-1023](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1014)):
- **Postgres stays the source of truth.** Every Redis read has a Postgres fallback; every Redis write is a *copy* of a row already persisted. Lose Redis at any moment → degrade to today's behavior, **no data loss**.
- **Cache entries are user-validated, not trusted.** `open_session` re-checks the cached session's `user_id` + freshness before reuse — a stale/cross-user cache entry can't leak.
- **TTLs, not manual invalidation, drive correctness.** The session-id key outlives the idle window; the history list self-trims. `clear_history`/`cdel` on unlink are belt-and-suspenders.

**What you must do in Supabase: NOTHING new — zero schema change.** Redis caches the `sessions`/`turns` rows; it never replaces them ([SUPABASE_SETUP.md:1036-1043](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1036)).

---

## 16. Phase 4 — Alembic migrations

You could apply the DDL directly via the SQL editor, but Alembic gives idempotent up/down migrations, git-versioned schema, and autogeneration ([SUPABASE_SETUP.md:1056-1062](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1056)).

### 16.1 Init & wiring

`alembic init -t async app/db/migrations` creates `env.py`, `script.py.mako`, `versions/`, and `alembic.ini` ([SUPABASE_SETUP.md:1063-1078](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1063)). Clear the hard-coded `sqlalchemy.url` in `alembic.ini` and load it from env in `env.py` via `config.set_main_option("sqlalchemy.url", settings.DATABASE_URL)`; the async `run_migrations_online` uses `async_engine_from_config(..., poolclass=pool.NullPool)` ([SUPABASE_SETUP.md:1080-1138](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1080)).

### 16.2 Autogenerate caveat (the critical limitation)

`alembic revision --autogenerate` ([SUPABASE_SETUP.md:1140-1180](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1140)):
- ✅ Picks up new tables / columns / indexes
- ❌ **Misses CHECK constraints, partial indexes, BRIN/GIN/IVFFlat indexes, materialized views**

You must hand-edit `upgrade()` with `op.execute(...)` for: the BRIN/partial/GIN indexes (`turns_asked_at_brin`, `turns_error_idx`, `turns_subject_idx`, `turns_extra_gin`, `turns_latex_gin`, `turns_decay_idx`, `sessions_resume_idx`), `CREATE EXTENSION IF NOT EXISTS vector` + the IVFFlat index, and the materialized views. `downgrade()` drops them in reverse order. Apply with `alembic upgrade head` ([SUPABASE_SETUP.md:1182-1188](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1182)).

### 16.3 ORM models

`app/db/models.py` currently defines only `Device` + `PairingCode`; the **authoritative** `SessionRecord`/`TurnRecord`/`UserMemory` definitions live in `SESSION_MEMORY_GUIDE.md` §3 (with `speech`, `latex_equations`, `turn_index`, `decay_resistance`, the `sessions.summary` fields, and the whole `user_memory` table) — copy them verbatim. The abbreviated `Turn` example shows the SQLAlchemy 2.0 typed-mapping shape (`Mapped[...] = mapped_column(...)`) ([SUPABASE_SETUP.md:1190-1236](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1190)).

---

## 17. Phase 5 — Wiring the backend (session factory + write_turn)

### 17.1 `app/db/session.py` — the async session factory

`init_db(create_tables=False)` builds the engine with `pool_size=10`, `max_overflow=5`, `pool_pre_ping=True`, `echo=False`; `async_sessionmaker(_engine, expire_on_commit=False)`; the FastAPI `get_db` dependency yields a session ([SUPABASE_SETUP.md:1242-1282](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1242)). The pool comment: Supabase free tier allows up to ~60 concurrent — keep room for migrations + workers.

`app/main.py` lifespan should open the engine when DB is configured ([SUPABASE_SETUP.md:1284-1291](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1284)):

```python
if settings.ENABLE_AUTH or settings.DATABASE_URL:
    from app.db.session import init_db
    await init_db(create_tables=False)    # Alembic owns DDL — never auto-create in prod
    log.info("✓ DB ready")
```

### 17.2 `app/storage/turns.py:write_turn` — the analytics insert

Replaces the `NotImplementedError` stub. Inserts the full `turns` row, pulling most fields straight from the orchestrator's `telemetry` dict ([SUPABASE_SETUP.md:1293-1364](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1293)). Key field mappings:
- `speech=reply.speech` (unified to match `LlmReply.speech`)
- `display_kind=reply.display.kind` (`'text'`|`'none'`, no `'latex'`)
- `latex_equations=reply.latex_equations or []`
- `llm_thinking_tok=telemetry.get("llm_thinking_tok")` (may be `None` for non-Gemini)
- `escalated=len(escalation_path or []) > 1`
- `status=telemetry.get("status") or "ok"`

**Critical error-handling invariant:** the whole insert is wrapped in `try/except Exception` that logs and **swallows** — *"Swallow — persistence MUST NOT break the response path."* ([SUPABASE_SETUP.md:1361-1364](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1361)). The orchestrator passes `final_tier` (which tier shipped) + `escalation_path` (tiers attempted).

### 17.3 Wiring into `orchestrator._persist_turn`

`_persist_turn` generates `turn_id = uuid.uuid7() if hasattr(uuid,'uuid7') else uuid.uuid4()`, pushes Redis history, optionally uploads blobs (`blobs.upload_audio`/`upload_image`), then calls `turns.write_turn(...)` with `user_id=None` (filled when `ENABLE_AUTH=True`) ([SUPABASE_SETUP.md:1370-1393](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1370)).

### 17.4 Supabase Storage for blobs (optional)

Create a **private** bucket `lumos-turns`, get the project URL + **service role key**, add `SUPABASE_URL` / `SUPABASE_SERVICE_KEY` / `SUPABASE_STORAGE_BUCKET` to `.env`, `pip install supabase storage3`, and implement `app/storage/blobs.py:upload_audio`. For the per-user history view, generate **signed download URLs (1-hour expiry)** via `create_signed_url`; the frontend never sees the bucket directly ([SUPABASE_SETUP.md:1395-1410](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1395)). (Note: §21's runtime cookbook describes the actual bucket as `turn-media` with `STORAGE_BACKEND=s3` — see §21.)

---

## 18. The admin allowlist & admin_setup.sql

### 18.1 What `scripts/admin_setup.sql` does

Run ONCE in the Supabase SQL Editor. It (1) creates the `admins` allowlist table, (2) enables RLS on it with **NO** anon/authenticated policy → deny-all to public roles (readable/writable only by the backend's privileged role, exactly like `pairing_codes`/`cost_log`), and (3) seeds the first admin ([scripts/admin_setup.sql:1-22](../../Smart-Tutor-Lamp-backend/scripts/admin_setup.sql#L1)).

**The file is OPTIONAL** — the backend ALSO auto-creates this table via SQLAlchemy `Base.metadata.create_all` on boot (`app/db/models.py:Admin`) and auto-seeds any user in the `ADMIN_USER_IDS`/`ADMIN_EMAILS` env allowlist on their first admin-authenticated request. The file's real value is (a) turning on RLS (`create_all` does **not** set RLS) and (b) seeding an admin purely in SQL with no env edit. The admin read endpoints do **not depend on RLS** (the backend uses a privileged role that bypasses it); RLS here is **defense-in-depth** so the table is never world-readable via PostgREST ([scripts/admin_setup.sql:14-21](../../Smart-Tutor-Lamp-backend/scripts/admin_setup.sql#L14)).

### 18.2 Table + index + RLS

```sql
create table if not exists admins (
  user_id    text primary key,                 -- Clerk user id "user_2abc…"
  email      text,                             -- lower-cased; for display + email-allowlist match
  note       text,                             -- free-form
  created_at timestamptz not null default now()
);
create index if not exists admins_email_idx on admins(email) where email is not null;
alter table admins enable row level security;
```

([scripts/admin_setup.sql:24-35](../../Smart-Tutor-Lamp-backend/scripts/admin_setup.sql#L24)). The partial `admins_email_idx` supports the email-match path (matching `lower(email)`).

### 18.3 Seeding the first admin

```sql
insert into admins (user_id, email, note)
values
  ('admin:ayushmaiti.startups@gmail.com', 'ayushmaiti.startups@gmail.com', 'first admin (seed)')
on conflict (user_id) do nothing;
```

([scripts/admin_setup.sql:37-47](../../Smart-Tutor-Lamp-backend/scripts/admin_setup.sql#L37)). The seed comment explains: `user_id` is optional if you only know the email (the backend matches by **EITHER** `user_id` **or** `lower(email)`); but every row needs its PK, so **use the email as the key (e.g. `admin:<email>`) until you know the real Clerk id**. Easiest alternative: leave `ADMIN_EMAILS` to auto-seed the real row on first login. `on conflict (user_id) do nothing` makes the seed idempotent.

### 18.4 The admin gate (how the table is enforced)

The gate is `app/services/admin.py:is_admin`, which returns true **only** when the Clerk `user_id` is in this table **or** `lower(email)` matches a row. There is **NO `.env` fallback** — `ADMIN_USER_IDS`/`ADMIN_EMAILS` are no longer consulted at gate-check time; **this table is the single source of truth** ([SUPABASE_QUERIES.md:717-726](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L717)). `GET /api/frontend/me` returns `is_admin`; the Next.js `/admin` page calls `requireAdmin()` and bounces non-admins to `/dashboard`; and **every** `/api/frontend/admin/*` endpoint re-checks `require_admin` server-side (403 `NOT_ADMIN` otherwise). So a normal user — even hitting the API directly — only ever sees their own data.

### 18.5 Admin SQL operations (from §14 of the cookbook)

- **List admins** ([SUPABASE_QUERIES.md:682-686](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L682)): `select user_id, email, note, created_at from admins order by created_at;`
- **Does the table exist?** ([SUPABASE_QUERIES.md:690-693](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L690)): `select to_regclass('public.admins') as admins_table, (select count(*) from admins) as admin_rows;` — `to_regclass` returns the table name if it exists, NULL otherwise.
- **Full admin inspection** ([SUPABASE_QUERIES.md:701-714](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L701)): joins `admins` to `user_profiles` (`has_profile`), counts paired lamps, and finds `last_active` via `max(t.asked_at)`.
- **Verify a specific person** ([SUPABASE_QUERIES.md:730-735](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L730)) — mirrors `is_admin()` exactly:
  ```sql
  select exists (
    select 1 from admins
    where user_id = '<clerk_user_id>' or lower(email) = lower('<email>')
  ) as is_admin;
  ```
- **Promote / revoke** ([SUPABASE_QUERIES.md:738-746](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L738)): `insert into admins (...) values (...) on conflict (user_id) do nothing;` / `delete from admins where user_id = 'user_2abc…';`

### 18.6 What each `/admin` dashboard panel runs

The admin endpoints are the **system-wide** form of the per-user cookbook queries — same shape, no `WHERE user_id = …` filter. Backed by `app/services/admin.py` ([SUPABASE_QUERIES.md:753-772](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L753)):

| Panel | Endpoint | Cookbook query (un-scoped) |
|---|---|---|
| Overview cards + health | `GET /api/frontend/admin/overview` | §1 health + online lamps |
| Activity timeline + mixes | `GET /api/frontend/admin/overview` | §5/§9 daily turns + subject/difficulty/query-type/status/tier |
| Cost + tokens | `GET /api/frontend/admin/overview` | §7 spend + token totals |
| Event-kind counts | `GET /api/frontend/admin/overview` | §8 `select kind, count(*) … group by kind` |
| Users table | `GET /api/frontend/admin/users` | §2 + §11 per-user devices/turns/cost/last-active |
| Devices table | `GET /api/frontend/admin/devices` | §3 pairing view + online flag |
| Sessions table | `GET /api/frontend/admin/sessions` | §4 recent sessions |
| Turns feed (filterable) | `GET /api/frontend/admin/turns?user_id=&status=` | §5 latest turns + §10 errors |
| Events log | `GET /api/frontend/admin/events` | §8 recent events |

**Every admin query is wrapped in a SAVEPOINT**, so a not-yet-migrated optional table (`memories`, `cost_log`) degrades that one panel to empty/zero instead of failing the page ([SUPABASE_QUERIES.md:770-772](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L770)).

---

## 19. Operational SQL cookbook (SUPABASE_QUERIES.md)

These are copy-paste queries for the Supabase SQL Editor. The SQL Editor runs as a privileged role and **sees all rows** regardless of RLS ([SUPABASE_QUERIES.md:1-9](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L1)). Placeholders `'<clerk_user_id>'` / `'<device_id>'` / `'<session_uuid>'` are pulled from discovery queries (§0.1) — **they are NOT in `.env`** (which holds the Clerk *secret key*, a server credential, not a user id) ([SUPABASE_QUERIES.md:29-54](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L29)). Note: `left(col, 80)` in many queries is **display-only**, not storage — the full text is stored; read it bare via `select asked_at, speech from turns …` ([SUPABASE_QUERIES.md:55-58](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L55)).

### 19.1 §1 — Quick health snapshot

A one-row overview using ten correlated subqueries ([SUPABASE_QUERIES.md:64-77](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L64)): `users_onboarded`, `devices_total`, `devices_paired` (`user_id is not null and revoked_at is null`), `devices_revoked`, `pairing_codes_live` (`status='pending' and expires_at > now()`), `sessions_total`, `turns_total`, `turns_failed` (`status <> 'ok'`), `memories_total`, `events_total`. A second query lists row counts + on-disk size per table by joining `pg_stat_user_tables` to `pg_class` and `pg_size_pretty(pg_total_relation_size(c.oid))` ([SUPABASE_QUERIES.md:79-88](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L79)).

### 19.2 §2 — Users & logins

- All onboarded users (newest first) ([SUPABASE_QUERIES.md:94-100](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L94)).
- Users who started but did NOT finish onboarding (`onboarding_complete = false`) ([SUPABASE_QUERIES.md:102-108](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L102)).
- **"Login/activity" proxy** — there is no auth table, so activity is inferred by left-joining `sessions` and `events`, sorting by `greatest(coalesce(max(...),'epoch'), …)` ([SUPABASE_QUERIES.md:110-122](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L110)).
- Everything for one user: `select * from user_profiles where user_id = '…'; select * from user_memory where user_id = '…';` ([SUPABASE_QUERIES.md:124-128](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L124)).

### 19.3 §3 — ESP32 pairing

- Main pairing view computing `is_paired` (`user_id is not null and revoked_at is null`) and `online_now` (`last_seen_at > now() - interval '60 seconds'`) ([SUPABASE_QUERIES.md:135-142](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L135)).
- User ↔ paired lamp join (LEFT JOIN so users with no lamp still appear) ([SUPABASE_QUERIES.md:145-153](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L145)).
- In-flight pairing codes (`still_valid`, `jwt_minted`) ([SUPABASE_QUERIES.md:161-168](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L161)).
- Stuck/abandoned pairings (`status='pending' and expires_at < now()`) ([SUPABASE_QUERIES.md:171-176](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L171)).
- Online lamps right now (60-s heartbeat window) ([SUPABASE_QUERIES.md:179-185](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L179)).
- Revoked/unlinked lamps (`revoked_at is not null`) ([SUPABASE_QUERIES.md:188-192](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L188)).

### 19.4 §4 — Sessions

- Recent sessions with `has_summary` ([SUPABASE_QUERIES.md:200-206](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L200)).
- Currently "open" sessions (`ended_at is null and last_activity_at > now() - interval '30 minutes'`) ([SUPABASE_QUERIES.md:210-215](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L210)) — the 30-min window matches the resume algorithm (§14.1).
- All sessions for one user ([SUPABASE_QUERIES.md:219-224](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L219)).
- Session L2 summaries (`where summary is not null`) ([SUPABASE_QUERIES.md:228-232](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L228)).

### 19.5 §5 — Conversations (stored turns)

The key semantic note: **`transcript` = what the USER said (STT); `speech` = what the LAMP replied (TTS text)** ([SUPABASE_QUERIES.md:240-241](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L240)).
- Full conversation for one session, ordered by `turn_index` ([SUPABASE_QUERIES.md:241-252](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L241)).
- Latest 30 turns across the system ([SUPABASE_QUERIES.md:256-263](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L256)).
- Full transcript for one user across all sessions (join `sessions`) ([SUPABASE_QUERIES.md:267-274](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L267)).
- Turns that produced LaTeX (`jsonb_array_length(latex_equations) > 0`) ([SUPABASE_QUERIES.md:278-284](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L278)).
- Everything for one turn: `select * from turns where id = '<turn_uuid>';` ([SUPABASE_QUERIES.md:288-289](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L288)).
- **Web simulator turns only** (`extra->>'source' = 'simulation'`; synthetic `device_id` = `websim-<user>`, real lamps `lamp-XXXXXX`) ([SUPABASE_QUERIES.md:293-304](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L293)).
- Lamp vs simulation split per user (`count(*) filter (where extra->>'source' = 'simulation')`) ([SUPABASE_QUERIES.md:307-312](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L307)).

### 19.6 §6 — Memory

- L3 learner profile per lamp (`long_term_summary`, `subject_profile`) ([SUPABASE_QUERIES.md:320-324](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L320)).
- L3.3 semantic memories (`kind ∈ turn|note|goal|correction`; `embedding is not null` confirms presence) ([SUPABASE_QUERIES.md:328-336](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L328)).

### 19.7 §7 — Cost & usage

- Per-turn LLM cost (most expensive first, `where cost_usd is not null order by cost_usd desc nulls last`) ([SUPABASE_QUERIES.md:344-351](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L344)).
- Spend per user (`round(sum(cost_usd)::numeric, 4)`) ([SUPABASE_QUERIES.md:355-363](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L355)).
- Itemised cost ledger from `cost_log` ([SUPABASE_QUERIES.md:367-372](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L367)).
- Daily spend trend (`date_trunc('day', asked_at)::date`) ([SUPABASE_QUERIES.md:376-381](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L376)).

### 19.8 §8 — Events / audit log

- Recent lifecycle events (newest first) ([SUPABASE_QUERIES.md:391-396](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L391)).
- Connectivity log for one lamp (`kind in ('ws_open','ws_close','reboot')`) ([SUPABASE_QUERIES.md:400-404](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L400)).
- Pairing/unlinking history (`kind in ('paired','unlinked')`) ([SUPABASE_QUERIES.md:408-412](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L408)).
- Event counts by kind (`group by kind order by count(*) desc`) ([SUPABASE_QUERIES.md:416-417](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L416)).

### 19.9 §9 — Analytics & multi-image (materialized views + `extra`)

Multi-image note: the lamp can attach 1..5 images per turn; `turns.image_url` holds the FIRST URL (back-compat), the full list is in `turns.extra.image_urls`, count in `turns.extra.image_count` ([SUPABASE_QUERIES.md:426-430](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L426)). Queries: image-count distribution over 14 days ([SUPABASE_QUERIES.md:432-438](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L432)), multi-image turns (`coalesce((extra->>'image_count')::int, 0) >= 2`) ([SUPABASE_QUERIES.md:440-450](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L440)), per-user multi-image adoption ([SUPABASE_QUERIES.md:452-460](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L452)), per-day/per-lamp rollup from `turns_daily` ([SUPABASE_QUERIES.md:463-472](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L463)), per-week subject mix from `turns_subject_weekly` ([SUPABASE_QUERIES.md:474-479](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L474)), and the refresh statements ([SUPABASE_QUERIES.md:481-485](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L481)).

### 19.10 §10 — Errors & debugging

- Failed/non-OK turns (`status <> 'ok'`; the comment lists all 9 statuses) ([SUPABASE_QUERIES.md:491-499](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L491)).
- Failure breakdown by status (`group by status`) ([SUPABASE_QUERIES.md:502-504](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L502)).
- Two-tier escalations (`escalated = true`) ([SUPABASE_QUERIES.md:507-514](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L507)).
- Slowest turns (`order by total_ms desc nulls last`) ([SUPABASE_QUERIES.md:517-522](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L517)).
- Firmware/signal diagnostics (`client_fw_version`, `wifi_rssi_dbm`) ([SUPABASE_QUERIES.md:525-531](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L525)).

### 19.11 §11 — One-shot "everything about X"

Two `UNION ALL` queries packing each related row via `to_jsonb(...)`: everything about one user (profile + device + session + memory) ([SUPABASE_QUERIES.md:538-546](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L538)) and everything about one lamp (device + session + event) ([SUPABASE_QUERIES.md:549-556](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L549)).

### 19.12 §12 — Integrity & completeness checks

The integrity suite ([SUPABASE_QUERIES.md:563-614](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L563)):
- **Orphan turns** — a turn whose `session_id` points at no session (LEFT JOIN, `s.id is null`).
- **Orphan sessions** — `device_id` not in `devices` (should be empty given the FK).
- **Turn-count drift** — `sessions.turn_count` vs `count(t.id)` via `having s.turn_count <> count(t.id)` (validates denormalization #2's invariant from §12).
- **Paired lamps whose user has no profile** (pairing without onboarding).
- **RLS sanity** — `pg_class.relrowsecurity`.
- **List all RLS policies** — `pg_policies`.
- **Confirm extensions** — `pg_extension`.

---

## 20. Analytics queries you'll actually run (Phase 6)

The setup doc's Phase 6 ([SUPABASE_SETUP.md:1414-1602](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1414)) ships 18 dashboard-grade queries. Highlights and their mechanics:

1. **Today's turn count + p95 latency** — `percentile_cont(0.95) WITHIN GROUP (ORDER BY total_ms)`, `status='ok'`, last 24h ([SUPABASE_SETUP.md:1419-1424](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1419)).
2. **Hot lamps last week** — join `devices`↔`turns`, group, top 20 ([SUPABASE_SETUP.md:1426-1433](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1426)).
3. **Subject mix for one user this month** — `asked_at >= date_trunc('month', now())` ([SUPABASE_SETUP.md:1435-1442](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1435)).
4. **Error rate by status, last 24h** — window-function percentage `100.0*count(*)/sum(count(*)) OVER ()` ([SUPABASE_SETUP.md:1444-1450](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1444)).
5. **Daily cost trend** — from `turns_daily` (instant) ([SUPABASE_SETUP.md:1452-1457](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1452)).
6. **Slowest 50 turns** ([SUPABASE_SETUP.md:1459-1464](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1459)).
7. **Vector ANN** — the cosine-distance query (§14.4) ([SUPABASE_SETUP.md:1466-1471](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1466)).
8. **Tier mix per week** — partitioned window for `pct_of_week` ([SUPABASE_SETUP.md:1475-1489](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1475)).
9. **Did escalation help?** — `avg(confidence)` per `final_tier` where `escalated` ([SUPABASE_SETUP.md:1491-1504](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1491)).
10. **Smart-skip routing** — `GROUP BY escalation_path` ([SUPABASE_SETUP.md:1506-1516](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1506)).
11. **Tier-4 cost breakdown** — `jsonb_object_keys(cost_usd_breakdown)` averaged ([SUPABASE_SETUP.md:1518-1525](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1518)).
12. **Thinking-token spend per model** — `avg`/`p95` of `llm_thinking_tok` (the metric that hid the bug) ([SUPABASE_SETUP.md:1527-1542](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1527)).
13. **WiFi quality vs latency** — `width_bucket(wifi_rssi_dbm, -90, -30, 6)` buckets RSSI into 6 bins between -90 and -30 dBm ([SUPABASE_SETUP.md:1544-1555](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1544)).
14. **Trace lookup** by `request_id` ([SUPABASE_SETUP.md:1557-1560](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1557)).
15. **Math density** — `% turns with eq` + `avg eq per math turn` ([SUPABASE_SETUP.md:1564-1574](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1564)).
16. **Most-emitted equations** — `jsonb_array_elements_text(latex_equations)` (GIN-accelerated) ([SUPABASE_SETUP.md:1576-1582](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1576)).
17. **Compaction health** — `turn_count - summary_as_of` = uncompacted turns, `turn_count >= 8` ([SUPABASE_SETUP.md:1584-1591](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1584)).
18. **Learner-profile coverage** — fraction of devices with a distilled `long_term_summary` ([SUPABASE_SETUP.md:1593-1599](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1593)).

---

## 21. Stored media (Supabase Storage)

Per-turn media (question audio WAV, raw camera JPEG, enhanced JPEG sent to the LLM) lives in the **`turn-media` Storage bucket** (`STORAGE_BACKEND=s3`), **NOT** in a Postgres column — the DB only stores **URL pointers**: `turns.image_url` / `turns.audio_url` (+ the multi-image list in `turns.extra->'image_urls'`) and `turn_traces.raw_image_url` / `raw_audio_url` / `enhanced_image_url`. Supabase keeps the bucket's file metadata in this same Postgres (`storage.objects`), so everything is queryable from the SQL Editor. **Deletion is manual-only** via the admin dashboard's "Delete old media" button (`POST /api/frontend/admin/media/cleanup`) — there is no automatic purge ([SUPABASE_QUERIES.md:776-791](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L776)).

**Key naming** (every key gets the uploader's `turn-` prefix): turn media is `turn-<uuid>.jpg|.wav` (with `-0`/`-1`… suffixes for multi-image turns); trace media is `turn-trace-<uuid>-raw.jpg` / `-enh.jpg` / `turn-trace-<uuid>.wav` ([SUPABASE_QUERIES.md:789-791](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L789)).

Cookbook subsections:
- **§15.1 What's in the bucket** — list newest files (`metadata->>'size'`, `metadata->>'mimetype'`), total usage vs 1 GB free tier, breakdown by media kind via `name like` patterns ([SUPABASE_QUERIES.md:795-833](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L795)).
- **§15.2 Which turns/traces have media** — turns with media pointers (`file://…` = legacy dead links from before `STORAGE_BACKEND=s3`), trace media with visual-grounding fields (`extracted_ocr_text`, `bounding_box`), and how to build a public CDN URL by concatenating the storage host with the object `name` ([SUPABASE_QUERIES.md:838-882](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L838)).
- **§15.3 Integrity: pointers vs files** — **DEAD POINTERS** (turns whose URL references a file not in the bucket, via `not exists (... regexp_replace(split_part(image_url,'?',1),'^.*/',''))`) and **ORPHAN FILES** (bucket objects no `turns`/`turn_traces` row points at, checking `image_urls` JSONB array too) ([SUPABASE_QUERIES.md:886-921](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L886)).
- **§15.4 Before "Delete old media"** — a dry-run preview at a 14-day cutoff (the button processes up to **400 rows per table per click**) and a post-cleanup verification using the `extra->>'media_purged' = 'true'` marker ([SUPABASE_QUERIES.md:923-950](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L923)).

---

## 22. Housekeeping & destructive resets

From §13 of the cookbook ([SUPABASE_QUERIES.md:618-667](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L618)):

- **Delete a stale pending pairing code** by hand: `delete from pairing_codes where code = '<CODE>' and status = 'pending';` ([SUPABASE_QUERIES.md:620-623](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L620)).
- **Wipe conversation data only** (commented for safety): delete `turns` then `sessions` (FK order) ([SUPABASE_QUERIES.md:626-631](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L626)).
- **FULL RESET via PL/pgSQL loop** — truncates EVERY base table in `public` (so it never misses a new table), leaving Supabase internals untouched, with `restart identity cascade` ([SUPABASE_QUERIES.md:633-651](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L633)):
  ```sql
  do $$
  declare r record;
  begin
    for r in select tablename from pg_tables where schemaname = 'public'
    loop
      execute format('truncate table public.%I restart identity cascade', r.tablename);
    end loop;
  end $$;
  ```
  Materialized views are NOT tables — refresh them so dashboards show zeros too.
- **Explicit table-list reset** (the SEE-what's-wiped variant): `truncate table turns, sessions, pairing_codes, memories, events, cost_log, user_memory, devices, user_profiles restart identity cascade;` ([SUPABASE_QUERIES.md:654-658](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L654)).

**Critical caveat:** there is no undo in the SQL Editor. A reset clears **Postgres only** — actual user *accounts* (email/password) live in **Clerk**. After a reset, a logged-in user is treated as "not onboarded" and re-onboards; their lamp must re-pair (re-scan the QR). To delete the accounts themselves, use the Clerk dashboard ([SUPABASE_QUERIES.md:661-667](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L661)).

---

## 23. Configuration, env vars & constants

| Name | Where | Effect |
|---|---|---|
| `DATABASE_URL` | `.env` | `postgresql+asyncpg://postgres:<pw>@db.<ref>.supabase.co:5432/postgres` — async driver, direct port 5432, **URL-encoded** password ([SUPABASE_SETUP.md:117-128](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L117)) |
| `ENABLE_AUTH` | settings | When true, prod auth path stamps real `user_id`; lifespan opens the DB ([SUPABASE_SETUP.md:1284-1291](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1284)) |
| `ENABLE_MEMORY` | settings | When true, `SessionMemoryService.persist_turn` is the canonical writer (only `status='ok'`) ([SUPABASE_SETUP.md:302-306](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L302)) |
| `REDIS_URL` | `.env` | Set → enable the L1 hot layer; blank → Supabase-only. `rediss://default:<pwd>@<host>:6379/0` ([SUPABASE_SETUP.md:985-988](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L985)) |
| `STORAGE_BACKEND=s3` | settings | Routes per-turn media to the `turn-media` Storage bucket ([SUPABASE_QUERIES.md:778-779](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L778)) |
| `SUPABASE_URL` / `SUPABASE_SERVICE_KEY` / `SUPABASE_STORAGE_BUCKET` | `.env` | Storage client config (bucket `lumos-turns` in the setup doc) ([SUPABASE_SETUP.md:1402-1406](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1402)) |
| `ADMIN_USER_IDS` / `ADMIN_EMAILS` | `.env` | Auto-seed admins on first request; **no longer consulted at gate-check time** — the `admins` table is the sole source of truth ([scripts/admin_setup.sql:15-21](../../Smart-Tutor-Lamp-backend/scripts/admin_setup.sql#L15)) |

Key constants/thresholds quoted from code:
- Pool: `pool_size=10`, `max_overflow=5`, `pool_pre_ping=True` ([SUPABASE_SETUP.md:1257-1259](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1257)); free-tier ~60 concurrent cap ([SUPABASE_SETUP.md:1257](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1257)).
- Session idle/resume window: **30 minutes** ([SUPABASE_SETUP.md:938-941](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L938)).
- Online heartbeat: **60 seconds** ([SUPABASE_QUERIES.md:140](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L140)); `last_seen_at` bumped every ~30 s ([SUPABASE_SETUP.md:228](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L228)).
- Pairing code TTL: **5 min**; cron sweep deletes `expires_at < now() - 1 hour` ([SUPABASE_SETUP.md:340-345](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L340)).
- `decay_resistance` default `0.5`, keeper threshold `> 0.7`, endpoints `0.9`/`0.15` ([SUPABASE_SETUP.md:490-559](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L490)).
- Profile tiering: `< 3` none, `3-9` template, `≥ 10` LLM ([SUPABASE_SETUP.md:663-666](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L663)).
- Char caps: profile ≤ 240, summary ≤ 480 ([SUPABASE_SETUP.md:903-904](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L903)).
- IVFFlat `lists = 100`, recreate at 10K rows; `vector(1536)` dim ([SUPABASE_SETUP.md:686-692](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L686)).
- Media cleanup batch: 400 rows/table/click, 14-day default cutoff ([SUPABASE_QUERIES.md:928-929](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L928)).
- Multi-image: 1..5 images per turn ([SUPABASE_QUERIES.md:428](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L428)).

---

## 24. Edge cases, error handling, fallbacks

- **Persistence must never break the response path.** `write_turn` swallows all exceptions after logging ([SUPABASE_SETUP.md:1361-1364](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1361)).
- **Dev / no-DB no-ops.** When `ENABLE_AUTH=False` and `user_id=NULL`, persistence cleanly no-ops; **error-status turns are skipped** so fallbacks never pollute history ([SUPABASE_SETUP.md:245-249](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L245)).
- **Cross-user safety.** The `user_id IS NOT DISTINCT FROM` guard plus Redis-history clear on unlink/`user.deleted` ensure a re-paired lamp never inherits prior turns ([SUPABASE_SETUP.md:246-249](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L246), [SUPABASE_SETUP.md:948-950](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L948)).
- **Resume on `last_activity_at`, not `ended_at`.** A session survives the disconnect/reconnect cycle; `ended_at` set on disconnect, cleared on resume ([SUPABASE_SETUP.md:946-947](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L946)).
- **Redis loss → graceful degrade.** Every Redis read has a Postgres fallback; lose Redis → today's behavior, no data loss ([SUPABASE_SETUP.md:1015-1017](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1015)).
- **Admin panels degrade per-panel.** Each admin query is wrapped in a SAVEPOINT so a missing optional table (`memories`, `cost_log`) zeros that panel instead of failing the page ([SUPABASE_QUERIES.md:770-772](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L770)).
- **Dead media pointers** (`file://…`) and orphan files are tolerated; the cleanup button treats missing files as already-deleted ([SUPABASE_QUERIES.md:840-842](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L840), [SUPABASE_QUERIES.md:888-890](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L888)).
- **`pairing_codes`/`cost_log`/`admins` RLS deny-all.** RLS-on + no-policy = deny-all to public roles; backend's service_role bypasses it ([SUPABASE_SETUP.md:751-756](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L751), [scripts/admin_setup.sql:33-35](../../Smart-Tutor-Lamp-backend/scripts/admin_setup.sql#L33)).
- **Transaction-pooler prepared-statement clash.** asyncpg prepared statements conflict with port 6543 → use direct 5432 or `prepared_statement_cache_size=0` ([SUPABASE_SETUP.md:1656](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1656)).

---

## 25. Integration points (firmware ↔ backend ↔ frontend ↔ db)

- **Firmware (ESP32-S3):** boots unpaired → `POST /register` → writes `devices` + `pairing_codes` rows → shows QR; polls for the minted `device_jwt`, stores it in NVS, deletes the pairing row ([SUPABASE_SETUP.md:218-224](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L218)). Each WS turn (audio/image) becomes one `turns` row; `client_fw_version`/`wifi_rssi_dbm` carry hardware context.
- **Backend (FastAPI):** `ws_lamp.py:_authenticate_prod` reads `device_jwt.uid`; `app/storage/turns.py:open_session` resumes/opens sessions; `orchestrator._persist_turn` → `turns.write_turn`; `SessionMemoryService.persist_turn`/`load_context` for the memory layer; `app/services/admin.py:is_admin` for the admin gate; `app/services/cache.py`/`revocation.py` for the Redis seam; `workers/rollup.py` refreshes materialized views ([SUPABASE_SETUP.md:234-242](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L234), [SUPABASE_SETUP.md:852](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L852)).
- **Frontend (Next.js):** onboarding writes `user_profiles` via `PUT /api/frontend/profile`; `/history` page is the future direct-RLS reader; `/admin` page (`requireAdmin()`) hits `/api/frontend/admin/*` which re-check `require_admin` ([SUPABASE_SETUP.md:362-371](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L362), [SUPABASE_QUERIES.md:717-726](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L717)).
- **Web simulator:** writes `turns` with synthetic `device_id = websim-<user>` and `extra->>'source' = 'simulation'` ([SUPABASE_QUERIES.md:293-304](../../Smart-Tutor-Lamp-backend/SUPABASE_QUERIES.md#L293)).
- **Clerk:** owns identity; `user.deleted` webhook (`clerk_webhook.py`) revokes devices and clears history ([SUPABASE_SETUP.md:215-217](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L215)).
- **DB (Supabase Postgres):** the durable store + Storage (`turn-media` bucket, `storage.objects` metadata) + extensions (`vector`, `pgcrypto`, `pg_stat_statements`).

---

## 26. Production scaling notes (Phase 7)

Things you don't need today but should know ([SUPABASE_SETUP.md:1606-1619](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1606)):

| Concern | Kicks in | What to do |
|---|---|---|
| Connection pool exhaustion | > 60 concurrent workers (free-tier cap) | PgBouncer (transaction mode, 6543); SQLAlchemy `NullPool` |
| `turns` > 10 M rows | Year 2-3 at thousands of lamps | Partition by `RANGE (asked_at)` monthly |
| Read replicas | Dashboards slow writes | Pro tier replicas; point Metabase at the replica URL |
| Serverless cold-start | Deploy to Cloud Run / Lambda | Transaction pooler (6543) + `poolclass=NullPool` |
| Backups | Now (PITR on Pro+); Free → weekly `pg_dump $DATABASE_URL > backup.sql` | — |
| Secrets rotation | Annually | New password in dashboard, update `.env`, restart |
| Schema drift | When you add staging | Use Alembic exclusively, never edit prod schema via dashboard |
| **GDPR / account-delete scrub** | Real users | Clerk `user.deleted` already revokes devices; for full erasure run `UPDATE turns SET user_id=NULL, transcript=NULL, speech='' WHERE user_id=$1; DELETE FROM user_memory WHERE user_id=$1; DELETE FROM memories WHERE user_id=$1; DELETE FROM user_profiles WHERE user_id=$1;` and delete blobs. Keep anonymised `turns` (user_id NULL) for aggregate analytics ([SUPABASE_SETUP.md:1619](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1619)) |

---

## 27. Troubleshooting (Phase 9)

The setup doc's troubleshooting matrix ([SUPABASE_SETUP.md:1649-1661](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1649)):

| Symptom | Cause | Fix |
|---|---|---|
| `InvalidPasswordError` | Password has URL-special chars, not encoded | URL-encode via `urllib.parse.quote_plus` |
| `connection refused` on first connect | IPv6-only network / IPv4 add-on disabled | Enable IPv4 add-on |
| `relation "turns" does not exist` | Alembic didn't run | `alembic upgrade head` |
| `prepared statement "..." already exists` | Connected via transaction pooler (6543) | Switch to direct 5432, or `prepared_statement_cache_size=0` |
| Slow `ORDER BY asked_at` | Missing BRIN index | Re-run the hand-edited migration step |
| `<=>` operator not found | pgvector not enabled | `CREATE EXTENSION vector;` |
| Pool exhausted under load | `pool_size` too small | Bump it, or PgBouncer (6543 + `NullPool`) |
| `permission denied for table turns` (frontend) | anon key without RLS policies | Add a SELECT policy (§9) or use service role |
| Autogenerate empty diff | Models not imported in `env.py` | Import every model file so `Base.metadata` sees them |

---

## 28. Diagrams

### 28.1 Identity & data-flow (flowchart)

```mermaid
flowchart TD
    subgraph Clerk["Clerk (managed identity)"]
        U["Human signs up\nuser_id = user_2abc…"]
    end
    subgraph Firmware["ESP32-S3 lamp"]
        REG["POST /register"]
        POLL["Poll for device_jwt\nstore in NVS"]
        WS["WS connect each turn"]
    end
    subgraph DB["Supabase Postgres"]
        DEV[("devices\nuser_id, secret_hash, revoked_at")]
        PC[("pairing_codes\ncode, device_jwt, expires_at")]
        SES[("sessions\nlast_activity_at, turn_count, summary")]
        TUR[("turns\nspeech, transcript, latex_equations, telemetry")]
        UM[("user_memory\nlong_term_summary, subject_profile")]
        EV[("events")]
        MEM[("memories\nvector(1536)")]
    end

    REG -->|upsert| DEV
    REG -->|create| PC
    U -->|scan QR + Link| PC
    PC -->|/complete-pairing writes user_id + mints jwt| DEV
    POLL -->|read + delete row| PC
    WS -->|verify jwt + devices.user_id == uid AND revoked_at IS NULL| DEV
    WS -->|open_session resume/insert| SES
    WS -->|_persist_turn -> write_turn| TUR
    TUR -->|denorm user_id + session_id| SES
    SES -->|once per session end| UM
    WS -->|lifecycle| EV
    TUR -.->|deferred ANN| MEM
```

### 28.2 Per-turn persistence with Redis fallback (sequence)

```mermaid
sequenceDiagram
    participant L as Lamp (WS)
    participant O as Orchestrator
    participant R as Redis (optional)
    participant PG as Supabase Postgres

    L->>O: audio/image turn
    O->>R: cget lamp:sid:{device_id}
    alt cache hit (re-validate user_id + idle)
        R-->>O: session_id
    else miss / Redis off (no-op)
        O->>PG: open_session() resume query (30-min idle window)
        PG-->>O: session_id (resume) or INSERT new
        O->>R: cset lamp:sid:{device_id} (TTL idle+5m)
    end
    O->>O: LLM tier router -> reply + telemetry
    O->>R: push_turn() LPUSH/LTRIM lamp:hist (write-through)
    O->>PG: write_turn() INSERT turns (user_id, session_id, telemetry)
    note over O,PG: try/except swallow — persistence MUST NOT break response
    O->>PG: bump sessions.last_activity_at + turn_count (same txn)
    O-->>L: speech + display + latex_equations
```

### 28.3 RLS / access decision (flowchart)

```mermaid
flowchart TD
    Q["Incoming read"] --> WHO{Which credential?}
    WHO -->|service_role key\n(backend)| BYPASS["Bypasses RLS\nsees ALL rows"]
    WHO -->|anon/authenticated\n+ Clerk JWT| POL{Table has SELECT policy?}
    POL -->|yes: user_id = auth.jwt()->>'sub'| OWN["Returns only that user's rows"]
    POL -->|no policy\n(pairing_codes, cost_log, admins)| DENY["Deny-all\n(0 rows)"]
    WHO -->|SQL Editor\n(privileged)| BYPASS
```

---

## 29. Setup checklist (Phase 8)

The end-to-end checklist before declaring the integration done ([SUPABASE_SETUP.md:1623-1645](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1623)):

- [ ] Supabase project created, region matches deploy target
- [ ] `vector` + `pgcrypto` + `pg_stat_statements` extensions enabled
- [ ] `DATABASE_URL` in `.env` (URL-encoded password)
- [ ] `pip install -r requirements.txt` succeeds (storage deps uncommented)
- [ ] asyncpg smoke test passes
- [ ] Alembic initialized, first migration applied, all tables visible
- [ ] BRIN + partial indexes hand-added to migration, applied
- [ ] `pgvector` extension + `ivfflat` index present
- [ ] Materialized views created + first `REFRESH` run
- [ ] `app/db/models.py` has `SessionRecord`, `TurnRecord`, `UserMemory` + `Memory`, `Event`
- [ ] `turns` has `speech`, `latex_equations`, `turn_index`, `decay_resistance`; `sessions` has `summary`/`summary_as_of`; `user_memory` exists
- [ ] `sessions.last_activity_at` + `sessions_resume_idx` exist (power reconnect-resume)
- [ ] `app/db/session.py` has `init_db`/`dispose_db`/`get_session_factory`/`get_db`
- [ ] `app/main.py` lifespan calls `init_db()` when `DATABASE_URL` is set
- [ ] `app/storage/turns.py:write_turn` implemented + wired into orchestrator
- [ ] First end-to-end turn produces one `turns` row (`SELECT count(*) FROM turns` ≥ 1)
- [ ] RLS enabled on user-facing tables (read-only policies; writes via service role)
- [ ] (Later) Clerk → Supabase JWT integration configured

### TL;DR (the doc's own one-page summary)

1. Create Supabase project, enable `vector` + `pgcrypto` + `pg_stat_statements`.
2. Add `DATABASE_URL` (URL-encode password).
3. `pip install` sqlalchemy[asyncio] asyncpg alembic pgvector.
4. Apply the §3.2 schema (devices, pairing_codes, sessions, turns, user_memory, memories, events, cost_log) + BRIN/partial/GIN/IVFFlat indexes + materialized views.
5. Wrap in Alembic, hand-edit for what autogen misses.
6. Update `app/db/session.py`, implement `write_turn`, wire from `_persist_turn`.
7. Enable RLS with SELECT policies matching `auth.jwt()->>'sub'`.
8. First turn → first row check.

([SUPABASE_SETUP.md:1665-1676](../../Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1665))
