# Database — Overview, Schema & Models

The Smart Tutor Lamp ("Lumos") backend persists every device, user, conversation, turn, audit trace, cost line and model-bench result in **PostgreSQL hosted on Supabase**, accessed asynchronously through **SQLAlchemy 2.x + asyncpg**. The schema is defined as ORM models in [`app/db/models.py`](Smart-Tutor-Lamp-backend/app/db/models.py) (**24 tables** as of the 2026-07-03 refresh, up from 16) and brought online by a lazy engine/session factory in [`app/db/session.py`](Smart-Tutor-Lamp-backend/app/db/session.py). Clerk owns human identity — there is intentionally **no `users` table**; every row instead carries the Clerk `user_id` string denormalized for one-hop, join-free per-user reads. The database is *optional at boot*: it activates only when `DATABASE_URL` is set, and the whole app degrades cleanly to stateless when it is absent. This document is the definitive reference for the storage layer's technology, connection management, and full schema.

> **Updated 2026-07-03:** eight tables were added since the 2026-06-16 sync — five pilot-instrumentation tables (`turn_feedback`, `survey_responses`, `problem_reports`, `user_consents`, `student_personalization`; writer `app/storage/pilot.py`), two offline analytics-tagging tables plus a controlled vocabulary (`syllabus_topics`, `turn_topics`, `turn_mistakes`; writers `app/workers/topic_tag.py` / `mistake_tag.py`), and one OTA table (`firmware_releases`; writer `app/services/ota_release.py`). All follow the existing house style (UUID PKs, no DB FKs, JSONB escape hatches, denormalized `user_id`) and are auto-created by `create_all`. They are cataloged in §7.13; the older 16 tables are unchanged.

---

## Table of Contents

1. [Purpose & Responsibility](#1-purpose--responsibility)
2. [Technology Stack](#2-technology-stack)
3. [Architecture & Module Map](#3-architecture--module-map)
4. [Connection & Session Management (`session.py`)](#4-connection--session-management-sessionpy)
   - 4.1 [Lazy engine lifecycle](#41-lazy-engine-lifecycle)
   - 4.2 [SSL/TLS auto-detection algorithm](#42-ssltls-auto-detection-algorithm)
   - 4.3 [Engine & pool configuration](#43-engine--pool-configuration)
   - 4.4 [`init_db` + `create_all` flow](#44-init_db--create_all-flow)
   - 4.5 [Additive-column migration shim](#45-additive-column-migration-shim)
   - 4.6 [The `get_db` request dependency](#46-the-get_db-request-dependency)
5. [Schema Modeling Conventions](#5-schema-modeling-conventions)
6. [The Shared `Base`](#6-the-shared-base)
7. [Table-by-Table Reference](#7-table-by-table-reference)
   - 7.1 [`devices`](#71-devices) · 7.2 [`pairing_codes`](#72-pairing_codes) · 7.3 [`user_profiles`](#73-user_profiles) · 7.4 [`sessions`](#74-sessions) · 7.5 [`turns`](#75-turns) · 7.6 [`turn_traces`](#76-turn_traces) · 7.7 [`user_memory`](#77-user_memory) · 7.8 [`events`](#78-events) · 7.9 [`cost_log`](#79-cost_log) · 7.10 [`admins`](#710-admins)
   - 7.11 [Model-bench tables](#711-model-bench-tables): `model_providers` · `model_requests` · `model_responses` · `model_feedback`
   - 7.12 [`memories` (deferred, not ORM-mapped)](#712-memories-deferred-not-orm-mapped) · 7.13 [Tables added since the 2026-06-16 sync](#713-tables-added-since-the-2026-06-16-sync) (pilot / tagging / OTA)
8. [Entity-Relationship Diagram](#8-entity-relationship-diagram)
9. [Index Inventory & Rationale](#9-index-inventory--rationale)
10. [Normalization Stance & Deliberate Denormalizations](#10-normalization-stance--deliberate-denormalizations)
11. [Boot-Time Control Flow](#11-boot-time-control-flow)
12. [Configuration & Environment Variables](#12-configuration--environment-variables)
13. [Edge Cases, Errors, Fallbacks](#13-edge-cases-errors-fallbacks)
14. [Integration Points (who calls what)](#14-integration-points-who-calls-what)
15. [Migrations: current state vs. documented Alembic path](#15-migrations-current-state-vs-documented-alembic-path)

---

## 1. Purpose & Responsibility

The database layer is the **durable source of truth** for everything that must survive a process restart or be queried after the fact. Its responsibilities:

- **Auth & pairing**: store the lamp's identity (`devices`) and the short-lived QR-pairing bridge (`pairing_codes`). The WebSocket gateway checks `devices.revoked_at` on every connect with **no Clerk call on the hot path** ([SUPABASE_SETUP.md §3.1a step 5](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L226)).
- **Conversation persistence**: group turns into `sessions`, persist each completed Q→A in `turns`, and maintain a cross-session learner profile in `user_memory`.
- **Audit & observability**: a verbose per-turn pipeline trace (`turn_traces`), a generic lifecycle log (`events`), and a per-API-call cost ledger (`cost_log`).
- **Web onboarding**: the learner's self-declared profile (`user_profiles`).
- **Admin allowlist**: `admins` (durable source of truth for who may open `/admin`).
- **Model-comparison bench**: a fully separate four-table cluster (`model_providers` / `model_requests` / `model_responses` / `model_feedback`) for the "which model answered, how fast, how much, how good" concern.

The single architectural invariant ([SUPABASE_SETUP.md §3.6.6](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1014)): **Postgres is always the source of truth; Redis (when present) is only a read accelerator in front of it, and every Redis entry is a copy of a row already persisted.** Lose Redis at any moment → the system degrades to Postgres-only with no data loss.

---

## 2. Technology Stack

| Layer | Choice | Where set |
|---|---|---|
| RDBMS | PostgreSQL 15+ on **Supabase** | [SUPABASE_SETUP.md §0](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L26) |
| Async driver | `asyncpg` (via `postgresql+asyncpg://…`) | [SUPABASE_SETUP.md §2.2](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L119) |
| ORM | SQLAlchemy 2.x async (`DeclarativeBase`, `Mapped`, `async_sessionmaker`) | [models.py:31](Smart-Tutor-Lamp-backend/app/db/models.py#L31), [session.py:17](Smart-Tutor-Lamp-backend/app/db/session.py#L17) |
| Vector search | `pgvector` extension — `vector(1536)` (OpenAI `text-embedding-3-small` dim) | [SUPABASE_SETUP.md §3.2 `memories`](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L668) |
| UUID generation | `gen_random_uuid()` (Postgres, from `pgcrypto`) / `uuid.uuid4()` (Python default) | [models.py:168](Smart-Tutor-Lamp-backend/app/db/models.py#L168), [SUPABASE_SETUP.md §1.3](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L78) |
| Object storage | Supabase Storage (S3-compatible) — blob URLs only stored in DB | [SUPABASE_SETUP.md §5.4](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1395) |
| Migrations (intended) | Alembic (documented but **not yet wired** — see §15) | [SUPABASE_SETUP.md §4](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1056) |

Supabase-specific extensions the setup expects ([SUPABASE_SETUP.md §1.3](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L78)): `vector` (pgvector ANN), `pg_stat_statements` (query analytics), `pgcrypto` (`gen_random_uuid()`). Connection is the **direct port 5432** (not the transaction pooler on 6543), because some asyncpg prepared-statement features conflict with PgBouncer's transaction mode ([SUPABASE_SETUP.md §1.2](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L76)).

---

## 3. Architecture & Module Map

```
app/db/
├── __init__.py     ← EMPTY (0 bytes) — namespace package only
├── models.py       ← all 24 ORM models + shared Base (this is the schema)
├── session.py      ← async engine, session factory, init/dispose, get_db dep
└── migrations/
    └── .keep       ← empty placeholder; Alembic NOT initialized (see §15)
```

The `db` package owns only **schema + connection**. The code that *writes* these tables lives one layer up in `app/storage/*` and `app/services/*`:

| Table(s) | Writer module |
|---|---|
| `sessions`, `turns` | [`app/storage/turns.py`](Smart-Tutor-Lamp-backend/app/storage/turns.py) (`open_session`, `close_session`, `write_turn`, `load_recent_turns`) |
| `turn_traces` | [`app/services/turn_trace.py`](Smart-Tutor-Lamp-backend/app/services/turn_trace.py) (passive fire-and-forget tracer) |
| `user_memory` | [`app/storage/user_memory.py`](Smart-Tutor-Lamp-backend/app/storage/user_memory.py) + [`app/services/session_memory.py`](Smart-Tutor-Lamp-backend/app/services/session_memory.py) |
| `user_profiles` | [`app/storage/user_profiles.py`](Smart-Tutor-Lamp-backend/app/storage/user_profiles.py) (via `PUT /api/frontend/profile`) |
| `events` | [`app/storage/events.py`](Smart-Tutor-Lamp-backend/app/storage/events.py) |
| `model_*` | [`app/storage/model_eval.py`](Smart-Tutor-Lamp-backend/app/storage/model_eval.py) (`seed_providers` + bench writers) |
| `devices`, `pairing_codes`, `admins` | the auth routes (`device_lamp.py`, `device_user.py`, `clerk_webhook.py`) + [`app/services/admin.py`](Smart-Tutor-Lamp-backend/app/services/admin.py) |
| `turn_feedback`, `survey_responses`, `problem_reports`, `user_consents`, `student_personalization` | [`app/storage/pilot.py`](Smart-Tutor-Lamp-backend/app/storage/pilot.py) (pilot instrumentation — routes `pilot.py`/`admin_pilot.py`) |
| `turn_topics`, `turn_mistakes` | offline workers [`app/workers/topic_tag.py`](Smart-Tutor-Lamp-backend/app/workers/topic_tag.py) / [`mistake_tag.py`](Smart-Tutor-Lamp-backend/app/workers/mistake_tag.py) (via `services/topic_tagger.py` / `mistake_tagger.py`); `syllabus_topics` is seeded reference data |
| `firmware_releases` | [`app/services/ota_release.py`](Smart-Tutor-Lamp-backend/app/services/ota_release.py) (admin OTA console + `routes/ota.py`) |
| `memories` (deferred) | raw SQL only (not ORM-mapped) |

---

## 4. Connection & Session Management (`session.py`)

[`app/db/session.py`](Smart-Tutor-Lamp-backend/app/db/session.py) is 160 lines and exposes the entire connection surface. Module-level singletons hold the process-wide engine and session factory ([session.py:29-30](Smart-Tutor-Lamp-backend/app/db/session.py#L29)):

```python
_engine: AsyncEngine | None = None
_session_factory: async_sessionmaker[AsyncSession] | None = None
```

### 4.1 Lazy engine lifecycle

The engine is **lazy by design** — `_engine` stays `None` until `init_db()` runs from the FastAPI lifespan. This keeps dev-mode (`ENABLE_AUTH=False`, no `DATABASE_URL`) bootable **without even installing asyncpg** ([session.py:4-7](Smart-Tutor-Lamp-backend/app/db/session.py#L4)). Two accessors guard against use-before-init:

- `get_engine()` ([session.py:55](Smart-Tutor-Lamp-backend/app/db/session.py#L55)) — raises `RuntimeError("DB engine not initialised…")` if `_engine is None`. This is treated as a **programming error**, not a runtime condition to degrade through.
- `get_session_factory()` ([session.py:67](Smart-Tutor-Lamp-backend/app/db/session.py#L67)) — raises `RuntimeError("Session factory not initialised — init_db() first.")`.

### 4.2 SSL/TLS auto-detection algorithm

`_ssl_connect_args(url)` ([session.py:33-52](Smart-Tutor-Lamp-backend/app/db/session.py#L33)) computes asyncpg's `ssl` connect-arg from the `DATABASE_SSL` env var combined with the host. The mechanics:

1. `mode = (settings.DATABASE_SSL or "").strip().lower()`.
2. **If `mode` is empty (the "AUTO" default)**: parse the host out of the URL via `make_url(url).host` (exception-guarded → `host = ""`). Then:
   - If host ends with `supabase.co` **or** `supabase.com` → force `mode = "require"`.
   - Else (e.g. `localhost`) → `return {}` (no SSL — local Postgres untouched).
3. If `mode in ("", "disable")` → `return {}`.
4. Otherwise → `return {"ssl": mode}`.

asyncpg accepts libpq `sslmode` strings (`require`, `verify-ca`, `verify-full`, …) for its `ssl` parameter. **Why this exists**: Supabase rejects plaintext connections, so without TLS the engine never connects; AUTO turns TLS on for Supabase hosts while leaving dev-against-localhost working ([session.py:34-39](Smart-Tutor-Lamp-backend/app/db/session.py#L34), config doc [config.py:213-219](Smart-Tutor-Lamp-backend/app/config.py#L213)).

### 4.3 Engine & pool configuration

`init_db` builds the engine with `create_async_engine` ([session.py:89-97](Smart-Tutor-Lamp-backend/app/db/session.py#L89)):

| Parameter | Value | Effect |
|---|---|---|
| `pool_size` | `10` | base persistent connections — "conservative; bump once we see a real load profile" ([session.py:8-9](Smart-Tutor-Lamp-backend/app/db/session.py#L8)) |
| `max_overflow` | `10` | up to 10 extra connections under burst (total ceiling 20) |
| `pool_pre_ping` | `True` | tests each checked-out connection with a lightweight ping → detects half-dead connections (small per-checkout cost) |
| `pool_recycle` | `1_800` (30 min) | hard-recycles a connection after 30 min to dodge server/idle-timeout drops |
| `future` | `True` | SQLAlchemy 2.0-style API |
| `connect_args` | `_ssl_connect_args(DATABASE_URL)` | the TLS decision from §4.2 |

The session factory is `async_sessionmaker(_engine, expire_on_commit=False)` ([session.py:98](Smart-Tutor-Lamp-backend/app/db/session.py#L98)). `expire_on_commit=False` keeps ORM attributes readable after `commit()` without an extra `SELECT` round-trip — important on the hot path. (Note: the live code uses `max_overflow=10` / `pool_recycle=1_800`; the *illustrative* snippet in [SUPABASE_SETUP.md §5.1](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1253) shows `max_overflow=5` with no recycle — the actual values in `session.py` are authoritative.)

### 4.4 `init_db` + `create_all` flow

`async def init_db(*, create_tables: bool = True)` ([session.py:73-104](Smart-Tutor-Lamp-backend/app/db/session.py#L73)):

1. **Guard**: if `not settings.DATABASE_URL` → raise `RuntimeError("DATABASE_URL is unset…")`. (Required when `ENABLE_AUTH=True`.)
2. Build `_engine` (§4.3) and `_session_factory`.
3. If `create_tables` (the default): open a transactional connection and run `Base.metadata.create_all` synchronously inside the async connection via `conn.run_sync(...)` ([session.py:101-102](Smart-Tutor-Lamp-backend/app/db/session.py#L101)). This **creates only MISSING tables — it never ALTERs** an existing one. Then log `"DB schema ensured (create_all)"` and call `_ensure_additive_columns()`.

**Dev vs prod posture**: in dev (`create_tables=True`) `create_all` makes everything work on a fresh Postgres. In prod the intent is to run Alembic and pass `create_tables=False` — and the call is cheap regardless because `create_all` is a no-op once all tables exist ([session.py:73-80](Smart-Tutor-Lamp-backend/app/db/session.py#L73)). In practice [`app/main.py`](Smart-Tutor-Lamp-backend/app/main.py#L81) currently calls `init_db(create_tables=True)` (see §11).

### 4.5 Additive-column migration shim

Because `create_all` *never ALTERs*, a deployment whose table predates a later-added column would silently fail every INSERT touching that column. The fix is a hand-rolled, idempotent additive-column applier.

`_ADDITIVE_COLUMNS` ([session.py:113-117](Smart-Tutor-Lamp-backend/app/db/session.py#L113)) is a tuple of `(table, column, ddl_type)`:

```python
_ADDITIVE_COLUMNS = (
    ("turn_traces", "llm_raw_system_prompt", "TEXT"),
    ("turn_traces", "extracted_ocr_text",    "TEXT"),
    ("turn_traces", "bounding_box",          "JSONB"),
)
```

`_ensure_additive_columns()` ([session.py:120-134](Smart-Tutor-Lamp-backend/app/db/session.py#L120)) iterates that tuple and runs, per entry, an idempotent:

```sql
ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {column} {ddl_type}
```

It is **best-effort per-column**: each in its own `engine.begin()` transaction wrapped in `try/except`. A failure (e.g. a restricted DB role) is logged via `log.warning(... exc_info=True)` and execution **continues** — "boot must never block on a cosmetic tracing column; the tracer itself degrades to dropped rows until the column exists" ([session.py:120-134](Smart-Tutor-Lamp-backend/app/db/session.py#L120)). Each operation is non-destructive: no drops, no rewrites, existing rows resolve to NULL.

### 4.6 The `get_db` request dependency

`async def get_db() -> AsyncIterator[AsyncSession]` ([session.py:147-159](Smart-Tutor-Lamp-backend/app/db/session.py#L147)) is the FastAPI dependency that yields **one async session per request**:

```python
factory = get_session_factory()
async with factory() as session:
    try:
        yield session
    except Exception:
        log.exception("[DB] request session error — rolling back")
        await session.rollback()
        raise
```

Semantics: an exception that escapes the route handler is **logged with a full traceback then rolled back then re-raised** (never silent). Handlers that mutate must `await db.commit()` themselves — the dependency does **not** auto-commit ([session.py:147-151](Smart-Tutor-Lamp-backend/app/db/session.py#L147)). Note the fire-and-forget storage writers (`turns.py`, `turn_trace.py`) bypass this dependency and use `get_session_factory()` directly so they can manage their own short-lived sessions and swallow errors.

`dispose_db()` ([session.py:137-143](Smart-Tutor-Lamp-backend/app/db/session.py#L137)) calls `_engine.dispose()` (releases the pool) and resets both singletons to `None`.

---

## 5. Schema Modeling Conventions

Distilled from the model definitions and [SUPABASE_SETUP.md §3.1](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L155):

1. **UUID primary keys** on append-heavy tables, `default=_uuid.uuid4` in Python with `UUID(as_uuid=True)` columns; lookup tables use natural string PKs (`devices.device_id`, `pairing_codes.code`, `user_profiles.user_id`, `admins.user_id`, `model_providers.model_name` is `unique` not PK).
2. **No DB-level FOREIGN KEYs in the ORM models** — joins are by id *in code* (e.g. `turns.session_id → sessions.id`). The house style ([models.py:430-432](Smart-Tutor-Lamp-backend/app/db/models.py#L430)) deliberately omits FKs even though the *illustrative SQL* in SUPABASE_SETUP.md shows `REFERENCES … ON DELETE CASCADE`. The ORM is the authority: there are **no `ForeignKey()` declarations anywhere in `models.py`**.
3. **`timestamptz` everywhere** — every datetime column is `DateTime(timezone=True)`; never naive `timestamp`.
4. **`server_default=func.now()`** for created/started timestamps so the DB stamps them.
5. **JSONB escape hatch** — most tables carry an `extra` (or `payload`) JSONB column defaulting to `{}` so new fields need no migration; promote to a real column once hot-queried (principle #4).
6. **`user_id` denormalized** onto `sessions`/`turns`/`user_memory`/`events`/`model_*` so per-user reads and RLS are one index hop, no join (see §10).
7. **Partial indexes** for the queries that matter (e.g. only index `user_id IS NOT NULL`).
8. **Numeric precision** is pinned: `confidence`/`decay_resistance` → `Numeric(3,2)` (0.00–1.00), `cost_usd` → `Numeric(10,6)`, model-bench costs → `Numeric(12,6)`.

---

## 6. The Shared `Base`

```python
class Base(DeclarativeBase):
    """Shared declarative base. Every model in `app.db` extends this so
    Base.metadata.create_all / Alembic autogen sees them as a single schema."""
```
[models.py:34-38](Smart-Tutor-Lamp-backend/app/db/models.py#L34). All 24 models subclass `Base`; this is what makes `Base.metadata.create_all` ([session.py:102](Smart-Tutor-Lamp-backend/app/db/session.py#L102)) and Alembic autogen treat them as one schema. `models.py` imports the Postgres-dialect column types `ARRAY`, `JSONB`, `UUID` from `sqlalchemy.dialects.postgresql` ([models.py:30](Smart-Tutor-Lamp-backend/app/db/models.py#L30)) — i.e. the schema is **Postgres-specific** (partial indexes via `postgresql_where`, `ARRAY(Text)`, JSONB).

---

## 7. Table-by-Table Reference

> Column legend: **PK** = primary key, **U** = unique, **NN** = NOT NULL, **dflt** = server/python default. All datetimes are `timestamptz`.

### 7.1 `devices`

One row per physical lamp — the **authoritative auth table** and the join point between a Clerk user and a lamp ([models.py:41-76](Smart-Tutor-Lamp-backend/app/db/models.py#L41)).

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `device_id` | String | **PK** | e.g. `"lamp-7C9EB42F"` (MAC-derived, NVS-stored) |
| `device_secret_hash` | String | NN | `argon2id(device_secret)` — raw secret never re-leaves NVS |
| `user_id` | String | nullable | Clerk ID `user_2abc…` or NULL when unpaired |
| `friendly_name` | String | NN, dflt `"Tutor Lamp"` | |
| `paired_at` | timestamptz | nullable | |
| `last_seen_at` | timestamptz | nullable | bumped ~every 30 s on the live socket |
| `revoked_at` | timestamptz | nullable | set on Unlink / Clerk account delete; **coexists with `user_id=NULL`** for audit clarity |
| `created_at` | timestamptz | NN, dflt `now()` | |

**Index**: `devices_user_idx` — partial B-tree on `user_id WHERE user_id IS NOT NULL` ([models.py:68-76](Smart-Tutor-Lamp-backend/app/db/models.py#L68)). Skips indexing orphan/unpaired rows because `/api/devices` always filters by `user_id IS NOT NULL`. (The SUPABASE_SETUP.md DDL additionally documents `devices_last_seen_idx` and a `revoked_at IS NULL` predicate on the user index — but the *ORM-created* index is exactly the one above.)

### 7.2 `pairing_codes`

Short-lived (5-min TTL), single-use bridge between a lamp's pending pairing and a Clerk user ([models.py:79-106](Smart-Tutor-Lamp-backend/app/db/models.py#L79)). Created by `POST /api/device/register`, polled via `POST /api/device/poll-pairing`, claimed by `POST /api/device/complete-pairing`. Deleted as soon as the lamp polls and receives the JWT.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `code` | String | **PK** | the 6-char code embedded in the QR |
| `device_id` | String | NN | |
| `user_id` | String | nullable | filled at complete-pairing |
| `status` | String | NN, **CHECK** | `IN ('pending','paired','expired')` |
| `device_jwt` | String | nullable | the minted device JWT, held until the lamp polls (never store the raw secret here) |
| `expires_at` | timestamptz | NN | |
| `created_at` | timestamptz | NN, dflt `now()` | |

**Constraints/Indexes**: `pairing_codes_status_check` CHECK ([models.py:100-104](Smart-Tutor-Lamp-backend/app/db/models.py#L100)); `pairing_codes_device_idx` on `device_id` ([models.py:105](Smart-Tutor-Lamp-backend/app/db/models.py#L105)).

### 7.3 `user_profiles`

Web-onboarding profile — **one row per Clerk user** (NOT per device), written by the Frontend Manager via `PUT /api/frontend/profile` ([models.py:109-155](Smart-Tutor-Lamp-backend/app/db/models.py#L109)). Distinct from `user_memory` (per-device, derived); this is the learner's **self-declared** onboarding (`lib/onboarding.ts`).

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `user_id` | String | **PK** | Clerk ID — the join key to everything |
| `full_name` | String | NN, dflt `""` | |
| `phone` | String | nullable | |
| `target_exam` | String | nullable, **CHECK** | `IN ('JEE','NEET','CAT','UPSC') OR NULL` |
| `prep_duration` | String | nullable | |
| `onboarding_complete` | Boolean | NN, dflt `false` | |
| `extra` | JSONB | NN, dflt `{}` | future fields (strong/weak subjects, locale…) |
| `created_at` / `updated_at` | timestamptz | NN, dflt `now()` | |

**Constraints/Indexes**: `user_profiles_exam_check` CHECK ([models.py:146-149](Smart-Tutor-Lamp-backend/app/db/models.py#L146)); partial index `user_profiles_exam_idx` on `target_exam WHERE target_exam IS NOT NULL` (cohort analytics) ([models.py:150-154](Smart-Tutor-Lamp-backend/app/db/models.py#L150)).

### 7.4 `sessions`

One contiguous interaction window for a lamp — opened on WS connect, finalized on disconnect ([models.py:158-188](Smart-Tutor-Lamp-backend/app/db/models.py#L158)). The compaction columns (`summary`, `summary_as_of`) are reserved for the SESSION_MEMORY_GUIDE layer and unused until it ships.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | **PK**, dflt `uuid4` | |
| `device_id` | String | NN | |
| `user_id` | String | nullable | Clerk ID carried by the device_jwt |
| `started_at` | timestamptz | NN, dflt `now()` | |
| `ended_at` | timestamptz | nullable | set on disconnect, **cleared on resume** |
| `last_activity_at` | timestamptz | NN, dflt `now()` | bumped per turn; drives reconnect-resume (30-min idle gap) |
| `turn_count` | Integer | NN, dflt `0` | denorm rollup |
| `summary` | Text | nullable | reserved — LLM-compacted older turns |
| `summary_as_of` | Integer | NN, dflt `0` | turn_count at last compaction |
| `primary_subject` | String | nullable | denorm for analytics |
| `avg_difficulty` | String | nullable | denorm for analytics |

**Indexes** ([models.py:182-188](Smart-Tutor-Lamp-backend/app/db/models.py#L182)): `sessions_device_idx (device_id, started_at)`; `sessions_user_idx (user_id, started_at) WHERE user_id IS NOT NULL`; `sessions_resume_idx (device_id, last_activity_at)` — the reconnect-resume lookup.

**Resume algorithm** (in `open_session`, [SUPABASE_SETUP.md §3.6.4](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L926)): on every WS connect, the most-recent session for `(device_id, user_id)` with `last_activity_at > now() - 30 min` is **resumed** (clear `ended_at`, bump `last_activity_at`); otherwise a fresh row is INSERTed. The match uses `user_id IS NOT DISTINCT FROM :u` so NULL matches NULL (dev mode) and a device re-paired to a different user starts fresh — history never bleeds across users. The 30-minute window is `MEMORY_SESSION_IDLE_MIN` ([config.py:289](Smart-Tutor-Lamp-backend/app/config.py#L289)).

### 7.5 `turns`

The most-written and most-queried table — one completed turn (question → reply) ([models.py:191-247](Smart-Tutor-Lamp-backend/app/db/models.py#L191)). Written fire-and-forget by `app/storage/turns.py`. Error-status turns are skipped by the memory writer so fallbacks never pollute history.

**Identity & timing**

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | **PK**, dflt `uuid4` | |
| `device_id` | String | NN | |
| `user_id` | String | nullable | denorm; NULL in dev/unpaired |
| `session_id` | UUID | nullable | join to `sessions.id` (in code, no FK) |
| `turn_index` | Integer | NN, dflt `1` | 1-based position in session (compaction ordering) |
| `asked_at` | timestamptz | NN, dflt `now()` | |
| `ended_at` | timestamptz | nullable | |

**Inputs / transcript**

| Column | Type | Notes |
|---|---|---|
| `transcript` | Text (nullable) | Whisper STT |
| `image_url` | String (nullable) | blob URL |
| `audio_url` | String (nullable) | blob URL |

**LLM reply** (mirrors `LlmReply`)

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `speech` | Text | NN, dflt `""` | spoken TTS text; `''` on logged failure rows |
| `display_kind` | String | nullable | `'text'`/`'none'` (the `'latex'` kind was removed) |
| `display_content` | Text | nullable | TFT text card |
| `latex_equations` | JSONB | NN, dflt `[]` | separate equation channel — array of LaTeX strings, stored verbatim |

**LLM self-classification**

| Column | Type | Notes |
|---|---|---|
| `confidence` | Numeric(3,2) nullable | 0.00–1.00 |
| `query_type` | String nullable | `concept`/`calc`/`formula`/`derivation`/… |
| `subject` | String nullable | `math`/`physics`/… |
| `difficulty` | String nullable | `easy`/`medium`/`hard` |
| `decay_resistance` | Numeric(3,2) nullable | 0.0–1.0 importance anchor for smart compaction (0.9 = hard derivation kept verbatim, 0.15 = easy check decays first) |

**Provider & telemetry**

| Column | Type | Notes |
|---|---|---|
| `llm_provider` / `llm_model` | String nullable | which LLM answered |
| `llm_input_tok` / `llm_output_tok` / `llm_thinking_tok` | Integer nullable | token spend; thinking = Gemini hidden CoT |
| `ttft_ms` / `total_ms` | Integer nullable | latency |
| `cost_usd` | Numeric(10,6) nullable | total turn cost |

**Escalation (ESCALATION_PLAN §2.8)**

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `status` | String | NN, dflt `"ok"` | |
| `escalated` | Boolean | NN, dflt `false` | denorm of `len(escalation_path) > 1` |
| `final_tier` | Integer | NN, dflt `1` | which tier shipped (1/2/3/4) |
| `escalation_path` | `ARRAY(Text)` | NN, dflt `{}` | e.g. `['tier1','tier3']` — matches Postgres `text[]` ([models.py:239](Smart-Tutor-Lamp-backend/app/db/models.py#L239)) |
| `extra` | JSONB | NN, dflt `{}` | escape hatch |

**Indexes** ([models.py:242-247](Smart-Tutor-Lamp-backend/app/db/models.py#L242)): `turns_device_idx (device_id, asked_at)`; `turns_session_idx (session_id, turn_index)`; `turns_user_idx (user_id, asked_at) WHERE user_id IS NOT NULL`. (SUPABASE_SETUP.md §3.2 documents many further analytics indexes — BRIN on `asked_at`, GIN on `latex_equations`/`extra`, partial indexes on subject/error/tier — those are part of the production DDL/Alembic path, not created by the ORM `__table_args__`; see §9.)

### 7.6 `turn_traces`

Verbose per-turn execution trace — the admin "visual pipeline audit" row ([models.py:250-324](Smart-Tutor-Lamp-backend/app/db/models.py#L250)). Written fire-and-forget by [`app/services/turn_trace.py`](Smart-Tutor-Lamp-backend/app/services/turn_trace.py); read by `GET /api/frontend/admin/turns/{id}/trace`. **Unlike `turns`, rows are written for FAILED turns too** — failure visibility is the point. `turn_id` links to `turns.id` when that row exists; it stays NULL for error/retake turns that never persisted a `turns` row.

| Group | Columns | Type | Notes |
|---|---|---|---|
| Identity | `id` (UUID PK), `turn_id` (UUID null), `device_id` (String NN dflt `"?"`), `user_id` (null), `session_id` (UUID null) | | |
| Source/status | `source` (String NN dflt `"lamp"` — `lamp`/`simulator`), `status` (NN dflt `"ok"`), `error_detail` (Text null) | | |
| Phase latencies (ms, all Integer nullable; NULL = phase didn't run) | `capture_latency_ms`, `image_enhance_ms`, `stt_latency_ms`, `tier1_latency_ms`, `tier2_latency_ms`, `tier3_latency_ms`, `tts_latency_ms`, `latex_latency_ms`, `processing_latency_ms` (end-to-end) | | [models.py:276-284](Smart-Tutor-Lamp-backend/app/db/models.py#L276) |
| Media URLs | `raw_audio_url`, `raw_image_url`, `enhanced_image_url` (String null) | | NULL when storage off / upload failed |
| Text artifacts | `whisper_transcript`, `llm_raw_prompt_brief`, `llm_raw_response`, `escalation_reason`, `llm_raw_system_prompt` (Text null) | | the exact system-instruction wrapper sent to the LLM |
| Visual grounding | `extracted_ocr_text` (Text null), `bounding_box` (JSONB null) | | what the model read + `[ymin,xmin,ymax,xmax]` normalized to a 0–1000 scale |
| Outcome | `final_tier` (Int NN dflt 1), `escalated` (Bool NN dflt false), `confidence` (Numeric(3,2) null) | | |
| Storyboard | `phases` (JSONB NN dflt `[]`), `extra` (JSONB NN dflt `{}`), `created_at` (timestamptz NN dflt now) | | `phases` = ordered list of `{"phase","ms","status","detail"}` |

**Indexes** ([models.py:320-324](Smart-Tutor-Lamp-backend/app/db/models.py#L320)): partial `turn_traces_turn_idx (turn_id) WHERE turn_id IS NOT NULL`; `turn_traces_device_idx (device_id, created_at)`.

> The three "additive" columns `llm_raw_system_prompt`, `extracted_ocr_text`, `bounding_box` are exactly the ones in `_ADDITIVE_COLUMNS` (§4.5) — they were added after the table first shipped, so the boot-time `ADD COLUMN IF NOT EXISTS` shim patches older deployments ([session.py:113-117](Smart-Tutor-Lamp-backend/app/db/session.py#L113)).

### 7.7 `user_memory`

Cross-session learner profile — **one row per device** (derived from turns, refreshed at session end) ([models.py:327-343](Smart-Tutor-Lamp-backend/app/db/models.py#L327)). Distinct from `user_profiles` (self-declared) and from the deferred vector `memories`.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | **PK**, dflt `uuid4` | |
| `device_id` | String | NN, **U** | the unique key (dev-mode lookup) — `unique=True` gives the device index |
| `user_id` | String | nullable | prod key (Clerk ID) |
| `long_term_summary` | Text | nullable | 1–2 sentence LLM-distilled profile |
| `subject_profile` | JSONB | NN, dflt `{}` | e.g. `{"math":"hard","physics":"medium"}` |
| `session_count` | Integer | NN, dflt `0` | |
| `total_turns` | Integer | NN, dflt `0` | |
| `created_at` / `updated_at` | timestamptz | NN, dflt `now()` | |

The profile build uses an anti-hallucination guard ([SUPABASE_SETUP.md §3.2 user_memory](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L663)): `< 3` turns → no profile; `3–9` turns → numeric template (no LLM); `≥ 10` turns → LLM-generated with a strict "report only the numbers" prompt.

### 7.8 `events`

Generic lifecycle/event log — pairing, ws_open/close, button events, reboots ([models.py:346-363](Smart-Tutor-Lamp-backend/app/db/models.py#L346)). New `kind`s need no migration.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | **PK**, dflt `uuid4` | |
| `device_id` | String | NN | |
| `user_id` | String | nullable | |
| `occurred_at` | timestamptz | NN, dflt `now()` | |
| `kind` | String | NN | `wake`/`cancel`/`ws_open`/`ws_close`/`reboot`/… |
| `payload` | JSONB | NN, dflt `{}` | structured per-kind fields |

**Indexes** ([models.py:360-362](Smart-Tutor-Lamp-backend/app/db/models.py#L360)): `events_device_idx (device_id, occurred_at)`; `events_kind_idx (kind, occurred_at)`.

### 7.9 `cost_log`

Per-API-call cost ledger — optional; use when one turn fans out to several priced calls (LLM + TTS + STT) ([models.py:366-381](Smart-Tutor-Lamp-backend/app/db/models.py#L366)). For single-call turns, `turns.cost_usd` is enough.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | **PK**, dflt `uuid4` | |
| `turn_id` | UUID | nullable | join to `turns.id` |
| `user_id` | String | nullable | |
| `occurred_at` | timestamptz | NN, dflt `now()` | |
| `provider` | String | NN | `gemini`/`cartesia`/`groq`/… |
| `kind` | String | NN | `llm`/`tts`/`stt`/`embed`/`image` |
| `input_units` / `output_units` | Integer | nullable | tokens/chars/images per `kind` |
| `cost_usd` | Numeric(10,6) | nullable | |

No `__table_args__` in the ORM (no model-level indexes); SUPABASE_SETUP.md documents two DDL indexes.

### 7.10 `admins`

Dashboard admin allowlist — one row per privileged Clerk user ([models.py:384-414](Smart-Tutor-Lamp-backend/app/db/models.py#L384)). **Durable source of truth** for who may open `/admin` and call `/api/frontend/admin/*`. The legacy `ADMIN_USER_IDS` / `ADMIN_EMAILS` env lists are a deprecated bootstrap that auto-seeds rows here on first admin-authenticated request — see [config.py:338-345](Smart-Tutor-Lamp-backend/app/config.py#L338) (values intentionally ignored now). Auto-created by `create_all` on boot.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `user_id` | String | **PK** | Clerk ID — join key to everything |
| `email` | String | nullable | stored lower-cased for display + allowlist matching |
| `note` | String | nullable | |
| `created_at` | timestamptz | NN, dflt `now()` | |

**Index**: partial `admins_email_idx (email) WHERE email IS NOT NULL` ([models.py:410-413](Smart-Tutor-Lamp-backend/app/db/models.py#L410)). Read by [`app/services/admin.py:is_admin`](Smart-Tutor-Lamp-backend/app/services/admin.py).

### 7.11 Model-bench tables

A fully separate four-table cluster ([models.py:417-555](Smart-Tutor-Lamp-backend/app/db/models.py#L417)) keeping the "which model answered, how fast, how much, how good" concern apart from the lamp's `turns` history. Same house style: UUID PKs, no DB FKs, JSONB `extra`, auto-created on boot. Seeded by [`app/storage/model_eval.py:seed_providers`](Smart-Tutor-Lamp-backend/app/storage/model_eval.py) from the in-code catalog `app/services/model_catalog.py`.

#### `model_providers` ([models.py:436-458](Smart-Tutor-Lamp-backend/app/db/models.py#L436))
Registry of comparable models + list pricing, best-effort upserted at startup.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | **PK**, dflt `uuid4` | |
| `model_name` | String | NN, **U** | catalog's stable public id (e.g. `"gemini-2.5-flash"`) — the join key |
| `provider_name` | String | NN | `gemini`/`openai`/… |
| `label` | String | NN, dflt `""` | |
| `version` | String | nullable | vendor model id / snapshot |
| `active_status` | Boolean | NN, dflt `false` | whether the provider's API key is configured |
| `input_per_mtok` / `output_per_mtok` | Numeric(12,6) | nullable | list price per million tokens |
| `created_at` / `updated_at` | timestamptz | NN, dflt `now()` | |

**Index**: `model_providers_provider_idx (provider_name)`.

#### `model_requests` ([models.py:461-489](Smart-Tutor-Lamp-backend/app/db/models.py#L461))
One question submitted to the bench — a single-model ask OR a compare group (then `is_compare=True`).

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `request_id` | UUID | **PK**, dflt `uuid4` | |
| `user_id` | String | nullable | |
| `session_id` | UUID | nullable | |
| `created_at` | timestamptz | NN, dflt `now()` | |
| `selected_model` | String | NN, dflt `""` | single id or comma-joined list |
| `is_compare` | Boolean | NN, dflt `false` | |
| `question_text` | Text | nullable | |
| `image_reference` | String | nullable | lightweight reference, not bytes |
| `image_count` | Integer | NN, dflt `0` | |
| `had_audio` | Boolean | NN, dflt `false` | |
| `channel` | String | NN, dflt `"web"` | |
| `extra` | JSONB | NN, dflt `{}` | |

**Indexes**: partial `model_requests_user_idx (user_id, created_at) WHERE user_id IS NOT NULL`; `model_requests_created_idx (created_at)`.

#### `model_responses` ([models.py:492-525](Smart-Tutor-Lamp-backend/app/db/models.py#L492))
One model's answer — the heart of the metrics layer. **`success_status=False` rows are KEPT** because failure/timeout rates *are* the metric.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `response_id` | UUID | **PK**, dflt `uuid4` | |
| `request_id` | UUID | nullable | join to `model_requests.request_id` |
| `user_id` | String | nullable | |
| `created_at` | timestamptz | NN, dflt `now()` | |
| `model_name` | String | NN | catalog id |
| `provider` | String | nullable | |
| `generated_answer` | Text | NN, dflt `""` | |
| `latency_ms` | Integer | nullable | |
| `input_tokens` / `output_tokens` / `total_tokens` | Integer | nullable | |
| `estimated_cost` | Numeric(12,6) | nullable | |
| `success_status` | Boolean | NN, dflt `true` | |
| `status` | String | NN, dflt `"ok"` | `ok`/`not_configured`/`timeout`/`error` — finer than the bool, drives timeout/failure split |
| `error_message` | Text | nullable | |
| `extra` | JSONB | NN, dflt `{}` | model classification/display |

**Indexes**: `model_responses_request_idx (request_id)`; `model_responses_model_idx (model_name, created_at)`; partial `model_responses_user_idx (user_id, created_at) WHERE user_id IS NOT NULL`.

#### `model_feedback` ([models.py:528-555](Smart-Tutor-Lamp-backend/app/db/models.py#L528))
A learner's rating of one `model_responses` row — thumbs and/or 1–5 stars and/or text. **One row per (response, user); re-submitting UPSERTs.**

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | **PK**, dflt `uuid4` | |
| `response_id` | UUID | NN | |
| `user_id` | String | nullable | |
| `created_at` / `updated_at` | timestamptz | NN, dflt `now()` | |
| `user_rating` | Integer | nullable, **CHECK** | `BETWEEN 1 AND 5 OR NULL` |
| `thumbs` | String | nullable, **CHECK** | `IN ('up','down') OR NULL` |
| `feedback_text` | Text | nullable | |

**Constraints/Indexes** ([models.py:544-554](Smart-Tutor-Lamp-backend/app/db/models.py#L544)): `model_feedback_thumbs_check`, `model_feedback_rating_check`, and a **UNIQUE** index `model_feedback_resp_user_idx (response_id, user_id)` — the storage layer UPSERTs on it.

### 7.12 `memories` (deferred, not ORM-mapped)

The pgvector ANN table (Layer 3.3) is **intentionally NOT ORM-mapped** ([models.py:558-561](Smart-Tutor-Lamp-backend/app/db/models.py#L558)): its `embedding vector(1536)` column needs the `pgvector` package and is deferred. When Layer 3.3 ships it will be accessed via raw SQL (`ORDER BY embedding <=> $1::vector`). The documented DDL ([SUPABASE_SETUP.md §3.2 memories](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L668)):

```sql
CREATE TABLE memories (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     text NOT NULL,
  kind        text NOT NULL DEFAULT 'turn' CHECK (kind IN ('turn','note','goal','correction')),
  content     text NOT NULL,
  embedding   vector(1536),                 -- OpenAI text-embedding-3-small dim
  source_turn uuid REFERENCES turns(id) ON DELETE SET NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX memories_embedding_idx ON memories USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
```
IVFFlat tuning rule: `lists ≈ sqrt(N_rows)`, start at 100, recreate past 10K rows. `<=>` is cosine distance; `1 - distance` is cosine similarity in [-1, 1].

### 7.13 Tables added since the 2026-06-16 sync

Eight ORM tables (bringing the total to 24) landed with the pilot-program, analytics-tagging, and OTA subsystems. All keep the house style: UUID PKs (except the two natural-key profiles), no DB FKs (plain join columns), `timestamptz` + `server_default=func.now()`, JSONB escape hatches, and auto-creation by `create_all`. None touch the live turn hot path.

**Pilot instrumentation** — written by [`app/storage/pilot.py`](Smart-Tutor-Lamp-backend/app/storage/pilot.py) (same DB-gated, crash-safe, fire-and-forget discipline as `model_eval.py`):

| Table | PK | Key columns / constraints | Notes |
|---|---|---|---|
| `turn_feedback` ([models.py:608](Smart-Tutor-Lamp-backend/app/db/models.py#L608)) | `id` UUID | `turn_id` NN (join to `turns.id`), `thumbs` CHECK `('up','down')`, `reason` (down-vote chip), `resolution` CHECK `('got_it','still_stuck','explain_differently')`, `user_rating` CHECK `1–5`; **UNIQUE `(turn_id, user_id)`** partial `turn_feedback_turn_user_idx` | Pilot **F1** — a learner's verdict on ONE real lamp/sim answer; UPSERT-merge (only provided fields overwrite). The storage layer validates the target `turns` row exists before writing. Distinct from `model_feedback` (bench). |
| `survey_responses` ([models.py:654](Smart-Tutor-Lamp-backend/app/db/models.py#L654)) | `id` UUID | `user_id` NN, `survey_kind` CHECK `('baseline','exit','weekly')`, `version`, `answers` JSONB; idx `(user_id, survey_kind)` + `(survey_kind, submitted_at)` | Pilot **F2** — append-only; the questionnaire evolves in JSONB with no migration, form version stamped in `version`. |
| `problem_reports` ([models.py:679](Smart-Tutor-Lamp-backend/app/db/models.py#L679)) | `id` UUID | `category`, `message`, `context` JSONB, `status` CHECK `('open','triaged','resolved')` dflt `open`; idx `(status, created_at)` + partial user idx | Pilot **F5** — one-tap "something's wrong"; `status` drives an admin triage queue. |
| `user_consents` ([models.py:707](Smart-Tutor-Lamp-backend/app/db/models.py#L707)) | `id` UUID | `user_id` NN, `consent_type`, `version`, `granted` bool, `source`, `extra` JSONB; idx `(user_id, consent_type)` | Pilot **F7** — immutable, append-only audit trail (one row per grant/withdrawal); guardian/PII in `extra` under the PII-masking policy. |
| `student_personalization` ([models.py:729](Smart-Tutor-Lamp-backend/app/db/models.py#L729)) | `user_id` (Clerk str) | `interests` JSONB list, `answer_length` (`short`/`balanced`/`detailed`), `example_pref` (`love`/`sometimes`/`rarely`), `notes` | **COLLECTION ONLY** — captured now, prompt-injection is a separate decision. Kept apart from `user_profiles` for a stricter (consent-gated) PII boundary. |

**Analytics tagging** — offline enrichment; the live pipeline and `turns` are never touched. `syllabus_topics` is seeded controlled-vocabulary reference data; the two result tables are written fire-and-forget by the batch workers:

| Table | PK | Key columns / constraints | Notes |
|---|---|---|---|
| `syllabus_topics` ([models.py:760](Smart-Tutor-Lamp-backend/app/db/models.py#L760)) | `id` UUID | `exams` **`ARRAY(Text)`** (a shared topic is one row tagged with all its exams), `subject` NN, `unit`, `topic` NN, `code` UNIQUE, `aliases` JSONB, `sort_order`, `active`; idx `(subject)` | Canonical syllabus taxonomy; the tagger maps a turn's text to one of these rows. |
| `turn_topics` ([models.py:784](Smart-Tutor-Lamp-backend/app/db/models.py#L784)) | `id` UUID | `turn_id` **UNIQUE** (re-tag UPSERTs), `topic_id`/`topic_code`/`subject`, `confidence` `Numeric(3,2)`, `source` dflt `keyword`, `model`; idx `(topic_id)` + `(source)` | Written by [`app/workers/topic_tag.py`](Smart-Tutor-Lamp-backend/app/workers/topic_tag.py) (picks up `status='ok'` turns lacking a row; always writes one, even `unmapped`). Analytics JOIN here; `turns` unchanged. |
| `turn_mistakes` ([models.py:808](Smart-Tutor-Lamp-backend/app/db/models.py#L808)) | `id` UUID | `turn_id` **UNIQUE**, `mistake_type` dflt `none`, `confidence`, `source` dflt `keyword`, `model`; idx `(mistake_type)` | Written by [`app/workers/mistake_tag.py`](Smart-Tutor-Lamp-backend/app/workers/mistake_tag.py); always writes a row (even `none`) so a turn is never reprocessed. |

**OTA firmware releases** — written by [`app/services/ota_release.py`](Smart-Tutor-Lamp-backend/app/services/ota_release.py):

| Table | PK | Key columns / constraints | Notes |
|---|---|---|---|
| `firmware_releases` ([models.py:836](Smart-Tutor-Lamp-backend/app/db/models.py#L836)) | `id` UUID | `version` int, `bin` **`LargeBinary`** (the image IN-DB), `size`, `content_type`, `notes`, `is_current` bool, `created_by`; idx `(is_current)` | The `.bin` lives in Postgres (bytea) and the backend serves it itself (`GET /lamp/ota/firmware.bin`) — a release is a row, not an env var / external object, so it needs no redeploy. Exactly one row `is_current=True`; `publish()` demotes the rest and prunes to the newest `_KEEP=5`. |

---

## 8. Entity-Relationship Diagram

The relationships are **logical** (enforced in code, not by DB FKs in the ORM). `user_id` is a Clerk string, denormalized onto every child row.

```mermaid
erDiagram
    devices {
        string device_id PK
        string device_secret_hash
        string user_id "Clerk ID, null=unpaired"
        string friendly_name
        timestamptz paired_at
        timestamptz last_seen_at
        timestamptz revoked_at
        timestamptz created_at
    }
    pairing_codes {
        string code PK
        string device_id
        string user_id
        string status "pending|paired|expired"
        string device_jwt
        timestamptz expires_at
    }
    user_profiles {
        string user_id PK "Clerk ID"
        string full_name
        string target_exam "JEE|NEET|CAT|UPSC"
        bool onboarding_complete
        jsonb extra
    }
    sessions {
        uuid id PK
        string device_id
        string user_id
        timestamptz last_activity_at
        int turn_count
        text summary
    }
    turns {
        uuid id PK
        string device_id
        string user_id
        uuid session_id
        int turn_index
        text speech
        jsonb latex_equations
        int final_tier
        text_array escalation_path
        numeric cost_usd
    }
    turn_traces {
        uuid id PK
        uuid turn_id "null for failed turns"
        string device_id
        string source "lamp|simulator"
        jsonb phases
    }
    user_memory {
        uuid id PK
        string device_id UK
        string user_id
        text long_term_summary
        jsonb subject_profile
    }
    events {
        uuid id PK
        string device_id
        string kind
        jsonb payload
    }
    cost_log {
        uuid id PK
        uuid turn_id
        string provider
        string kind
    }
    admins {
        string user_id PK
        string email
    }
    memories {
        uuid id PK
        string user_id
        vector embedding
        uuid source_turn
    }
    model_providers {
        uuid id PK
        string model_name UK
        string provider_name
        bool active_status
    }
    model_requests {
        uuid request_id PK
        string user_id
        bool is_compare
        text question_text
    }
    model_responses {
        uuid response_id PK
        uuid request_id
        string model_name
        bool success_status
        string status
    }
    model_feedback {
        uuid id PK
        uuid response_id
        string user_id
        int user_rating
        string thumbs
    }

    devices ||--o{ pairing_codes : "device_id"
    devices ||--o{ sessions      : "device_id"
    devices ||--o{ events        : "device_id"
    devices ||--o| user_memory   : "device_id (unique)"
    sessions ||--o{ turns        : "session_id"
    turns   ||--o{ turn_traces   : "turn_id (nullable)"
    turns   ||--o{ cost_log      : "turn_id"
    turns   ||--o{ memories      : "source_turn"
    user_profiles ||--o{ sessions : "user_id (Clerk)"
    model_requests  ||--o{ model_responses : "request_id"
    model_responses ||--o{ model_feedback  : "response_id"
    model_providers ||--o{ model_responses : "model_name"
```

> The 2026-07-03 tables (§7.13) are omitted from the diagram above for readability; their logical relationships are all by plain join column (no DB FKs), same as the rest: `turns ||--o| turn_feedback : "turn_id (unique)"`, `turns ||--o| turn_topics : "turn_id (unique)"`, `turns ||--o| turn_mistakes : "turn_id (unique)"`, `syllabus_topics ||--o{ turn_topics : "topic_id"`, and `user_profiles`/`student_personalization`/`survey_responses`/`user_consents`/`problem_reports` all keyed by the Clerk `user_id`. `firmware_releases` stands alone (OTA image store).

---

## 9. Index Inventory & Rationale

Indexes actually created by the ORM (`__table_args__`), grouped:

| Table | Index | Columns / predicate | Purpose |
|---|---|---|---|
| devices | `devices_user_idx` | `user_id WHERE user_id IS NOT NULL` (partial) | `/api/devices` per-user listing |
| pairing_codes | `pairing_codes_device_idx` | `device_id` | poll/complete by device |
| user_profiles | `user_profiles_exam_idx` | `target_exam WHERE NOT NULL` (partial) | cohort analytics |
| sessions | `sessions_device_idx` | `device_id, started_at` | per-device session history |
| sessions | `sessions_user_idx` | `user_id, started_at WHERE NOT NULL` (partial) | per-user sessions |
| sessions | `sessions_resume_idx` | `device_id, last_activity_at` | reconnect-resume hot lookup |
| turns | `turns_device_idx` | `device_id, asked_at` | "this device's last N turns" |
| turns | `turns_session_idx` | `session_id, turn_index` | ordered session replay/compaction |
| turns | `turns_user_idx` | `user_id, asked_at WHERE NOT NULL` (partial) | frontend `/history` |
| turn_traces | `turn_traces_turn_idx` | `turn_id WHERE NOT NULL` (partial) | trace-by-turn lookup |
| turn_traces | `turn_traces_device_idx` | `device_id, created_at` | per-device trace stream |
| events | `events_device_idx`, `events_kind_idx` | `(device_id,occurred_at)`, `(kind,occurred_at)` | per-device / per-kind logs |
| admins | `admins_email_idx` | `email WHERE NOT NULL` (partial) | "is this email an admin" |
| model_providers | `model_providers_provider_idx` | `provider_name` | registry filter |
| model_requests | `model_requests_user_idx` (partial), `model_requests_created_idx` | | bench history |
| model_responses | `model_responses_request_idx`, `model_responses_model_idx`, `model_responses_user_idx` (partial) | | metrics slicing |
| model_feedback | `model_feedback_resp_user_idx` | `(response_id, user_id)` **UNIQUE** | UPSERT target |

**Analytics indexes documented but ORM-absent**: SUPABASE_SETUP.md §3.2 specifies many further indexes for the production DDL/Alembic path that the ORM `__table_args__` do **not** create — notably `turns_asked_at_brin` (BRIN, ~1000× smaller than B-tree for time-range scans), `turns_latex_gin` / `turns_extra_gin` (GIN over JSONB), `turns_escalation_path_gin`, partial `turns_subject_idx` / `turns_error_idx` / `turns_tier_at_idx` / `turns_escalated_idx`, plus `events_at_brin`, `cost_log_at_brin`, and the `memories` IVFFlat ANN index. These are hand-added in the Alembic migration step ([SUPABASE_SETUP.md §4.3](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1146)) because autogen misses BRIN/GIN/IVFFlat/partial/CHECK. On a `create_all`-only deployment they simply won't exist (queries still work, just slower at scale).

---

## 10. Normalization Stance & Deliberate Denormalizations

The entities are in **3NF** — each fact lives in exactly one place ([SUPABASE_SETUP.md §3.6.1](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L870)). Three conscious denormalizations exist, each a read-speed-for-write-cost trade with a stated invariant:

| # | Denormalization | Why | Consistency invariant |
|---|---|---|---|
| 1 | `user_id` copied onto `sessions`/`turns`/`user_memory`/`events`/`model_*` | per-user reads + RLS (`auth.jwt()->>'sub' = user_id`) must work without joining `devices` on every row | Backend stamps `user_id` **at write time** from the authenticated socket. Historical rows are **never rewritten** when a device is re-paired to a different user — a turn keeps the `user_id` that owned it (exactly what analytics + GDPR want). |
| 2 | `sessions.turn_count` / `primary_subject` / `avg_difficulty` | session-resume + profile-load hot path must not `COUNT(*)`/`GROUP BY turns` | incremented in the **same transaction** as each turn insert (`write_turn` bumps `turn_count` + `last_activity_at`, [turns.py:212](Smart-Tutor-Lamp-backend/app/storage/turns.py#L212)) |
| 3 | `turns.cost_usd` | dashboards `SUM(cost_usd)` must not unpack JSONB per row | written together with the breakdown at persist time |

Large columns (`speech`, `display_content`, `latex_equations`) are deliberately **single-homed** — never copied to a second table. Redis holds a *truncated* copy for hot reads but Postgres `turns` remains the single source of truth.

---

## 11. Boot-Time Control Flow

The lifespan in [`app/main.py`](Smart-Tutor-Lamp-backend/app/main.py#L38) orchestrates DB bring-up:

```mermaid
flowchart TD
    A[lifespan start] --> B[run_all_startup_checks]
    B --> C{ENABLE_AUTH?}
    C -->|yes| D{required auth env vars set?<br/>DEVICE_JWT_SECRET,<br/>CLERK_SECRET_KEY,<br/>DATABASE_URL...}
    D -->|missing| E[raise RuntimeError - fail loud]
    D -->|ok| F
    C -->|no| F{DATABASE_URL set?}
    F -->|no| G[log: running stateless<br/>no persistence]
    F -->|yes| H[import app.db.session.init_db]
    H --> I["init_db(create_tables=True)"]
    I --> I1[create_async_engine<br/>pool_size=10, pre_ping,<br/>recycle 1800s, SSL auto]
    I1 --> I2[async_sessionmaker<br/>expire_on_commit=False]
    I2 --> I3[Base.metadata.create_all<br/>creates MISSING tables only]
    I3 --> I4[_ensure_additive_columns<br/>ALTER ... ADD COLUMN IF NOT EXISTS<br/>best-effort per column]
    I4 --> J[seed_providers<br/>upsert model_catalog -> model_providers]
    J --> K[log: ✓ DB ready]
    I -->|exception & ENABLE_AUTH| E
    I -->|exception & auth off| L[log.exception<br/>continue STATELESS]
    K --> M{REDIS_URL set?}
    G --> M
    M -->|yes| N[init_redis - eager PING]
    M -->|no| O[Redis no-op / fallbacks]
    N --> P[serve traffic]
    O --> P
```

Key facts from [main.py:71-101](Smart-Tutor-Lamp-backend/app/main.py#L71):

- DB initializes **whenever `DATABASE_URL` is set — independent of auth**. Auth *requires* it (enforced earlier), but turn/session persistence also uses it, so dev can store sessions with auth OFF.
- The `init_db` import is **inside the try** so a missing/old SQLAlchemy degrades gracefully instead of crashing boot when auth is off ([main.py:77-80](Smart-Tutor-Lamp-backend/app/main.py#L77)).
- After a successful init, `seed_providers()` upserts the model catalog (best-effort; failure logged + continue) ([main.py:84-89](Smart-Tutor-Lamp-backend/app/main.py#L84)).
- On init failure: if `ENABLE_AUTH` → re-raise (auth can't function without DB); else log the exception and continue **STATELESS** ([main.py:90-101](Smart-Tutor-Lamp-backend/app/main.py#L90)) — this catches the common `[YOUR-DB-PASSWORD]` placeholder case.
- On shutdown, `dispose_db()` is called only when `ENABLE_AUTH` is true ([main.py:132-134](Smart-Tutor-Lamp-backend/app/main.py#L132)).

---

## 12. Configuration & Environment Variables

DB-relevant settings from [`app/config.py`](Smart-Tutor-Lamp-backend/app/config.py) (Pydantic `BaseSettings`, loaded from `.env`):

| Variable | Default | Effect |
|---|---|---|
| `DATABASE_URL` | `""` | `postgresql+asyncpg://…` connection string. Empty → stateless. Required when `ENABLE_AUTH=True`. [config.py:213](Smart-Tutor-Lamp-backend/app/config.py#L213) |
| `DATABASE_SSL` | `""` (AUTO) | asyncpg sslmode. AUTO → `require` for `*.supabase.co/.com`, off for localhost. Override with `disable`/`prefer`/`require`/`verify-ca`/`verify-full`. [config.py:214-219](Smart-Tutor-Lamp-backend/app/config.py#L214) |
| `ENABLE_AUTH` | `False` | Master auth toggle. `True` requires `DATABASE_URL` + Clerk + JWT secrets and makes DB init failure fatal. [config.py:297](Smart-Tutor-Lamp-backend/app/config.py#L297) |
| `REDIS_URL` | `""` | Single switch for all caching/acceleration in front of Postgres. Blank → Postgres-only, clean fallbacks. [config.py:228](Smart-Tutor-Lamp-backend/app/config.py#L228) |
| `ENABLE_MEMORY` | `True` | Master toggle for L1+L2+L3 conversational memory (writes `sessions`/`turns`/`user_memory`). [config.py:282](Smart-Tutor-Lamp-backend/app/config.py#L282) |
| `MEMORY_SESSION_IDLE_MIN` | `30` | Idle gap (min) before a reconnect starts a fresh session — the resume window in `open_session`. [config.py:289](Smart-Tutor-Lamp-backend/app/config.py#L289) |
| `MEMORY_COMPACT_THRESHOLD` | `8` | Turns before older turns compact into `sessions.summary`. [config.py:285](Smart-Tutor-Lamp-backend/app/config.py#L285) |
| `MEMORY_TAIL_SIZE` | `3` | Most-recent turns kept verbatim in the prompt. [config.py:287](Smart-Tutor-Lamp-backend/app/config.py#L287) |
| `TURN_TRACE_ENABLED` | `True` | Whether each turn writes a `turn_traces` row (no-op without `DATABASE_URL`). [config.py:276](Smart-Tutor-Lamp-backend/app/config.py#L276) |
| `STORAGE_BACKEND` | `"local"` | Where raw audio/image blobs go; populates `turns.image_url`/`audio_url` (the DB stores only the URL). `off`/`local`/`s3`/`r2`. [config.py:241](Smart-Tutor-Lamp-backend/app/config.py#L241) |
| `SQL_ECHO` | `False` | Print every SQL statement + params (debug). [config.py:745](Smart-Tutor-Lamp-backend/app/config.py#L745) |
| `LOG_SQL_POOL` | `False` | Print DB connection-pool events. [config.py:746](Smart-Tutor-Lamp-backend/app/config.py#L746) |
| `ADMIN_USER_IDS` / `ADMIN_EMAILS` | `""` | **DEPRECATED / ignored** — admin access now governed solely by the `admins` table. [config.py:338-345](Smart-Tutor-Lamp-backend/app/config.py#L338) |

Note: the engine pool params (`pool_size=10`, `max_overflow=10`, `pool_recycle=1800`) are **hardcoded in `session.py`**, not env-driven.

---

## 13. Edge Cases, Errors, Fallbacks

| Scenario | Handling | Location |
|---|---|---|
| `DATABASE_URL` unset | App boots **stateless** (no persistence); `init_db` raises if called anyway | [main.py:100-101](Smart-Tutor-Lamp-backend/app/main.py#L100), [session.py:83-87](Smart-Tutor-Lamp-backend/app/db/session.py#L83) |
| Engine used before `init_db` | `get_engine()`/`get_session_factory()` raise `RuntimeError` (programming error) | [session.py:55-70](Smart-Tutor-Lamp-backend/app/db/session.py#L55) |
| DB init fails, auth OFF | Logged, continue stateless | [main.py:94-99](Smart-Tutor-Lamp-backend/app/main.py#L94) |
| DB init fails, auth ON | Re-raised — fail loud at boot | [main.py:91-93](Smart-Tutor-Lamp-backend/app/main.py#L91) |
| Supabase rejects plaintext | SSL auto-forces `require` for `*.supabase.co/.com` | [session.py:46-48](Smart-Tutor-Lamp-backend/app/db/session.py#L46) |
| Half-dead pooled connection | `pool_pre_ping=True` detects + replaces; `pool_recycle=1800` caps connection age | [session.py:92-93](Smart-Tutor-Lamp-backend/app/db/session.py#L92) |
| Table predates a new column | Boot-time `ALTER … ADD COLUMN IF NOT EXISTS` shim (best-effort, swallows errors) | [session.py:120-134](Smart-Tutor-Lamp-backend/app/db/session.py#L120) |
| Additive ALTER fails (restricted role) | `log.warning(... exc_info=True)`, continue; tracer drops rows until column exists | [session.py:132-134](Smart-Tutor-Lamp-backend/app/db/session.py#L132) |
| Exception in a request handler | `get_db` logs + rolls back + re-raises (never silent) | [session.py:154-159](Smart-Tutor-Lamp-backend/app/db/session.py#L154) |
| Turn-persistence failure | Storage writers swallow exceptions — persistence MUST NOT break the response path | [SUPABASE_SETUP.md §5.2](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1361) |
| Error-status / fallback turns | Skipped by the memory writer (`status != 'ok'` not persisted to `turns`) so fallbacks never pollute history | [models.py:191-196](Smart-Tutor-Lamp-backend/app/db/models.py#L191) |
| `turn_traces` for failed turns | Deliberately written (failure visibility is the point); `turn_id` stays NULL | [models.py:256-261](Smart-Tutor-Lamp-backend/app/db/models.py#L256) |
| Redis down/disabled | Hot reads fall back to Postgres; revocation falls back to ≤30 s heartbeat; rate limiter uses in-memory store | [config.py:221-228](Smart-Tutor-Lamp-backend/app/config.py#L221) |
| Cross-user resume safety | `open_session` matches `user_id IS NOT DISTINCT FROM` → re-paired device starts fresh; cached session id re-validated | [SUPABASE_SETUP.md §3.6.4](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L946) |
| `un-migrated` DB missing `last_activity_at` | `open_session` degrades to "no session row" (turns still carry `user_id`) | [turns.py:133](Smart-Tutor-Lamp-backend/app/storage/turns.py#L133) |

---

## 14. Integration Points (who calls what)

**Calls into the DB layer:**

- **`app/main.py` lifespan** → `init_db(create_tables=True)` on boot (when `DATABASE_URL` set) and `dispose_db()` on shutdown ([main.py:81,134](Smart-Tutor-Lamp-backend/app/main.py#L81)).
- **`app/storage/turns.py`** → `get_session_factory()` for `open_session`/`close_session`/`write_turn`/`load_recent_turns`, writing `sessions` + `turns`. Called by the WS orchestrator (`_persist_turn`) and by `ws_lamp.py` on connect/disconnect ([turns.py:47-53,166](Smart-Tutor-Lamp-backend/app/storage/turns.py#L47)).
- **`app/services/turn_trace.py`** → `turn_traces` (fire-and-forget; needs `DATABASE_URL`, media URLs need `STORAGE_BACKEND != off`).
- **`app/services/session_memory.py` + `app/storage/user_memory.py`** → `user_memory` (refreshed at session end).
- **`app/storage/user_profiles.py`** ← `app/routes/frontend_manager.py` (`PUT /api/frontend/profile`) → `user_profiles`.
- **`app/storage/model_eval.py:seed_providers`** ← `app/main.py` lifespan → upserts `model_providers`; bench routes write `model_requests`/`model_responses`/`model_feedback`.
- **`app/services/admin.py:is_admin`** → `admins` (with `ADMIN_*` env bootstrap auto-seed).
- **Auth routes** (`device_lamp.py`, `device_user.py`, `clerk_webhook.py`, `pairing_info.py`) → `devices` + `pairing_codes`; `ws_lamp.py:_authenticate_prod` reads `device_jwt.uid` then checks `devices.user_id == jwt.uid AND revoked_at IS NULL` ([SUPABASE_SETUP.md §3.1a step 5](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L226)).
- **`app/routes/health.py`** → DB readiness probe.

**What the DB layer calls out to:** only `app.config.settings` (for `DATABASE_URL`/`DATABASE_SSL`) and `app.db.models.Base`. It has no other dependencies — the engine is the leaf.

**Cross-system flow** (firmware ↔ backend ↔ DB ↔ frontend): the ESP32 lamp pairs via QR (`pairing_codes`), connects over WebSocket carrying a `device_jwt`; the gateway validates against `devices`; the orchestrator stamps `user_id`+`device_id`+`session_id` onto every `sessions`/`turns`/`turn_traces` row; the Next.js frontend reads per-user history (eventually directly via Supabase REST + RLS using the Clerk JWT `sub` claim, [SUPABASE_SETUP.md §3.3](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L734)); the web simulator's `/solve` path writes `turn_traces` with `source='simulator'` and the model-bench tables.

---

## 15. Migrations: current state vs. documented Alembic path

**Current reality**: `app/db/migrations/` contains **only a `.keep` placeholder** — Alembic is **not initialized** (no `env.py`, no `versions/`, no `alembic.ini`). The schema is materialized at boot by `Base.metadata.create_all` (§4.4) plus the `_ensure_additive_columns` shim (§4.5). This is the dev/single-deployment path: it creates missing tables and patches the three known additive `turn_traces` columns, but it **does not** create the CHECK constraints beyond what the ORM declares, nor the BRIN/GIN/IVFFlat/partial analytics indexes, nor the materialized views.

**Documented prod path** ([SUPABASE_SETUP.md §4](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L1056)): run `alembic init -t async app/db/migrations`, point `env.py` at `settings.DATABASE_URL` with `target_metadata = Base.metadata`, autogenerate the initial revision, then **hand-edit** `upgrade()` to add what autogen misses — BRIN (`turns_asked_at_brin`), partial indexes (`turns_error_idx`, `turns_subject_idx`), GIN (`turns_extra_gin`, `turns_latex_gin`), the pgvector extension + IVFFlat (`memories_embedding_idx`), and the materialized views (`turns_daily`, `turns_subject_weekly`). In prod the intent is `init_db(create_tables=False)` so Alembic owns DDL — but the live `main.py` currently passes `create_tables=True` regardless ([main.py:81](Smart-Tutor-Lamp-backend/app/main.py#L81)), which is a harmless no-op once tables exist.

**Materialized views** (analytics, refreshed nightly by `workers/rollup.py`, [SUPABASE_SETUP.md §3.5](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md#L807)): `turns_daily` (per-device daily counts, tier mix, p50/p95 TTFT + total, cost + token sums) and `turns_subject_weekly` (per-user subject mix). Both have a UNIQUE index so `REFRESH … CONCURRENTLY` works. These are part of the documented DDL only — not created by the ORM.

---

*Sources read in full: [`app/db/models.py`](Smart-Tutor-Lamp-backend/app/db/models.py) (562 lines), [`app/db/session.py`](Smart-Tutor-Lamp-backend/app/db/session.py) (160 lines), [`app/db/__init__.py`](Smart-Tutor-Lamp-backend/app/db/__init__.py) (empty), [`app/db/migrations/`](Smart-Tutor-Lamp-backend/app/db/migrations) (only `.keep`), [`SUPABASE_SETUP.md`](Smart-Tutor-Lamp-backend/SUPABASE_SETUP.md) (1677 lines), [`app/config.py`](Smart-Tutor-Lamp-backend/app/config.py) (754 lines). Cross-referenced: `app/main.py`, `app/storage/turns.py`, `app/storage/model_eval.py`.*
